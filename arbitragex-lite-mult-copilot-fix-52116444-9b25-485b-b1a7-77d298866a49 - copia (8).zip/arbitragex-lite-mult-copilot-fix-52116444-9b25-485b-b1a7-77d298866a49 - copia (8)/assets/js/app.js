// Aplicación principal de ArbitrageX
import { appHeader, $ } from './components.js';
import { initFilters } from './filters.js';
import { stream, getJSON } from './api.js';
import { renderChecklist } from './coverage.js';

const LS_UI = 'arbitragex.ui.state.v1';

// Estado global de la aplicación
const AppState = {
  currentHub: 0,
  lastUpdate: null,
  serverTime: null,
  theme: 'light',
  filters: {},
  charts: {}
};

// Función para establecer el header
function setHeader(activeIndex) {
  const headerContainer = $('#app-header');
  if (headerContainer) {
    headerContainer.innerHTML = appHeader(activeIndex);
  }
}

// Función para actualizar el reloj
function setClock({ serverTime, lastUpdate }) {
  const timeElement = $('#clockTime');
  const lastElement = $('#clockLast');
  
  if (!timeElement || !lastElement) return;
  
  if (serverTime) {
    timeElement.textContent = formatTime(serverTime);
    AppState.serverTime = serverTime;
  } else {
    timeElement.textContent = 'N/D';
  }
  
  if (lastUpdate) {
    lastElement.textContent = `Últ. act.: ${formatTime(lastUpdate)}`;
    AppState.lastUpdate = lastUpdate;
  } else {
    lastElement.textContent = 'Últ. act.: N/D';
  }
}

// Función para formatear tiempo
function formatTime(timestamp) {
  try {
    const date = new Date(timestamp);
    if (isNaN(date.getTime())) return 'N/D';
    
    return date.toLocaleString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  } catch {
    return 'N/D';
  }
}

// Función para cargar estado de UI
function loadUIState() {
  try {
    return JSON.parse(localStorage.getItem(LS_UI)) || {};
  } catch {
    return {};
  }
}

// Función para guardar estado de UI
function saveUIState(patch) {
  try {
    const state = { ...loadUIState(), ...patch };
    localStorage.setItem(LS_UI, JSON.stringify(state));
  } catch (error) {
    console.warn('No se pudo guardar el estado de UI:', error);
  }
}

// Función para inicializar el tema
function initTheme() {
  const savedTheme = localStorage.getItem('arbitragex.theme') || 'auto';
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  let theme = savedTheme;
  if (savedTheme === 'auto') {
    theme = prefersDark ? 'dark' : 'light';
  }
  
  document.documentElement.setAttribute('data-theme', theme);
  AppState.theme = theme;
  
  // Event listener para cambios de tema del sistema
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (savedTheme === 'auto') {
      const newTheme = e.matches ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', newTheme);
      AppState.theme = newTheme;
    }
  });
}

// Función para cambiar tema
function toggleTheme() {
  const themes = ['light', 'dark', 'auto'];
  const currentIndex = themes.indexOf(AppState.theme);
  const nextIndex = (currentIndex + 1) % themes.length;
  const newTheme = themes[nextIndex];
  
  AppState.theme = newTheme;
  localStorage.setItem('arbitragex.theme', newTheme);
  
  if (newTheme === 'auto') {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
  } else {
    document.documentElement.setAttribute('data-theme', newTheme);
  }
  
  // Actualizar icono del botón
  const themeToggle = $('#themeToggle');
  if (themeToggle) {
    const icons = { light: '🌙', dark: '☀️', auto: '🔄' };
    themeToggle.textContent = icons[newTheme];
  }
}

// Función para inicializar la aplicación
export function boot({ hubIndex }) {
  AppState.currentHub = hubIndex;
  
  // Establecer header
  setHeader(hubIndex);
  
  // Inicializar tema
  initTheme();
  
  // Inicializar filtros
  initFilters();
  
  // Inicializar sistema de defensa si estamos en DefenseHub
  if (hubIndex === 6) {
    import('./defense.js').then(module => {
      module.initDefenseSystem();
    });
  }
  
  // Restaurar estado de UI
  const uiState = loadUIState();
  if (uiState.search) {
    const searchInput = $('#globalSearch');
    if (searchInput) {
      searchInput.value = uiState.search;
    }
  }
  
  // Event listeners
  setupEventListeners();
  
  // Inicializar reloj
  initClock();
  
  // Renderizar checklist
  renderChecklist();
  
  // Inicializar filtros panel
  initFiltersPanel();
  
  console.log(`ArbitrageX ${hubIndex === 0 ? 'Configuration' : hubIndex === 1 ? 'Monitoring' : hubIndex === 2 ? 'Execution' : hubIndex === 3 ? 'Transaction' : hubIndex === 4 ? 'History' : 'Connectivity'} Hub iniciado`);
}

// Función para configurar event listeners
function setupEventListeners() {
  // Búsqueda global
  const searchInput = $('#globalSearch');
  if (searchInput) {
    searchInput.addEventListener('input', (event) => {
      saveUIState({ search: event.target.value });
    });
  }
  
  // Toggle de tema
  document.addEventListener('click', (event) => {
    if (event.target.id === 'themeToggle') {
      toggleTheme();
    }
  });
  
  // Persistir antes de cerrar
  window.addEventListener('beforeunload', () => {
    saveUIState({ 
      lastVisit: Date.now(),
      currentHub: AppState.currentHub 
    });
  });
}

// Función para inicializar el reloj
function initClock() {
  // Estado inicial del reloj
  setClock({ serverTime: null, lastUpdate: null });
  
  // Intentar SSE primero
  const streamConnection = stream('/api/stream', (event) => {
    const data = event?.data || {};
    const serverTime = data.serverTime || data.time || null;
    const lastUpdate = data.lastUpdate || data.updatedAt || null;
    
    if (serverTime || lastUpdate) {
      setClock({ serverTime, lastUpdate });
    }
  }, { interval: 4000 });
  
  // Poll de respaldo para /status
  let statusPollInterval;
  
  async function statusPoll() {
    try {
      const status = await getJSON('/api/status');
      if (status) {
        const serverTime = status.serverTime || status.time || null;
        const lastUpdate = status.lastUpdate || status.updatedAt || null;
        
        if (serverTime || lastUpdate) {
          setClock({ serverTime, lastUpdate });
        }
      }
    } catch (error) {
      console.warn('Status poll failed:', error);
    }
    
    // Continuar polling cada 8 segundos
    statusPollInterval = setTimeout(statusPoll, 8000);
  }
  
  // Iniciar polling
  statusPoll();
  
  // Cleanup function
  return () => {
    if (streamConnection && streamConnection.stop) {
      streamConnection.stop();
    }
    if (statusPollInterval) {
      clearTimeout(statusPollInterval);
    }
  };
}

// Función para inicializar panel de filtros
function initFiltersPanel() {
  // Agregar panel de filtros al DOM si no existe
  if (!document.getElementById('filtersPanel')) {
    const filtersPanel = document.createElement('div');
    filtersPanel.id = 'filtersPanel';
    filtersPanel.className = 'filters-panel';
    filtersPanel.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin: 0;">Filtros</h3>
        <button class="btn ghost" onclick="toggleFilters()">Cerrar</button>
      </div>
      
      <div class="filter-group">
        <label>Blockchains</label>
        <div class="multi-select" id="filterChains"></div>
        <select class="filter-input" onchange="addFilterTag('filterChains', this.value)">
          <option value="">Seleccionar blockchain...</option>
          <option value="Ethereum">Ethereum</option>
          <option value="BSC">BSC</option>
          <option value="Polygon">Polygon</option>
          <option value="Avalanche">Avalanche</option>
          <option value="Fantom">Fantom</option>
          <option value="Arbitrum">Arbitrum</option>
          <option value="Optimism">Optimism</option>
          <option value="Solana">Solana</option>
          <option value="Cronos">Cronos</option>
          <option value="Gnosis">Gnosis</option>
          <option value="Moonbeam">Moonbeam</option>
          <option value="Base">Base</option>
        </select>
      </div>
      
      <div class="filter-group">
        <label>Estrategia</label>
        <select class="filter-input" id="filterStrategy">
          <option value="">Todas las estrategias</option>
          <option value="Cross-Chain Multi-Hop Flash-Loan">Cross-Chain Multi-Hop Flash-Loan</option>
          <option value="Cross-Chain Cross-DEX">Cross-Chain Cross-DEX</option>
          <option value="Flash-Loan Triangular Cross-DEX">Flash-Loan Triangular Cross-DEX</option>
          <option value="Multi-Hop Cross-DEX">Multi-Hop Cross-DEX</option>
          <option value="Flash-Loan Cross-DEX">Flash-Loan Cross-DEX</option>
          <option value="Triangular Inter-DEX">Triangular Inter-DEX</option>
          <option value="Triangular Intra-DEX">Triangular Intra-DEX</option>
          <option value="Atomic Swap Cross-DEX">Atomic Swap Cross-DEX</option>
          <option value="Atomic Swap Intra-DEX">Atomic Swap Intra-DEX</option>
          <option value="Basic Cross-DEX">Basic Cross-DEX</option>
          <option value="Basic Flash-Loan">Basic Flash-Loan</option>
          <option value="MEV Sandwich Protection">MEV Sandwich Protection</option>
          <option value="Liquidity Rebalancing">Liquidity Rebalancing</option>
          <option value="Yield Farming Arbitrage">Yield Farming Arbitrage</option>
          <option value="Stablecoin Arbitrage">Stablecoin Arbitrage</option>
          <option value="Impermanent Loss Arbitrage">Impermanent Loss Arbitrage</option>
          <option value="Gas Optimization Arbitrage">Gas Optimization Arbitrage</option>
          <option value="Liquidation Arbitrage">Liquidation Arbitrage</option>
          <option value="Oracle Manipulation Arbitrage">Oracle Manipulation Arbitrage</option>
          <option value="Cross-Protocol Arbitrage">Cross-Protocol Arbitrage</option>
          <option value="Time-Based Arbitrage">Time-Based Arbitrage</option>
          <option value="Volatility Arbitrage">Volatility Arbitrage</option>
          <option value="Liquidity Mining Arbitrage">Liquidity Mining Arbitrage</option>
          <option value="Governance Token Arbitrage">Governance Token Arbitrage</option>
          <option value="Wrapped Token Arbitrage">Wrapped Token Arbitrage</option>
          <option value="Bridge Arbitrage">Bridge Arbitrage</option>
          <option value="Layer2 Arbitrage">Layer2 Arbitrage</option>
          <option value="NFT Arbitrage">NFT Arbitrage</option>
          <option value="Options Arbitrage">Options Arbitrage</option>
          <option value="Futures Arbitrage">Futures Arbitrage</option>
          <option value="Perpetual Arbitrage">Perpetual Arbitrage</option>
          <option value="Synthetic Asset Arbitrage">Synthetic Asset Arbitrage</option>
          <option value="Derivatives Arbitrage">Derivatives Arbitrage</option>
          <option value="Insurance Arbitrage">Insurance Arbitrage</option>
          <option value="Prediction Market Arbitrage">Prediction Market Arbitrage</option>
          <option value="Social Trading Arbitrage">Social Trading Arbitrage</option>
          <option value="AI-Powered Arbitrage">AI-Powered Arbitrage</option>
          <option value="Quantitative Arbitrage">Quantitative Arbitrage</option>
          <option value="High-Frequency Arbitrage">High-Frequency Arbitrage</option>
          <option value="Multi-Strategy Arbitrage">Multi-Strategy Arbitrage</option>
          <option value="Cross-Chain Optimization">Cross-Chain Optimization</option>
        </select>
      </div>
      
      <div class="filter-group">
        <label>ROI mínimo (%)</label>
        <input type="number" class="filter-input" id="filterRoiMin" min="0" max="100" value="0">
      </div>
      
      <div class="filter-group">
        <label>Riesgo</label>
        <select class="filter-input" id="filterRisk">
          <option value="">Todos los riesgos</option>
          <option value="Baja">Baja</option>
          <option value="Media">Media</option>
          <option value="Alta">Alta</option>
          <option value="Muy Alta">Muy Alta</option>
        </select>
      </div>
      
      <div class="filter-group">
        <label>Estado</label>
        <select class="filter-input" id="filterStatus">
          <option value="">Todos los estados</option>
          <option value="Activa">Activa</option>
          <option value="En cola">En cola</option>
          <option value="Completada">Completada</option>
          <option value="Fallida">Fallida</option>
        </select>
      </div>
      
      <div class="filter-group">
        <label>Modo</label>
        <select class="filter-input" id="filterMode">
          <option value="">Todos los modos</option>
          <option value="Manual">Manual</option>
          <option value="Semi">Semi</option>
          <option value="Auto">Auto</option>
        </select>
      </div>
      
      <button class="btn" onclick="applyFilters()">Aplicar filtros</button>
      <button class="btn ghost" onclick="clearFilters()">Limpiar</button>
    `;
    
    document.body.appendChild(filtersPanel);
  }
}

// Función para obtener estado de la aplicación
export function getAppState() {
  return { ...AppState };
}

// Función para actualizar estado
export function updateAppState(updates) {
  Object.assign(AppState, updates);
}

// Función para registrar gráfica
export function registerChart(id, chart) {
  AppState.charts[id] = chart;
}

// Función para obtener gráfica
export function getChart(id) {
  return AppState.charts[id];
}

// Función para limpiar gráficas
export function cleanupCharts() {
  Object.values(AppState.charts).forEach(chart => {
    if (chart && typeof chart.destroy === 'function') {
      chart.destroy();
    }
  });
  AppState.charts = {};
}

// Cleanup al cambiar de página
window.addEventListener('beforeunload', cleanupCharts);
