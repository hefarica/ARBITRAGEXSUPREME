// Wrappers para Chart.js en ArbitrageX
export function lineChart(ctx, { labels = [], series = [] } = {}) {
  if (!window.Chart || !ctx) return null;
  
  const data = {
    labels,
    datasets: series.map((s, i) => ({
      label: s.name || `Serie ${i + 1}`,
      data: s.data || [],
      borderColor: getColor(i),
      backgroundColor: getColor(i, 0.1),
      tension: 0.35,
      borderWidth: 2,
      pointRadius: 3,
      pointHoverRadius: 5
    }))
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        backgroundColor: 'rgba(0,0,0,0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: 'rgba(255,255,255,0.2)',
        borderWidth: 1
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          color: 'var(--muted)',
          font: {
            size: 11
          }
        }
      },
      y: {
        grid: {
          color: 'rgba(15,23,42,.06)'
        },
        ticks: {
          color: 'var(--muted)',
          font: {
            size: 11
          }
        }
      }
    },
    interaction: {
      mode: 'nearest',
      axis: 'x',
      intersect: false
    }
  };
  
  return new Chart(ctx, {
    type: 'line',
    data,
    options
  });
}

export function barChart(ctx, { labels = [], series = [] } = {}) {
  if (!window.Chart || !ctx) return null;
  
  const data = {
    labels,
    datasets: series.map((s, i) => ({
      label: s.name || `Serie ${i + 1}`,
      data: s.data || [],
      backgroundColor: getColor(i, 0.8),
      borderColor: getColor(i),
      borderWidth: 1,
      borderRadius: 4
    }))
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        backgroundColor: 'rgba(0,0,0,0.8)',
        titleColor: '#fff',
        bodyColor: '#fff'
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          color: 'var(--muted)'
        }
      },
      y: {
        grid: {
          color: 'rgba(15,23,42,.06)'
        },
        ticks: {
          color: 'var(--muted)'
        }
      }
    }
  };
  
  return new Chart(ctx, {
    type: 'bar',
    data,
    options
  });
}

export function doughnutChart(ctx, { labels = [], data = [] } = {}) {
  if (!window.Chart || !ctx) return null;
  
  const chartData = {
    labels,
    datasets: [{
      data,
      backgroundColor: labels.map((_, i) => getColor(i, 0.8)),
      borderColor: labels.map((_, i) => getColor(i)),
      borderWidth: 2,
      hoverOffset: 4
    }]
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          color: 'var(--ink)',
          padding: 15,
          usePointStyle: true
        }
      },
      tooltip: {
        backgroundColor: 'rgba(0,0,0,0.8)',
        titleColor: '#fff',
        bodyColor: '#fff'
      }
    }
  };
  
  return new Chart(ctx, {
    type: 'doughnut',
    data: chartData,
    options
  });
}

export function areaChart(ctx, { labels = [], series = [] } = {}) {
  if (!window.Chart || !ctx) return null;
  
  const data = {
    labels,
    datasets: series.map((s, i) => ({
      label: s.name || `Serie ${i + 1}`,
      data: s.data || [],
      borderColor: getColor(i),
      backgroundColor: getColor(i, 0.2),
      tension: 0.4,
      fill: true,
      borderWidth: 2
    }))
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        mode: 'index',
        intersect: false
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          color: 'rgba(15,23,42,.06)'
        }
      }
    }
  };
  
  return new Chart(ctx, {
    type: 'line',
    data,
    options
  });
}

export function sparklineChart(ctx, { data = [], color = null } = {}) {
  if (!window.Chart || !ctx) return null;
  
  const chartColor = color || getColor(0);
  
  const chartData = {
    labels: Array(data.length).fill(''),
    datasets: [{
      data,
      borderColor: chartColor,
      backgroundColor: chartColor + '20',
      borderWidth: 2,
      fill: true,
      tension: 0.4,
      pointRadius: 0,
      pointHoverRadius: 0
    }]
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        enabled: false
      }
    },
    scales: {
      x: {
        display: false
      },
      y: {
        display: false
      }
    },
    elements: {
      point: {
        radius: 0
      }
    }
  };
  
  return new Chart(ctx, {
    type: 'line',
    data: chartData,
    options
  });
}

export function gaugeChart(ctx, { value = 0, max = 100, label = '' } = {}) {
  if (!window.Chart || !ctx) return null;
  
  const percentage = (value / max) * 100;
  const color = getGaugeColor(percentage);
  
  const data = {
    labels: [label],
    datasets: [{
      data: [value, max - value],
      backgroundColor: [color, 'rgba(15,23,42,.06)'],
      borderWidth: 0,
      cutout: '70%'
    }]
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        enabled: false
      }
    },
    elements: {
      arc: {
        borderWidth: 0
      }
    }
  };
  
  const chart = new Chart(ctx, {
    type: 'doughnut',
    data,
    options
  });
  
  // Agregar texto central
  const centerText = {
    id: 'centerText',
    afterDatasetsDraw(chart, args, options) {
      const { ctx, chartArea: { left, right, top, bottom, width, height } } = chart;
      
      ctx.save();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      // Valor principal
      ctx.font = 'bold 24px Inter';
      ctx.fillStyle = 'var(--ink)';
      ctx.fillText(`${value}%`, left + width / 2, top + height / 2 - 10);
      
      // Etiqueta
      ctx.font = '12px Inter';
      ctx.fillStyle = 'var(--muted)';
      ctx.fillText(label, left + width / 2, top + height / 2 + 15);
      
      ctx.restore();
    }
  };
  
  chart.options.plugins.centerText = centerText;
  chart.update();
  
  return chart;
}

// Funciones auxiliares
function getColor(index, alpha = 1) {
  const colors = [
    'var(--accent-from)',
    'var(--accent-to)',
    '#43a047',
    '#f59e0b',
    '#8e24aa',
    '#e53935',
    '#00acc1',
    '#ff9800',
    '#4caf50',
    '#9c27b0'
  ];
  
  const color = colors[index % colors.length];
  
  if (alpha < 1) {
    // Convertir a rgba si es necesario
    if (color.startsWith('var(--')) {
      return `rgba(35,164,245,${alpha})`; // Fallback
    }
    return color;
  }
  
  return color;
}

function getGaugeColor(percentage) {
  if (percentage >= 80) return '#22c55e'; // Verde
  if (percentage >= 60) return '#f59e0b'; // Amarillo
  if (percentage >= 40) return '#fb8c00'; // Naranja
  return '#ef4444'; // Rojo
}

// Función para actualizar gráficas con filtros
export function updateChartsWithFilters(charts, filters) {
  if (!charts || !filters) return;
  
  Object.values(charts).forEach(chart => {
    if (chart && typeof chart.update === 'function') {
      // Aquí se aplicarían los filtros a los datos de la gráfica
      // Por ahora solo se actualiza
      chart.update('none');
    }
  });
}

// Función para destruir gráficas
export function destroyChart(chart) {
  if (chart && typeof chart.destroy === 'function') {
    chart.destroy();
  }
}

// Función para crear gráfica de oportunidades
export function createOpportunitiesChart(ctx, opportunities = []) {
  if (!opportunities.length) {
    return null;
  }
  
  const labels = opportunities.map(op => op.strategy);
  const data = opportunities.map(op => op.roi);
  
  return barChart(ctx, {
    labels,
    series: [{
      name: 'ROI (%)',
      data
    }]
  });
}

// Función para crear gráfica de rendimiento por blockchain
export function createBlockchainPerformanceChart(ctx, data = {}) {
  const chains = Object.keys(data);
  const values = Object.values(data);
  
  if (!chains.length) {
    return null;
  }
  
  return barChart(ctx, {
    labels: chains,
    series: [{
      name: 'Rendimiento',
      data: values
    }]
  });
}
