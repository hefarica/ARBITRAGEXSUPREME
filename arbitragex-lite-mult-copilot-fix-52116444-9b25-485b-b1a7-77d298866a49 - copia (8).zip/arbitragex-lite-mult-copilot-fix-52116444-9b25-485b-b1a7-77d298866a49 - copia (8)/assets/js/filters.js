// Sistema de filtros para ArbitrageX
const LS_FILTERS = 'arbitragex.filters.v1';
const LS_UI_STATE = 'arbitragex.ui.state.v1';

export const FiltersState = {
  open: false,
  values: loadFilters()
};

function loadFilters() {
  try {
    return JSON.parse(localStorage.getItem(LS_FILTERS)) || {
      chains: [],
      dex: null,
      strategy: null,
      roi: [0, 100],
      risk: null,
      status: null,
      dates: [null, null],
      mode: null
    };
  } catch {
    return {
      chains: [],
      dex: null,
      strategy: null,
      roi: [0, 100],
      risk: null,
      status: null,
      dates: [null, null],
      mode: null
    };
  }
}

function saveFilters() {
  try {
    localStorage.setItem(LS_FILTERS, JSON.stringify(FiltersState.values));
  } catch (error) {
    console.warn('No se pudieron guardar los filtros:', error);
  }
}

function loadUIState() {
  try {
    return JSON.parse(localStorage.getItem(LS_UI_STATE)) || {};
  } catch {
    return {};
  }
}

function saveUIState(patch) {
  try {
    const state = { ...loadUIState(), ...patch };
    localStorage.setItem(LS_UI_STATE, JSON.stringify(state));
  } catch (error) {
    console.warn('No se pudo guardar el estado de UI:', error);
  }
}

export function initFilters() {
  // Atajos de teclado
  document.addEventListener('keydown', (event) => {
    // F para abrir/cerrar filtros
    if (event.key === 'f' || event.key === 'F') {
      toggleFilters();
      event.preventDefault();
    }
    
    // / para buscar
    if (event.key === '/') {
      const searchInput = document.getElementById('globalSearch');
      if (searchInput) {
        searchInput.focus();
        event.preventDefault();
      }
    }
    
    // G para ir a primera gráfica
    if (event.key === 'g' || event.key === 'G') {
      const firstChart = document.querySelector('canvas');
      if (firstChart) {
        firstChart.focus();
        event.preventDefault();
      }
    }
    
    // Escape para cerrar filtros
    if (event.key === 'Escape') {
      const filtersPanel = document.getElementById('filtersPanel');
      if (filtersPanel && filtersPanel.classList.contains('open')) {
        toggleFilters();
        event.preventDefault();
      }
    }
  });
  
  // Restaurar estado de UI
  const uiState = loadUIState();
  if (uiState.search) {
    const searchInput = document.getElementById('globalSearch');
    if (searchInput) {
      searchInput.value = uiState.search;
    }
  }
  
  // Persistir cambios en búsqueda
  const searchInput = document.getElementById('globalSearch');
  if (searchInput) {
    searchInput.addEventListener('input', (event) => {
      saveUIState({ search: event.target.value });
    });
  }
  
  // Persistir antes de cerrar
  window.addEventListener('beforeunload', () => {
    saveFilters();
    saveUIState({ lastVisit: Date.now() });
  });
  
  // Aplicar filtros guardados
  applySavedFilters();
}

export function toggleFilters() {
  const panel = document.getElementById('filtersPanel');
  if (!panel) return;
  
  FiltersState.open = !FiltersState.open;
  panel.classList.toggle('open', FiltersState.open);
  
  if (FiltersState.open) {
    // Enfocar primer input
    const firstInput = panel.querySelector('input, select');
    if (firstInput) {
      firstInput.focus();
    }
  }
}

export function updateFilter(key, value) {
  FiltersState.values[key] = value;
  saveFilters();
  
  // Aplicar filtros automáticamente
  applyFilters();
}

export function applyFilters() {
  const filters = FiltersState.values;
  
  // Aquí se aplicarían los filtros a las tablas/gráficas
  // Por ahora solo log
  console.log('Aplicando filtros:', filters);
  
  // Ejemplo: filtrar tabla de oportunidades
  filterOpportunitiesTable(filters);
  
  // Ejemplo: actualizar gráficas
  updateChartsWithFilters(filters);
}

function applySavedFilters() {
  const filters = FiltersState.values;
  
  // Restaurar valores en inputs
  if (filters.chains.length > 0) {
    const chainsContainer = document.getElementById('filterChains');
    if (chainsContainer) {
      chainsContainer.innerHTML = '';
      filters.chains.forEach(chain => {
        addFilterTag('filterChains', chain);
      });
    }
  }
  
  if (filters.strategy) {
    const strategySelect = document.getElementById('filterStrategy');
    if (strategySelect) {
      strategySelect.value = filters.strategy;
    }
  }
  
  if (filters.risk) {
    const riskSelect = document.getElementById('filterRisk');
    if (riskSelect) {
      riskSelect.value = filters.risk;
    }
  }
  
  if (filters.status) {
    const statusSelect = document.getElementById('filterStatus');
    if (statusSelect) {
      statusSelect.value = filters.status;
    }
  }
  
  if (filters.mode) {
    const modeSelect = document.getElementById('filterMode');
    if (modeSelect) {
      modeSelect.value = filters.mode;
    }
  }
  
  if (filters.roi && filters.roi[0] > 0) {
    const roiInput = document.getElementById('filterRoiMin');
    if (roiInput) {
      roiInput.value = filters.roi[0];
    }
  }
}

function filterOpportunitiesTable(filters) {
  const table = document.querySelector('table');
  if (!table) return;
  
  const rows = table.querySelectorAll('tbody tr');
  rows.forEach(row => {
    let show = true;
    
    // Filtrar por blockchain
    if (filters.chains.length > 0) {
      const chainCell = row.querySelector('td:nth-child(3)'); // Asumiendo columna 3
      if (chainCell && !filters.chains.includes(chainCell.textContent.trim())) {
        show = false;
      }
    }
    
    // Filtrar por estrategia
    if (filters.strategy) {
      const strategyCell = row.querySelector('td:nth-child(2)'); // Asumiendo columna 2
      if (strategyCell && strategyCell.textContent.trim() !== filters.strategy) {
        show = false;
      }
    }
    
    // Filtrar por ROI mínimo
    if (filters.roi && filters.roi[0] > 0) {
      const roiCell = row.querySelector('td:nth-child(4)'); // Asumiendo columna 4
      if (roiCell) {
        const roi = parseFloat(roiCell.textContent.replace('%', ''));
        if (isNaN(roi) || roi < filters.roi[0]) {
          show = false;
        }
      }
    }
    
    // Filtrar por riesgo
    if (filters.risk) {
      const riskCell = row.querySelector('td:nth-child(5)'); // Asumiendo columna 5
      if (riskCell && riskCell.textContent.trim() !== filters.risk) {
        show = false;
      }
    }
    
    // Filtrar por estado
    if (filters.status) {
      const statusCell = row.querySelector('td:nth-child(6)'); // Asumiendo columna 6
      if (statusCell && statusCell.textContent.trim() !== filters.status) {
        show = false;
      }
    }
    
    // Mostrar/ocultar fila
    row.style.display = show ? '' : 'none';
  });
}

function updateChartsWithFilters(filters) {
  // Aquí se actualizarían las gráficas con los filtros aplicados
  // Por ahora solo log
  console.log('Actualizando gráficas con filtros:', filters);
}

// Funciones globales para el HTML
window.updateFilter = updateFilter;
window.applyFilters = applyFilters;
window.clearFilters = function() {
  FiltersState.values = {
    chains: [],
    dex: null,
    strategy: null,
    roi: [0, 100],
    risk: null,
    status: null,
    dates: [null, null],
    mode: null
  };
  
  // Limpiar inputs
  const inputs = document.querySelectorAll('.filter-input');
  inputs.forEach(input => {
    if (input.type === 'select-one') {
      input.selectedIndex = 0;
    } else if (input.type === 'number') {
      input.value = input.min || 0;
    }
  });
  
  const multiSelects = document.querySelectorAll('.multi-select');
  multiSelects.forEach(container => {
    container.innerHTML = '';
  });
  
  saveFilters();
  applyFilters();
};

// Event listeners para inputs de filtros
document.addEventListener('DOMContentLoaded', () => {
  // ROI mínimo
  const roiInput = document.getElementById('filterRoiMin');
  if (roiInput) {
    roiInput.addEventListener('change', (event) => {
      updateFilter('roi', [parseInt(event.target.value), 100]);
    });
  }
  
  // Estrategia
  const strategySelect = document.getElementById('filterStrategy');
  if (strategySelect) {
    strategySelect.addEventListener('change', (event) => {
      updateFilter('strategy', event.target.value || null);
    });
  }
  
  // Riesgo
  const riskSelect = document.getElementById('filterRisk');
  if (riskSelect) {
    riskSelect.addEventListener('change', (event) => {
      updateFilter('risk', event.target.value || null);
    });
  }
  
  // Estado
  const statusSelect = document.getElementById('filterStatus');
  if (statusSelect) {
    statusSelect.addEventListener('change', (event) => {
      updateFilter('status', event.target.value || null);
    });
  }
  
  // Modo
  const modeSelect = document.getElementById('filterMode');
  if (modeSelect) {
    modeSelect.addEventListener('change', (event) => {
      updateFilter('mode', event.target.value || null);
    });
  }
});
