// Sistema de cobertura y checklist para ArbitrageX
const CHAINS = [
  "Ethereum", "BSC", "Polygon", "Avalanche", "Fantom", "Arbitrum", 
  "Optimism", "Solana", "Cronos", "Gnosis", "Moonbeam", "Base"
];

const STRATEGIES = [
  "Cross-Chain Multi-Hop Flash-Loan (15-25%, Muy Alta)",
  "Cross-Chain Cross-DEX (12-20%, Alta)",
  "Flash-Loan Triangular Cross-DEX (10-18%, Alta)",
  "Multi-Hop Cross-DEX (8-15%, Media)",
  "Flash-Loan Cross-DEX (7-14%, Media)",
  "Triangular Inter-DEX (6-12%, Media)",
  "Triangular Intra-DEX (5-10%, Baja)",
  "Atomic Swap Cross-DEX (4-9%, Media)",
  "Atomic Swap Intra-DEX (3-7%, Media)",
  "Basic Cross-DEX (2-6%, Baja)",
  "Basic Flash-Loan (1-5%, Baja)",
  "MEV Sandwich Protection (8-16%, Alta)",
  "Liquidity Rebalancing (5-12%, Media)",
  "Yield Farming Arbitrage (10-20%, Alta)",
  "Stablecoin Arbitrage (4-10%, Media)",
  "Impermanent Loss Arbitrage (12-25%, Alta)",
  "Gas Optimization Arbitrage (3-8%, Media)",
  "Liquidation Arbitrage (15-30%, Alta)",
  "Oracle Manipulation Arbitrage (20-40%, Muy Alta)",
  "Cross-Protocol Arbitrage (10-18%, Alta)",
  "Time-Based Arbitrage (6-12%, Media)",
  "Volatility Arbitrage (12-22%, Alta)",
  "Liquidity Mining Arbitrage (8-18%, Media)",
  "Governance Token Arbitrage (10-25%, Media)",
  "Wrapped Token Arbitrage (5-15%, Media)",
  "Bridge Arbitrage (15-35%, Alta)",
  "Layer2 Arbitrage (8-20%, Media)",
  "NFT Arbitrage (20-50%, Muy Alta)",
  "Options Arbitrage (25-60%, Muy Alta)",
  "Futures Arbitrage (30-80%, Muy Alta)",
  "Perpetual Arbitrage (35-100%, Muy Alta)",
  "Synthetic Asset Arbitrage (20-45%, Muy Alta)",
  "Derivatives Arbitrage (40-90%, Muy Alta)",
  "Insurance Arbitrage (15-40%, Alta)",
  "Prediction Market Arbitrage (25-70%, Muy Alta)",
  "Social Trading Arbitrage (10-30%, Media)",
  "AI-Powered Arbitrage (20-50%, Muy Alta)",
  "Quantitative Arbitrage (15-35%, Alta)",
  "High-Frequency Arbitrage (25-60%, Muy Alta)",
  "Multi-Strategy Arbitrage (30-80%, Muy Alta)",
  "Cross-Chain Optimization (20-45%, Muy Alta)"
];

// 🆕 Sistema de Defensa MEV - Características implementadas
const DEFENSE_FEATURES = [
  "Threat Detection (MINOR/MODERATE/MAJOR/NUCLEAR)",
  "Automated Response Escalation",
  "Reverse Sandwich Counterattack",
  "Honey Trap Deployment",
  "Strategy Poisoning System",
  "Gas War Manipulation",
  "Coalition Defense Network",
  "Economic Warfare Engine",
  "Stealth RPC Management",
  "Flashbots Integration",
  "MEV Protection Protocols",
  "Automated Defense System",
  "Threat Classification Engine",
  "Response Success Tracking",
  "Emergency Mode Controls",
  "Nuclear Mode Activation",
  "Coalition Mode Coordination",
  "Real-time Threat Monitoring",
  "Automated Counterattack Execution",
  "Stealth Engine Integration",
  "Economic Isolation Protocols"
];

const FEATURES = {
  ui: [
    "Resumen ejecutivo",
    "Alertas inteligentes",
    "Piloto Automático",
    "Semáforos",
    "Métricas avanzadas",
    "Insights IA",
    "Oportunidades tiempo real",
    "Onboarding:tutorial",
    "Onboarding:wizard",
    "Onboarding:demo",
    "Onboarding:certificación",
    "Onboarding:logros",
    "Onboarding:escenarios",
    "Onboarding:progreso",
    "Panel:set&forget",
    "Panel:intervención manual",
    "Panel:recomendaciones IA"
  ],
  tx: [
    "Modos:manual",
    "Modos:semi",
    "Modos:auto",
    "Ejecución 1 clic",
    "Auto-ejecución",
    "Tracking estado",
    "Historial ejecuciones",
    "Catálogo 41 estrategias"
  ],
  scan: [
    "Detección 15-30",
    "Filtros estrategia",
    "Filtros blockchain",
    "Filtros riesgo",
    "Ranking ROI",
    "Refresh 3-5s",
    "Validación condiciones",
    "Alertas push",
    "Alertas voz",
    "Dashboard móvil",
    "Modo emergencias",
    "Preferencias",
    "Predictivo:mapa",
    "Predictivo:timeline",
    "Predictivo:patrones",
    "Predictivo:proyecciones IA"
  ],
  ops: [
    "Riesgo:perfiles",
    "Riesgo:Kelly",
    "Riesgo:por ROI",
    "Riesgo:monitoreo en tiempo real",
    "Config:12 chains",
    "Config:DEX on/off",
    "Config:RPC",
    "Config:gas",
    "Config:slippage",
    "Auto:install.sh",
    "Auto:cron discovery",
    "Auto:validación on-chain",
    "Auto:health checks"
  ],
  conn: [
    "Endpoints REST",
    "Web3",
    "MEV protection",
    "Bridges",
    "Nodos estado"
  ],
  def: [
    "Threat Monitor",
    "Auto Defense", 
    "Counter Attacks",
    "Coalition Network",
    "Economic Warfare",
    "Stealth Engine",
    "Amenazas activas",
    "Respuestas exitosas",
    "Modo emergencia",
    "Coalición activa",
    "Filtros amenazas",
    "Modo nuclear",
    "Coalición total",
    "Threat classification",
    "Response escalation",
    "Honey traps",
    "Strategy poisoning",
    "Gas wars",
    "Reverse sandwich",
    "Economic isolation",
    "Stealth RPC"
  ]
};

// Función para escanear el DOM y encontrar features
function scanDOM() {
  const foundFeatures = new Set();
  
  // Buscar elementos con data-feature
  const elements = document.querySelectorAll('[data-feature]');
  elements.forEach(element => {
    const feature = element.getAttribute('data-feature');
    if (feature) {
      foundFeatures.add(feature);
    }
  });
  
  return foundFeatures;
}

// Función para calcular cobertura por grupo
function calculateCoverage(foundFeatures) {
  const groups = Object.entries(FEATURES).map(([group, items]) => {
    const total = items.length;
    const hit = items.filter(item => 
      [...foundFeatures].some(found => found.includes(item))
    ).length;
    const percentage = Math.round((hit / total) * 100);
    
    return {
      group,
      total,
      hit,
      percentage,
      items: items.map(item => ({
        name: item,
        found: [...foundFeatures].some(found => found.includes(item))
      }))
    };
  });
  
  return groups;
}

// Función para renderizar el checklist
export function renderChecklist(containerId = 'coverage') {
  const container = document.getElementById(containerId);
  if (!container) {
    console.warn('Contenedor de cobertura no encontrado:', containerId);
    return;
  }
  
  const foundFeatures = scanDOM();
  const groups = calculateCoverage(foundFeatures);
  const totalCoverage = Math.round(
    groups.reduce((sum, g) => sum + g.hit, 0) / 
    groups.reduce((sum, g) => sum + g.total, 0) * 100
  );
  
  container.innerHTML = `
    <div class="card panel" data-feature="coverage:checklist">
      <div style="display: flex; align-items: center; gap: 10px; justify-content: space-between; margin-bottom: 16px;">
        <div class="h1" style="font-size: 18px;">Checklist de Cobertura</div>
        <div style="display: flex; gap: 8px;">
          <span class="badge">${totalCoverage}% Total</span>
          <button id="exportCoverage" class="btn">Exportar cobertura</button>
        </div>
      </div>
      
      ${groups.map(group => `
        <div style="margin: 12px 0; padding: 12px; border-radius: 8px; background: rgba(15,23,42,.02);">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <strong style="text-transform: capitalize;">${group.group}</strong>
            <span class="badge" style="background: ${group.percentage >= 80 ? 'rgba(34,197,94,.12)' : group.percentage >= 60 ? 'rgba(245,158,11,.12)' : 'rgba(239,68,68,.12)'}; color: ${group.percentage >= 80 ? '#15803d' : group.percentage >= 60 ? '#92400e' : '#991b1b'};">
              ${group.percentage}%
            </span>
          </div>
          <div class="status">${group.hit}/${group.total} detectados</div>
          
          <div style="margin-top: 8px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 4px;">
            ${group.items.map(item => `
              <div style="display: flex; align-items: center; gap: 6px; font-size: 12px;">
                <span style="color: ${item.found ? '#22c55e' : '#ef4444'}; font-weight: bold;">
                  ${item.found ? '✓' : '✗'}
                </span>
                <span style="color: ${item.found ? 'var(--ink)' : 'var(--muted)'};">
                  ${item.name}
                </span>
              </div>
            `).join('')}
          </div>
        </div>
      `).join('')}
      
      <div style="margin-top: 16px; padding: 12px; border-radius: 8px; background: rgba(35,164,245,.05); border: 1px solid rgba(35,164,245,.1);">
        <div style="font-size: 12px; color: var(--muted); margin-bottom: 8px;">
          <strong>Resumen:</strong> ${totalCoverage}% de cobertura total
        </div>
        <div style="font-size: 11px; color: var(--muted);">
          • ${groups.filter(g => g.percentage >= 80).length} grupos completos (≥80%)<br>
          • ${groups.filter(g => g.percentage >= 60 && g.percentage < 80).length} grupos parciales (60-79%)<br>
          • ${groups.filter(g => g.percentage < 60).length} grupos incompletos (<60%)
        </div>
      </div>
    </div>
  `;
  
  // Event listener para exportar
  const exportBtn = document.getElementById('exportCoverage');
  if (exportBtn) {
    exportBtn.addEventListener('click', () => exportCoverage(groups, totalCoverage));
  }
}

// Función para exportar cobertura
function exportCoverage(groups, totalCoverage) {
  const data = {
    timestamp: new Date().toISOString(),
    totalCoverage,
    groups,
    summary: {
      totalFeatures: groups.reduce((sum, g) => sum + g.total, 0),
      foundFeatures: groups.reduce((sum, g) => sum + g.hit, 0),
      completeGroups: groups.filter(g => g.percentage >= 80).length,
      partialGroups: groups.filter(g => g.percentage >= 60 && g.percentage < 80).length,
      incompleteGroups: groups.filter(g => g.percentage < 60).length
    }
  };
  
  // Crear y descargar archivo
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `arbitragex-coverage-${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Función para exportar como CSV
function exportCoverageCSV(groups, totalCoverage) {
  let csv = 'Grupo,Feature,Encontrado\n';
  
  groups.forEach(group => {
    group.items.forEach(item => {
      csv += `"${group.group}","${item.name}","${item.found ? 'Sí' : 'No'}"\n`;
    });
  });
  
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `arbitragex-coverage-${new Date().toISOString().split('T')[0]}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Función para validar features específicas
export function validateFeature(featureName) {
  const foundFeatures = scanDOM();
  return [...foundFeatures].some(found => found.includes(featureName));
}

// Función para obtener estadísticas de cobertura
export function getCoverageStats() {
  const foundFeatures = scanDOM();
  const groups = calculateCoverage(foundFeatures);
  
  return {
    totalFeatures: groups.reduce((sum, g) => sum + g.total, 0),
    foundFeatures: groups.reduce((sum, g) => sum + g.hit, 0),
    totalCoverage: Math.round(
      groups.reduce((sum, g) => sum + g.hit, 0) / 
      groups.reduce((sum, g) => sum + g.total, 0) * 100
    ),
    groups: groups.map(g => ({
      name: g.group,
      coverage: g.percentage,
      status: g.percentage >= 80 ? 'complete' : g.percentage >= 60 ? 'partial' : 'incomplete'
    }))
  };
}

// Función para mostrar alertas de cobertura
export function showCoverageAlerts() {
  const stats = getCoverageStats();
  const alerts = [];
  
  if (stats.totalCoverage < 60) {
    alerts.push({
      type: 'error',
      message: `Cobertura crítica: ${stats.totalCoverage}%. Se requieren más features implementadas.`
    });
  } else if (stats.totalCoverage < 80) {
    alerts.push({
      type: 'warning',
      message: `Cobertura parcial: ${stats.totalCoverage}%. Considerar implementar features faltantes.`
    });
  } else {
    alerts.push({
      type: 'success',
      message: `Cobertura excelente: ${stats.totalCoverage}%. Todas las features críticas están implementadas.`
    });
  }
  
  // Mostrar alertas en la consola por ahora
  alerts.forEach(alert => {
    console.log(`[${alert.type.toUpperCase()}] ${alert.message}`);
  });
  
  return alerts;
}

// Auto-inicializar cuando se carga el DOM
document.addEventListener('DOMContentLoaded', () => {
  // Renderizar checklist después de un pequeño delay para asegurar que todos los elementos estén cargados
  setTimeout(() => {
    renderChecklist();
    showCoverageAlerts();
  }, 100);
});

// Exportar constantes para uso externo
export { CHAINS, STRATEGIES, FEATURES, DEFENSE_FEATURES };
