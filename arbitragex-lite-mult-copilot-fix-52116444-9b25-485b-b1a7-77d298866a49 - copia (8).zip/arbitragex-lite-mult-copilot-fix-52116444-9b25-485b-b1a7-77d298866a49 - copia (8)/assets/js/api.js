// API utilities para ArbitrageX
export async function getJSON(url) {
  try {
    const response = await fetch(url, {
      headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (error) {
    console.warn('getJSON failed:', url, error);
    return null;
  }
}

export async function postJSON(url, body) {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (error) {
    console.warn('postJSON failed:', url, error);
    return null;
  }
}

// SSE con fallback a polling
export function stream(url, onEvent, { interval = 4000 } = {}) {
  let timer = null;
  let eventSource = null;
  
  try {
    eventSource = new EventSource(url);
    eventSource.onmessage = (event) => {
      onEvent({ type: 'sse', data: safeJSON(event.data) });
    };
    eventSource.onerror = () => {
      eventSource.close();
      startPolling();
    };
  } catch (error) {
    startPolling();
  }
  
  function startPolling() {
    stop();
    timer = setInterval(async () => {
      const response = await getJSON(url.replace('/stream', '/status'));
      onEvent({ type: 'poll', data: response });
    }, interval);
  }
  
  function stop() {
    if (timer) clearInterval(timer);
    if (eventSource) {
      try { eventSource.close(); } catch {}
    }
  }
  
  return { stop };
}

function safeJSON(str) {
  try {
    return JSON.parse(str);
  } catch {
    return str;
  }
}

// Mock data para desarrollo (solo si no hay backend)
export function getMockData(endpoint) {
  const mocks = {
    '/api/opportunities': {
      opportunities: [
        {
          id: '1',
          strategy: 'Cross-Chain Multi-Hop Flash-Loan',
          chain: 'Ethereum',
          dex: 'Uniswap V3',
          roi: 18.5,
          risk: 'Muy Alta',
          status: 'Activa',
          timestamp: new Date().toISOString()
        }
      ]
    },
    '/api/metrics': {
      tps: 0,
      roiHour: 0,
      roiDay: 0,
      riskScore: 0,
      efficiency: 0,
      operationsPerHour: 0
    },
    '/api/status': {
      serverTime: null,
      lastUpdate: null,
      status: 'offline'
    }
  };
  
  return mocks[endpoint] || null;
}

// Health check
export async function healthCheck() {
  const endpoints = [
    '/api/status',
    '/api/opportunities',
    '/api/metrics',
    '/api/events'
  ];
  
  const results = await Promise.allSettled(
    endpoints.map(endpoint => getJSON(endpoint))
  );
  
  return endpoints.reduce((acc, endpoint, index) => {
    acc[endpoint] = results[index].status === 'fulfilled' && results[index].value !== null;
    return acc;
  }, {});
}
