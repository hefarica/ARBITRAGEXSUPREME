// Sistema de Defensa MEV - Frontend Integration
import { $, $all, postJSON, getJSON } from './api.js';

// Estado del sistema de defensa
const DefenseState = {
  threats: [],
  responses: [],
  systemStatus: 'ACTIVE',
  emergencyMode: false,
  coalitionActive: false,
  lastUpdate: null
};

// Configuración del sistema
const DEFENSE_CONFIG = {
  endpoints: {
    threats: '/api/mev-defense/threats',
    status: '/api/mev-defense/status',
    activate: '/api/mev-defense/activate',
    deactivate: '/api/mev-defense/deactivate',
    nuclear: '/api/mev-defense/nuclear',
    coalition: '/api/mev-defense/coalition'
  },
  updateInterval: 3000, // 3 segundos
  threatLevels: ['MINOR', 'MODERATE', 'MAJOR', 'NUCLEAR'],
  threatTypes: ['FRONTRUNNER', 'SANDWICH_ATTACKER', 'COPYCAT', 'MEMPOOL_SNIFFER', 'VALIDATOR_CORRUPTION']
};

// Inicialización del sistema de defensa
export function initDefenseSystem() {
  console.log('🚀 Inicializando Sistema de Defensa MEV...');
  
  // Configurar event listeners
  setupEventListeners();
  
  // Iniciar monitoreo en tiempo real
  startRealTimeMonitoring();
  
  // Cargar estado inicial
  loadDefenseStatus();
  
  // Configurar controles de emergencia
  setupEmergencyControls();
}

// Configurar event listeners
function setupEventListeners() {
  // Tabs de navegación
  const tabs = $all('.tab');
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => switchTab(index));
  });
  
  // Controles de emergencia
  const nuclearBtn = $('#nuclearMode');
  const coalitionBtn = $('#coalitionMode');
  
  if (nuclearBtn) {
    nuclearBtn.addEventListener('click', activateNuclearMode);
  }
  
  if (coalitionBtn) {
    coalitionBtn.addEventListener('click', activateCoalitionMode);
  }
}

// Cambiar entre tabs
function switchTab(activeIndex) {
  const tabs = $all('.tab');
  tabs.forEach((tab, index) => {
    tab.setAttribute('aria-selected', index === activeIndex);
  });
  
  // Aquí se cargarían los contenidos específicos de cada tab
  loadTabContent(activeIndex);
}

// Cargar contenido del tab
function loadTabContent(tabIndex) {
  const tabContents = {
    0: loadThreatMonitor,
    1: loadAutoDefense,
    2: loadCounterAttacks,
    3: loadCoalitionNetwork,
    4: loadEconomicWarfare,
    5: loadStealthEngine
  };
  
  const loader = tabContents[tabIndex];
  if (loader) {
    loader();
  }
}

// Monitoreo en tiempo real
function startRealTimeMonitoring() {
  setInterval(async () => {
    await updateDefenseMetrics();
  }, DEFENSE_CONFIG.updateInterval);
}

// Actualizar métricas de defensa
async function updateDefenseMetrics() {
  try {
    // Actualizar KPIs
    await updateDefenseKPIs();
    
    // Actualizar lista de amenazas
    await updateThreatList();
    
    // Actualizar estado del sistema
    await updateSystemStatus();
    
    DefenseState.lastUpdate = new Date();
    updateLastUpdated();
    
  } catch (error) {
    console.warn('Error actualizando métricas de defensa:', error);
  }
}

// Actualizar KPIs de defensa
async function updateDefenseKPIs() {
  const status = await getJSON(DEFENSE_CONFIG.endpoints.status);
  if (!status) return;
  
  // Amenazas activas
  const activeThreats = $('#def-amenazas-activas');
  if (activeThreats) {
    const count = status.activeThreats || 0;
    activeThreats.textContent = count;
  }
  
  // Respuestas exitosas
  const successRate = $('#def-respuestas-exitosas');
  if (successRate) {
    const rate = status.responseSuccessRate || 0;
    successRate.textContent = `${Math.round(rate * 100)}%`;
  }
  
  // Modo emergencia
  const emergencyMode = $('#def-modo-emergencia');
  if (emergencyMode) {
    const mode = status.emergencyMode ? 'ACTIVO' : 'INACTIVO';
    emergencyMode.textContent = mode;
  }
  
  // Coalición activa
  const coalitionActive = $('#def-coalición-activa');
  if (coalitionActive) {
    const coalition = status.coalitionActive ? 'ACTIVA' : 'INACTIVA';
    coalitionActive.textContent = coalition;
  }
}

// Actualizar lista de amenazas
async function updateThreatList() {
  const threats = await getJSON(DEFENSE_CONFIG.endpoints.threats);
  if (!threats) return;
  
  DefenseState.threats = threats;
  renderThreatList(threats);
}

// Renderizar lista de amenazas
function renderThreatList(threats) {
  const container = $('[data-feature="def:threat-monitor"]');
  if (!container) return;
  
  if (!threats || threats.length === 0) {
    container.innerHTML = `
      <div class="h1" style="font-size:16px">Threat Monitor</div>
      <div class="empty">Sin amenazas detectadas. Sistema operativo.</div>
    `;
    return;
  }
  
  const threatsHtml = threats.map(threat => `
    <div class="card panel" style="margin-bottom:12px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-weight:600">${threat.address}</div>
          <div class="status">${threat.threatType} • ${threat.level}</div>
        </div>
        <div class="chip ${getThreatLevelClass(threat.level)}">${threat.level}</div>
      </div>
      <div style="margin-top:8px">
        <div class="status">Confianza: ${Math.round(threat.confidence * 100)}%</div>
        <div class="status">Estado: ${threat.status}</div>
      </div>
    </div>
  `).join('');
  
  container.innerHTML = `
    <div class="h1" style="font-size:16px">Threat Monitor</div>
    <div class="status">${threats.length} amenazas activas</div>
    ${threatsHtml}
  `;
}

// Obtener clase CSS para nivel de amenaza
function getThreatLevelClass(level) {
  const classes = {
    'MINOR': 'ok',
    'MODERATE': 'mid',
    'MAJOR': 'high',
    'NUCLEAR': 'high'
  };
  return classes[level] || 'mid';
}

// Actualizar estado del sistema
async function updateSystemStatus() {
  const status = await getJSON(DEFENSE_CONFIG.endpoints.status);
  if (!status) return;
  
  DefenseState.systemStatus = status.systemStatus || 'UNKNOWN';
  DefenseState.emergencyMode = status.emergencyMode || false;
  DefenseState.coalitionActive = status.coalitionActive || false;
  
  updateSystemStatusDisplay();
}

// Actualizar display del estado del sistema
function updateSystemStatusDisplay() {
  const container = $('[data-feature="def:auto-defense"]');
  if (!container) return;
  
  const statusText = DefenseState.emergencyMode ? 'MODO EMERGENCIA ACTIVO' : 'SISTEMA OPERATIVO';
  const statusClass = DefenseState.emergencyMode ? 'high' : 'ok';
  
  container.innerHTML = `
    <div class="h1" style="font-size:16px">Sistema de Defensa Automatizada</div>
    <div class="chip ${statusClass}">${statusText}</div>
    <div class="status">Estado: ${DefenseState.systemStatus}</div>
    <div class="status">Coalición: ${DefenseState.coalitionActive ? 'ACTIVA' : 'INACTIVA'}</div>
  `;
}

// Cargar estado inicial
async function loadDefenseStatus() {
  try {
    await updateDefenseMetrics();
  } catch (error) {
    console.warn('Error cargando estado inicial:', error);
  }
}

// Configurar controles de emergencia
function setupEmergencyControls() {
  // Los botones ya están configurados en setupEventListeners
  console.log('⚠️ Controles de emergencia configurados');
}

// Activar modo nuclear
async function activateNuclearMode() {
  if (!confirm('¿ESTÁS SEGURO? El modo nuclear activará contraataques destructivos totales.')) {
    return;
  }
  
  try {
    const result = await postJSON(DEFENSE_CONFIG.endpoints.nuclear, {
      action: 'activate',
      timestamp: new Date().toISOString()
    });
    
    if (result) {
      alert('🚨 MODO NUCLEAR ACTIVADO - Sistema de contraataque destructivo total activado');
      await updateDefenseMetrics();
    }
  } catch (error) {
    console.error('Error activando modo nuclear:', error);
    alert('Error activando modo nuclear');
  }
}

// Activar modo coalición
async function activateCoalitionMode() {
  try {
    const result = await postJSON(DEFENSE_CONFIG.endpoints.coalition, {
      action: 'activate',
      timestamp: new Date().toISOString()
    });
    
    if (result) {
      alert('🛡️ MODO COALICIÓN ACTIVADO - Red de defensa colectiva activada');
      await updateDefenseMetrics();
    }
  } catch (error) {
    console.error('Error activando modo coalición:', error);
    alert('Error activando modo coalición');
  }
}

// Cargar contenido de tabs específicos
function loadThreatMonitor() {
  console.log('📊 Cargando Threat Monitor...');
  // El contenido se actualiza automáticamente
}

function loadAutoDefense() {
  console.log('🤖 Cargando Auto Defense...');
  // El contenido se actualiza automáticamente
}

function loadCounterAttacks() {
  console.log('⚔️ Cargando Counter Attacks...');
  // Implementar contenido específico
}

function loadCoalitionNetwork() {
  console.log('🛡️ Cargando Coalition Network...');
  // Implementar contenido específico
}

function loadEconomicWarfare() {
  console.log('💣 Cargando Economic Warfare...');
  // Implementar contenido específico
}

function loadStealthEngine() {
  console.log('👻 Cargando Stealth Engine...');
  // Implementar contenido específico
}

// Actualizar timestamp de última actualización
function updateLastUpdated() {
  const element = $('#lastUpdated');
  if (element && DefenseState.lastUpdate) {
    const seconds = Math.max(0, Math.round((Date.now() - DefenseState.lastUpdate) / 1000));
    element.textContent = `Actualizado hace ${seconds}s`;
  }
}

// Exportar funciones para uso externo
export {
  DefenseState,
  updateDefenseMetrics,
  activateNuclearMode,
  activateCoalitionMode
};
