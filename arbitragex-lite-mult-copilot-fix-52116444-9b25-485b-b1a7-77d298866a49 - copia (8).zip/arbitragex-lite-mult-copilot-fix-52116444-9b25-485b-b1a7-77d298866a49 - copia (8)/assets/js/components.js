// Componentes reutilizables para ArbitrageX
export function $(selector, root = document) {
  return root.querySelector(selector);
}

export function $all(selector, root = document) {
  return [...root.querySelectorAll(selector)];
}

export function appHeader(activeIndex) {
  const hubs = [
    { name: 'Configuration', label: 'Configuración', url: '/ConfigurationHub.html' },
    { name: 'Monitoring', label: 'Seguimiento', url: '/MonitoringHub.html' },
    { name: 'Execution', label: 'Ejecución', url: '/ExecutionHub.html' },
    { name: 'Transaction', label: 'Transacciones', url: '/TransactionHub.html' },
    { name: 'History', label: 'Historiales', url: '/HistoryHub.html' },
    { name: 'Connectivity', label: 'Conectividad', url: '/ConnectivityHub.html' },
    { name: 'Defense', label: 'Defensa MEV', url: '/DefenseHub.html' }
  ];
  
  return `
    <div class="header-wrap">
      <div class="header" role="banner" aria-label="Barra superior">
        <div style="display: flex; gap: 10px; align-items: center;">
          <div class="brand" aria-hidden="true"></div>
          <nav class="nav" role="navigation" aria-label="Hubs">
            ${hubs.map((hub, index) => `
              <a class="pill" ${activeIndex === index ? 'aria-current="page"' : ''} 
                 href="${hub.url}">${hub.label}</a>
            `).join('')}
          </nav>
        </div>
        <div style="display: flex; align-items: center; gap: 12px;">
          <div class="clock" aria-live="polite">
            <span id="clockTime">N/D</span>
            <span class="muted">·</span>
            <span id="clockLast">Últ. act.: N/D</span>
          </div>
          <div class="search" role="search">
            <span aria-hidden="true">🔎</span>
            <input id="globalSearch" placeholder="Buscar o preguntar…" aria-label="Buscar"/>
          </div>
          <button class="theme-toggle" id="themeToggle" aria-label="Cambiar tema">
            🌙
          </button>
        </div>
      </div>
      <div class="header-glow" aria-hidden="true"></div>
    </div>
  `;
}

export function kpi(label, value, ring = 220, feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `
    <div class="card kpi" ${featureAttr}>
      <div class="ring" style="background: conic-gradient(from 90deg, var(--accent-from) 0 ${ring}deg, rgba(15,23,42,.08) ${ring}deg 360deg)"></div>
      <div>
        <div class="status">${label}</div>
        <div style="font-weight: 700; font-size: 20px">${value}</div>
      </div>
    </div>
  `;
}

export function tabs(items, selected = 0, feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `
    <div class="tabs" role="tablist" ${featureAttr}>
      ${items.map((tab, index) => `
        <button class="tab" role="tab" aria-selected="${index === selected}" 
                data-tab="${index}">${tab}</button>
      `).join('')}
    </div>
  `;
}

export function emptyState(text = 'Sin datos disponibles', feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `<div class="empty" role="status" ${featureAttr}>${text}</div>`;
}

export function skeleton(rows = 3, feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `
    <div ${featureAttr}>
      ${Array(rows).fill().map(() => `
        <div class="skeleton" style="width: ${Math.random() * 40 + 60}%"></div>
      `).join('')}
    </div>
  `;
}

export function dataTable(headers, rows, feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `
    <div class="card" ${featureAttr}>
      <table class="table">
        <thead>
          <tr>
            ${headers.map(header => `<th>${header}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${rows.length > 0 ? rows.map(row => `
            <tr class="row">
              ${row.map(cell => `<td>${cell}</td>`).join('')}
            </tr>
          `).join('') : `
            <tr><td colspan="${headers.length}" class="empty">Sin datos</td></tr>
          `}
        </tbody>
      </table>
    </div>
  `;
}

export function chip(text, type = 'default', feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  const typeClass = type !== 'default' ? ` chip-${type}` : '';
  return `<span class="chip${typeClass}" ${featureAttr}>${text}</span>`;
}

export function alert(message, type = 'info', feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  const typeClass = type !== 'info' ? ` alert-${type}` : '';
  return `
    <div class="alert${typeClass}" role="alert" ${featureAttr}>
      ${message}
    </div>
  `;
}

export function toggle(id, label, checked = false, feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `
    <label class="toggle" ${featureAttr}>
      <input type="checkbox" id="${id}" ${checked ? 'checked' : ''}>
      <span class="toggle-slider"></span>
      <span class="toggle-label">${label}</span>
    </label>
  `;
}

export function rangeSlider(id, label, min = 0, max = 100, value = 50, feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `
    <div class="filter-group" ${featureAttr}>
      <label for="${id}">${label}</label>
      <input type="range" id="${id}" class="filter-input" 
             min="${min}" max="${max}" value="${value}">
      <span class="range-value">${value}</span>
    </div>
  `;
}

export function multiSelect(id, label, options = [], selected = [], feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `
    <div class="filter-group" ${featureAttr}>
      <label for="${id}">${label}</label>
      <div class="multi-select" id="${id}">
        ${selected.map(item => `
          <span class="tag">
            ${item}
            <span class="remove" onclick="removeTag('${id}', '${item}')">×</span>
          </span>
        `).join('')}
      </div>
      <select class="filter-input" onchange="addTag('${id}', this.value)">
        <option value="">Seleccionar...</option>
        ${options.map(option => `
          <option value="${option}">${option}</option>
        `).join('')}
      </select>
    </div>
  `;
}

export function filtersPanel(feature = null) {
  const featureAttr = feature ? `data-feature="${feature}"` : '';
  return `
    <div class="filters-panel" id="filtersPanel" ${featureAttr}>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin: 0;">Filtros</h3>
        <button class="btn ghost" onclick="toggleFilters()">Cerrar</button>
      </div>
      
      <div class="filter-group">
        <label>Blockchains</label>
        <div class="multi-select" id="filterChains">
          <!-- Tags se generan dinámicamente -->
        </div>
        <select class="filter-input" onchange="addFilterTag('filterChains', this.value)">
          <option value="">Seleccionar blockchain...</option>
          <option value="Ethereum">Ethereum</option>
          <option value="BSC">BSC</option>
          <option value="Polygon">Polygon</option>
          <option value="Avalanche">Avalanche</option>
          <option value="Fantom">Fantom</option>
          <option value="Arbitrum">Arbitrum</option>
          <option value="Optimism">Optimism</option>
          <option value="Solana">Solana</option>
          <option value="Cronos">Cronos</option>
          <option value="Gnosis">Gnosis</option>
          <option value="Moonbeam">Moonbeam</option>
          <option value="Base">Base</option>
        </select>
      </div>
      
      <div class="filter-group">
        <label>Estrategia</label>
        <select class="filter-input" id="filterStrategy">
          <option value="">Todas las estrategias</option>
          <option value="Cross-Chain Multi-Hop Flash-Loan">Cross-Chain Multi-Hop Flash-Loan</option>
          <option value="Cross-Chain Cross-DEX">Cross-Chain Cross-DEX</option>
          <option value="Flash-Loan Triangular Cross-DEX">Flash-Loan Triangular Cross-DEX</option>
          <option value="Multi-Hop Cross-DEX">Multi-Hop Cross-DEX</option>
          <option value="Flash-Loan Cross-DEX">Flash-Loan Cross-DEX</option>
          <option value="Triangular Inter-DEX">Triangular Inter-DEX</option>
          <option value="Triangular Intra-DEX">Triangular Intra-DEX</option>
          <option value="Atomic Swap Cross-DEX">Atomic Swap Cross-DEX</option>
          <option value="Atomic Swap Intra-DEX">Atomic Swap Intra-DEX</option>
          <option value="Basic Cross-DEX">Basic Cross-DEX</option>
          <option value="Basic Flash-Loan">Basic Flash-Loan</option>
          <option value="MEV Sandwich Protection">MEV Sandwich Protection</option>
          <option value="Liquidity Rebalancing">Liquidity Rebalancing</option>
          <option value="Yield Farming Arbitrage">Yield Farming Arbitrage</option>
          <option value="Stablecoin Arbitrage">Stablecoin Arbitrage</option>
          <option value="Impermanent Loss Arbitrage">Impermanent Loss Arbitrage</option>
          <option value="Gas Optimization Arbitrage">Gas Optimization Arbitrage</option>
          <option value="Liquidation Arbitrage">Liquidation Arbitrage</option>
          <option value="Oracle Manipulation Arbitrage">Oracle Manipulation Arbitrage</option>
          <option value="Cross-Protocol Arbitrage">Cross-Protocol Arbitrage</option>
          <option value="Time-Based Arbitrage">Time-Based Arbitrage</option>
          <option value="Volatility Arbitrage">Volatility Arbitrage</option>
          <option value="Liquidity Mining Arbitrage">Liquidity Mining Arbitrage</option>
          <option value="Governance Token Arbitrage">Governance Token Arbitrage</option>
          <option value="Wrapped Token Arbitrage">Wrapped Token Arbitrage</option>
          <option value="Bridge Arbitrage">Bridge Arbitrage</option>
          <option value="Layer2 Arbitrage">Layer2 Arbitrage</option>
          <option value="NFT Arbitrage">NFT Arbitrage</option>
          <option value="Options Arbitrage">Options Arbitrage</option>
          <option value="Futures Arbitrage">Futures Arbitrage</option>
          <option value="Perpetual Arbitrage">Perpetual Arbitrage</option>
          <option value="Synthetic Asset Arbitrage">Synthetic Asset Arbitrage</option>
          <option value="Derivatives Arbitrage">Derivatives Arbitrage</option>
          <option value="Insurance Arbitrage">Insurance Arbitrage</option>
          <option value="Prediction Market Arbitrage">Prediction Market Arbitrage</option>
          <option value="Social Trading Arbitrage">Social Trading Arbitrage</option>
          <option value="AI-Powered Arbitrage">AI-Powered Arbitrage</option>
          <option value="Quantitative Arbitrage">Quantitative Arbitrage</option>
          <option value="High-Frequency Arbitrage">High-Frequency Arbitrage</option>
          <option value="Multi-Strategy Arbitrage">Multi-Strategy Arbitrage</option>
          <option value="Cross-Chain Optimization">Cross-Chain Optimization</option>
        </select>
      </div>
      
      <div class="filter-group">
        <label>ROI mínimo (%)</label>
        <input type="number" class="filter-input" id="filterRoiMin" min="0" max="100" value="0">
      </div>
      
      <div class="filter-group">
        <label>Riesgo</label>
        <select class="filter-input" id="filterRisk">
          <option value="">Todos los riesgos</option>
          <option value="Baja">Baja</option>
          <option value="Media">Media</option>
          <option value="Alta">Alta</option>
          <option value="Muy Alta">Muy Alta</option>
        </select>
      </div>
      
      <div class="filter-group">
        <label>Estado</label>
        <select class="filter-input" id="filterStatus">
          <option value="">Todos los estados</option>
          <option value="Activa">Activa</option>
          <option value="En cola">En cola</option>
          <option value="Completada">Completada</option>
          <option value="Fallida">Fallida</option>
        </select>
      </div>
      
      <div class="filter-group">
        <label>Modo</label>
        <select class="filter-input" id="filterMode">
          <option value="">Todos los modos</option>
          <option value="Manual">Manual</option>
          <option value="Semi">Semi</option>
          <option value="Auto">Auto</option>
        </select>
      </div>
      
      <button class="btn" onclick="applyFilters()">Aplicar filtros</button>
      <button class="btn ghost" onclick="clearFilters()">Limpiar</button>
    </div>
  `;
}

// Funciones auxiliares para filtros
window.addFilterTag = function(containerId, value) {
  if (!value) return;
  const container = document.getElementById(containerId);
  if (!container) return;
  
  const existingTags = container.querySelectorAll('.tag');
  for (let tag of existingTags) {
    if (tag.textContent.includes(value)) return; // Ya existe
  }
  
  const tag = document.createElement('span');
  tag.className = 'tag';
  tag.innerHTML = `
    ${value}
    <span class="remove" onclick="this.parentElement.remove()">×</span>
  `;
  container.appendChild(tag);
};

window.removeTag = function(containerId, value) {
  const container = document.getElementById(containerId);
  if (!container) return;
  
  const tags = container.querySelectorAll('.tag');
  for (let tag of tags) {
    if (tag.textContent.includes(value)) {
      tag.remove();
      break;
    }
  }
};

window.toggleFilters = function() {
  const panel = document.getElementById('filtersPanel');
  if (panel) {
    panel.classList.toggle('open');
  }
};

window.applyFilters = function() {
  // Implementar lógica de filtros
  console.log('Aplicando filtros...');
  toggleFilters();
};

window.clearFilters = function() {
  // Limpiar todos los filtros
  const inputs = document.querySelectorAll('.filter-input');
  inputs.forEach(input => {
    if (input.type === 'select-one') {
      input.selectedIndex = 0;
    } else if (input.type === 'number') {
      input.value = input.min || 0;
    }
  });
  
  const multiSelects = document.querySelectorAll('.multi-select');
  multiSelects.forEach(container => {
    container.innerHTML = '';
  });
};
