import React, { useState, useEffect, useCallback } from 'react';
import { RealTimeDashboard } from './components/RealTimeDashboard';
import { CommandPalette } from './components/CommandPalette';
import { NavigationSidebar } from './components/layout/NavigationSidebar';
import { StatusBar } from './components/layout/StatusBar';
import { NotificationCenter } from './components/notifications/NotificationCenter';
import { ConfigurationHub } from './components/dashboard/ConfigurationHub';
import { MonitoringHub } from './components/dashboard/MonitoringHub';
import { ExecutionHub } from './components/dashboard/ExecutionHub';
import { TransactionHub } from './components/dashboard/TransactionHub';
import { HistoryHub } from './components/dashboard/HistoryHub';
import { ConnectivityHub } from './components/dashboard/ConnectivityHub';
import { AdvancedMonitoringHub } from './components/dashboard/AdvancedMonitoringHub';
import { ApiService } from './services/ApiService';
import { RealTimeDataIngestion } from './core/RealTimeDataIngestion';
import { ArbitrageDetectionEngine } from './core/ArbitrageDetectionEngine';
import { MEVProtectedExecutor } from './core/MEVProtectedExecutor';
import { PerformanceMonitor } from './core/PerformanceMonitor';

// Tipos para el sistema
interface SystemMetrics {
  totalOpportunities: number;
  activeStrategies: number;
  totalProfit: number;
  systemEfficiency: number;
  riskScore: number;
  operationsPerHour: number;
  uptime: number;
  errorRate: number;
  successRate: number;
  reconnectionAttempts: number;
}

interface DashboardState {
  activeDashboard: 'configuration' | 'monitoring' | 'execution' | 'transactions' | 'history' | 'connectivity' | 'advanced-monitoring';
  isAutoPilotEnabled: boolean;
  systemStatus: 'running' | 'stopped' | 'error' | 'maintenance';
  lastUpdate: Date;
}

function App() {
  // Estado del sistema
  const [dashboardState, setDashboardState] = useState<DashboardState>({
    activeDashboard: 'monitoring',
    isAutoPilotEnabled: false,
    systemStatus: 'stopped',
    lastUpdate: new Date()
  });

  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics>({
    totalOpportunities: 0,
    activeStrategies: 0,
    totalProfit: 0,
    systemEfficiency: 0,
    riskScore: 0,
    operationsPerHour: 0,
    uptime: 0,
    errorRate: 0,
    successRate: 0,
    reconnectionAttempts: 0
  });

  // Servicios del sistema
  const [apiService] = useState(() => new ApiService());
  const [dataIngestion] = useState(() => new RealTimeDataIngestion([
    { chainId: 1, wsUrl: process.env.REACT_APP_ETH_WS_URL || '' },
    { chainId: 56, wsUrl: process.env.REACT_APP_BSC_WS_URL || '' },
    { chainId: 137, wsUrl: process.env.REACT_APP_POLYGON_WS_URL || '' },
    { chainId: 43114, wsUrl: process.env.REACT_APP_AVALANCHE_WS_URL || '' },
    { chainId: 250, wsUrl: process.env.REACT_APP_FANTOM_WS_URL || '' },
    { chainId: 42161, wsUrl: process.env.REACT_APP_ARBITRUM_WS_URL || '' },
    { chainId: 10, wsUrl: process.env.REACT_APP_OPTIMISM_WS_URL || '' },
    { chainId: 139, wsUrl: process.env.REACT_APP_POLYGON_ZKEVM_WS_URL || '' },
    { chainId: 25, wsUrl: process.env.REACT_APP_CRONOS_WS_URL || '' },
    { chainId: 100, wsUrl: process.env.REACT_APP_GNOSIS_WS_URL || '' },
    { chainId: 1284, wsUrl: process.env.REACT_APP_MOONBEAM_WS_URL || '' },
    { chainId: 8453, wsUrl: process.env.REACT_APP_BASE_WS_URL || '' }
  ]));
  const [arbitrageEngine] = useState(() => new ArbitrageDetectionEngine(dataIngestion));
  const [mevExecutor] = useState(() => new MEVProtectedExecutor(
    {} as any, // Wallet placeholder - se configurará en producción
    {} as any, // Provider placeholder - se configurará en producción
    '', // Contract address placeholder
    [] // ABI placeholder
  ));
  const [performanceMonitor] = useState(() => new PerformanceMonitor());

  // Actualización en tiempo real de métricas del sistema
  const updateSystemMetrics = useCallback(async () => {
    try {
      const metrics = await apiService.getSystemMetrics();
      setSystemMetrics(metrics);
      setDashboardState(prev => ({
        ...prev,
        lastUpdate: new Date()
      }));
    } catch (error) {
      console.error('Error actualizando métricas del sistema:', error);
    }
  }, [apiService]);

  // Control del sistema
  const startSystem = useCallback(async () => {
    try {
      await apiService.startSystem();
      setDashboardState(prev => ({
        ...prev,
        systemStatus: 'running'
      }));
    } catch (error) {
      console.error('Error iniciando el sistema:', error);
    }
  }, [apiService]);

  const stopSystem = useCallback(async () => {
    try {
      await apiService.stopSystem();
      setDashboardState(prev => ({
        ...prev,
        systemStatus: 'stopped'
      }));
    } catch (error) {
      console.error('Error deteniendo el sistema:', error);
    }
  }, [apiService]);

  const toggleAutoPilot = useCallback(async () => {
    try {
      const newState = !dashboardState.isAutoPilotEnabled;
      await apiService.updateSystemConfig({ autoPilot: newState });
      setDashboardState(prev => ({
        ...prev,
        isAutoPilotEnabled: newState
      }));
    } catch (error) {
      console.error('Error cambiando modo piloto automático:', error);
    }
  }, [dashboardState.isAutoPilotEnabled, apiService]);

  // Cambio de dashboard
  const changeDashboard = useCallback((dashboard: DashboardState['activeDashboard']) => {
    setDashboardState(prev => ({
      ...prev,
      activeDashboard: dashboard
    }));
  }, []);

  // Efectos para actualización automática
  useEffect(() => {
    updateSystemMetrics();
    const interval = setInterval(updateSystemMetrics, 3000); // Actualización cada 3 segundos
    return () => clearInterval(interval);
  }, [updateSystemMetrics]);

  // Renderizado del dashboard activo
  const renderActiveDashboard = () => {
    switch (dashboardState.activeDashboard) {
      case 'configuration':
        return <ConfigurationHub />;
      case 'monitoring':
        return <MonitoringHub 
          systemMetrics={systemMetrics}
          dataIngestion={dataIngestion}
          arbitrageEngine={arbitrageEngine}
        />;
      case 'execution':
        return <ExecutionHub 
          mevExecutor={mevExecutor}
          systemStatus={dashboardState.systemStatus}
          onStartSystem={startSystem}
          onStopSystem={stopSystem}
        />;
      case 'transactions':
        return <TransactionHub />;
      case 'history':
        return <HistoryHub />;
      case 'connectivity':
        return <ConnectivityHub />;
      case 'advanced-monitoring':
        return <AdvancedMonitoringHub />;
      default:
        return <MonitoringHub 
          systemMetrics={systemMetrics}
          dataIngestion={dataIngestion}
          arbitrageEngine={arbitrageEngine}
        />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      {/* Header Principal */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-blue-500/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo y Título */}
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                <span className="text-xl font-bold">AX</span>
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                  ArbitrageX Pro 2025
                </h1>
                <p className="text-xs text-blue-300">Sistema de Arbitraje DeFi Avanzado</p>
              </div>
            </div>

            {/* Controles Principales del Sistema */}
            <div className="flex items-center space-x-4">
              {/* Estado del Sistema */}
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${
                  dashboardState.systemStatus === 'running' ? 'bg-green-500' :
                  dashboardState.systemStatus === 'stopped' ? 'bg-red-500' :
                  dashboardState.systemStatus === 'error' ? 'bg-yellow-500' :
                  'bg-blue-500'
                }`} />
                <span className="text-sm font-medium capitalize">
                  {dashboardState.systemStatus}
                </span>
              </div>

              {/* Botón Piloto Automático */}
              <button
                onClick={toggleAutoPilot}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  dashboardState.isAutoPilotEnabled
                    ? 'bg-green-600 hover:bg-green-700 text-white'
                    : 'bg-gray-600 hover:bg-gray-700 text-gray-200'
                }`}
              >
                {dashboardState.isAutoPilotEnabled ? '🟢 Piloto ON' : '🔴 Piloto OFF'}
              </button>

              {/* Botones de Control del Sistema */}
              <div className="flex space-x-2">
                <button
                  onClick={startSystem}
                  disabled={dashboardState.systemStatus === 'running'}
                  className="px-3 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg text-sm font-medium transition-colors"
                >
                  ▶️ Iniciar
                </button>
                <button
                  onClick={stopSystem}
                  disabled={dashboardState.systemStatus === 'stopped'}
                  className="px-3 py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg text-sm font-medium transition-colors"
                >
                  ⏹️ Detener
                </button>
              </div>
            </div>

            {/* Comando de Búsqueda */}
            <div className="flex-1 max-w-md mx-8">
              <CommandPalette />
            </div>

            {/* Notificaciones */}
            <NotificationCenter />
          </div>
        </div>
      </header>

      {/* Contenido Principal */}
      <div className="flex h-screen">
        {/* Sidebar de Navegación */}
        <NavigationSidebar 
          activeDashboard={dashboardState.activeDashboard}
          onDashboardChange={changeDashboard}
          systemMetrics={systemMetrics}
        />

        {/* Área de Contenido Principal */}
        <main className="flex-1 overflow-hidden">
          <div className="h-full p-6">
            {renderActiveDashboard()}
          </div>
        </main>
      </div>

      {/* Barra de Estado */}
      <StatusBar 
        systemStatus={dashboardState.systemStatus}
        lastUpdate={dashboardState.lastUpdate}
        systemMetrics={systemMetrics}
      />
    </div>
  );
}

export default App;