/**
 * 🔗 Hook personalizado para el servicio de integración de blockchains
 * Proporciona acceso fácil al servicio de integración desde componentes React
 */

import { useState, useEffect, useCallback, useMemo } from 'react'
import { blockchainIntegrationService, BlockchainInfo, IntegrationStatus } from '../services/BlockchainIntegrationService'

export interface UseBlockchainIntegrationReturn {
  // Estado del servicio
  isInitialized: boolean
  isInitializing: boolean
  
  // Estado de integración
  integrationStatus: IntegrationStatus
  
  // Información de blockchains
  allBlockchains: BlockchainInfo[]
  enabledBlockchains: BlockchainInfo[]
  disabledBlockchains: BlockchainInfo[]
  
  // Estadísticas
  integrationStats: {
    totalBlockchains: number
    enabledBlockchains: number
    connectedBlockchains: number
    disconnectedBlockchains: number
    errorBlockchains: number
    averageLatency: number
  }
  
  // Salud de la integración
  integrationHealth: {
    isHealthy: boolean
    issues: string[]
    recommendations: string[]
  }
  
  // Acciones
  initialize: () => Promise<void>
  setBlockchainEnabled: (name: string, enabled: boolean) => void
  updateBlockchainRPC: (name: string, newRpcUrl: string) => void
  forceReconnectAll: () => Promise<void>
  
  // Utilidades
  getBlockchainInfo: (name: string) => BlockchainInfo | undefined
  getBlockchainByName: (name: string) => BlockchainInfo | undefined
  getBlockchainsByChainId: (chainId: number) => BlockchainInfo[]
}

export function useBlockchainIntegration(): UseBlockchainIntegrationReturn {
  // Estados del servicio
  const [isInitialized, setIsInitialized] = useState(false)
  const [isInitializing, setIsInitializing] = useState(false)
  
  // Estado de integración
  const [integrationStatus, setIntegrationStatus] = useState<IntegrationStatus>({
    isIntegrated: false,
    totalBlockchains: 0,
    integratedBlockchains: 0,
    lastSync: 0,
    errors: []
  })
  
  // Información de blockchains
  const [allBlockchains, setAllBlockchains] = useState<BlockchainInfo[]>([])
  
  // Estadísticas
  const [integrationStats, setIntegrationStats] = useState({
    totalBlockchains: 0,
    enabledBlockchains: 0,
    connectedBlockchains: 0,
    disconnectedBlockchains: 0,
    errorBlockchains: 0,
    averageLatency: 0
  })
  
  // Salud de la integración
  const [integrationHealth, setIntegrationHealth] = useState({
    isHealthy: true,
    issues: [],
    recommendations: []
  })

  // Función para refrescar datos
  const refreshData = useCallback(() => {
    try {
      // Refrescar estado de integración
      const newStatus = blockchainIntegrationService.getIntegrationStatus()
      setIntegrationStatus(newStatus)
      
      // Refrescar información de blockchains
      const newBlockchains = blockchainIntegrationService.getAllBlockchains()
      setAllBlockchains(newBlockchains)
      
      // Refrescar estadísticas
      const newStats = blockchainIntegrationService.getIntegrationStats()
      setIntegrationStats(newStats)
      
      // Refrescar salud de la integración
      const newHealth = blockchainIntegrationService.checkIntegrationHealth()
      setIntegrationHealth(newHealth)
      
    } catch (error) {
      console.error('Error refrescando datos de integración:', error)
    }
  }, [])

  // Función para inicializar el servicio
  const initialize = useCallback(async () => {
    if (isInitialized || isInitializing) return
    
    setIsInitializing(true)
    try {
      await blockchainIntegrationService.initialize()
      setIsInitialized(true)
      refreshData()
    } catch (error) {
      console.error('Error inicializando servicio de integración:', error)
    } finally {
      setIsInitializing(false)
    }
  }, [isInitialized, isInitializing, refreshData])

  // Función para habilitar/deshabilitar blockchain
  const setBlockchainEnabled = useCallback((name: string, enabled: boolean) => {
    try {
      blockchainIntegrationService.setBlockchainEnabled(name, enabled)
      refreshData()
    } catch (error) {
      console.error(`Error ${enabled ? 'habilitando' : 'deshabilitando'} blockchain ${name}:`, error)
    }
  }, [refreshData])

  // Función para actualizar RPC de blockchain
  const updateBlockchainRPC = useCallback((name: string, newRpcUrl: string) => {
    try {
      blockchainIntegrationService.updateBlockchainRPC(name, newRpcUrl)
      refreshData()
    } catch (error) {
      console.error(`Error actualizando RPC de blockchain ${name}:`, error)
    }
  }, [refreshData])

  // Función para forzar reconexión de todas las blockchains
  const forceReconnectAll = useCallback(async () => {
    try {
      await blockchainIntegrationService.forceReconnectAll()
      refreshData()
    } catch (error) {
      console.error('Error en reconexión forzada:', error)
    }
  }, [refreshData])

  // Utilidades para filtrar blockchains
  const getBlockchainInfo = useCallback((name: string) => {
    return blockchainIntegrationService.getBlockchainInfo(name)
  }, [])

  const getBlockchainByName = useCallback((name: string) => {
    return allBlockchains.find(blockchain => blockchain.name === name)
  }, [allBlockchains])

  const getBlockchainsByChainId = useCallback((chainId: number) => {
    return allBlockchains.filter(blockchain => blockchain.chainId === chainId)
  }, [allBlockchains])

  // Computar blockchains habilitadas y deshabilitadas
  const enabledBlockchains = useMemo(() => {
    return allBlockchains.filter(blockchain => blockchain.enabled)
  }, [allBlockchains])

  const disabledBlockchains = useMemo(() => {
    return allBlockchains.filter(blockchain => !blockchain.enabled)
  }, [allBlockchains])

  // Efecto para inicializar automáticamente
  useEffect(() => {
    if (!isInitialized && !isInitializing) {
      initialize()
    }
  }, [isInitialized, isInitializing, initialize])

  // Efecto para refrescar datos periódicamente
  useEffect(() => {
    if (isInitialized) {
      const interval = setInterval(refreshData, 10000) // Cada 10 segundos
      return () => clearInterval(interval)
    }
  }, [isInitialized, refreshData])

  // Memoizar el valor de retorno
  const returnValue = useMemo<UseBlockchainIntegrationReturn>(() => ({
    // Estado del servicio
    isInitialized,
    isInitializing,
    
    // Estado de integración
    integrationStatus,
    
    // Información de blockchains
    allBlockchains,
    enabledBlockchains,
    disabledBlockchains,
    
    // Estadísticas
    integrationStats,
    
    // Salud de la integración
    integrationHealth,
    
    // Acciones
    initialize,
    setBlockchainEnabled,
    updateBlockchainRPC,
    forceReconnectAll,
    
    // Utilidades
    getBlockchainInfo,
    getBlockchainByName,
    getBlockchainsByChainId
  }), [
    isInitialized,
    isInitializing,
    integrationStatus,
    allBlockchains,
    enabledBlockchains,
    disabledBlockchains,
    integrationStats,
    integrationHealth,
    initialize,
    setBlockchainEnabled,
    updateBlockchainRPC,
    forceReconnectAll,
    getBlockchainInfo,
    getBlockchainByName,
    getBlockchainsByChainId
  ])

  return returnValue
}

// Hook simplificado para solo el estado básico
export function useBlockchainIntegrationStatus() {
  const { isInitialized, integrationStatus, integrationStats, integrationHealth } = useBlockchainIntegration()
  
  return {
    isInitialized,
    integrationStatus,
    integrationStats,
    integrationHealth
  }
}

// Hook para acciones básicas
export function useBlockchainIntegrationActions() {
  const { initialize, setBlockchainEnabled, updateBlockchainRPC, forceReconnectAll } = useBlockchainIntegration()
  
  return {
    initialize,
    setBlockchainEnabled,
    updateBlockchainRPC,
    forceReconnectAll
  }
}

// Hook para información de blockchains
export function useBlockchainInfo() {
  const { allBlockchains, enabledBlockchains, disabledBlockchains, getBlockchainInfo, getBlockchainByName } = useBlockchainIntegration()
  
  return {
    allBlockchains,
    enabledBlockchains,
    disabledBlockchains,
    getBlockchainInfo,
    getBlockchainByName
  }
}
