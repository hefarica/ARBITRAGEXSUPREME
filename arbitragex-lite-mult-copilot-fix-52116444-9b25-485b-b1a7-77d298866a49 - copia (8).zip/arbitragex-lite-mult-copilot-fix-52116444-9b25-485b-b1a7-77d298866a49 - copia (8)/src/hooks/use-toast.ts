import { useState, useCallback } from 'react'

interface Toast {
  id: string
  title: string
  description?: string
  variant?: 'default' | 'destructive'
  duration?: number
}

const toasts: Toast[] = []
const listeners: Set<(toasts: Toast[]) => void> = new Set()

let toastCount = 0

function genId() {
  toastCount = (toastCount + 1) % Number.MAX_SAFE_INTEGER
  return toastCount.toString()
}

const addToast = (toast: Omit<Toast, 'id'>) => {
  const id = genId()
  const newToast = { ...toast, id }
  toasts.push(newToast)
  
  listeners.forEach((listener) => {
    listener([...toasts])
  })

  // Auto remove after duration
  const duration = toast.duration ?? 5000
  if (duration > 0) {
    setTimeout(() => removeToast(id), duration)
  }

  return id
}

const removeToast = (id: string) => {
  const index = toasts.findIndex((toast) => toast.id === id)
  if (index > -1) {
    toasts.splice(index, 1)
    listeners.forEach((listener) => {
      listener([...toasts])
    })
  }
}

export function useToast() {
  const [currentToasts, setCurrentToasts] = useState<Toast[]>([])

  const toast = useCallback(
    (props: Omit<Toast, 'id'>) => {
      return addToast(props)
    },
    []
  )

  const dismiss = useCallback((toastId?: string) => {
    if (toastId) {
      removeToast(toastId)
    } else {
      toasts.splice(0, toasts.length)
      listeners.forEach((listener) => {
        listener([])
      })
    }
  }, [])

  // Subscribe to toast changes
  React.useEffect(() => {
    const listener = (newToasts: Toast[]) => {
      setCurrentToasts(newToasts)
    }

    listeners.add(listener)
    return () => {
      listeners.delete(listener)
    }
  }, [])

  return {
    toast,
    dismiss,
    toasts: currentToasts,
  }
}