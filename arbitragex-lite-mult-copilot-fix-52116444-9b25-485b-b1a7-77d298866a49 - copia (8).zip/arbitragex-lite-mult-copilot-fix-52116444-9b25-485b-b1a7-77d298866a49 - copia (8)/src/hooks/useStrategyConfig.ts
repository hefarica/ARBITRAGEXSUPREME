// 🎯 HOOKS PARA CONFIGURACIÓN DE ESTRATEGIAS
// Custom hooks para manejar la configuración de estrategias de arbitraje

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useKV } from '@/hooks/useKV'
import { StrategyConfig } from '../types/strategy.types'
import { strategies } from '../config/strategies'

/**
 * Hook para configuración de estrategias con persistencia local
 */
export const useStrategyConfig = () => {
  const [strategyConfigs, setStrategyConfigs] = useKV<Record<string, StrategyConfig>>('strategy-configs', {})
  
  const updateStrategyConfig = (strategyId: string, config: Partial<StrategyConfig>) => {
    setStrategyConfigs(prev => ({
      ...prev,
      [strategyId]: {
        strategyId,
        enabled: true,
        autoExecute: false,
        parameters: {
          minProfitUSD: 10,
          maxRiskScore: 5,
          maxGasPrice: 100,
          maxSlippage: 0.5,
          minConfidence: 0.7,
          maxExecutionTime: 60
        },
        limits: {
          dailyLimit: 10000,
          maxConcurrentTrades: 3,
          cooldownPeriod: 300
        },
        notifications: {
          telegram: false,
          discord: false,
          email: false,
          webhook: false
        },
        ...prev[strategyId],
        ...config
      }
    }))
  }
  
  const getStrategyConfig = (strategyId: string): StrategyConfig => {
    return strategyConfigs[strategyId] || {
      strategyId,
      enabled: false,
      autoExecute: false,
      parameters: {
        minProfitUSD: 10,
        maxRiskScore: 5,
        maxGasPrice: 100,
        maxSlippage: 0.5,
        minConfidence: 0.7,
        maxExecutionTime: 60
      },
      limits: {
        dailyLimit: 10000,
        maxConcurrentTrades: 3,
        cooldownPeriod: 300
      },
      notifications: {
        telegram: false,
        discord: false,
        email: false,
        webhook: false
      }
    }
  }
  
  const enabledStrategies = Object.values(strategyConfigs).filter(config => config.enabled)
  
  return {
    strategyConfigs,
    updateStrategyConfig,
    getStrategyConfig,
    enabledStrategies,
    enabledCount: enabledStrategies.length
  }
}

/**
 * Hook para métricas de rendimiento por estrategia
 */
export const useStrategyPerformance = (strategyId: string) => {
  return useQuery({
    queryKey: ['strategy-performance', strategyId],
    queryFn: async () => {
      // Simulación - En producción: fetch(`/api/strategies/${strategyId}/performance`)
      await new Promise(resolve => setTimeout(resolve, 300))
      
      const strategy = strategies.find(s => s.id === strategyId)
      if (!strategy) return null
      
      return {
        strategyId,
        totalProfit: Math.random() * 5000 + 1000,
        totalTrades: Math.floor(Math.random() * 100) + 20,
        successRate: Math.random() * 20 + strategy.metrics.successRate - 10,
        avgProfitPerTrade: Math.random() * 50 + 10,
        maxProfit: Math.random() * 200 + 50,
        maxDrawdown: Math.random() * 5 + 1,
        sharpeRatio: Math.random() * 2 + 1,
        lastExecution: Date.now() - Math.random() * 3600000, // Última hora
        currentStatus: Math.random() > 0.2 ? 'active' : 'paused',
        
        // Métricas específicas por tipo de estrategia
        specificMetrics: getStrategySpecificMetrics(strategy.category)
      }
    },
    staleTime: 30000,
    enabled: !!strategyId
  })
}

/**
 * Hook para obtener mejores configuraciones por estrategia
 */
export const useOptimalStrategyGear = (strategyId: string) => {
  return useQuery({
    queryKey: ['optimal-strategy-settings', strategyId],
    queryFn: async () => {
      // Simulación - En producción: ML endpoint para configuraciones óptimas
      await new Promise(resolve => setTimeout(resolve, 500))
      
      const strategy = strategies.find(s => s.id === strategyId)
      if (!strategy) return null
      
      return {
        strategyId,
        recommended: {
          minProfitUSD: strategy.requirements.minCapital * 0.001, // 0.1% del capital
          maxRiskScore: strategy.riskLevel === 'low' ? 3 : 
                       strategy.riskLevel === 'medium' ? 6 : 8,
          maxGasPrice: strategy.requirements.maxGasPrice,
          maxSlippage: strategy.complexity === 'simple' ? 0.3 : 
                      strategy.complexity === 'intermediate' ? 0.5 : 1.0,
          minConfidence: 0.8,
          maxExecutionTime: strategy.metrics.avgExecutionTime * 2
        },
        backtestResults: {
          period: '30d',
          totalReturn: Math.random() * 100 + 20,
          volatility: Math.random() * 10 + 5,
          maxDrawdown: Math.random() * 8 + 2,
          winRate: strategy.metrics.successRate + (Math.random() - 0.5) * 10,
          profitFactor: Math.random() * 2 + 1.2
        },
        confidence: Math.random() * 0.3 + 0.7 // 70-100% confidence
      }
    },
    staleTime: 300000, // 5 minutos
    enabled: !!strategyId
  })
}

/**
 * Hook para comparar rendimiento entre estrategias
 */
export const useStrategyComparison = (strategyIds: string[]) => {
  return useQuery({
    queryKey: ['strategy-comparison', strategyIds],
    queryFn: async () => {
      // Simulación - En producción: endpoint de comparación
      await new Promise(resolve => setTimeout(resolve, 400))
      
      const comparisons = strategyIds.map(strategyId => {
        const strategy = strategies.find(s => s.id === strategyId)
        if (!strategy) return null
        
        return {
          strategyId,
          name: strategy.label,
          category: strategy.category,
          roi2025: strategy.roi2025,
          metrics: {
            totalProfit: Math.random() * 10000 + 1000,
            profitMargin: Math.random() * 3 + 0.5,
            successRate: strategy.metrics.successRate + (Math.random() - 0.5) * 10,
            avgExecutionTime: strategy.metrics.avgExecutionTime + (Math.random() - 0.5) * 10,
            riskScore: Math.random() * 8 + 1,
            gasEfficiency: strategy.metrics.gasEfficiency + (Math.random() - 0.5) * 2
          }
        }
      }).filter(Boolean)
      
      return {
        strategies: comparisons,
        bestPerformer: comparisons.reduce((best, current) => 
          current && (!best || current.metrics.totalProfit > best.metrics.totalProfit) ? current : best
        ),
        summary: {
          totalCombinedProfit: comparisons.reduce((sum, s) => sum + (s?.metrics.totalProfit || 0), 0),
          avgSuccessRate: comparisons.reduce((sum, s) => sum + (s?.metrics.successRate || 0), 0) / comparisons.length,
          diversificationScore: Math.min(comparisons.length * 0.2, 1) // Max 1.0
        }
      }
    },
    staleTime: 60000,
    enabled: strategyIds.length > 0
  })
}

/**
 * Hook para auto-configurar estrategias basado en perfil de riesgo
 */
export const useAutoConfigureStrategies = () => {
  const { updateStrategyConfig } = useStrategyConfig()
  const queryClient = useQueryClient()
  
  return useMutation<void, Error, {
    riskProfile: 'conservative' | 'moderate' | 'aggressive'
    capitalAmount: number
    preferences: {
      flashLoans: boolean
      crossChain: boolean
      highFrequency: boolean
    }
  }>({
    mutationFn: async ({ riskProfile, capitalAmount, preferences }) => {
      // Simulación - En producción: ML para auto-configuración
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Filtrar estrategias según perfil de riesgo
      const suitableStrategies = strategies.filter(strategy => {
        if (strategy.requirements.minCapital > capitalAmount) return false
        
        switch (riskProfile) {
          case 'conservative':
            return strategy.riskLevel === 'low' || strategy.riskLevel === 'medium'
          case 'moderate':
            return strategy.riskLevel !== 'extreme'
          case 'aggressive':
            return true
          default:
            return false
        }
      })
      
      // Aplicar preferencias
      const filteredStrategies = suitableStrategies.filter(strategy => {
        if (!preferences.flashLoans && strategy.category === 'flash-loan') return false
        if (!preferences.crossChain && strategy.category === 'cross-chain') return false
        return true
      })
      
      // Configurar automáticamente las mejores estrategias
      const topStrategies = filteredStrategies
        .sort((a, b) => b.roi2025 - a.roi2025)
        .slice(0, 5)
      
      topStrategies.forEach(strategy => {
        const config: Partial<StrategyConfig> = {
          enabled: true,
          autoExecute: riskProfile === 'aggressive',
          parameters: {
            minProfitUSD: capitalAmount * 0.001 * (riskProfile === 'conservative' ? 2 : 1),
            maxRiskScore: riskProfile === 'conservative' ? 3 : 
                         riskProfile === 'moderate' ? 6 : 8,
            maxGasPrice: strategy.requirements.maxGasPrice,
            maxSlippage: riskProfile === 'conservative' ? 0.3 : 0.5,
            minConfidence: riskProfile === 'conservative' ? 0.9 : 0.7,
            maxExecutionTime: strategy.metrics.avgExecutionTime * 1.5
          },
          limits: {
            dailyLimit: capitalAmount * (riskProfile === 'conservative' ? 0.05 : 
                                       riskProfile === 'moderate' ? 0.1 : 0.2),
            maxConcurrentTrades: riskProfile === 'conservative' ? 2 : 
                               riskProfile === 'moderate' ? 3 : 5,
            cooldownPeriod: riskProfile === 'aggressive' ? 60 : 300
          }
        }
        
        updateStrategyConfig(strategy.id, config)
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['strategy-performance'] })
    }
  })
}

// Función auxiliar para métricas específicas por categoría
function getStrategySpecificMetrics(category: string) {
  switch (category) {
    case 'flash-loan':
      return {
        avgFlashLoanAmount: Math.random() * 100000 + 10000,
        flashLoanFees: Math.random() * 500 + 50,
        avgLoanDuration: Math.random() * 30 + 5 // segundos
      }
    case 'cross-chain':
      return {
        avgBridgeTime: Math.random() * 300 + 60, // segundos
        bridgeFees: Math.random() * 50 + 5,
        successfulBridges: Math.floor(Math.random() * 50) + 20
      }
    case 'mev-protection':
      return {
        mevSavings: Math.random() * 1000 + 100,
        protectionRate: Math.random() * 20 + 80, // %
        bundleSuccessRate: Math.random() * 15 + 85 // %
      }
    default:
      return {
        avgSlippage: Math.random() * 0.5 + 0.1,
        avgGasUsed: Math.random() * 100000 + 50000,
        networkUtilization: Math.random() * 100
      }
  }
}