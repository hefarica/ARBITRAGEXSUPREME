// src/hooks/useCircuitBreaker.ts
import { useState, useCallback, useRef } from 'react'

interface CircuitBreakerConfig {
  failureThreshold: number // Número de fallos antes de abrir el circuito
  resetTimeout: number     // Tiempo en ms antes de intentar cerrar el circuito
  monitoringPeriod: number // Período de monitoreo en ms
}

interface CircuitBreakerState {
  state: 'CLOSED' | 'OPEN' | 'HALF_OPEN'
  failureCount: number
  lastFailureTime: number | null
  nextAttempt: number | null
}

/**
 * Hook personalizado para implementar el patrón Circuit Breaker
 * Previene llamadas repetidas a APIs que fallan sistemáticamente
 */
export const useCircuitBreaker = (config: CircuitBreakerConfig) => {
  const [state, setState] = useState<CircuitBreakerState>({
    state: 'CLOSED',
    failureCount: 0,
    lastFailureTime: null,
    nextAttempt: null
  })

  const configRef = useRef(config)
  configRef.current = config

  const canExecute = useCallback((): boolean => {
    const now = Date.now()
    
    switch (state.state) {
      case 'CLOSED':
        return true
        
      case 'OPEN':
        if (state.nextAttempt && now >= state.nextAttempt) {
          setState(prev => ({ ...prev, state: 'HALF_OPEN' }))
          return true
        }
        return false
        
      case 'HALF_OPEN':
        return true
        
      default:
        return false
    }
  }, [state])

  const onSuccess = useCallback((): void => {
    setState({
      state: 'CLOSED',
      failureCount: 0,
      lastFailureTime: null,
      nextAttempt: null
    })
  }, [])

  const onFailure = useCallback((): void => {
    const now = Date.now()
    const newFailureCount = state.failureCount + 1
    
    setState(prev => ({
      ...prev,
      failureCount: newFailureCount,
      lastFailureTime: now
    }))

    // Abrir circuito si se supera el umbral
    if (newFailureCount >= configRef.current.failureThreshold) {
      setState(prev => ({
        ...prev,
        state: 'OPEN',
        nextAttempt: now + configRef.current.resetTimeout
      }))
    }
  }, [state.failureCount])

  const execute = useCallback(async <T>(
    operation: () => Promise<T>
  ): Promise<T> => {
    if (!canExecute()) {
      throw new Error(`Circuit breaker is ${state.state}. Next attempt at: ${new Date(state.nextAttempt || 0)}`)
    }

    try {
      const result = await operation()
      onSuccess()
      return result
    } catch (error) {
      onFailure()
      throw error
    }
  }, [canExecute, onSuccess, onFailure, state.state, state.nextAttempt])

  return {
    execute,
    state: state.state,
    failureCount: state.failureCount,
    canExecute: canExecute(),
    nextAttempt: state.nextAttempt,
    reset: () => setState({
      state: 'CLOSED',
      failureCount: 0,
      lastFailureTime: null,
      nextAttempt: null
    })
  }
}