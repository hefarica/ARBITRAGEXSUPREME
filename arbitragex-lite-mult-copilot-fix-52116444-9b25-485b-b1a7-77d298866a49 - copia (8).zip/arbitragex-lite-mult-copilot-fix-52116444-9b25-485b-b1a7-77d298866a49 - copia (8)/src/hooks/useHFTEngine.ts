// ⚡ HOOKS PARA HFT ENGINE - Optimizados para ultra-baja latencia
// Custom hooks para manejar el motor HFT con métricas de microsegundos

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { HFTMetrics, EngineStatus } from '../types/strategy.types'

// Configuración específica para HFT - intervalos más cortos
const HFT_REFETCH_INTERVAL = 1000 // 1 segundo para HFT
const HFT_STALE_TIME = 500 // 500ms para HFT

/**
 * Hook para métricas HFT con actualización ultra-frecuente
 */
export const useHFTMetrics = () => {
  return useQuery<HFTMetrics>({
    queryKey: ['hft-metrics'],
    queryFn: async () => {
      // Simulación optimizada para HFT - En producción: fetch('/api/hft/metrics')
      await new Promise(resolve => setTimeout(resolve, 50)) // Más rápido que arbitraje
      
      return {
        latency: {
          orderToExecution: Math.random() * 100 + 5,     // 5-105 μs
          priceUpdate: Math.random() * 20 + 1,           // 1-21 μs  
          networkRoundTrip: Math.random() * 200 + 10     // 10-210 μs
        },
        throughput: {
          ordersPerSecond: Math.random() * 10000 + 5000,   // 5k-15k ops
          updatesPerSecond: Math.random() * 50000 + 25000, // 25k-75k updates/s
          executionsPerSecond: Math.random() * 1000 + 500  // 500-1500 exec/s
        },
        performance: {
          fillRate: Math.random() * 15 + 85,               // 85-100%
          slippage: Math.random() * 0.05,                  // 0-0.05%
          rejectionRate: Math.random() * 5                 // 0-5%
        },
        hardware: {
          cpuUsage: Math.random() * 40 + 20,               // 20-60%
          memoryUsage: Math.random() * 30 + 40,            // 40-70%
          networkBandwidth: Math.random() * 500 + 100      // 100-600 Mbps
        }
      }
    },
    refetchInterval: HFT_REFETCH_INTERVAL,
    staleTime: HFT_STALE_TIME
  })
}

/**
 * Hook para estado del motor HFT
 */
export const useHFTStatus = () => {
  return useQuery<EngineStatus>({
    queryKey: ['hft-status'],
    queryFn: async () => {
      // Simulación - En producción: fetch('/api/hft/status')
      await new Promise(resolve => setTimeout(resolve, 25)) // Ultra rápido
      
      const isRunning = Math.random() > 0.2
      
      return {
        isRunning,
        mode: isRunning ? 'auto' : 'manual',
        totalOpportunities: Math.floor(Math.random() * 1000) + 500,
        executedTrades: Math.floor(Math.random() * 800) + 200,
        totalProfit: Math.random() * 15000 + 5000,
        successRate: Math.random() * 10 + 90, // HFT debe tener alta tasa de éxito
        currentLatency: Math.random() * 50 + 5,
        lastUpdate: Date.now(),
        errors: isRunning ? [] : ['CPU affinity no configurada', 'Memoria insuficiente'],
        warnings: isRunning ? ['Alta latencia de red detectada'] : []
      }
    },
    refetchInterval: HFT_REFETCH_INTERVAL,
    staleTime: HFT_STALE_TIME
  })
}

/**
 * Hook para ejecutar órdenes HFT
 */
export const useExecuteHFT = () => {
  const queryClient = useQueryClient()
  
  return useMutation<{
    success: boolean
    message: string
    execTime: number
    orderId?: string
    fillPrice?: number
  }, Error, {
    symbol: string
    side: 'buy' | 'sell'
    quantity: number
    price?: number
    orderType: 'market' | 'limit' | 'stop'
  }>({
    mutationFn: async ({ symbol, side, quantity, price, orderType }) => {
      // Simulación HFT - En producción: POST /api/hft/execute
      const execTime = Math.random() * 10 + 2 // 2-12ms
      await new Promise(resolve => setTimeout(resolve, execTime))
      
      if (Math.random() > 0.05) { // 95% tasa de éxito para HFT
        return {
          success: true,
          message: `HFT ejecutado en ${execTime.toFixed(2)}ms`,
          execTime,
          orderId: `hft_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          fillPrice: price ? price * (1 + (Math.random() - 0.5) * 0.001) : undefined // ±0.1% slippage
        }
      } else {
        throw new Error('Error HFT: Latencia de red excesiva')
      }
    },
    onSuccess: () => {
      // Invalidar queries HFT específicas
      queryClient.invalidateQueries({ queryKey: ['hft-metrics'] })
      queryClient.invalidateQueries({ queryKey: ['hft-status'] })
      queryClient.invalidateQueries({ queryKey: ['hft-orderbook'] })
    }
  })
}

/**
 * Hook para configurar parámetros HFT
 */
export const useConfigureHFT = () => {
  const queryClient = useQueryClient()
  
  return useMutation<void, Error, {
    maxLatencyMicros: number
    maxSlippageBps: number
    minFillRate: number
    cpuAffinity: number[]
    priorityLevel: 'realtime' | 'high' | 'normal'
    memoryLock: boolean
  }>({
    mutationFn: async (config) => {
      // Simulación - En producción: PUT /api/hft/config
      await new Promise(resolve => setTimeout(resolve, 500))
      
      console.log('Configuración HFT actualizada:', config)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hft-status'] })
      queryClient.invalidateQueries({ queryKey: ['hft-config'] })
    }
  })
}

/**
 * Hook para orden book en tiempo real
 */
export const useHFTOrderbook = (symbol: string) => {
  return useQuery({
    queryKey: ['hft-orderbook', symbol],
    queryFn: async () => {
      // Simulación - En producción: WebSocket o fetch rápido
      await new Promise(resolve => setTimeout(resolve, 20)) // Ultra rápido
      
      const bids = []
      const asks = []
      const basePrice = 2000 + Math.random() * 1000 // Precio base
      
      // Generar book depth realista
      for (let i = 0; i < 20; i++) {
        bids.push([
          basePrice - (i * 0.1), // Precio
          Math.random() * 10 + 1  // Cantidad
        ])
        asks.push([
          basePrice + (i * 0.1), // Precio
          Math.random() * 10 + 1  // Cantidad
        ])
      }
      
      return {
        symbol,
        bids: bids as [number, number][],
        asks: asks as [number, number][],
        timestamp: Date.now(),
        spread: asks[0][0] - bids[0][0],
        midPrice: (asks[0][0] + bids[0][0]) / 2
      }
    },
    refetchInterval: 500, // Cada 500ms para orderbook
    staleTime: 100
  })
}

/**
 * Hook para performance analytics HFT
 */
export const useHFTPerformance = (timeframe: '1m' | '5m' | '1h' | '24h' = '1h') => {
  return useQuery({
    queryKey: ['hft-performance', timeframe],
    queryFn: async () => {
      // Simulación - En producción: fetch(`/api/hft/performance?timeframe=${timeframe}`)
      await new Promise(resolve => setTimeout(resolve, 200))
      
      const now = Date.now()
      const intervals = timeframe === '1m' ? 60 : timeframe === '5m' ? 12 : timeframe === '1h' ? 60 : 24
      const intervalMs = timeframe === '1m' ? 1000 : timeframe === '5m' ? 5000 : timeframe === '1h' ? 60000 : 3600000
      
      const data = []
      for (let i = 0; i < intervals; i++) {
        data.push({
          timestamp: now - (intervals - i) * intervalMs,
          latency: Math.random() * 50 + 10, // μs
          throughput: Math.random() * 1000 + 500, // ops/s
          fillRate: Math.random() * 10 + 90, // %
          pnl: (Math.random() - 0.5) * 1000, // USD
          spread: Math.random() * 0.05 + 0.01 // %
        })
      }
      
      return {
        timeframe,
        data,
        summary: {
          avgLatency: data.reduce((sum, d) => sum + d.latency, 0) / data.length,
          avgThroughput: data.reduce((sum, d) => sum + d.throughput, 0) / data.length,
          avgFillRate: data.reduce((sum, d) => sum + d.fillRate, 0) / data.length,
          totalPnL: data.reduce((sum, d) => sum + d.pnl, 0),
          sharpeRatio: Math.random() * 2 + 1,
          maxDrawdown: Math.random() * 1000 + 100
        }
      }
    },
    staleTime: timeframe === '1m' ? 5000 : timeframe === '5m' ? 15000 : 60000
  })
}

/**
 * Hook para monitoreo del hardware HFT
 */
export const useHFTHardwareDesktop = () => {
  return useQuery({
    queryKey: ['hft-hardware'],
    queryFn: async () => {
      // Simulación - En producción: endpoint de sistema
      await new Promise(resolve => setTimeout(resolve, 100))
      
      return {
        cpu: {
          usage: Math.random() * 40 + 20, // %
          frequency: 3.2 + Math.random() * 0.8, // GHz
          temperature: Math.random() * 20 + 45, // °C
          affinity: [0, 1, 2, 3], // Cores asignados
          priority: 'realtime'
        },
        memory: {
          used: Math.random() * 30 + 40, // %
          locked: Math.random() * 2 + 1, // GB
          available: Math.random() * 10 + 20, // GB
          swapUsed: Math.random() * 5 // %
        },
        network: {
          bandwidth: Math.random() * 500 + 100, // Mbps
          latency: Math.random() * 0.5 + 0.1, // ms
          packetLoss: Math.random() * 0.01, // %
          connections: Math.floor(Math.random() * 1000) + 500
        },
        storage: {
          readLatency: Math.random() * 0.1 + 0.05, // ms
          writeLatency: Math.random() * 0.2 + 0.1, // ms
          iops: Math.floor(Math.random() * 10000) + 50000, // IOPS
          utilization: Math.random() * 20 + 10 // %
        }
      }
    },
    refetchInterval: 2000, // Cada 2 segundos para hardware
    staleTime: 1000
  })
}

/**
 * Hook para alertas HFT críticas
 */
export const useHFTAlerts = () => {
  return useQuery({
    queryKey: ['hft-alerts'],
    queryFn: async () => {
      // Simulación - En producción: WebSocket o polling de alertas
      await new Promise(resolve => setTimeout(resolve, 50))
      
      const alerts = []
      
      // Generar alertas basadas en métricas simuladas
      if (Math.random() < 0.1) {
        alerts.push({
          id: `alert_${Date.now()}`,
          type: 'latency',
          severity: 'warning',
          message: 'Latencia superior a 100μs detectada',
          timestamp: Date.now(),
          value: Math.random() * 50 + 100
        })
      }
      
      if (Math.random() < 0.05) {
        alerts.push({
          id: `alert_${Date.now() + 1}`,
          type: 'fillrate',
          severity: 'critical',
          message: 'Fill rate bajo crítico (<80%)',
          timestamp: Date.now(),
          value: Math.random() * 20 + 60
        })
      }
      
      if (Math.random() < 0.15) {
        alerts.push({
          id: `alert_${Date.now() + 2}`,
          type: 'hardware',
          severity: 'info',
          message: 'CPU usage elevado',
          timestamp: Date.now(),
          value: Math.random() * 20 + 80
        })
      }
      
      return alerts.sort((a, b) => b.timestamp - a.timestamp)
    },
    refetchInterval: 3000,
    staleTime: 1000
  })
}