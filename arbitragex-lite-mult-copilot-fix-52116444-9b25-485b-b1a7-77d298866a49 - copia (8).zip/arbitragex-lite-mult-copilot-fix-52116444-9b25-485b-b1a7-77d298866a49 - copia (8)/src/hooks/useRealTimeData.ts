// 📡 HOOKS PARA DATOS EN TIEMPO REAL - WebSocket simulation
// Custom hooks para manejar streams de datos en tiempo real para DeFi

import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useRef } from 'react'
import { PriceUpdate, MarketDepth, GasTracker } from '../types/strategy.types'

/**
 * Hook para actualizaciones de precios en tiempo real
 */
export const useRealTimePrices = (symbols: string[] = ['ETH', 'USDC', 'WBTC', 'DAI']) => {
  return useQuery<Record<string, PriceUpdate>>({
    queryKey: ['real-time-prices', symbols],
    queryFn: async () => {
      // Simulación - En producción: WebSocket de precios
      await new Promise(resolve => setTimeout(resolve, 100))
      
      const prices: Record<string, PriceUpdate> = {}
      
      symbols.forEach(symbol => {
        const basePrice = symbol === 'ETH' ? 2000 : 
                         symbol === 'WBTC' ? 30000 :
                         symbol === 'USDC' || symbol === 'DAI' ? 1 : 100
        
        const change = (Math.random() - 0.5) * 0.1 // ±5% change
        const currentPrice = basePrice * (1 + change)
        
        prices[symbol] = {
          symbol,
          price: currentPrice,
          change24h: (Math.random() - 0.5) * 20, // ±10%
          volume24h: Math.random() * 1000000 + 100000,
          timestamp: Date.now(),
          source: 'simulation'
        }
      })
      
      return prices
    },
    refetchInterval: 1000, // Actualizar cada segundo
    staleTime: 500
  })
}

/**
 * Hook para profundidad de mercado en tiempo real
 */
export const useMarketDepth = (symbol: string) => {
  return useQuery<MarketDepth>({
    queryKey: ['market-depth', symbol],
    queryFn: async () => {
      // Simulación - En producción: WebSocket orderbook
      await new Promise(resolve => setTimeout(resolve, 50))
      
      const basePrice = 2000 // ETH price
      const bids: [number, number][] = []
      const asks: [number, number][] = []
      
      // Generar 20 niveles de bid/ask
      for (let i = 0; i < 20; i++) {
        bids.push([
          basePrice - (i * 0.5), // Precio descendente
          Math.random() * 10 + 0.1 // Cantidad
        ])
        asks.push([
          basePrice + (i * 0.5), // Precio ascendente
          Math.random() * 10 + 0.1 // Cantidad
        ])
      }
      
      return {
        symbol,
        bids,
        asks,
        timestamp: Date.now()
      }
    },
    refetchInterval: 2000, // Cada 2 segundos
    staleTime: 1000
  })
}

/**
 * Hook para tracking de gas en tiempo real
 */
export const useGasTracker = () => {
  return useQuery<Record<string, GasTracker>>({
    queryKey: ['gas-tracker'],
    queryFn: async () => {
      // Simulación - En producción: Gas tracker APIs
      await new Promise(resolve => setTimeout(resolve, 150))
      
      const networks = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism']
      const gasData: Record<string, GasTracker> = {}
      
      networks.forEach(network => {
        const baseGas = network === 'ethereum' ? 50 :
                       network === 'polygon' ? 30 :
                       network === 'bsc' ? 5 :
                       network === 'arbitrum' ? 1 :
                       network === 'optimism' ? 1 : 10
        
        const multiplier = 1 + (Math.random() - 0.5) * 0.5 // ±25%
        
        gasData[network] = {
          network,
          gasPrice: {
            slow: Math.round(baseGas * 0.8 * multiplier),
            standard: Math.round(baseGas * multiplier),
            fast: Math.round(baseGas * 1.2 * multiplier),
            instant: Math.round(baseGas * 1.5 * multiplier)
          },
          timestamp: Date.now()
        }
      })
      
      return gasData
    },
    refetchInterval: 15000, // Cada 15 segundos
    staleTime: 10000
  })
}

/**
 * Hook simulador de WebSocket para eventos en tiempo real
 */
export const useWebSocketSimulator = () => {
  const queryClient = useQueryClient()
  const intervalRef = useRef<NodeJS.Timeout>()
  
  useEffect(() => {
    // Simular WebSocket events cada 3-8 segundos
    const startWebSocketSimulation = () => {
      intervalRef.current = setInterval(() => {
        const eventType = Math.random()
        
        if (eventType < 0.3) {
          // Simular nueva oportunidad
          queryClient.invalidateQueries({ queryKey: ['opportunities'] })
        } else if (eventType < 0.6) {
          // Simular actualización de precios
          queryClient.invalidateQueries({ queryKey: ['real-time-prices'] })
        } else if (eventType < 0.8) {
          // Simular actualización de métricas
          queryClient.invalidateQueries({ queryKey: ['arbitrage-metrics'] })
          queryClient.invalidateQueries({ queryKey: ['hft-metrics'] })
        } else {
          // Simular cambio de gas
          queryClient.invalidateQueries({ queryKey: ['gas-tracker'] })
        }
      }, Math.random() * 5000 + 3000) // 3-8 segundos
    }
    
    startWebSocketSimulation()
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [queryClient])
  
  return useQuery({
    queryKey: ['websocket-status'],
    queryFn: async () => {
      return {
        connected: true,
        lastUpdate: Date.now(),
        eventsReceived: Math.floor(Math.random() * 100) + 50
      }
    },
    refetchInterval: 5000
  })
}

/**
 * Hook para notificaciones en tiempo real
 */
export const useRealTimeNotifications = () => {
  return useQuery({
    queryKey: ['real-time-notifications'],
    queryFn: async () => {
      // Simulación - En producción: WebSocket de notificaciones
      await new Promise(resolve => setTimeout(resolve, 100))
      
      const notifications = []
      const types = ['opportunity', 'execution', 'alert', 'system']
      
      // Generar 0-3 notificaciones aleatorias
      const count = Math.floor(Math.random() * 4)
      
      for (let i = 0; i < count; i++) {
        const type = types[Math.floor(Math.random() * types.length)]
        
        notifications.push({
          id: `notif_${Date.now()}_${i}`,
          type,
          title: getNotificationTitle(type),
          message: getNotificationMessage(type),
          severity: Math.random() > 0.7 ? 'high' : 'normal',
          timestamp: Date.now() - Math.random() * 60000, // Último minuto
          read: false
        })
      }
      
      return notifications.sort((a, b) => b.timestamp - a.timestamp)
    },
    refetchInterval: 10000, // Cada 10 segundos
    staleTime: 5000
  })
}

// Funciones auxiliares para notificaciones
function getNotificationTitle(type: string): string {
  switch (type) {
    case 'opportunity':
      return '🚀 Nueva Oportunidad Detectada'
    case 'execution':
      return '✅ Ejecución Completada'
    case 'alert':
      return '⚠️ Alerta de Sistema'
    case 'system':
      return '🔧 Actualización de Sistema'
    default:
      return '📡 Notificación'
  }
}

function getNotificationMessage(type: string): string {
  switch (type) {
    case 'opportunity':
      const profits = ['$125', '$89', '$234', '$67', '$156']
      return `Oportunidad de arbitraje ETH/USDC con ganancia estimada: ${profits[Math.floor(Math.random() * profits.length)]}`
    case 'execution':
      return `Arbitraje ejecutado exitosamente. Ganancia real: $${Math.floor(Math.random() * 200) + 50}`
    case 'alert':
      const alerts = [
        'Latencia HFT superior a 100μs',
        'Gas price elevado en Ethereum (>100 gwei)',
        'Baja liquidez detectada en pool USDC/DAI'
      ]
      return alerts[Math.floor(Math.random() * alerts.length)]
    case 'system':
      const systems = [
        'Conexión WebSocket reconectada',
        'Cache de precios actualizado',
        'Nueva estrategia agregada al pool'
      ]
      return systems[Math.floor(Math.random() * systems.length)]
    default:
      return 'Notificación del sistema'
  }
}

/**
 * Hook para métricas de red en tiempo real
 */
export const useNetworkMetrics = () => {
  return useQuery({
    queryKey: ['network-metrics'],
    queryFn: async () => {
      // Simulación - En producción: múltiples endpoints de red
      await new Promise(resolve => setTimeout(resolve, 200))
      
      const networks = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism']
      const metrics: Record<string, any> = {}
      
      networks.forEach(network => {
        metrics[network] = {
          blockNumber: Math.floor(Math.random() * 1000000) + 18000000,
          blockTime: Math.random() * 15 + 2, // 2-17 segundos
          gasPrice: Math.random() * 100 + 10,
          tps: Math.random() * 1000 + 100, // Transacciones por segundo
          tvl: Math.random() * 10000000000 + 1000000000, // TVL en USD
          activeAddresses: Math.floor(Math.random() * 100000) + 50000,
          pendingTxs: Math.floor(Math.random() * 50000) + 10000,
          networkUtilization: Math.random() * 100,
          status: Math.random() > 0.1 ? 'healthy' : 'congested'
        }
      })
      
      return metrics
    },
    refetchInterval: 30000, // Cada 30 segundos
    staleTime: 15000
  })
}

/**
 * Hook para eventos de blockchain en tiempo real
 */
export const useBlockchainEvents = () => {
  return useQuery({
    queryKey: ['blockchain-events'],
    queryFn: async () => {
      // Simulación - En producción: WebSocket de eventos blockchain
      await new Promise(resolve => setTimeout(resolve, 100))
      
      const events = []
      const eventTypes = ['swap', 'mint', 'burn', 'transfer', 'approval']
      
      // Generar 5-15 eventos recientes
      const count = Math.floor(Math.random() * 11) + 5
      
      for (let i = 0; i < count; i++) {
        const eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)]
        
        events.push({
          id: `event_${Date.now()}_${i}`,
          type: eventType,
          txHash: `0x${Math.random().toString(16).substr(2, 8)}...`,
          blockNumber: Math.floor(Math.random() * 1000) + 18000000,
          timestamp: Date.now() - Math.random() * 300000, // Últimos 5 minutos
          network: ['ethereum', 'polygon', 'arbitrum'][Math.floor(Math.random() * 3)],
          value: Math.random() * 10000 + 100,
          gasUsed: Math.floor(Math.random() * 100000) + 21000
        })
      }
      
      return events.sort((a, b) => b.timestamp - a.timestamp)
    },
    refetchInterval: 8000, // Cada 8 segundos
    staleTime: 4000
  })
}