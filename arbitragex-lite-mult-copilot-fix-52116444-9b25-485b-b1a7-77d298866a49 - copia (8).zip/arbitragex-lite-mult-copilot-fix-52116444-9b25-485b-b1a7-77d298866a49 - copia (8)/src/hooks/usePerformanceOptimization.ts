import { useCallback, useMemo, useRef, useEffect, useState } from 'react'

/**
 * @title usePerformanceOptimization
 * @description Hooks para optimización de performance en React
 * @author ArbitrageX Performance Team 2025
 */

/**
 * Hook para debounce de funciones
 */
export function useDebounce<T extends (...args: any[]) => any>(
  callback: T,
  delay: number
): T {
  const timeoutRef = useRef<NodeJS.Timeout>()

  return useCallback(
    (...args: Parameters<T>) => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }

      timeoutRef.current = setTimeout(() => {
        callback(...args)
      }, delay)
    },
    [callback, delay]
  ) as T
}

/**
 * Hook para throttle de funciones
 */
export function useThrottle<T extends (...args: any[]) => any>(
  callback: T,
  delay: number
): T {
  const lastCall = useRef(0)
  const lastCallTimer = useRef<NodeJS.Timeout>()

  return useCallback(
    (...args: Parameters<T>) => {
      const now = Date.now()

      if (now - lastCall.current >= delay) {
        callback(...args)
        lastCall.current = now
      } else {
        if (lastCallTimer.current) {
          clearTimeout(lastCallTimer.current)
        }

        lastCallTimer.current = setTimeout(() => {
          callback(...args)
          lastCall.current = Date.now()
        }, delay - (now - lastCall.current))
      }
    },
    [callback, delay]
  ) as T
}

/**
 * Hook para memoización de objetos costosos
 */
export function useMemoizedObject<T extends object>(
  factory: () => T,
  deps: React.DependencyList
): T {
  return useMemo(factory, deps)
}

/**
 * Hook para memoización de arrays costosos
 */
export function useMemoizedArray<T>(
  factory: () => T[],
  deps: React.DependencyList
): T[] {
  return useMemo(factory, deps)
}

/**
 * Hook para lazy loading de componentes
 */
export function useLazyComponent<T extends React.ComponentType<any>>(
  importFunc: () => Promise<{ default: T }>,
  fallback?: React.ReactNode
) {
  const [Component, setComponent] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    setLoading(true)
    setError(null)

    importFunc()
      .then((module) => {
        setComponent(() => module.default)
        setLoading(false)
      })
      .catch((err) => {
        setError(err)
        setLoading(false)
      })
  }, [importFunc])

  return { Component, loading, error, fallback }
}

/**
 * Hook para virtualización de listas
 */
export function useVirtualization<T>(
  items: T[],
  itemHeight: number,
  containerHeight: number,
  overscan: number = 5
) {
  const [scrollTop, setScrollTop] = useState(0)

  const visibleRange = useMemo(() => {
    const start = Math.floor(scrollTop / itemHeight)
    const end = Math.min(
      start + Math.ceil(containerHeight / itemHeight) + overscan,
      items.length
    )

    return {
      start: Math.max(0, start - overscan),
      end
    }
  }, [scrollTop, itemHeight, containerHeight, overscan, items.length])

  const visibleItems = useMemo(() => {
    return items.slice(visibleRange.start, visibleRange.end)
  }, [items, visibleRange])

  const totalHeight = items.length * itemHeight
  const offsetY = visibleRange.start * itemHeight

  return {
    visibleItems,
    totalHeight,
    offsetY,
    setScrollTop
  }
}

/**
 * Hook para optimización de re-renders
 */
export function useOptimizedCallback<T extends (...args: any[]) => any>(
  callback: T,
  deps: React.DependencyList
): T {
  return useCallback(callback, deps)
}

/**
 * Hook para optimización de valores computados
 */
export function useOptimizedMemo<T>(
  factory: () => T,
  deps: React.DependencyList
): T {
  return useMemo(factory, deps)
}

/**
 * Hook para detección de cambios en objetos profundos
 */
export function useDeepMemo<T>(
  value: T,
  deps: React.DependencyList
): T {
  return useMemo(() => value, deps)
}

/**
 * Hook para lazy loading de imágenes
 */
export function useLazyImage(src: string, placeholder?: string) {
  const [imageSrc, setImageSrc] = useState(placeholder || src)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    const img = new Image()
    
    img.onload = () => {
      setImageSrc(src)
      setLoading(false)
    }
    
    img.onerror = () => {
      setError(true)
      setLoading(false)
    }
    
    img.src = src
  }, [src])

  return { imageSrc, loading, error }
}

/**
 * Hook para optimización de formularios
 */
export function useOptimizedForm<T extends Record<string, any>>(
  initialValues: T
) {
  const [values, setValues] = useState<T>(initialValues)
  const [errors, setErrors] = useState<Partial<Record<keyof T, string>>>({})
  const [touched, setTouched] = useState<Partial<Record<keyof T, boolean>>>({})

  const setValue = useCallback((key: keyof T, value: T[keyof T]) => {
    setValues(prev => ({ ...prev, [key]: value }))
  }, [])

  const setError = useCallback((key: keyof T, error: string) => {
    setErrors(prev => ({ ...prev, [key]: error }))
  }, [])

  const setFieldTouched = useCallback((key: keyof T, isTouched: boolean = true) => {
    setTouched(prev => ({ ...prev, [key]: isTouched }))
  }, [])

  const reset = useCallback(() => {
    setValues(initialValues)
    setErrors({})
    setTouched({})
  }, [initialValues])

  return {
    values,
    errors,
    touched,
    setValue,
    setError,
    setFieldTouched,
    reset
  }
}

/**
 * Hook para optimización de scroll
 */
export function useOptimizedScroll(
  callback: (scrollTop: number) => void,
  delay: number = 16
) {
  const ticking = useRef(false)
  const lastScrollTop = useRef(0)

  const handleScroll = useCallback(() => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop

    if (!ticking.current) {
      requestAnimationFrame(() => {
        if (Math.abs(scrollTop - lastScrollTop.current) > 5) {
          callback(scrollTop)
          lastScrollTop.current = scrollTop
        }
        ticking.current = false
      })
      ticking.current = true
    }
  }, [callback])

  useEffect(() => {
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [handleScroll])
}

/**
 * Hook para optimización de resize
 */
export function useOptimizedResize(
  callback: (width: number, height: number) => void,
  delay: number = 250
) {
  const debouncedCallback = useDebounce(callback, delay)

  useEffect(() => {
    const handleResize = () => {
      debouncedCallback(window.innerWidth, window.innerHeight)
    }

    window.addEventListener('resize', handleResize, { passive: true })
    handleResize() // Llamada inicial

    return () => window.removeEventListener('resize', handleResize)
  }, [debouncedCallback])
}

/**
 * Hook para optimización de focus
 */
export function useOptimizedFocus(
  callback: (isFocused: boolean) => void
) {
  const handleFocus = useCallback(() => callback(true), [callback])
  const handleBlur = useCallback(() => callback(false), [callback])

  return { handleFocus, handleBlur }
}

/**
 * Hook para optimización de hover
 */
export function useOptimizedHover(
  callback: (isHovered: boolean) => void,
  delay: number = 100
) {
  const timeoutRef = useRef<NodeJS.Timeout>()

  const handleMouseEnter = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }
    callback(true)
  }, [callback])

  const handleMouseLeave = useCallback(() => {
    timeoutRef.current = setTimeout(() => {
      callback(false)
    }, delay)
  }, [callback, delay])

  return { handleMouseEnter, handleMouseLeave }
}

/**
 * Hook para optimización de clicks
 */
export function useOptimizedClick(
  callback: (event: React.MouseEvent) => void,
  preventDoubleClick: boolean = true
) {
  const lastClickTime = useRef(0)

  const handleClick = useCallback((event: React.MouseEvent) => {
    const now = Date.now()
    
    if (preventDoubleClick && now - lastClickTime.current < 300) {
      return
    }
    
    lastClickTime.current = now
    callback(event)
  }, [callback, preventDoubleClick])

  return handleClick
}

/**
 * Hook para optimización de teclado
 */
export function useOptimizedKeyboard(
  callback: (event: KeyboardEvent) => void,
  keys: string[] = []
) {
  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (keys.length === 0 || keys.includes(event.key)) {
      callback(event)
    }
  }, [callback, keys])

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [handleKeyDown])
}

/**
 * Hook para optimización de animaciones
 */
export function useOptimizedAnimation(
  callback: (progress: number) => void,
  duration: number = 300
) {
  const animationRef = useRef<number>()
  const startTime = useRef<number>()

  const startAnimation = useCallback(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
    }

    startTime.current = performance.now()

    const animate = (currentTime: number) => {
      const elapsed = currentTime - (startTime.current || 0)
      const progress = Math.min(elapsed / duration, 1)

      callback(progress)

      if (progress < 1) {
        animationRef.current = requestAnimationFrame(animate)
      }
    }

    animationRef.current = requestAnimationFrame(animate)
  }, [callback, duration])

  const stopAnimation = useCallback(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
    }
  }, [])

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  return { startAnimation, stopAnimation }
} 