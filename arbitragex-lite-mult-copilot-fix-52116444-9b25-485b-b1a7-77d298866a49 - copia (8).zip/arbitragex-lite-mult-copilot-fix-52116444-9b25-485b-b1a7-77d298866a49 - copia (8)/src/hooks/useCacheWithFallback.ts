// src/hooks/useCacheWithFallback.ts
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useKV } from '@/hooks/useKV'
import { useCallback } from 'react'

interface CacheConfig<T> {
  queryKey: string[]
  fetcher: () => Promise<T>
  localStorageKey: string
  fallbackData?: T
  staleTime?: number
  maxAge?: number // Tiempo máximo para datos en cache local
  onError?: (error: Error) => void
}

/**
 * Hook avanzado de caching con múltiples niveles de fallback:
 * 1. React Query cache (memoria)
 * 2. Spark KV storage (persistente)
 * 3. Local fallback data
 * 4. Error state con retry inteligente
 */
export const useCacheWithFallback = <T>(config: CacheConfig<T>) => {
  const queryClient = useQueryClient()
  const [cachedData, setCachedData] = useKV<{
    data: T
    timestamp: number
    version: string
  } | null>(config.localStorageKey, null)

  const isLocalDataValid = useCallback((): boolean => {
    if (!cachedData) return false
    
    const maxAge = config.maxAge || 1000 * 60 * 30 // 30 minutos por defecto
    const age = Date.now() - cachedData.timestamp
    
    return age < maxAge
  }, [cachedData, config.maxAge])

  const saveToLocalCache = useCallback((data: T) => {
    setCachedData({
      data,
      timestamp: Date.now(),
      version: '1.0.0' // Versionar para migraciones futuras
    })
  }, [setCachedData])

  const query = useQuery<T>({
    queryKey: config.queryKey,
    queryFn: async () => {
      try {
        const data = await config.fetcher()
        // Guardar en cache local al obtener datos frescos
        saveToLocalCache(data)
        return data
      } catch (error) {
        config.onError?.(error as Error)
        
        // Intentar usar datos locales si están disponibles
        if (isLocalDataValid() && cachedData) {
          console.warn(`Using cached data for ${config.queryKey.join('/')} due to fetch error:`, error)
          return cachedData.data
        }
        
        // Si no hay datos locales válidos, usar fallback
        if (config.fallbackData) {
          console.warn(`Using fallback data for ${config.queryKey.join('/')} due to fetch error:`, error)
          return config.fallbackData
        }
        
        throw error
      }
    },
    staleTime: config.staleTime || 0,
    retry: (failureCount, error: any) => {
      // Estrategia de retry inteligente
      if (error?.status === 429) return false // Rate limit
      if (error?.status >= 500 && failureCount < 2) return true // Server errors
      if (failureCount < 3) return true // Network errors
      
      // Si se agotan los retries, intentar con datos locales
      if (isLocalDataValid() && cachedData) {
        queryClient.setQueryData(config.queryKey, cachedData.data)
        return false
      }
      
      return false
    },
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    
    // Datos iniciales desde cache local si están disponibles
    initialData: () => {
      if (isLocalDataValid() && cachedData) {
        return cachedData.data
      }
      return config.fallbackData
    },
    
    // Marcar datos iniciales como stale para refetch
    initialDataUpdatedAt: () => {
      if (cachedData) {
        return cachedData.timestamp
      }
      return 0
    }
  })

  const invalidateCache = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: config.queryKey })
    setCachedData(null)
  }, [queryClient, config.queryKey, setCachedData])

  const forceArrowClockwise = useCallback(async () => {
    setCachedData(null)
    return queryClient.refetchQueries({ queryKey: config.queryKey })
  }, [queryClient, config.queryKey, setCachedData])

  return {
    ...query,
    // Metadatos adicionales del cache
    isUsingCachedData: isLocalDataValid() && !query.isFetching,
    isUsingFallbackData: query.data === config.fallbackData,
    localCacheAge: cachedData ? Date.now() - cachedData.timestamp : null,
    
    // Funciones de control
    invalidateCache,
    forceArrowClockwise,
    
    // Estado del cache
    hasLocalCache: !!cachedData,
    localCacheValid: isLocalDataValid()
  }
}

// Hook especializado para métricas de trading en tiempo real
export const useTradingMetricsWithFallback = (environment: 'test' | 'prod') => {
  return useCacheWithFallback({
    queryKey: ['trading-metrics', environment],
    fetcher: async () => {
      const response = await fetch(`/api/trading/metrics?env=${environment}`)
      if (!response.ok) throw new Error('Failed to fetch trading metrics')
      return response.json()
    },
    localStorageKey: `trading-metrics-${environment}`,
    fallbackData: {
      totalProfit24h: 0,
      activeOpportunities: 0,
      successRate: 0,
      averageLatency: 0
    },
    staleTime: 1000 * 10, // 10 segundos para datos de trading
    maxAge: 1000 * 60 * 5, // 5 minutos máximo para cache local
    onError: (error) => {
      console.error('Trading metrics fetch failed:', error)
    }
  })
}

// Hook especializado para datos de portfolio con fallback
export const usePortfolioWithFallback = (environment: 'test' | 'prod') => {
  return useCacheWithFallback({
    queryKey: ['portfolio', environment],
    fetcher: async () => {
      const response = await fetch(`/api/portfolio?env=${environment}`)
      if (!response.ok) throw new Error('Failed to fetch portfolio')
      return response.json()
    },
    localStorageKey: `portfolio-${environment}`,
    fallbackData: {
      totalValue: 0,
      positions: [],
      lastUpdate: new Date().toISOString()
    },
    staleTime: 1000 * 30, // 30 segundos
    maxAge: 1000 * 60 * 10, // 10 minutos máximo
    onError: (error) => {
      console.error('Portfolio fetch failed:', error)
    }
  })
}