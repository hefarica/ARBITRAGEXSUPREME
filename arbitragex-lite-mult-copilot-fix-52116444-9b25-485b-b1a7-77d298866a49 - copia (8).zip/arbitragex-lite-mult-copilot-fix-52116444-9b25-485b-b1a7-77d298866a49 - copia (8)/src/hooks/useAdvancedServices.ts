/**
 * 🚀 Hook para Servicios Avanzados 2025 - ArbitrageX Pro
 * Hook unificado para acceder a todos los servicios avanzados implementados
 */

import { useState, useEffect, useCallback } from 'react'
import { useArbitrageSystem } from '@/core/ArbitrageSystemManager'
import { getAdvancedServicesConfig, AdvancedServicesConfig } from '@/config/advanced-services.config'

export interface AdvancedServicesState {
  mevProtection: {
    isActive: boolean
    currentLevel: string
    protectionStats: any
    isLoading: boolean
    error: string | null
  }
  flashLoans: {
    isActive: boolean
    successRate: number
    flashLoanStats: any
    isLoading: boolean
    error: string | null
  }
  crossChain: {
    isActive: boolean
    opportunities: number
    crossChainStats: any
    isLoading: boolean
    error: string | null
  }
  performance: {
    isActive: boolean
    performanceScore: number
    performanceStats: any
    isLoading: boolean
    error: string | null
  }
}

export interface AdvancedServicesActions {
  // MEV Protection Actions
  setMEVProtectionLevel: (level: 'basic' | 'advanced' | 'military') => Promise<void>
  analyzeMEVRisk: (transaction: any) => Promise<any>
  protectTransaction: (transaction: any, level?: 'basic' | 'advanced' | 'military') => Promise<any>
  
  // Flash Loan Actions
  executeFlashLoanArbitrage: (opportunity: any) => Promise<any>
  getFlashLoanProviders: () => string[]
  validateFlashLoanOpportunity: (opportunity: any) => Promise<boolean>
  
  // Cross-Chain Actions
  detectCrossChainOpportunities: (chains?: number[]) => Promise<any[]>
  executeCrossChainArbitrage: (opportunity: any) => Promise<any>
  getSupportedChains: () => number[]
  
  // Performance Actions
  getPerformanceMetrics: () => any
  optimizePerformance: (metric: string) => Promise<any>
  subscribeToMetrics: (callback: (metrics: any) => void) => () => void
}

export function useAdvancedServices(environment: 'test' | 'prod' = 'test') {
  const {
    mevProtectionService,
    flashLoanService2025,
    crossChainArbitrageService,
    performanceMonitoringService,
    isInitialized,
    isLoading,
    error
  } = useArbitrageSystem(environment)

  const [config] = useState<AdvancedServicesConfig>(() => getAdvancedServicesConfig(environment))
  const [state, setState] = useState<AdvancedServicesState>({
    mevProtection: {
      isActive: false,
      currentLevel: 'basic',
      protectionStats: null,
      isLoading: false,
      error: null
    },
    flashLoans: {
      isActive: false,
      successRate: 0,
      flashLoanStats: null,
      isLoading: false,
      error: null
    },
    crossChain: {
      isActive: false,
      opportunities: 0,
      crossChainStats: null,
      isLoading: false,
      error: null
    },
    performance: {
      isActive: false,
      performanceScore: 0,
      performanceStats: null,
      isLoading: false,
      error: null
    }
  })

  // 🆕 INICIALIZAR ESTADOS DE SERVICIOS AVANZADOS
  useEffect(() => {
    if (isInitialized && !isLoading) {
      const initializeAdvancedServices = async () => {
        try {
          // MEV Protection
          if (mevProtectionService && config.mevProtection.enabled) {
            const stats = mevProtectionService.getProtectionStats()
            setState(prev => ({
              ...prev,
              mevProtection: {
                ...prev.mevProtection,
                isActive: true,
                currentLevel: stats.currentProtectionLevel,
                protectionStats: stats
              }
            }))
          }

          // Flash Loans
          if (flashLoanService2025 && config.flashLoans.enabled) {
            const stats = flashLoanService2025.getFlashLoanStats()
            setState(prev => ({
              ...prev,
              flashLoans: {
                ...prev.flashLoans,
                isActive: true,
                successRate: stats.successRate,
                flashLoanStats: stats
              }
            }))
          }

          // Cross-Chain
          if (crossChainArbitrageService && config.crossChain.enabled) {
            const stats = crossChainArbitrageService.getCrossChainStats()
            setState(prev => ({
              ...prev,
              crossChain: {
                ...prev.crossChain,
                isActive: true,
                opportunities: stats.totalOpportunities,
                crossChainStats: stats
              }
            }))
          }

          // Performance
          if (performanceMonitoringService && config.performance.enabled) {
            const stats = performanceMonitoringService.getPerformanceStats()
            setState(prev => ({
              ...prev,
              performance: {
                ...prev.performance,
                isActive: true,
                performanceScore: stats.overallScore,
                performanceStats: stats
              }
            }))
          }
        } catch (error) {
          console.error('Error initializing advanced services:', error)
        }
      }

      initializeAdvancedServices()
    }
  }, [isInitialized, isLoading, mevProtectionService, flashLoanService2025, crossChainArbitrageService, performanceMonitoringService, config])

  // 🆕 ACTUALIZAR ESTADÍSTICAS EN TIEMPO REAL
  useEffect(() => {
    if (!isInitialized) return

    const updateStats = async () => {
      try {
        // MEV Protection Stats
        if (mevProtectionService && state.mevProtection.isActive) {
          const stats = mevProtectionService.getProtectionStats()
          setState(prev => ({
            ...prev,
            mevProtection: {
              ...prev.mevProtection,
              protectionStats: stats,
              currentLevel: stats.currentProtectionLevel
            }
          }))
        }

        // Flash Loan Stats
        if (flashLoanService2025 && state.flashLoans.isActive) {
          const stats = flashLoanService2025.getFlashLoanStats()
          setState(prev => ({
            ...prev,
            flashLoans: {
              ...prev.flashLoans,
              flashLoanStats: stats,
              successRate: stats.successRate
            }
          }))
        }

        // Cross-Chain Stats
        if (crossChainArbitrageService && state.crossChain.isActive) {
          const stats = crossChainArbitrageService.getCrossChainStats()
          setState(prev => ({
            ...prev,
            crossChain: {
              ...prev.crossChain,
              crossChainStats: stats,
              opportunities: stats.totalOpportunities
            }
          }))
        }

        // Performance Stats
        if (performanceMonitoringService && state.performance.isActive) {
          const stats = performanceMonitoringService.getPerformanceStats()
          setState(prev => ({
            ...prev,
            performance: {
              ...prev.performance,
              performanceStats: stats,
              performanceScore: stats.overallScore
            }
          }))
        }
      } catch (error) {
        console.error('Error updating advanced services stats:', error)
      }
    }

    const interval = setInterval(updateStats, config.performance.monitoringInterval)
    return () => clearInterval(interval)
  }, [isInitialized, mevProtectionService, flashLoanService2025, crossChainArbitrageService, performanceMonitoringService, config.performance.monitoringInterval, state])

  // 🆕 ACCIONES DE MEV PROTECTION
  const setMEVProtectionLevel = useCallback(async (level: 'basic' | 'advanced' | 'military') => {
    if (!mevProtectionService) throw new Error('MEV Protection Service not available')
    
    setState(prev => ({
      ...prev,
      mevProtection: { ...prev.mevProtection, isLoading: true, error: null }
    }))

    try {
      await mevProtectionService.setProtectionLevel(level)
      setState(prev => ({
        ...prev,
        mevProtection: { 
          ...prev.mevProtection, 
          isLoading: false, 
          currentLevel: level 
        }
      }))
    } catch (error) {
      setState(prev => ({
        ...prev,
        mevProtection: { 
          ...prev.mevProtection, 
          isLoading: false, 
          error: error instanceof Error ? error.message : 'Unknown error' 
        }
      }))
      throw error
    }
  }, [mevProtectionService])

  const analyzeMEVRisk = useCallback(async (transaction: any) => {
    if (!mevProtectionService) throw new Error('MEV Protection Service not available')
    return await mevProtectionService.analyzeMEVRisk(transaction)
  }, [mevProtectionService])

  const protectTransaction = useCallback(async (transaction: any, level?: 'basic' | 'advanced' | 'military') => {
    if (!mevProtectionService) throw new Error('MEV Protection Service not available')
    return await mevProtectionService.protectArbitrageTransaction(transaction, level)
  }, [mevProtectionService])

  // 🆕 ACCIONES DE FLASH LOANS
  const executeFlashLoanArbitrage = useCallback(async (opportunity: any) => {
    if (!flashLoanService2025) throw new Error('Flash Loan Service not available')
    return await flashLoanService2025.executeFlashLoanArbitrage(opportunity)
  }, [flashLoanService2025])

  const getFlashLoanProviders = useCallback(() => {
    if (!flashLoanService2025) return []
    const stats = flashLoanService2025.getFlashLoanStats()
    return Object.keys(stats.providers || {})
  }, [flashLoanService2025])

  const validateFlashLoanOpportunity = useCallback(async (opportunity: any) => {
    if (!flashLoanService2025) return false
    return await flashLoanService2025.validateArbitrageOpportunity(opportunity)
  }, [flashLoanService2025])

  // 🆕 ACCIONES DE CROSS-CHAIN
  const detectCrossChainOpportunities = useCallback(async (chains?: number[]) => {
    if (!crossChainArbitrageService) throw new Error('Cross-Chain Service not available')
    return await crossChainArbitrageService.detectCrossChainOpportunities(chains)
  }, [crossChainArbitrageService])

  const executeCrossChainArbitrage = useCallback(async (opportunity: any) => {
    if (!crossChainArbitrageService) throw new Error('Cross-Chain Service not available')
    return await crossChainArbitrageService.executeCrossChainArbitrage(opportunity)
  }, [crossChainArbitrageService])

  const getSupportedChains = useCallback(() => {
    if (!crossChainArbitrageService) return []
    const stats = crossChainArbitrageService.getCrossChainStats()
    return stats.supportedChains || []
  }, [crossChainArbitrageService])

  // 🆕 ACCIONES DE PERFORMANCE
  const getPerformanceMetrics = useCallback(() => {
    if (!performanceMonitoringService) return null
    return performanceMonitoringService.getPerformanceStats()
  }, [performanceMonitoringService])

  const optimizePerformance = useCallback(async (metric: string) => {
    if (!performanceMonitoringService) throw new Error('Performance Service not available')
    return await performanceMonitoringService.optimizePerformance(metric)
  }, [performanceMonitoringService])

  const subscribeToMetrics = useCallback((callback: (metrics: any) => void) => {
    if (!performanceMonitoringService) return () => {}
    return performanceMonitoringService.subscribeToMetrics(callback)
  }, [performanceMonitoringService])

  const actions: AdvancedServicesActions = {
    setMEVProtectionLevel,
    analyzeMEVRisk,
    protectTransaction,
    executeFlashLoanArbitrage,
    getFlashLoanProviders,
    validateFlashLoanOpportunity,
    detectCrossChainOpportunities,
    executeCrossChainArbitrage,
    getSupportedChains,
    getPerformanceMetrics,
    optimizePerformance,
    subscribeToMetrics
  }

  return {
    state,
    actions,
    config,
    isInitialized,
    isLoading,
    error
  }
}

export default useAdvancedServices
