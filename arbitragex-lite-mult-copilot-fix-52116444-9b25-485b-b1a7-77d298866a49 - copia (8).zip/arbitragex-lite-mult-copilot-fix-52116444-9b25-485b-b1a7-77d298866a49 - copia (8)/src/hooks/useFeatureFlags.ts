// src/hooks/useFeatureFlags.ts
import { useKV } from '@/hooks/useKV'
import { useQuery } from '@tanstack/react-query'

interface FeatureFlag {
  key: string
  enabled: boolean
  rolloutPercentage: number
  environment: string[]
  dependencies?: string[]
  description: string
}

interface FeatureFlagsConfig {
  // Flags críticos para el sistema de revenue
  ARBITRAGE_ENGINE_V2: FeatureFlag
  HFT_ULTRA_LOW_LATENCY: FeatureFlag
  MEV_PROTECTION_ADVANCED: FeatureFlag
  CROSS_CHAIN_ROUTING: FeatureFlag
  AI_STRATEGY_OPTIMIZER: FeatureFlag
  REAL_TIME_PORTFOLIO: FeatureFlag
  CIRCUIT_BREAKER_ENHANCED: FeatureFlag
}

/**
 * Hook para manejo de feature flags dinámicos con soporte para A/B testing
 * Permite habilitar/deshabilitar funcionalidades en tiempo real
 */
export const useFeatureFlags = (environment: 'test' | 'prod') => {
  const [localFlags, setLocalFlags] = useKV<Partial<FeatureFlagsConfig>>('feature-flags-override', {})

  // Fetch flags desde el servidor (implementar endpoint cuando esté listo)
  const { data: serverFlags, isLoading } = useQuery<FeatureFlagsConfig>({
    queryKey: ['feature-flags', environment],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/feature-flags?env=${environment}`)
        if (!response.ok) throw new Error('Failed to fetch feature flags')
        return response.json()
      } catch (error) {
        // Fallback a configuración local si el servidor no está disponible
        console.warn('Using fallback feature flags:', error)
        return getFallbackFlags(environment)
      }
    },
    staleTime: 1000 * 60 * 5, // 5 minutos
    retry: 1
  })

  const isFeatureEnabled = (flagKey: keyof FeatureFlagsConfig): boolean => {
    // Prioridad: Override local > Servidor > Fallback
    const localOverride = localFlags[flagKey]
    if (localOverride !== undefined) {
      return localOverride.enabled
    }

    const serverFlag = serverFlags?.[flagKey]
    if (serverFlag) {
      // Verificar ambiente
      if (!serverFlag.environment.includes(environment)) {
        return false
      }

      // Verificar dependencias
      if (serverFlag.dependencies) {
        const dependenciesMet = serverFlag.dependencies.every(dep => 
          isFeatureEnabled(dep as keyof FeatureFlagsConfig)
        )
        if (!dependenciesMet) return false
      }

      // A/B testing basado en rollout percentage
      if (serverFlag.rolloutPercentage < 100) {
        const userId = getUserId() // Implementar función estable de ID
        const hash = simpleHash(userId + flagKey)
        return (hash % 100) < serverFlag.rolloutPercentage
      }

      return serverFlag.enabled
    }

    // Fallback por defecto
    return getFallbackFlags(environment)[flagKey]?.enabled || false
  }

  const setLocalOverride = (flagKey: keyof FeatureFlagsConfig, enabled: boolean) => {
    setLocalFlags(prev => ({
      ...prev,
      [flagKey]: { ...serverFlags?.[flagKey], enabled }
    }))
  }

  const clearLocalOverrides = () => {
    setLocalFlags({})
  }

  return {
    isFeatureEnabled,
    setLocalOverride,
    clearLocalOverrides,
    isLoading,
    flags: serverFlags || getFallbackFlags(environment),
    localOverrides: localFlags
  }
}

// Configuración de fallback cuando el servidor no está disponible
const getFallbackFlags = (environment: 'test' | 'prod'): FeatureFlagsConfig => ({
  ARBITRAGE_ENGINE_V2: {
    key: 'ARBITRAGE_ENGINE_V2',
    enabled: environment === 'test', // Solo en test por defecto
    rolloutPercentage: environment === 'test' ? 100 : 50,
    environment: ['test', 'prod'],
    description: 'Motor de arbitraje v2 con estrategias optimizadas'
  },
  HFT_ULTRA_LOW_LATENCY: {
    key: 'HFT_ULTRA_LOW_LATENCY',
    enabled: false, // Requiere infraestructura especial
    rolloutPercentage: 0,
    environment: ['prod'],
    dependencies: ['ARBITRAGE_ENGINE_V2'],
    description: 'Motor HFT con latencia <50μs'
  },
  MEV_PROTECTION_ADVANCED: {
    key: 'MEV_PROTECTION_ADVANCED',
    enabled: true,
    rolloutPercentage: 100,
    environment: ['test', 'prod'],
    description: 'Protección MEV avanzada con Flashbots'
  },
  CROSS_CHAIN_ROUTING: {
    key: 'CROSS_CHAIN_ROUTING',
    enabled: environment === 'test',
    rolloutPercentage: environment === 'test' ? 100 : 25,
    environment: ['test', 'prod'],
    description: 'Enrutamiento cross-chain optimizado'
  },
  AI_STRATEGY_OPTIMIZER: {
    key: 'AI_STRATEGY_OPTIMIZER',
    enabled: false, // En desarrollo
    rolloutPercentage: 0,
    environment: ['test'],
    description: 'Optimización de estrategias con IA'
  },
  REAL_TIME_PORTFOLIO: {
    key: 'REAL_TIME_PORTFOLIO',
    enabled: true,
    rolloutPercentage: 100,
    environment: ['test', 'prod'],
    description: 'Tracking de portfolio en tiempo real'
  },
  CIRCUIT_BREAKER_ENHANCED: {
    key: 'CIRCUIT_BREAKER_ENHANCED',
    enabled: true,
    rolloutPercentage: 100,
    environment: ['test', 'prod'],
    description: 'Circuit breaker mejorado para APIs'
  }
})

// Funciones auxiliares
const getUserId = (): string => {
  // Implementar una función que retorne un ID estable por usuario/sesión
  // Por ahora usamos un ID basado en localStorage
  let userId = localStorage.getItem('user-id')
  if (!userId) {
    userId = Math.random().toString(36).substring(2, 15)
    localStorage.setItem('user-id', userId)
  }
  return userId
}

const simpleHash = (str: string): number => {
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash // Convert to 32bit integer
  }
  return Math.abs(hash)
}