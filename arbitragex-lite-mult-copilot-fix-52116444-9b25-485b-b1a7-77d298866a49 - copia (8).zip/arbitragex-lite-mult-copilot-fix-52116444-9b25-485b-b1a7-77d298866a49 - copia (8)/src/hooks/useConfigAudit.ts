import { useState, useEffect, useCallback } from 'react';

export interface ConfigGap {
  file: string;
  key: string;
  value: string;
  service: string;
  category: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
}

export interface AuditState {
  gaps: ConfigGap[];
  isScanning: boolean;
  lastScan: Date | null;
  totalScans: number;
  healthScore: number;
}

// Critical services required for arbitrage operations
const CRITICAL_SERVICES = [
  {
    key: 'COINGECKO_API_KEY',
    category: 'PRICE_FEED',
    service: 'CoinGecko API - Price feeds',
    description: 'API para precios de tokens en tiempo real'
  },
  {
    key: 'ETHEREUM_RPC_URL',
    category: 'BLOCKCHAIN_RPC',
    service: 'Ethereum RPC - Mainnet/Goerli/Sepolia',
    description: 'Conexión principal a la red Ethereum para arbitraje'
  },
  {
    key: 'POLYGON_RPC_URL',
    category: 'BLOCKCHAIN_RPC',
    service: 'Polygon RPC - Matic network',
    description: 'Conexión a Polygon para arbitraje cross-chain'
  },
  {
    key: 'FLASHBOTS_RELAY_URL',
    category: 'MEV_PROTECTION',
    service: 'Flashbots Protect - MEV protection',
    description: 'Protección contra MEV attacks y front-running'
  },
  {
    key: 'OPENAI_API_KEY',
    category: 'AI_SERVICE',
    service: 'OpenAI GPT-4 API - Trading decisions',
    description: 'IA para análisis de mercado y toma de decisiones automatizada'
  },
  {
    key: 'AAVE_API_ENDPOINT',
    category: 'DEFI_PROTOCOL',
    service: 'Aave Protocol API - Flash loans',
    description: 'Acceso a flash loans para arbitraje con capital prestado'
  },
];

// Mock environment values to simulate missing configuration
const MOCK_ENV_VALUES: Record<string, string> = {
  COINGECKO_API_KEY: 'YOUR_COINGECKO_API_KEY_HERE',
  ETHEREUM_RPC_URL: '',
  FLASHBOTS_RELAY_URL: 'TBD',
  OPENAI_API_KEY: 'sk-placeholder-key-123',
  AAVE_API_ENDPOINT: 'changeme'
};

const PLACEHOLDER_PATTERNS = [
  /your_.*_here/i,
  /^[A-Z_]+_API_KEY$/,
  /placeholder/i,
  /changeme/i,
  /^tbd$/i,
  /^todo$/i,
  /^temp$/i,
  /example/i,
  /^test$/i
];

export const useConfigAudit = () => {
  const [auditState, setAuditState] = useState<AuditState>({
    gaps: [],
    isScanning: false,
    lastScan: null,
    totalScans: 0,
    healthScore: 100
  });

  const isPlaceholder = useCallback((value: string) => {
    if (typeof value !== 'string') return false;
    if (!value.trim()) return true;
    return PLACEHOLDER_PATTERNS.some(pattern => pattern.test(value));
  }, []);

  const getSeverity = useCallback((category: string): ConfigGap['severity'] => {
    switch (category) {
      case 'PRICE_FEED':
      case 'BLOCKCHAIN_RPC':
      case 'MEV_PROTECTION':
        return 'critical';
      case 'AI_SERVICE':
      case 'DEFI_PROTOCOL':
        return 'high';
      case 'NOTIFICATION':
        return 'medium';
      default:
        return 'low';
    }
  }, []);

  const runAudit = useCallback(async () => {
    setAuditState(prev => ({ ...prev, isScanning: true }));
    
    // Simular delay de escaneo para mostrar loading
    await new Promise(resolve => setTimeout(resolve, 1000));

    const foundGaps: ConfigGap[] = [];

    // Auditar servicios críticos
    CRITICAL_SERVICES.forEach(serviceConfig => {
      const value = MOCK_ENV_VALUES[serviceConfig.key] || process.env[serviceConfig.key] || '';
      
      if (isPlaceholder(value)) {
        foundGaps.push({
          file: '.env',
          key: serviceConfig.key,
          value: value || '(vacío)',
          service: serviceConfig.service,
          category: serviceConfig.category,
          severity: getSeverity(serviceConfig.category),
          description: serviceConfig.description
        });
      }
    });

    // Simular gaps adicionales en archivos de configuración
    const additionalGaps = [
      {
        file: 'config/services.json',
        key: 'price_feeds.dexscreener.api_key',
        value: 'YOUR_API_KEY',
        service: 'DexScreener API - DEX price aggregation',
        category: 'PRICE_FEED',
        severity: getSeverity('PRICE_FEED'),
        description: 'API para agregación de precios de DEXs descentralizados'
      },
      {
        file: 'config/networks.json',
        key: 'arbitrum.rpc_url',
        value: '',
        service: 'Arbitrum One RPC',
        category: 'BLOCKCHAIN_RPC',
        severity: getSeverity('BLOCKCHAIN_RPC'),
        description: 'Conexión a red Arbitrum para arbitraje Layer 2'
      },
      {
        file: 'src/config/strategies.ts',
        key: 'strategies.flash_loan.providers',
        value: 'mock_providers',
        service: 'Flash Loan Providers Integration',
        category: 'DEFI_PROTOCOL',
        severity: getSeverity('DEFI_PROTOCOL'),
        description: 'Configuración real de proveedores de flash loans'
      }
    ] as ConfigGap[];

    foundGaps.push(...additionalGaps);

    const healthScore = Math.max(0, Math.round(100 - (foundGaps.length * 8)));

    setAuditState(prev => ({
      ...prev,
      gaps: foundGaps,
      isScanning: false,
      lastScan: new Date(),
      totalScans: prev.totalScans + 1,
      healthScore
    }));

    return foundGaps;
  }, [isPlaceholder, getSeverity]);

  // Auto-audit on mount
  useEffect(() => {
    runAudit();
  }, [runAudit]);

  // Auto-refresh every 2 minutes
  useEffect(() => {
    const interval = setInterval(runAudit, 2 * 60 * 1000);
    return () => clearInterval(interval);
  }, [runAudit]);

  const getGapsByCategory = useCallback((category?: string) => {
    if (!category || category === 'all') return auditState.gaps;
    return auditState.gaps.filter(gap => gap.category === category);
  }, [auditState.gaps]);

  const getCriticalCount = useCallback(() => {
    return auditState.gaps.filter(gap => gap.severity === 'critical').length;
  }, [auditState.gaps]);

  const getCategories = useCallback(() => {
    return ['all', ...new Set(auditState.gaps.map(gap => gap.category))];
  }, [auditState.gaps]);

  return {
    ...auditState,
    runAudit,
    getGapsByCategory,
    getCriticalCount,
    getCategories
  };
};