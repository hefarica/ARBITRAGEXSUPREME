/**
 * 🔄 Hook personalizado para el servicio de reconexión automática
 * Proporciona acceso fácil al servicio de reconexión desde componentes React
 */

import { useState, useEffect, useCallback, useMemo } from 'react'
import { autoReconnectionService, BlockchainConnection, ReconnectionConfig } from '../services/AutoReconnectionService'

export interface UseAutoReconnectionReturn {
  // Estado del servicio
  isServiceRunning: boolean
  isStarting: boolean
  isStopping: boolean
  
  // Estado de las conexiones
  connections: Map<string, BlockchainConnection>
  connectionStats: {
    totalConnections: number
    connectedConnections: number
    disconnectedConnections: number
    reconnectingConnections: number
    errorConnections: number
  }
  
  // Configuración
  config: ReconnectionConfig
  
  // Acciones
  startService: () => Promise<void>
  stopService: () => void
  reconnectAll: () => Promise<void>
  reconnectBlockchain: (name: string) => Promise<boolean>
  updateConfig: (config: Partial<ReconnectionConfig>) => void
  
  // Eventos
  lastEvent: {
    type: string
    data: any
    timestamp: number
  } | null
  
  // Utilidades
  getConnectionByName: (name: string) => BlockchainConnection | undefined
  getConnectionsByStatus: (status: BlockchainConnection['status']) => BlockchainConnection[]
  getConnectionsByChainId: (chainId: number) => BlockchainConnection[]
}

export function useAutoReconnection(): UseAutoReconnectionReturn {
  // Estados del servicio
  const [isServiceRunning, setIsServiceRunning] = useState(false)
  const [isStarting, setIsStarting] = useState(false)
  const [isStopping, setIsStopping] = useState(false)
  
  // Estado de las conexiones
  const [connections, setConnections] = useState<Map<string, BlockchainConnection>>(new Map())
  const [connectionStats, setConnectionStats] = useState({
    totalConnections: 0,
    connectedConnections: 0,
    disconnectedConnections: 0,
    reconnectingConnections: 0,
    errorConnections: 0
  })
  
  // Configuración
  const [config, setConfig] = useState<ReconnectionConfig>(autoReconnectionService.getConfig())
  
  // Último evento recibido
  const [lastEvent, setLastEvent] = useState<{
    type: string
    data: any
    timestamp: number
  } | null>(null)

  // Configurar listeners de eventos
  useEffect(() => {
    const service = autoReconnectionService
    
    // Eventos del servicio
    const handleServiceStarted = () => {
      setIsServiceRunning(true)
      setIsStarting(false)
      setLastEvent({
        type: 'service_started',
        data: null,
        timestamp: Date.now()
      })
    }
    
    const handleServiceStopped = () => {
      setIsServiceRunning(false)
      setIsStopping(false)
      setLastEvent({
        type: 'service_stopped',
        data: null,
        timestamp: Date.now()
      })
    }
    
    // Eventos de blockchain
    const handleBlockchainReconnected = (data: { name: string; chainId: number }) => {
      setLastEvent({
        type: 'blockchain_reconnected',
        data,
        timestamp: Date.now()
      })
      refreshConnections()
    }
    
    const handleBlockchainDisconnected = (data: { name: string; chainId: number; error?: string }) => {
      setLastEvent({
        type: 'blockchain_disconnected',
        data,
        timestamp: Date.now()
      })
      refreshConnections()
    }
    
    const handleReconnecting = (data: { name: string; chainId: number; attempt: number }) => {
      setLastEvent({
        type: 'reconnecting',
        data,
        timestamp: Date.now()
      })
      refreshConnections()
    }
    
    const handleMaxReconnectionAttempts = (data: { name: string; chainId: number }) => {
      setLastEvent({
        type: 'max_reconnection_attempts_reached',
        data,
        timestamp: Date.now()
      })
      refreshConnections()
    }
    
    const handleConnectionStatusChanged = (data: { name: string; previousStatus: string; newStatus: string }) => {
      setLastEvent({
        type: 'connection_status_changed',
        data,
        timestamp: Date.now()
      })
      refreshConnections()
    }
    
    const handleHealthCheckSuccess = (data: { name: string; latency: number; blockHeight: number }) => {
      setLastEvent({
        type: 'health_check_success',
        data,
        timestamp: Date.now()
      })
      refreshConnections()
    }
    
    const handleHighLatencyDetected = (data: { name: string; latency: number }) => {
      setLastEvent({
        type: 'high_latency_detected',
        data,
        timestamp: Date.now()
      })
    }

    // Registrar listeners
    service.on('service_started', handleServiceStarted)
    service.on('service_stopped', handleServiceStopped)
    service.on('blockchain_reconnected', handleBlockchainReconnected)
    service.on('blockchain_disconnected', handleBlockchainDisconnected)
    service.on('reconnecting', handleReconnecting)
    service.on('max_reconnection_attempts_reached', handleMaxReconnectionAttempts)
    service.on('connection_status_changed', handleConnectionStatusChanged)
    service.on('health_check_success', handleHealthCheckSuccess)
    service.on('high_latency_detected', handleHighLatencyDetected)

    // Verificar estado inicial
    setIsServiceRunning(service.isServiceRunning())
    setConfig(service.getConfig())
    refreshConnections()

    // Cleanup
    return () => {
      service.off('service_started', handleServiceStarted)
      service.off('service_stopped', handleServiceStopped)
      service.off('blockchain_reconnected', handleBlockchainReconnected)
      service.off('blockchain_disconnected', handleBlockchainDisconnected)
      service.off('reconnecting', handleReconnecting)
      service.off('max_reconnection_attempts_reached', handleMaxReconnectionAttempts)
      service.off('connection_status_changed', handleConnectionStatusChanged)
      service.off('health_check_success', handleHealthCheckSuccess)
      service.off('high_latency_detected', handleHighLatencyDetected)
    }
  }, [])

  // Función para refrescar conexiones
  const refreshConnections = useCallback(() => {
    const service = autoReconnectionService
    const newConnections = service.getConnectionStatus()
    const newStats = service.getReconnectionStats()
    
    setConnections(newConnections)
    setConnectionStats(newStats)
  }, [])

  // Función para iniciar el servicio
  const startService = useCallback(async () => {
    if (isServiceRunning) return
    
    setIsStarting(true)
    try {
      await autoReconnectionService.start()
      setIsServiceRunning(true)
    } catch (error) {
      console.error('Error iniciando servicio de reconexión:', error)
    } finally {
      setIsStarting(false)
    }
  }, [isServiceRunning])

  // Función para detener el servicio
  const stopService = useCallback(() => {
    if (!isServiceRunning) return
    
    setIsStopping(true)
    try {
      autoReconnectionService.stop()
      setIsServiceRunning(false)
    } catch (error) {
      console.error('Error deteniendo servicio de reconexión:', error)
    } finally {
      setIsStopping(false)
    }
  }, [isServiceRunning])

  // Función para reconectar todas las blockchains
  const reconnectAll = useCallback(async () => {
    try {
      await autoReconnectionService.reconnectAllDisconnected()
      refreshConnections()
    } catch (error) {
      console.error('Error en reconexión masiva:', error)
    }
  }, [refreshConnections])

  // Función para reconectar una blockchain específica
  const reconnectBlockchain = useCallback(async (name: string): Promise<boolean> => {
    try {
      const result = await autoReconnectionService.reconnectBlockchain(name)
      refreshConnections()
      return result
    } catch (error) {
      console.error(`Error reconectando ${name}:`, error)
      return false
    }
  }, [refreshConnections])

  // Función para actualizar configuración
  const updateConfig = useCallback((newConfig: Partial<ReconnectionConfig>) => {
    autoReconnectionService.configure(newConfig)
    setConfig(autoReconnectionService.getConfig())
  }, [])

  // Utilidades para filtrar conexiones
  const getConnectionByName = useCallback((name: string) => {
    return connections.get(name)
  }, [connections])

  const getConnectionsByStatus = useCallback((status: BlockchainConnection['status']) => {
    return Array.from(connections.values()).filter(conn => conn.status === status)
  }, [connections])

  const getConnectionsByChainId = useCallback((chainId: number) => {
    return Array.from(connections.values()).filter(conn => conn.chainId === chainId)
  }, [connections])

  // Actualizar conexiones periódicamente
  useEffect(() => {
    const interval = setInterval(refreshConnections, 5000) // Cada 5 segundos
    return () => clearInterval(interval)
  }, [refreshConnections])

  // Memoizar el valor de retorno
  const returnValue = useMemo<UseAutoReconnectionReturn>(() => ({
    // Estado del servicio
    isServiceRunning,
    isStarting,
    isStopping,
    
    // Estado de las conexiones
    connections,
    connectionStats,
    
    // Configuración
    config,
    
    // Acciones
    startService,
    stopService,
    reconnectAll,
    reconnectBlockchain,
    updateConfig,
    
    // Eventos
    lastEvent,
    
    // Utilidades
    getConnectionByName,
    getConnectionsByStatus,
    getConnectionsByChainId
  }), [
    isServiceRunning,
    isStarting,
    isStopping,
    connections,
    connectionStats,
    config,
    startService,
    stopService,
    reconnectAll,
    reconnectBlockchain,
    updateConfig,
    lastEvent,
    getConnectionByName,
    getConnectionsByStatus,
    getConnectionsByChainId
  ])

  return returnValue
}

// Hook simplificado para solo el estado básico
export function useAutoReconnectionStatus() {
  const { isServiceRunning, connectionStats, lastEvent } = useAutoReconnection()
  
  return {
    isServiceRunning,
    connectionStats,
    lastEvent
  }
}

// Hook para acciones básicas
export function useAutoReconnectionActions() {
  const { startService, stopService, reconnectAll, reconnectBlockchain } = useAutoReconnection()
  
  return {
    startService,
    stopService,
    reconnectAll,
    reconnectBlockchain
  }
}
