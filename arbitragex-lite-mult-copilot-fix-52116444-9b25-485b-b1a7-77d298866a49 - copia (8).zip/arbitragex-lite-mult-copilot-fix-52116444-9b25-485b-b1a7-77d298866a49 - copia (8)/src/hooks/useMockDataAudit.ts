// hooks/useMockDataAudit.ts
/**
 * HOOK PERSONALIZADO PARA AUDITORÍA ZERO MOCK DATA
 * Integra detección y remediación en tiempo real
 */

import { useState, useCallback, useEffect } from 'react';
import { mockDataDetector, MockDataFinding } from '../audit/MockDataDetector';
import { mockDataRemediator } from '../audit/MockDataRemediator';

export interface AuditState {
  isRunning: boolean;
  findings: MockDataFinding[];
  remediationResults: any[];
  systemStatus: 'clean' | 'mock_detected' | 'deployment_blocked';
  lastAuditTime: Date | null;
  totalFindings: number;
  criticalFindings: number;
  highFindings: number;
  mediumFindings: number;
  lowFindings: number;
}

export interface AuditActions {
  runFullAudit: () => Promise<void>;
  runRemediationScan: () => Promise<void>;
  generateIntegrationServices: () => Promise<void>;
  blockDeployment: () => boolean;
  clearAuditResults: () => void;
}

export const useMockDataAudit = (): [AuditState, AuditActions] => {
  const [auditState, setAuditState] = useState<AuditState>({
    isRunning: false,
    findings: [],
    remediationResults: [],
    systemStatus: 'clean',
    lastAuditTime: null,
    totalFindings: 0,
    criticalFindings: 0,
    highFindings: 0,
    mediumFindings: 0,
    lowFindings: 0
  });

  // Ejecutar auditoría completa
  const runFullAudit = useCallback(async () => {
    setAuditState(prev => ({ ...prev, isRunning: true }));
    
    try {
      console.log('🔍 INICIANDO AUDITORÍA ZERO MOCK DATA...');
      
      const findings = await mockDataDetector.scanProject();
      
      // Calcular métricas
      const criticalFindings = findings.filter(f => f.severity === 'CRITICAL').length;
      const highFindings = findings.filter(f => f.severity === 'HIGH').length;
      const mediumFindings = findings.filter(f => f.severity === 'MEDIUM').length;
      const lowFindings = findings.filter(f => f.severity === 'LOW').length;
      
      // Determinar estado del sistema
      let systemStatus: 'clean' | 'mock_detected' | 'deployment_blocked' = 'clean';
      if (findings.length > 0) {
        systemStatus = 'mock_detected';
        if (criticalFindings > 0 || highFindings > 0) {
          systemStatus = 'deployment_blocked';
        }
      }
      
      setAuditState(prev => ({
        ...prev,
        findings,
        systemStatus,
        lastAuditTime: new Date(),
        totalFindings: findings.length,
        criticalFindings,
        highFindings,
        mediumFindings,
        lowFindings
      }));
      
      // Log resultados
      if (findings.length === 0) {
        console.log('✅ AUDITORÍA EXITOSA: Zero mock data detectado');
      } else {
        console.log(`🚨 MOCK DATA DETECTADO: ${findings.length} hallazgos`);
        console.log(`🔴 Críticos: ${criticalFindings}`);
        console.log(`🟠 Altos: ${highFindings}`);
        
        if (systemStatus === 'deployment_blocked') {
          console.log('🚫 DEPLOY BLOQUEADO por hallazgos críticos');
        }
      }
      
    } catch (error) {
      console.error('❌ Error en auditoría:', error);
    } finally {
      setAuditState(prev => ({ ...prev, isRunning: false }));
    }
  }, []);

  // Ejecutar remediación automática
  const runRemediationScan = useCallback(async () => {
    if (auditState.findings.length === 0) {
      console.log('ℹ️ No hay hallazgos para remediar');
      return;
    }
    
    setAuditState(prev => ({ ...prev, isRunning: true }));
    
    try {
      console.log('🔧 INICIANDO REMEDIACIÓN AUTOMÁTICA...');
      
      const remediationActions = await mockDataRemediator.remediateFindings(auditState.findings);
      
      setAuditState(prev => ({
        ...prev,
        remediationResults: remediationActions
      }));
      
      // Log resultados de remediación
      const completed = remediationActions.filter(r => r.status === 'COMPLETED').length;
      const manual = remediationActions.filter(r => r.status === 'REQUIRES_MANUAL').length;
      const failed = remediationActions.filter(r => r.status === 'FAILED').length;
      
      console.log(`✅ Remediación completada: ${completed} automáticas`);
      console.log(`⚠️ Requieren intervención manual: ${manual}`);
      console.log(`❌ Fallidas: ${failed}`);
      
    } catch (error) {
      console.error('❌ Error en remediación:', error);
    } finally {
      setAuditState(prev => ({ ...prev, isRunning: false }));
    }
  }, [auditState.findings]);

  // Generar servicios de integración
  const generateIntegrationServices = useCallback(async () => {
    setAuditState(prev => ({ ...prev, isRunning: true }));
    
    try {
      console.log('🏗️ GENERANDO SERVICIOS DE INTEGRACIÓN...');
      
      await mockDataRemediator.generateIntegrationServices();
      
      console.log('✅ Servicios de integración generados');
      console.log('📝 Configurar variables de entorno con credenciales reales');
      
    } catch (error) {
      console.error('❌ Error generando servicios:', error);
    } finally {
      setAuditState(prev => ({ ...prev, isRunning: false }));
    }
  }, []);

  // Verificar si el deployment debe ser bloqueado
  const blockDeployment = useCallback((): boolean => {
    return auditState.systemStatus === 'deployment_blocked';
  }, [auditState.systemStatus]);

  // Limpiar resultados de auditoría
  const clearAuditResults = useCallback(() => {
    setAuditState({
      isRunning: false,
      findings: [],
      remediationResults: [],
      systemStatus: 'clean',
      lastAuditTime: null,
      totalFindings: 0,
      criticalFindings: 0,
      highFindings: 0,
      mediumFindings: 0,
      lowFindings: 0
    });
  }, []);

  // Auditoría automática al montar el componente
  useEffect(() => {
    // Ejecutar auditoría automática en modo silencioso
    const runSilentAudit = async () => {
      try {
        const findings = await mockDataDetector.scanProject();
        
        if (findings.length > 0) {
          const criticalFindings = findings.filter(f => f.severity === 'CRITICAL').length;
          const highFindings = findings.filter(f => f.severity === 'HIGH').length;
          
          setAuditState(prev => ({
            ...prev,
            findings,
            systemStatus: (criticalFindings > 0 || highFindings > 0) ? 'deployment_blocked' : 'mock_detected',
            totalFindings: findings.length,
            criticalFindings,
            highFindings,
            mediumFindings: findings.filter(f => f.severity === 'MEDIUM').length,
            lowFindings: findings.filter(f => f.severity === 'LOW').length,
            lastAuditTime: new Date()
          }));
        }
      } catch (error) {
        console.warn('Warning: Auditoría silenciosa falló:', error);
      }
    };
    
    runSilentAudit();
  }, []);

  const actions: AuditActions = {
    runFullAudit,
    runRemediationScan,
    generateIntegrationServices,
    blockDeployment,
    clearAuditResults
  };

  return [auditState, actions];
};

// Hook simplificado para verificar estado de mock data
export const useMockDataStatus = () => {
  const [auditState] = useMockDataAudit();
  
  return {
    hasMockData: auditState.totalFindings > 0,
    isDeploymentBlocked: auditState.systemStatus === 'deployment_blocked',
    criticalFindings: auditState.criticalFindings,
    totalFindings: auditState.totalFindings,
    lastAuditTime: auditState.lastAuditTime
  };
};