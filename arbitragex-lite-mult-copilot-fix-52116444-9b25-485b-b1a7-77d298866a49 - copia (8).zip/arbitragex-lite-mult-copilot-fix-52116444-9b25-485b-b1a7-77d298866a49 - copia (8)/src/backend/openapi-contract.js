/**
 * Contrato OpenAPI para ArbitrageX Gap Auditor Server
 * Este archivo genera el contrato OpenAPI basado en los endpoints reales del servidor
 */

export function generateOpenAPIContract() {
  return {
    "openapi": "3.0.3",
    "info": {
      "title": "ArbitrageX Gap Auditor API",
      "version": "1.0.0",
      "description": "API para el sistema de auditoría de gaps de arbitraje DeFi de ArbitrageX",
      "contact": {
        "name": "ArbitrageX Support",
        "url": "https://arbitragex.pro"
      }
    },
    "servers": [
      {
        "url": "http://localhost:3002/api",
        "description": "Servidor de desarrollo"
      },
      {
        "url": "https://api.arbitragex.pro/api",
        "description": "Servidor de producción"
      }
    ],
    "paths": {
      "/health": {
        "get": {
          "summary": "Health Check",
          "description": "Verificar estado del servidor",
          "operationId": "healthCheck",
          "tags": ["System"],
          "responses": {
            "200": {
              "description": "Servidor funcionando correctamente",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "status": { "type": "string", "example": "ok" },
                      "timestamp": { "type": "string", "format": "date-time" }
                    }
                  }
                }
              }
            }
          }
        }
      },
      "/api/metrics": {
        "get": {
          "summary": "Obtener Métricas del Sistema",
          "description": "Retorna métricas actuales del auditor de gaps",
          "operationId": "getMetrics",
          "tags": ["Metrics"],
          "responses": {
            "200": {
              "description": "Métricas del sistema",
              "content": {
                "application/json": {
                  "schema": {
                    "$ref": "#/components/schemas/Metrics"
                  }
                }
              }
            }
          }
        }
      },
      "/api/events": {
        "get": {
          "summary": "Obtener Eventos del Sistema",
          "description": "Retorna los últimos 50 eventos del auditor",
          "operationId": "getEvents",
          "tags": ["Events"],
          "responses": {
            "200": {
              "description": "Lista de eventos",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "array",
                    "items": {
                      "$ref": "#/components/schemas/Event"
                    }
                  }
                }
              }
            }
          }
        }
      },
      "/api/nodes": {
        "get": {
          "summary": "Obtener Estado de Nodos",
          "description": "Retorna el estado de todos los nodos monitoreados",
          "operationId": "getNodes",
          "tags": ["Nodes"],
          "responses": {
            "200": {
              "description": "Estado de nodos",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "array",
                    "items": {
                      "$ref": "#/components/schemas/NodeStatus"
                    }
                  }
                }
              }
            }
          }
        }
      },
      "/api/config": {
        "get": {
          "summary": "Obtener Configuración",
          "description": "Retorna la configuración actual del auditor",
          "operationId": "getConfig",
          "tags": ["Configuration"],
          "responses": {
            "200": {
              "description": "Configuración actual",
              "content": {
                "application/json": {
                  "schema": {
                    "$ref": "#/components/schemas/Config"
                  }
                }
              }
            }
          }
        },
        "post": {
          "summary": "Actualizar Configuración",
          "description": "Actualiza la configuración del auditor",
          "operationId": "updateConfig",
          "tags": ["Configuration"],
          "requestBody": {
            "required": true,
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/ConfigUpdate"
                }
              }
            }
          },
          "responses": {
            "200": {
              "description": "Configuración actualizada",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "success": { "type": "boolean" },
                      "config": { "$ref": "#/components/schemas/Config" }
                    }
                  }
                }
              }
            }
          }
        }
      },
      "/api/start": {
        "post": {
          "summary": "Iniciar Auditor",
          "description": "Inicia el proceso de auditoría de gaps",
          "operationId": "startAuditor",
          "tags": ["Control"],
          "responses": {
            "200": {
              "description": "Auditor iniciado",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "success": { "type": "boolean" },
                      "message": { "type": "string" }
                    }
                  }
                }
              }
            }
          }
        }
      },
      "/api/stop": {
        "post": {
          "summary": "Detener Auditor",
          "description": "Detiene el proceso de auditoría de gaps",
          "operationId": "stopAuditor",
          "tags": ["Control"],
          "responses": {
            "200": {
              "description": "Auditor detenido",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "success": { "type": "boolean" },
                      "message": { "type": "string" }
                    }
                  }
                }
              }
            }
          }
        }
      },
      "/api/status": {
        "get": {
          "summary": "Estado del Auditor",
          "description": "Obtiene el estado actual del auditor",
          "operationId": "getStatus",
          "tags": ["Control"],
          "responses": {
            "200": {
              "description": "Estado del auditor",
              "content": {
                "application/json": {
                  "schema": {
                    "$ref": "#/components/schemas/AuditorStatus"
                  }
                }
              }
            }
          }
        }
      }
    },
    "components": {
      "schemas": {
        "Metrics": {
          "type": "object",
          "properties": {
            "gapScore": { "type": "number", "description": "Puntuación de gap" },
            "priceGap": { "type": "number", "description": "Gap de precio" },
            "depthGap": { "type": "number", "description": "Gap de profundidad" },
            "latencyGap": { "type": "number", "description": "Gap de latencia" },
            "riskGap": { "type": "number", "description": "Gap de riesgo" },
            "roiNet": { "type": "number", "description": "ROI neto" },
            "collisionProb": { "type": "number", "description": "Probabilidad de colisión" },
            "decisionLatency": { "type": "number", "description": "Latencia de decisión" }
          }
        },
        "Event": {
          "type": "object",
          "properties": {
            "id": { "type": "string" },
            "type": { "type": "string" },
            "timestamp": { "type": "string", "format": "date-time" },
            "message": { "type": "string" },
            "data": { "type": "object" }
          }
        },
        "NodeStatus": {
          "type": "object",
          "properties": {
            "id": { "type": "string" },
            "url": { "type": "string" },
            "status": { "type": "string", "enum": ["online", "offline", "degraded"] },
            "latency": { "type": "number" },
            "lastCheck": { "type": "string", "format": "date-time" }
          }
        },
        "Config": {
          "type": "object",
          "properties": {
            "rpcLocal": { "type": "string" },
            "subgraphUni": { "type": "string" },
            "llamaEndpoint": { "type": "string" },
            "flashbotsRelay": { "type": "string" },
            "collectionInterval": { "type": "number" },
            "decisionLatency": { "type": "number" },
            "minGapScore": { "type": "number" },
            "minRoiNet": { "type": "number" },
            "maxCollisionProb": { "type": "number" }
          }
        },
        "ConfigUpdate": {
          "type": "object",
          "properties": {
            "collectionInterval": { "type": "number", "minimum": 100 },
            "decisionLatency": { "type": "number", "minimum": 50 },
            "minGapScore": { "type": "number", "minimum": 0, "maximum": 100 },
            "minRoiNet": { "type": "number", "minimum": 0 },
            "maxCollisionProb": { "type": "number", "minimum": 0, "maximum": 1 }
          }
        },
        "AuditorStatus": {
          "type": "object",
          "properties": {
            "isRunning": { "type": "boolean" },
            "uptime": { "type": "number", "description": "Tiempo en milisegundos" }
          }
        }
      },
      "tags": [
        {
          "name": "System",
          "description": "Endpoints del sistema"
        },
        {
          "name": "Metrics",
          "description": "Métricas del auditor"
        },
        {
          "name": "Events",
          "description": "Eventos del sistema"
        },
        {
          "name": "Nodes",
          "description": "Estado de nodos"
        },
        {
          "name": "Configuration",
          "description": "Configuración del auditor"
        },
        {
          "name": "Control",
          "description": "Control del auditor"
        }
      ]
    }
  };
}

