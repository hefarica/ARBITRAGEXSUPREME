const WebSocket = require('ws');
const http = require('http');
const express = require('express');
const cors = require('cors');

class BlockchainStreamServer {
    constructor(port = 3001) {
        this.port = port;
        this.app = express();
        this.server = http.createServer(this.app);
        this.wss = new WebSocket.Server({ server: this.server });
        this.clients = new Set();
        this.blockchainStatus = {};
        this.connectionTests = new Map();
        
        this.setupMiddleware();
        this.setupWebSocket();
        this.setupRoutes();
        this.startConnectionMonitoring();
    }

    setupMiddleware() {
        this.app.use(cors());
        this.app.use(express.json());
        this.app.use(express.static('public'));
    }

    setupWebSocket() {
        this.wss.on('connection', (ws, req) => {
            console.log('Cliente WebSocket conectado:', req.socket.remoteAddress);
            this.clients.add(ws);

            // Enviar estado inicial
            ws.send(JSON.stringify({
                type: 'blockchain_status',
                data: this.blockchainStatus,
                timestamp: Date.now()
            }));

            ws.on('close', () => {
                console.log('Cliente WebSocket desconectado');
                this.clients.delete(ws);
            });

            ws.on('error', (error) => {
                console.error('Error WebSocket:', error);
                this.clients.delete(ws);
            });
        });
    }

    setupRoutes() {
        // Endpoint para obtener estado actual de blockchains
        this.app.get('/api/blockchain/status', (req, res) => {
            res.json({
                success: true,
                data: this.blockchainStatus,
                timestamp: Date.now()
            });
        });

        // Endpoint para actualizar configuración de blockchain
        this.app.post('/api/blockchain/update', async (req, res) => {
            try {
                const { blockchain, rpcUrl, enabled } = req.body;
                
                if (!blockchain || !rpcUrl) {
                    return res.status(400).json({
                        success: false,
                        message: 'Blockchain y RPC URL son requeridos'
                    });
                }

                // Validar conexión RPC
                const isConnected = await this.testBlockchainConnection(rpcUrl);
                
                // Actualizar estado
                this.blockchainStatus[blockchain] = {
                    name: this.getBlockchainDisplayName(blockchain),
                    connected: isConnected && enabled,
                    rpc: rpcUrl,
                    status: isConnected && enabled ? 'active' : 'inactive',
                    lastTested: Date.now(),
                    latency: await this.measureLatency(rpcUrl)
                };

                // Notificar a todos los clientes
                this.broadcastUpdate();

                res.json({
                    success: true,
                    data: this.blockchainStatus[blockchain],
                    message: `Blockchain ${blockchain} actualizada`
                });

            } catch (error) {
                console.error('Error actualizando blockchain:', error);
                res.status(500).json({
                    success: false,
                    message: 'Error interno del servidor'
                });
            }
        });

        // Endpoint para test de conexión
        this.app.post('/api/blockchain/test', async (req, res) => {
            try {
                const { rpcUrl } = req.body;
                const isConnected = await this.testBlockchainConnection(rpcUrl);
                const latency = await this.measureLatency(rpcUrl);

                res.json({
                    success: true,
                    connected: isConnected,
                    latency: latency,
                    timestamp: Date.now()
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    message: 'Error en test de conexión'
                });
            }
        });

        // Endpoint para streaming SSE (Server-Sent Events)
        this.app.get('/blockchain-stream', (req, res) => {
            res.writeHead(200, {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                'Access-Control-Allow-Origin': '*'
            });

            const clientId = Date.now();
            console.log('Cliente SSE conectado:', clientId);

            // Enviar estado inicial
            res.write(`data: ${JSON.stringify({
                type: 'blockchain_status',
                data: this.blockchainStatus,
                timestamp: Date.now()
            })}\n\n`);

            // Mantener conexión viva
            const keepAlive = setInterval(() => {
                res.write(`data: ${JSON.stringify({
                    type: 'ping',
                    timestamp: Date.now()
                })}\n\n`);
            }, 30000);

            req.on('close', () => {
                console.log('Cliente SSE desconectado:', clientId);
                clearInterval(keepAlive);
            });
        });
    }

    async testBlockchainConnection(rpcUrl) {
        if (!rpcUrl || rpcUrl.trim() === '') {
            return false;
        }

        try {
            const startTime = Date.now();
            
            // Test básico de conectividad HTTP
            const response = await fetch(rpcUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'eth_blockNumber',
                    params: [],
                    id: 1
                }),
                signal: AbortSignal.timeout(5000) // 5 segundos timeout
            });

            if (response.ok) {
                const data = await response.json();
                return data.jsonrpc === '2.0' && data.result;
            }

            return false;
        } catch (error) {
            console.error('Error testando conexión blockchain:', error);
            return false;
        }
    }

    async measureLatency(rpcUrl) {
        if (!rpcUrl || rpcUrl.trim() === '') {
            return null;
        }

        try {
            const startTime = Date.now();
            
            await fetch(rpcUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'eth_blockNumber',
                    params: [],
                    id: 1
                }),
                signal: AbortSignal.timeout(5000)
            });

            return Date.now() - startTime;
        } catch (error) {
            return null;
        }
    }

    getBlockchainDisplayName(blockchain) {
        const names = {
            ethereum: 'Ethereum (ETH)',
            polygon: 'Polygon (MATIC)',
            bsc: 'Binance Smart Chain (BNB)',
            arbitrum: 'Arbitrum (ARB)',
            optimism: 'Optimism (OP)',
            avalanche: 'Avalanche (AVAX)',
            fantom: 'Fantom (FTM)',
            solana: 'Solana (SOL)'
        };
        return names[blockchain] || blockchain;
    }

    startConnectionMonitoring() {
        // Monitorear conexiones cada 30 segundos
        setInterval(async () => {
            console.log('Monitoreando conexiones blockchain...');
            
            for (const [blockchain, status] of Object.entries(this.blockchainStatus)) {
                if (status.rpc && status.status === 'active') {
                    const isConnected = await this.testBlockchainConnection(status.rpc);
                    const latency = await this.measureLatency(status.rpc);
                    
                    if (isConnected !== status.connected || latency !== status.latency) {
                        this.blockchainStatus[blockchain] = {
                            ...status,
                            connected: isConnected,
                            status: isConnected ? 'active' : 'inactive',
                            lastTested: Date.now(),
                            latency: latency
                        };
                        
                        console.log(`Estado actualizado para ${blockchain}:`, this.blockchainStatus[blockchain]);
                    }
                }
            }
            
            // Notificar cambios a clientes
            this.broadcastUpdate();
        }, 30000);
    }

    broadcastUpdate() {
        const update = {
            type: 'blockchain_update',
            data: this.blockchainStatus,
            timestamp: Date.now()
        };

        // Enviar a clientes WebSocket
        this.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify(update));
            }
        });

        console.log('Actualización broadcast enviada a', this.clients.size, 'clientes');
    }

    start() {
        this.server.listen(this.port, () => {
            console.log(`🚀 Servidor Blockchain Stream iniciado en puerto ${this.port}`);
            console.log(`📡 WebSocket disponible en ws://localhost:${this.port}`);
            console.log(`🌐 API REST disponible en http://localhost:${this.port}`);
            console.log(`📊 Streaming SSE disponible en http://localhost:${this.port}/blockchain-stream`);
        });
    }
}

module.exports = BlockchainStreamServer;

// Iniciar servidor si se ejecuta directamente
if (require.main === module) {
    const server = new BlockchainStreamServer();
    server.start();
}
