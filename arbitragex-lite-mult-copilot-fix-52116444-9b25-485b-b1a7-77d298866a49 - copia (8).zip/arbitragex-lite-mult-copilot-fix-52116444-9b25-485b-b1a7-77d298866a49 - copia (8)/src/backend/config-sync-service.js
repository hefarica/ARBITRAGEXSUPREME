const fs = require('fs').promises;
const path = require('path');

class ConfigSyncService {
    constructor(blockchainServer) {
        this.blockchainServer = blockchainServer;
        this.configPath = path.join(__dirname, '../../frontend/config.html');
        this.watchInterval = null;
        this.lastConfigHash = null;
        
        this.startConfigWatching();
    }

    async startConfigWatching() {
        console.log('🔍 Iniciando monitoreo de config.html...');
        
        // Monitorear cambios en config.html cada 2 segundos
        this.watchInterval = setInterval(async () => {
            try {
                await this.checkConfigChanges();
            } catch (error) {
                console.error('Error monitoreando config.html:', error);
            }
        }, 2000);
    }

    async checkConfigChanges() {
        try {
            const configContent = await fs.readFile(this.configPath, 'utf8');
            const currentHash = this.generateHash(configContent);
            
            if (this.lastConfigHash !== currentHash) {
                console.log('📝 Cambios detectados en config.html');
                this.lastConfigHash = currentHash;
                
                // Extraer configuraciones de blockchain
                const blockchainConfigs = this.extractBlockchainConfigs(configContent);
                
                // Sincronizar con el servidor blockchain
                await this.syncBlockchainConfigs(blockchainConfigs);
            }
        } catch (error) {
            console.error('Error leyendo config.html:', error);
        }
    }

    extractBlockchainConfigs(configContent) {
        const configs = {};
        
        // Extraer configuraciones de RPC usando regex
        const rpcPatterns = {
            ethereum: /id="ethereum-rpc"[^>]*value="([^"]*)"/,
            polygon: /id="polygon-rpc"[^>]*value="([^"]*)"/,
            bsc: /id="bsc-rpc"[^>]*value="([^"]*)"/,
            arbitrum: /id="arbitrum-rpc"[^>]*value="([^"]*)"/,
            optimism: /id="optimism-rpc"[^>]*value="([^"]*)"/,
            avalanche: /id="avalanche-rpc"[^>]*value="([^"]*)"/,
            fantom: /id="fantom-rpc"[^>]*value="([^"]*)"/,
            solana: /id="solana-rpc"[^>]*value="([^"]*)"/
        };

        // Extraer configuraciones de estado (enabled/disabled)
        const enabledPatterns = {
            ethereum: /id="ethereum-enabled"[^>]*checked/,
            polygon: /id="polygon-enabled"[^>]*checked/,
            bsc: /id="bsc-enabled"[^>]*checked/,
            arbitrum: /id="arbitrum-enabled"[^>]*checked/,
            optimism: /id="optimism-enabled"[^>]*checked/,
            avalanche: /id="avalanche-enabled"[^>]*checked/,
            fantom: /id="fantom-enabled"[^>]*checked/,
            solana: /id="solana-enabled"[^>]*checked/
        };

        Object.keys(rpcPatterns).forEach(blockchain => {
            const rpcMatch = configContent.match(rpcPatterns[blockchain]);
            const enabledMatch = configContent.match(enabledPatterns[blockchain]);
            
            if (rpcMatch && rpcMatch[1]) {
                configs[blockchain] = {
                    rpc: rpcMatch[1].trim(),
                    enabled: !!enabledMatch
                };
            }
        });

        return configs;
    }

    async syncBlockchainConfigs(blockchainConfigs) {
        console.log('🔄 Sincronizando configuraciones blockchain:', Object.keys(blockchainConfigs));
        
        for (const [blockchain, config] of Object.entries(blockchainConfigs)) {
            try {
                // Actualizar en el servidor blockchain
                const response = await fetch(`http://localhost:${this.blockchainServer.port}/api/blockchain/update`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        blockchain,
                        rpcUrl: config.rpc,
                        enabled: config.enabled
                    })
                });

                if (response.ok) {
                    const result = await response.json();
                    console.log(`✅ ${blockchain} sincronizado:`, result.message);
                } else {
                    console.error(`❌ Error sincronizando ${blockchain}:`, response.statusText);
                }
            } catch (error) {
                console.error(`❌ Error sincronizando ${blockchain}:`, error.message);
            }
        }
    }

    generateHash(content) {
        // Hash simple para detectar cambios
        let hash = 0;
        for (let i = 0; i < content.length; i++) {
            const char = content.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convertir a 32-bit integer
        }
        return hash;
    }

    stop() {
        if (this.watchInterval) {
            clearInterval(this.watchInterval);
            console.log('🛑 Monitoreo de config.html detenido');
        }
    }
}

module.exports = ConfigSyncService;
