import express from 'express';
import cors from 'cors';
import Web3 from 'web3';
import axios from 'axios';
import { EventEmitter } from 'events';
import { generateOpenAPIContract } from './openapi-contract.js';
// import { rateLimitingMiddleware } from '../middleware/RateLimitingMiddleware.js';
// Comentado temporalmente hasta que se compile el TypeScript

class GapAuditorServer {
  constructor() {
    this.app = express();
    this.port = process.env.PORT || 3002; // Puerto fijo para desarrollo
    this.isRunning = false;
    this.events = new EventEmitter();
    this.metrics = {
      gapScore: 0,
      priceGap: 0,
      depthGap: 0,
      latencyGap: 0,
      riskGap: 0,
      roiNet: 0,
      collisionProb: 0,
      decisionLatency: 0
    };
    this.config = {
      rpcLocal: 'https://eth-mainnet.g.alchemy.com/v2/demo',
      subgraphUni: 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3',
      llamaEndpoint: 'https://api.llama.fi',
      flashbotsRelay: 'https://relay.flashbots.net',
      collectionInterval: 500,
      decisionLatency: 150,
      minGapScore: 75,
      minRoiNet: 0.4,
      maxCollisionProb: 0.25
    };
    this.eventsList = [];
    this.nodeStatuses = [];
    
    this.setupMiddleware();
    this.setupRoutes();
    this.setupMonitoringServices();
    this.initializeWeb3();
  }

  setupMiddleware() {
    // CORS Seguro - Solo orígenes específicos
    const allowedOrigins = process.env.NODE_ENV === 'production' 
      ? ['https://arbitragex.pro', 'https://www.arbitragex.pro', 'https://app.arbitragex.pro']
      : ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:3001', 'http://localhost:8080', 'http://127.0.0.1:8080'];

    this.app.use(cors({
      origin: (origin, callback) => {
        // Permitir requests sin origin (Postman, curl, etc.) solo en desarrollo
        if (!origin && process.env.NODE_ENV !== 'production') {
          return callback(null, true);
        }
        
        if (allowedOrigins.includes(origin)) {
          callback(null, true);
        } else {
          console.warn(`🚫 CORS: Origen rechazado: ${origin}`);
          callback(new Error('No permitido por CORS'), false);
        }
      },
      credentials: true, // Permitir cookies y headers de auth
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: [
        'Content-Type', 
        'Authorization', 
        'X-Requested-With',
        'X-API-Key',
        'X-Request-ID',
        'Cache-Control'
      ],
      exposedHeaders: [
        'X-RateLimit-Limit',
        'X-RateLimit-Remaining', 
        'X-RateLimit-Reset',
        'X-Request-ID'
      ],
      maxAge: 86400 // 24 horas cache para preflight
    }));

    // Middleware de seguridad adicional
    this.app.use((req, res, next) => {
      // Headers de seguridad
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Frame-Options', 'DENY');
      res.setHeader('X-XSS-Protection', '0');
      res.setHeader('Referrer-Policy', 'no-referrer');
      res.removeHeader('X-Powered-By');
      res.setHeader('Server', 'ArbitrageX-API');
      
      // HTTPS obligatorio en producción
      if (process.env.NODE_ENV === 'production' && !req.secure && req.headers['x-forwarded-proto'] !== 'https') {
        return res.redirect(301, `https://${req.headers.host}${req.url}`);
      }
      
      next();
    });

    this.app.use(express.json({ 
      limit: '10mb',
      verify: (req, res, buf, encoding) => {
        // Verificar que el JSON no sea malicioso
        if (buf && buf.length) {
          const body = buf.toString(encoding || 'utf8');
          if (body.includes('__proto__') || body.includes('constructor.prototype')) {
            throw new Error('Payload malicioso detectado');
          }
        }
      }
    }));
    
    this.app.use(express.static('public', {
      etag: false,
      lastModified: false,
      setHeaders: (res, path) => {
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
      }
    }));
    
    // Configurar rate limiting
    // rateLimitingMiddleware.setupCommonLimiters();
    // this.app.use(rateLimitingMiddleware.middleware());
    // Comentado temporalmente hasta que se compile el TypeScript
    
    console.log('🛡️ Middleware de seguridad configurado');
    console.log(`🔒 CORS configurado para: ${allowedOrigins.join(', ')}`);
  }

  setupRoutes() {
    // Health check
    this.app.get('/health', (req, res) => {
      res.json({ status: 'ok', timestamp: new Date().toISOString() });
    });

    // Get current metrics
    this.app.get('/api/metrics', (req, res) => {
      res.json(this.metrics);
    });

    // Get events
    this.app.get('/api/events', (req, res) => {
      res.json(this.eventsList.slice(0, 50));
    });

    // Get node statuses
    this.app.get('/api/nodes', (req, res) => {
      res.json(this.nodeStatuses);
    });

    // Get configuration
    this.app.get('/api/config', (req, res) => {
      res.json(this.config);
    });

    // Update configuration
    this.app.post('/api/config', (req, res) => {
      const oldConfig = { ...this.config };
      this.config = { ...this.config, ...req.body };
      
      // Emitir evento para Contract Watcher
      this.events.emit('config_updated', {
        oldConfig,
        newConfig: this.config,
        timestamp: new Date().toISOString()
      });
      
      res.json({ success: true, config: this.config });
    });

    // Start auditor
    this.app.post('/api/start', (req, res) => {
      this.startAuditor();
      res.json({ success: true, message: 'Auditor started' });
    });

    // Stop auditor
    this.app.post('/api/stop', (req, res) => {
      this.stopAuditor();
      res.json({ success: true, message: 'Auditor stopped' });
    });

    // Get auditor status
    this.app.get('/api/status', (req, res) => {
      res.json({ 
        isRunning: this.isRunning, 
        uptime: this.isRunning ? Date.now() - this.startTime : 0 
      });
    });

    // SSE for real-time updates
    this.app.get('/api/stream', (req, res) => {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Access-Control-Allow-Origin': '*'
      });

      const sendEvent = (data) => {
        res.write(`data: ${JSON.stringify(data)}\n\n`);
      };

      this.events.on('metrics', sendEvent);
      this.events.on('event', sendEvent);

      req.on('close', () => {
        this.events.off('metrics', sendEvent);
        this.events.off('event', sendEvent);
      });
    });

    // 🔍 CONTRACT WATCHER ENDPOINTS - OpenAPI Contract
    this.app.get('/api/openapi.json', (req, res) => {
      try {
        const contract = generateOpenAPIContract();
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Cache-Control', 'public, max-age=300'); // Cache 5 minutos
        res.json(contract);
      } catch (error) {
        console.error('❌ Error generando contrato OpenAPI:', error);
        res.status(500).json({ error: 'Error generando contrato' });
      }
    });

    // OpenAPI contract en ruta alternativa
    this.app.get('/openapi.json', (req, res) => {
      res.redirect('/api/openapi.json');
    });

    // Contract watcher - Registry UI management
    this.app.put('/api/ui/feature-registry', express.json(), (req, res) => {
      try {
        // Validar que el registry tenga estructura válida
        if (!req.body || !req.body.features || !Array.isArray(req.body.features)) {
          return res.status(400).json({ 
            error: 'Registry inválido: se requiere array de features' 
          });
        }

        // En una implementación real, guardarías esto en base de datos
        // Por ahora solo confirmamos recepción
        console.log('📝 Registry UI recibido:', {
          version: req.body.version,
          features: req.body.features.length,
          source: req.body.source,
          contractHash: req.body.contractHash
        });

        res.json({ 
          success: true, 
          message: 'Registry guardado exitosamente',
          saved: {
            version: req.body.version,
            featuresCount: req.body.features.length,
            timestamp: new Date().toISOString()
          }
        });
      } catch (error) {
        console.error('❌ Error guardando registry UI:', error);
        res.status(500).json({ error: 'Error guardando registry' });
      }
    });

    // Check if registry endpoint exists (HEAD request)
    this.app.head('/api/ui/feature-registry', (req, res) => {
      res.status(200).end();
    });

    // Contract stream for real-time updates (SSE)
    this.app.get('/api/contracts/stream', (req, res) => {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Cache-Control'
      });

      // Enviar evento inicial
      res.write(`data: ${JSON.stringify({
        type: 'contract_stream_connected',
        message: 'Contract watcher stream conectado',
        timestamp: new Date().toISOString()
      })}\n\n`);

      // Simular eventos de cambio de contrato cada 60 segundos para pruebas
      const contractUpdateInterval = setInterval(() => {
        if (!res.destroyed) {
          res.write(`data: ${JSON.stringify({
            type: 'contract_heartbeat',
            message: 'Contract watcher activo',
            timestamp: new Date().toISOString(),
            endpoints: ['/api/openapi.json']
          })}\n\n`);
        }
      }, 60000);

      // Escuchar eventos de configuración para notificar cambios
      const onConfigChange = () => {
        if (!res.destroyed) {
          res.write(`data: ${JSON.stringify({
            type: 'contract_updated',
            message: 'Configuración actualizada - contrato puede haber cambiado',
            timestamp: new Date().toISOString(),
            trigger: 'config_change'
          })}\n\n`);
        }
      };

      this.events.on('config_updated', onConfigChange);

      req.on('close', () => {
        clearInterval(contractUpdateInterval);
        this.events.off('config_updated', onConfigChange);
        console.log('🔍 Contract watcher stream desconectado');
      });
    });
  }

  async initializeWeb3() {
    try {
      this.web3 = new Web3(this.config.rpcLocal);
      console.log('✅ Web3 initialized');
      
      // Initialize mock nodes
      this.nodeStatuses = [
        {
          name: 'Ethereum Mainnet',
          url: this.config.rpcLocal,
          status: 'connected',
          blockNumber: await this.web3.eth.getBlockNumber(),
          gasPrice: await this.web3.eth.getGasPrice(),
          pendingTxs: Math.floor(Math.random() * 100),
          lastUpdate: new Date()
        },
        {
          name: 'Polygon',
          url: 'https://polygon-rpc.com',
          status: 'connected',
          blockNumber: Math.floor(Math.random() * 1000000),
          gasPrice: Math.floor(Math.random() * 100),
          pendingTxs: Math.floor(Math.random() * 80),
          lastUpdate: new Date()
        },
        {
          name: 'BSC',
          url: 'https://bsc-dataseed.binance.org',
          status: 'connected',
          blockNumber: Math.floor(Math.random() * 10000000),
          gasPrice: Math.floor(Math.random() * 10),
          pendingTxs: Math.floor(Math.random() * 120),
          lastUpdate: new Date()
        }
      ];
    } catch (error) {
      console.error('❌ Error initializing Web3:', error.message);
    }
  }

  async collectBlockchainData() {
    try {
      if (!this.web3) return null;

      const blockNumber = await this.web3.eth.getBlockNumber();
      const gasPrice = await this.web3.eth.getGasPrice();
      const pendingCount = await this.web3.eth.getPendingTransactions();

      return {
        blockNumber,
        gasPrice: this.web3.utils.fromWei(gasPrice, 'gwei'),
        pendingTxs: pendingCount.length || Math.floor(Math.random() * 100),
        timestamp: new Date()
      };
    } catch (error) {
      console.error('❌ Error collecting blockchain data:', error.message);
      return null;
    }
  }

  async collectDexPrices() {
    try {
      // Simulate DEX price collection
      const prices = {
        'USDC/ETH': 0.0005 + Math.random() * 0.0001,
        'USDT/ETH': 0.0005 + Math.random() * 0.0001,
        'DAI/ETH': 0.0005 + Math.random() * 0.0001,
        'WETH/USDC': 2000 + Math.random() * 100,
        'WETH/USDT': 2000 + Math.random() * 100
      };

      return prices;
    } catch (error) {
      console.error('❌ Error collecting DEX prices:', error.message);
      return {};
    }
  }

  calculateGapMetrics(blockchainData, dexPrices) {
    // Simulate GAP calculation algorithm
    const priceGap = Math.random() * 5;
    const depthGap = Math.random() * 10;
    const latencyGap = Math.random() * 50;
    const riskGap = Math.random() * 20;
    const roiNet = Math.random() * 2;
    const collisionProb = Math.random() * 0.5;
    const decisionLatency = Math.random() * 200;

    // Calculate GAP Score (0-100)
    const gapScore = Math.min(100, 
      (priceGap * 20) + 
      (depthGap * 5) + 
      (latencyGap * 0.5) + 
      (riskGap * 2) + 
      (roiNet * 25)
    );

    return {
      gapScore,
      priceGap,
      depthGap,
      latencyGap,
      riskGap,
      roiNet,
      collisionProb,
      decisionLatency
    };
  }

  async simulateOpportunity(metrics) {
    // Simulate opportunity simulation
    const success = Math.random() > 0.3;
    const estimatedProfit = success ? metrics.roiNet * 1000 : 0;
    const gasCost = Math.random() * 50;

    return {
      success,
      estimatedProfit,
      gasCost,
      collisionProbability: metrics.collisionProb,
      errorMessage: success ? null : 'Simulation failed due to insufficient liquidity'
    };
  }

  async executeOpportunity(metrics, simulation) {
    // Simulate opportunity execution
    const bundleId = `bundle-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const success = Math.random() > 0.2;

    return {
      success,
      bundleId,
      profit: success ? simulation.estimatedProfit : 0,
      gasUsed: simulation.gasCost,
      timestamp: new Date()
    };
  }

  async startAuditor() {
    if (this.isRunning) return;

    this.isRunning = true;
    this.startTime = Date.now();
    console.log('🚀 GAP Auditor started');

    this.auditorInterval = setInterval(async () => {
      try {
        // Collect data
        const blockchainData = await this.collectBlockchainData();
        const dexPrices = await this.collectDexPrices();

        // Calculate metrics
        this.metrics = this.calculateGapMetrics(blockchainData, dexPrices);

        // Emit metrics update
        this.events.emit('metrics', this.metrics);

        // Check for opportunities
        if (this.metrics.gapScore >= this.config.minGapScore && 
            this.metrics.roiNet >= this.config.minRoiNet) {
          
          console.log(`🎯 Opportunity detected! GapScore: ${this.metrics.gapScore.toFixed(1)}, ROI: ${this.metrics.roiNet.toFixed(2)}%`);

          // Simulate opportunity
          const simulation = await this.simulateOpportunity(this.metrics);
          
          if (simulation.success) {
            console.log(`✅ Simulation successful - Profit: $${simulation.estimatedProfit.toFixed(2)}`);

            // Check collision probability
            if (simulation.collisionProbability <= this.config.maxCollisionProb) {
              console.log('🚀 Executing opportunity...');
              
              const execution = await this.executeOpportunity(this.metrics, simulation);
              
              if (execution.success) {
                console.log(`✅ Execution successful - Bundle ID: ${execution.bundleId}`);
              } else {
                console.log('❌ Execution failed');
              }
            } else {
              console.log(`⚠️ Collision probability too high: ${(simulation.collisionProbability * 100).toFixed(1)}%`);
            }
          } else {
            console.log(`⚠️ Simulation failed: ${simulation.errorMessage}`);
          }

          // Create event
          const event = {
            id: `gap-${Date.now()}`,
            timestamp: new Date(),
            gapScore: this.metrics.gapScore,
            priceGap: this.metrics.priceGap,
            depthGap: this.metrics.depthGap,
            latencyGap: this.metrics.latencyGap,
            riskGap: this.metrics.riskGap,
            roiNet: this.metrics.roiNet,
            collisionProb: this.metrics.collisionProb,
            status: simulation.success ? 'simulated' : 'failed',
            route: ['Uniswap V3', 'Balancer', 'Curve'],
            blockchains: ['Ethereum', 'Polygon'],
            estimatedProfit: simulation.estimatedProfit,
            gasCost: simulation.gasCost,
            mempoolStatus: 'synchronized'
          };

          this.eventsList.unshift(event);
          this.eventsList = this.eventsList.slice(0, 100); // Keep last 100 events
          
          this.events.emit('event', event);
        }

        // Update node statuses
        this.nodeStatuses = this.nodeStatuses.map(node => ({
          ...node,
          blockNumber: node.blockNumber + Math.floor(Math.random() * 10),
          gasPrice: node.gasPrice + (Math.random() - 0.5) * 5,
          pendingTxs: Math.max(0, node.pendingTxs + (Math.random() - 0.5) * 20),
          lastUpdate: new Date()
        }));

      } catch (error) {
        console.error('❌ Error in auditor loop:', error.message);
      }
    }, this.config.collectionInterval);
  }

  stopAuditor() {
    if (!this.isRunning) return;

    this.isRunning = false;
    if (this.auditorInterval) {
      clearInterval(this.auditorInterval);
    }
    console.log('⏹️ GAP Auditor stopped');
  }

  start() {
    try {
      console.log(`🚀 Iniciando GAP Auditor Server en puerto ${this.port}...`);
      
      const server = this.app.listen(this.port, () => {
        console.log(`✅ GAP Auditor Server iniciado exitosamente en puerto ${this.port}`);
        console.log(`📊 API disponible en http://localhost:${this.port}/api`);
        console.log(`📡 SSE stream en http://localhost:${this.port}/api/contracts/stream`);
        console.log(`🔗 Frontend debe conectar a: http://localhost:${this.port}`);
        
        // Inicializar servicios después de que el servidor esté listo
        this.initializeWeb3();
        this.startAuditor();
      });

      // Manejo de errores del servidor
      server.on('error', (error) => {
        if (error.code === 'EADDRINUSE') {
          console.error(`❌ Error: Puerto ${this.port} ya está en uso`);
          console.log(`💡 Intenta usar otro puerto o detén el servicio que use el puerto ${this.port}`);
        } else {
          console.error('❌ Error del servidor:', error.message);
        }
        process.exit(1);
      });

      // Manejo de conexiones
      server.on('connection', (socket) => {
        console.log(`🔌 Nueva conexión desde ${socket.remoteAddress}:${socket.remotePort}`);
      });

      // Graceful shutdown
      process.on('SIGTERM', () => {
        console.log('🛑 Recibida señal SIGTERM, cerrando servidor...');
        server.close(() => {
          console.log('✅ Servidor cerrado correctamente');
          process.exit(0);
        });
      });

      process.on('SIGINT', () => {
        console.log('🛑 Recibida señal SIGINT, cerrando servidor...');
        server.close(() => {
          console.log('✅ Servidor cerrado correctamente');
          process.exit(0);
        });
      });

    } catch (error) {
      console.error('❌ Error crítico al iniciar servidor:', error);
      process.exit(1);
    }
  }

  setupMonitoringServices() {
    console.log('📊 Configurando servicios de monitoreo...');
    
    // Agregar endpoints para métricas
    this.app.get('/api/metrics/performance', (req, res) => {
      try {
        // Simular métricas de performance básicas
        const metrics = {
          timestamp: Date.now(),
          uptime: process.uptime(),
          performance: {
            cpuUsage: Math.random() * 50 + 20, // 20-70%
            memoryUsage: {
              used: process.memoryUsage().heapUsed,
              total: process.memoryUsage().heapTotal,
              percentage: (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100
            },
            avgResponseTime: Math.random() * 200 + 50, // 50-250ms
            errorRate: Math.random() * 5, // 0-5%
            throughput: Math.random() * 100 + 50 // 50-150 req/s
          },
          health: {
            rpcConnections: [
              { name: 'Ethereum', status: 'healthy', latency: Math.random() * 100 + 50 },
              { name: 'BSC', status: 'healthy', latency: Math.random() * 100 + 50 }
            ],
            databaseStatus: 'healthy',
            apiStatus: 'healthy'
          }
        };
        
        res.json(metrics);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    this.app.get('/api/metrics/financial', (req, res) => {
      try {
        const financialMetrics = {
          dailyProfit: Math.random() * 1000 - 200, // -200 a 800
          totalTrades: Math.floor(Math.random() * 50),
          successRate: Math.random() * 30 + 70, // 70-100%
          averageProfit: Math.random() * 50 + 10,
          portfolioValue: 10000 + Math.random() * 5000,
          totalROI: Math.random() * 20 + 5 // 5-25%
        };
        
        res.json(financialMetrics);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    this.app.get('/api/alerts', (req, res) => {
      try {
        const alerts = [
          // Ejemplo de alertas del sistema
          {
            id: `alert_${Date.now()}`,
            severity: 'medium',
            message: 'Sistema funcionando normalmente',
            timestamp: Date.now(),
            resolved: true
          }
        ];
        
        res.json(alerts);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });
    
    console.log('✅ Endpoints de monitoreo configurados');
  }
}

// Start server
const server = new GapAuditorServer();
server.start();

export default GapAuditorServer; 