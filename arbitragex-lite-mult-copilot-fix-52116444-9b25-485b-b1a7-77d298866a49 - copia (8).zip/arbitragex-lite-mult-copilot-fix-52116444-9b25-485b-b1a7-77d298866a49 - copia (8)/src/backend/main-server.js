const BlockchainStreamServer = require('./blockchain-stream-server');
const ConfigSyncService = require('./config-sync-service');
const express = require('express');
const cors = require('cors');
const path = require('path');

class MainServer {
    constructor() {
        this.port = 3001;
        this.app = express();
        this.blockchainServer = new BlockchainStreamServer(this.port);
        this.configSyncService = new ConfigSyncService(this.blockchainServer);
        
        this.setupMiddleware();
        this.setupRoutes();
        this.start();
    }

    setupMiddleware() {
        this.app.use(cors());
        this.app.use(express.json());
        this.app.use(express.static(path.join(__dirname, '../../frontend')));
    }

    setupRoutes() {
        // Endpoint para recibir cambios desde config.html
        this.app.post('/api/config/update', async (req, res) => {
            try {
                const { blockchain, rpcUrl, enabled } = req.body;
                console.log(`📝 Configuración recibida desde config.html:`, { blockchain, rpcUrl, enabled });
                
                if (!blockchain || !rpcUrl) {
                    return res.status(400).json({
                        success: false,
                        message: 'Blockchain y RPC URL son requeridos'
                    });
                }

                // Validar conexión RPC en tiempo real
                const isConnected = await this.blockchainServer.testBlockchainConnection(rpcUrl);
                const latency = await this.blockchainServer.measureLatency(rpcUrl);
                
                // Actualizar estado en el servidor blockchain
                this.blockchainServer.blockchainStatus[blockchain] = {
                    name: this.blockchainServer.getBlockchainDisplayName(blockchain),
                    connected: isConnected && enabled,
                    rpc: rpcUrl,
                    status: isConnected && enabled ? 'active' : 'inactive',
                    lastTested: Date.now(),
                    latency: latency,
                    lastUpdated: Date.now()
                };

                console.log(`✅ Estado actualizado para ${blockchain}:`, this.blockchainServer.blockchainStatus[blockchain]);

                // Notificar a todos los clientes (index.html)
                this.blockchainServer.broadcastUpdate();

                res.json({
                    success: true,
                    data: this.blockchainServer.blockchainStatus[blockchain],
                    message: `Blockchain ${blockchain} configurada exitosamente`,
                    connected: isConnected,
                    latency: latency
                });

            } catch (error) {
                console.error('Error procesando configuración:', error);
                res.status(500).json({
                    success: false,
                    message: 'Error interno del servidor'
                });
            }
        });

        // Endpoint para obtener estado completo
        this.app.get('/api/status', (req, res) => {
            res.json({
                success: true,
                data: {
                    blockchains: this.blockchainServer.blockchainStatus,
                    serverTime: Date.now(),
                    activeConnections: this.blockchainServer.clients.size
                }
            });
        });

        // Endpoint para test de conexión desde config.html
        this.app.post('/api/blockchain/test-connection', async (req, res) => {
            try {
                const { rpcUrl } = req.body;
                console.log(`🧪 Test de conexión solicitado para: ${rpcUrl}`);
                
                const isConnected = await this.blockchainServer.testBlockchainConnection(rpcUrl);
                const latency = await this.blockchainServer.measureLatency(rpcUrl);
                
                res.json({
                    success: true,
                    connected: isConnected,
                    latency: latency,
                    timestamp: Date.now()
                });

            } catch (error) {
                console.error('Error en test de conexión:', error);
                res.status(500).json({
                    success: false,
                    message: 'Error en test de conexión'
                });
            }
        });

        // Endpoint para agregar nueva blockchain personalizada
        this.app.post('/api/blockchain/custom', async (req, res) => {
            try {
                const { name, symbol, chainId, rpcUrl, explorerUrl, nativeCurrency } = req.body;
                console.log(`🆕 Nueva blockchain personalizada:`, { name, symbol, chainId, rpcUrl });
                
                if (!name || !symbol || !rpcUrl) {
                    return res.status(400).json({
                        success: false,
                        message: 'Nombre, símbolo y RPC URL son requeridos'
                    });
                }

                // Validar conexión
                const isConnected = await this.blockchainServer.testBlockchainConnection(rpcUrl);
                const latency = await this.blockchainServer.measureLatency(rpcUrl);
                
                // Crear clave única
                const blockchainKey = `custom_${symbol.toLowerCase()}`;
                
                // Almacenar en el servidor
                this.blockchainServer.blockchainStatus[blockchainKey] = {
                    name: `${name} (${symbol})`,
                    connected: isConnected,
                    rpc: rpcUrl,
                    status: isConnected ? 'active' : 'inactive',
                    lastTested: Date.now(),
                    latency: latency,
                    lastUpdated: Date.now(),
                    custom: true,
                    metadata: {
                        chainId,
                        explorerUrl,
                        nativeCurrency
                    }
                };

                console.log(`✅ Blockchain personalizada agregada:`, blockchainKey);

                // Notificar a clientes
                this.blockchainServer.broadcastUpdate();

                res.json({
                    success: true,
                    data: this.blockchainServer.blockchainStatus[blockchainKey],
                    message: `Blockchain personalizada ${name} agregada exitosamente`
                });

            } catch (error) {
                console.error('Error agregando blockchain personalizada:', error);
                res.status(500).json({
                    success: false,
                    message: 'Error interno del servidor'
                });
            }
        });

        // Endpoint para eliminar blockchain personalizada
        this.app.delete('/api/blockchain/custom/:symbol', (req, res) => {
            try {
                const { symbol } = req.params;
                const blockchainKey = `custom_${symbol.toLowerCase()}`;
                
                if (this.blockchainServer.blockchainStatus[blockchainKey]) {
                    delete this.blockchainServer.blockchainStatus[blockchainKey];
                    console.log(`🗑️ Blockchain personalizada eliminada:`, blockchainKey);
                    
                    // Notificar a clientes
                    this.blockchainServer.broadcastUpdate();
                    
                    res.json({
                        success: true,
                        message: `Blockchain ${symbol} eliminada exitosamente`
                    });
                } else {
                    res.status(404).json({
                        success: false,
                        message: 'Blockchain no encontrada'
                    });
                }

            } catch (error) {
                console.error('Error eliminando blockchain:', error);
                res.status(500).json({
                    success: false,
                    message: 'Error interno del servidor'
                });
            }
        });
    }

    start() {
        this.app.listen(this.port, () => {
            console.log(`🚀 Servidor Principal iniciado en puerto ${this.port}`);
            console.log(`📡 WebSocket disponible en ws://localhost:${this.port}`);
            console.log(`🌐 API REST disponible en http://localhost:${this.port}`);
            console.log(`📊 Streaming SSE disponible en http://localhost:${this.port}/blockchain-stream`);
            console.log(`🔧 Configuración desde config.html → Backend → index.html`);
        });
    }
}

module.exports = MainServer;

// Iniciar servidor si se ejecuta directamente
if (require.main === module) {
    const server = new MainServer();
}
