/**
 * Sistema de Registry Principal para ArbitrageX Pro 2025
 * Maneja el registro, consulta y orquestación de features
 */

export interface Feature {
  id: string;
  name: string;
  description?: string;
  component?: string;
  path?: string;
  slot: string;
  placement: {
    size?: string;
    priority?: number;
    requiresAuth?: boolean;
    isMainPage?: boolean;
  };
  dataDeps: {
    apis?: string[];
    sseEvents?: string[];
    realTimeData?: string[];
  };
  permissions: {
    accessLevel?: string;
    roles?: string[];
  };
  category?: string;
  enabled?: boolean;
  metadata?: any;
}

// Registry global de features
let globalFeatures: Feature[] = [];
let subscribers: Set<() => void> = new Set();

/**
 * Registra una lista de features en el registry global
 */
export function registerFeatures(features: Feature[]): void {
  // Evitar duplicados por ID
  const existingIds = new Set(globalFeatures.map(f => f.id));
  const newFeatures = features.filter(f => !existingIds.has(f.id));
  
  globalFeatures.push(...newFeatures);
  
  // Notificar a suscriptores
  notifySubscribers();
  
  console.log(`✅ ${newFeatures.length} nuevas features registradas (total: ${globalFeatures.length})`);
}

/**
 * Obtiene todas las features registradas
 */
export function getFeatures(): Feature[] {
  return [...globalFeatures];
}

/**
 * Obtiene features por slot específico
 */
export function getFeaturesBySlot(slot: string): Feature[] {
  return globalFeatures.filter(feature => 
    feature.slot === slot && feature.enabled !== false
  );
}

/**
 * Obtiene features por categoría
 */
export function getFeaturesByCategory(category: string): Feature[] {
  return globalFeatures.filter(feature => 
    feature.category === category && feature.enabled !== false
  );
}

/**
 * Obtiene una feature por ID
 */
export function getFeatureById(id: string): Feature | undefined {
  return globalFeatures.find(feature => feature.id === id);
}

/**
 * Obtiene features habilitadas
 */
export function getEnabledFeatures(): Feature[] {
  return globalFeatures.filter(feature => feature.enabled !== false);
}

/**
 * Obtiene features que requieren datos en tiempo real
 */
export function getFeaturesWithRealTimeData(): Feature[] {
  return globalFeatures.filter(feature => 
    feature.dataDeps.realTimeData && 
    feature.dataDeps.realTimeData.length > 0 &&
    feature.enabled !== false
  );
}

/**
 * Obtiene features principales (páginas principales)
 */
export function getMainPageFeatures(): Feature[] {
  return globalFeatures.filter(feature => 
    feature.placement.isMainPage && feature.enabled !== false
  );
}

/**
 * Obtiene features por nivel de permisos
 */
export function getFeaturesByPermissionLevel(level: string): Feature[] {
  return globalFeatures.filter(feature => 
    feature.permissions.accessLevel === level && feature.enabled !== false
  );
}

/**
 * Filtra features por permisos de usuario
 */
export function getAvailableFeatures(userPermissions?: {
  roles?: string[];
  accessLevel?: string;
}): Feature[] {
  if (!userPermissions) {
    return getFeaturesByPermissionLevel('public');
  }

  return globalFeatures.filter(feature => {
    if (feature.enabled === false) return false;

    const featureLevel = feature.permissions.accessLevel || 'public';
    const userLevel = userPermissions.accessLevel || 'public';

    // Verificar nivel de acceso
    const levelHierarchy = ['public', 'authenticated', 'admin', 'superadmin'];
    const userLevelIndex = levelHierarchy.indexOf(userLevel);
    const featureLevelIndex = levelHierarchy.indexOf(featureLevel);

    if (userLevelIndex < featureLevelIndex) return false;

    // Verificar roles específicos
    if (feature.permissions.roles && feature.permissions.roles.length > 0) {
      const userRoles = userPermissions.roles || [];
      return feature.permissions.roles.some(role => userRoles.includes(role));
    }

    return true;
  });
}

/**
 * Busca features por texto
 */
export function searchFeatures(query: string): Feature[] {
  const lowerQuery = query.toLowerCase();
  
  return globalFeatures.filter(feature => {
    if (feature.enabled === false) return false;
    
    const searchableText = [
      feature.name,
      feature.description,
      feature.category,
      feature.path,
      ...(feature.metadata?.keywords || [])
    ].join(' ').toLowerCase();
    
    return searchableText.includes(lowerQuery);
  });
}

/**
 * Obtiene estadísticas del registry
 */
export function getRegistryStats() {
  const features = getEnabledFeatures();
  
  const bySlot = features.reduce((acc, f) => {
    acc[f.slot] = (acc[f.slot] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const byCategory = features.reduce((acc, f) => {
    acc[f.category || 'other'] = (acc[f.category || 'other'] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const withRealTimeData = getFeaturesWithRealTimeData().length;
  const mainPages = getMainPageFeatures().length;

  return {
    total: features.length,
    bySlot,
    byCategory,
    withRealTimeData,
    mainPages,
    lastUpdated: new Date().toISOString()
  };
}

/**
 * Suscribirse a cambios en el registry
 */
export function subscribeToRegistry(callback: () => void): () => void {
  subscribers.add(callback);
  
  // Retornar función de desuscripción
  return () => {
    subscribers.delete(callback);
  };
}

/**
 * Notificar a todos los suscriptores
 */
function notifySubscribers(): void {
  subscribers.forEach(callback => {
    try {
      callback();
    } catch (error) {
      console.error('Error en callback de registry:', error);
    }
  });
}

/**
 * Limpiar el registry (útil para testing)
 */
export function clearRegistry(): void {
  globalFeatures = [];
  notifySubscribers();
}

/**
 * Habilitar/deshabilitar una feature
 */
export function toggleFeature(id: string, enabled?: boolean): boolean {
  const feature = getFeatureById(id);
  if (!feature) return false;

  feature.enabled = enabled !== undefined ? enabled : !feature.enabled;
  notifySubscribers();
  
  return true;
}

/**
 * Actualizar una feature existente
 */
export function updateFeature(id: string, updates: Partial<Feature>): boolean {
  const featureIndex = globalFeatures.findIndex(f => f.id === id);
  if (featureIndex === -1) return false;

  globalFeatures[featureIndex] = {
    ...globalFeatures[featureIndex],
    ...updates,
    id // Mantener ID original
  };

  notifySubscribers();
  return true;
}

// Exportar para debugging
export function _getGlobalFeatures() {
  return globalFeatures;
}

export function _getSubscribers() {
  return subscribers;
}
