/**
 * Registro automático de features para ArbitrageX Pro 2025
 * Importa y registra todas las features auto-detectadas
 */

import { registerFeatures } from '../registry';
import { autoFeatures } from './registry.generated';

/**
 * Registra todas las features auto-detectadas
 */
export function registerAutoFeatures(): void {
  console.log('🚀 Registrando features auto-detectadas...');
  
  try {
    registerFeatures(autoFeatures);
    
    console.log(`✅ ${autoFeatures.length} features auto-detectadas registradas`);
    
    // Log de estadísticas por slot
    const bySlot = autoFeatures.reduce((acc, f) => {
      acc[f.slot] = (acc[f.slot] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    console.log('📊 Distribución por slots:', bySlot);
    
    // Log de features con datos en tiempo real
    const withRealTimeData = autoFeatures.filter(f => 
      f.dataDeps.realTimeData && f.dataDeps.realTimeData.length > 0
    );
    
    if (withRealTimeData.length > 0) {
      console.log(`⚡ ${withRealTimeData.length} features con datos en tiempo real detectadas`);
    }
    
    // Log de features principales
    const mainPages = autoFeatures.filter(f => f.placement.isMainPage);
    if (mainPages.length > 0) {
      console.log(`🏠 ${mainPages.length} páginas principales detectadas`);
    }
    
  } catch (error) {
    console.error('❌ Error registrando features auto-detectadas:', error);
    throw error;
  }
}

/**
 * Obtiene información sobre las features auto-detectadas
 */
export function getAutoFeaturesInfo() {
  return {
    total: autoFeatures.length,
    bySlot: autoFeatures.reduce((acc, f) => {
      acc[f.slot] = (acc[f.slot] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    byCategory: autoFeatures.reduce((acc, f) => {
      acc[f.category || 'other'] = (acc[f.category || 'other'] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    withRealTimeData: autoFeatures.filter(f => 
      f.dataDeps.realTimeData && f.dataDeps.realTimeData.length > 0
    ).length,
    mainPages: autoFeatures.filter(f => f.placement.isMainPage).length,
    requiresAuth: autoFeatures.filter(f => f.permissions.requiresAuth).length,
    apis: [...new Set(autoFeatures.flatMap(f => f.dataDeps.apis || []))].length
  };
}

// Registrar automáticamente al importar (si está en el browser)
if (typeof window !== 'undefined') {
  // Registrar después de que el DOM esté listo
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', registerAutoFeatures);
  } else {
    // DOM ya está listo
    setTimeout(registerAutoFeatures, 0);
  }
}
