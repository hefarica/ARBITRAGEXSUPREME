/**
 * Feature Registry Auto-generado para ArbitrageX Pro 2025
 * ⚠️ NO EDITAR MANUALMENTE - Se regenera automáticamente
 * 
 * Generado: 2025-08-09T13:42:21.301Z
 * Hash: a91f0a55dbde1b39c833852508428fef
 * Features: 140
 */

// Features auto-detectadas
export const autoFeatures = [
  {
    "id": "page-audit",
    "name": "Audit",
    "description": "AuditDashboard.tsx - Dashboard de Auditoría Zero-Mock Data",
    "component": "src\\components\\audit\\AuditDashboard.tsx",
    "path": "/audit",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {
      "apis": [
        "/api/metrics",
        "/api/health"
      ],
      "realTimeData": [
        "gap-metrics",
        "real-time-audit"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-keylessgapauditor",
    "name": "Keylessgapauditor",
    "description": "eth-mainnet.g.alchemy.com/v2/demo',",
    "component": "src\\components\\audit\\KeylessGapAuditor.tsx",
    "path": "/keylessgapauditor",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {
      "apis": [
        "/api/metrics",
        "/api/health"
      ],
      "realTimeData": [
        "gap-metrics",
        "real-time-audit"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-mockdataauditpanel",
    "name": "Mockdataauditpanel",
    "description": "Real-time audit data fetching",
    "component": "src\\components\\audit\\MockDataAuditPanel.tsx",
    "path": "/mockdataauditpanel",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {
      "apis": [
        "/api/metrics",
        "/api/health"
      ],
      "realTimeData": [
        "gap-metrics",
        "real-time-audit"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-arbitrage",
    "name": "Arbitrage",
    "description": "State management",
    "component": "src\\components\\dashboard\\ArbitrageDashboard.tsx",
    "path": "/arbitrage",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 20
    },
    "dataDeps": {
      "apis": [
        "/api/arbitrage/opportunities",
        "/api/arbitrage/execute",
        "/health",
        "/api/metrics",
        "/api/events",
        "/api/nodes",
        "/api/config",
        "/api/config",
        "/api/start",
        "/api/stop",
        "/api/status",
        "/api/stream",
        "/api/metrics/performance",
        "/api/metrics/financial",
        "/api/alerts"
      ],
      "realTimeData": [
        "prices",
        "opportunities"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "arbitrage",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-unifiedintelligent",
    "name": "Unifiedintelligent",
    "description": "Estados principales",
    "component": "src\\components\\dashboard\\UnifiedIntelligentDashboard.tsx",
    "path": "/unifiedintelligent",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-advancedllmmodule",
    "name": "Advancedllmmodule",
    "description": "Simulate AI response - in production this would connect to real LLM API",
    "component": "src\\components\\modules\\AdvancedLLMModule.tsx",
    "path": "/advancedllmmodule",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-advancedmevprotection",
    "name": "Advancedmevprotection",
    "description": "Página Advancedmevprotection",
    "component": "src\\components\\modules\\AdvancedMEVProtection.tsx",
    "path": "/advancedmevprotection",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-advancedsecuritycenter",
    "name": "Advancedsecuritycenter",
    "description": "Página Advancedsecuritycenter",
    "component": "src\\components\\modules\\AdvancedSecurityCenter.tsx",
    "path": "/advancedsecuritycenter",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "security",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-autoexecutioncontroller",
    "name": "Autoexecutioncontroller",
    "description": "Página Autoexecutioncontroller",
    "component": "src\\components\\modules\\AutoExecutionController.tsx",
    "path": "/autoexecutioncontroller",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-enhancedmainmodule",
    "name": "Enhancedmainmodule",
    "description": "Simulated real-time metrics",
    "component": "src\\components\\modules\\EnhancedMainModule.tsx",
    "path": "/enhancedmainmodule",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {
      "apis": [
        "/api/metrics",
        "/api/metrics/performance",
        "/api/metrics/financial"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-enhancedmonitoringhub",
    "name": "Enhancedmonitoringhub",
    "description": "Página Enhancedmonitoringhub",
    "component": "src\\components\\modules\\EnhancedMonitoringHub.tsx",
    "path": "/enhancedmonitoringhub",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 30
    },
    "dataDeps": {
      "apis": [
        "/api/metrics",
        "/api/status"
      ],
      "sseEvents": [
        "metrics-update"
      ],
      "realTimeData": [
        "system-metrics",
        "live-data"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-intelligentconfigcenter",
    "name": "Intelligentconfigcenter",
    "description": "Página Intelligentconfigcenter",
    "component": "src\\components\\modules\\IntelligentConfigCenter.tsx",
    "path": "/intelligentconfigcenter",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-intelligentriskmodule",
    "name": "Intelligentriskmodule",
    "description": "Página Intelligentriskmodule",
    "component": "src\\components\\modules\\IntelligentRiskModule.tsx",
    "path": "/intelligentriskmodule",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-mlinsightsengine",
    "name": "Mlinsightsengine",
    "description": "Página Mlinsightsengine",
    "component": "src\\components\\modules\\MLInsightsEngine.tsx",
    "path": "/mlinsightsengine",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-multichainmanagerpro",
    "name": "Multichainmanagerpro",
    "description": "Página Multichainmanagerpro",
    "component": "src\\components\\modules\\MultiChainManagerPro.tsx",
    "path": "/multichainmanagerpro",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-sentimenttradingengine",
    "name": "Sentimenttradingengine",
    "description": "Página Sentimenttradingengine",
    "component": "src\\components\\modules\\SentimentTradingEngine.tsx",
    "path": "/sentimenttradingengine",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-smartarbitrageengine",
    "name": "Smartarbitrageengine",
    "description": "Simulate real-time opportunity detection",
    "component": "src\\components\\modules\\SmartArbitrageEngine.tsx",
    "path": "/smartarbitrageengine",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 20
    },
    "dataDeps": {
      "apis": [
        "/api/arbitrage/opportunities",
        "/api/arbitrage/execute",
        "/health",
        "/api/metrics",
        "/api/events",
        "/api/nodes",
        "/api/config",
        "/api/config",
        "/api/start",
        "/api/stop",
        "/api/status",
        "/api/stream",
        "/api/metrics/performance",
        "/api/metrics/financial",
        "/api/alerts"
      ],
      "realTimeData": [
        "prices",
        "opportunities"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "arbitrage",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-smartliquiditytracker",
    "name": "Smartliquiditytracker",
    "description": "Página Smartliquiditytracker",
    "component": "src\\components\\modules\\SmartLiquidityTracker.tsx",
    "path": "/smartliquiditytracker",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-ultralowlatencyengine",
    "name": "Ultralowlatencyengine",
    "description": "Página Ultralowlatencyengine",
    "component": "src\\components\\modules\\UltraLowLatencyEngine.tsx",
    "path": "/ultralowlatencyengine",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-realtimemonitoring",
    "name": "Realtimemonitoring",
    "description": "RealTimeMonitoringDashboard.tsx",
    "component": "src\\components\\monitoring\\RealTimeMonitoringDashboard.tsx",
    "path": "/realtimemonitoring",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 30
    },
    "dataDeps": {
      "apis": [
        "/api/metrics",
        "/api/status"
      ],
      "sseEvents": [
        "metrics-update"
      ],
      "realTimeData": [
        "system-metrics",
        "live-data"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-securitycontrolcenter",
    "name": "Securitycontrolcenter",
    "description": "Página Securitycontrolcenter",
    "component": "src\\components\\panels\\SecurityControlCenter.tsx",
    "path": "/securitycontrolcenter",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "security",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-unifiedcommandcenter",
    "name": "Unifiedcommandcenter",
    "description": "import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from 'recharts'",
    "component": "src\\components\\panels\\UnifiedCommandCenter.tsx",
    "path": "/unifiedcommandcenter",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-moad",
    "name": "Moad",
    "description": "MOAD Dashboard - Módulo de Oportunidades de Arbitraje DeFi",
    "component": "src\\components\\revenue\\MOADDashboard.tsx",
    "path": "/moad",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-riskmanagementcontrol",
    "name": "Riskmanagementcontrol",
    "description": "Página Riskmanagementcontrol",
    "component": "src\\components\\risk\\RiskManagementControl.tsx",
    "path": "/riskmanagementcontrol",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-securitycontrolpanel",
    "name": "Securitycontrolpanel",
    "description": "Persistent security configuration",
    "component": "src\\components\\security\\SecurityControlPanel.tsx",
    "path": "/securitycontrolpanel",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "security",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-truthguardstatus",
    "name": "Truthguardstatus",
    "description": "Determine overall system health",
    "component": "src\\components\\status\\TruthGuardStatus.tsx",
    "path": "/truthguardstatus",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {
      "apis": [
        "/health",
        "/api/status"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-specialstrategiesbrochure",
    "name": "Specialstrategiesbrochure",
    "description": "Página Specialstrategiesbrochure",
    "component": "src\\components\\strategy\\SpecialStrategiesBrochure.tsx",
    "path": "/specialstrategiesbrochure",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-unifiedspecialstrategies",
    "name": "Unifiedspecialstrategies",
    "description": "Estrategias Básicas + Especiales Unificadas",
    "component": "src\\components\\strategy\\UnifiedSpecialStrategies.tsx",
    "path": "/unifiedspecialstrategies",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-systemvalidation",
    "name": "Systemvalidation",
    "description": "Configuration states from KV",
    "component": "src\\components\\validation\\SystemValidation.tsx",
    "path": "/systemvalidation",
    "slot": "workspace",
    "placement": {
      "size": "md",
      "requiresAuth": false,
      "isMainPage": false,
      "priority": 50
    },
    "dataDeps": {
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "component"
    }
  },
  {
    "id": "page-home",
    "name": "Home",
    "description": "Command Palette",
    "component": "src/App.tsx",
    "path": "/",
    "slot": "workspace",
    "placement": {
      "size": "full",
      "requiresAuth": false,
      "isMainPage": true,
      "priority": 10
    },
    "dataDeps": {
      "apis": [
        "/api/metrics",
        "/api/status"
      ],
      "sseEvents": [
        "metrics-update"
      ],
      "realTimeData": [
        "system-metrics",
        "live-data"
      ]
    },
    "permissions": {
      "accessLevel": "public"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "page",
      "routerType": "main"
    }
  },
  {
    "id": "advancedanalyticsdashboard-src\\components\\analytics\\AdvancedAnalyticsDashboard",
    "name": "AdvancedAnalyticsDashboard",
    "description": "Calculate comprehensive metrics",
    "component": "src\\components\\analytics\\AdvancedAnalyticsDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/metrics",
        "/api/metrics/performance",
        "/api/metrics/financial"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "analytics-src\\components\\analytics\\Analytics",
    "name": "Analytics",
    "description": "Calculate analytics",
    "component": "src\\components\\analytics\\Analytics.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "marketanalysisdashboard-src\\components\\analytics\\MarketAnalysisDashboard",
    "name": "MarketAnalysisDashboard",
    "description": "Simulated real-time opportunities",
    "component": "src\\components\\analytics\\MarketAnalysisDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "predictiveanalytics2025-src\\components\\analytics\\PredictiveAnalytics2025",
    "name": "PredictiveAnalytics2025",
    "description": "Simulación de datos en tiempo real",
    "component": "src\\components\\analytics\\PredictiveAnalytics2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "auditdashboard-src\\components\\audit\\AuditDashboard",
    "name": "AuditDashboard",
    "description": "AuditDashboard.tsx - Dashboard de Auditoría Zero-Mock Data",
    "component": "src\\components\\audit\\AuditDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "automatedauditrunner-src\\components\\audit\\AutomatedAuditRunner",
    "name": "AutomatedAuditRunner",
    "description": "Infrastructure Scripts",
    "component": "src\\components\\audit\\AutomatedAuditRunner.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "certificationreport-src\\components\\audit\\CertificationReport",
    "name": "CertificationReport",
    "description": "Mock certification data - in real implementation, this would come from the audit system",
    "component": "src\\components\\audit\\CertificationReport.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "compliancechecks-src\\components\\audit\\ComplianceChecks",
    "name": "ComplianceChecks",
    "description": "Pre-configured compliance checks for each audit section",
    "component": "src\\components\\audit\\ComplianceChecks.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "index-src\\components\\audit\\index",
    "name": "index",
    "description": "Widget index",
    "component": "src\\components\\audit\\index.ts",
    "slot": "workspace",
    "placement": {
      "slot": "workspace",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "keylessgapauditor-src\\components\\audit\\KeylessGapAuditor",
    "name": "KeylessGapAuditor",
    "description": "eth-mainnet.g.alchemy.com/v2/demo',",
    "component": "src\\components\\audit\\KeylessGapAuditor.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "apis": [
        "http://localhost:${backendPort}/health",
        "${apiBaseUrl}/metrics",
        "${apiBaseUrl}/events",
        "${apiBaseUrl}/nodes",
        "${apiBaseUrl}/config"
      ],
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "mockdataauditor-src\\components\\audit\\MockDataAuditor",
    "name": "MockDataAuditor",
    "description": "Simulated mock data patterns for demonstration",
    "component": "src\\components\\audit\\MockDataAuditor.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "mockdataauditpanel-src\\components\\audit\\MockDataAuditPanel",
    "name": "MockDataAuditPanel",
    "description": "Real-time audit data fetching",
    "component": "src\\components\\audit\\MockDataAuditPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "apis": [
        "/api/audit/mock-data",
        "/api/audit/mock-data"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "realtimegapauditor-src\\components\\audit\\RealTimeGapAuditor",
    "name": "RealTimeGapAuditor",
    "description": "URLs de documentación para cada servicio",
    "component": "src\\components\\audit\\RealTimeGapAuditor.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "systemstatusindicator-src\\components\\audit\\SystemStatusIndicator",
    "name": "SystemStatusIndicator",
    "description": "Widget SystemStatusIndicator",
    "component": "src\\components\\audit\\SystemStatusIndicator.tsx",
    "slot": "topbar",
    "placement": {
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "apis": [
        "/api/status"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "action"
    }
  },
  {
    "id": "charterrorboundary-src\\components\\charts\\ChartErrorBoundary",
    "name": "ChartErrorBoundary",
    "description": "Widget ChartErrorBoundary",
    "component": "src\\components\\charts\\ChartErrorBoundary.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "portfoliochart-src\\components\\charts\\PortfolioChart",
    "name": "PortfolioChart",
    "description": "Starting balance",
    "component": "src\\components\\charts\\PortfolioChart.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/start"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "profitlosschart-src\\components\\charts\\ProfitLossChart",
    "name": "ProfitLossChart",
    "description": "Group trades by day",
    "component": "src\\components\\charts\\ProfitLossChart.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "riskmetricschart-src\\components\\charts\\RiskMetricsChart",
    "name": "RiskMetricsChart",
    "description": "Sort trades chronologically",
    "component": "src\\components\\charts\\RiskMetricsChart.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/metrics",
        "/api/metrics/performance",
        "/api/metrics/financial"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "strategyallocationchart-src\\components\\charts\\StrategyAllocationChart",
    "name": "StrategyAllocationChart",
    "description": "Calculate total allocation by strategy type",
    "component": "src\\components\\charts\\StrategyAllocationChart.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "tradingvolumechart-src\\components\\charts\\TradingVolumeChart",
    "name": "TradingVolumeChart",
    "description": "Group trades by hour for recent activity, or by day for longer periods",
    "component": "src\\components\\charts\\TradingVolumeChart.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "commandpalette-src\\components\\CommandPalette",
    "name": "CommandPalette",
    "description": "Command Palette para ArbitrageX Pro 2025",
    "component": "src\\components\\CommandPalette.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {
      "apis": [
        "/api/health"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "configurationhub-src\\components\\configuration\\ConfigurationHub",
    "name": "ConfigurationHub",
    "description": "Persistent state management",
    "component": "src\\components\\configuration\\ConfigurationHub.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "credentialssetuppanel-src\\components\\configuration\\CredentialsSetupPanel",
    "name": "CredentialsSetupPanel",
    "description": "Blockchain RPCs",
    "component": "src\\components\\configuration\\CredentialsSetupPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "dynamicserviceform-src\\components\\configuration\\DynamicServiceForm",
    "name": "DynamicServiceForm",
    "description": "Auto-detect status based on required fields",
    "component": "src\\components\\configuration\\DynamicServiceForm.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/status"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "arbitragedashboard-src\\components\\dashboard\\ArbitrageDashboard",
    "name": "ArbitrageDashboard",
    "description": "State management",
    "component": "src\\components\\dashboard\\ArbitrageDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/health",
        "/api/metrics",
        "/api/events",
        "/api/nodes",
        "/api/config",
        "/api/config",
        "/api/start",
        "/api/stop",
        "/api/status",
        "/api/stream",
        "/api/metrics/performance",
        "/api/metrics/financial",
        "/api/alerts"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "arbitrage",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "dashboard-src\\components\\dashboard\\Dashboard",
    "name": "Dashboard",
    "description": "Simulate arbitrage opportunities",
    "component": "src\\components\\dashboard\\Dashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "intelligentdashboard2025-src\\components\\dashboard\\IntelligentDashboard2025",
    "name": "IntelligentDashboard2025",
    "description": "seconds",
    "component": "src\\components\\dashboard\\IntelligentDashboard2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "realtimeperformancedashboard-src\\components\\dashboard\\RealtimePerformanceDashboard",
    "name": "RealtimePerformanceDashboard",
    "description": "Update timestamp periodically",
    "component": "src\\components\\dashboard\\RealtimePerformanceDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/metrics/performance"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "unifiedintelligentdashboard-src\\components\\dashboard\\UnifiedIntelligentDashboard",
    "name": "UnifiedIntelligentDashboard",
    "description": "Estados principales",
    "component": "src\\components\\dashboard\\UnifiedIntelligentDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "learningcenter-src\\components\\learning\\LearningCenter",
    "name": "LearningCenter",
    "description": "Quiz completed",
    "component": "src\\components\\learning\\LearningCenter.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "advancedllmmodule-src\\components\\modules\\AdvancedLLMModule",
    "name": "AdvancedLLMModule",
    "description": "Simulate AI response - in production this would connect to real LLM API",
    "component": "src\\components\\modules\\AdvancedLLMModule.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "advancedmevprotection-src\\components\\modules\\AdvancedMEVProtection",
    "name": "AdvancedMEVProtection",
    "description": "Widget AdvancedMEVProtection",
    "component": "src\\components\\modules\\AdvancedMEVProtection.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "advancedsecuritycenter-src\\components\\modules\\AdvancedSecurityCenter",
    "name": "AdvancedSecurityCenter",
    "description": "Widget AdvancedSecurityCenter",
    "component": "src\\components\\modules\\AdvancedSecurityCenter.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "security",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "autoexecutioncontroller-src\\components\\modules\\AutoExecutionController",
    "name": "AutoExecutionController",
    "description": "Widget AutoExecutionController",
    "component": "src\\components\\modules\\AutoExecutionController.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "enhancedmainmodule-src\\components\\modules\\EnhancedMainModule",
    "name": "EnhancedMainModule",
    "description": "Simulated real-time metrics",
    "component": "src\\components\\modules\\EnhancedMainModule.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/metrics",
        "/api/metrics/performance",
        "/api/metrics/financial"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "enhancedmonitoringhub-src\\components\\modules\\EnhancedMonitoringHub",
    "name": "EnhancedMonitoringHub",
    "description": "Widget EnhancedMonitoringHub",
    "component": "src\\components\\modules\\EnhancedMonitoringHub.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "intelligentconfigcenter-src\\components\\modules\\IntelligentConfigCenter",
    "name": "IntelligentConfigCenter",
    "description": "Widget IntelligentConfigCenter",
    "component": "src\\components\\modules\\IntelligentConfigCenter.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "intelligentriskmodule-src\\components\\modules\\IntelligentRiskModule",
    "name": "IntelligentRiskModule",
    "description": "Widget IntelligentRiskModule",
    "component": "src\\components\\modules\\IntelligentRiskModule.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "mlinsightsengine-src\\components\\modules\\MLInsightsEngine",
    "name": "MLInsightsEngine",
    "description": "Widget MLInsightsEngine",
    "component": "src\\components\\modules\\MLInsightsEngine.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "arbitrageenginecard-src\\components\\modules\\moad\\ArbitrageEngineCard",
    "name": "ArbitrageEngineCard",
    "description": "ArbitrageX Pro 2 - Arbitrage Engine Card",
    "component": "src\\components\\modules\\moad\\ArbitrageEngineCard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 20,
      "size": "md"
    },
    "dataDeps": {
      "apis": [
        "/health",
        "/api/metrics",
        "/api/events",
        "/api/nodes",
        "/api/config",
        "/api/config",
        "/api/start",
        "/api/stop",
        "/api/status",
        "/api/stream",
        "/api/metrics/performance",
        "/api/metrics/financial",
        "/api/alerts"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "arbitrage",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "hftenginecard-src\\components\\modules\\moad\\HFTEngineCard",
    "name": "HFTEngineCard",
    "description": "ArbitrageX Pro 2 - HFT Engine Card",
    "component": "src\\components\\modules\\moad\\HFTEngineCard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "index-src\\components\\modules\\moad\\index",
    "name": "index",
    "description": "ArbitrageX Pro 2 - MOAD Index",
    "component": "src\\components\\modules\\moad\\index.ts",
    "slot": "workspace",
    "placement": {
      "slot": "workspace",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "moadcompletesystem-src\\components\\modules\\moad\\MOADCompleteSystem",
    "name": "MOADCompleteSystem",
    "description": "ArbitrageX Pro 2 - MOAD Complete System",
    "component": "src\\components\\modules\\moad\\MOADCompleteSystem.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "moadexecutivesummary-src\\components\\modules\\moad\\MOADExecutiveSummary",
    "name": "MOADExecutiveSummary",
    "description": "ArbitrageX Pro 2 - MOAD Executive Summary",
    "component": "src\\components\\modules\\moad\\MOADExecutiveSummary.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "moadstrategytesting-src\\components\\modules\\moad\\MOADStrategyTesting",
    "name": "MOADStrategyTesting",
    "description": "ArbitrageX Pro 2 - MOAD Strategy Testing",
    "component": "src\\components\\modules\\moad\\MOADStrategyTesting.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "notifier-src\\components\\modules\\moad\\notifier",
    "name": "notifier",
    "description": "ArbitrageX Pro 2 - MOAD System Notifier",
    "component": "src\\components\\modules\\moad\\notifier.ts",
    "slot": "workspace",
    "placement": {
      "slot": "workspace",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "opportunitiespanel-src\\components\\modules\\moad\\OpportunitiesPanel",
    "name": "OpportunitiesPanel",
    "description": "ArbitrageX Pro 2 - Opportunities Panel",
    "component": "src\\components\\modules\\moad\\OpportunitiesPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "revenuedashboard-src\\components\\modules\\moad\\RevenueDashboard",
    "name": "RevenueDashboard",
    "description": "ArbitrageX Pro 2 - Revenue Dashboard",
    "component": "src\\components\\modules\\moad\\RevenueDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "xl",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "action"
    }
  },
  {
    "id": "strategyselector-src\\components\\modules\\moad\\StrategySelector",
    "name": "StrategySelector",
    "description": "ArbitrageX Pro 2 - Strategy Selector",
    "component": "src\\components\\modules\\moad\\StrategySelector.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "multichainmanagerpro-src\\components\\modules\\MultiChainManagerPro",
    "name": "MultiChainManagerPro",
    "description": "Widget MultiChainManagerPro",
    "component": "src\\components\\modules\\MultiChainManagerPro.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "sentimenttradingengine-src\\components\\modules\\SentimentTradingEngine",
    "name": "SentimentTradingEngine",
    "description": "Widget SentimentTradingEngine",
    "component": "src\\components\\modules\\SentimentTradingEngine.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "smartarbitrageengine-src\\components\\modules\\SmartArbitrageEngine",
    "name": "SmartArbitrageEngine",
    "description": "Simulate real-time opportunity detection",
    "component": "src\\components\\modules\\SmartArbitrageEngine.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/health",
        "/api/metrics",
        "/api/events",
        "/api/nodes",
        "/api/config",
        "/api/config",
        "/api/start",
        "/api/stop",
        "/api/status",
        "/api/stream",
        "/api/metrics/performance",
        "/api/metrics/financial",
        "/api/alerts"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "arbitrage",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "smartliquiditytracker-src\\components\\modules\\SmartLiquidityTracker",
    "name": "SmartLiquidityTracker",
    "description": "Widget SmartLiquidityTracker",
    "component": "src\\components\\modules\\SmartLiquidityTracker.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "ultralowlatencyengine-src\\components\\modules\\UltraLowLatencyEngine",
    "name": "UltraLowLatencyEngine",
    "description": "Widget UltraLowLatencyEngine",
    "component": "src\\components\\modules\\UltraLowLatencyEngine.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "realtimemonitoringdashboard-src\\components\\monitoring\\RealTimeMonitoringDashboard",
    "name": "RealTimeMonitoringDashboard",
    "description": "RealTimeMonitoringDashboard.tsx",
    "component": "src\\components\\monitoring\\RealTimeMonitoringDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "apis": [
        "/api/metrics/performance",
        "/api/metrics/financial",
        "/api/alerts"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "sidebar-src\\components\\navigation\\Sidebar",
    "name": "Sidebar",
    "description": "Nuevos iconos para las funcionalidades 2025",
    "component": "src\\components\\navigation\\Sidebar.tsx",
    "slot": "sidebar",
    "placement": {
      "slot": "sidebar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "advancednotificationsystem2025-src\\components\\notifications\\AdvancedNotificationSystem2025",
    "name": "AdvancedNotificationSystem2025",
    "description": "Simulación de notificaciones en tiempo real",
    "component": "src\\components\\notifications\\AdvancedNotificationSystem2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "table"
    }
  },
  {
    "id": "discordnotificationconfig-src\\components\\notifications\\DiscordNotificationConfig",
    "name": "DiscordNotificationConfig",
    "description": "cdn.discordapp.com/attachments/123/bot-icon.png'",
    "component": "src\\components\\notifications\\DiscordNotificationConfig.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "notificationcenter-src\\components\\notifications\\NotificationCenter",
    "name": "NotificationCenter",
    "description": "Estadísticas del sistema",
    "component": "src\\components\\notifications\\NotificationCenter.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "action"
    }
  },
  {
    "id": "notificationhistory-src\\components\\notifications\\NotificationHistory",
    "name": "NotificationHistory",
    "description": "Aplicar filtros",
    "component": "src\\components\\notifications\\NotificationHistory.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "notificationpreferences-src\\components\\notifications\\NotificationPreferences",
    "name": "NotificationPreferences",
    "description": "Tipos de eventos disponibles con sus descripciones",
    "component": "src\\components\\notifications\\NotificationPreferences.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "realtimenotificationprovider-src\\components\\notifications\\RealTimeNotificationProvider",
    "name": "RealTimeNotificationProvider",
    "description": "Configuración",
    "component": "src\\components\\notifications\\RealTimeNotificationProvider.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "telegramnotificationconfig-src\\components\\notifications\\TelegramNotificationConfig",
    "name": "TelegramNotificationConfig",
    "description": "Cargar configuración existente",
    "component": "src\\components\\notifications\\TelegramNotificationConfig.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "apis": [
        "https://api.telegram.org/bot${telegramConfig.botToken}/getMe",
        "/api/config",
        "/api/config"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "types-src\\components\\notifications\\types",
    "name": "types",
    "description": "Tipos TypeScript para el sistema de notificaciones en tiempo real",
    "component": "src\\components\\notifications\\types.ts",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "gamifiedonboarding2025-src\\components\\onboarding\\GamifiedOnboarding2025",
    "name": "GamifiedOnboarding2025",
    "description": "minutes",
    "component": "src\\components\\onboarding\\GamifiedOnboarding2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "advancedautomationcenter-src\\components\\panels\\AdvancedAutomationCenter",
    "name": "AdvancedAutomationCenter",
    "description": "Mock data for demonstration",
    "component": "src\\components\\panels\\AdvancedAutomationCenter.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "advancedmevcontrolpanel2025-src\\components\\panels\\AdvancedMEVControlPanel2025",
    "name": "AdvancedMEVControlPanel2025",
    "description": "Actualizar cada 5 segundos",
    "component": "src\\components\\panels\\AdvancedMEVControlPanel2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "advancedstrategiespanel2025-src\\components\\panels\\AdvancedStrategiesPanel2025",
    "name": "AdvancedStrategiesPanel2025",
    "description": "Actualizar cada 5 segundos",
    "component": "src\\components\\panels\\AdvancedStrategiesPanel2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "auditcompliancecenter-src\\components\\panels\\AuditComplianceCenter",
    "name": "AuditComplianceCenter",
    "description": "Widget AuditComplianceCenter",
    "component": "src\\components\\panels\\AuditComplianceCenter.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "autonomouscontrolpanel2025-src\\components\\panels\\AutonomousControlPanel2025",
    "name": "AutonomousControlPanel2025",
    "description": "Actualizar cada 5 segundos",
    "component": "src\\components\\panels\\AutonomousControlPanel2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "crosschainaiorchestrator-src\\components\\panels\\CrossChainAIOrchestrator",
    "name": "CrossChainAIOrchestrator",
    "description": "Mock data for demonstration",
    "component": "src\\components\\panels\\CrossChainAIOrchestrator.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "moadpanel-src\\components\\panels\\MOADPanel",
    "name": "MOADPanel",
    "description": "MÓDULO DE OPORTUNIDADES DE ARBITRAJE DeFi (MOAD)",
    "component": "src\\components\\panels\\MOADPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "productionpanel-src\\components\\panels\\ProductionPanel",
    "name": "ProductionPanel",
    "description": "Verificar credenciales",
    "component": "src\\components\\panels\\ProductionPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "riskexecutioncontrol-src\\components\\panels\\RiskExecutionControl",
    "name": "RiskExecutionControl",
    "description": "Mock data for demonstration",
    "component": "src\\components\\panels\\RiskExecutionControl.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "securitycontrolcenter-src\\components\\panels\\SecurityControlCenter",
    "name": "SecurityControlCenter",
    "description": "Widget SecurityControlCenter",
    "component": "src\\components\\panels\\SecurityControlCenter.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "security",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "securitysentimenthub-src\\components\\panels\\SecuritySentimentHub",
    "name": "SecuritySentimentHub",
    "description": "Mock data for demonstration",
    "component": "src\\components\\panels\\SecuritySentimentHub.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "security",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "smarttradingengine-src\\components\\panels\\SmartTradingEngine",
    "name": "SmartTradingEngine",
    "description": "Mock data for demonstration",
    "component": "src\\components\\panels\\SmartTradingEngine.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "unifiedcommandcenter-src\\components\\panels\\UnifiedCommandCenter",
    "name": "UnifiedCommandCenter",
    "description": "import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from 'recharts'",
    "component": "src\\components\\panels\\UnifiedCommandCenter.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "apis": [
        "/api/system/alerts"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "unifiedcontrolpanel2025-src\\components\\panels\\UnifiedControlPanel2025",
    "name": "UnifiedControlPanel2025",
    "description": "0-100",
    "component": "src\\components\\panels\\UnifiedControlPanel2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "portfoliobalancetracker-src\\components\\portfolio\\PortfolioBalanceTracker",
    "name": "PortfolioBalanceTracker",
    "description": "Token Balance Interface",
    "component": "src\\components\\portfolio\\PortfolioBalanceTracker.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "portfolioperformancedashboard-src\\components\\portfolio\\PortfolioPerformanceDashboard",
    "name": "PortfolioPerformanceDashboard",
    "description": "Calculate key performance metrics",
    "component": "src\\components\\portfolio\\PortfolioPerformanceDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/metrics",
        "/api/metrics/performance",
        "/api/metrics/financial"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "portfolioperformancetracker-src\\components\\portfolio\\PortfolioPerformanceTracker",
    "name": "PortfolioPerformanceTracker",
    "description": "Enhanced performance calculations",
    "component": "src\\components\\portfolio\\PortfolioPerformanceTracker.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/metrics/performance"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "riskmanagementsystem-src\\components\\portfolio\\RiskManagementSystem",
    "name": "RiskManagementSystem",
    "description": "Calculate current risk metrics",
    "component": "src\\components\\portfolio\\RiskManagementSystem.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/metrics",
        "/api/metrics/performance",
        "/api/metrics/financial"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "alertcenter-src\\components\\revenue\\AlertCenter",
    "name": "AlertCenter",
    "description": "Generar alertas del sistema",
    "component": "src\\components\\revenue\\AlertCenter.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "md"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "arbitrageenginecard-src\\components\\revenue\\ArbitrageEngineCard",
    "name": "ArbitrageEngineCard",
    "description": "🚀 ARBITRAGE ENGINE CARD - Inspirado en Balancer V2 + Hummingbot Architecture",
    "component": "src\\components\\revenue\\ArbitrageEngineCard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/health",
        "/api/metrics",
        "/api/events",
        "/api/nodes",
        "/api/config",
        "/api/config",
        "/api/start",
        "/api/stop",
        "/api/status",
        "/api/stream",
        "/api/metrics/performance",
        "/api/metrics/financial",
        "/api/alerts"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "arbitrage",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "autoruncontroller-src\\components\\revenue\\AutoRunController",
    "name": "AutoRunController",
    "description": "segundos",
    "component": "src\\components\\revenue\\AutoRunController.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "hftenginecard-src\\components\\revenue\\HFTEngineCard",
    "name": "HFTEngineCard",
    "description": "⚡ HFT ENGINE CARD - Inspirado en arquitectura de trading de alta frecuencia",
    "component": "src\\components\\revenue\\HFTEngineCard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "moaddashboard-src\\components\\revenue\\MOADDashboard",
    "name": "MOADDashboard",
    "description": "MOAD Dashboard - Módulo de Oportunidades de Arbitraje DeFi",
    "component": "src\\components\\revenue\\MOADDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "opportunitiespanel-src\\components\\revenue\\OpportunitiesPanel",
    "name": "OpportunitiesPanel",
    "description": "📊 OPPORTUNITIES PANEL - Panel de oportunidades en tiempo real",
    "component": "src\\components\\revenue\\OpportunitiesPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "performancemetrics-src\\components\\revenue\\PerformanceMetrics",
    "name": "PerformanceMetrics",
    "description": "Calcular cambios porcentuales (simulados por ahora)",
    "component": "src\\components\\revenue\\PerformanceMetrics.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/metrics",
        "/api/metrics/performance",
        "/api/metrics/financial"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "revenuedashboard-src\\components\\revenue\\RevenueDashboard",
    "name": "RevenueDashboard",
    "description": "💰 REVENUE DASHBOARD - Dashboard principal de ingresos con arquitectura modular",
    "component": "src\\components\\revenue\\RevenueDashboard.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "strategyselector-src\\components\\revenue\\StrategySelector",
    "name": "StrategySelector",
    "description": "src/components/revenue/StrategySelector.tsx",
    "component": "src\\components\\revenue\\StrategySelector.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "strategyselectorpanel-src\\components\\revenue\\StrategySelectorPanel",
    "name": "StrategySelectorPanel",
    "description": "Ordenar estrategias",
    "component": "src\\components\\revenue\\StrategySelectorPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "advancedriskdashboard2025-src\\components\\risk\\AdvancedRiskDashboard2025",
    "name": "AdvancedRiskDashboard2025",
    "description": "Estados principales",
    "component": "src\\components\\risk\\AdvancedRiskDashboard2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg",
      "isMainPage": true
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "riskmanagementcontrol-src\\components\\risk\\RiskManagementControl",
    "name": "RiskManagementControl",
    "description": "Widget RiskManagementControl",
    "component": "src\\components\\risk\\RiskManagementControl.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "riskmanagementsystem2025-src\\components\\risk\\RiskManagementSystem2025",
    "name": "RiskManagementSystem2025",
    "description": "% máximo de la cuenta total",
    "component": "src\\components\\risk\\RiskManagementSystem2025.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "securitycontrolpanel-src\\components\\security\\SecurityControlPanel",
    "name": "SecurityControlPanel",
    "description": "Persistent security configuration",
    "component": "src\\components\\security\\SecurityControlPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "marketsimulator-src\\components\\simulation\\MarketSimulator",
    "name": "MarketSimulator",
    "description": "Simulate market data updates",
    "component": "src\\components\\simulation\\MarketSimulator.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "truthguardstatus-src\\components\\status\\TruthGuardStatus",
    "name": "TruthGuardStatus",
    "description": "Determine overall system health",
    "component": "src\\components\\status\\TruthGuardStatus.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {
      "apis": [
        "/health",
        "/api/status"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "action"
    }
  },
  {
    "id": "specialstrategiesbrochure-src\\components\\strategy\\SpecialStrategiesBrochure",
    "name": "SpecialStrategiesBrochure",
    "description": "Widget SpecialStrategiesBrochure",
    "component": "src\\components\\strategy\\SpecialStrategiesBrochure.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "strategybuilder-src\\components\\strategy\\StrategyBuilder",
    "name": "StrategyBuilder",
    "description": "Widget StrategyBuilder",
    "component": "src\\components\\strategy\\StrategyBuilder.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "unifiedspecialstrategies-src\\components\\strategy\\UnifiedSpecialStrategies",
    "name": "UnifiedSpecialStrategies",
    "description": "Estrategias Básicas + Especiales Unificadas",
    "component": "src\\components\\strategy\\UnifiedSpecialStrategies.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "strategytestingpanel-src\\components\\testing\\StrategyTestingPanel",
    "name": "StrategyTestingPanel",
    "description": "StrategyTestingPanel.tsx",
    "component": "src\\components\\testing\\StrategyTestingPanel.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "card-src\\components\\ui\\card",
    "name": "card",
    "description": "Widget card",
    "component": "src\\components\\ui\\card.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "chart-src\\components\\ui\\chart",
    "name": "chart",
    "description": "Format: { THEME_NAME: CSS_SELECTOR }",
    "component": "src\\components\\ui\\chart.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 25,
      "size": "lg"
    },
    "dataDeps": {
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "chart"
    }
  },
  {
    "id": "hover-card-src\\components\\ui\\hover-card",
    "name": "hover-card",
    "description": "Widget hover-card",
    "component": "src\\components\\ui\\hover-card.tsx",
    "slot": "workspace",
    "placement": {
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "resizable-src\\components\\ui\\resizable",
    "name": "resizable",
    "description": "Widget resizable",
    "component": "src\\components\\ui\\resizable.tsx",
    "slot": "rightPanel",
    "placement": {
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {},
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "display"
    }
  },
  {
    "id": "sidebar-src\\components\\ui\\sidebar",
    "name": "sidebar",
    "description": "This is the internal state of the sidebar.",
    "component": "src\\components\\ui\\sidebar.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 50,
      "size": "md"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "dashboard",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "form"
    }
  },
  {
    "id": "systemvalidation-src\\components\\validation\\SystemValidation",
    "name": "SystemValidation",
    "description": "Configuration states from KV",
    "component": "src\\components\\validation\\SystemValidation.tsx",
    "slot": "topbar",
    "placement": {
      "slot": "topbar",
      "priority": 25,
      "size": "sm"
    },
    "dataDeps": {
      "sseEvents": [
        "real-time-updates"
      ],
      "realTimeData": [
        "live-metrics",
        "real-time-data"
      ],
      "apis": [
        "/api/config",
        "/api/config"
      ]
    },
    "permissions": {
      "accessLevel": "authenticated"
    },
    "category": "monitoring",
    "enabled": true,
    "metadata": {
      "type": "widget",
      "widgetType": "metric"
    }
  },
  {
    "id": "admin-arbitrage",
    "name": "Arbitrage Admin",
    "description": "Panel de administración para arbitrage",
    "slot": "workspace",
    "placement": {
      "size": "lg",
      "priority": 20,
      "requiresAuth": true
    },
    "dataDeps": {
      "apis": [
        "/health",
        "/api/metrics",
        "/api/events",
        "/api/nodes",
        "/api/config",
        "/api/config",
        "/api/start",
        "/api/stop",
        "/api/status",
        "/api/stream",
        "/api/metrics/performance",
        "/api/metrics/financial",
        "/api/alerts"
      ]
    },
    "permissions": {
      "accessLevel": "admin",
      "roles": [
        "admin",
        "operator"
      ]
    },
    "category": "arbitrage",
    "enabled": true,
    "metadata": {
      "type": "admin-panel",
      "endpoints": 13,
      "methods": [
        "GET",
        "POST"
      ]
    }
  }
];

// Registry completo
export const featureRegistry = {
  "features": [
    {
      "id": "page-audit",
      "name": "Audit",
      "description": "AuditDashboard.tsx - Dashboard de Auditoría Zero-Mock Data",
      "component": "src\\components\\audit\\AuditDashboard.tsx",
      "path": "/audit",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {
        "apis": [
          "/api/metrics",
          "/api/health"
        ],
        "realTimeData": [
          "gap-metrics",
          "real-time-audit"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-keylessgapauditor",
      "name": "Keylessgapauditor",
      "description": "eth-mainnet.g.alchemy.com/v2/demo',",
      "component": "src\\components\\audit\\KeylessGapAuditor.tsx",
      "path": "/keylessgapauditor",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {
        "apis": [
          "/api/metrics",
          "/api/health"
        ],
        "realTimeData": [
          "gap-metrics",
          "real-time-audit"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-mockdataauditpanel",
      "name": "Mockdataauditpanel",
      "description": "Real-time audit data fetching",
      "component": "src\\components\\audit\\MockDataAuditPanel.tsx",
      "path": "/mockdataauditpanel",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {
        "apis": [
          "/api/metrics",
          "/api/health"
        ],
        "realTimeData": [
          "gap-metrics",
          "real-time-audit"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-arbitrage",
      "name": "Arbitrage",
      "description": "State management",
      "component": "src\\components\\dashboard\\ArbitrageDashboard.tsx",
      "path": "/arbitrage",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 20
      },
      "dataDeps": {
        "apis": [
          "/api/arbitrage/opportunities",
          "/api/arbitrage/execute",
          "/health",
          "/api/metrics",
          "/api/events",
          "/api/nodes",
          "/api/config",
          "/api/config",
          "/api/start",
          "/api/stop",
          "/api/status",
          "/api/stream",
          "/api/metrics/performance",
          "/api/metrics/financial",
          "/api/alerts"
        ],
        "realTimeData": [
          "prices",
          "opportunities"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "arbitrage",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-unifiedintelligent",
      "name": "Unifiedintelligent",
      "description": "Estados principales",
      "component": "src\\components\\dashboard\\UnifiedIntelligentDashboard.tsx",
      "path": "/unifiedintelligent",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-advancedllmmodule",
      "name": "Advancedllmmodule",
      "description": "Simulate AI response - in production this would connect to real LLM API",
      "component": "src\\components\\modules\\AdvancedLLMModule.tsx",
      "path": "/advancedllmmodule",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-advancedmevprotection",
      "name": "Advancedmevprotection",
      "description": "Página Advancedmevprotection",
      "component": "src\\components\\modules\\AdvancedMEVProtection.tsx",
      "path": "/advancedmevprotection",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-advancedsecuritycenter",
      "name": "Advancedsecuritycenter",
      "description": "Página Advancedsecuritycenter",
      "component": "src\\components\\modules\\AdvancedSecurityCenter.tsx",
      "path": "/advancedsecuritycenter",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "security",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-autoexecutioncontroller",
      "name": "Autoexecutioncontroller",
      "description": "Página Autoexecutioncontroller",
      "component": "src\\components\\modules\\AutoExecutionController.tsx",
      "path": "/autoexecutioncontroller",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-enhancedmainmodule",
      "name": "Enhancedmainmodule",
      "description": "Simulated real-time metrics",
      "component": "src\\components\\modules\\EnhancedMainModule.tsx",
      "path": "/enhancedmainmodule",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {
        "apis": [
          "/api/metrics",
          "/api/metrics/performance",
          "/api/metrics/financial"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-enhancedmonitoringhub",
      "name": "Enhancedmonitoringhub",
      "description": "Página Enhancedmonitoringhub",
      "component": "src\\components\\modules\\EnhancedMonitoringHub.tsx",
      "path": "/enhancedmonitoringhub",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 30
      },
      "dataDeps": {
        "apis": [
          "/api/metrics",
          "/api/status"
        ],
        "sseEvents": [
          "metrics-update"
        ],
        "realTimeData": [
          "system-metrics",
          "live-data"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-intelligentconfigcenter",
      "name": "Intelligentconfigcenter",
      "description": "Página Intelligentconfigcenter",
      "component": "src\\components\\modules\\IntelligentConfigCenter.tsx",
      "path": "/intelligentconfigcenter",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-intelligentriskmodule",
      "name": "Intelligentriskmodule",
      "description": "Página Intelligentriskmodule",
      "component": "src\\components\\modules\\IntelligentRiskModule.tsx",
      "path": "/intelligentriskmodule",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-mlinsightsengine",
      "name": "Mlinsightsengine",
      "description": "Página Mlinsightsengine",
      "component": "src\\components\\modules\\MLInsightsEngine.tsx",
      "path": "/mlinsightsengine",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-multichainmanagerpro",
      "name": "Multichainmanagerpro",
      "description": "Página Multichainmanagerpro",
      "component": "src\\components\\modules\\MultiChainManagerPro.tsx",
      "path": "/multichainmanagerpro",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-sentimenttradingengine",
      "name": "Sentimenttradingengine",
      "description": "Página Sentimenttradingengine",
      "component": "src\\components\\modules\\SentimentTradingEngine.tsx",
      "path": "/sentimenttradingengine",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-smartarbitrageengine",
      "name": "Smartarbitrageengine",
      "description": "Simulate real-time opportunity detection",
      "component": "src\\components\\modules\\SmartArbitrageEngine.tsx",
      "path": "/smartarbitrageengine",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 20
      },
      "dataDeps": {
        "apis": [
          "/api/arbitrage/opportunities",
          "/api/arbitrage/execute",
          "/health",
          "/api/metrics",
          "/api/events",
          "/api/nodes",
          "/api/config",
          "/api/config",
          "/api/start",
          "/api/stop",
          "/api/status",
          "/api/stream",
          "/api/metrics/performance",
          "/api/metrics/financial",
          "/api/alerts"
        ],
        "realTimeData": [
          "prices",
          "opportunities"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "arbitrage",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-smartliquiditytracker",
      "name": "Smartliquiditytracker",
      "description": "Página Smartliquiditytracker",
      "component": "src\\components\\modules\\SmartLiquidityTracker.tsx",
      "path": "/smartliquiditytracker",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-ultralowlatencyengine",
      "name": "Ultralowlatencyengine",
      "description": "Página Ultralowlatencyengine",
      "component": "src\\components\\modules\\UltraLowLatencyEngine.tsx",
      "path": "/ultralowlatencyengine",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-realtimemonitoring",
      "name": "Realtimemonitoring",
      "description": "RealTimeMonitoringDashboard.tsx",
      "component": "src\\components\\monitoring\\RealTimeMonitoringDashboard.tsx",
      "path": "/realtimemonitoring",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 30
      },
      "dataDeps": {
        "apis": [
          "/api/metrics",
          "/api/status"
        ],
        "sseEvents": [
          "metrics-update"
        ],
        "realTimeData": [
          "system-metrics",
          "live-data"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-securitycontrolcenter",
      "name": "Securitycontrolcenter",
      "description": "Página Securitycontrolcenter",
      "component": "src\\components\\panels\\SecurityControlCenter.tsx",
      "path": "/securitycontrolcenter",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "security",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-unifiedcommandcenter",
      "name": "Unifiedcommandcenter",
      "description": "import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from 'recharts'",
      "component": "src\\components\\panels\\UnifiedCommandCenter.tsx",
      "path": "/unifiedcommandcenter",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-moad",
      "name": "Moad",
      "description": "MOAD Dashboard - Módulo de Oportunidades de Arbitraje DeFi",
      "component": "src\\components\\revenue\\MOADDashboard.tsx",
      "path": "/moad",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-riskmanagementcontrol",
      "name": "Riskmanagementcontrol",
      "description": "Página Riskmanagementcontrol",
      "component": "src\\components\\risk\\RiskManagementControl.tsx",
      "path": "/riskmanagementcontrol",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-securitycontrolpanel",
      "name": "Securitycontrolpanel",
      "description": "Persistent security configuration",
      "component": "src\\components\\security\\SecurityControlPanel.tsx",
      "path": "/securitycontrolpanel",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "security",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-truthguardstatus",
      "name": "Truthguardstatus",
      "description": "Determine overall system health",
      "component": "src\\components\\status\\TruthGuardStatus.tsx",
      "path": "/truthguardstatus",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {
        "apis": [
          "/health",
          "/api/status"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-specialstrategiesbrochure",
      "name": "Specialstrategiesbrochure",
      "description": "Página Specialstrategiesbrochure",
      "component": "src\\components\\strategy\\SpecialStrategiesBrochure.tsx",
      "path": "/specialstrategiesbrochure",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-unifiedspecialstrategies",
      "name": "Unifiedspecialstrategies",
      "description": "Estrategias Básicas + Especiales Unificadas",
      "component": "src\\components\\strategy\\UnifiedSpecialStrategies.tsx",
      "path": "/unifiedspecialstrategies",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-systemvalidation",
      "name": "Systemvalidation",
      "description": "Configuration states from KV",
      "component": "src\\components\\validation\\SystemValidation.tsx",
      "path": "/systemvalidation",
      "slot": "workspace",
      "placement": {
        "size": "md",
        "requiresAuth": false,
        "isMainPage": false,
        "priority": 50
      },
      "dataDeps": {
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "component"
      }
    },
    {
      "id": "page-home",
      "name": "Home",
      "description": "Command Palette",
      "component": "src/App.tsx",
      "path": "/",
      "slot": "workspace",
      "placement": {
        "size": "full",
        "requiresAuth": false,
        "isMainPage": true,
        "priority": 10
      },
      "dataDeps": {
        "apis": [
          "/api/metrics",
          "/api/status"
        ],
        "sseEvents": [
          "metrics-update"
        ],
        "realTimeData": [
          "system-metrics",
          "live-data"
        ]
      },
      "permissions": {
        "accessLevel": "public"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "page",
        "routerType": "main"
      }
    },
    {
      "id": "advancedanalyticsdashboard-src\\components\\analytics\\AdvancedAnalyticsDashboard",
      "name": "AdvancedAnalyticsDashboard",
      "description": "Calculate comprehensive metrics",
      "component": "src\\components\\analytics\\AdvancedAnalyticsDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/metrics",
          "/api/metrics/performance",
          "/api/metrics/financial"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "analytics-src\\components\\analytics\\Analytics",
      "name": "Analytics",
      "description": "Calculate analytics",
      "component": "src\\components\\analytics\\Analytics.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "marketanalysisdashboard-src\\components\\analytics\\MarketAnalysisDashboard",
      "name": "MarketAnalysisDashboard",
      "description": "Simulated real-time opportunities",
      "component": "src\\components\\analytics\\MarketAnalysisDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "predictiveanalytics2025-src\\components\\analytics\\PredictiveAnalytics2025",
      "name": "PredictiveAnalytics2025",
      "description": "Simulación de datos en tiempo real",
      "component": "src\\components\\analytics\\PredictiveAnalytics2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "auditdashboard-src\\components\\audit\\AuditDashboard",
      "name": "AuditDashboard",
      "description": "AuditDashboard.tsx - Dashboard de Auditoría Zero-Mock Data",
      "component": "src\\components\\audit\\AuditDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "automatedauditrunner-src\\components\\audit\\AutomatedAuditRunner",
      "name": "AutomatedAuditRunner",
      "description": "Infrastructure Scripts",
      "component": "src\\components\\audit\\AutomatedAuditRunner.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "certificationreport-src\\components\\audit\\CertificationReport",
      "name": "CertificationReport",
      "description": "Mock certification data - in real implementation, this would come from the audit system",
      "component": "src\\components\\audit\\CertificationReport.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "compliancechecks-src\\components\\audit\\ComplianceChecks",
      "name": "ComplianceChecks",
      "description": "Pre-configured compliance checks for each audit section",
      "component": "src\\components\\audit\\ComplianceChecks.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "index-src\\components\\audit\\index",
      "name": "index",
      "description": "Widget index",
      "component": "src\\components\\audit\\index.ts",
      "slot": "workspace",
      "placement": {
        "slot": "workspace",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "keylessgapauditor-src\\components\\audit\\KeylessGapAuditor",
      "name": "KeylessGapAuditor",
      "description": "eth-mainnet.g.alchemy.com/v2/demo',",
      "component": "src\\components\\audit\\KeylessGapAuditor.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "apis": [
          "http://localhost:${backendPort}/health",
          "${apiBaseUrl}/metrics",
          "${apiBaseUrl}/events",
          "${apiBaseUrl}/nodes",
          "${apiBaseUrl}/config"
        ],
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "mockdataauditor-src\\components\\audit\\MockDataAuditor",
      "name": "MockDataAuditor",
      "description": "Simulated mock data patterns for demonstration",
      "component": "src\\components\\audit\\MockDataAuditor.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "mockdataauditpanel-src\\components\\audit\\MockDataAuditPanel",
      "name": "MockDataAuditPanel",
      "description": "Real-time audit data fetching",
      "component": "src\\components\\audit\\MockDataAuditPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "apis": [
          "/api/audit/mock-data",
          "/api/audit/mock-data"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "realtimegapauditor-src\\components\\audit\\RealTimeGapAuditor",
      "name": "RealTimeGapAuditor",
      "description": "URLs de documentación para cada servicio",
      "component": "src\\components\\audit\\RealTimeGapAuditor.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "systemstatusindicator-src\\components\\audit\\SystemStatusIndicator",
      "name": "SystemStatusIndicator",
      "description": "Widget SystemStatusIndicator",
      "component": "src\\components\\audit\\SystemStatusIndicator.tsx",
      "slot": "topbar",
      "placement": {
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "apis": [
          "/api/status"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "action"
      }
    },
    {
      "id": "charterrorboundary-src\\components\\charts\\ChartErrorBoundary",
      "name": "ChartErrorBoundary",
      "description": "Widget ChartErrorBoundary",
      "component": "src\\components\\charts\\ChartErrorBoundary.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "portfoliochart-src\\components\\charts\\PortfolioChart",
      "name": "PortfolioChart",
      "description": "Starting balance",
      "component": "src\\components\\charts\\PortfolioChart.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/start"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "profitlosschart-src\\components\\charts\\ProfitLossChart",
      "name": "ProfitLossChart",
      "description": "Group trades by day",
      "component": "src\\components\\charts\\ProfitLossChart.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "riskmetricschart-src\\components\\charts\\RiskMetricsChart",
      "name": "RiskMetricsChart",
      "description": "Sort trades chronologically",
      "component": "src\\components\\charts\\RiskMetricsChart.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/metrics",
          "/api/metrics/performance",
          "/api/metrics/financial"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "strategyallocationchart-src\\components\\charts\\StrategyAllocationChart",
      "name": "StrategyAllocationChart",
      "description": "Calculate total allocation by strategy type",
      "component": "src\\components\\charts\\StrategyAllocationChart.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "tradingvolumechart-src\\components\\charts\\TradingVolumeChart",
      "name": "TradingVolumeChart",
      "description": "Group trades by hour for recent activity, or by day for longer periods",
      "component": "src\\components\\charts\\TradingVolumeChart.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "commandpalette-src\\components\\CommandPalette",
      "name": "CommandPalette",
      "description": "Command Palette para ArbitrageX Pro 2025",
      "component": "src\\components\\CommandPalette.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {
        "apis": [
          "/api/health"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "configurationhub-src\\components\\configuration\\ConfigurationHub",
      "name": "ConfigurationHub",
      "description": "Persistent state management",
      "component": "src\\components\\configuration\\ConfigurationHub.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "credentialssetuppanel-src\\components\\configuration\\CredentialsSetupPanel",
      "name": "CredentialsSetupPanel",
      "description": "Blockchain RPCs",
      "component": "src\\components\\configuration\\CredentialsSetupPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "dynamicserviceform-src\\components\\configuration\\DynamicServiceForm",
      "name": "DynamicServiceForm",
      "description": "Auto-detect status based on required fields",
      "component": "src\\components\\configuration\\DynamicServiceForm.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/status"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "arbitragedashboard-src\\components\\dashboard\\ArbitrageDashboard",
      "name": "ArbitrageDashboard",
      "description": "State management",
      "component": "src\\components\\dashboard\\ArbitrageDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/health",
          "/api/metrics",
          "/api/events",
          "/api/nodes",
          "/api/config",
          "/api/config",
          "/api/start",
          "/api/stop",
          "/api/status",
          "/api/stream",
          "/api/metrics/performance",
          "/api/metrics/financial",
          "/api/alerts"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "arbitrage",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "dashboard-src\\components\\dashboard\\Dashboard",
      "name": "Dashboard",
      "description": "Simulate arbitrage opportunities",
      "component": "src\\components\\dashboard\\Dashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "intelligentdashboard2025-src\\components\\dashboard\\IntelligentDashboard2025",
      "name": "IntelligentDashboard2025",
      "description": "seconds",
      "component": "src\\components\\dashboard\\IntelligentDashboard2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "realtimeperformancedashboard-src\\components\\dashboard\\RealtimePerformanceDashboard",
      "name": "RealtimePerformanceDashboard",
      "description": "Update timestamp periodically",
      "component": "src\\components\\dashboard\\RealtimePerformanceDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/metrics/performance"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "unifiedintelligentdashboard-src\\components\\dashboard\\UnifiedIntelligentDashboard",
      "name": "UnifiedIntelligentDashboard",
      "description": "Estados principales",
      "component": "src\\components\\dashboard\\UnifiedIntelligentDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "learningcenter-src\\components\\learning\\LearningCenter",
      "name": "LearningCenter",
      "description": "Quiz completed",
      "component": "src\\components\\learning\\LearningCenter.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "advancedllmmodule-src\\components\\modules\\AdvancedLLMModule",
      "name": "AdvancedLLMModule",
      "description": "Simulate AI response - in production this would connect to real LLM API",
      "component": "src\\components\\modules\\AdvancedLLMModule.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "advancedmevprotection-src\\components\\modules\\AdvancedMEVProtection",
      "name": "AdvancedMEVProtection",
      "description": "Widget AdvancedMEVProtection",
      "component": "src\\components\\modules\\AdvancedMEVProtection.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "advancedsecuritycenter-src\\components\\modules\\AdvancedSecurityCenter",
      "name": "AdvancedSecurityCenter",
      "description": "Widget AdvancedSecurityCenter",
      "component": "src\\components\\modules\\AdvancedSecurityCenter.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "security",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "autoexecutioncontroller-src\\components\\modules\\AutoExecutionController",
      "name": "AutoExecutionController",
      "description": "Widget AutoExecutionController",
      "component": "src\\components\\modules\\AutoExecutionController.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "enhancedmainmodule-src\\components\\modules\\EnhancedMainModule",
      "name": "EnhancedMainModule",
      "description": "Simulated real-time metrics",
      "component": "src\\components\\modules\\EnhancedMainModule.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/metrics",
          "/api/metrics/performance",
          "/api/metrics/financial"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "enhancedmonitoringhub-src\\components\\modules\\EnhancedMonitoringHub",
      "name": "EnhancedMonitoringHub",
      "description": "Widget EnhancedMonitoringHub",
      "component": "src\\components\\modules\\EnhancedMonitoringHub.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "intelligentconfigcenter-src\\components\\modules\\IntelligentConfigCenter",
      "name": "IntelligentConfigCenter",
      "description": "Widget IntelligentConfigCenter",
      "component": "src\\components\\modules\\IntelligentConfigCenter.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "intelligentriskmodule-src\\components\\modules\\IntelligentRiskModule",
      "name": "IntelligentRiskModule",
      "description": "Widget IntelligentRiskModule",
      "component": "src\\components\\modules\\IntelligentRiskModule.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "mlinsightsengine-src\\components\\modules\\MLInsightsEngine",
      "name": "MLInsightsEngine",
      "description": "Widget MLInsightsEngine",
      "component": "src\\components\\modules\\MLInsightsEngine.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "arbitrageenginecard-src\\components\\modules\\moad\\ArbitrageEngineCard",
      "name": "ArbitrageEngineCard",
      "description": "ArbitrageX Pro 2 - Arbitrage Engine Card",
      "component": "src\\components\\modules\\moad\\ArbitrageEngineCard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 20,
        "size": "md"
      },
      "dataDeps": {
        "apis": [
          "/health",
          "/api/metrics",
          "/api/events",
          "/api/nodes",
          "/api/config",
          "/api/config",
          "/api/start",
          "/api/stop",
          "/api/status",
          "/api/stream",
          "/api/metrics/performance",
          "/api/metrics/financial",
          "/api/alerts"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "arbitrage",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "hftenginecard-src\\components\\modules\\moad\\HFTEngineCard",
      "name": "HFTEngineCard",
      "description": "ArbitrageX Pro 2 - HFT Engine Card",
      "component": "src\\components\\modules\\moad\\HFTEngineCard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "index-src\\components\\modules\\moad\\index",
      "name": "index",
      "description": "ArbitrageX Pro 2 - MOAD Index",
      "component": "src\\components\\modules\\moad\\index.ts",
      "slot": "workspace",
      "placement": {
        "slot": "workspace",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "moadcompletesystem-src\\components\\modules\\moad\\MOADCompleteSystem",
      "name": "MOADCompleteSystem",
      "description": "ArbitrageX Pro 2 - MOAD Complete System",
      "component": "src\\components\\modules\\moad\\MOADCompleteSystem.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "moadexecutivesummary-src\\components\\modules\\moad\\MOADExecutiveSummary",
      "name": "MOADExecutiveSummary",
      "description": "ArbitrageX Pro 2 - MOAD Executive Summary",
      "component": "src\\components\\modules\\moad\\MOADExecutiveSummary.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "moadstrategytesting-src\\components\\modules\\moad\\MOADStrategyTesting",
      "name": "MOADStrategyTesting",
      "description": "ArbitrageX Pro 2 - MOAD Strategy Testing",
      "component": "src\\components\\modules\\moad\\MOADStrategyTesting.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "notifier-src\\components\\modules\\moad\\notifier",
      "name": "notifier",
      "description": "ArbitrageX Pro 2 - MOAD System Notifier",
      "component": "src\\components\\modules\\moad\\notifier.ts",
      "slot": "workspace",
      "placement": {
        "slot": "workspace",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "opportunitiespanel-src\\components\\modules\\moad\\OpportunitiesPanel",
      "name": "OpportunitiesPanel",
      "description": "ArbitrageX Pro 2 - Opportunities Panel",
      "component": "src\\components\\modules\\moad\\OpportunitiesPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "revenuedashboard-src\\components\\modules\\moad\\RevenueDashboard",
      "name": "RevenueDashboard",
      "description": "ArbitrageX Pro 2 - Revenue Dashboard",
      "component": "src\\components\\modules\\moad\\RevenueDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "xl",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "action"
      }
    },
    {
      "id": "strategyselector-src\\components\\modules\\moad\\StrategySelector",
      "name": "StrategySelector",
      "description": "ArbitrageX Pro 2 - Strategy Selector",
      "component": "src\\components\\modules\\moad\\StrategySelector.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "multichainmanagerpro-src\\components\\modules\\MultiChainManagerPro",
      "name": "MultiChainManagerPro",
      "description": "Widget MultiChainManagerPro",
      "component": "src\\components\\modules\\MultiChainManagerPro.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "sentimenttradingengine-src\\components\\modules\\SentimentTradingEngine",
      "name": "SentimentTradingEngine",
      "description": "Widget SentimentTradingEngine",
      "component": "src\\components\\modules\\SentimentTradingEngine.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "smartarbitrageengine-src\\components\\modules\\SmartArbitrageEngine",
      "name": "SmartArbitrageEngine",
      "description": "Simulate real-time opportunity detection",
      "component": "src\\components\\modules\\SmartArbitrageEngine.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/health",
          "/api/metrics",
          "/api/events",
          "/api/nodes",
          "/api/config",
          "/api/config",
          "/api/start",
          "/api/stop",
          "/api/status",
          "/api/stream",
          "/api/metrics/performance",
          "/api/metrics/financial",
          "/api/alerts"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "arbitrage",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "smartliquiditytracker-src\\components\\modules\\SmartLiquidityTracker",
      "name": "SmartLiquidityTracker",
      "description": "Widget SmartLiquidityTracker",
      "component": "src\\components\\modules\\SmartLiquidityTracker.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "ultralowlatencyengine-src\\components\\modules\\UltraLowLatencyEngine",
      "name": "UltraLowLatencyEngine",
      "description": "Widget UltraLowLatencyEngine",
      "component": "src\\components\\modules\\UltraLowLatencyEngine.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "realtimemonitoringdashboard-src\\components\\monitoring\\RealTimeMonitoringDashboard",
      "name": "RealTimeMonitoringDashboard",
      "description": "RealTimeMonitoringDashboard.tsx",
      "component": "src\\components\\monitoring\\RealTimeMonitoringDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "apis": [
          "/api/metrics/performance",
          "/api/metrics/financial",
          "/api/alerts"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "sidebar-src\\components\\navigation\\Sidebar",
      "name": "Sidebar",
      "description": "Nuevos iconos para las funcionalidades 2025",
      "component": "src\\components\\navigation\\Sidebar.tsx",
      "slot": "sidebar",
      "placement": {
        "slot": "sidebar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "advancednotificationsystem2025-src\\components\\notifications\\AdvancedNotificationSystem2025",
      "name": "AdvancedNotificationSystem2025",
      "description": "Simulación de notificaciones en tiempo real",
      "component": "src\\components\\notifications\\AdvancedNotificationSystem2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "table"
      }
    },
    {
      "id": "discordnotificationconfig-src\\components\\notifications\\DiscordNotificationConfig",
      "name": "DiscordNotificationConfig",
      "description": "cdn.discordapp.com/attachments/123/bot-icon.png'",
      "component": "src\\components\\notifications\\DiscordNotificationConfig.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "notificationcenter-src\\components\\notifications\\NotificationCenter",
      "name": "NotificationCenter",
      "description": "Estadísticas del sistema",
      "component": "src\\components\\notifications\\NotificationCenter.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "action"
      }
    },
    {
      "id": "notificationhistory-src\\components\\notifications\\NotificationHistory",
      "name": "NotificationHistory",
      "description": "Aplicar filtros",
      "component": "src\\components\\notifications\\NotificationHistory.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "notificationpreferences-src\\components\\notifications\\NotificationPreferences",
      "name": "NotificationPreferences",
      "description": "Tipos de eventos disponibles con sus descripciones",
      "component": "src\\components\\notifications\\NotificationPreferences.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "realtimenotificationprovider-src\\components\\notifications\\RealTimeNotificationProvider",
      "name": "RealTimeNotificationProvider",
      "description": "Configuración",
      "component": "src\\components\\notifications\\RealTimeNotificationProvider.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "telegramnotificationconfig-src\\components\\notifications\\TelegramNotificationConfig",
      "name": "TelegramNotificationConfig",
      "description": "Cargar configuración existente",
      "component": "src\\components\\notifications\\TelegramNotificationConfig.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "apis": [
          "https://api.telegram.org/bot${telegramConfig.botToken}/getMe",
          "/api/config",
          "/api/config"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "types-src\\components\\notifications\\types",
      "name": "types",
      "description": "Tipos TypeScript para el sistema de notificaciones en tiempo real",
      "component": "src\\components\\notifications\\types.ts",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "gamifiedonboarding2025-src\\components\\onboarding\\GamifiedOnboarding2025",
      "name": "GamifiedOnboarding2025",
      "description": "minutes",
      "component": "src\\components\\onboarding\\GamifiedOnboarding2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "advancedautomationcenter-src\\components\\panels\\AdvancedAutomationCenter",
      "name": "AdvancedAutomationCenter",
      "description": "Mock data for demonstration",
      "component": "src\\components\\panels\\AdvancedAutomationCenter.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "advancedmevcontrolpanel2025-src\\components\\panels\\AdvancedMEVControlPanel2025",
      "name": "AdvancedMEVControlPanel2025",
      "description": "Actualizar cada 5 segundos",
      "component": "src\\components\\panels\\AdvancedMEVControlPanel2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "advancedstrategiespanel2025-src\\components\\panels\\AdvancedStrategiesPanel2025",
      "name": "AdvancedStrategiesPanel2025",
      "description": "Actualizar cada 5 segundos",
      "component": "src\\components\\panels\\AdvancedStrategiesPanel2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "auditcompliancecenter-src\\components\\panels\\AuditComplianceCenter",
      "name": "AuditComplianceCenter",
      "description": "Widget AuditComplianceCenter",
      "component": "src\\components\\panels\\AuditComplianceCenter.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "autonomouscontrolpanel2025-src\\components\\panels\\AutonomousControlPanel2025",
      "name": "AutonomousControlPanel2025",
      "description": "Actualizar cada 5 segundos",
      "component": "src\\components\\panels\\AutonomousControlPanel2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "crosschainaiorchestrator-src\\components\\panels\\CrossChainAIOrchestrator",
      "name": "CrossChainAIOrchestrator",
      "description": "Mock data for demonstration",
      "component": "src\\components\\panels\\CrossChainAIOrchestrator.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "moadpanel-src\\components\\panels\\MOADPanel",
      "name": "MOADPanel",
      "description": "MÓDULO DE OPORTUNIDADES DE ARBITRAJE DeFi (MOAD)",
      "component": "src\\components\\panels\\MOADPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "productionpanel-src\\components\\panels\\ProductionPanel",
      "name": "ProductionPanel",
      "description": "Verificar credenciales",
      "component": "src\\components\\panels\\ProductionPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "riskexecutioncontrol-src\\components\\panels\\RiskExecutionControl",
      "name": "RiskExecutionControl",
      "description": "Mock data for demonstration",
      "component": "src\\components\\panels\\RiskExecutionControl.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "securitycontrolcenter-src\\components\\panels\\SecurityControlCenter",
      "name": "SecurityControlCenter",
      "description": "Widget SecurityControlCenter",
      "component": "src\\components\\panels\\SecurityControlCenter.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "security",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "securitysentimenthub-src\\components\\panels\\SecuritySentimentHub",
      "name": "SecuritySentimentHub",
      "description": "Mock data for demonstration",
      "component": "src\\components\\panels\\SecuritySentimentHub.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "security",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "smarttradingengine-src\\components\\panels\\SmartTradingEngine",
      "name": "SmartTradingEngine",
      "description": "Mock data for demonstration",
      "component": "src\\components\\panels\\SmartTradingEngine.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "unifiedcommandcenter-src\\components\\panels\\UnifiedCommandCenter",
      "name": "UnifiedCommandCenter",
      "description": "import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from 'recharts'",
      "component": "src\\components\\panels\\UnifiedCommandCenter.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "apis": [
          "/api/system/alerts"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "unifiedcontrolpanel2025-src\\components\\panels\\UnifiedControlPanel2025",
      "name": "UnifiedControlPanel2025",
      "description": "0-100",
      "component": "src\\components\\panels\\UnifiedControlPanel2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "portfoliobalancetracker-src\\components\\portfolio\\PortfolioBalanceTracker",
      "name": "PortfolioBalanceTracker",
      "description": "Token Balance Interface",
      "component": "src\\components\\portfolio\\PortfolioBalanceTracker.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "portfolioperformancedashboard-src\\components\\portfolio\\PortfolioPerformanceDashboard",
      "name": "PortfolioPerformanceDashboard",
      "description": "Calculate key performance metrics",
      "component": "src\\components\\portfolio\\PortfolioPerformanceDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/metrics",
          "/api/metrics/performance",
          "/api/metrics/financial"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "portfolioperformancetracker-src\\components\\portfolio\\PortfolioPerformanceTracker",
      "name": "PortfolioPerformanceTracker",
      "description": "Enhanced performance calculations",
      "component": "src\\components\\portfolio\\PortfolioPerformanceTracker.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/metrics/performance"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "riskmanagementsystem-src\\components\\portfolio\\RiskManagementSystem",
      "name": "RiskManagementSystem",
      "description": "Calculate current risk metrics",
      "component": "src\\components\\portfolio\\RiskManagementSystem.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/metrics",
          "/api/metrics/performance",
          "/api/metrics/financial"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "alertcenter-src\\components\\revenue\\AlertCenter",
      "name": "AlertCenter",
      "description": "Generar alertas del sistema",
      "component": "src\\components\\revenue\\AlertCenter.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "md"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "arbitrageenginecard-src\\components\\revenue\\ArbitrageEngineCard",
      "name": "ArbitrageEngineCard",
      "description": "🚀 ARBITRAGE ENGINE CARD - Inspirado en Balancer V2 + Hummingbot Architecture",
      "component": "src\\components\\revenue\\ArbitrageEngineCard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/health",
          "/api/metrics",
          "/api/events",
          "/api/nodes",
          "/api/config",
          "/api/config",
          "/api/start",
          "/api/stop",
          "/api/status",
          "/api/stream",
          "/api/metrics/performance",
          "/api/metrics/financial",
          "/api/alerts"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "arbitrage",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "autoruncontroller-src\\components\\revenue\\AutoRunController",
      "name": "AutoRunController",
      "description": "segundos",
      "component": "src\\components\\revenue\\AutoRunController.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "hftenginecard-src\\components\\revenue\\HFTEngineCard",
      "name": "HFTEngineCard",
      "description": "⚡ HFT ENGINE CARD - Inspirado en arquitectura de trading de alta frecuencia",
      "component": "src\\components\\revenue\\HFTEngineCard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "moaddashboard-src\\components\\revenue\\MOADDashboard",
      "name": "MOADDashboard",
      "description": "MOAD Dashboard - Módulo de Oportunidades de Arbitraje DeFi",
      "component": "src\\components\\revenue\\MOADDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "opportunitiespanel-src\\components\\revenue\\OpportunitiesPanel",
      "name": "OpportunitiesPanel",
      "description": "📊 OPPORTUNITIES PANEL - Panel de oportunidades en tiempo real",
      "component": "src\\components\\revenue\\OpportunitiesPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "performancemetrics-src\\components\\revenue\\PerformanceMetrics",
      "name": "PerformanceMetrics",
      "description": "Calcular cambios porcentuales (simulados por ahora)",
      "component": "src\\components\\revenue\\PerformanceMetrics.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/metrics",
          "/api/metrics/performance",
          "/api/metrics/financial"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "revenuedashboard-src\\components\\revenue\\RevenueDashboard",
      "name": "RevenueDashboard",
      "description": "💰 REVENUE DASHBOARD - Dashboard principal de ingresos con arquitectura modular",
      "component": "src\\components\\revenue\\RevenueDashboard.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "strategyselector-src\\components\\revenue\\StrategySelector",
      "name": "StrategySelector",
      "description": "src/components/revenue/StrategySelector.tsx",
      "component": "src\\components\\revenue\\StrategySelector.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "strategyselectorpanel-src\\components\\revenue\\StrategySelectorPanel",
      "name": "StrategySelectorPanel",
      "description": "Ordenar estrategias",
      "component": "src\\components\\revenue\\StrategySelectorPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "advancedriskdashboard2025-src\\components\\risk\\AdvancedRiskDashboard2025",
      "name": "AdvancedRiskDashboard2025",
      "description": "Estados principales",
      "component": "src\\components\\risk\\AdvancedRiskDashboard2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg",
        "isMainPage": true
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "riskmanagementcontrol-src\\components\\risk\\RiskManagementControl",
      "name": "RiskManagementControl",
      "description": "Widget RiskManagementControl",
      "component": "src\\components\\risk\\RiskManagementControl.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "riskmanagementsystem2025-src\\components\\risk\\RiskManagementSystem2025",
      "name": "RiskManagementSystem2025",
      "description": "% máximo de la cuenta total",
      "component": "src\\components\\risk\\RiskManagementSystem2025.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "securitycontrolpanel-src\\components\\security\\SecurityControlPanel",
      "name": "SecurityControlPanel",
      "description": "Persistent security configuration",
      "component": "src\\components\\security\\SecurityControlPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "marketsimulator-src\\components\\simulation\\MarketSimulator",
      "name": "MarketSimulator",
      "description": "Simulate market data updates",
      "component": "src\\components\\simulation\\MarketSimulator.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "truthguardstatus-src\\components\\status\\TruthGuardStatus",
      "name": "TruthGuardStatus",
      "description": "Determine overall system health",
      "component": "src\\components\\status\\TruthGuardStatus.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {
        "apis": [
          "/health",
          "/api/status"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "action"
      }
    },
    {
      "id": "specialstrategiesbrochure-src\\components\\strategy\\SpecialStrategiesBrochure",
      "name": "SpecialStrategiesBrochure",
      "description": "Widget SpecialStrategiesBrochure",
      "component": "src\\components\\strategy\\SpecialStrategiesBrochure.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "strategybuilder-src\\components\\strategy\\StrategyBuilder",
      "name": "StrategyBuilder",
      "description": "Widget StrategyBuilder",
      "component": "src\\components\\strategy\\StrategyBuilder.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "unifiedspecialstrategies-src\\components\\strategy\\UnifiedSpecialStrategies",
      "name": "UnifiedSpecialStrategies",
      "description": "Estrategias Básicas + Especiales Unificadas",
      "component": "src\\components\\strategy\\UnifiedSpecialStrategies.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "strategytestingpanel-src\\components\\testing\\StrategyTestingPanel",
      "name": "StrategyTestingPanel",
      "description": "StrategyTestingPanel.tsx",
      "component": "src\\components\\testing\\StrategyTestingPanel.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "card-src\\components\\ui\\card",
      "name": "card",
      "description": "Widget card",
      "component": "src\\components\\ui\\card.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "chart-src\\components\\ui\\chart",
      "name": "chart",
      "description": "Format: { THEME_NAME: CSS_SELECTOR }",
      "component": "src\\components\\ui\\chart.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 25,
        "size": "lg"
      },
      "dataDeps": {
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "chart"
      }
    },
    {
      "id": "hover-card-src\\components\\ui\\hover-card",
      "name": "hover-card",
      "description": "Widget hover-card",
      "component": "src\\components\\ui\\hover-card.tsx",
      "slot": "workspace",
      "placement": {
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "resizable-src\\components\\ui\\resizable",
      "name": "resizable",
      "description": "Widget resizable",
      "component": "src\\components\\ui\\resizable.tsx",
      "slot": "rightPanel",
      "placement": {
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {},
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "display"
      }
    },
    {
      "id": "sidebar-src\\components\\ui\\sidebar",
      "name": "sidebar",
      "description": "This is the internal state of the sidebar.",
      "component": "src\\components\\ui\\sidebar.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 50,
        "size": "md"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "dashboard",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "form"
      }
    },
    {
      "id": "systemvalidation-src\\components\\validation\\SystemValidation",
      "name": "SystemValidation",
      "description": "Configuration states from KV",
      "component": "src\\components\\validation\\SystemValidation.tsx",
      "slot": "topbar",
      "placement": {
        "slot": "topbar",
        "priority": 25,
        "size": "sm"
      },
      "dataDeps": {
        "sseEvents": [
          "real-time-updates"
        ],
        "realTimeData": [
          "live-metrics",
          "real-time-data"
        ],
        "apis": [
          "/api/config",
          "/api/config"
        ]
      },
      "permissions": {
        "accessLevel": "authenticated"
      },
      "category": "monitoring",
      "enabled": true,
      "metadata": {
        "type": "widget",
        "widgetType": "metric"
      }
    },
    {
      "id": "admin-arbitrage",
      "name": "Arbitrage Admin",
      "description": "Panel de administración para arbitrage",
      "slot": "workspace",
      "placement": {
        "size": "lg",
        "priority": 20,
        "requiresAuth": true
      },
      "dataDeps": {
        "apis": [
          "/health",
          "/api/metrics",
          "/api/events",
          "/api/nodes",
          "/api/config",
          "/api/config",
          "/api/start",
          "/api/stop",
          "/api/status",
          "/api/stream",
          "/api/metrics/performance",
          "/api/metrics/financial",
          "/api/alerts"
        ]
      },
      "permissions": {
        "accessLevel": "admin",
        "roles": [
          "admin",
          "operator"
        ]
      },
      "category": "arbitrage",
      "enabled": true,
      "metadata": {
        "type": "admin-panel",
        "endpoints": 13,
        "methods": [
          "GET",
          "POST"
        ]
      }
    }
  ],
  "generatedAt": "2025-08-09T13:42:21.301Z",
  "hash": "a91f0a55dbde1b39c833852508428fef",
  "config": {
    "autoReload": true,
    "enabledSlots": [
      "topbar",
      "sidebar",
      "workspace",
      "rightPanel",
      "modals",
      "drawers",
      "toasts",
      "commandPalette",
      "footer"
    ],
    "defaultPermissions": {
      "accessLevel": "authenticated"
    }
  }
};

// Helper functions
export function getFeaturesBySlot(slot) {
  return autoFeatures.filter(feature => feature.slot === slot);
}

export function getFeaturesByCategory(category) {
  return autoFeatures.filter(feature => feature.category === category);
}

export function getFeatureById(id) {
  return autoFeatures.find(feature => feature.id === id);
}

export function getEnabledFeatures() {
  return autoFeatures.filter(feature => feature.enabled !== false);
}

export function getFeaturesWithRealTimeData() {
  return autoFeatures.filter(feature => 
    feature.dataDeps.realTimeData && feature.dataDeps.realTimeData.length > 0
  );
}

export function getMainPageFeatures() {
  return autoFeatures.filter(feature => feature.placement.isMainPage);
}

export function getFeaturesByPermissionLevel(level) {
  return autoFeatures.filter(feature => feature.permissions.accessLevel === level);
}

// Estadísticas
export const registryStats = {
  totalFeatures: 140,
  generatedAt: '2025-08-09T13:42:21.301Z',
  hash: 'a91f0a55dbde1b39c833852508428fef',
  bySlot: {
    "workspace": 35,
    "topbar": 93,
    "rightPanel": 11,
    "sidebar": 1
},
  byCategory: {
    "dashboard": 98,
    "arbitrage": 7,
    "security": 6,
    "monitoring": 29
}
};

// Command Palette Actions - Auto-generadas desde features
export const autoCommandActions = autoFeatures
  .filter(feature => feature.path || feature.component)
  .map(feature => ({
    id: `goto-${feature.id}`,
    label: `Ir a ${feature.name}`,
    description: feature.description,
    category: feature.category || 'navigation',
    keywords: [
      feature.name.toLowerCase(),
      feature.category || '',
      feature.slot,
      ...(feature.path?.split('/').filter(Boolean) || [])
    ],
    action: () => {
      if (feature.path) {
        window.location.href = feature.path;
      } else if (feature.component) {
        window.dispatchEvent(new CustomEvent('navigate-to-feature', { 
          detail: { featureId: feature.id, component: feature.component } 
        }));
      }
    },
    icon: feature.category === 'arbitrage' ? '⚡' :
          feature.category === 'monitoring' ? '📊' :
          feature.category === 'security' ? '🛡️' :
          feature.category === 'admin' ? '⚙️' : '📄',
    enabled: feature.enabled !== false
  }));

export default {
  features: autoFeatures,
  registry: featureRegistry,
  stats: registryStats,
  commands: autoCommandActions
};