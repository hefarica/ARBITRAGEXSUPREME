import { FigmaAPI } from 'figma-api';
import * as fs from 'fs';
import * as path from 'path';

export interface FigmaMCPServerConfig {
  accessToken: string;
  port?: number;
  assetsDir?: string;
}

export class FigmaMCPServer {
  private figma: FigmaAPI;
  private config: FigmaMCPServerConfig;
  private server: any;

  constructor(config: FigmaMCPServerConfig) {
    this.config = {
      port: 3001,
      assetsDir: 'frontend/images/figma-assets',
      ...config
    };
    
    this.figma = new FigmaAPI({ personalAccessToken: this.config.accessToken });
  }

  /**
   * Inicia el servidor MCP
   */
  async start(): Promise<void> {
    try {
      console.log('🚀 Iniciando servidor MCP de Figma...');
      console.log(`📍 Puerto: ${this.config.port}`);
      console.log(`📁 Directorio de assets: ${this.config.assetsDir}`);
      
      // Crear directorio de assets si no existe
      this.ensureAssetsDirectory();
      
      // Aquí implementarías la lógica del servidor MCP
      // Por ahora, solo simulamos el inicio
      console.log('✅ Servidor MCP de Figma iniciado correctamente');
      console.log('📡 Esperando conexiones...');
      
    } catch (error) {
      console.error('❌ Error iniciando servidor MCP:', error);
      throw error;
    }
  }

  /**
   * Asegura que el directorio de assets exista
   */
  private ensureAssetsDirectory(): void {
    const assetsPath = path.resolve(this.config.assetsDir!);
    if (!fs.existsSync(assetsPath)) {
      fs.mkdirSync(assetsPath, { recursive: true });
      console.log(`📁 Directorio de assets creado: ${assetsPath}`);
    }
  }

  /**
   * Obtiene información de un archivo de Figma
   */
  async getFileInfo(fileId: string): Promise<any> {
    try {
      const file = await this.figma.getFile(fileId);
      return {
        id: file.key,
        name: file.name,
        lastModified: file.lastModified,
        thumbnailUrl: file.thumbnailUrl || '',
        version: file.version,
        document: file.document
      };
    } catch (error) {
      console.error('Error obteniendo información del archivo:', error);
      throw error;
    }
  }

  /**
   * Obtiene componentes de un archivo
   */
  async getComponents(fileId: string): Promise<any[]> {
    try {
      const file = await this.figma.getFile(fileId);
      const components: any[] = [];
      
      const findComponents = (node: any) => {
        if (node.type === 'COMPONENT' || node.type === 'COMPONENT_SET') {
          components.push({
            id: node.id,
            name: node.name,
            description: node.description || '',
            key: node.key,
            type: node.type
          });
        }
        
        if (node.children) {
          node.children.forEach(findComponents);
        }
      };
      
      if (file.document) {
        findComponents(file.document);
      }
      
      return components;
    } catch (error) {
      console.error('Error obteniendo componentes:', error);
      throw error;
    }
  }

  /**
   * Obtiene assets de componentes específicos
   */
  async getAssets(fileId: string, nodeIds: string[], format: 'png' | 'jpg' | 'svg' | 'pdf' = 'png', scale: number = 1): Promise<any[]> {
    try {
      const images = await this.figma.getImage(fileId, {
        ids: nodeIds,
        format,
        scale
      });

      return Object.entries(images.images).map(([id, url]) => ({
        id,
        name: `asset_${id}`,
        url,
        format,
        scale
      }));
    } catch (error) {
      console.error('Error obteniendo assets:', error);
      throw error;
    }
  }

  /**
   * Descarga y guarda un asset
   */
  async downloadAsset(asset: any, outputPath: string): Promise<string> {
    try {
      const response = await fetch(asset.url);
      const buffer = await response.arrayBuffer();
      
      // Asegurar que el directorio existe
      const dir = path.dirname(outputPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      // Guardar archivo
      fs.writeFileSync(outputPath, Buffer.from(buffer));
      
      return outputPath;
    } catch (error) {
      console.error('Error descargando asset:', error);
      throw error;
    }
  }

  /**
   * Sincroniza todos los assets de un archivo
   */
  async syncAssets(fileId: string): Promise<{ success: boolean; message: string; assetsCount: number }> {
    try {
      console.log(`🔄 Sincronizando assets del archivo ${fileId}...`);
      
      // Obtener componentes
      const components = await this.getComponents(fileId);
      console.log(`📋 Encontrados ${components.length} componentes`);
      
      if (components.length === 0) {
        return {
          success: true,
          message: 'No hay componentes para sincronizar',
          assetsCount: 0
        };
      }
      
      // Obtener assets
      const nodeIds = components.map(c => c.id);
      const assets = await this.getAssets(fileId, nodeIds, 'png', 2);
      console.log(`🖼️  Encontrados ${assets.length} assets`);
      
      // Descargar cada asset
      let downloadedCount = 0;
      for (const asset of assets) {
        const fileName = `${asset.name}_${asset.id}.${asset.format}`;
        const outputPath = path.join(this.config.assetsDir!, fileName);
        
        await this.downloadAsset(asset, outputPath);
        downloadedCount++;
        console.log(`✅ Asset descargado: ${fileName}`);
      }
      
      console.log(`🎉 Sincronización completada: ${downloadedCount} assets descargados`);
      
      return {
        success: true,
        message: `Sincronización completada: ${downloadedCount} assets descargados`,
        assetsCount: downloadedCount
      };
      
    } catch (error) {
      console.error('Error en sincronización:', error);
      return {
        success: false,
        message: `Error en sincronización: ${error}`,
        assetsCount: 0
      };
    }
  }

  /**
   * Busca componentes por nombre
   */
  async searchComponents(fileId: string, searchTerm: string): Promise<any[]> {
    const components = await this.getComponents(fileId);
    return components.filter(component => 
      component.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  /**
   * Obtiene estadísticas del archivo
   */
  async getFileStats(fileId: string): Promise<any> {
    try {
      const fileInfo = await this.getFileInfo(fileId);
      const components = await this.getComponents(fileId);
      
      return {
        totalComponents: components.length,
        totalPages: 1,
        lastModified: fileInfo.lastModified,
        fileSize: 'N/A'
      };
    } catch (error) {
      throw new Error(`Error obteniendo estadísticas: ${error}`);
    }
  }

  /**
   * Detiene el servidor
   */
  async stop(): Promise<void> {
    try {
      if (this.server) {
        // Lógica para detener el servidor
        console.log('🛑 Servidor MCP de Figma detenido');
      }
    } catch (error) {
      console.error('Error deteniendo servidor:', error);
    }
  }
}
