const { Api } = require('figma-api');
const fs = require('fs');
const path = require('path');

class FigmaMCPServer {
  constructor(config) {
    this.config = {
      port: 3001,
      assetsDir: 'frontend/images/figma-assets',
      ...config
    };
    
    this.figma = new Api({ personalAccessToken: this.config.accessToken });
    this.server = null;
  }

  /**
   * Inicia el servidor MCP
   */
  async start() {
    try {
      console.log('🚀 Iniciando servidor MCP de Figma...');
      console.log(`📍 Puerto: ${this.config.port}`);
      console.log(`📁 Directorio de assets: ${this.config.assetsDir}`);
      
      // Crear directorio de assets si no existe
      this.ensureAssetsDirectory();
      
      // Aquí implementarías la lógica del servidor MCP
      // Por ahora, solo simulamos el inicio
      console.log('✅ Servidor MCP de Figma iniciado correctamente');
      console.log('📡 Esperando conexiones...');
      
    } catch (error) {
      console.error('❌ Error iniciando servidor MCP:', error);
      throw error;
    }
  }

  /**
   * Asegura que el directorio de assets exista
   */
  ensureAssetsDirectory() {
    const assetsPath = path.resolve(this.config.assetsDir);
    if (!fs.existsSync(assetsPath)) {
      fs.mkdirSync(assetsPath, { recursive: true });
      console.log(`📁 Directorio de assets creado: ${assetsPath}`);
    }
  }

  /**
   * Obtiene información de un archivo de Figma
   */
  async getFileInfo(fileId) {
    try {
      // Usar fetch directamente en lugar de la librería problemática
      const response = await fetch(`https://api.figma.com/v1/files/${fileId}`, {
        method: 'GET',
        headers: {
          'X-Figma-Token': this.config.accessToken,
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const file = await response.json();
      return {
        id: file.key,
        name: file.name,
        lastModified: file.lastModified,
        thumbnailUrl: file.thumbnailUrl || '',
        version: file.version,
        document: file.document
      };
    } catch (error) {
      console.error('Error obteniendo información del archivo:', error);
      throw error;
    }
  }

  /**
   * Obtiene componentes de un archivo
   */
  async getComponents(fileId) {
    try {
      // Usar fetch directamente en lugar de la librería problemática
      const response = await fetch(`https://api.figma.com/v1/files/${fileId}`, {
        method: 'GET',
        headers: {
          'X-Figma-Token': this.config.accessToken,
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const file = await response.json();
      const components = [];
      
      const findComponents = (node) => {
        if (node.type === 'COMPONENT' || node.type === 'COMPONENT_SET') {
          components.push({
            id: node.id,
            name: node.name,
            description: node.description || '',
            key: node.key,
            type: node.type
          });
        }
        
        if (node.children) {
          node.children.forEach(findComponents);
        }
      };
      
      if (file.document) {
        findComponents(file.document);
      }
      
      return components;
    } catch (error) {
      console.error('Error obteniendo componentes:', error);
      throw error;
    }
  }

  /**
   * Obtiene assets de componentes específicos
   */
  async getAssets(fileId, nodeIds, format = 'png', scale = 1) {
    try {
      // Usar fetch directamente en lugar de la librería problemática
      const params = new URLSearchParams({
        ids: nodeIds.join(','),
        format,
        scale: scale.toString()
      });
      
      const response = await fetch(`https://api.figma.com/v1/images/${fileId}?${params}`, {
        method: 'GET',
        headers: {
          'X-Figma-Token': this.config.accessToken,
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const images = await response.json();

      return Object.entries(images.images).map(([id, url]) => ({
        id,
        name: `asset_${id}`,
        url,
        format,
        scale
      }));
    } catch (error) {
      console.error('Error obteniendo assets:', error);
      throw error;
    }
  }

  /**
   * Descarga y guarda un asset
   */
  async downloadAsset(asset, outputPath) {
    try {
      const response = await fetch(asset.url);
      const buffer = await response.arrayBuffer();
      
      // Asegurar que el directorio existe
      const dir = path.dirname(outputPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      // Guardar archivo
      fs.writeFileSync(outputPath, Buffer.from(buffer));
      
      return outputPath;
    } catch (error) {
      console.error('Error descargando asset:', error);
      throw error;
    }
  }

  /**
   * Sincroniza todos los assets de un archivo
   */
  async syncAssets(fileId) {
    try {
      console.log(`🔄 Sincronizando assets del archivo ${fileId}...`);
      
      // Obtener componentes
      const components = await this.getComponents(fileId);
      console.log(`📋 Encontrados ${components.length} componentes`);
      
      if (components.length === 0) {
        return {
          success: true,
          message: 'No hay componentes para sincronizar',
          assetsCount: 0
        };
      }
      
      // Obtener assets
      const nodeIds = components.map(c => c.id);
      const assets = await this.getAssets(fileId, nodeIds, 'png', 2);
      console.log(`🖼️  Encontrados ${assets.length} assets`);
      
      // Descargar cada asset
      let downloadedCount = 0;
      for (const asset of assets) {
        const fileName = `${asset.name}_${asset.id}.${asset.format}`;
        const outputPath = path.join(this.config.assetsDir, fileName);
        
        await this.downloadAsset(asset, outputPath);
        downloadedCount++;
        console.log(`✅ Asset descargado: ${fileName}`);
      }
      
      console.log(`🎉 Sincronización completada: ${downloadedCount} assets descargados`);
      
      return {
        success: true,
        message: `Sincronización completada: ${downloadedCount} assets descargados`,
        assetsCount: downloadedCount
      };
      
    } catch (error) {
      console.error('Error en sincronización:', error);
      return {
        success: false,
        message: `Error en sincronización: ${error}`,
        assetsCount: 0
      };
    }
  }

  /**
   * Busca componentes por nombre
   */
  async searchComponents(fileId, searchTerm) {
    const components = await this.getComponents(fileId);
    return components.filter(component => 
      component.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  /**
   * Obtiene estadísticas del archivo
   */
  async getFileStats(fileId) {
    try {
      const fileInfo = await this.getFileInfo(fileId);
      const components = await this.getComponents(fileId);
      
      return {
        totalComponents: components.length,
        totalPages: 1,
        lastModified: fileInfo.lastModified,
        fileSize: 'N/A'
      };
    } catch (error) {
      throw new Error(`Error obteniendo estadísticas: ${error}`);
    }
  }

  /**
   * Detiene el servidor
   */
  async stop() {
    try {
      if (this.server) {
        // Lógica para detener el servidor
        console.log('🛑 Servidor MCP de Figma detenido');
      }
    } catch (error) {
      console.error('Error deteniendo servidor:', error);
    }
  }
}

module.exports = { FigmaMCPServer };
