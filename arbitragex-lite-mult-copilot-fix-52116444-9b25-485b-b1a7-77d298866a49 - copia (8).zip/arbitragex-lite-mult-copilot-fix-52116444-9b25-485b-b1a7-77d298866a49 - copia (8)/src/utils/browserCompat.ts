/**
 * Browser-safe security module wrapper
 * Provides stub implementations of security modules for browser compatibility
 */

// Browser-safe memory usage function
const getBrowserMemoryUsage = () => {
  if (typeof performance !== 'undefined' && (performance as any).memory) {
    const memory = (performance as any).memory;
    return {
      rss: memory.totalJSHeapSize || 0,
      heapTotal: memory.totalJSHeapSize || 0,
      heapUsed: memory.usedJSHeapSize || 0,
      external: 0,
      arrayBuffers: 0
    };
  }
  return {
    rss: 0,
    heapTotal: 0,
    heapUsed: 0,
    external: 0,
    arrayBuffers: 0
  };
};

// Browser-safe CPU usage function
const getBrowserCPUUsage = () => {
  return {
    user: Date.now() * 1000, // Convert to microseconds
    system: 0
  };
};

// Add safe wrappers to the process polyfill
if (typeof process !== 'undefined') {
  if (!process.memoryUsage) {
    process.memoryUsage = getBrowserMemoryUsage;
  }
  if (!process.cpuUsage) {
    process.cpuUsage = getBrowserCPUUsage;
  }
}

export { getBrowserMemoryUsage, getBrowserCPUUsage };