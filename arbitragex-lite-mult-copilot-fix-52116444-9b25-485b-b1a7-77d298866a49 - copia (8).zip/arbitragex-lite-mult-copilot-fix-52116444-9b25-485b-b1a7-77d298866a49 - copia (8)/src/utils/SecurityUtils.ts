import DOMPurify from 'dompurify'

/**
 * @title SecurityUtils
 * @description Utilidades de seguridad para prevenir XSS, CSRF y otras vulnerabilidades
 * @author ArbitrageX Security Team 2025
 */
export class SecurityUtils {
  /**
   * Sanitizar input para prevenir XSS
   */
  public static sanitizeInput(input: string): string {
    if (!input) return ''
    
    // Usar DOMPurify para sanitización
    const sanitized = DOMPurify.sanitize(input, {
      ALLOWED_TAGS: [],
      ALLOWED_ATTR: [],
      KEEP_CONTENT: true
    })
    
    return sanitized.trim()
  }

  /**
   * Sanitizar input HTML permitiendo tags específicos
   */
  public static sanitizeHTML(input: string, allowedTags: string[] = ['b', 'i', 'em', 'strong']): string {
    if (!input) return ''
    
    const sanitized = DOMPurify.sanitize(input, {
      ALLOWED_TAGS: allowedTags,
      ALLOWED_ATTR: ['class'],
      KEEP_CONTENT: true
    })
    
    return sanitized.trim()
  }

  /**
   * Validar y sanitizar números
   */
  public static sanitizeNumber(input: string | number): number | null {
    if (typeof input === 'number') {
      return isFinite(input) ? input : null
    }
    
    if (typeof input === 'string') {
      const sanitized = input.replace(/[^0-9.-]/g, '')
      const num = parseFloat(sanitized)
      return isFinite(num) ? num : null
    }
    
    return null
  }

  /**
   * Validar y sanitizar email
   */
  public static sanitizeEmail(input: string): string | null {
    if (!input) return null
    
    const sanitized = input.trim().toLowerCase()
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    
    return emailRegex.test(sanitized) ? sanitized : null
  }

  /**
   * Validar y sanitizar URL
   */
  public static sanitizeURL(input: string): string | null {
    if (!input) return null
    
    const sanitized = input.trim()
    
    try {
      const url = new URL(sanitized)
      // Solo permitir HTTPS en producción
      if (process.env.NODE_ENV === 'production' && url.protocol !== 'https:') {
        return null
      }
      return sanitized
    } catch {
      return null
    }
  }

  /**
   * Generar token CSRF
   */
  public static generateCSRFToken(): string {
    const array = new Uint8Array(32)
    crypto.getRandomValues(array)
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('')
  }

  /**
   * Validar token CSRF
   */
  public static validateCSRFToken(token: string, storedToken: string): boolean {
    if (!token || !storedToken) return false
    return token === storedToken
  }

  /**
   * Validar input contra patrones maliciosos
   */
  public static validateInput(input: string): { isValid: boolean; reason?: string } {
    if (!input) {
      return { isValid: false, reason: 'Input vacío' }
    }

    // Patrones maliciosos comunes
    const maliciousPatterns = [
      /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
      /javascript:/gi,
      /on\w+\s*=/gi,
      /data:text\/html/gi,
      /vbscript:/gi,
      /<iframe/gi,
      /<object/gi,
      /<embed/gi
    ]

    for (const pattern of maliciousPatterns) {
      if (pattern.test(input)) {
        return { isValid: false, reason: 'Patrón malicioso detectado' }
      }
    }

    return { isValid: true }
  }

  /**
   * Validar y sanitizar JSON
   */
  public static sanitizeJSON(input: string): any | null {
    if (!input) return null
    
    try {
      const parsed = JSON.parse(input)
      return this.deepSanitizeObject(parsed)
    } catch {
      return null
    }
  }

  /**
   * Sanitizar objeto completo recursivamente
   */
  private static deepSanitizeObject(obj: any): any {
    if (obj === null || obj === undefined) {
      return obj
    }

    if (typeof obj === 'string') {
      return this.sanitizeInput(obj)
    }

    if (typeof obj === 'number') {
      return this.sanitizeNumber(obj)
    }

    if (Array.isArray(obj)) {
      return obj.map(item => this.deepSanitizeObject(item))
    }

    if (typeof obj === 'object') {
      const sanitized: any = {}
      for (const [key, value] of Object.entries(obj)) {
        const sanitizedKey = this.sanitizeInput(key)
        if (sanitizedKey) {
          sanitized[sanitizedKey] = this.deepSanitizeObject(value)
        }
      }
      return sanitized
    }

    return obj
  }

  /**
   * Validar y sanitizar parámetros de URL
   */
  public static sanitizeURLParams(params: Record<string, string>): Record<string, string> {
    const sanitized: Record<string, string> = {}
    
    for (const [key, value] of Object.entries(params)) {
      const sanitizedKey = this.sanitizeInput(key)
      const sanitizedValue = this.sanitizeInput(value)
      
      if (sanitizedKey && sanitizedValue) {
        sanitized[sanitizedKey] = sanitizedValue
      }
    }
    
    return sanitized
  }

  /**
   * Validar y sanitizar headers HTTP
   */
  public static sanitizeHeaders(headers: Record<string, string>): Record<string, string> {
    const sanitized: Record<string, string> = {}
    
    for (const [key, value] of Object.entries(headers)) {
      const sanitizedKey = this.sanitizeInput(key)
      const sanitizedValue = this.sanitizeInput(value)
      
      if (sanitizedKey && sanitizedValue) {
        sanitized[sanitizedKey] = sanitizedValue
      }
    }
    
    return sanitized
  }

  /**
   * Validar y sanitizar datos de formulario
   */
  public static sanitizeFormData(formData: FormData): Record<string, any> {
    const sanitized: Record<string, any> = {}
    
    for (const [key, value] of formData.entries()) {
      const sanitizedKey = this.sanitizeInput(key)
      
      if (sanitizedKey) {
        if (typeof value === 'string') {
          sanitized[sanitizedKey] = this.sanitizeInput(value)
        } else if (value instanceof File) {
          // Validar archivo
          const isValidFile = this.validateFile(value)
          if (isValidFile.isValid) {
            sanitized[sanitizedKey] = value
          }
        }
      }
    }
    
    return sanitized
  }

  /**
   * Validar archivo
   */
  public static validateFile(file: File): { isValid: boolean; reason?: string } {
    // Tamaño máximo: 10MB
    const maxSize = 10 * 1024 * 1024
    
    if (file.size > maxSize) {
      return { isValid: false, reason: 'Archivo demasiado grande' }
    }

    // Tipos de archivo permitidos
    const allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'application/pdf',
      'text/plain',
      'application/json'
    ]

    if (!allowedTypes.includes(file.type)) {
      return { isValid: false, reason: 'Tipo de archivo no permitido' }
    }

    return { isValid: true }
  }

  /**
   * Generar hash seguro para archivos
   */
  public static async generateFileHash(file: File): Promise<string> {
    const buffer = await file.arrayBuffer()
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
  }

  /**
   * Validar y sanitizar datos de configuración de riesgo
   */
  public static sanitizeRiskConfig(config: any): any {
    const sanitized = { ...config }
    
    // Sanitizar valores numéricos
    if (sanitized.maxAccountExposure) {
      const exposure = this.sanitizeNumber(sanitized.maxAccountExposure)
      sanitized.maxAccountExposure = exposure !== null ? Math.min(Math.max(exposure, 0), 100) : 25
    }
    
    if (sanitized.maxTransactionRisk) {
      const risk = this.sanitizeNumber(sanitized.maxTransactionRisk)
      sanitized.maxTransactionRisk = risk !== null ? Math.min(Math.max(risk, 0), 50) : 5
    }
    
    if (sanitized.maxROIRisk) {
      const roiRisk = this.sanitizeNumber(sanitized.maxROIRisk)
      sanitized.maxROIRisk = roiRisk !== null ? Math.min(Math.max(roiRisk, 0), 100) : 60
    }
    
    if (sanitized.maxDailyLoss) {
      const dailyLoss = this.sanitizeNumber(sanitized.maxDailyLoss)
      sanitized.maxDailyLoss = dailyLoss !== null ? Math.min(Math.max(dailyLoss, 0), 20) : 2.5
    }
    
    // Sanitizar strings
    if (sanitized.name) {
      sanitized.name = this.sanitizeInput(sanitized.name)
    }
    
    if (sanitized.description) {
      sanitized.description = this.sanitizeInput(sanitized.description)
    }
    
    return sanitized
  }

  /**
   * Validar y sanitizar datos de Kelly Criterion
   */
  public static sanitizeKellyConfig(config: any): any {
    const sanitized = { ...config }
    
    if (sanitized.winRate) {
      const winRate = this.sanitizeNumber(sanitized.winRate)
      sanitized.winRate = winRate !== null ? Math.min(Math.max(winRate, 0), 100) : 75
    }
    
    if (sanitized.avgWin) {
      const avgWin = this.sanitizeNumber(sanitized.avgWin)
      sanitized.avgWin = avgWin !== null ? Math.min(Math.max(avgWin, 0), 20) : 3.5
    }
    
    if (sanitized.avgLoss) {
      const avgLoss = this.sanitizeNumber(sanitized.avgLoss)
      sanitized.avgLoss = avgLoss !== null ? Math.min(Math.max(avgLoss, 0), 10) : 1.2
    }
    
    return sanitized
  }

  /**
   * Log de eventos de seguridad
   */
  public static logSecurityEvent(event: string, details: any): void {
    const securityLog = {
      timestamp: new Date().toISOString(),
      event,
      details,
      userAgent: typeof window !== 'undefined' ? window.navigator.userAgent : 'server',
      ip: 'client-ip', // Se debe obtener del request
      sessionId: 'session-id' // Se debe obtener del contexto
    }
    
    console.warn('Security Event:', securityLog)
    
    // Aquí se enviaría a un sistema de logging de seguridad
    // como Splunk, ELK Stack, o similar
  }
} 