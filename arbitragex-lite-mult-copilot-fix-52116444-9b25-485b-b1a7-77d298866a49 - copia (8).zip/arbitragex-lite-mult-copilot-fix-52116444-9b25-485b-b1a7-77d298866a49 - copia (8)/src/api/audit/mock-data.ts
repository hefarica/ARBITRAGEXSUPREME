// api/audit/mock-data.ts
/**
 * API endpoint para ejecutar auditoría de datos mock
 * Integra con el Truth Guard real-time auditor
 */

import { NextApiRequest, NextApiResponse } from 'next';
import { spawn } from 'child_process';
import path from 'path';

interface AuditRequest {
  scanType: 'full' | 'incremental' | 'realtime';
  projectRoot?: string;
  watchMode?: boolean;
}

interface AuditResponse {
  success: boolean;
  timestamp: number;
  totalGaps: number;
  newGaps: number;
  gaps: MockDataGap[];
  error?: string;
}

interface MockDataGap {
  file: string;
  key: string;
  serviceNeeded: string;
  origin: 'config' | 'code';
  line: number;
  value?: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<AuditResponse>
) {
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      timestamp: Date.now(),
      totalGaps: 0,
      newGaps: 0,
      gaps: [],
      error: 'Method not allowed'
    });
  }

  try {
    const { scanType, projectRoot, watchMode }: AuditRequest = req.body;
    
    // Determinar la ruta del proyecto
    const rootPath = projectRoot || process.cwd();
    const auditorScript = path.join(process.cwd(), 'scripts', 'mock-data-auditor.js');
    
    // Construir argumentos para el auditor
    const args = [auditorScript];
    if (watchMode) {
      args.push('--watch');
    }
    args.push('--json');
    args.push('/tmp/audit-report.json');
    args.push(rootPath);

    // Ejecutar el auditor
    const auditResults = await executeAuditor(args);
    
    return res.status(200).json({
      success: true,
      timestamp: Date.now(),
      totalGaps: auditResults.totalGaps,
      newGaps: auditResults.newGaps,
      gaps: auditResults.gaps
    });

  } catch (error) {
    console.error('Error en auditoría de mock data:', error);
    
    return res.status(500).json({
      success: false,
      timestamp: Date.now(),
      totalGaps: 0,
      newGaps: 0,
      gaps: [],
      error: error instanceof Error ? error.message : 'Error desconocido'
    });
  }
}

async function executeAuditor(args: string[]): Promise<AuditResponse> {
  return new Promise((resolve, reject) => {
    const auditor = spawn('node', args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      cwd: process.cwd()
    });

    let stdout = '';
    let stderr = '';

    auditor.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    auditor.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    auditor.on('close', (code) => {
      if (code === 0) {
        try {
          // Intentar leer el archivo JSON de resultados
          const fs = require('fs');
          const reportPath = '/tmp/audit-report.json';
          
          if (fs.existsSync(reportPath)) {
            const reportData = JSON.parse(fs.readFileSync(reportPath, 'utf8'));
            resolve(reportData);
          } else {
            // Si no hay archivo, asumir que no hay gaps
            resolve({
              success: true,
              timestamp: Date.now(),
              totalGaps: 0,
              newGaps: 0,
              gaps: []
            });
          }
        } catch (parseError) {
          reject(new Error(`Error parsing audit results: ${parseError}`));
        }
      } else {
        reject(new Error(`Audit failed with code ${code}: ${stderr}`));
      }
    });

    auditor.on('error', (error) => {
      reject(new Error(`Failed to start auditor: ${error.message}`));
    });
  });
}