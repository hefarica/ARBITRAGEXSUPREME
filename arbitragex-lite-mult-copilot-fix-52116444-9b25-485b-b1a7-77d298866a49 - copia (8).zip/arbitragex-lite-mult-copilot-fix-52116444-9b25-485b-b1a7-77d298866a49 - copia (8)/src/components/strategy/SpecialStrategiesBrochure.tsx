import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Crown, 
  Star, 
  Rocket, 
  Lightning, 
  Target, 
  TrendUp, 
  Globe,
  Shield,
  Zap,
  Coins,
  ChartLine,
  ArrowRight,
  CheckCircle,
  Warning,
  Brain,
  Timer,
  Wallet
} from '@phosphor-icons/react'

interface SpecialStrategiesBrochureProps {
  onActivateStrategies: () => void
}

const SPECIAL_STRATEGIES_HIGHLIGHTS = [
  {
    id: 'cross-chain-multi-hop-flash-loan',
    name: 'Cross-Chain Multi-Hop Flash-Loan',
    roi: '15-25%',
    icon: '🚀',
    description: 'La estrategia más avanzada que combina flash loans con arbitraje multi-salto cross-chain',
    features: ['8 Blockchains', 'Flash Loans', 'MEV Protection', 'Ultra Baja Latencia'],
    complexity: 'Expert',
    capital: '$50K-$500K',
    time: '45-90s'
  },
  {
    id: 'cross-chain-cross-dex',
    name: 'Cross-Chain Cross-DEX',
    roi: '12-20%',
    icon: '🔗',
    description: 'Arbitraje directo entre DEXs de diferentes blockchains',
    features: ['Cross-Chain', 'Multi-DEX', 'MEV Protection', 'Alto ROI'],
    complexity: 'Advanced',
    capital: '$25K-$200K',
    time: '30-60s'
  },
  {
    id: 'flash-loan-triangular-cross-dex',
    name: 'Flash-Loan Triangular Cross-DEX',
    roi: '10-18%',
    icon: '📐',
    description: 'Arbitraje triangular usando flash loans entre múltiples DEXs',
    features: ['Triangular', 'Flash Loans', 'Multi-DEX', 'Protección Avanzada'],
    complexity: 'Advanced',
    capital: '$20K-$300K',
    time: '25-45s'
  }
]

const BLOCKCHAINS_SUPPORTED = [
  { name: 'Ethereum', icon: '🔵', status: 'active' },
  { name: 'Polygon', icon: '🟣', status: 'active' },
  { name: 'BSC', icon: '🟡', status: 'active' },
  { name: 'Arbitrum', icon: '🔵', status: 'active' },
  { name: 'Optimism', icon: '🔴', status: 'active' },
  { name: 'Avalanche', icon: '🔴', status: 'active' },
  { name: 'Fantom', icon: '🔵', status: 'active' },
  { name: 'Cronos', icon: '🟢', status: 'active' }
]

export default function SpecialStrategiesBrochure({ onActivateStrategies }: SpecialStrategiesBrochureProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <div className="space-y-6">
      {/* Header Principal */}
      <Card className="bg-gradient-to-r from-yellow-500/10 via-orange-500/10 to-red-500/10 border-yellow-500/20">
        <CardContent className="p-8">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Crown className="h-8 w-8 text-yellow-500" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-500 to-orange-500 bg-clip-text text-transparent">
                ESTRATEGIAS ESPECIALES PRO 2025
              </h1>
              <Star className="h-8 w-8 text-yellow-500" />
            </div>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Descubre las estrategias de arbitraje más avanzadas del mercado. 
              Diseñadas para maximizar tu ROI con protección MEV integrada y soporte para 8 blockchains principales.
            </p>
            <div className="flex items-center justify-center gap-4 mt-6">
              <Badge className="bg-yellow-500 text-white px-4 py-2 text-lg">
                <Star className="h-4 w-4 mr-2" />
                ESTRATEGIAS ESPECIALES
              </Badge>
              <Badge variant="outline" className="px-4 py-2 text-lg">
                <Globe className="h-4 w-4 mr-2" />
                8 BLOCKCHAINS
              </Badge>
              <Badge variant="outline" className="px-4 py-2 text-lg">
                <Shield className="h-4 w-4 mr-2" />
                MEV PROTECTION
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estrategias Destacadas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {SPECIAL_STRATEGIES_HIGHLIGHTS.map((strategy) => (
          <Card key={strategy.id} className="relative overflow-hidden border-yellow-500/30 bg-gradient-to-br from-yellow-50/50 to-orange-50/50 dark:from-yellow-900/10 dark:to-orange-900/10">
            <div className="absolute -top-2 -right-2">
              <Badge className="bg-yellow-500 text-white text-xs">
                <Star className="h-3 w-3 mr-1" />
                ESPECIAL
              </Badge>
            </div>
            <CardHeader className="text-center">
              <div className="text-4xl mb-2">{strategy.icon}</div>
              <CardTitle className="text-lg">{strategy.name}</CardTitle>
              <CardDescription>{strategy.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* ROI Destacado */}
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">{strategy.roi}</div>
                <div className="text-sm text-muted-foreground">ROI Esperado</div>
              </div>

              {/* Características */}
              <div className="space-y-2">
                {strategy.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              {/* Detalles */}
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="text-center p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                  <div className="font-semibold text-blue-600">{strategy.complexity}</div>
                  <div className="text-muted-foreground">Complejidad</div>
                </div>
                <div className="text-center p-2 bg-green-50 dark:bg-green-900/20 rounded">
                  <div className="font-semibold text-green-600">{strategy.capital}</div>
                  <div className="text-muted-foreground">Capital</div>
                </div>
                <div className="text-center p-2 bg-purple-50 dark:bg-purple-900/20 rounded">
                  <div className="font-semibold text-purple-600">{strategy.time}</div>
                  <div className="text-muted-foreground">Tiempo</div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Blockchains Soportadas */}
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2">
            <Globe className="h-6 w-6" />
            Blockchains Soportadas
          </CardTitle>
          <CardDescription>
            Todas las estrategias especiales funcionan en las 8 principales blockchains
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {BLOCKCHAINS_SUPPORTED.map((blockchain) => (
              <div key={blockchain.name} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                <span className="text-2xl">{blockchain.icon}</span>
                <div>
                  <div className="font-semibold">{blockchain.name}</div>
                  <div className="text-xs text-green-600 flex items-center gap-1">
                    <CheckCircle className="h-3 w-3" />
                    Activo
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-blue-600">5</div>
            <div className="text-sm text-muted-foreground">Estrategias Especiales</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-green-600">15-25%</div>
            <div className="text-sm text-muted-foreground">ROI Máximo</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-purple-600">8</div>
            <div className="text-sm text-muted-foreground">Blockchains</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-orange-600">&lt;100μs</div>
            <div className="text-sm text-muted-foreground">Latencia</div>
          </CardContent>
        </Card>
      </div>

      {/* Características Avanzadas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-6 w-6" />
            Características Avanzadas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Shield className="h-5 w-5 text-green-500 mt-1" />
                <div>
                  <h4 className="font-semibold">Protección MEV Integrada</h4>
                  <p className="text-sm text-muted-foreground">
                    Flashbots y técnicas avanzadas para evitar front-running y sandwich attacks
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Zap className="h-5 w-5 text-blue-500 mt-1" />
                <div>
                  <h4 className="font-semibold">Flash Loans Automáticos</h4>
                  <p className="text-sm text-muted-foreground">
                    Ejecución automática de flash loans para arbitraje sin capital inicial
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Globe className="h-5 w-5 text-purple-500 mt-1" />
                <div>
                  <h4 className="font-semibold">Cross-Chain Arbitrage</h4>
                  <p className="text-sm text-muted-foreground">
                    Arbitraje entre diferentes blockchains para maximizar oportunidades
                  </p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Timer className="h-5 w-5 text-orange-500 mt-1" />
                <div>
                  <h4 className="font-semibold">Ultra Baja Latencia</h4>
                  <p className="text-sm text-muted-foreground">
                    Ejecución en menos de 100 microsegundos para capturar oportunidades rápidas
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ChartLine className="h-5 w-5 text-green-500 mt-1" />
                <div>
                  <h4 className="font-semibold">Análisis Predictivo</h4>
                  <p className="text-sm text-muted-foreground">
                    IA avanzada para predecir y optimizar oportunidades de arbitraje
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Wallet className="h-5 w-5 text-yellow-500 mt-1" />
                <div>
                  <h4 className="font-semibold">Gestión de Riesgo</h4>
                  <p className="text-sm text-muted-foreground">
                    Sistema inteligente de gestión de riesgo con stop-loss automático
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Call to Action */}
      <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/20">
        <CardContent className="p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">¿Listo para Activar las Estrategias Especiales?</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Accede a las estrategias más avanzadas de arbitraje DeFi. 
            Configura tus parámetros de riesgo y comienza a maximizar tus ganancias.
          </p>
          <div className="flex items-center justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
              onClick={onActivateStrategies}
            >
              <Rocket className="h-5 w-5 mr-2" />
              Activar Estrategias Especiales
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>
          <div className="mt-4 text-sm text-muted-foreground">
            <Warning className="h-4 w-4 inline mr-1" />
            Las estrategias especiales requieren configuración de riesgo y capital mínimo
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 