import React, { useState, useEffect } from 'react'
import { ethers } from 'ethers'
import { StrategyViabilityService, StrategyViabilityReport } from '../../services/StrategyViabilityService'
import { BlockchainGasProfile } from '../../core/types'

/**
 * Dashboard que muestra la viabilidad real de las 8 estrategias de arbitraje
 * Integra costos de gas, slippage y rentabilidad neta por blockchain
 */
export const StrategyViabilityDashboard: React.FC = () => {
  const [reports, setReports] = useState<StrategyViabilityReport[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null)
  const [gasProfiles, setGasProfiles] = useState<Map<number, BlockchainGasProfile>>(new Map())

  useEffect(() => {
    initializeDashboard()
  }, [])

  const initializeDashboard = async () => {
    try {
      setLoading(true)
      
      // Crear provider de ejemplo (en producción usar providers reales)
      const provider = new ethers.providers.JsonRpcProvider('https://eth-mainnet.alchemyapi.io/v2/demo')
      
      const service = new StrategyViabilityService()
      const strategyReports = await service.evaluateAllStrategies(provider)
      
      setReports(strategyReports)
      
      // Obtener perfiles de gas
      const profiles = new Map<number, BlockchainGasProfile>()
      for (const report of strategyReports) {
        for (const blockchainReport of report.blockchainReports) {
          profiles.set(blockchainReport.chainId, blockchainReport.gasProfile)
        }
      }
      setGasProfiles(profiles)
      
    } catch (error) {
      console.error('Error inicializando dashboard:', error)
    } finally {
      setLoading(false)
    }
  }

  const getViabilityColor = (score: number): string => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    if (score >= 40) return 'text-orange-600'
    return 'text-red-600'
  }

  const getRiskColor = (level: string): string => {
    switch (level) {
      case 'low': return 'text-green-600'
      case 'medium': return 'text-yellow-600'
      case 'high': return 'text-orange-600'
      case 'extreme': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const getEfficiencyColor = (efficiency: string): string => {
    switch (efficiency) {
      case 'very-high': return 'text-green-600'
      case 'high': return 'text-blue-600'
      case 'medium': return 'text-yellow-600'
      case 'low': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Dashboard de Viabilidad de Estrategias de Arbitraje
          </h1>
          <p className="text-gray-600">
            Análisis real de rentabilidad considerando costos de gas, slippage y viabilidad por blockchain
          </p>
        </div>

        {/* Resumen General */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Estrategias Viable</h3>
            <p className="text-3xl font-bold text-green-600">
              {reports.filter(r => r.overallViabilityScore >= 70).length}
            </p>
            <p className="text-sm text-gray-500">de {reports.length} total</p>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Blockchains Soportadas</h3>
            <p className="text-3xl font-bold text-blue-600">{gasProfiles.size}</p>
            <p className="text-sm text-gray-500">redes analizadas</p>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Score Promedio</h3>
            <p className="text-3xl font-bold text-purple-600">
              {Math.round(reports.reduce((sum, r) => sum + r.overallViabilityScore, 0) / reports.length)}
            </p>
            <p className="text-sm text-gray-500">viabilidad general</p>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Mejor Estrategia</h3>
            <p className="text-xl font-bold text-green-600">
              {reports[0]?.strategy.name || 'N/A'}
            </p>
            <p className="text-sm text-gray-500">
              Score: {reports[0]?.overallViabilityScore || 0}/100
            </p>
          </div>
        </div>

        {/* Tabla de Estrategias */}
        <div className="bg-white rounded-lg shadow overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Análisis de Viabilidad por Estrategia</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estrategia
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Score
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Riesgo
                  </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Capital Mín.
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Blockchains
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acciones
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {reports.map((report) => (
                  <tr key={report.strategyId} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {report.strategy.name}
                        </div>
                        <div className="text-sm text-gray-500">
                          {report.strategy.description}
                        </div>
                      </div>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`text-lg font-bold ${getViabilityColor(report.overallViabilityScore)}`}>
                        {report.overallViabilityScore}/100
                      </span>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getRiskColor(report.riskAssessment.level)}`}>
                        {report.riskAssessment.level.toUpperCase()}
                      </span>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ${report.strategy.minCapital}
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {report.blockchainReports.filter(r => r.isViable).length} viables
                      </div>
                      <div className="text-sm text-gray-500">
                        de {report.blockchainReports.length} total
                      </div>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => setSelectedStrategy(selectedStrategy === report.strategyId ? null : report.strategyId)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        {selectedStrategy === report.strategyId ? 'Ocultar' : 'Ver Detalles'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Detalles de Estrategia Seleccionada */}
        {selectedStrategy && (
          <StrategyDetailsPanel
            report={reports.find(r => r.strategyId === selectedStrategy)!}
            onClose={() => setSelectedStrategy(null)}
          />
        )}

        {/* Perfiles de Gas por Blockchain */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Perfiles de Gas por Blockchain</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 p-6">
            {Array.from(gasProfiles.values()).map((profile) => (
              <div key={profile.chainId} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-gray-900">{profile.chainName}</h3>
                  <span className={`text-sm font-medium ${getEfficiencyColor(profile.gasEfficiency)}`}>
                    {profile.gasEfficiency.toUpperCase()}
                  </span>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Gas Price:</span>
                    <span className="font-medium">{profile.averageGasPrice} gwei</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-500">Costo USD:</span>
                    <span className="font-medium">${profile.averageGasPriceUSD}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-500">Block Time:</span>
                    <span className="font-medium">{profile.blockTime}s</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-500">Multiplicador:</span>
                    <span className="font-medium">{profile.gasCostMultiplier.toFixed(3)}x</span>
                  </div>
                </div>
                
                <div className="mt-3 pt-3 border-t">
                  <div className="text-xs text-gray-500 mb-1">Estrategias Recomendadas:</div>
                  <div className="flex flex-wrap gap-1">
                    {profile.recommendedStrategies.slice(0, 2).map((strategy, idx) => (
                      <span key={idx} className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        {strategy}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

/**
 * Panel de detalles de una estrategia específica
 */
const StrategyDetailsPanel: React.FC<{
  report: StrategyViabilityReport
  onClose: () => void
}> = ({ report, onClose }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg mb-8">
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
        <h3 className="text-xl font-semibold text-gray-900">
          Detalles: {report.strategy.name}
        </h3>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      
      <div className="p-6">
        {/* Información General */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-2">Características</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Tipo:</span>
                <span className="font-medium">{report.strategy.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Velocidad:</span>
                <span className="font-medium">{report.strategy.executionSpeed}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Capital Mín:</span>
                <span className="font-medium">${report.strategy.minCapital}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-2">Riesgo</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Nivel:</span>
                <span className={`font-medium ${getRiskColor(report.riskAssessment.level)}`}>
                  {report.riskAssessment.level.toUpperCase()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Blockchains:</span>
                <span className="font-medium">{report.riskAssessment.viableBlockchainsCount}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-2">Score General</h4>
            <div className="text-center">
              <div className={`text-3xl font-bold ${getViabilityColor(report.overallViabilityScore)}`}>
                {report.overallViabilityScore}/100
              </div>
              <div className="text-sm text-gray-500">Viabilidad General</div>
            </div>
          </div>
        </div>

        {/* Análisis por Blockchain */}
        <div className="mb-6">
          <h4 className="font-semibold text-gray-700 mb-4">Análisis por Blockchain</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {report.blockchainReports.map((blockchainReport) => (
              <div key={blockchainReport.chainId} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="font-semibold text-gray-900">{blockchainReport.chainName}</h5>
                  <span className={`text-sm font-medium ${blockchainReport.isViable ? 'text-green-600' : 'text-red-600'}`}>
                    {blockchainReport.isViable ? 'VIABLE' : 'NO VIABLE'}
                  </span>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Score:</span>
                    <span className={`font-medium ${getViabilityColor(blockchainReport.viabilityScore)}`}>
                      {blockchainReport.viabilityScore}/100
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-500">ROI Mín:</span>
                    <span className="font-medium">{blockchainReport.minViableROI}%</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-500">Gas Cost:</span>
                    <span className="font-medium">${blockchainReport.viability.gasMetrics.gasFeeUSD.toFixed(3)}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-500">Profit Neto:</span>
                    <span className="font-medium">${blockchainReport.viability.profitabilityMetrics.netProfit.toFixed(2)}</span>
                  </div>
                </div>
                
                <div className="mt-3 pt-3 border-t">
                  <div className="text-xs text-gray-500 mb-1">Recomendaciones:</div>
                  <div className="text-xs text-gray-700">
                    {blockchainReport.recommendations.slice(0, 2).join(', ')}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recomendaciones Generales */}
        <div className="mb-6">
          <h4 className="font-semibold text-gray-700 mb-4">Recomendaciones Generales</h4>
          <div className="bg-blue-50 rounded-lg p-4">
            <ul className="space-y-2 text-sm text-blue-800">
              {report.recommendations.map((rec, idx) => (
                <li key={idx} className="flex items-start">
                  <span className="text-blue-600 mr-2">•</span>
                  {rec}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Estrategias de Mitigación de Riesgo */}
        {report.riskAssessment.mitigationStrategies.length > 0 && (
          <div>
            <h4 className="font-semibold text-gray-700 mb-4">Estrategias de Mitigación de Riesgo</h4>
            <div className="bg-yellow-50 rounded-lg p-4">
              <ul className="space-y-2 text-sm text-yellow-800">
                {report.riskAssessment.mitigationStrategies.map((strategy, idx) => (
                  <li key={idx} className="flex items-start">
                    <span className="text-yellow-600 mr-2">•</span>
                    {strategy}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// Función helper para colores de viabilidad
const getViabilityColor = (score: number): string => {
  if (score >= 80) return 'text-green-600'
  if (score >= 60) return 'text-yellow-600'
  if (score >= 40) return 'text-orange-600'
  return 'text-red-600'
}

// Función helper para colores de riesgo
const getRiskColor = (level: string): string => {
  switch (level) {
    case 'low': return 'text-green-600'
    case 'medium': return 'text-yellow-600'
    case 'high': return 'text-orange-600'
    case 'extreme': return 'text-red-600'
    default: return 'text-gray-600'
  }
}
