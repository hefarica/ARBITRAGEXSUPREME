import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useKV } from '@/hooks/useKV'
import { Target, Play, BarChart, Gear, Plus } from '@phosphor-icons/react'

interface Strategy {
  id: string
  name: string
  type: 'triangular' | 'cross-dex' | 'flash-loan'
  parameters: {
    minProfitThreshold: number
    maxSlippage: number
    gasLimit: number
  }
  performance: {
    totalTrades: number
    successRate: number
    avgProfit: number
  }
  isActive: boolean
}

export function StrategyBuilder() {
  const [strategies, setStrategies] = useKV<Strategy[]>("strategies", [])
  const [selectedStrategy, setSelectedStrategy] = useState<Strategy | null>(null)
  const [isCreating, setIsCreating] = useState(false)
  const [newStrategy, setNewStrategy] = useState({
    name: '',
    type: 'triangular' as const,
    minProfitThreshold: 5,
    maxSlippage: 1,
    gasLimit: 300000
  })

  const strategyTypes = [
    {
      id: 'triangular',
      name: 'Triangular Arbitrage',
      description: 'Profit from price differences in three-token loops',
      difficulty: 'Beginner',
      avgReturn: '0.1-0.5%'
    },
    {
      id: 'cross-dex',
      name: 'Cross-DEX Arbitrage',
      description: 'Exploit price differences between different exchanges',
      difficulty: 'Intermediate',
      avgReturn: '0.2-1.0%'
    },
    {
      id: 'flash-loan',
      name: 'Flash Loan Arbitrage',
      description: 'Use borrowed funds for large arbitrage opportunities',
      difficulty: 'Advanced',
      avgReturn: '0.5-2.0%'
    }
  ]

  const createStrategy = () => {
    const strategy: Strategy = {
      id: crypto.randomUUID(),
      name: newStrategy.name || `${newStrategy.type} Strategy ${strategies.length + 1}`,
      type: newStrategy.type,
      parameters: {
        minProfitThreshold: newStrategy.minProfitThreshold,
        maxSlippage: newStrategy.maxSlippage,
        gasLimit: newStrategy.gasLimit
      },
      performance: {
        totalTrades: 0,
        successRate: 0,
        avgProfit: 0
      },
      isActive: false
    }

    setStrategies([...strategies, strategy])
    setIsCreating(false)
    setNewStrategy({
      name: '',
      type: 'triangular',
      minProfitThreshold: 5,
      maxSlippage: 1,
      gasLimit: 300000
    })
  }

  const toggleStrategy = (id: string) => {
    setStrategies(prev => 
      prev.map(s => s.id === id ? { ...s, isActive: !s.isActive } : s)
    )
  }

  const deleteStrategy = (id: string) => {
    setStrategies(prev => prev.filter(s => s.id !== id))
    if (selectedStrategy?.id === id) {
      setSelectedStrategy(null)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-profit text-profit-foreground'
      case 'Intermediate': return 'bg-warning text-warning-foreground'
      case 'Advanced': return 'bg-destructive text-destructive-foreground'
      default: return 'bg-muted text-muted-foreground'
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Strategy Management</h3>
          <p className="text-muted-foreground">Create and configure your arbitrage strategies</p>
        </div>
        <Button onClick={() => setIsCreating(true)} className="gap-2">
          <Plus size={16} />
          New Strategy
        </Button>
      </div>

      <Tabs defaultValue="strategies" className="space-y-6">
        <TabsList>
          <TabsTrigger value="strategies">My Strategies</TabsTrigger>
          <TabsTrigger value="templates">Strategy Templates</TabsTrigger>
          <TabsTrigger value="backtest">Backtest Results</TabsTrigger>
        </TabsList>

        <TabsContent value="strategies" className="space-y-4">
          {isCreating && (
            <Card>
              <CardHeader>
                <CardTitle>Create New Strategy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="strategy-name">Strategy Name</Label>
                    <Input
                      id="strategy-name"
                      placeholder="My Arbitrage Strategy"
                      value={newStrategy.name}
                      onChange={(e) => setNewStrategy(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="strategy-type">Strategy Type</Label>
                    <select
                      id="strategy-type"
                      className="w-full h-10 px-3 border border-input rounded-md bg-background"
                      value={newStrategy.type}
                      onChange={(e) => setNewStrategy(prev => ({ ...prev, type: e.target.value as any }))}
                    >
                      <option value="triangular">Triangular Arbitrage</option>
                      <option value="cross-dex">Cross-DEX Arbitrage</option>
                      <option value="flash-loan">Flash Loan Arbitrage</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="min-profit">Min Profit ($)</Label>
                    <Input
                      id="min-profit"
                      type="number"
                      value={newStrategy.minProfitThreshold}
                      onChange={(e) => setNewStrategy(prev => ({ ...prev, minProfitThreshold: Number(e.target.value) }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="max-slippage">Max Slippage (%)</Label>
                    <Input
                      id="max-slippage"
                      type="number"
                      step="0.1"
                      value={newStrategy.maxSlippage}
                      onChange={(e) => setNewStrategy(prev => ({ ...prev, maxSlippage: Number(e.target.value) }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="gas-limit">Gas Limit</Label>
                    <Input
                      id="gas-limit"
                      type="number"
                      value={newStrategy.gasLimit}
                      onChange={(e) => setNewStrategy(prev => ({ ...prev, gasLimit: Number(e.target.value) }))}
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button onClick={createStrategy}>Create Strategy</Button>
                  <Button variant="outline" onClick={() => setIsCreating(false)}>Cancel</Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-4">
            {strategies.map((strategy) => (
              <Card key={strategy.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold">{strategy.name}</h4>
                        <Badge variant="outline">{strategy.type.replace('-', ' ')}</Badge>
                        <Badge className={strategy.isActive ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                          {strategy.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Min Profit</p>
                          <p className="font-medium">{formatCurrency(strategy.parameters.minProfitThreshold)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Max Slippage</p>
                          <p className="font-medium">{strategy.parameters.maxSlippage}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Total Trades</p>
                          <p className="font-medium">{strategy.performance.totalTrades}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Success Rate</p>
                          <p className="font-medium">{strategy.performance.successRate.toFixed(1)}%</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant={strategy.isActive ? "secondary" : "default"}
                        onClick={() => toggleStrategy(strategy.id)}
                        className="gap-2"
                      >
                        {strategy.isActive ? 'Pause' : <Play size={16} />}
                        {strategy.isActive ? 'Pause' : 'Start'}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedStrategy(strategy)}
                      >
                        <Gear size={16} />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {strategies.length === 0 && (
              <Card>
                <CardContent className="p-12 text-center">
                  <Target size={48} className="mx-auto mb-4 text-muted-foreground opacity-50" />
                  <h4 className="font-semibold mb-2">No strategies created yet</h4>
                  <p className="text-muted-foreground mb-4">Create your first arbitrage strategy to start trading</p>
                  <Button onClick={() => setIsCreating(true)} className="gap-2">
                    <Plus size={16} />
                    Create Strategy
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid gap-4">
            {strategyTypes.map((template) => (
              <Card key={template.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold">{template.name}</h4>
                        <Badge className={getDifficultyColor(template.difficulty)}>
                          {template.difficulty}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground mb-3">{template.description}</p>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-muted-foreground">
                          Expected Return: <span className="font-medium text-foreground">{template.avgReturn}</span>
                        </span>
                      </div>
                    </div>
                    <Button 
                      variant="outline"
                      onClick={() => {
                        setNewStrategy(prev => ({ ...prev, type: template.id as any }))
                        setIsCreating(true)
                      }}
                    >
                      Use Template
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="backtest">
          <Card>
            <CardContent className="p-12 text-center">
              <BarChart size={48} className="mx-auto mb-4 text-muted-foreground opacity-50" />
              <h4 className="font-semibold mb-2">Backtesting Coming Soon</h4>
              <p className="text-muted-foreground">
                Test your strategies against historical market data to validate performance
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}