import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Shield,
  ShieldCheck,
  ShieldWarning,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Target,
  Brain,
  Calculator,
  ChartLine,
  BarChart3,
  PieChart,
  LineChart,
  Globe,
  Database,
  Cpu,
  Network,
  Wifi,
  WifiOff,
  Lock,
  Unlock,
  Eye,
  EyeSlash,
  Bell,
  BellSlash,
  Timer,
  Calendar,
  ClockCounterClockwise,
  Rocket,
  Satellite,
  Broadcast,
  Radio,
  Television,
  Monitor,
  Smartphone,
  Tablet,
  Laptop,
  Desktop,
  Server,
  Cloud,
  HardDrives,
  HardDrive,
  FloppyDisk,
  CompactDisc,
  Usb,
  Bluetooth,
  WifiHigh,
  WifiMedium,
  WifiLow,
  Signal,
  SignalHigh,
  SignalMedium,
  SignalLow,
  Battery,
  BatteryCharging,
  BatteryWarning,
  BatteryEmpty,
  Power,
  PowerOff,
  PowerOn,
  PowerWarning,
  PowerError,
  PowerSuccess,
  PowerInfo,
  PowerQuestion,
  PowerPlus,
  PowerMinus,
  PowerEqual,
  PowerDivide,
  PowerMultiply,
  PowerPercent,
  PowerSquare,
  PowerCube,
  PowerRoot,
  PowerLog,
  PowerLn,
  PowerExp,
  PowerSin,
  PowerCos,
  PowerTan,
  PowerAsin,
  PowerAcos,
  PowerAtan,
  PowerSinh,
  PowerCosh,
  PowerTanh,
  PowerAsinh,
  PowerAcosh,
  PowerAtanh,
  MapTrifold,
  Compass,
  Navigation,
  Location,
  Placeholder,
  PlaceholderSimple,
  PlaceholderBold,
  PlaceholderLight,
  PlaceholderThin,
  PlaceholderFill,
  PlaceholderDuotone,
  PlaceholderGradient,
  PlaceholderLinear,
  PlaceholderRadial,
  PlaceholderConic,
  PlaceholderAngular,
  PlaceholderCubic,
  PlaceholderQuadratic,
  PlaceholderExponential,
  PlaceholderLogarithmic,
  PlaceholderSine,
  PlaceholderCosine,
  PlaceholderTangent,
  PlaceholderArcsin,
  PlaceholderArccos,
  PlaceholderArctan,
  PlaceholderSinh,
  PlaceholderCosh,
  PlaceholderTanh,
  PlaceholderArcsinh,
  PlaceholderArccosh,
  PlaceholderArctanh,
  Warning,
  CheckCircle,
  XCircle,
  Info,
  AlertTriangle,
  Settings,
  Gear,
  Sliders,
  ToggleLeft,
  ToggleRight,
  ArrowsClockwise,
  ArrowsCounterClockwise,
  Plus,
  Minus,
  Equal,
  ChartLine as ChartLineIcon,
  BarChart3 as BarChart3Icon,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon,
  Globe as GlobeIcon,
  Database as DatabaseIcon,
  Cpu as CpuIcon,
  Network as NetworkIcon,
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Lock as LockIcon,
  Unlock as UnlockIcon,
  Eye as EyeIcon,
  EyeSlash as EyeSlashIcon,
  Bell as BellIcon,
  BellSlash as BellSlashIcon,
  Timer as TimerIcon,
  Calendar as CalendarIcon,
  ClockCounterClockwise as ClockCounterClockwiseIcon,
  Rocket as RocketIcon,
  Satellite as SatelliteIcon,
  Broadcast as BroadcastIcon,
  Radio as RadioIcon,
  Television as TelevisionIcon,
  Monitor as MonitorIcon,
  Smartphone as SmartphoneIcon,
  Tablet as TabletIcon,
  Laptop as LaptopIcon,
  Desktop as DesktopIcon,
  Server as ServerIcon,
  Cloud as CloudIcon,
  HardDrives as HardDrivesIcon,
  HardDrive as HardDriveIcon,
  FloppyDisk as FloppyDiskIcon,
  CompactDisc as CompactDiscIcon,
  Usb as UsbIcon,
  Bluetooth as BluetoothIcon,
  WifiHigh as WifiHighIcon,
  WifiMedium as WifiMediumIcon,
  WifiLow as WifiLowIcon,
  Signal as SignalIcon,
  SignalHigh as SignalHighIcon,
  SignalMedium as SignalMediumIcon,
  SignalLow as SignalLowIcon,
  Battery as BatteryIcon,
  BatteryCharging as BatteryChargingIcon,
  BatteryWarning as BatteryWarningIcon,
  BatteryEmpty as BatteryEmptyIcon,
  Power as PowerIcon,
  PowerOff as PowerOffIcon,
  PowerOn as PowerOnIcon,
  PowerWarning as PowerWarningIcon,
  PowerError as PowerErrorIcon,
  PowerSuccess as PowerSuccessIcon,
  PowerInfo as PowerInfoIcon,
  PowerQuestion as PowerQuestionIcon,
  PowerPlus as PowerPlusIcon,
  PowerMinus as PowerMinusIcon,
  PowerEqual as PowerEqualIcon,
  PowerDivide as PowerDivideIcon,
  PowerMultiply as PowerMultiplyIcon,
  PowerPercent as PowerPercentIcon,
  PowerSquare as PowerSquareIcon,
  PowerCube as PowerCubeIcon,
  PowerRoot as PowerRootIcon,
  PowerLog as PowerLogIcon,
  PowerLn as PowerLnIcon,
  PowerExp as PowerExpIcon,
  PowerSin as PowerSinIcon,
  PowerCos as PowerCosIcon,
  PowerTan as PowerTanIcon,
  PowerAsin as PowerAsinIcon,
  PowerAcos as PowerAcosIcon,
  PowerAtan as PowerAtanIcon,
  PowerSinh as PowerSinhIcon,
  PowerCosh as PowerCoshIcon,
  PowerTanh as PowerTanhIcon,
  PowerAsinh as PowerAsinhIcon,
  PowerAcosh as PowerAcoshIcon,
  PowerAtanh as PowerAtanhIcon
} from '@phosphor-icons/react'
import { cn } from '@/lib/utils'

interface RiskProfile {
  id: string
  name: string
  description: string
  riskLevel: 'conservative' | 'moderate' | 'aggressive' | 'ultra-aggressive'
  maxAccountExposure: number // % máximo de la cuenta total
  maxTransactionRisk: number // % máximo de riesgo por transacción
  maxROIRisk: number // % máximo de riesgo basado en ROI
  maxDailyLoss: number // % máximo de pérdida diaria
  maxDrawdown: number // % máximo de drawdown
  diversification: number // % mínimo de diversificación
  stopLossPercentage: number // % de stop loss automático
  takeProfitPercentage: number // % de take profit automático
  maxConcurrentTrades: number // Número máximo de trades simultáneos
  minROI: number // ROI mínimo para ejecutar trade
  maxSlippage: number // % máximo de slippage permitido
  gasLimit: number // Límite de gas en Gwei
  priority: number // Prioridad de ejecución
  enabled: boolean
}

interface InvestmentStrategy {
  id: string
  name: string
  description: string
  riskProfile: string
  allocation: number // % de asignación
  maxPositionSize: number // Tamaño máximo de posición
  minPositionSize: number // Tamaño mínimo de posición
  targetROI: number // ROI objetivo
  maxRiskPerTrade: number // Riesgo máximo por trade
  stopLoss: number // Stop loss en %
  takeProfit: number // Take profit en %
  timeHorizon: 'short' | 'medium' | 'long'
  rebalanceFrequency: 'hourly' | 'daily' | 'weekly' | 'monthly'
  enabled: boolean
}

interface KellyCriterion {
  winRate: number
  avgWin: number
  avgLoss: number
  recommendedPositionSize: number
  maxPositionSize: number
  riskAdjustedReturn: number
}

export function RiskManagementSystem2025() {
  const [riskProfiles, setRiskProfiles] = useState<RiskProfile[]>([
    {
      id: 'conservative',
      name: 'Conservador',
      description: 'Preservación de capital, bajo riesgo',
      riskLevel: 'conservative',
      maxAccountExposure: 10,
      maxTransactionRisk: 2,
      maxROIRisk: 50,
      maxDailyLoss: 1,
      maxDrawdown: 5,
      diversification: 80,
      stopLossPercentage: 2,
      takeProfitPercentage: 4,
      maxConcurrentTrades: 3,
      minROI: 0.5,
      maxSlippage: 0.5,
      gasLimit: 300,
      priority: 1,
      enabled: true
    },
    {
      id: 'moderate',
      name: 'Moderado',
      description: 'Balance entre riesgo y retorno',
      riskLevel: 'moderate',
      maxAccountExposure: 25,
      maxTransactionRisk: 5,
      maxROIRisk: 60,
      maxDailyLoss: 2.5,
      maxDrawdown: 10,
      diversification: 70,
      stopLossPercentage: 3,
      takeProfitPercentage: 6,
      maxConcurrentTrades: 5,
      minROI: 0.3,
      maxSlippage: 1,
      gasLimit: 500,
      priority: 2,
      enabled: true
    },
    {
      id: 'aggressive',
      name: 'Agresivo',
      description: 'Maximización de retornos, alto riesgo',
      riskLevel: 'aggressive',
      maxAccountExposure: 50,
      maxTransactionRisk: 10,
      maxROIRisk: 70,
      maxDailyLoss: 5,
      maxDrawdown: 20,
      diversification: 50,
      stopLossPercentage: 5,
      takeProfitPercentage: 10,
      maxConcurrentTrades: 8,
      minROI: 0.2,
      maxSlippage: 2,
      gasLimit: 800,
      priority: 3,
      enabled: true
    },
    {
      id: 'ultra-aggressive',
      name: 'Ultra Agresivo',
      description: 'Máximo riesgo para máximo retorno',
      riskLevel: 'ultra-aggressive',
      maxAccountExposure: 80,
      maxTransactionRisk: 20,
      maxROIRisk: 80,
      maxDailyLoss: 10,
      maxDrawdown: 40,
      diversification: 30,
      stopLossPercentage: 8,
      takeProfitPercentage: 15,
      maxConcurrentTrades: 12,
      minROI: 0.1,
      maxSlippage: 5,
      gasLimit: 1200,
      priority: 4,
      enabled: false
    }
  ])

  const [investmentStrategies, setInvestmentStrategies] = useState<InvestmentStrategy[]>([
    {
      id: 'arbitrage-conservative',
      name: 'Arbitraje Conservador',
      description: 'Arbitraje de bajo riesgo con alta probabilidad',
      riskProfile: 'conservative',
      allocation: 40,
      maxPositionSize: 5,
      minPositionSize: 1,
      targetROI: 2,
      maxRiskPerTrade: 1,
      stopLoss: 1.5,
      takeProfit: 3,
      timeHorizon: 'short',
      rebalanceFrequency: 'hourly',
      enabled: true
    },
    {
      id: 'flash-loan-moderate',
      name: 'Flash Loans Moderado',
      description: 'Flash loans con gestión de riesgo moderada',
      riskProfile: 'moderate',
      allocation: 30,
      maxPositionSize: 10,
      minPositionSize: 2,
      targetROI: 5,
      maxRiskPerTrade: 3,
      stopLoss: 2,
      takeProfit: 8,
      timeHorizon: 'short',
      rebalanceFrequency: 'daily',
      enabled: true
    },
    {
      id: 'mev-aggressive',
      name: 'MEV Agresivo',
      description: 'Estrategias MEV de alto riesgo y alto retorno',
      riskProfile: 'aggressive',
      allocation: 20,
      maxPositionSize: 15,
      minPositionSize: 5,
      targetROI: 15,
      maxRiskPerTrade: 8,
      stopLoss: 5,
      takeProfit: 20,
      timeHorizon: 'short',
      rebalanceFrequency: 'daily',
      enabled: true
    },
    {
      id: 'yield-farming-conservative',
      name: 'Yield Farming Conservador',
      description: 'Yield farming de bajo riesgo',
      riskProfile: 'conservative',
      allocation: 10,
      maxPositionSize: 8,
      minPositionSize: 2,
      targetROI: 8,
      maxRiskPerTrade: 2,
      stopLoss: 3,
      takeProfit: 12,
      timeHorizon: 'long',
      rebalanceFrequency: 'weekly',
      enabled: true
    }
  ])

  const [kellyCriterion, setKellyCriterion] = useState<KellyCriterion>({
    winRate: 75,
    avgWin: 3.5,
    avgLoss: 1.2,
    recommendedPositionSize: 12.5,
    maxPositionSize: 25,
    riskAdjustedReturn: 2.1
  })

  const [accountBalance, setAccountBalance] = useState(10000)
  const [currentExposure, setCurrentExposure] = useState(2500)
  const [dailyPnL, setDailyPnL] = useState(150)
  const [maxDrawdown, setMaxDrawdown] = useState(3.2)

  const [selectedProfile, setSelectedProfile] = useState<string>('moderate')
  const [autoRiskManagement, setAutoRiskManagement] = useState(true)
  const [dynamicPositionSizing, setDynamicPositionSizing] = useState(true)

  // Simulación de datos en tiempo real
  useEffect(() => {
    const interval = setInterval(() => {
      setDailyPnL(prev => prev + (Math.random() - 0.5) * 50)
      setCurrentExposure(prev => prev + (Math.random() - 0.5) * 200)
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const calculatePositionSize = (expectedProfit: number, riskProfile: RiskProfile) => {
    // Fórmula Kelly Criterion modificada para DeFi
    const kellyFraction = (kellyCriterion.winRate * kellyCriterion.avgWin - (1 - kellyCriterion.winRate) * kellyCriterion.avgLoss) / kellyCriterion.avgWin
    
    // Ajuste por perfil de riesgo
    const riskMultiplier = {
      'conservative': 0.25,
      'moderate': 0.5,
      'aggressive': 0.75,
      'ultra-aggressive': 1
    }[riskProfile.riskLevel] || 0.5

    // Cálculo del tamaño de posición basado en ROI
    const maxRiskAmount = expectedProfit * (riskProfile.maxROIRisk / 100)
    const kellyPositionSize = accountBalance * kellyFraction * riskMultiplier
    
    return Math.min(maxRiskAmount, kellyPositionSize, accountBalance * (riskProfile.maxTransactionRisk / 100))
  }

  const calculateRiskScore = (strategy: InvestmentStrategy, profile: RiskProfile) => {
    const exposureScore = (currentExposure / accountBalance) / (profile.maxAccountExposure / 100)
    const dailyLossScore = Math.abs(dailyPnL) / (accountBalance * profile.maxDailyLoss / 100)
    const drawdownScore = maxDrawdown / profile.maxDrawdown
    
    return Math.min(100, (exposureScore + dailyLossScore + drawdownScore) * 33.33)
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'conservative': return 'bg-green-100 text-green-800'
      case 'moderate': return 'bg-blue-100 text-blue-800'
      case 'aggressive': return 'bg-yellow-100 text-yellow-800'
      case 'ultra-aggressive': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const currentProfile = riskProfiles.find(p => p.id === selectedProfile)!

  return (
    <div className="space-y-6">
      {/* Header del Sistema de Gestión de Riesgos */}
      <div className="bg-gradient-to-r from-red-600 to-orange-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Shield size={32} />
            <div>
              <h1 className="text-2xl font-bold">Sistema de Gestión de Riesgos DeFi 2025</h1>
              <p className="text-red-100">Gestión inteligente de capital y control de riesgo automatizado</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <DollarSign size={20} />
                <span className="text-xl font-bold">{formatCurrency(accountBalance)}</span>
              </div>
              <p className="text-sm text-red-100">Capital Total</p>
            </div>
            
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <Shield size={20} />
                <span className="text-xl font-bold">{((currentExposure / accountBalance) * 100).toFixed(1)}%</span>
              </div>
              <p className="text-sm text-red-100">Exposición Actual</p>
            </div>
          </div>
        </div>
        
        {/* Métricas de Riesgo */}
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold">{formatCurrency(dailyPnL)}</p>
            <p className="text-sm text-red-100">P&L Diario</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{maxDrawdown.toFixed(1)}%</p>
            <p className="text-sm text-red-100">Max Drawdown</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{kellyCriterion.recommendedPositionSize.toFixed(1)}%</p>
            <p className="text-sm text-red-100">Posición Kelly</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{kellyCriterion.riskAdjustedReturn.toFixed(2)}</p>
            <p className="text-sm text-red-100">Retorno Ajustado</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="profiles" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profiles">Perfiles de Riesgo</TabsTrigger>
          <TabsTrigger value="strategies">Estrategias</TabsTrigger>
          <TabsTrigger value="kelly">Kelly Criterion</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoreo</TabsTrigger>
        </TabsList>

        <TabsContent value="profiles" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lista de Perfiles de Riesgo */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Perfiles de Riesgo Disponibles</h3>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={autoRiskManagement}
                    onCheckedChange={setAutoRiskManagement}
                  />
                  <span className="text-sm">Gestión Automática</span>
                </div>
              </div>
              
              {riskProfiles.map((profile) => (
                <Card key={profile.id} className={cn(
                  "transition-all duration-300 hover:shadow-md",
                  selectedProfile === profile.id ? "border-blue-500 bg-blue-50" : "border-gray-200"
                )}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-10 h-10 rounded-lg flex items-center justify-center",
                          selectedProfile === profile.id ? "bg-blue-100" : "bg-gray-100"
                        )}>
                          <Shield size={20} />
                        </div>
                        <div>
                          <h4 className="font-semibold">{profile.name}</h4>
                          <p className="text-sm text-muted-foreground">{profile.description}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge className={getRiskColor(profile.riskLevel)}>
                          {profile.riskLevel}
                        </Badge>
                        <Switch
                          checked={selectedProfile === profile.id}
                          onCheckedChange={() => setSelectedProfile(profile.id)}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Exposición Máx:</span>
                        <p className="font-semibold">{profile.maxAccountExposure}%</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Riesgo por Trade:</span>
                        <p className="font-semibold">{profile.maxTransactionRisk}%</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Riesgo ROI:</span>
                        <p className="font-semibold">{profile.maxROIRisk}%</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Pérdida Diaria:</span>
                        <p className="font-semibold">{profile.maxDailyLoss}%</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Configuración del Perfil Seleccionado */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Configuración del Perfil</h3>
              
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm">Exposición Máxima de Cuenta</Label>
                      <Slider
                        value={[currentProfile.maxAccountExposure]}
                        onValueChange={(value) => {
                          setRiskProfiles(prev => prev.map(p => 
                            p.id === selectedProfile ? { ...p, maxAccountExposure: value[0] } : p
                          ))
                        }}
                        max={100}
                        step={1}
                        className="mt-2"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>5%</span>
                        <span>{currentProfile.maxAccountExposure}%</span>
                        <span>100%</span>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm">Riesgo Máximo por Transacción</Label>
                      <Slider
                        value={[currentProfile.maxTransactionRisk]}
                        onValueChange={(value) => {
                          setRiskProfiles(prev => prev.map(p => 
                            p.id === selectedProfile ? { ...p, maxTransactionRisk: value[0] } : p
                          ))
                        }}
                        max={50}
                        step={0.5}
                        className="mt-2"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>0.5%</span>
                        <span>{currentProfile.maxTransactionRisk}%</span>
                        <span>50%</span>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm">Riesgo Máximo basado en ROI</Label>
                      <Slider
                        value={[currentProfile.maxROIRisk]}
                        onValueChange={(value) => {
                          setRiskProfiles(prev => prev.map(p => 
                            p.id === selectedProfile ? { ...p, maxROIRisk: value[0] } : p
                          ))
                        }}
                        max={100}
                        step={5}
                        className="mt-2"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>25%</span>
                        <span>{currentProfile.maxROIRisk}%</span>
                        <span>100%</span>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm">Pérdida Máxima Diaria</Label>
                      <Slider
                        value={[currentProfile.maxDailyLoss]}
                        onValueChange={(value) => {
                          setRiskProfiles(prev => prev.map(p => 
                            p.id === selectedProfile ? { ...p, maxDailyLoss: value[0] } : p
                          ))
                        }}
                        max={20}
                        step={0.5}
                        className="mt-2"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>0.5%</span>
                        <span>{currentProfile.maxDailyLoss}%</span>
                        <span>20%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="strategies" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lista de Estrategias */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Estrategias de Inversión</h3>
              
              {investmentStrategies.map((strategy) => {
                const profile = riskProfiles.find(p => p.id === strategy.riskProfile)!
                const riskScore = calculateRiskScore(strategy, profile)
                
                return (
                  <Card key={strategy.id} className="transition-all duration-300 hover:shadow-md">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold">{strategy.name}</h4>
                          <p className="text-sm text-muted-foreground">{strategy.description}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={getRiskColor(profile.riskLevel)}>
                            {profile.riskLevel}
                          </Badge>
                          <Switch
                            checked={strategy.enabled}
                            onCheckedChange={(checked) => {
                              setInvestmentStrategies(prev => prev.map(s => 
                                s.id === strategy.id ? { ...s, enabled: checked } : s
                              ))
                            }}
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Asignación:</span>
                          <p className="font-semibold">{strategy.allocation}%</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">ROI Objetivo:</span>
                          <p className="font-semibold text-green-600">{strategy.targetROI}%</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Posición Máx:</span>
                          <p className="font-semibold">{strategy.maxPositionSize}%</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Riesgo por Trade:</span>
                          <p className="font-semibold text-red-600">{strategy.maxRiskPerTrade}%</p>
                        </div>
                      </div>
                      
                      <div className="mt-3">
                        <div className="flex justify-between text-xs mb-1">
                          <span>Puntuación de Riesgo</span>
                          <span>{riskScore.toFixed(1)}%</span>
                        </div>
                        <Progress 
                          value={riskScore} 
                          className="h-2"
                          style={{
                            '--progress-background': riskScore > 70 ? '#ef4444' : 
                                                   riskScore > 40 ? '#f59e0b' : '#10b981'
                          } as React.CSSProperties}
                        />
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Calculadora de Posición */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Calculadora de Posición</h3>
              
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm">Ganancia Esperada (USD)</Label>
                      <Input
                        type="number"
                        placeholder="100"
                        className="mt-1"
                        onChange={(e) => {
                          const profit = Number(e.target.value)
                          const positionSize = calculatePositionSize(profit, currentProfile)
                          // Aquí podrías actualizar el estado con el tamaño calculado
                        }}
                      />
                    </div>
                    
                    <div>
                      <Label className="text-sm">ROI Esperado (%)</Label>
                      <Input
                        type="number"
                        placeholder="5"
                        className="mt-1"
                      />
                    </div>
                    
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-semibold text-blue-800 mb-2">Tamaño de Posición Recomendado</h4>
                      <div className="space-y-2 text-sm text-blue-700">
                        <div className="flex justify-between">
                          <span>Basado en Kelly Criterion:</span>
                          <span className="font-semibold">{kellyCriterion.recommendedPositionSize.toFixed(1)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Basado en ROI:</span>
                          <span className="font-semibold">{currentProfile.maxROIRisk}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Máximo por Transacción:</span>
                          <span className="font-semibold">{currentProfile.maxTransactionRisk}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Máximo de Cuenta:</span>
                          <span className="font-semibold">{currentProfile.maxAccountExposure}%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={dynamicPositionSizing}
                        onCheckedChange={setDynamicPositionSizing}
                      />
                      <Label className="text-sm">Tamaño de Posición Dinámico</Label>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="kelly" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Kelly Criterion Calculator */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator size={20} />
                  Calculadora Kelly Criterion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm">Tasa de Éxito (%)</Label>
                    <Slider
                      value={[kellyCriterion.winRate]}
                      onValueChange={(value) => setKellyCriterion(prev => ({ ...prev, winRate: value[0] }))}
                      max={100}
                      step={1}
                      className="mt-2"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>50%</span>
                      <span>{kellyCriterion.winRate}%</span>
                      <span>100%</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm">Ganancia Promedio (%)</Label>
                    <Slider
                      value={[kellyCriterion.avgWin]}
                      onValueChange={(value) => setKellyCriterion(prev => ({ ...prev, avgWin: value[0] }))}
                      max={20}
                      step={0.1}
                      className="mt-2"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>1%</span>
                      <span>{kellyCriterion.avgWin}%</span>
                      <span>20%</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm">Pérdida Promedio (%)</Label>
                    <Slider
                      value={[kellyCriterion.avgLoss]}
                      onValueChange={(value) => setKellyCriterion(prev => ({ ...prev, avgLoss: value[0] }))}
                      max={10}
                      step={0.1}
                      className="mt-2"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>0.5%</span>
                      <span>{kellyCriterion.avgLoss}%</span>
                      <span>10%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Resultados Kelly */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ChartLine size={20} />
                  Resultados Kelly Criterion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Tamaño de Posición Recomendado</h4>
                    <p className="text-2xl font-bold text-green-600">{kellyCriterion.recommendedPositionSize.toFixed(1)}%</p>
                    <p className="text-sm text-green-700">del capital total</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <p className="text-lg font-bold text-blue-600">{kellyCriterion.maxPositionSize}%</p>
                      <p className="text-sm text-blue-700">Máximo</p>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <p className="text-lg font-bold text-purple-600">{kellyCriterion.riskAdjustedReturn.toFixed(2)}</p>
                      <p className="text-sm text-purple-700">Retorno Ajustado</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold">Interpretación:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• <strong>{kellyCriterion.recommendedPositionSize.toFixed(1)}%</strong> es el tamaño óptimo de posición</li>
                      <li>• <strong>{kellyCriterion.maxPositionSize}%</strong> es el máximo recomendado</li>
                      <li>• <strong>{kellyCriterion.riskAdjustedReturn.toFixed(2)}</strong> es el retorno ajustado al riesgo</li>
                      <li>• Tasa de éxito: <strong>{kellyCriterion.winRate}%</strong></li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Métricas de Riesgo */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield size={20} />
                  Métricas de Riesgo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Exposición Actual</span>
                    <Badge variant="outline">{((currentExposure / accountBalance) * 100).toFixed(1)}%</Badge>
                  </div>
                  <Progress value={(currentExposure / accountBalance) * 100} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">P&L Diario</span>
                    <Badge className={dailyPnL >= 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                      {formatCurrency(dailyPnL)}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Max Drawdown</span>
                    <Badge variant="outline">{maxDrawdown.toFixed(1)}%</Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Trades Activos</span>
                    <Badge variant="outline">5</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Alertas de Riesgo */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle size={20} />
                  Alertas de Riesgo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                    <span className="text-sm text-green-700">Exposición OK</span>
                    <CheckCircle size={16} className="text-green-600" />
                  </div>
                  
                  <div className="flex items-center justify-between p-2 bg-yellow-50 rounded">
                    <span className="text-sm text-yellow-700">P&L Diario -2.1%</span>
                    <Warning size={16} className="text-yellow-600" />
                  </div>
                  
                  <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                    <span className="text-sm text-green-700">Drawdown OK</span>
                    <CheckCircle size={16} className="text-green-600" />
                  </div>
                  
                  <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                    <span className="text-sm text-green-700">Diversificación OK</span>
                    <CheckCircle size={16} className="text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Configuración de Alertas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell size={20} />
                  Configuración de Alertas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                                          <span className="text-sm">Exposición &gt; 80%</span>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                                          <span className="text-sm">Pérdida Diaria &gt; 5%</span>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Drawdown &gt; 15%</span>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">ROI &lt; 0.5%</span>
                    <Switch />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Slippage &gt; 2%</span>
                    <Switch defaultChecked />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 