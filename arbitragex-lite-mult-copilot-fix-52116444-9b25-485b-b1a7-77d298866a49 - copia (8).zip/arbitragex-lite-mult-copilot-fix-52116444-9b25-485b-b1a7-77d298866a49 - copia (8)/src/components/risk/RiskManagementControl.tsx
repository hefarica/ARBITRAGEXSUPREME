import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Shield, 
  Warning, 
  CheckCircle, 
  WarningCircle,
  Activity,
  TrendUp,
  TrendDown
} from '@phosphor-icons/react'

interface RiskControlProps {
  environment: 'test' | 'prod'
}

export default function RiskManagementControl({ environment }: RiskControlProps) {
  const riskMetrics = {
    currentRiskScore: environment === 'prod' ? 25 : 45,
    portfolioExposure: environment === 'prod' ? 65 : 80,
    dailyPnL: environment === 'prod' ? 4.2 : 2.8,
    maxDrawdown: environment === 'prod' ? 2.1 : 5.3,
    sharpeRatio: environment === 'prod' ? 2.8 : 1.9,
    successRate: environment === 'prod' ? 94 : 87
  }

  const getRiskColor = (score: number) => {
    if (score <= 30) return 'text-green-600'
    if (score <= 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getRiskIcon = (score: number) => {
    if (score <= 30) return <CheckCircle className="text-green-600" size={20} />
    if (score <= 60) return <Warning className="text-yellow-600" size={20} />
    return <WarningCircle className="text-red-600" size={20} />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Management Center</h2>
          <p className="text-muted-foreground">
            Real-time risk monitoring and control for {environment.toUpperCase()} environment
          </p>
        </div>
        <Badge variant="outline" className="gap-2">
          {getRiskIcon(riskMetrics.currentRiskScore)}
          Risk Level: {riskMetrics.currentRiskScore <= 30 ? 'LOW' : riskMetrics.currentRiskScore <= 60 ? 'MEDIUM' : 'HIGH'}
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Risk Score</CardTitle>
            <Shield size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getRiskColor(riskMetrics.currentRiskScore)}`}>
              {riskMetrics.currentRiskScore}/100
            </div>
            <Progress value={riskMetrics.currentRiskScore} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">
              Real-time risk assessment
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Daily P&L</CardTitle>
            {riskMetrics.dailyPnL >= 0 ? 
              <TrendUp size={16} className="text-green-600" /> : 
              <TrendDown size={16} className="text-red-600" />
            }
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${riskMetrics.dailyPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {riskMetrics.dailyPnL >= 0 ? '+' : ''}{riskMetrics.dailyPnL}%
            </div>
            <p className="text-xs text-muted-foreground">
              Today's performance
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <Activity size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {riskMetrics.successRate}%
            </div>
            <p className="text-xs text-muted-foreground">
              Execution success rate
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Risk Parameters</CardTitle>
            <CardDescription>Current risk management settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Max Position Size</span>
                <span className="text-sm">${environment === 'prod' ? '10,000' : '1,000'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm font-medium">Max Slippage</span>
                <span className="text-sm">{environment === 'prod' ? '2.0' : '3.0'}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm font-medium">Min Profit Threshold</span>
                <span className="text-sm">{environment === 'prod' ? '4.0' : '1.0'}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm font-medium">Max Daily Loss</span>
                <span className="text-sm">{environment === 'prod' ? '5.0' : '10.0'}%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Portfolio Metrics</CardTitle>
            <CardDescription>Current portfolio risk analysis</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Portfolio Exposure</span>
                  <span className="text-sm">{riskMetrics.portfolioExposure}%</span>
                </div>
                <Progress value={riskMetrics.portfolioExposure} />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Max Drawdown</span>
                  <span className="text-sm">{riskMetrics.maxDrawdown}%</span>
                </div>
                <Progress value={riskMetrics.maxDrawdown} className="bg-red-100" />
              </div>
              <div className="flex justify-between">
                <span className="text-sm font-medium">Sharpe Ratio</span>
                <span className="text-sm font-bold">{riskMetrics.sharpeRatio}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}