import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Switch } from '../ui/switch'
import { Textarea } from '../ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Badge } from '../ui/badge'
import { Alert, AlertDescription } from '../ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { Separator } from '../ui/separator'
import { useNotifications } from './RealTimeNotificationProvider'
import { TelegramConfig, NotificationChannel } from './types'
import { PaperPlane, TestTube, CheckCircle, XCircle, WarningCircle, Copy } from 'lucide-react'
import { useToast } from '../../hooks/use-toast'

interface Props {
  onConfigChange?: (config: TelegramConfig) => void
}

export function TelegramNotificationConfig({ onConfigChange }: Props) {
  const { config, updateConfig, sendTestNotification } = useNotifications()
  const { toast } = useToast()
  
  const [telegramConfig, setTelegramConfig] = useState<TelegramConfig>({
    botToken: '',
    chatId: '',
    parseMode: 'HTML',
    disableWebPagePreview: false,
    disableNotification: false
  })
  
  const [isTestingConnection, setIsTestingConnection] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState<'untested' | 'success' | 'error'>('untested')
  const [testResult, setTestResult] = useState<string>('')
  const [isEnabled, setIsEnabled] = useState(false)

  // Cargar configuración existente
  useEffect(() => {
    const telegramChannel = config?.channels.find(ch => ch.type === 'telegram')
    if (telegramChannel) {
      setTelegramConfig(telegramChannel.config as TelegramConfig)
      setIsEnabled(telegramChannel.enabled)
    }
  }, [config])

  // Manejar cambios en la configuración
  const handleConfigChange = (key: keyof TelegramConfig, value: any) => {
    const newConfig = { ...telegramConfig, [key]: value }
    setTelegramConfig(newConfig)
    onConfigChange?.(newConfig)
  }

  // Probar conexión con Telegram
  const testConnection = async () => {
    if (!telegramConfig.botToken || !telegramConfig.chatId) {
      toast({
        title: "Configuración incompleta",
        description: "Por favor, proporciona el Bot Token y Chat ID",
        variant: "destructive"
      })
      return
    }

    setIsTestingConnection(true)
    setConnectionStatus('untested')
    
    try {
      // Verificar que el bot token es válido
      const botResponse = await fetch(`https://api.telegram.org/bot${telegramConfig.botToken}/getMe`)
      const botData = await botResponse.json()
      
      if (!botData.ok) {
        throw new Error(botData.description || 'Token de bot inválido')
      }

      // Enviar mensaje de prueba
      const testMessage = `🤖 *ArbitrageX Pro 2025 - Test de Conexión*\n\n` +
        `✅ Conexión establecida exitosamente\n` +
        `🤖 Bot: ${botData.result.first_name} (@${botData.result.username})\n` +
        `💬 Chat ID: ${telegramConfig.chatId}\n` +
        `⏰ Timestamp: ${new Date().toLocaleString()}\n\n` +
        `🚀 Las notificaciones están funcionando correctamente!`

      await sendTestNotification('telegram', testMessage)
      
      setConnectionStatus('success')
      setTestResult(`Conexión exitosa con bot: ${botData.result.first_name}`)
      
      toast({
        title: "✅ Conexión exitosa",
        description: "El bot de Telegram está funcionando correctamente",
        variant: "default"
      })
      
    } catch (error) {
      setConnectionStatus('error')
      setTestResult(error instanceof Error ? error.message : 'Error desconocido')
      
      toast({
        title: "❌ Error de conexión",
        description: error instanceof Error ? error.message : 'Error al conectar con Telegram',
        variant: "destructive"
      })
    } finally {
      setIsTestingConnection(false)
    }
  }

  // Guardar configuración
  const saveConfiguration = async () => {
    try {
      if (!config) return

      const telegramChannel: NotificationChannel = {
        type: 'telegram',
        id: 'telegram-primary',
        name: 'Canal Principal Telegram',
        enabled: isEnabled,
        config: telegramConfig,
        priority: 'high'
      }

      const updatedChannels = config.channels.filter(ch => ch.type !== 'telegram')
      updatedChannels.push(telegramChannel)

      await updateConfig({
        channels: updatedChannels
      })

      toast({
        title: "✅ Configuración guardada",
        description: "La configuración de Telegram ha sido guardada exitosamente",
        variant: "default"
      })
      
    } catch (error) {
      toast({
        title: "❌ Error al guardar",
        description: error instanceof Error ? error.message : 'Error al guardar la configuración',
        variant: "destructive"
      })
    }
  }

  // Copiar al portapapeles
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "📋 Copiado",
      description: "Texto copiado al portapapeles",
      variant: "default"
    })
  }

  const getStatusIcon = () => {
    switch (connectionStatus) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'error': return <XCircle className="h-4 w-4 text-red-500" />
      default: return <WarningCircle className="h-4 w-4 text-yellow-500" />
    }
  }

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'success': return 'bg-green-500'
      case 'error': return 'bg-red-500'
      default: return 'bg-yellow-500'
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              📱 Configuración de Telegram
              <Badge variant={isEnabled ? "default" : "secondary"}>
                {isEnabled ? "Activo" : "Inactivo"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Configura las notificaciones en tiempo real vía Telegram Bot
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${getStatusColor()}`}></div>
            {getStatusIcon()}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Toggle principal */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="telegram-enabled" className="text-base font-medium">
              Habilitar notificaciones Telegram
            </Label>
            <p className="text-sm text-muted-foreground mt-1">
              Activar/desactivar todas las notificaciones de Telegram
            </p>
          </div>
          <Switch
            id="telegram-enabled"
            checked={isEnabled}
            onCheckedChange={setIsEnabled}
          />
        </div>

        <Separator />

        <Tabs defaultValue="config" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="config">Configuración</TabsTrigger>
            <TabsTrigger value="test">Pruebas</TabsTrigger>
            <TabsTrigger value="help">Ayuda</TabsTrigger>
          </TabsList>

          <TabsContent value="config" className="space-y-4">
            {/* Bot Token */}
            <div className="space-y-2">
              <Label htmlFor="bot-token">Bot Token *</Label>
              <div className="flex gap-2">
                <Input
                  id="bot-token"
                  type="password"
                  placeholder="1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                  value={telegramConfig.botToken}
                  onChange={(e) => handleConfigChange('botToken', e.target.value)}
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(telegramConfig.botToken)}
                  disabled={!telegramConfig.botToken}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Token proporcionado por @BotFather en Telegram
              </p>
            </div>

            {/* Chat ID */}
            <div className="space-y-2">
              <Label htmlFor="chat-id">Chat ID *</Label>
              <div className="flex gap-2">
                <Input
                  id="chat-id"
                  placeholder="-1001234567890"
                  value={telegramConfig.chatId}
                  onChange={(e) => handleConfigChange('chatId', e.target.value)}
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(telegramConfig.chatId)}
                  disabled={!telegramConfig.chatId}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                ID del chat, grupo o canal donde enviar notificaciones
              </p>
            </div>

            {/* Parse Mode */}
            <div className="space-y-2">
              <Label htmlFor="parse-mode">Formato de mensaje</Label>
              <Select
                value={telegramConfig.parseMode}
                onValueChange={(value: 'HTML' | 'Markdown' | 'MarkdownV2') => 
                  handleConfigChange('parseMode', value)
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="HTML">HTML</SelectItem>
                  <SelectItem value="Markdown">Markdown</SelectItem>
                  <SelectItem value="MarkdownV2">Markdown V2</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Thread ID (para grupos con topics) */}
            <div className="space-y-2">
              <Label htmlFor="thread-id">Thread ID (opcional)</Label>
              <Input
                id="thread-id"
                type="number"
                placeholder="123"
                value={telegramConfig.threadId || ''}
                onChange={(e) => handleConfigChange('threadId', 
                  e.target.value ? parseInt(e.target.value) : undefined
                )}
              />
              <p className="text-xs text-muted-foreground">
                ID del hilo para grupos con topics habilitados
              </p>
            </div>

            {/* Opciones adicionales */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Deshabilitar vista previa de enlaces</Label>
                  <p className="text-sm text-muted-foreground">
                    Evita que Telegram muestre previews de URLs
                  </p>
                </div>
                <Switch
                  checked={telegramConfig.disableWebPagePreview || false}
                  onCheckedChange={(checked) => 
                    handleConfigChange('disableWebPagePreview', checked)
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Envío silencioso</Label>
                  <p className="text-sm text-muted-foreground">
                    Los mensajes no generarán notificaciones sonoras
                  </p>
                </div>
                <Switch
                  checked={telegramConfig.disableNotification || false}
                  onCheckedChange={(checked) => 
                    handleConfigChange('disableNotification', checked)
                  }
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="test" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">Probar conexión</h3>
                  <p className="text-sm text-muted-foreground">
                    Envía un mensaje de prueba para verificar la configuración
                  </p>
                </div>
                <Button
                  onClick={testConnection}
                  disabled={isTestingConnection || !telegramConfig.botToken || !telegramConfig.chatId}
                  className="min-w-[120px]"
                >
                  {isTestingConnection ? (
                    <>
                      <TestTube className="h-4 w-4 mr-2 animate-spin" />
                      Probando...
                    </>
                  ) : (
                    <>
                      <PaperPlane className="h-4 w-4 mr-2" />
                      Probar
                    </>
                  )}
                </Button>
              </div>

              {connectionStatus !== 'untested' && (
                <Alert className={connectionStatus === 'success' ? 'border-green-500' : 'border-red-500'}>
                  <AlertDescription className="flex items-center gap-2">
                    {getStatusIcon()}
                    <span>{testResult}</span>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </TabsContent>

          <TabsContent value="help" className="space-y-4">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-3">🤖 Cómo crear un Bot de Telegram</h3>
                <ol className="space-y-2 text-sm list-decimal list-inside text-muted-foreground">
                  <li>Busca y habla con @BotFather en Telegram</li>
                  <li>Envía el comando <code className="bg-muted px-1 rounded">/newbot</code></li>
                  <li>Sigue las instrucciones para nombrar tu bot</li>
                  <li>Copia el token que te proporciona BotFather</li>
                  <li>Pega el token en el campo "Bot Token" arriba</li>
                </ol>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-3">💬 Cómo obtener el Chat ID</h3>
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    <strong>Para chat personal:</strong>
                  </p>
                  <ol className="space-y-2 text-sm list-decimal list-inside text-muted-foreground ml-4">
                    <li>Envía un mensaje a tu bot</li>
                    <li>Visita: <code className="bg-muted px-1 rounded">https://api.telegram.org/bot{"{TOKEN}"}/getUpdates</code></li>
                    <li>Busca el campo "id" dentro de "chat"</li>
                  </ol>

                  <p className="text-sm text-muted-foreground mt-4">
                    <strong>Para grupos/canales:</strong>
                  </p>
                  <ol className="space-y-2 text-sm list-decimal list-inside text-muted-foreground ml-4">
                    <li>Agrega tu bot al grupo/canal</li>
                    <li>Dale permisos de administrador</li>
                    <li>Envía un mensaje mencionando al bot</li>
                    <li>Usa el mismo enlace para obtener el ID (comenzará con -)</li>
                  </ol>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-3">🔧 Configuración avanzada</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p><strong>Thread ID:</strong> Para grupos con topics, puedes especificar el ID del hilo</p>
                  <p><strong>Parse Mode:</strong> HTML permite más formateo pero requiere escapar caracteres especiales</p>
                  <p><strong>Envío silencioso:</strong> Útil para notificaciones no urgentes</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <Separator />

        {/* Botones de acción */}
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => {
            setTelegramConfig({ botToken: '', chatId: '', parseMode: 'HTML' })
            setIsEnabled(false)
            setConnectionStatus('untested')
            setTestResult('')
          }}>
            Resetear
          </Button>
          <Button 
            onClick={saveConfiguration}
            disabled={!telegramConfig.botToken || !telegramConfig.chatId}
          >
            Guardar configuración
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}