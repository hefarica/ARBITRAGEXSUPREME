import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { ScrollArea } from '../ui/scroll-area'
import { Separator } from '../ui/separator'
import { Input } from '../ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { useNotifications } from './RealTimeNotificationProvider'
import { NotificationHistory } from './types'
import { 
  Bell, 
  CheckCircle, 
  XCircle, 
  Clock, 
  MagnifyingGlass, 
  Funnel,
  Download,
  Trash2,
  Eye,
  WarningCircle,
  TrendUp,
  Shield,
  CurrencyDollar,
  Activity
} from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { es } from 'date-fns/locale'

interface FunnelOptions {
  status: string
  channel: string
  eventType: string
  dateRange: string
  search: string
}

export function NotificationHistoryComponent() {
  const { history, clearHistory } = useNotifications()
  const [filteredHistory, setFunneledHistory] = useState<NotificationHistory[]>([])
  const [filters, setFunnels] = useState<FunnelOptions>({
    status: 'all',
    channel: 'all',
    eventType: 'all',
    dateRange: 'all',
    search: ''
  })
  const [selectedNotification, setSelectedNotification] = useState<NotificationHistory | null>(null)

  // Aplicar filtros
  useEffect(() => {
    let filtered = [...history]

    // Filtro por estado
    if (filters.status !== 'all') {
      filtered = filtered.filter(notification => notification.status === filters.status)
    }

    // Filtro por canal
    if (filters.channel !== 'all') {
      filtered = filtered.filter(notification => notification.channel === filters.channel)
    }

    // Filtro por tipo de evento
    if (filters.eventType !== 'all') {
      filtered = filtered.filter(notification => notification.eventType === filters.eventType)
    }

    // Filtro por búsqueda
    if (filters.search) {
      const searchLower = filters.search.toLowerCase()
      filtered = filtered.filter(notification => 
        notification.message.toLowerCase().includes(searchLower) ||
        notification.eventType.toLowerCase().includes(searchLower) ||
        notification.channel.toLowerCase().includes(searchLower)
      )
    }

    // Filtro por rango de fechas
    if (filters.dateRange !== 'all') {
      const now = new Date()
      let startDate: Date

      switch (filters.dateRange) {
        case '1h':
          startDate = new Date(now.getTime() - 60 * 60 * 1000)
          break
        case '24h':
          startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000)
          break
        case '7d':
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
          break
        case '30d':
          startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
          break
        default:
          startDate = new Date(0)
      }

      filtered = filtered.filter(notification => 
        new Date(notification.createdAt) >= startDate
      )
    }

    // Ordenar por fecha (más recientes primero)
    filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    setFunneledHistory(filtered)
  }, [history, filters])

  // Obtener canales únicos
  const uniqueChannels = Array.from(new Set(history.map(n => n.channel)))
  const uniqueEventTypes = Array.from(new Set(history.map(n => n.eventType)))

  // Estadísticas rápidas
  const stats = {
    total: history.length,
    sent: history.filter(n => n.status === 'sent').length,
    failed: history.filter(n => n.status === 'failed').length,
    pending: history.filter(n => n.status === 'pending').length,
    successRate: history.length > 0 ? (history.filter(n => n.status === 'sent').length / history.length * 100).toFixed(1) : '0'
  }

  // Iconos para tipos de evento
  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case 'arbitrage_opportunity': return <TrendUp className="h-4 w-4 text-green-500" />
      case 'trade_executed': return <Activity className="h-4 w-4 text-blue-500" />
      case 'security_alert': return <Shield className="h-4 w-4 text-red-500" />
      case 'price_alert': return <CurrencyDollar className="h-4 w-4 text-yellow-500" />
      default: return <Bell className="h-4 w-4 text-gray-500" />
    }
  }

  // Iconos para estado
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'failed': return <XCircle className="h-4 w-4 text-red-500" />
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />
      case 'retrying': return <WarningCircle className="h-4 w-4 text-orange-500" />
      default: return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  // Obtener color de badge para el estado
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'sent': return 'default'
      case 'failed': return 'destructive'
      case 'pending': return 'secondary'
      case 'retrying': return 'outline'
      default: return 'secondary'
    }
  }

  // Formatear mensaje para preview
  const formatMessagePreview = (message: string, maxLength: number = 100) => {
    if (message.length <= maxLength) return message
    return message.substring(0, maxLength) + '...'
  }

  // Exportar historial
  const exportHistory = () => {
    const dataStr = JSON.stringify(filteredHistory, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `notification-history-${new Date().toISOString().split('T')[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              📋 Historial de Notificaciones
              <Badge variant="outline">{filteredHistory.length} de {history.length}</Badge>
            </CardTitle>
            <CardDescription>
              Seguimiento de todas las notificaciones enviadas y su estado
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={exportHistory}>
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
            <Button variant="outline" size="sm" onClick={clearHistory}>
              <Trash2 className="h-4 w-4 mr-2" />
              Limpiar
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Estadísticas rápidas */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="text-center p-3 bg-muted rounded-lg">
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="text-sm text-muted-foreground">Total</div>
          </div>
          <div className="text-center p-3 bg-green-50 dark:bg-green-950 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{stats.sent}</div>
            <div className="text-sm text-muted-foreground">Enviadas</div>
          </div>
          <div className="text-center p-3 bg-red-50 dark:bg-red-950 rounded-lg">
            <div className="text-2xl font-bold text-red-600">{stats.failed}</div>
            <div className="text-sm text-muted-foreground">Fallidas</div>
          </div>
          <div className="text-center p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
            <div className="text-sm text-muted-foreground">Pendientes</div>
          </div>
          <div className="text-center p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{stats.successRate}%</div>
            <div className="text-sm text-muted-foreground">Éxito</div>
          </div>
        </div>

        <Separator />

        <Tabs defaultValue="list" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="list">Lista de Notificaciones</TabsTrigger>
            <TabsTrigger value="details">Detalles</TabsTrigger>
          </TabsList>

          <TabsContent value="list" className="space-y-4">
            {/* Filtros */}
            <div className="flex flex-wrap gap-4 p-4 bg-muted rounded-lg">
              <div className="flex items-center gap-2">
                <MagnifyingGlass className="h-4 w-4" />
                <Input
                  placeholder="Buscar notificaciones..."
                  value={filters.search}
                  onChange={(e) => setFunnels(prev => ({ ...prev, search: e.target.value }))}
                  className="w-64"
                />
              </div>

              <Select
                value={filters.status}
                onValueChange={(value) => setFunnels(prev => ({ ...prev, status: value }))}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="sent">Enviadas</SelectItem>
                  <SelectItem value="failed">Fallidas</SelectItem>
                  <SelectItem value="pending">Pendientes</SelectItem>
                  <SelectItem value="retrying">Reintentando</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={filters.channel}
                onValueChange={(value) => setFunnels(prev => ({ ...prev, channel: value }))}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los canales</SelectItem>
                  {uniqueChannels.map(channel => (
                    <SelectItem key={channel} value={channel}>
                      {channel.charAt(0).toUpperCase() + channel.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={filters.eventType}
                onValueChange={(value) => setFunnels(prev => ({ ...prev, eventType: value }))}
              >
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los eventos</SelectItem>
                  {uniqueEventTypes.map(eventType => (
                    <SelectItem key={eventType} value={eventType}>
                      {eventType.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={filters.dateRange}
                onValueChange={(value) => setFunnels(prev => ({ ...prev, dateRange: value }))}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todo el tiempo</SelectItem>
                  <SelectItem value="1h">Última hora</SelectItem>
                  <SelectItem value="24h">Últimas 24h</SelectItem>
                  <SelectItem value="7d">Últimos 7 días</SelectItem>
                  <SelectItem value="30d">Últimos 30 días</SelectItem>
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setFunnels({
                  status: 'all',
                  channel: 'all',
                  eventType: 'all',
                  dateRange: 'all',
                  search: ''
                })}
              >
                <Funnel className="h-4 w-4 mr-2" />
                Limpiar filtros
              </Button>
            </div>

            {/* Lista de notificaciones */}
            <ScrollArea className="h-96">
              <div className="space-y-2">
                {filteredHistory.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No hay notificaciones que mostrar</p>
                    <p className="text-sm">Ajusta los filtros o envía algunas notificaciones</p>
                  </div>
                ) : (
                  filteredHistory.map((notification) => (
                    <div
                      key={notification.id}
                      className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => setSelectedNotification(notification)}
                    >
                      <div className="flex items-center gap-2">
                        {getEventIcon(notification.eventType)}
                        {getStatusIcon(notification.status)}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">
                            {notification.eventType.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </span>
                          <Badge variant={getStatusBadgeVariant(notification.status)} className="text-xs">
                            {notification.status}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {notification.channel}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">
                          {formatMessagePreview(notification.message)}
                        </p>
                      </div>

                      <div className="text-right text-sm text-muted-foreground">
                        <div>
                          {formatDistanceToNow(new Date(notification.createdAt), { 
                            addSuffix: true, 
                            locale: es 
                          })}
                        </div>
                        {notification.retryCount > 0 && (
                          <div className="text-xs text-orange-500">
                            {notification.retryCount} reintentos
                          </div>
                        )}
                      </div>

                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="details" className="space-y-4">
            {selectedNotification ? (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Detalles de la notificación</h3>
                  <Badge variant={getStatusBadgeVariant(selectedNotification.status)}>
                    {selectedNotification.status}
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">ID</label>
                      <p className="font-mono text-sm">{selectedNotification.id}</p>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Tipo de evento</label>
                      <p className="flex items-center gap-2">
                        {getEventIcon(selectedNotification.eventType)}
                        {selectedNotification.eventType.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </p>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Canal</label>
                      <p className="capitalize">{selectedNotification.channel}</p>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Estado</label>
                      <p className="flex items-center gap-2">
                        {getStatusIcon(selectedNotification.status)}
                        {selectedNotification.status}
                      </p>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Reintentos</label>
                      <p>{selectedNotification.retryCount}</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Creado</label>
                      <p>{new Date(selectedNotification.createdAt).toLocaleString()}</p>
                    </div>

                    {selectedNotification.sentAt && (
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">Enviado</label>
                        <p>{new Date(selectedNotification.sentAt).toLocaleString()}</p>
                      </div>
                    )}

                    {selectedNotification.deliveredAt && (
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">Entregado</label>
                        <p>{new Date(selectedNotification.deliveredAt).toLocaleString()}</p>
                      </div>
                    )}

                    {selectedNotification.failureReason && (
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">Razón del fallo</label>
                        <p className="text-red-600">{selectedNotification.failureReason}</p>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-muted-foreground">Mensaje</label>
                  <div className="mt-2 p-4 bg-muted rounded-lg">
                    <pre className="text-sm whitespace-pre-wrap">{selectedNotification.message}</pre>
                  </div>
                </div>

                {selectedNotification.metadata && Object.keys(selectedNotification.metadata).length > 0 && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Metadatos</label>
                    <div className="mt-2 p-4 bg-muted rounded-lg">
                      <pre className="text-sm">{JSON.stringify(selectedNotification.metadata, null, 2)}</pre>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Eye className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Selecciona una notificación para ver sus detalles</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}