import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Switch } from '../ui/switch'
import { Textarea } from '../ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Badge } from '../ui/badge'
import { Alert, AlertDescription } from '../ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { Separator } from '../ui/separator'
import { useNotifications } from './RealTimeNotificationProvider'
import { DiscordConfig, NotificationChannel, DiscordEmbed } from './types'
import { PaperPlane, TestTube, CheckCircle, XCircle, WarningCircle, Copy, Palette, Link } from 'lucide-react'
import { useToast } from '../../hooks/use-toast'

interface Props {
  onConfigChange?: (config: DiscordConfig) => void
}

export function DiscordNotificationConfig({ onConfigChange }: Props) {
  const { config, updateConfig, sendTestNotification } = useNotifications()
  const { toast } = useToast()
  
  const [discordConfig, setDiscordConfig] = useState<DiscordConfig>({
    webhookUrl: '',
    username: 'ArbitrageX Pro',
    avatarUrl: '',
    embeds: true,
    tts: false
  })
  
  const [isTestingConnection, setIsTestingConnection] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState<'untested' | 'success' | 'error'>('untested')
  const [testResult, setTestResult] = useState<string>('')
  const [isEnabled, setIsEnabled] = useState(false)
  const [embedPreview, setEmbedPreview] = useState<DiscordEmbed>({
    title: '🚀 ArbitrageX Pro - Notificación de Prueba',
    description: 'Esta es una notificación de prueba del sistema de arbitraje',
    color: 0x00ff88,
    timestamp: new Date().toISOString(),
    footer: {
      text: 'ArbitrageX Pro 2025',
      icon_url: 'https://cdn.discordapp.com/attachments/123/bot-icon.png'
    },
    fields: [
      {
        name: '💰 Profit Estimado',
        value: '$1,250.50',
        inline: true
      },
      {
        name: '📈 ROI',
        value: '15.3%',
        inline: true
      },
      {
        name: '⚡ Estrategia',
        value: 'Cross-DEX Arbitrage',
        inline: true
      }
    ]
  })

  // Cargar configuración existente
  useEffect(() => {
    const discordChannel = config?.channels.find(ch => ch.type === 'discord')
    if (discordChannel) {
      setDiscordConfig(discordChannel.config as DiscordConfig)
      setIsEnabled(discordChannel.enabled)
    }
  }, [config])

  // Manejar cambios en la configuración
  const handleConfigChange = (key: keyof DiscordConfig, value: any) => {
    const newConfig = { ...discordConfig, [key]: value }
    setDiscordConfig(newConfig)
    onConfigChange?.(newConfig)
  }

  // Validar URL de webhook
  const isValidWebhookUrl = (url: string): boolean => {
    const webhookPattern = /^https:\/\/(canary\.|ptb\.)?discord\.com\/api\/webhooks\/\d+\/[\w-]+$/
    return webhookPattern.test(url)
  }

  // Probar conexión con Discord
  const testConnection = async () => {
    if (!discordConfig.webhookUrl) {
      toast({
        title: "URL de webhook requerida",
        description: "Por favor, proporciona una URL de webhook válida",
        variant: "destructive"
      })
      return
    }

    if (!isValidWebhookUrl(discordConfig.webhookUrl)) {
      toast({
        title: "URL de webhook inválida",
        description: "La URL debe ser un webhook válido de Discord",
        variant: "destructive"
      })
      return
    }

    setIsTestingConnection(true)
    setConnectionStatus('untested')
    
    try {
      const testPayload = {
        username: discordConfig.username || 'ArbitrageX Pro',
        avatar_url: discordConfig.avatarUrl || undefined,
        embeds: discordConfig.embeds ? [embedPreview] : undefined,
        content: discordConfig.embeds ? undefined : '🤖 **ArbitrageX Pro 2025 - Test de Conexión**\n\n✅ Conexión establecida exitosamente!\n⏰ Timestamp: ' + new Date().toLocaleString() + '\n\n🚀 Las notificaciones están funcionando correctamente!'
      }

      const response = await fetch(discordConfig.webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(testPayload)
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Error ${response.status}: ${errorText}`)
      }

      setConnectionStatus('success')
      setTestResult('Mensaje de prueba enviado exitosamente')
      
      toast({
        title: "✅ Conexión exitosa",
        description: "El webhook de Discord está funcionando correctamente",
        variant: "default"
      })
      
    } catch (error) {
      setConnectionStatus('error')
      setTestResult(error instanceof Error ? error.message : 'Error desconocido')
      
      toast({
        title: "❌ Error de conexión",
        description: error instanceof Error ? error.message : 'Error al conectar con Discord',
        variant: "destructive"
      })
    } finally {
      setIsTestingConnection(false)
    }
  }

  // Guardar configuración
  const saveConfiguration = async () => {
    try {
      if (!config) return

      const discordChannel: NotificationChannel = {
        type: 'discord',
        id: 'discord-primary',
        name: 'Canal Principal Discord',
        enabled: isEnabled,
        config: discordConfig,
        priority: 'high'
      }

      const updatedChannels = config.channels.filter(ch => ch.type !== 'discord')
      updatedChannels.push(discordChannel)

      await updateConfig({
        channels: updatedChannels
      })

      toast({
        title: "✅ Configuración guardada",
        description: "La configuración de Discord ha sido guardada exitosamente",
        variant: "default"
      })
      
    } catch (error) {
      toast({
        title: "❌ Error al guardar",
        description: error instanceof Error ? error.message : 'Error al guardar la configuración',
        variant: "destructive"
      })
    }
  }

  // Copiar al portapapeles
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "📋 Copiado",
      description: "Texto copiado al portapapeles",
      variant: "default"
    })
  }

  // Actualizar embed preview
  const updateEmbedPreview = (field: keyof DiscordEmbed, value: any) => {
    setEmbedPreview(prev => ({ ...prev, [field]: value }))
  }

  const getStatusIcon = () => {
    switch (connectionStatus) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'error': return <XCircle className="h-4 w-4 text-red-500" />
      default: return <WarningCircle className="h-4 w-4 text-yellow-500" />
    }
  }

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'success': return 'bg-green-500'
      case 'error': return 'bg-red-500'
      default: return 'bg-yellow-500'
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              💜 Configuración de Discord
              <Badge variant={isEnabled ? "default" : "secondary"}>
                {isEnabled ? "Activo" : "Inactivo"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Configura las notificaciones en tiempo real vía Discord Webhooks
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${getStatusColor()}`}></div>
            {getStatusIcon()}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Toggle principal */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="discord-enabled" className="text-base font-medium">
              Habilitar notificaciones Discord
            </Label>
            <p className="text-sm text-muted-foreground mt-1">
              Activar/desactivar todas las notificaciones de Discord
            </p>
          </div>
          <Switch
            id="discord-enabled"
            checked={isEnabled}
            onCheckedChange={setIsEnabled}
          />
        </div>

        <Separator />

        <Tabs defaultValue="config" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="config">Configuración</TabsTrigger>
            <TabsTrigger value="embeds">Embeds</TabsTrigger>
            <TabsTrigger value="test">Pruebas</TabsTrigger>
            <TabsTrigger value="help">Ayuda</TabsTrigger>
          </TabsList>

          <TabsContent value="config" className="space-y-4">
            {/* Webhook URL */}
            <div className="space-y-2">
              <Label htmlFor="webhook-url">Webhook URL *</Label>
              <div className="flex gap-2">
                <Input
                  id="webhook-url"
                  type="password"
                  placeholder="https://discord.com/api/webhooks/123456789/ABCDEFGHIJK..."
                  value={discordConfig.webhookUrl}
                  onChange={(e) => handleConfigChange('webhookUrl', e.target.value)}
                  className={`flex-1 ${
                    discordConfig.webhookUrl && !isValidWebhookUrl(discordConfig.webhookUrl)
                      ? 'border-red-500' 
                      : ''
                  }`}
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(discordConfig.webhookUrl)}
                  disabled={!discordConfig.webhookUrl}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              {discordConfig.webhookUrl && !isValidWebhookUrl(discordConfig.webhookUrl) && (
                <p className="text-xs text-red-500">
                  La URL debe ser un webhook válido de Discord
                </p>
              )}
              <p className="text-xs text-muted-foreground">
                URL del webhook creado en tu servidor de Discord
              </p>
            </div>

            {/* Username personalizado */}
            <div className="space-y-2">
              <Label htmlFor="username">Nombre del bot</Label>
              <Input
                id="username"
                placeholder="ArbitrageX Pro"
                value={discordConfig.username || ''}
                onChange={(e) => handleConfigChange('username', e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Nombre que aparecerá como remitente de los mensajes
              </p>
            </div>

            {/* Avatar URL */}
            <div className="space-y-2">
              <Label htmlFor="avatar-url">URL del avatar (opcional)</Label>
              <Input
                id="avatar-url"
                type="url"
                placeholder="https://example.com/avatar.png"
                value={discordConfig.avatarUrl || ''}
                onChange={(e) => handleConfigChange('avatarUrl', e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Imagen que aparecerá como avatar del bot
              </p>
            </div>

            {/* Thread ID */}
            <div className="space-y-2">
              <Label htmlFor="thread-id">Thread ID (opcional)</Label>
              <Input
                id="thread-id"
                placeholder="1234567890123456789"
                value={discordConfig.threadId || ''}
                onChange={(e) => handleConfigChange('threadId', e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                ID del hilo para enviar mensajes en un hilo específico
              </p>
            </div>

            {/* Opciones adicionales */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Usar embeds enriquecidos</Label>
                  <p className="text-sm text-muted-foreground">
                    Mensajes con formato enriquecido y colores
                  </p>
                </div>
                <Switch
                  checked={discordConfig.embeds || false}
                  onCheckedChange={(checked) => 
                    handleConfigChange('embeds', checked)
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Text-to-Speech (TTS)</Label>
                  <p className="text-sm text-muted-foreground">
                    Los mensajes se leerán en voz alta
                  </p>
                </div>
                <Switch
                  checked={discordConfig.tts || false}
                  onCheckedChange={(checked) => 
                    handleConfigChange('tts', checked)
                  }
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="embeds" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Configuración de embed */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Configuración de Embed
                </h3>

                <div className="space-y-3">
                  <div>
                    <Label htmlFor="embed-title">Título</Label>
                    <Input
                      id="embed-title"
                      value={embedPreview.title || ''}
                      onChange={(e) => updateEmbedPreview('title', e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="embed-description">Descripción</Label>
                    <Textarea
                      id="embed-description"
                      value={embedPreview.description || ''}
                      onChange={(e) => updateEmbedPreview('description', e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="embed-color">Color (hex)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="embed-color"
                        placeholder="#00ff88"
                        value={`#${embedPreview.color?.toString(16).padStart(6, '0') || '00ff88'}`}
                        onChange={(e) => {
                          const hex = e.target.value.replace('#', '')
                          const color = parseInt(hex, 16)
                          if (!isNaN(color)) {
                            updateEmbedPreview('color', color)
                          }
                        }}
                      />
                      <div 
                        className="w-10 h-10 rounded border"
                        style={{ backgroundColor: `#${embedPreview.color?.toString(16).padStart(6, '0') || '00ff88'}` }}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="embed-footer">Texto del footer</Label>
                    <Input
                      id="embed-footer"
                      value={embedPreview.footer?.text || ''}
                      onChange={(e) => updateEmbedPreview('footer', { 
                        ...embedPreview.footer, 
                        text: e.target.value 
                      })}
                    />
                  </div>
                </div>
              </div>

              {/* Preview del embed */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Vista previa</h3>
                <div className="border rounded-lg p-4 bg-gray-50 dark:bg-gray-900">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm font-bold">
                      A
                    </div>
                    <div>
                      <div className="font-medium">{discordConfig.username || 'ArbitrageX Pro'}</div>
                      <div className="text-xs text-muted-foreground">BOT — Hoy a las {new Date().toLocaleTimeString()}</div>
                    </div>
                  </div>
                  
                  {discordConfig.embeds ? (
                    <div className="border-l-4 pl-4 py-3 bg-card rounded" style={{ borderLeftColor: `#${embedPreview.color?.toString(16).padStart(6, '0') || '00ff88'}` }}>
                      {embedPreview.title && (
                        <div className="font-bold text-blue-400 mb-2">{embedPreview.title}</div>
                      )}
                      {embedPreview.description && (
                        <div className="text-sm mb-3">{embedPreview.description}</div>
                      )}
                      {embedPreview.fields && (
                        <div className="grid grid-cols-1 gap-2">
                          {embedPreview.fields.map((field, idx) => (
                            <div key={idx} className={`${field.inline ? 'inline-block w-1/3' : 'block'}`}>
                              <div className="font-medium text-sm">{field.name}</div>
                              <div className="text-sm text-muted-foreground">{field.value}</div>
                            </div>
                          ))}
                        </div>
                      )}
                      {embedPreview.footer && (
                        <div className="text-xs text-muted-foreground mt-3">
                          {embedPreview.footer.text}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-sm">
                      🤖 **ArbitrageX Pro 2025 - Notificación**{'\n\n'}
                      ✅ Mensaje de texto simple{'\n'}
                      ⏰ {new Date().toLocaleString()}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="test" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">Probar conexión</h3>
                  <p className="text-sm text-muted-foreground">
                    Envía un mensaje de prueba para verificar la configuración
                  </p>
                </div>
                <Button
                  onClick={testConnection}
                  disabled={isTestingConnection || !discordConfig.webhookUrl || !isValidWebhookUrl(discordConfig.webhookUrl)}
                  className="min-w-[120px]"
                >
                  {isTestingConnection ? (
                    <>
                      <TestTube className="h-4 w-4 mr-2 animate-spin" />
                      Probando...
                    </>
                  ) : (
                    <>
                      <PaperPlane className="h-4 w-4 mr-2" />
                      Probar
                    </>
                  )}
                </Button>
              </div>

              {connectionStatus !== 'untested' && (
                <Alert className={connectionStatus === 'success' ? 'border-green-500' : 'border-red-500'}>
                  <AlertDescription className="flex items-center gap-2">
                    {getStatusIcon()}
                    <span>{testResult}</span>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </TabsContent>

          <TabsContent value="help" className="space-y-4">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-3 flex items-center gap-2">
                  <Link className="h-5 w-5" />
                  Cómo crear un Webhook de Discord
                </h3>
                <ol className="space-y-2 text-sm list-decimal list-inside text-muted-foreground">
                  <li>Ve a tu servidor de Discord y selecciona el canal donde quieres recibir notificaciones</li>
                  <li>Haz clic en la rueda de configuración del canal</li>
                  <li>Ve a la sección "Integraciones" → "Webhooks"</li>
                  <li>Haz clic en "Crear Webhook"</li>
                  <li>Personaliza el nombre y avatar del webhook</li>
                  <li>Copia la URL del webhook y pégala en el campo de arriba</li>
                </ol>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-3">🎨 Personalización de embeds</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p><strong>Embeds:</strong> Los embeds permiten mensajes más ricos con colores, campos y formatos especiales</p>
                  <p><strong>Color:</strong> Usa códigos hexadecimales (#RRGGBB) para personalizar el color de la barra lateral</p>
                  <p><strong>Campos:</strong> Los campos pueden ser inline (en línea) o de bloque completo</p>
                  <p><strong>Footer:</strong> Aparece al final del embed en texto pequeño</p>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-3">🔧 Configuración avanzada</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p><strong>Thread ID:</strong> Para enviar mensajes a un hilo específico dentro del canal</p>
                  <p><strong>TTS:</strong> Los mensajes se leerán en voz alta a los usuarios conectados</p>
                  <p><strong>Username/Avatar:</strong> Personaliza cómo aparece el bot en el chat</p>
                  <p><strong>Rate limits:</strong> Discord permite hasta 30 mensajes por minuto por webhook</p>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-3">⚠️ Limitaciones importantes</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>• Máximo 2000 caracteres por mensaje</p>
                  <p>• Máximo 25 campos por embed</p>
                  <p>• Máximo 10 embeds por mensaje</p>
                  <p>• Rate limit: 30 requests por minuto</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <Separator />

        {/* Botones de acción */}
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => {
            setDiscordConfig({ webhookUrl: '', username: 'ArbitrageX Pro', embeds: true, tts: false })
            setIsEnabled(false)
            setConnectionStatus('untested')
            setTestResult('')
          }}>
            Resetear
          </Button>
          <Button 
            onClick={saveConfiguration}
            disabled={!discordConfig.webhookUrl || !isValidWebhookUrl(discordConfig.webhookUrl)}
          >
            Guardar configuración
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}