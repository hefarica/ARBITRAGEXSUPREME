import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Bell,
  BellSlash,
  BellRinging,
  SpeakerHigh,
  SpeakerX,
  Smartphone,
  Monitor,
  Tablet,
  Globe,
  Wifi,
  WifiOff,
  CheckCircle,
  XCircle,
  Warning,
  Info,
  AlertTriangle,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Clock,
  Calendar,
  User,
  Settings,
  VolumeHigh,
  VolumeLow,
  VolumeX,
  MessageCircle,
  Envelope,
  Phone,
  VideoCamera,
  Microphone,
  Headphones,
  Radio,
  Television,
  Broadcast,
  Satellite,
  Signal,
  SignalHigh,
  SignalMedium,
  SignalLow,
  Battery,
  BatteryCharging,
  BatteryWarning,
  BatteryEmpty,
  Power,
  PowerOff,
  PowerOn,
  PowerWarning,
  PowerError,
  PowerSuccess,
  PowerInfo,
  PowerQuestion,
  PowerPlus,
  PowerMinus,
  PowerEqual,
  PowerDivide,
  PowerMultiply,
  PowerPercent,
  PowerSquare,
  PowerCube,
  PowerRoot,
  PowerLog,
  PowerLn,
  PowerExp,
  PowerSin,
  PowerCos,
  PowerTan,
  PowerAsin,
  PowerAcos,
  PowerAtan,
  PowerSinh,
  PowerCosh,
  PowerTanh,
  PowerAsinh,
  PowerAcosh,
  PowerAtanh
} from '@phosphor-icons/react'
import { cn } from '@/lib/utils'

interface Notification {
  id: string
  type: 'success' | 'warning' | 'error' | 'info' | 'profit' | 'loss'
  title: string
  message: string
  priority: 'low' | 'medium' | 'high' | 'critical'
  timestamp: Date
  read: boolean
  actionable: boolean
  action?: string
  device: 'mobile' | 'desktop' | 'tablet' | 'all'
  channel: 'push' | 'email' | 'sms' | 'voice' | 'in-app'
}

interface NotificationConfig {
  push: boolean
  email: boolean
  sms: boolean
  voice: boolean
  inApp: boolean
  emergencyOnly: boolean
  quietHours: {
    enabled: boolean
    start: string
    end: string
  }
  devices: {
    mobile: boolean
    desktop: boolean
    tablet: boolean
  }
  channels: {
    telegram: boolean
    discord: boolean
    slack: boolean
    webhook: boolean
  }
}

export function AdvancedNotificationSystem2025() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [config, setConfig] = useState<NotificationConfig>({
    push: true,
    email: false,
    sms: false,
    voice: true,
    inApp: true,
    emergencyOnly: false,
    quietHours: {
      enabled: false,
      start: '22:00',
      end: '08:00'
    },
    devices: {
      mobile: true,
      desktop: true,
      tablet: true
    },
    channels: {
      telegram: false,
      discord: false,
      slack: false,
      webhook: false
    }
  })

  const [mobileDashboard, setMobileDashboard] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(true)

  // Simulación de notificaciones en tiempo real
  useEffect(() => {
    const generateNotification = (): Notification => {
      const types: Array<Notification['type']> = ['success', 'warning', 'error', 'info', 'profit', 'loss']
      const priorities: Array<Notification['priority']> = ['low', 'medium', 'high', 'critical']
      const devices: Array<Notification['device']> = ['mobile', 'desktop', 'tablet', 'all']
      const channels: Array<Notification['channel']> = ['push', 'email', 'sms', 'voice', 'in-app']
      
      const type = types[Math.floor(Math.random() * types.length)]
      const priority = priorities[Math.floor(Math.random() * priorities.length)]
      
      let title = ''
      let message = ''
      
      switch (type) {
        case 'profit':
          title = '¡Ganancia Detectada!'
          message = `Operación exitosa: +$${(Math.random() * 100 + 10).toFixed(2)}`
          break
        case 'loss':
          title = 'Pérdida Detectada'
          message = `Operación fallida: -$${(Math.random() * 50 + 5).toFixed(2)}`
          break
        case 'warning':
          title = 'Advertencia del Sistema'
          message = 'Volatilidad de mercado detectada'
          break
        case 'error':
          title = 'Error del Sistema'
          message = 'Fallo en la ejecución de operación'
          break
        case 'success':
          title = 'Operación Completada'
          message = 'Estrategia ejecutada exitosamente'
          break
        default:
          title = 'Información del Sistema'
          message = 'Actualización de estado disponible'
      }
      
      return {
        id: crypto.randomUUID(),
        type,
        title,
        message,
        priority,
        timestamp: new Date(),
        read: false,
        actionable: Math.random() > 0.5,
        action: Math.random() > 0.7 ? 'Ver Detalles' : undefined,
        device: devices[Math.floor(Math.random() * devices.length)],
        channel: channels[Math.floor(Math.random() * channels.length)]
      }
    }

    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        const newNotification = generateNotification()
        setNotifications(prev => [newNotification, ...prev.slice(0, 19)])
        
        // Simular notificación de voz
        if (voiceEnabled && newNotification.priority === 'critical') {
          speakNotification(newNotification)
        }
      }
    }, 3000)

    return () => clearInterval(interval)
  }, [voiceEnabled])

  const speakNotification = (notification: Notification) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(
        `${notification.title}. ${notification.message}`
      )
      utterance.lang = 'es-ES'
      utterance.rate = 0.9
      speechSynthesis.speak(utterance)
    }
  }

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => prev.map(notif => 
      notif.id === notificationId ? { ...notif, read: true } : notif
    ))
  }

  const clearAllNotifications = () => {
    setNotifications([])
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle size={20} className="text-green-600" />
      case 'warning': return <Warning size={20} className="text-yellow-600" />
      case 'error': return <XCircle size={20} className="text-red-600" />
      case 'info': return <Info size={20} className="text-blue-600" />
      case 'profit': return <TrendingUp size={20} className="text-green-600" />
      case 'loss': return <TrendingDown size={20} className="text-red-600" />
      default: return <Info size={20} className="text-gray-600" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const unreadCount = notifications.filter(n => !n.read).length
  const criticalCount = notifications.filter(n => n.priority === 'critical').length

  return (
    <div className="space-y-6">
      {/* Header del Sistema de Notificaciones */}
      <div className="bg-gradient-to-r from-orange-600 to-red-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <BellRinging size={32} />
            <div>
              <h1 className="text-2xl font-bold">Sistema de Notificaciones Avanzado</h1>
              <p className="text-orange-100">Mantente informado en tiempo real</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <Bell size={20} />
                <span className="text-xl font-bold">{unreadCount}</span>
              </div>
              <p className="text-sm text-orange-100">No leídas</p>
            </div>
            
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle size={20} />
                <span className="text-xl font-bold">{criticalCount}</span>
              </div>
              <p className="text-sm text-orange-100">Críticas</p>
            </div>
          </div>
        </div>
        
        {/* Estado de Canales */}
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Wifi size={20} className="text-green-300" />
            </div>
            <p className="text-sm text-orange-100">Push</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <SpeakerHigh size={20} className="text-green-300" />
            </div>
            <p className="text-sm text-orange-100">Voz</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Smartphone size={20} className="text-green-300" />
            </div>
            <p className="text-sm text-orange-100">Móvil</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Globe size={20} className="text-green-300" />
            </div>
            <p className="text-sm text-orange-100">Web</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="notifications" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="notifications">Notificaciones</TabsTrigger>
          <TabsTrigger value="mobile">Dashboard Móvil</TabsTrigger>
          <TabsTrigger value="voice">Alertas de Voz</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="notifications" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Lista de Notificaciones */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Bell size={20} />
                      Notificaciones Recientes
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={config.emergencyOnly}
                        onCheckedChange={(checked) => setConfig(prev => ({ ...prev, emergencyOnly: checked }))}
                      />
                      <span className="text-sm">Solo Emergencias</span>
                      <Button variant="outline" size="sm" onClick={clearAllNotifications}>
                        Limpiar Todo
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {notifications.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Bell size={48} className="mx-auto mb-4 opacity-50" />
                      <p>No hay notificaciones nuevas</p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {notifications
                        .filter(n => !config.emergencyOnly || n.priority === 'critical')
                        .map((notification) => (
                        <div key={notification.id} className={cn(
                          "p-4 rounded-lg border transition-all duration-300",
                          notification.read ? "bg-gray-50 border-gray-200" : "bg-white border-blue-200",
                          getPriorityColor(notification.priority)
                        )}>
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3 flex-1">
                              {getNotificationIcon(notification.type)}
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <h4 className="font-semibold">{notification.title}</h4>
                                  <Badge variant="outline" className="text-xs">
                                    {notification.priority}
                                  </Badge>
                                </div>
                                <p className="text-sm mb-2">{notification.message}</p>
                                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                  <span>{notification.timestamp.toLocaleTimeString()}</span>
                                  <span>{notification.device}</span>
                                  <span>{notification.channel}</span>
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex flex-col gap-2">
                              {!notification.read && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => markAsRead(notification.id)}
                                >
                                  Marcar Leída
                                </Button>
                              )}
                              {notification.actionable && notification.action && (
                                <Button size="sm">
                                  {notification.action}
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Panel de Estado */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings size={20} />
                    Estado del Sistema
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Notificaciones Push</span>
                      <Badge className={config.push ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                        {config.push ? "Activo" : "Inactivo"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Alertas de Voz</span>
                      <Badge className={config.voice ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                        {config.voice ? "Activo" : "Inactivo"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Modo Solo Emergencias</span>
                      <Badge className={config.emergencyOnly ? "bg-orange-100 text-orange-800" : "bg-gray-100 text-gray-800"}>
                        {config.emergencyOnly ? "Activado" : "Desactivado"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Horas Silenciosas</span>
                      <Badge className={config.quietHours.enabled ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-800"}>
                        {config.quietHours.enabled ? "Activado" : "Desactivado"}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe size={20} />
                    Canales Conectados
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Telegram</span>
                      <Badge className={config.channels.telegram ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                        {config.channels.telegram ? "Conectado" : "Desconectado"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Discord</span>
                      <Badge className={config.channels.discord ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                        {config.channels.discord ? "Conectado" : "Desconectado"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Slack</span>
                      <Badge className={config.channels.slack ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                        {config.channels.slack ? "Conectado" : "Desconectado"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Webhook</span>
                      <Badge className={config.channels.webhook ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                        {config.channels.webhook ? "Conectado" : "Desconectado"}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="mobile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Smartphone size={20} />
                Dashboard Móvil
              </CardTitle>
              <p className="text-muted-foreground">
                Vista optimizada para dispositivos móviles
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Vista Móvil Simulada */}
                <div className="border-2 border-gray-300 rounded-3xl p-4 bg-gray-100 max-w-sm mx-auto">
                  <div className="bg-white rounded-2xl p-4 space-y-4">
                    {/* Header Móvil */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Bell size={20} className="text-blue-600" />
                        <span className="font-bold">ArbitrageX</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        {unreadCount} nuevas
                      </Badge>
                    </div>
                    
                    {/* Notificaciones Móviles */}
                    <div className="space-y-3">
                      {notifications.slice(0, 3).map((notification) => (
                        <div key={notification.id} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-start gap-2">
                            {getNotificationIcon(notification.type)}
                            <div className="flex-1">
                              <h4 className="font-semibold text-sm">{notification.title}</h4>
                              <p className="text-xs text-muted-foreground">{notification.message}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {notification.timestamp.toLocaleTimeString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    {/* Controles Móviles */}
                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1">
                        Ver Todas
                      </Button>
                      <Button size="sm" variant="outline">
                        Config
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Controles de Dispositivos */}
                <div className="space-y-4">
                  <h3 className="font-semibold">Dispositivos Conectados</h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Smartphone size={24} className="text-blue-600" />
                        <div>
                          <p className="font-medium">iPhone 15 Pro</p>
                          <p className="text-sm text-muted-foreground">Última conexión: 2 min</p>
                        </div>
                      </div>
                      <Switch
                        checked={config.devices.mobile}
                        onCheckedChange={(checked) => setConfig(prev => ({
                          ...prev,
                          devices: { ...prev.devices, mobile: checked }
                        }))}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Tablet size={24} className="text-green-600" />
                        <div>
                          <p className="font-medium">iPad Pro</p>
                          <p className="text-sm text-muted-foreground">Última conexión: 15 min</p>
                        </div>
                      </div>
                      <Switch
                        checked={config.devices.tablet}
                        onCheckedChange={(checked) => setConfig(prev => ({
                          ...prev,
                          devices: { ...prev.devices, tablet: checked }
                        }))}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Monitor size={24} className="text-purple-600" />
                        <div>
                          <p className="font-medium">MacBook Pro</p>
                          <p className="text-sm text-muted-foreground">Conectado ahora</p>
                        </div>
                      </div>
                      <Switch
                        checked={config.devices.desktop}
                        onCheckedChange={(checked) => setConfig(prev => ({
                          ...prev,
                          devices: { ...prev.devices, desktop: checked }
                        }))}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="voice" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <SpeakerHigh size={20} />
                Alertas de Voz
              </CardTitle>
              <p className="text-muted-foreground">
                Configura notificaciones de voz para eventos críticos
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Configuración de Voz */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Alertas de Voz</span>
                    <Switch
                      checked={config.voice}
                      onCheckedChange={(checked) => setConfig(prev => ({ ...prev, voice: checked }))}
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-semibold">Tipos de Alertas</h4>
                    
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <DollarSign size={16} className="text-green-600" />
                        <span className="text-sm">Ganancias Altas</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <AlertTriangle size={16} className="text-red-600" />
                        <span className="text-sm">Errores Críticos</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <Warning size={16} className="text-yellow-600" />
                        <span className="text-sm">Advertencias</span>
                      </div>
                      <Switch />
                    </div>
                    
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <Info size={16} className="text-blue-600" />
                        <span className="text-sm">Información General</span>
                      </div>
                      <Switch />
                    </div>
                  </div>
                </div>

                {/* Prueba de Voz */}
                <div className="space-y-4">
                  <h4 className="font-semibold">Prueba de Voz</h4>
                  
                  <div className="space-y-3">
                    <Button
                      onClick={() => speakNotification({
                        id: 'test',
                        type: 'profit',
                        title: 'Prueba de Voz',
                        message: 'Esta es una prueba del sistema de alertas de voz',
                        priority: 'high',
                        timestamp: new Date(),
                        read: false,
                        actionable: false,
                        device: 'all',
                        channel: 'voice'
                      })}
                      className="w-full gap-2"
                    >
                      <SpeakerHigh size={16} />
                      Probar Alerta de Ganancia
                    </Button>
                    
                    <Button
                      onClick={() => speakNotification({
                        id: 'test2',
                        type: 'error',
                        title: 'Prueba de Error',
                        message: 'Esta es una prueba de alerta de error crítico',
                        priority: 'critical',
                        timestamp: new Date(),
                        read: false,
                        actionable: false,
                        device: 'all',
                        channel: 'voice'
                      })}
                      variant="destructive"
                      className="w-full gap-2"
                    >
                      <AlertTriangle size={16} />
                      Probar Alerta de Error
                    </Button>
                  </div>
                  
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h5 className="font-semibold text-blue-800 mb-2">Configuración de Voz</h5>
                    <div className="space-y-2 text-sm text-blue-700">
                      <p>• Idioma: Español</p>
                      <p>• Velocidad: Normal</p>
                      <p>• Volumen: Alto</p>
                      <p>• Solo emergencias: {config.emergencyOnly ? 'Sí' : 'No'}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Configuración General */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings size={20} />
                  Configuración General
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Notificaciones Push</span>
                  <Switch
                    checked={config.push}
                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, push: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Notificaciones por Email</span>
                  <Switch
                    checked={config.email}
                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, email: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Notificaciones SMS</span>
                  <Switch
                    checked={config.sms}
                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, sms: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Notificaciones en App</span>
                  <Switch
                    checked={config.inApp}
                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, inApp: checked }))}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Configuración Avanzada */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell size={20} />
                  Configuración Avanzada
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Modo Solo Emergencias</span>
                  <Switch
                    checked={config.emergencyOnly}
                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, emergencyOnly: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Horas Silenciosas</span>
                  <Switch
                    checked={config.quietHours.enabled}
                    onCheckedChange={(checked) => setConfig(prev => ({
                      ...prev,
                      quietHours: { ...prev.quietHours, enabled: checked }
                    }))}
                  />
                </div>
                
                {config.quietHours.enabled && (
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="time"
                      value={config.quietHours.start}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        quietHours: { ...prev.quietHours, start: e.target.value }
                      }))}
                      className="p-2 border rounded"
                    />
                    <input
                      type="time"
                      value={config.quietHours.end}
                      onChange={(e) => setConfig(prev => ({
                        ...prev,
                        quietHours: { ...prev.quietHours, end: e.target.value }
                      }))}
                      className="p-2 border rounded"
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 