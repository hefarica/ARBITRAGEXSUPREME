import React, { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { useKV } from '@/hooks/useKV'
import { 
  NotificationConfig, 
  NotificationEvent, 
  NotificationHistory, 
  NotificationPreference,
  ArbitrageOpportunityEvent,
  TradeExecutedEvent,
  SecurityAlertEvent,
  PriceAlertEvent
} from './types'
import { NotificationService } from '../../services/NotificationService'
import { WebSocketService } from '../../services/WebSocketService'

interface NotificationContextType {
  // Configuración
  config: NotificationConfig | null
  updateConfig: (config: Partial<NotificationConfig>) => Promise<void>
  
  // Preferencias de usuario
  preferences: NotificationPreference | null
  updatePreferences: (prefs: Partial<NotificationPreference>) => Promise<void>
  
  // Historial
  history: NotificationHistory[]
  clearHistory: () => Promise<void>
  
  // Estado en tiempo real
  isConnected: boolean
  lastNotification: NotificationHistory | null
  
  // Métodos para enviar notificaciones
  sendNotification: (event: NotificationEvent, data: any) => Promise<void>
  sendTestNotification: (channelId: string, message: string) => Promise<void>
  
  // Eventos específicos del sistema
  notifyArbitrageOpportunity: (opportunity: ArbitrageOpportunityEvent['opportunity']) => Promise<void>
  notifyTradeExecuted: (trade: TradeExecutedEvent['trade']) => Promise<void>
  notifySecurityAlert: (alert: SecurityAlertEvent['alert']) => Promise<void>
  notifyPriceAlert: (alert: PriceAlertEvent['alert']) => Promise<void>
  
  // Estado del servicio
  serviceStatus: 'connected' | 'disconnected' | 'error' | 'reconnecting'
  error: string | null
}

const NotificationContext = createContext<NotificationContextType | null>(null)

export function useNotifications() {
  const context = useContext(NotificationContext)
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider')
  }
  return context
}

interface Props {
  children: React.ReactNode
}

export function RealTimeNotificationProvider({ children }: Props) {
  // Estado persistente
  const [config, setConfig] = useKV<NotificationConfig | null>('notification-config', null)
  const [preferences, setPreferences] = useKV<NotificationPreference | null>('notification-preferences', null)
  const [history, setHistory] = useKV<NotificationHistory[]>('notification-history', [])
  
  // Estado temporal
  const [isConnected, setIsConnected] = useState(false)
  const [lastNotification, setLastNotification] = useState<NotificationHistory | null>(null)
  const [serviceStatus, setServiceStatus] = useState<'connected' | 'disconnected' | 'error' | 'reconnecting'>('disconnected')
  const [error, setError] = useState<string | null>(null)
  
  // Servicios
  const [notificationService] = useState(() => new NotificationService())
  const [websocketService] = useState(() => new WebSocketService())

  // Inicializar servicios
  useEffect(() => {
    const initializeServices = async () => {
      try {
        setServiceStatus('reconnecting')
        
        // Configurar servicio de notificaciones
        if (config) {
          await notificationService.initialize(config)
        }
        
        // Conectar WebSocket para eventos en tiempo real
        await websocketService.connect()
        
        // Listeners para eventos del WebSocket
        websocketService.on('arbitrage_opportunity', handleArbitrageOpportunity)
        websocketService.on('trade_executed', handleTradeExecuted)
        websocketService.on('security_alert', handleSecurityAlert)
        websocketService.on('price_alert', handlePriceAlert)
        websocketService.on('connection_status', handleConnectionStatus)
        
        setServiceStatus('connected')
        setIsConnected(true)
        setError(null)
        
      } catch (error) {
        console.error('Error initializing notification services:', error)
        setServiceStatus('error')
        setError(error instanceof Error ? error.message : 'Unknown error')
        setIsConnected(false)
      }
    }

    initializeServices()

    return () => {
      websocketService.disconnect()
      notificationService.cleanup()
    }
  }, [config])

  // Handlers para eventos en tiempo real
  const handleArbitrageOpportunity = useCallback(async (data: ArbitrageOpportunityEvent['opportunity']) => {
    if (!preferences?.globalEnabled || !preferences?.events['arbitrage_opportunity']) return
    
    await notifyArbitrageOpportunity(data)
  }, [preferences])

  const handleTradeExecuted = useCallback(async (data: TradeExecutedEvent['trade']) => {
    if (!preferences?.globalEnabled || !preferences?.events['trade_executed']) return
    
    await notifyTradeExecuted(data)
  }, [preferences])

  const handleSecurityAlert = useCallback(async (data: SecurityAlertEvent['alert']) => {
    if (!preferences?.globalEnabled || !preferences?.events['security_alert']) return
    
    await notifySecurityAlert(data)
  }, [preferences])

  const handlePriceAlert = useCallback(async (data: PriceAlertEvent['alert']) => {
    if (!preferences?.globalEnabled || !preferences?.events['price_alert']) return
    
    await notifyPriceAlert(data)
  }, [preferences])

  const handleConnectionStatus = useCallback((status: boolean) => {
    setIsConnected(status)
    setServiceStatus(status ? 'connected' : 'disconnected')
  }, [])

  // Actualizar configuración
  const updateConfig = useCallback(async (newConfig: Partial<NotificationConfig>) => {
    try {
      const updatedConfig = config ? 
        { ...config, ...newConfig, updatedAt: new Date() } :
        {
          id: crypto.randomUUID(),
          enabled: true,
          channels: [],
          events: [],
          filters: [],
          rateLimiting: {
            enabled: true,
            maxPerMinute: 10,
            maxPerHour: 100,
            maxPerDay: 1000,
            burstLimit: 5,
            backoffStrategy: 'exponential' as const,
            retryAfter: 60
          },
          format: {
            style: 'detailed' as const,
            includeTimestamp: true,
            includeMetadata: true,
            includeCharts: false,
            language: 'en' as const,
            timezone: 'UTC'
          },
          createdAt: new Date(),
          updatedAt: new Date(),
          ...newConfig
        }
      
      setConfig(updatedConfig)
      await notificationService.updateConfig(updatedConfig)
      
    } catch (error) {
      console.error('Error updating notification config:', error)
      setError(error instanceof Error ? error.message : 'Error updating config')
    }
  }, [config, setConfig])

  // Actualizar preferencias
  const updatePreferences = useCallback(async (newPrefs: Partial<NotificationPreference>) => {
    try {
      const updatedPrefs = preferences ? 
        { ...preferences, ...newPrefs } :
        {
          userId: 'default',
          globalEnabled: true,
          channels: {},
          events: {},
          quietHours: {
            enabled: false,
            start: '22:00',
            end: '08:00',
            timezone: 'UTC',
            days: [],
            exceptions: []
          },
          frequency: {
            immediate: ['security_alert', 'system_error'],
            batched: {
              enabled: false,
              events: [],
              interval: 15,
              maxEvents: 10
            },
            digest: {
              enabled: false,
              frequency: 'daily' as const,
              time: '09:00',
              events: [],
              format: 'summary' as const
            }
          },
          grouping: {
            enabled: true,
            strategy: 'by_event' as const,
            maxItems: 5,
            timeWindow: 5
          },
          customGear: {},
          ...newPrefs
        }
      
      setPreferences(updatedPrefs)
      
    } catch (error) {
      console.error('Error updating notification preferences:', error)
      setError(error instanceof Error ? error.message : 'Error updating preferences')
    }
  }, [preferences, setPreferences])

  // Limpiar historial
  const clearHistory = useCallback(async () => {
    setHistory([])
  }, [setHistory])

  // Enviar notificación genérica
  const sendNotification = useCallback(async (event: NotificationEvent, data: any) => {
    try {
      if (!config || !preferences?.globalEnabled) return

      const notificationHistory = await notificationService.sendNotification(event, data)
      
      setHistory(prev => [notificationHistory, ...prev.slice(0, 999)]) // Mantener últimas 1000
      setLastNotification(notificationHistory)
      
    } catch (error) {
      console.error('Error sending notification:', error)
      setError(error instanceof Error ? error.message : 'Error sending notification')
    }
  }, [config, preferences, setHistory])

  // Enviar notificación de prueba
  const sendTestNotification = useCallback(async (channelId: string, message: string) => {
    try {
      await notificationService.sendTestNotification(channelId, message)
    } catch (error) {
      console.error('Error sending test notification:', error)
      throw error
    }
  }, [])

  // Métodos específicos para eventos del sistema
  const notifyArbitrageOpportunity = useCallback(async (opportunity: ArbitrageOpportunityEvent['opportunity']) => {
    const event: NotificationEvent = {
      type: 'arbitrage_opportunity',
      enabled: true,
      conditions: []
    }
    
    await sendNotification(event, { opportunity })
  }, [sendNotification])

  const notifyTradeExecuted = useCallback(async (trade: TradeExecutedEvent['trade']) => {
    const event: NotificationEvent = {
      type: 'trade_executed',
      enabled: true,
      conditions: []
    }
    
    await sendNotification(event, { trade })
  }, [sendNotification])

  const notifySecurityAlert = useCallback(async (alert: SecurityAlertEvent['alert']) => {
    const event: NotificationEvent = {
      type: 'security_alert',
      enabled: true,
      conditions: []
    }
    
    await sendNotification(event, { alert })
  }, [sendNotification])

  const notifyPriceAlert = useCallback(async (alert: PriceAlertEvent['alert']) => {
    const event: NotificationEvent = {
      type: 'price_alert',
      enabled: true,
      conditions: []
    }
    
    await sendNotification(event, { alert })
  }, [sendNotification])

  const contextValue: NotificationContextType = {
    config,
    updateConfig,
    preferences,
    updatePreferences,
    history,
    clearHistory,
    isConnected,
    lastNotification,
    sendNotification,
    sendTestNotification,
    notifyArbitrageOpportunity,
    notifyTradeExecuted,
    notifySecurityAlert,
    notifyPriceAlert,
    serviceStatus,
    error
  }

  return (
    <NotificationContext.Provider value={contextValue}>
      {children}
    </NotificationContext.Provider>
  )
}