/**
 * Tipos TypeScript para el sistema de notificaciones en tiempo real
 * Soporte para Telegram, Discord y futuras integraciones
 */

export interface NotificationConfig {
  id: string
  enabled: boolean
  channels: NotificationChannel[]
  events: NotificationEvent[]
  filters: NotificationFunnel[]
  rateLimiting: RateLimitConfig
  format: NotificationFormat
  createdAt: Date
  updatedAt: Date
}

export interface NotificationChannel {
  type: 'telegram' | 'discord' | 'email' | 'webhook' | 'sms'
  id: string
  name: string
  enabled: boolean
  config: TelegramConfig | DiscordConfig | EmailConfig | WebhookConfig | SMSConfig
  priority: 'low' | 'medium' | 'high' | 'critical'
  failover?: NotificationChannel[]
}

export interface TelegramConfig {
  botToken: string
  chatId: string
  parseMode?: 'HTML' | 'Markdown' | 'MarkdownV2'
  disableWebPagePreview?: boolean
  disableNotification?: boolean
  replyToMessageId?: number
  customKeyboard?: TelegramKeyboard
  threadId?: number
}

export interface DiscordConfig {
  webhookUrl: string
  username?: string
  avatarUrl?: string
  embeds?: boolean
  tts?: boolean
  allowedMentions?: {
    users?: string[]
    roles?: string[]
    everyone?: boolean
  }
  threadId?: string
}

export interface EmailConfig {
  smtpHost: string
  smtpPort: number
  username: string
  password: string
  from: string
  to: string[]
  cc?: string[]
  bcc?: string[]
  secure: boolean
  template?: string
}

export interface WebhookConfig {
  url: string
  method: 'POST' | 'PUT' | 'PATCH'
  headers: Record<string, string>
  authentication?: {
    type: 'bearer' | 'basic' | 'api-key'
    token: string
    key?: string
  }
  retries: number
  timeout: number
}

export interface SMSConfig {
  provider: 'twilio' | 'aws-sns' | 'vonage'
  accountSid?: string
  authToken?: string
  fromNumber: string
  toNumber: string
  region?: string
}

export interface TelegramKeyboard {
  inline_keyboard: TelegramButton[][]
}

export interface TelegramButton {
  text: string
  callback_data?: string
  url?: string
  switch_inline_query?: string
}

export interface NotificationEvent {
  type: 'arbitrage_opportunity' | 'trade_executed' | 'profit_target' | 'loss_limit' | 'system_error' | 'security_alert' | 'price_alert' | 'volume_spike' | 'gas_price' | 'mev_detected' | 'strategy_completed' | 'balance_low' | 'api_failure' | 'connection_lost'
  enabled: boolean
  conditions: EventCondition[]
  throttle?: ThrottleConfig
  template?: NotificationTemplate
}

export interface EventCondition {
  field: string
  operator: 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'greater_equal' | 'less_equal' | 'contains' | 'not_contains' | 'in' | 'not_in'
  value: any
  type: 'number' | 'string' | 'boolean' | 'array' | 'object'
}

export interface ThrottleConfig {
  enabled: boolean
  maxEvents: number
  timeWindow: number // seconds
  resetOnSuccess?: boolean
}

export interface NotificationFunnel {
  id: string
  name: string
  conditions: EventCondition[]
  action: 'allow' | 'deny' | 'modify'
  priority: number
  enabled: boolean
}

export interface RateLimitConfig {
  enabled: boolean
  maxPerMinute: number
  maxPerHour: number
  maxPerDay: number
  burstLimit: number
  backoffStrategy: 'linear' | 'exponential' | 'fixed'
  retryAfter: number
}

export interface NotificationFormat {
  style: 'minimal' | 'detailed' | 'rich' | 'custom'
  includeTimestamp: boolean
  includeMetadata: boolean
  includeCharts: boolean
  customTemplate?: string
  language: 'en' | 'es' | 'fr' | 'de' | 'pt' | 'zh'
  timezone: string
}

export interface NotificationTemplate {
  id: string
  name: string
  eventType: string
  channels: string[]
  subject?: string
  body: string
  richContent?: RichContent
  variables: TemplateVariable[]
  conditions?: EventCondition[]
}

export interface RichContent {
  embeds?: DiscordEmbed[]
  attachments?: Attachment[]
  charts?: ChartConfig[]
  buttons?: ActionButton[]
}

export interface DiscordEmbed {
  title?: string
  description?: string
  url?: string
  timestamp?: string
  color?: number
  footer?: {
    text: string
    icon_url?: string
  }
  thumbnail?: {
    url: string
  }
  image?: {
    url: string
  }
  author?: {
    name: string
    url?: string
    icon_url?: string
  }
  fields?: {
    name: string
    value: string
    inline?: boolean
  }[]
}

export interface Attachment {
  type: 'image' | 'document' | 'chart' | 'report'
  url: string
  filename: string
  description?: string
}

export interface ChartConfig {
  type: 'line' | 'bar' | 'pie' | 'candlestick' | 'heatmap'
  data: any[]
  options: any
  width: number
  height: number
  format: 'png' | 'svg' | 'pdf'
}

export interface ActionButton {
  label: string
  action: 'execute_strategy' | 'stop_strategy' | 'view_details' | 'acknowledge' | 'custom'
  style: 'primary' | 'secondary' | 'success' | 'danger'
  url?: string
  callback?: string
}

export interface TemplateVariable {
  name: string
  type: 'string' | 'number' | 'boolean' | 'date' | 'currency' | 'percentage'
  defaultValue?: any
  format?: string
  required: boolean
}

export interface NotificationPreference {
  userId: string
  globalEnabled: boolean
  channels: Record<string, boolean>
  events: Record<string, boolean>
  quietHours: QuietHours
  frequency: NotificationFrequency
  grouping: NotificationGrouping
  customGear: Record<string, any>
}

export interface QuietHours {
  enabled: boolean
  start: string // HH:mm format
  end: string
  timezone: string
  days: number[] // 0 = Sunday, 1 = Monday, etc.
  exceptions: string[] // ISO date strings
}

export interface NotificationFrequency {
  immediate: string[]
  batched: BatchConfig
  digest: DigestConfig
}

export interface BatchConfig {
  enabled: boolean
  events: string[]
  interval: number // minutes
  maxEvents: number
}

export interface DigestConfig {
  enabled: boolean
  frequency: 'hourly' | 'daily' | 'weekly'
  time: string // HH:mm format
  day?: number // For weekly digest
  events: string[]
  format: 'summary' | 'detailed'
}

export interface NotificationGrouping {
  enabled: boolean
  strategy: 'by_event' | 'by_strategy' | 'by_blockchain' | 'by_time'
  maxItems: number
  timeWindow: number // minutes
}

export interface NotificationHistory {
  id: string
  eventType: string
  channel: string
  status: 'pending' | 'sent' | 'failed' | 'retrying' | 'cancelled'
  message: string
  metadata: Record<string, any>
  sentAt?: Date
  deliveredAt?: Date
  failureReason?: string
  retryCount: number
  createdAt: Date
}

export interface NotificationMetrics {
  totalSent: number
  successRate: number
  averageDeliveryTime: number
  failuresByChannel: Record<string, number>
  failuresByEvent: Record<string, number>
  rateLimitHits: number
  costEstimate: number
  period: {
    start: Date
    end: Date
  }
}

export interface NotificationAlert {
  id: string
  type: 'rate_limit' | 'delivery_failure' | 'quota_exceeded' | 'config_error' | 'service_down'
  severity: 'low' | 'medium' | 'high' | 'critical'
  message: string
  details: Record<string, any>
  resolved: boolean
  createdAt: Date
  resolvedAt?: Date
  actions?: AlertAction[]
}

export interface AlertAction {
  label: string
  action: string
  parameters?: Record<string, any>
}

// Eventos específicos del sistema de arbitraje
export interface ArbitrageOpportunityEvent {
  type: 'arbitrage_opportunity'
  opportunity: {
    id: string
    strategy: string
    tokenPair: string
    exchange1: string
    exchange2: string
    profit: number
    profitPercentage: number
    volume: number
    estimatedGas: number
    confidence: number
    expiresAt: Date
    blockchain: string
    riskLevel: 'low' | 'medium' | 'high'
  }
  metadata: {
    detectedAt: Date
    source: string
    version: string
  }
}

export interface TradeExecutedEvent {
  type: 'trade_executed'
  trade: {
    id: string
    strategy: string
    tokenPair: string
    exchange: string
    amount: number
    price: number
    profit: number
    gas: number
    status: 'success' | 'failed' | 'pending'
    blockchain: string
    hash?: string
    blockNumber?: number
  }
  metadata: {
    executedAt: Date
    executionTime: number
    slippage: number
  }
}

export interface SecurityAlertEvent {
  type: 'security_alert'
  alert: {
    id: string
    severity: 'low' | 'medium' | 'high' | 'critical'
    category: 'unauthorized_access' | 'suspicious_transaction' | 'api_abuse' | 'wallet_compromise' | 'mev_attack'
    description: string
    affectedAssets: string[]
    recommendations: string[]
    autoActions: string[]
  }
  metadata: {
    detectedAt: Date
    source: string
    confidence: number
  }
}

export interface PriceAlertEvent {
  type: 'price_alert'
  alert: {
    token: string
    exchange: string
    price: number
    change24h: number
    changePercentage: number
    volume24h: number
    marketCap?: number
    blockchain: string
    trigger: 'above' | 'below' | 'change_percent'
    triggerValue: number
  }
  metadata: {
    triggeredAt: Date
    previousPrice: number
    priceSource: string
  }
}

// Utility types
export type NotificationEventType = NotificationEvent['type']
export type NotificationChannelType = NotificationChannel['type']
export type NotificationStatus = NotificationHistory['status']
export type EventType = ArbitrageOpportunityEvent | TradeExecutedEvent | SecurityAlertEvent | PriceAlertEvent