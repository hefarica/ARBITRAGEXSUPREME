import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Label } from '../ui/label'
import { Switch } from '../ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Slider } from '../ui/slider'
import { Badge } from '../ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { Separator } from '../ui/separator'
import { useNotifications } from './RealTimeNotificationProvider'
import { NotificationPreference, NotificationEventType } from './types'
import { 
  Bell, 
  Clock, 
  SpeakerHigh2, 
  SpeakerHighX, 
  Gear, 
  Moon,
  Sun,
  CalendarBlank,
  Funnel,
  Lightning,
  Package,
  ChartBar3
} from 'lucide-react'
import { useToast } from '../../hooks/use-toast'

// Tipos de eventos disponibles con sus descripciones
const EVENT_TYPES: Record<NotificationEventType, { label: string; description: string; icon: React.ReactNode; defaultEnabled: boolean }> = {
  arbitrage_opportunity: {
    label: 'Oportunidades de Arbitraje',
    description: 'Nuevas oportunidades de arbitraje detectadas',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  },
  trade_executed: {
    label: 'Trades Ejecutados',
    description: 'Confirmación de trades completados',
    icon: <BarChart3 className="h-4 w-4" />,
    defaultEnabled: true
  },
  profit_target: {
    label: 'Objetivo de Ganancia',
    description: 'Cuando se alcanza un objetivo de ganancia',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  },
  loss_limit: {
    label: 'Límite de Pérdida',
    description: 'Alertas de límites de pérdida alcanzados',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  },
  system_error: {
    label: 'Errores del Sistema',
    description: 'Errores críticos del sistema',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  },
  security_alert: {
    label: 'Alertas de Seguridad',
    description: 'Alertas relacionadas con seguridad',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  },
  price_alert: {
    label: 'Alertas de Precio',
    description: 'Cambios significativos de precio',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: false
  },
  volume_spike: {
    label: 'Picos de SpeakerHighn',
    description: 'Incrementos súbitos en volumen de trading',
    icon: <BarChart3 className="h-4 w-4" />,
    defaultEnabled: false
  },
  gas_price: {
    label: 'Precio del Gas',
    description: 'Cambios en el precio del gas',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: false
  },
  mev_detected: {
    label: 'MEV Detectado',
    description: 'Detección de ataques MEV',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  },
  strategy_completed: {
    label: 'Estrategia Completada',
    description: 'Finalización de estrategias de trading',
    icon: <Package className="h-4 w-4" />,
    defaultEnabled: true
  },
  balance_low: {
    label: 'Balance Bajo',
    description: 'Alertas de balance insuficiente',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  },
  api_failure: {
    label: 'Fallo de API',
    description: 'Errores en APIs externas',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  },
  connection_lost: {
    label: 'Conexión Perdida',
    description: 'Pérdida de conexión con servicios',
    icon: <Lightning className="h-4 w-4" />,
    defaultEnabled: true
  }
}

const CHANNELS = {
  telegram: { label: 'Telegram', icon: '📱' },
  discord: { label: 'Discord', icon: '💜' },
  email: { label: 'Email', icon: '📧' },
  webhook: { label: 'Webhook', icon: '🔗' },
  sms: { label: 'SMS', icon: '📱' }
}

export function NotificationPreferences() {
  const { preferences, updatePreferences } = useNotifications()
  const { toast } = useToast()
  
  const [localPreferences, setLocalPreferences] = useState<NotificationPreference>({
    userId: 'default',
    globalEnabled: true,
    channels: {},
    events: {},
    quietHours: {
      enabled: false,
      start: '22:00',
      end: '08:00',
      timezone: 'UTC',
      days: [],
      exceptions: []
    },
    frequency: {
      immediate: ['security_alert', 'system_error'],
      batched: {
        enabled: false,
        events: [],
        interval: 15,
        maxEvents: 10
      },
      digest: {
        enabled: false,
        frequency: 'daily',
        time: '09:00',
        events: [],
        format: 'summary'
      }
    },
    grouping: {
      enabled: true,
      strategy: 'by_event',
      maxItems: 5,
      timeWindow: 5
    },
    customGear: {}
  })

  // Cargar preferencias existentes
  useEffect(() => {
    if (preferences) {
      setLocalPreferences(preferences)
    }
  }, [preferences])

  // Manejar cambios en las preferencias
  const handlePreferenceChange = (key: keyof NotificationPreference, value: any) => {
    const updatedPrefs = { ...localPreferences, [key]: value }
    setLocalPreferences(updatedPrefs)
  }

  // Manejar cambios en eventos
  const handleEventToggle = (eventType: NotificationEventType, enabled: boolean) => {
    const updatedEvents = { ...localPreferences.events, [eventType]: enabled }
    setLocalPreferences(prev => ({ ...prev, events: updatedEvents }))
  }

  // Manejar cambios en canales
  const handleChannelToggle = (channel: string, enabled: boolean) => {
    const updatedChannels = { ...localPreferences.channels, [channel]: enabled }
    setLocalPreferences(prev => ({ ...prev, channels: updatedChannels }))
  }

  // Guardar preferencias
  const savePreferences = async () => {
    try {
      await updatePreferences(localPreferences)
      toast({
        title: "✅ Preferencias guardadas",
        description: "Las preferencias de notificaciones han sido actualizadas",
        variant: "default"
      })
    } catch (error) {
      toast({
        title: "❌ Error al guardar",
        description: error instanceof Error ? error.message : 'Error al guardar las preferencias',
        variant: "destructive"
      })
    }
  }

  // Resetear a valores por defecto
  const resetToDefaults = () => {
    const defaultPrefs: NotificationPreference = {
      userId: 'default',
      globalEnabled: true,
      channels: {
        telegram: true,
        discord: true,
        email: false,
        webhook: false,
        sms: false
      },
      events: Object.fromEntries(
        Object.entries(EVENT_TYPES).map(([key, value]) => [key, value.defaultEnabled])
      ),
      quietHours: {
        enabled: false,
        start: '22:00',
        end: '08:00',
        timezone: 'UTC',
        days: [],
        exceptions: []
      },
      frequency: {
        immediate: ['security_alert', 'system_error', 'loss_limit'],
        batched: {
          enabled: true,
          events: ['price_alert', 'volume_spike'],
          interval: 15,
          maxEvents: 10
        },
        digest: {
          enabled: true,
          frequency: 'daily',
          time: '09:00',
          events: ['trade_executed', 'profit_target'],
          format: 'summary'
        }
      },
      grouping: {
        enabled: true,
        strategy: 'by_event',
        maxItems: 5,
        timeWindow: 5
      },
      customGear: {}
    }
    
    setLocalPreferences(defaultPrefs)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Gear className="h-5 w-5" />
              Preferencias de Notificaciones
              <Badge variant={localPreferences.globalEnabled ? "default" : "secondary"}>
                {localPreferences.globalEnabled ? "Activo" : "Inactivo"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Personaliza cuándo y cómo recibir notificaciones
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={resetToDefaults}>
              Restaurar por defecto
            </Button>
            <Button onClick={savePreferences}>
              Guardar cambios
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Toggle global */}
        <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="flex items-center gap-3">
            <Bell className="h-5 w-5" />
            <div>
              <Label htmlFor="global-enabled" className="text-base font-medium">
                Notificaciones globales
              </Label>
              <p className="text-sm text-muted-foreground">
                Activar/desactivar todas las notificaciones
              </p>
            </div>
          </div>
          <Switch
            id="global-enabled"
            checked={localPreferences.globalEnabled}
            onCheckedChange={(checked) => handlePreferenceChange('globalEnabled', checked)}
          />
        </div>

        <Tabs defaultValue="events" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="events">Eventos</TabsTrigger>
            <TabsTrigger value="channels">Canales</TabsTrigger>
            <TabsTrigger value="timing">Horarios</TabsTrigger>
            <TabsTrigger value="advanced">Avanzado</TabsTrigger>
          </TabsList>

          <TabsContent value="events" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Tipos de eventos</h3>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const allEnabled = Object.fromEntries(
                        Object.keys(EVENT_TYPES).map(key => [key, true])
                      )
                      setLocalPreferences(prev => ({ ...prev, events: allEnabled }))
                    }}
                  >
                    Activar todos
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const allDisabled = Object.fromEntries(
                        Object.keys(EVENT_TYPES).map(key => [key, false])
                      )
                      setLocalPreferences(prev => ({ ...prev, events: allDisabled }))
                    }}
                  >
                    Desactivar todos
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(EVENT_TYPES).map(([eventType, config]) => (
                  <div
                    key={eventType}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      {config.icon}
                      <div>
                        <Label className="font-medium">{config.label}</Label>
                        <p className="text-sm text-muted-foreground">{config.description}</p>
                      </div>
                    </div>
                    <Switch
                      checked={localPreferences.events[eventType as NotificationEventType] || false}
                      onCheckedChange={(checked) => 
                        handleEventToggle(eventType as NotificationEventType, checked)
                      }
                    />
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="channels" className="space-y-4">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Canales de notificación</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(CHANNELS).map(([channel, config]) => (
                  <div
                    key={channel}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{config.icon}</span>
                      <div>
                        <Label className="font-medium">{config.label}</Label>
                        <p className="text-sm text-muted-foreground">
                          Enviar notificaciones vía {config.label}
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={localPreferences.channels[channel] || false}
                      onCheckedChange={(checked) => handleChannelToggle(channel, checked)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="timing" className="space-y-4">
            <div className="space-y-6">
              {/* Horarios silenciosos */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Moon className="h-5 w-5" />
                    <h3 className="text-lg font-medium">Horarios silenciosos</h3>
                  </div>
                  <Switch
                    checked={localPreferences.quietHours.enabled}
                    onCheckedChange={(checked) =>
                      setLocalPreferences(prev => ({
                        ...prev,
                        quietHours: { ...prev.quietHours, enabled: checked }
                      }))
                    }
                  />
                </div>

                {localPreferences.quietHours.enabled && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
                    <div>
                      <Label htmlFor="quiet-start">Hora de inicio</Label>
                      <Select
                        value={localPreferences.quietHours.start}
                        onValueChange={(value) =>
                          setLocalPreferences(prev => ({
                            ...prev,
                            quietHours: { ...prev.quietHours, start: value }
                          }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 24 }, (_, i) => {
                            const hour = i.toString().padStart(2, '0')
                            return (
                              <SelectItem key={hour} value={`${hour}:00`}>
                                {hour}:00
                              </SelectItem>
                            )
                          })}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="quiet-end">Hora de fin</Label>
                      <Select
                        value={localPreferences.quietHours.end}
                        onValueChange={(value) =>
                          setLocalPreferences(prev => ({
                            ...prev,
                            quietHours: { ...prev.quietHours, end: value }
                          }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 24 }, (_, i) => {
                            const hour = i.toString().padStart(2, '0')
                            return (
                              <SelectItem key={hour} value={`${hour}:00`}>
                                {hour}:00
                              </SelectItem>
                            )
                          })}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Zona horaria</Label>
                      <Select
                        value={localPreferences.quietHours.timezone}
                        onValueChange={(value) =>
                          setLocalPreferences(prev => ({
                            ...prev,
                            quietHours: { ...prev.quietHours, timezone: value }
                          }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="UTC">UTC</SelectItem>
                          <SelectItem value="America/New_York">Nueva York</SelectItem>
                          <SelectItem value="America/Los_Angeles">Los Ángeles</SelectItem>
                          <SelectItem value="Europe/London">Londres</SelectItem>
                          <SelectItem value="Europe/Madrid">Madrid</SelectItem>
                          <SelectItem value="Asia/Tokyo">Tokio</SelectItem>
                          <SelectItem value="America/Bogota">Bogotá</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              {/* Frecuencia de notificaciones */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Frecuencia de notificaciones
                </h3>

                {/* Notificaciones en lote */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Agrupar notificaciones en lotes</Label>
                    <Switch
                      checked={localPreferences.frequency.batched.enabled}
                      onCheckedChange={(checked) =>
                        setLocalPreferences(prev => ({
                          ...prev,
                          frequency: {
                            ...prev.frequency,
                            batched: { ...prev.frequency.batched, enabled: checked }
                          }
                        }))
                      }
                    />
                  </div>

                  {localPreferences.frequency.batched.enabled && (
                    <div className="space-y-3 p-3 bg-muted rounded-lg">
                      <div>
                        <Label>Intervalo de lote (minutos)</Label>
                        <Slider
                          value={[localPreferences.frequency.batched.interval]}
                          onValueChange={([value]) =>
                            setLocalPreferences(prev => ({
                              ...prev,
                              frequency: {
                                ...prev.frequency,
                                batched: { ...prev.frequency.batched, interval: value }
                              }
                            }))
                          }
                          min={5}
                          max={60}
                          step={5}
                          className="mt-2"
                        />
                        <div className="text-sm text-muted-foreground mt-1">
                          {localPreferences.frequency.batched.interval} minutos
                        </div>
                      </div>

                      <div>
                        <Label>Máximo de eventos por lote</Label>
                        <Slider
                          value={[localPreferences.frequency.batched.maxEvents]}
                          onValueChange={([value]) =>
                            setLocalPreferences(prev => ({
                              ...prev,
                              frequency: {
                                ...prev.frequency,
                                batched: { ...prev.frequency.batched, maxEvents: value }
                              }
                            }))
                          }
                          min={5}
                          max={50}
                          step={5}
                          className="mt-2"
                        />
                        <div className="text-sm text-muted-foreground mt-1">
                          {localPreferences.frequency.batched.maxEvents} eventos
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Resumen diario */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Resumen diario</Label>
                    <Switch
                      checked={localPreferences.frequency.digest.enabled}
                      onCheckedChange={(checked) =>
                        setLocalPreferences(prev => ({
                          ...prev,
                          frequency: {
                            ...prev.frequency,
                            digest: { ...prev.frequency.digest, enabled: checked }
                          }
                        }))
                      }
                    />
                  </div>

                  {localPreferences.frequency.digest.enabled && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-3 bg-muted rounded-lg">
                      <div>
                        <Label>Frecuencia</Label>
                        <Select
                          value={localPreferences.frequency.digest.frequency}
                          onValueChange={(value: 'hourly' | 'daily' | 'weekly') =>
                            setLocalPreferences(prev => ({
                              ...prev,
                              frequency: {
                                ...prev.frequency,
                                digest: { ...prev.frequency.digest, frequency: value }
                              }
                            }))
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="hourly">Cada hora</SelectItem>
                            <SelectItem value="daily">Diario</SelectItem>
                            <SelectItem value="weekly">Semanal</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label>Hora de envío</Label>
                        <Select
                          value={localPreferences.frequency.digest.time}
                          onValueChange={(value) =>
                            setLocalPreferences(prev => ({
                              ...prev,
                              frequency: {
                                ...prev.frequency,
                                digest: { ...prev.frequency.digest, time: value }
                              }
                            }))
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {Array.from({ length: 24 }, (_, i) => {
                              const hour = i.toString().padStart(2, '0')
                              return (
                                <SelectItem key={hour} value={`${hour}:00`}>
                                  {hour}:00
                                </SelectItem>
                              )
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <div className="space-y-6">
              {/* Agrupación de notificaciones */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    <h3 className="text-lg font-medium">Agrupación inteligente</h3>
                  </div>
                  <Switch
                    checked={localPreferences.grouping.enabled}
                    onCheckedChange={(checked) =>
                      setLocalPreferences(prev => ({
                        ...prev,
                        grouping: { ...prev.grouping, enabled: checked }
                      }))
                    }
                  />
                </div>

                {localPreferences.grouping.enabled && (
                  <div className="space-y-4 p-4 bg-muted rounded-lg">
                    <div>
                      <Label>Estrategia de agrupación</Label>
                      <Select
                        value={localPreferences.grouping.strategy}
                        onValueChange={(value: 'by_event' | 'by_strategy' | 'by_blockchain' | 'by_time') =>
                          setLocalPreferences(prev => ({
                            ...prev,
                            grouping: { ...prev.grouping, strategy: value }
                          }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="by_event">Por tipo de evento</SelectItem>
                          <SelectItem value="by_strategy">Por estrategia</SelectItem>
                          <SelectItem value="by_blockchain">Por blockchain</SelectItem>
                          <SelectItem value="by_time">Por tiempo</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Máximo de elementos agrupados</Label>
                      <Slider
                        value={[localPreferences.grouping.maxItems]}
                        onValueChange={([value]) =>
                          setLocalPreferences(prev => ({
                            ...prev,
                            grouping: { ...prev.grouping, maxItems: value }
                          }))
                        }
                        min={3}
                        max={20}
                        step={1}
                        className="mt-2"
                      />
                      <div className="text-sm text-muted-foreground mt-1">
                        {localPreferences.grouping.maxItems} elementos
                      </div>
                    </div>

                    <div>
                      <Label>Ventana de tiempo (minutos)</Label>
                      <Slider
                        value={[localPreferences.grouping.timeWindow]}
                        onValueChange={([value]) =>
                          setLocalPreferences(prev => ({
                            ...prev,
                            grouping: { ...prev.grouping, timeWindow: value }
                          }))
                        }
                        min={1}
                        max={30}
                        step={1}
                        className="mt-2"
                      />
                      <div className="text-sm text-muted-foreground mt-1">
                        {localPreferences.grouping.timeWindow} minutos
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <Separator />

        {/* Botones de acción */}
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={resetToDefaults}>
            Restaurar por defecto
          </Button>
          <Button onClick={savePreferences}>
            Guardar cambios
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}