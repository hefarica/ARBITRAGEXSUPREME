/**
 * Command Palette para ArbitrageX Pro 2025
 * Navegación rápida y ejecución de acciones con Cmd/Ctrl+K
 */

import React, { useState, useEffect, useRef } from 'react';

interface Command {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'navigation' | 'system' | 'trading' | 'analysis' | 'settings';
  shortcut?: string;
  action: () => void;
}

export const CommandPalette: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [filteredCommands, setFilteredCommands] = useState<Command[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Comandos disponibles del sistema
  const allCommands: Command[] = [
    // Navegación
    {
      id: 'monitoring',
      name: 'Ir a Seguimiento',
      description: 'Abrir dashboard de monitoreo en tiempo real',
      icon: '📊',
      category: 'navigation',
      shortcut: 'Ctrl+1',
      action: () => console.log('Navegar a Seguimiento')
    },
    {
      id: 'configuration',
      name: 'Ir a Configuración',
      description: 'Abrir dashboard de configuración del sistema',
      icon: '⚙️',
      category: 'navigation',
      shortcut: 'Ctrl+2',
      action: () => console.log('Navegar a Configuración')
    },
    {
      id: 'execution',
      name: 'Ir a Ejecución',
      description: 'Abrir dashboard de control de estrategias',
      icon: '⚡',
      category: 'navigation',
      shortcut: 'Ctrl+3',
      action: () => console.log('Navegar a Ejecución')
    },
    {
      id: 'transactions',
      name: 'Ir a Transacciones',
      description: 'Abrir dashboard de gestión de operaciones',
      icon: '💱',
      category: 'navigation',
      shortcut: 'Ctrl+4',
      action: () => console.log('Navegar a Transacciones')
    },
    {
      id: 'history',
      name: 'Ir a Historiales',
      description: 'Abrir dashboard de análisis y reportes',
      icon: '📈',
      category: 'navigation',
      shortcut: 'Ctrl+5',
      action: () => console.log('Navegar a Historiales')
    },
    {
      id: 'connectivity',
      name: 'Ir a Conectividad',
      description: 'Abrir dashboard de estado de infraestructura',
      icon: '🔌',
      category: 'navigation',
      shortcut: 'Ctrl+6',
      action: () => console.log('Navegar a Conectividad')
    },

    // Sistema
    {
      id: 'start-system',
      name: 'Iniciar Sistema',
      description: 'Activar el motor de arbitraje',
      icon: '▶️',
      category: 'system',
      shortcut: 'Ctrl+Shift+S',
      action: () => console.log('Iniciar Sistema')
    },
    {
      id: 'stop-system',
      name: 'Detener Sistema',
      description: 'Parar el motor de arbitraje',
      icon: '⏹️',
      category: 'system',
      shortcut: 'Ctrl+Shift+X',
      action: () => console.log('Detener Sistema')
    },
    {
      id: 'toggle-autopilot',
      name: 'Alternar Piloto Automático',
      description: 'Activar/desactivar modo automático',
      icon: '🤖',
      category: 'system',
      shortcut: 'Ctrl+Shift+A',
      action: () => console.log('Alternar Piloto Automático')
    },
    {
      id: 'system-status',
      name: 'Estado del Sistema',
      description: 'Ver métricas y salud del sistema',
      icon: '📊',
      category: 'system',
      shortcut: 'Ctrl+Shift+H',
      action: () => console.log('Estado del Sistema')
    },

    // Trading
    {
      id: 'scan-opportunities',
      name: 'Escanear Oportunidades',
      description: 'Buscar nuevas oportunidades de arbitraje',
      icon: '🔍',
      category: 'trading',
      shortcut: 'Ctrl+Shift+O',
      action: () => console.log('Escanear Oportunidades')
    },
    {
      id: 'execute-strategy',
      name: 'Ejecutar Estrategia',
      description: 'Ejecutar estrategia de arbitraje específica',
      icon: '🚀',
      category: 'trading',
      shortcut: 'Ctrl+Shift+E',
      action: () => console.log('Ejecutar Estrategia')
    },
    {
      id: 'view-pools',
      name: 'Ver Pools',
      description: 'Mostrar estado de pools en tiempo real',
      icon: '🏊',
      category: 'trading',
      shortcut: 'Ctrl+Shift+P',
      action: () => console.log('Ver Pools')
    },

    // Análisis
    {
      id: 'performance-report',
      name: 'Reporte de Rendimiento',
      description: 'Generar reporte de performance del sistema',
      icon: '📋',
      category: 'analysis',
      shortcut: 'Ctrl+Shift+R',
      action: () => console.log('Reporte de Rendimiento')
    },
    {
      id: 'risk-analysis',
      name: 'Análisis de Riesgo',
      description: 'Evaluar exposición al riesgo actual',
      icon: '⚠️',
      category: 'analysis',
      shortcut: 'Ctrl+Shift+K',
      action: () => console.log('Análisis de Riesgo')
    },
    {
      id: 'profit-analysis',
      name: 'Análisis de Ganancias',
      description: 'Revisar métricas de rentabilidad',
      icon: '💰',
      category: 'analysis',
      shortcut: 'Ctrl+Shift+G',
      action: () => console.log('Análisis de Ganancias')
    },

    // Configuración
    {
      id: 'settings',
      name: 'Configuración',
      description: 'Abrir panel de configuración avanzada',
      icon: '⚙️',
      category: 'settings',
      shortcut: 'Ctrl+,',
      action: () => console.log('Configuración')
    },
    {
      id: 'api-keys',
      name: 'Gestionar API Keys',
      description: 'Configurar credenciales de servicios',
      icon: '🔑',
      category: 'settings',
      shortcut: 'Ctrl+Shift+K',
      action: () => console.log('Gestionar API Keys')
    },
    {
      id: 'notifications',
      name: 'Configurar Notificaciones',
      description: 'Personalizar alertas del sistema',
      icon: '🔔',
      category: 'settings',
      shortcut: 'Ctrl+Shift+N',
      action: () => console.log('Configurar Notificaciones')
    }
  ];

  // Filtrar comandos basado en la búsqueda
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredCommands(allCommands);
    } else {
      const filtered = allCommands.filter(command =>
        command.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        command.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        command.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredCommands(filtered);
      setSelectedIndex(0);
    }
  }, [searchQuery]);

  // Manejar atajos de teclado
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(true);
        setTimeout(() => inputRef.current?.focus(), 100);
      }

      if (isOpen) {
        switch (e.key) {
          case 'Escape':
            setIsOpen(false);
            setSearchQuery('');
            break;
          case 'ArrowDown':
            e.preventDefault();
            setSelectedIndex(prev => 
              prev < filteredCommands.length - 1 ? prev + 1 : 0
            );
            break;
          case 'ArrowUp':
            e.preventDefault();
            setSelectedIndex(prev => 
              prev > 0 ? prev - 1 : filteredCommands.length - 1
            );
            break;
          case 'Enter':
            e.preventDefault();
            if (filteredCommands[selectedIndex]) {
              filteredCommands[selectedIndex].action();
              setIsOpen(false);
              setSearchQuery('');
            }
            break;
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filteredCommands, selectedIndex]);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'navigation':
        return 'text-blue-400';
      case 'system':
        return 'text-green-400';
      case 'trading':
        return 'text-yellow-400';
      case 'analysis':
        return 'text-purple-400';
      case 'settings':
        return 'text-orange-400';
      default:
        return 'text-gray-400';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'navigation':
        return '🧭';
      case 'system':
        return '⚙️';
      case 'trading':
        return '📈';
      case 'analysis':
        return '📊';
      case 'settings':
        return '🔧';
      default:
        return '📝';
    }
  };

  return (
    <>
      {/* Botón de búsqueda */}
      <button
        onClick={() => setIsOpen(true)}
        className="w-full px-4 py-2 bg-black/20 hover:bg-black/30 border border-blue-500/30 rounded-lg text-left transition-colors group"
      >
        <div className="flex items-center space-x-3">
          <span className="text-blue-300">🔍</span>
          <span className="text-blue-200 group-hover:text-white transition-colors">
            Buscar o preguntar...
          </span>
          <span className="ml-auto text-xs text-blue-400 bg-blue-500/20 px-2 py-1 rounded">
            Ctrl+K
          </span>
        </div>
      </button>

      {/* Modal de Comandos */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-center pt-20">
          <div className="w-full max-w-2xl mx-4">
            <div className="bg-black/90 border border-blue-500/30 rounded-xl shadow-2xl overflow-hidden">
              {/* Header */}
              <div className="p-4 border-b border-blue-500/20">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">🎯</span>
                  <div>
                    <h2 className="text-lg font-semibold text-white">
                      Paleta de Comandos
                    </h2>
                    <p className="text-sm text-blue-300">
                      Navega y controla el sistema rápidamente
                    </p>
                  </div>
                </div>
              </div>

              {/* Barra de búsqueda */}
              <div className="p-4 border-b border-blue-500/20">
                <div className="relative">
                  <input
                    ref={inputRef}
                    type="text"
                    placeholder="Buscar comandos..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full px-4 py-3 bg-black/50 border border-blue-500/30 rounded-lg text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500"
                  />
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-400">
                    ⌘K
                  </span>
                </div>
              </div>

              {/* Lista de comandos */}
              <div className="max-h-96 overflow-y-auto">
                {filteredCommands.length === 0 ? (
                  <div className="p-8 text-center text-blue-300">
                    <span className="text-3xl mb-4 block">🔍</span>
                    <p className="text-lg font-medium mb-2">No se encontraron comandos</p>
                    <p className="text-sm">Intenta con otros términos de búsqueda</p>
                  </div>
                ) : (
                  <div className="p-2">
                    {filteredCommands.map((command, index) => (
                      <button
                        key={command.id}
                        onClick={() => {
                          command.action();
                          setIsOpen(false);
                          setSearchQuery('');
                        }}
                        className={`w-full p-3 rounded-lg text-left transition-all duration-200 group ${
                          index === selectedIndex
                            ? 'bg-blue-500/20 border border-blue-500/50'
                            : 'hover:bg-black/30 border border-transparent'
                        }`}
                      >
                        <div className="flex items-center space-x-3">
                          <span className="text-xl">{command.icon}</span>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <h3 className="font-medium text-white truncate">
                                {command.name}
                              </h3>
                              <span className="text-xs text-blue-400 bg-blue-500/20 px-2 py-1 rounded">
                                {command.shortcut}
                              </span>
                            </div>
                            
                            <p className="text-sm text-blue-300 mb-2 line-clamp-1">
                              {command.description}
                            </p>
                            
                            <div className="flex items-center space-x-2">
                              <span className={`text-xs font-medium ${getCategoryColor(command.category)}`}>
                                {getCategoryIcon(command.category)} {command.category}
                              </span>
                            </div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-blue-500/20 bg-black/20">
                <div className="flex items-center justify-between text-sm text-blue-300">
                  <span>
                    {filteredCommands.length} comando{filteredCommands.length !== 1 ? 's' : ''} disponible{filteredCommands.length !== 1 ? 's' : ''}
                  </span>
                  <div className="flex items-center space-x-4">
                    <span>↑↓ Navegar</span>
                    <span>↵ Ejecutar</span>
                    <span>Esc Cerrar</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
