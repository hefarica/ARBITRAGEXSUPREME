import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Trophy,
  Star,
  Target,
  Brain,
  Shield,
  Zap,
  Play,
  Pause,
  CheckCircle,
  XCircle,
  ArrowRight,
  ArrowLeft,
  GraduationCap,
  BookOpen,
  Lightbulb,
  Rocket,
  Crown,
  Medal,
  Award,
  Certificate,
  User,
  Lock,
  Unlock,
  Eye,
  EyeSlash,
  Wallet,
  Key,
  Database,
  Globe,
  Smartphone,
  Monitor,
  Settings,
  Bell,
  ShieldCheck,
  TrendingUp,
  DollarSign,
  Clock,
  AlertTriangle,
  Info,
  HelpCircle,
  Video,
  FileText,
  Users,
  MessageCircle,
  Headphones
} from '@phosphor-icons/react'
import { cn } from '@/lib/utils'

interface UserLevel {
  id: string
  name: string
  title: string
  description: string
  icon: React.ReactNode
  requirements: string[]
  benefits: string[]
  unlocked: boolean
  progress: number
}

interface TutorialStep {
  id: string
  title: string
  description: string
  action: string
  completed: boolean
  required: boolean
  points: number
}

interface DemoScenario {
  id: string
  name: string
  description: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  duration: number // minutes
  virtualBalance: number
  expectedProfit: number
  risk: 'low' | 'medium' | 'high'
  completed: boolean
  score: number
}

export function GamifiedOnboarding2025() {
  const [currentStep, setCurrentStep] = useState(0)
  const [userLevel, setUserLevel] = useState<UserLevel>({
    id: 'novice',
    name: 'Novato',
    title: 'Iniciador de Arbitraje',
    description: 'Acabas de comenzar tu viaje en el mundo del arbitraje DeFi',
    icon: <User size={24} />,
    requirements: ['Completar tutorial básico', 'Configurar primera wallet'],
    benefits: ['Acceso a estrategias básicas', 'Soporte prioritario'],
    unlocked: true,
    progress: 0
  })
  
  const [totalPoints, setTotalPoints] = useState(0)
  const [tutorialSteps, setTutorialSteps] = useState<TutorialStep[]>([
    {
      id: 'welcome',
      title: '¡Bienvenido a ArbitrageX 2025!',
      description: 'Tu plataforma de arbitraje inteligente con IA',
      action: 'Comenzar',
      completed: false,
      required: true,
      points: 10
    },
    {
      id: 'wallet-setup',
      title: 'Configuración de Wallet',
      description: 'Conecta tu wallet para comenzar a operar',
      action: 'Conectar Wallet',
      completed: false,
      required: true,
      points: 25
    },
    {
      id: 'risk-assessment',
      title: 'Evaluación de Riesgo',
      description: 'Completa el cuestionario para personalizar tu experiencia',
      action: 'Comenzar Evaluación',
      completed: false,
      required: true,
      points: 30
    },
    {
      id: 'demo-mode',
      title: 'Modo Demo',
      description: 'Prueba el sistema con fondos virtuales',
      action: 'Iniciar Demo',
      completed: false,
      required: false,
      points: 50
    },
    {
      id: 'first-trade',
      title: 'Primera Operación',
      description: 'Ejecuta tu primera operación de arbitraje',
      action: 'Ejecutar Operación',
      completed: false,
      required: true,
      points: 100
    },
    {
      id: 'ai-training',
      title: 'Entrenamiento de IA',
      description: 'Ayuda a la IA a aprender tus preferencias',
      action: 'Entrenar IA',
      completed: false,
      required: false,
      points: 75
    }
  ])

  const [demoScenarios, setDemoScenarios] = useState<DemoScenario[]>([
    {
      id: 'basic-arbitrage',
      name: 'Arbitraje Básico',
      description: 'Aprende los fundamentos del arbitraje triangular',
      difficulty: 'beginner',
      duration: 5,
      virtualBalance: 1000,
      expectedProfit: 25,
      risk: 'low',
      completed: false,
      score: 0
    },
    {
      id: 'cross-dex',
      name: 'Arbitraje Cross-DEX',
      description: 'Explora oportunidades entre diferentes exchanges',
      difficulty: 'intermediate',
      duration: 10,
      virtualBalance: 2500,
      expectedProfit: 75,
      risk: 'medium',
      completed: false,
      score: 0
    },
    {
      id: 'flash-loan',
      name: 'Flash Loans Avanzado',
      description: 'Domina las estrategias de flash loans',
      difficulty: 'advanced',
      duration: 15,
      virtualBalance: 5000,
      expectedProfit: 200,
      risk: 'high',
      completed: false,
      score: 0
    }
  ])

  const [walletConnected, setWalletConnected] = useState(false)
  const [riskAssessment, setRiskAssessment] = useState({
    experience: 'beginner',
    riskTolerance: 'conservative',
    investmentAmount: '1000-5000',
    timeHorizon: 'short-term'
  })

  const levels: UserLevel[] = [
    {
      id: 'novice',
      name: 'Novato',
      title: 'Iniciador de Arbitraje',
      description: 'Acabas de comenzar tu viaje en el mundo del arbitraje DeFi',
      icon: <User size={24} />,
      requirements: ['Completar tutorial básico', 'Configurar primera wallet'],
      benefits: ['Acceso a estrategias básicas', 'Soporte prioritario'],
      unlocked: true,
      progress: 0
    },
    {
      id: 'apprentice',
      name: 'Aprendiz',
      title: 'Operador Intermedio',
      description: 'Has completado los fundamentos y estás listo para más',
      icon: <GraduationCap size={24} />,
      requirements: ['Completar 10 operaciones', 'Ganar 100 puntos'],
      benefits: ['Estrategias intermedias', 'Análisis avanzado'],
      unlocked: false,
      progress: 0
    },
    {
      id: 'expert',
      name: 'Experto',
      title: 'Maestro del Arbitraje',
      description: 'Dominas las estrategias y optimizas constantemente',
      icon: <Brain size={24} />,
      requirements: ['Completar 50 operaciones', 'Ganar 500 puntos', 'Mantener 80% win rate'],
      benefits: ['Estrategias avanzadas', 'IA personalizada', 'Soporte VIP'],
      unlocked: false,
      progress: 0
    },
    {
      id: 'master',
      name: 'Maestro',
      title: 'Leyenda del Arbitraje',
      description: 'Eres una leyenda en el mundo del arbitraje DeFi',
      icon: <Crown size={24} />,
      requirements: ['Completar 100 operaciones', 'Ganar 1000 puntos', 'Mantener 90% win rate'],
      benefits: ['Acceso exclusivo', 'Estrategias premium', 'Soporte 24/7'],
      unlocked: false,
      progress: 0
    }
  ]

  const completeStep = (stepId: string) => {
    setTutorialSteps(prev => prev.map(step => 
      step.id === stepId 
        ? { ...step, completed: true }
        : step
    ))
    
    const step = tutorialSteps.find(s => s.id === stepId)
    if (step) {
      setTotalPoints(prev => prev + step.points)
    }
  }

  const completeDemo = (scenarioId: string, score: number) => {
    setDemoScenarios(prev => prev.map(scenario => 
      scenario.id === scenarioId 
        ? { ...scenario, completed: true, score }
        : scenario
    ))
    
    setTotalPoints(prev => prev + score)
  }

  const getLevelProgress = () => {
    const completedSteps = tutorialSteps.filter(step => step.completed).length
    const totalRequired = tutorialSteps.filter(step => step.required).length
    return (completedSteps / totalRequired) * 100
  }

  const getCurrentLevel = () => {
    if (totalPoints >= 1000) return levels[3] // Master
    if (totalPoints >= 500) return levels[2] // Expert
    if (totalPoints >= 100) return levels[1] // Apprentice
    return levels[0] // Novice
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  return (
    <div className="space-y-6">
      {/* Header con Progreso */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Trophy size={32} />
            <div>
              <h1 className="text-2xl font-bold">Onboarding Gamificado</h1>
              <p className="text-blue-100">Completa tu entrenamiento y desbloquea todo el potencial</p>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2 mb-2">
              <Star size={20} className="text-yellow-300" />
              <span className="text-xl font-bold">{totalPoints}</span>
            </div>
            <p className="text-sm text-blue-100">Puntos Totales</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progreso General</span>
            <span>{getLevelProgress().toFixed(1)}%</span>
          </div>
          <Progress value={getLevelProgress()} className="h-3" />
        </div>
      </div>

      <Tabs defaultValue="tutorial" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="tutorial">Tutorial</TabsTrigger>
          <TabsTrigger value="demo">Modo Demo</TabsTrigger>
          <TabsTrigger value="levels">Niveles</TabsTrigger>
          <TabsTrigger value="certification">Certificación</TabsTrigger>
        </TabsList>

        <TabsContent value="tutorial" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Lista de Pasos */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen size={20} />
                    Pasos del Tutorial
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {tutorialSteps.map((step, index) => (
                      <div key={step.id} className={cn(
                        "p-4 rounded-lg border transition-all duration-300",
                        step.completed 
                          ? "bg-green-50 border-green-200" 
                          : "bg-white border-gray-200 hover:border-blue-300"
                      )}>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <div className={cn(
                                "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold",
                                step.completed 
                                  ? "bg-green-500 text-white" 
                                  : "bg-gray-200 text-gray-600"
                              )}>
                                {step.completed ? <CheckCircle size={16} /> : index + 1}
                              </div>
                              <div>
                                <h4 className="font-semibold">{step.title}</h4>
                                <p className="text-sm text-muted-foreground">{step.description}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-4 text-xs">
                              <Badge variant={step.required ? "default" : "secondary"}>
                                {step.required ? "Requerido" : "Opcional"}
                              </Badge>
                              <span className="flex items-center gap-1">
                                <Star size={12} className="text-yellow-500" />
                                {step.points} puntos
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex flex-col gap-2">
                            {step.id === 'wallet-setup' && !walletConnected && (
                              <Button 
                                onClick={() => {
                                  setWalletConnected(true)
                                  completeStep(step.id)
                                }}
                                className="gap-2"
                                size="sm"
                              >
                                <Wallet size={16} />
                                {step.action}
                              </Button>
                            )}
                            
                            {step.id === 'risk-assessment' && !riskAssessment.experience && (
                              <Button 
                                onClick={() => completeStep(step.id)}
                                className="gap-2"
                                size="sm"
                              >
                                <Shield size={16} />
                                {step.action}
                              </Button>
                            )}
                            
                            {step.id === 'demo-mode' && (
                              <Button 
                                onClick={() => completeStep(step.id)}
                                className="gap-2"
                                size="sm"
                                variant="outline"
                              >
                                <Play size={16} />
                                {step.action}
                              </Button>
                            )}
                            
                            {step.completed && (
                              <Badge className="bg-green-500 text-white">
                                <CheckCircle size={12} className="mr-1" />
                                Completado
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Panel de Estado */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target size={20} />
                    Tu Nivel Actual
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center space-y-3">
                    <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                      {getCurrentLevel().icon}
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">{getCurrentLevel().name}</h3>
                      <p className="text-sm text-muted-foreground">{getCurrentLevel().title}</p>
                    </div>
                    <Progress value={getLevelProgress()} className="h-2" />
                    <p className="text-xs text-muted-foreground">
                      {getLevelProgress().toFixed(1)}% completado
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award size={20} />
                    Logros
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Pasos Completados</span>
                      <Badge variant="outline">
                        {tutorialSteps.filter(s => s.completed).length}/{tutorialSteps.length}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Demos Completadas</span>
                      <Badge variant="outline">
                        {demoScenarios.filter(s => s.completed).length}/{demoScenarios.length}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Puntos Ganados</span>
                      <Badge className="bg-yellow-500 text-white">
                        {totalPoints}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="demo" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play size={20} />
                Escenarios de Demo
              </CardTitle>
              <p className="text-muted-foreground">
                Practica con fondos virtuales antes de usar dinero real
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {demoScenarios.map((scenario) => (
                  <Card key={scenario.id} className={cn(
                    "transition-all duration-300 hover:shadow-lg",
                    scenario.completed && "border-green-500 bg-green-50"
                  )}>
                    <CardContent className="p-6">
                      <div className="text-center space-y-4">
                        <div className={cn(
                          "mx-auto w-16 h-16 rounded-full flex items-center justify-center",
                          scenario.difficulty === 'beginner' ? "bg-green-100" :
                          scenario.difficulty === 'intermediate' ? "bg-yellow-100" : "bg-red-100"
                        )}>
                          {scenario.difficulty === 'beginner' ? <User size={24} className="text-green-600" /> :
                           scenario.difficulty === 'intermediate' ? <GraduationCap size={24} className="text-yellow-600" /> :
                           <Brain size={24} className="text-red-600" />}
                        </div>
                        
                        <div>
                          <h3 className="font-bold text-lg">{scenario.name}</h3>
                          <p className="text-sm text-muted-foreground">{scenario.description}</p>
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Dificultad:</span>
                            <Badge variant={
                              scenario.difficulty === 'beginner' ? 'default' :
                              scenario.difficulty === 'intermediate' ? 'secondary' : 'destructive'
                            }>
                              {scenario.difficulty}
                            </Badge>
                          </div>
                          <div className="flex justify-between">
                            <span>Duración:</span>
                            <span>{scenario.duration} min</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Balance Virtual:</span>
                            <span>{formatCurrency(scenario.virtualBalance)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Ganancia Esperada:</span>
                            <span className="text-green-600 font-semibold">
                              {formatCurrency(scenario.expectedProfit)}
                            </span>
                          </div>
                        </div>
                        
                        <Button 
                          className="w-full gap-2"
                          variant={scenario.completed ? "outline" : "default"}
                          onClick={() => {
                            if (!scenario.completed) {
                              completeDemo(scenario.id, Math.floor(Math.random() * 50) + 50)
                            }
                          }}
                        >
                          {scenario.completed ? (
                            <>
                              <CheckCircle size={16} />
                              Completado ({scenario.score} pts)
                            </>
                          ) : (
                            <>
                              <Play size={16} />
                              Iniciar Demo
                            </>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="levels" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {levels.map((level) => (
              <Card key={level.id} className={cn(
                "transition-all duration-300",
                level.unlocked ? "border-green-500 bg-green-50" : "border-gray-200"
              )}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={cn(
                      "w-16 h-16 rounded-full flex items-center justify-center",
                      level.unlocked ? "bg-green-500 text-white" : "bg-gray-200 text-gray-600"
                    )}>
                      {level.icon}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-bold text-lg">{level.name}</h3>
                        {level.unlocked && (
                          <Badge className="bg-green-500 text-white">
                            <Unlock size={12} className="mr-1" />
                            Desbloqueado
                          </Badge>
                        )}
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-3">{level.description}</p>
                      
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm">Requisitos:</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          {level.requirements.map((req, index) => (
                            <li key={index} className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 bg-gray-400 rounded-full" />
                              {req}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="mt-4 space-y-2">
                        <h4 className="font-semibold text-sm">Beneficios:</h4>
                        <ul className="text-sm text-green-600 space-y-1">
                          {level.benefits.map((benefit, index) => (
                            <li key={index} className="flex items-center gap-2">
                              <CheckCircle size={12} />
                              {benefit}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="certification" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Certificate size={20} />
                Certificación de Usuario
              </CardTitle>
              <p className="text-muted-foreground">
                Obtén certificaciones oficiales que validen tu experiencia
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Certificaciones Disponibles</h3>
                  
                  <div className="space-y-3">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">Certificación Básica</h4>
                        <Badge variant="outline">Gratuita</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">
                        Valida tu conocimiento fundamental de arbitraje
                      </p>
                      <Button size="sm" className="w-full">
                        <Certificate size={16} className="mr-2" />
                        Obtener Certificación
                      </Button>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">Certificación Avanzada</h4>
                        <Badge className="bg-blue-500 text-white">Premium</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">
                        Certificación profesional con validez internacional
                      </p>
                      <Button size="sm" variant="outline" className="w-full">
                        <Info size={16} className="mr-2" />
                        Más Información
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Tu Progreso</h3>
                  
                  <div className="space-y-3">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <div className="flex items-center gap-3 mb-2">
                        <Medal size={20} className="text-blue-600" />
                        <span className="font-semibold">Puntuación Total</span>
                      </div>
                      <p className="text-2xl font-bold text-blue-600">{totalPoints}</p>
                      <p className="text-sm text-muted-foreground">
                        Puntos necesarios para siguiente nivel: {Math.max(0, 100 - totalPoints)}
                      </p>
                    </div>
                    
                    <div className="p-4 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-3 mb-2">
                        <Trophy size={20} className="text-green-600" />
                        <span className="font-semibold">Logros Desbloqueados</span>
                      </div>
                      <p className="text-2xl font-bold text-green-600">
                        {tutorialSteps.filter(s => s.completed).length}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        de {tutorialSteps.length} pasos completados
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 