/**
 * 🔄 Panel de Control de Reconexión Automática
 * Interfaz completa para gestionar el servicio de reconexión automática
 * de todas las blockchains del sistema ArbitrageX
 */

import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { Switch } from '../../ui/switch'
import { Slider } from '../../ui/slider'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../ui/tabs'
import { Alert, AlertDescription } from '../../ui/alert'
import { Progress } from '../../ui/progress'
import { 
  Play, 
  Square, 
  RefreshCw, 
  Settings, 
  Wifi, 
  WifiOff, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Zap,
  Shield,
  Activity
} from 'lucide-react'
import { useAutoReconnection } from '../../hooks/useAutoReconnection'
import { BlockchainConnection } from '../../services/AutoReconnectionService'

export const AutoReconnectionPanel: React.FC = () => {
  const {
    isServiceRunning,
    isStarting,
    isStopping,
    connections,
    connectionStats,
    config,
    startService,
    stopService,
    reconnectAll,
    reconnectBlockchain,
    updateConfig,
    lastEvent
  } = useAutoReconnection()

  const [activeTab, setActiveTab] = useState('overview')
  const [showAdvancedConfig, setShowAdvancedConfig] = useState(false)

  // Función para obtener el icono de estado
  const getStatusIcon = (status: BlockchainConnection['status']) => {
    switch (status) {
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'disconnected':
        return <WifiOff className="h-4 w-4 text-red-500" />
      case 'connecting':
        return <RefreshCw className="h-4 w-4 text-yellow-500 animate-spin" />
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  // Función para obtener el color del badge de estado
  const getStatusBadgeVariant = (status: BlockchainConnection['status']) => {
    switch (status) {
      case 'connected':
        return 'default'
      case 'disconnected':
        return 'destructive'
      case 'connecting':
        return 'secondary'
      case 'error':
        return 'destructive'
      default:
        return 'outline'
    }
  }

  // Función para obtener el texto del estado
  const getStatusText = (status: BlockchainConnection['status']) => {
    switch (status) {
      case 'connected':
        return 'Conectada'
      case 'disconnected':
        return 'Desconectada'
      case 'connecting':
        return 'Reconectando...'
      case 'error':
        return 'Error'
      default:
        return 'Desconocido'
    }
  }

  // Función para formatear timestamp
  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
  }

  // Función para obtener el porcentaje de conexiones exitosas
  const getConnectionSuccessRate = () => {
    if (connectionStats.totalConnections === 0) return 0
    return (connectionStats.connectedConnections / connectionStats.totalConnections) * 100
  }

  return (
    <div className="space-y-6">
      {/* Header del Panel */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-blue-500/10 rounded-lg">
            <Zap className="h-8 w-8 text-blue-500" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Reconexión Automática de Blockchains</h1>
            <p className="text-muted-foreground">
              Sistema inteligente de reconexión automática para todas las blockchains
            </p>
          </div>
        </div>
        
        {/* Controles principales */}
        <div className="flex items-center space-x-3">
          {!isServiceRunning ? (
            <Button 
              onClick={startService} 
              disabled={isStarting}
              className="bg-green-600 hover:bg-green-700"
            >
              {isStarting ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Iniciando...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Iniciar Servicio
                </>
              )}
            </Button>
          ) : (
            <Button 
              onClick={stopService} 
              disabled={isStopping}
              variant="destructive"
            >
              {isStopping ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Deteniendo...
                </>
              ) : (
                <>
                  <Square className="h-4 w-4 mr-2" />
                  Detener Servicio
                </>
              )}
            </Button>
          )}
          
          <Button 
            onClick={reconnectAll} 
            disabled={!isServiceRunning}
            variant="outline"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Reconectar Todas
          </Button>
        </div>
      </div>

      {/* Estado del Servicio */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Estado del Servicio
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {isServiceRunning ? '🟢 Activo' : '🔴 Inactivo'}
              </div>
              <div className="text-sm text-muted-foreground">Estado del Servicio</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {connectionStats.connectedConnections}
              </div>
              <div className="text-sm text-muted-foreground">Blockchains Conectadas</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {connectionStats.disconnectedConnections + connectionStats.errorConnections}
              </div>
              <div className="text-sm text-muted-foreground">Blockchains Desconectadas</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {connectionStats.reconnectingConnections}
              </div>
              <div className="text-sm text-muted-foreground">Reconectando</div>
            </div>
          </div>
          
          {/* Barra de progreso de conexiones */}
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-2">
              <span>Tasa de Conexión Exitosa</span>
              <span>{getConnectionSuccessRate().toFixed(1)}%</span>
            </div>
            <Progress value={getConnectionSuccessRate()} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Panel Principal con Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Vista General</TabsTrigger>
          <TabsTrigger value="connections">Conexiones</TabsTrigger>
          <TabsTrigger value="events">Eventos</TabsTrigger>
          <TabsTrigger value="config">Configuración</TabsTrigger>
        </TabsList>

        {/* Tab: Vista General */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Resumen de Conexiones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wifi className="h-5 w-5" />
                  Resumen de Conexiones
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Array.from(connections.values()).map((connection) => (
                  <div key={connection.name} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(connection.status)}
                      <div>
                        <div className="font-medium capitalize">{connection.name}</div>
                        <div className="text-sm text-muted-foreground">
                          Chain ID: {connection.chainId}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={getStatusBadgeVariant(connection.status)}>
                        {getStatusText(connection.status)}
                      </Badge>
                      {connection.isConnected && (
                        <div className="text-xs text-muted-foreground mt-1">
                          {connection.latency}ms
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Último Evento */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Último Evento
                </CardTitle>
              </CardHeader>
              <CardContent>
                {lastEvent ? (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{lastEvent.type}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {formatTimestamp(lastEvent.timestamp)}
                      </span>
                    </div>
                    <div className="text-sm">
                      <pre className="bg-muted p-2 rounded text-xs overflow-auto">
                        {JSON.stringify(lastEvent.data, null, 2)}
                      </pre>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    No hay eventos recientes
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab: Conexiones Detalladas */}
        <TabsContent value="connections" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wifi className="h-5 w-5" />
                Estado Detallado de Conexiones
              </CardTitle>
              <CardDescription>
                Información completa de cada blockchain y su estado de conexión
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array.from(connections.values()).map((connection) => (
                  <div key={connection.name} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <h3 className="text-lg font-semibold capitalize">{connection.name}</h3>
                        <Badge variant="outline">Chain ID: {connection.chainId}</Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(connection.status)}
                        <Badge variant={getStatusBadgeVariant(connection.status)}>
                          {getStatusText(connection.status)}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                      <div>
                        <div className="text-sm font-medium text-muted-foreground">RPC URL</div>
                        <div className="text-sm font-mono bg-muted p-2 rounded truncate">
                          {connection.rpcUrl}
                        </div>
                      </div>
                      
                      <div>
                        <div className="text-sm font-medium text-muted-foreground">Latencia</div>
                        <div className="text-sm">
                          {connection.isConnected ? `${connection.latency}ms` : '--'}
                        </div>
                      </div>
                      
                      <div>
                        <div className="text-sm font-medium text-muted-foreground">Último Bloque</div>
                        <div className="text-sm">
                          {connection.isConnected ? connection.blockHeight.toLocaleString() : '--'}
                        </div>
                      </div>
                    </div>
                    
                    {connection.error && (
                      <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>{connection.error}</AlertDescription>
                      </Alert>
                    )}
                    
                    <div className="flex justify-end gap-2 mt-3">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => reconnectBlockchain(connection.name)}
                        disabled={!isServiceRunning || connection.status === 'connecting'}
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Reconectar
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Eventos */}
        <TabsContent value="events" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Historial de Eventos
              </CardTitle>
              <CardDescription>
                Registro de todos los eventos del servicio de reconexión
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center text-muted-foreground py-8">
                <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>El historial de eventos se implementará en la siguiente versión</p>
                <p className="text-sm">Por ahora, solo se muestra el último evento</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Configuración */}
        <TabsContent value="config" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Configuración del Servicio
              </CardTitle>
              <CardDescription>
                Ajusta los parámetros del servicio de reconexión automática
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Configuración Básica */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Configuración Básica</h3>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">Servicio Habilitado</div>
                    <div className="text-sm text-muted-foreground">
                      Activa/desactiva el servicio de reconexión automática
                    </div>
                  </div>
                  <Switch
                    checked={config.enabled}
                    onCheckedChange={(checked) => updateConfig({ enabled: checked })}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">Reconexión Automática en Error</div>
                    <div className="text-sm text-muted-foreground">
                      Intenta reconectar automáticamente cuando hay errores
                    </div>
                  </div>
                  <Switch
                    checked={config.autoReconnectOnError}
                    onCheckedChange={(checked) => updateConfig({ autoReconnectOnError: checked })}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">RPCs de Fallback</div>
                    <div className="text-sm text-muted-foreground">
                      Usa RPCs alternativos cuando el principal falla
                    </div>
                  </div>
                  <Switch
                    checked={config.fallbackRPCs}
                    onCheckedChange={(checked) => updateConfig({ fallbackRPCs: checked })}
                  />
                </div>
              </div>

              {/* Configuración Avanzada */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Configuración Avanzada</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAdvancedConfig(!showAdvancedConfig)}
                  >
                    {showAdvancedConfig ? 'Ocultar' : 'Mostrar'}
                  </Button>
                </div>
                
                {showAdvancedConfig && (
                  <div className="space-y-4 p-4 border rounded-lg bg-muted/50">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Máximo de Intentos</span>
                        <span>{config.maxRetries}</span>
                      </div>
                      <Slider
                        value={[config.maxRetries]}
                        onValueChange={([value]) => updateConfig({ maxRetries: value })}
                        max={20}
                        min={1}
                        step={1}
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Delay Base (ms)</span>
                        <span>{config.baseDelay}ms</span>
                      </div>
                      <Slider
                        value={[config.baseDelay]}
                        onValueChange={([value]) => updateConfig({ baseDelay: value })}
                        max={10000}
                        min={100}
                        step={100}
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Delay Máximo (ms)</span>
                        <span>{config.maxDelay}ms</span>
                      </div>
                      <Slider
                        value={[config.maxDelay]}
                        onValueChange={([value]) => updateConfig({ maxDelay: value })}
                        max={60000}
                        min={5000}
                        step={1000}
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Intervalo de Health Check (ms)</span>
                        <span>{config.healthCheckInterval}ms</span>
                      </div>
                      <Slider
                        value={[config.healthCheckInterval]}
                        onValueChange={([value]) => updateConfig({ healthCheckInterval: value })}
                        max={60000}
                        min={5000}
                        step={5000}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Backoff Exponencial</div>
                        <div className="text-sm text-muted-foreground">
                          Aumenta el delay entre intentos de reconexión
                        </div>
                      </div>
                      <Switch
                        checked={config.exponentialBackoff}
                        onCheckedChange={(checked) => updateConfig({ exponentialBackoff: checked })}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Botón de Restaurar Configuración */}
              <div className="flex justify-end">
                <Button
                  variant="outline"
                  onClick={() => updateConfig({
                    enabled: true,
                    maxRetries: 10,
                    baseDelay: 1000,
                    maxDelay: 30000,
                    exponentialBackoff: true,
                    healthCheckInterval: 15000,
                    autoReconnectOnError: true,
                    fallbackRPCs: true
                  })}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Restaurar Valores por Defecto
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Alertas y Notificaciones */}
      {connectionStats.errorConnections > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Hay {connectionStats.errorConnections} blockchain(s) con errores de conexión. 
            El servicio de reconexión automática está trabajando para resolverlos.
          </AlertDescription>
        </Alert>
      )}

      {!isServiceRunning && (
        <Alert>
          <Shield className="h-4 w-4" />
          <AlertDescription>
            El servicio de reconexión automática está inactivo. 
            Inícialo para comenzar a monitorear y reconectar blockchains automáticamente.
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
