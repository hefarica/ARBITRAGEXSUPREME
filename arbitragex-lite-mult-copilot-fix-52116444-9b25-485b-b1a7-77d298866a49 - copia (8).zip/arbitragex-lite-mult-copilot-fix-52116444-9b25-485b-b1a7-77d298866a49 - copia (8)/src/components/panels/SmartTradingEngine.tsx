import { useState, Suspense } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Progress } from '@/components/ui/progress'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import { 
  Robot, 
  Lock, 
  Drop, 
  TrendUp,
  Lightning,
  Shield,
  Play,
  Pause,
  Stop,
  WarningCircle,
  CheckCircle,
  Brain,
  Network,
  Timer,
  Target
} from '@phosphor-icons/react'
import { useKV } from '@/hooks/useKV'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, ScatterChart, Scatter } from 'recharts'
import MOADPanel from './MOADPanel'

interface SmartTradingEngineProps {
  environment: 'test' | 'prod'
}

// Mock data for demonstration
const arbitrageOpportunities = [
  { 
    id: 1, 
    pair: 'ETH/USDC', 
    dex1: 'Uniswap V3', 
    dex2: 'SushiSwap', 
    profit: 1.24, 
    confidence: 95,
    status: 'active'
  },
  { 
    id: 2, 
    pair: 'WBTC/ETH', 
    dex1: 'Curve', 
    dex2: 'Balancer V2', 
    profit: 0.87, 
    confidence: 88,
    status: 'pending'
  },
  { 
    id: 3, 
    pair: 'USDT/DAI', 
    dex1: 'PancakeSwap', 
    dex2: 'QuickSwap', 
    profit: 0.45, 
    confidence: 92,
    status: 'completed'
  },
]

const mevProtectionData = [
  { time: '00:00', attacks: 0, protected: 5, savings: 120 },
  { time: '04:00', attacks: 2, protected: 8, savings: 340 },
  { time: '08:00', attacks: 1, protected: 12, savings: 890 },
  { time: '12:00', attacks: 3, protected: 15, savings: 1200 },
  { time: '16:00', attacks: 0, protected: 9, savings: 560 },
  { time: '20:00', attacks: 1, protected: 7, savings: 780 },
]

const liquidityPools = [
  { pool: 'ETH/USDC', tvl: 45600000, apy: 12.5, volume24h: 12400000, opportunity: 'high' },
  { pool: 'WBTC/ETH', tvl: 23400000, apy: 8.9, volume24h: 8900000, opportunity: 'medium' },
  { pool: 'DAI/USDC', tvl: 67800000, apy: 4.2, volume24h: 5600000, opportunity: 'low' },
  { pool: 'LINK/ETH', tvl: 12300000, apy: 15.7, volume24h: 3400000, opportunity: 'high' },
]

export const SmartTradingEngine = ({ environment }: SmartTradingEngineProps) => {
  const [triangularEnabled, setTriangularEnabled] = useKV('triangular-arbitrage-enabled', true)
  const [minProfit, setMinProfit] = useKV('min-profit-threshold', [0.5])
  const [maxSlippage, setMaxSlippage] = useKV('max-slippage', [1.0])
  const [mevProtectionEnabled, setMevProtectionEnabled] = useKV('mev-protection-enabled', true)
  const [selectedDexs, setSelectedDexs] = useKV('selected-dexs', ['uniswap', 'sushiswap'])
  const [flashbotsBundles, setFlashbotsBundles] = useKV('flashbots-bundles', true)
  const [liquidityThreshold, setLiquidityThreshold] = useKV('liquidity-tvl-threshold', [1000000])

  const [engineStatus, setEngineStatus] = useState<'running' | 'paused' | 'stopped'>('running')

  const handleEngineControl = (action: 'start' | 'pause' | 'stop') => {
    setEngineStatus(action === 'start' ? 'running' : action)
  }

  return (
    <div className="p-6 space-y-6 pt-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Robot size={32} className="text-primary" />
            Smart Trading Engine
          </h1>
          <p className="text-muted-foreground mt-1">
            Arbitrage Detection + MEV Protection + Liquidity Hunter
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant={environment === 'test' ? 'secondary' : 'destructive'}>
            {environment === 'test' ? 'Paper Trading' : 'Live Trading'}
          </Badge>
          <Badge 
            variant={engineStatus === 'running' ? 'default' : engineStatus === 'paused' ? 'secondary' : 'outline'}
            className="gap-1"
          >
            {engineStatus === 'running' && <Lightning size={12} />}
            {engineStatus === 'paused' && <Pause size={12} />}
            {engineStatus === 'stopped' && <Stop size={12} />}
            {engineStatus.charAt(0).toUpperCase() + engineStatus.slice(1)}
          </Badge>
        </div>
      </div>

      {/* Engine Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Play size={20} />
            Engine Control Center
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Button 
              onClick={() => handleEngineControl('start')}
              disabled={engineStatus === 'running'}
              className="gap-2"
            >
              <Play size={16} />
              Start
            </Button>
            <Button 
              variant="outline"
              onClick={() => handleEngineControl('pause')}
              disabled={engineStatus === 'stopped'}
              className="gap-2"
            >
              <Pause size={16} />
              Pause
            </Button>
            <Button 
              variant="destructive"
              onClick={() => handleEngineControl('stop')}
              disabled={engineStatus === 'stopped'}
              className="gap-2"
            >
              <Stop size={16} />
              Stop
            </Button>
            <div className="ml-auto text-sm text-muted-foreground">
              Engine uptime: 2h 34m
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Consolidated Trading Tabs */}
      <Tabs defaultValue="moad" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="moad" className="gap-2">
            <Target size={16} />
            MOAD System
          </TabsTrigger>
          <TabsTrigger value="arbitrage" className="gap-2">
            <Target size={16} />
            Arbitrage Strategies
          </TabsTrigger>
          <TabsTrigger value="mev-protection" className="gap-2">
            <Shield size={16} />
            MEV Protection
          </TabsTrigger>
          <TabsTrigger value="liquidity" className="gap-2">
            <Drop size={16} />
            Liquidity Hunter
          </TabsTrigger>
        </TabsList>

        {/* MOAD System Tab */}
        <TabsContent value="moad" className="space-y-6">
          <Suspense fallback={<LoadingSpinner />}>
            <MOADPanel environment={environment} />
          </Suspense>
        </TabsContent>

        {/* Arbitrage Strategies Tab */}
        <TabsContent value="arbitrage" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Strategy Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Robot size={20} />
                  Strategy Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <Label>Triangular Arbitrage</Label>
                  <Switch
                    checked={triangularEnabled}
                    onCheckedChange={setTriangularEnabled}
                  />
                </div>

                <div className="space-y-3">
                  <Label>Minimum Profit Threshold (%)</Label>
                  <Slider
                    value={minProfit}
                    onValueChange={setMinProfit}
                    max={10}
                    min={0.01}
                    step={0.01}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">Current: {minProfit[0]}%</p>
                </div>

                <div className="space-y-3">
                  <Label>Maximum Slippage (%)</Label>
                  <Slider
                    value={maxSlippage}
                    onValueChange={setMaxSlippage}
                    max={5}
                    min={0.1}
                    step={0.1}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">Current: {maxSlippage[0]}%</p>
                </div>

                <div className="space-y-3">
                  <Label>Enabled DEXs</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {['uniswap', 'sushiswap', 'pancakeswap', 'quickswap'].map((dex) => (
                      <div key={dex} className="flex items-center space-x-2">
                        <Checkbox
                          checked={selectedDexs.includes(dex)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedDexs([...selectedDexs, dex])
                            } else {
                              setSelectedDexs(selectedDexs.filter(d => d !== dex))
                            }
                          }}
                        />
                        <Label className="capitalize">{dex}</Label>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Active Opportunities */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendUp size={20} />
                  Active Opportunities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {arbitrageOpportunities.map((opp) => (
                    <div key={opp.id} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{opp.pair}</span>
                        <Badge 
                          variant={opp.status === 'active' ? 'default' : 
                                   opp.status === 'pending' ? 'secondary' : 'outline'}
                        >
                          {opp.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <div>{opp.dex1} → {opp.dex2}</div>
                        <div className="flex justify-between mt-1">
                          <span>Profit: +{opp.profit}%</span>
                          <span>Confidence: {opp.confidence}%</span>
                        </div>
                      </div>
                      <Progress value={opp.confidence} className="mt-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Performance Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Arbitrage Performance (24h)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={mevProtectionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="savings" stroke="#8884d8" name="Savings ($)" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* MEV Protection Tab */}
        <TabsContent value="mev-protection" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Protection Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield size={20} />
                  Protection Gear
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <Label>MEV Protection Enabled</Label>
                  <Switch
                    checked={mevProtectionEnabled}
                    onCheckedChange={setMevProtectionEnabled}
                  />
                </div>

                <div className="space-y-3">
                  <Label>Protection Methods</Label>
                  <div className="space-y-2">
                    {[
                      'Flashbots Protect',
                      'Private Mempool',
                      'Commit-Reveal',
                      'Order Splitting',
                      'Temporal Randomization'
                    ].map((method) => (
                      <div key={method} className="flex items-center space-x-2">
                        <Checkbox defaultChecked />
                        <Label>{method}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Label>Use Flashbots Bundle</Label>
                  <Switch
                    checked={flashbotsBundles}
                    onCheckedChange={setFlashbotsBundles}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Protection Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle size={20} />
                  Protection Statistics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">47</div>
                    <div className="text-sm text-muted-foreground">Attacks Blocked</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">$4,890</div>
                    <div className="text-sm text-muted-foreground">Value Protected</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">99.2%</div>
                    <div className="text-sm text-muted-foreground">Success Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">12ms</div>
                    <div className="text-sm text-muted-foreground">Avg Response</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Front-running</span>
                    <span className="text-green-600">15 blocked</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Sandwich attacks</span>
                    <span className="text-green-600">23 blocked</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Back-running</span>
                    <span className="text-green-600">9 blocked</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* MEV Protection Timeline */}
          <Card>
            <CardHeader>
              <CardTitle>MEV Protection Activity (24h)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={mevProtectionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="attacks" fill="#ef4444" name="Attacks Detected" />
                  <Bar dataKey="protected" fill="#22c55e" name="Transactions Protected" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Liquidity Hunter Tab */}
        <TabsContent value="liquidity" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Liquidity Gear */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Drop size={20} />
                  Hunter Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>TVL Threshold (USD)</Label>
                  <Slider
                    value={liquidityThreshold}
                    onValueChange={setLiquidityThreshold}
                    max={10000000}
                    min={1000}
                    step={1000}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Current: ${liquidityThreshold[0].toLocaleString()}
                  </p>
                </div>

                <div className="space-y-3">
                  <Label>Target Tokens</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {['ETH', 'WBTC', 'USDC', 'DAI', 'LINK', 'UNI'].map((token) => (
                      <div key={token} className="flex items-center space-x-2">
                        <Checkbox defaultChecked />
                        <Label>{token}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Minimum APY (%)</Label>
                  <Input type="number" placeholder="5.0" />
                </div>
              </CardContent>
            </Card>

            {/* Market Making Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network size={20} />
                  Market Making Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">8</div>
                    <div className="text-sm text-muted-foreground">Active Positions</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">$23,450</div>
                    <div className="text-sm text-muted-foreground">Total Liquidity</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">11.2%</div>
                    <div className="text-sm text-muted-foreground">Avg APY</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">$456</div>
                    <div className="text-sm text-muted-foreground">24h Earnings</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Impermanent Loss</span>
                    <span className="text-red-600">-0.3%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Fee Earnings</span>
                    <span className="text-green-600">+1.8%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Net Profit</span>
                    <span className="text-green-600">+1.5%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Liquidity Opportunities */}
          <Card>
            <CardHeader>
              <CardTitle>Top Liquidity Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Pool</th>
                      <th className="text-right p-2">TVL</th>
                      <th className="text-right p-2">APY</th>
                      <th className="text-right p-2">24h SpeakerHigh</th>
                      <th className="text-center p-2">Opportunity</th>
                    </tr>
                  </thead>
                  <tbody>
                    {liquidityPools.map((pool, idx) => (
                      <tr key={idx} className="border-b">
                        <td className="p-2 font-medium">{pool.pool}</td>
                        <td className="p-2 text-right">${(pool.tvl / 1000000).toFixed(1)}M</td>
                        <td className="p-2 text-right">{pool.apy}%</td>
                        <td className="p-2 text-right">${(pool.volume24h / 1000000).toFixed(1)}M</td>
                        <td className="p-2 text-center">
                          <Badge 
                            variant={pool.opportunity === 'high' ? 'default' : 
                                   pool.opportunity === 'medium' ? 'secondary' : 'outline'}
                          >
                            {pool.opportunity}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

