import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { Switch } from '../../ui/switch'
import { Input } from '../../ui/input'
import { Label } from '../../ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../ui/tabs'
import { Alert, AlertDescription } from '../../ui/alert'
import { Progress } from '../../ui/progress'
import { 
  Play, Square, RefreshCw, Settings, Wifi, WifiOff, AlertTriangle, 
  CheckCircle, Clock, Zap, Shield, Activity, Database, Link, 
  Globe, Server, Network, Cpu, HardDrive, BarChart3
} from 'lucide-react'
import { useBlockchainIntegration } from '../../hooks/useBlockchainIntegration'
import { BlockchainInfo, IntegrationStatus } from '../../services/BlockchainIntegrationService'

export const BlockchainIntegrationPanel: React.FC = () => {
  const {
    isInitialized,
    isInitializing,
    integrationStatus,
    allBlockchains,
    enabledBlockchains,
    disabledBlockchains,
    integrationStats,
    integrationHealth,
    initialize,
    setBlockchainEnabled,
    updateBlockchainRPC,
    forceReconnectAll,
    getBlockchainInfo
  } = useBlockchainIntegration()

  const [editingRPC, setEditingRPC] = useState<string | null>(null)
  const [newRPCUrl, setNewRPCUrl] = useState('')

  // Helper functions for status display
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-500" />
      default: return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'healthy': return <Badge variant="default" className="bg-green-100 text-green-800">Healthy</Badge>
      case 'warning': return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Warning</Badge>
      case 'error': return <Badge variant="destructive">Error</Badge>
      default: return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'healthy': return 'All systems operational'
      case 'warning': return 'Some issues detected'
      case 'error': return 'Critical issues detected'
      default: return 'Status unknown'
    }
  }

  const formatTimestamp = (timestamp: number) => {
    if (!timestamp) return 'Never'
    return new Date(timestamp).toLocaleString()
  }

  const getBlockchainStatusIcon = (blockchain: BlockchainInfo) => {
    if (!blockchain.enabled) return <WifiOff className="h-4 w-4 text-gray-400" />
    if (blockchain.isConnected) return <Wifi className="h-4 w-4 text-green-500" />
    return <WifiOff className="h-4 w-4 text-red-500" />
  }

  const getBlockchainStatusBadge = (blockchain: BlockchainInfo) => {
    if (!blockchain.enabled) return <Badge variant="outline">Disabled</Badge>
    if (blockchain.isConnected) return <Badge variant="default" className="bg-green-100 text-green-800">Connected</Badge>
    return <Badge variant="destructive">Disconnected</Badge>
  }

  const handleRPCUpdate = (blockchainName: string) => {
    if (newRPCUrl.trim()) {
      updateBlockchainRPC(blockchainName, newRPCUrl.trim())
      setNewRPCUrl('')
      setEditingRPC(null)
    }
  }

  const getHealthPercentage = () => {
    if (allBlockchains.length === 0) return 0
    const healthyCount = allBlockchains.filter(b => b.enabled && b.isConnected).length
    return Math.round((healthyCount / allBlockchains.length) * 100)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Blockchain Integration</h1>
          <p className="text-muted-foreground">
            Manage and monitor blockchain connections across the entire system
          </p>
        </div>
        <div className="flex items-center space-x-2">
          {!isInitialized && (
            <Button 
              onClick={initialize} 
              disabled={isInitializing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isInitializing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Initializing...
                </>
              ) : (
                <>
                  <Database className="mr-2 h-4 w-4" />
                  Initialize System
                </>
              )}
            </Button>
          )}
          <Button 
            onClick={forceReconnectAll}
            disabled={!isInitialized}
            variant="outline"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Force Reconnect All
          </Button>
        </div>
      </div>

      {/* Service Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Server className="h-5 w-5" />
            <span>Integration Service Status</span>
          </CardTitle>
          <CardDescription>
            Overall health and status of the blockchain integration system
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-2">
                {getStatusIcon(integrationHealth.status)}
                <span className="font-medium">Status:</span>
              </div>
              {getStatusBadge(integrationHealth.status)}
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-gray-500" />
              <span className="font-medium">Last Updated:</span>
              <span className="text-sm text-muted-foreground">
                {formatTimestamp(integrationHealth.lastUpdated)}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Activity className="h-4 w-4 text-blue-500" />
              <span className="font-medium">Health Score:</span>
              <span className="text-sm font-mono">{getHealthPercentage()}%</span>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Overall Health</span>
              <span>{getHealthPercentage()}%</span>
            </div>
            <Progress value={getHealthPercentage()} className="h-2" />
          </div>

          <div className="text-sm text-muted-foreground">
            {getStatusText(integrationHealth.status)}
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="blockchains">Blockchains</TabsTrigger>
          <TabsTrigger value="statistics">Statistics</TabsTrigger>
          <TabsTrigger value="configuration">Configuration</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Blockchains</CardTitle>
                <Globe className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{allBlockchains.length}</div>
                <p className="text-xs text-muted-foreground">
                  Configured in system
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Enabled</CardTitle>
                <Wifi className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{enabledBlockchains.length}</div>
                <p className="text-xs text-muted-foreground">
                  Active connections
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Connected</CardTitle>
                <Network className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {enabledBlockchains.filter(b => b.isConnected).length}
                </div>
                <p className="text-xs text-muted-foreground">
                  Currently online
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Disabled</CardTitle>
                <WifiOff className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-600">{disabledBlockchains.length}</div>
                <p className="text-xs text-muted-foreground">
                  Inactive connections
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Zap className="h-5 w-5" />
                <span>Quick Actions</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={forceReconnectAll}
                  disabled={!isInitialized}
                  variant="outline"
                  size="sm"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Reconnect All
                </Button>
                <Button
                  onClick={() => {
                    enabledBlockchains.forEach(b => setBlockchainEnabled(b.name, false))
                  }}
                  variant="outline"
                  size="sm"
                >
                  <WifiOff className="mr-2 h-4 w-4" />
                  Disable All
                </Button>
                <Button
                  onClick={() => {
                    disabledBlockchains.forEach(b => setBlockchainEnabled(b.name, true))
                  }}
                  variant="outline"
                  size="sm"
                >
                  <Wifi className="mr-2 h-4 w-4" />
                  Enable All
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Blockchains Tab */}
        <TabsContent value="blockchains" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Database className="h-5 w-5" />
                <span>Blockchain Connections</span>
              </CardTitle>
              <CardDescription>
                Manage individual blockchain connections and settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {allBlockchains.map((blockchain) => (
                  <div key={blockchain.name} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        {getBlockchainStatusIcon(blockchain)}
                        <div>
                          <h3 className="font-semibold">{blockchain.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            Chain ID: {blockchain.chainId} • {blockchain.networkType}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getBlockchainStatusBadge(blockchain)}
                        <Switch
                          checked={blockchain.enabled}
                          onCheckedChange={(checked) => setBlockchainEnabled(blockchain.name, checked)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">RPC URL:</span>
                        <div className="flex items-center space-x-2 mt-1">
                          <Input
                            value={editingRPC === blockchain.name ? newRPCUrl : blockchain.rpcUrl}
                            onChange={(e) => setNewRPCUrl(e.target.value)}
                            placeholder="Enter new RPC URL"
                            className="text-xs"
                          />
                          {editingRPC === blockchain.name ? (
                            <div className="flex space-x-1">
                              <Button
                                size="sm"
                                onClick={() => handleRPCUpdate(blockchain.name)}
                                className="h-8 px-2"
                              >
                                Save
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingRPC(null)
                                  setNewRPCUrl('')
                                }}
                                className="h-8 px-2"
                              >
                                Cancel
                              </Button>
                            </div>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingRPC(blockchain.name)
                                setNewRPCUrl(blockchain.rpcUrl)
                              }}
                              className="h-8 px-2"
                            >
                              Edit
                            </Button>
                          )}
                        </div>
                      </div>

                      <div>
                        <span className="font-medium">Connection Info:</span>
                        <div className="mt-1 space-y-1">
                          <div className="flex justify-between">
                            <span>Status:</span>
                            <span className={blockchain.isConnected ? 'text-green-600' : 'text-red-600'}>
                              {blockchain.isConnected ? 'Online' : 'Offline'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Last Connected:</span>
                            <span className="text-xs">
                              {formatTimestamp(blockchain.lastConnected)}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Last Disconnected:</span>
                            <span className="text-xs">
                              {formatTimestamp(blockchain.lastDisconnected)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {blockchain.enabled && (
                      <div className="flex justify-end">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            // This would trigger a reconnection for this specific blockchain
                            console.log(`Reconnecting ${blockchain.name}`)
                          }}
                        >
                          <RefreshCw className="mr-2 h-4 w-4" />
                          Reconnect
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Statistics Tab */}
        <TabsContent value="statistics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5" />
                  <span>Integration Statistics</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Total Blockchains:</span>
                    <span className="font-mono">{integrationStats.totalBlockchains}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Enabled Blockchains:</span>
                    <span className="font-mono">{integrationStats.enabledBlockchains}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Connected Blockchains:</span>
                    <span className="font-mono">{integrationStats.connectedBlockchains}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Connection Rate:</span>
                    <span className="font-mono">
                      {integrationStats.connectionRate.toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Synchronization:</span>
                    <span className="text-sm">
                      {formatTimestamp(integrationStats.lastSynchronization)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Health Metrics</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Overall Health:</span>
                    <span className="font-mono">{integrationHealth.overallHealth}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Connection Stability:</span>
                    <span className="font-mono">{integrationHealth.connectionStability}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Response Time:</span>
                    <span className="font-mono">{integrationHealth.averageResponseTime}ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Error Rate:</span>
                    <span className="font-mono">{integrationHealth.errorRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Uptime:</span>
                    <span className="font-mono">{integrationHealth.uptime}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Configuration Tab */}
        <TabsContent value="configuration" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>Integration Configuration</span>
              </CardTitle>
              <CardDescription>
                Configure blockchain integration settings and parameters
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Service Settings</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="auto-sync">Auto Synchronization</Label>
                      <Switch id="auto-sync" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="health-checks">Health Checks</Label>
                      <Switch id="health-checks" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="auto-reconnect">Auto Reconnection</Label>
                      <Switch id="auto-reconnect" defaultChecked />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Performance Settings</h4>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="sync-interval">Sync Interval (ms)</Label>
                      <Input
                        id="sync-interval"
                        type="number"
                        defaultValue={5000}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="health-interval">Health Check Interval (ms)</Label>
                      <Input
                        id="health-interval"
                        type="number"
                        defaultValue={30000}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="timeout">Connection Timeout (ms)</Label>
                      <Input
                        id="timeout"
                        type="number"
                        defaultValue={10000}
                        className="mt-1"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Button variant="outline" className="w-full">
                  <Settings className="mr-2 h-4 w-4" />
                  Save Configuration
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Alerts */}
      {!isInitialized && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            The blockchain integration service has not been initialized. Click "Initialize System" to start managing blockchain connections.
          </AlertDescription>
        </Alert>
      )}

      {isInitialized && integrationHealth.status === 'error' && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Critical issues detected in the blockchain integration system. Check the configuration and connection status.
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}

