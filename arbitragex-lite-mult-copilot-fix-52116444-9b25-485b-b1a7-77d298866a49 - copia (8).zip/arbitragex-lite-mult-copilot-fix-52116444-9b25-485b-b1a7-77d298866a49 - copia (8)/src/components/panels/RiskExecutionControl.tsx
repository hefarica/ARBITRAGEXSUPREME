import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { 
  Shield, 
  Play, 
  Timer, 
  WarningCircle,
  TrendUp,
  TrendDown,
  Pause,
  SkipForward,
  Gear,
  Cpu,
  Activity,
  Target,
  Lightning,
  Clock,
  ChartBar3,
  ChartLine as ChartLineIcon
} from '@phosphor-icons/react'
import { useKV } from '@/hooks/useKV'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell } from 'recharts'

interface RiskExecutionControlProps {
  environment: 'test' | 'prod'
}

// Mock data for demonstration
const riskMetrics = [
  { time: '00:00', var95: 1200, var99: 1800, sharpe: 1.45 },
  { time: '04:00', var95: 1350, var99: 2100, sharpe: 1.38 },
  { time: '08:00', var95: 1580, var99: 2400, sharpe: 1.52 },
  { time: '12:00', var95: 1420, var99: 2200, sharpe: 1.41 },
  { time: '16:00', var95: 1680, var99: 2550, sharpe: 1.35 },
  { time: '20:00', var95: 1390, var99: 2180, sharpe: 1.48 },
]

const executionMetrics = [
  { time: '00:00', orders: 23, filled: 22, latency: 45 },
  { time: '04:00', orders: 18, filled: 18, latency: 42 },
  { time: '08:00', orders: 31, filled: 29, latency: 48 },
  { time: '12:00', orders: 45, filled: 43, latency: 52 },
  { time: '16:00', orders: 38, filled: 37, latency: 46 },
  { time: '20:00', orders: 27, filled: 26, latency: 44 },
]

const latencyDistribution = [
  { name: '<10ms', value: 35, color: '#22c55e' },
  { name: '10-50ms', value: 45, color: '#3b82f6' },
  { name: '50-100ms', value: 15, color: '#f59e0b' },
  { name: '>100ms', value: 5, color: '#ef4444' },
]

const riskProfiles = [
  { name: 'Conservative', risk: 20, maxDrawdown: 5, targetReturn: 8 },
  { name: 'Moderate', risk: 50, maxDrawdown: 10, targetReturn: 15 },
  { name: 'Aggressive', risk: 80, maxDrawdown: 20, targetReturn: 25 },
]

export const RiskExecutionControl = ({ environment }: RiskExecutionControlProps) => {
  const [riskProfile, setRiskProfile] = useKV('risk-profile', 'moderate')
  const [maxPositionSize, setMaxPositionSize] = useKV('max-position-size', [50000])
  const [stopLossPercent, setStopLossPercent] = useKV('stop-loss-percent', [2.0])
  const [executionMode, setExecutionMode] = useKV('execution-mode', 'semi-auto')
  const [maxConcurrentOrders, setMaxConcurrentOrders] = useKV('max-concurrent-orders', [10])
  const [routingAlgorithm, setRoutingAlgorithm] = useKV('routing-algorithm', 'TWAP')
  const [latencyTarget, setLatencyTarget] = useKV('latency-target', '<50μs')
  const [cpuCores, setCpuCores] = useKV('cpu-cores', [4])

  const [systemStatus, setSystemStatus] = useState<'optimal' | 'warning' | 'critical'>('optimal')

  return (
    <div className="p-6 space-y-6 pt-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Shield size={32} className="text-primary" />
            Risk & Execution Control
          </h1>
          <p className="text-muted-foreground mt-1">
            Risk Management + Execution Control + HFT Optimization
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant={environment === 'test' ? 'secondary' : 'destructive'}>
            {environment === 'test' ? 'Risk-Free Mode' : 'Live Risk'}
          </Badge>
          <Badge 
            variant={systemStatus === 'optimal' ? 'default' : 
                   systemStatus === 'warning' ? 'secondary' : 'destructive'}
            className="gap-1"
          >
            {systemStatus === 'optimal' && <Activity size={12} />}
            {systemStatus === 'warning' && <WarningCircle size={12} />}
            {systemStatus === 'critical' && <WarningCircle size={12} />}
            {systemStatus.charAt(0).toUpperCase() + systemStatus.slice(1)}
          </Badge>
        </div>
      </div>

      {/* Quick Risk Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Current VaR (95%)</p>
                <p className="text-2xl font-bold">$1,420</p>
              </div>
              <Shield className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Sharpe Ratio</p>
                <p className="text-2xl font-bold">1.48</p>
              </div>
              <TrendUp className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Latency</p>
                <p className="text-2xl font-bold">46ms</p>
              </div>
              <Timer className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Fill Rate</p>
                <p className="text-2xl font-bold">97.3%</p>
              </div>
              <Target className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Control Tabs */}
      <Tabs defaultValue="risk" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="risk" className="gap-2">
            <Shield size={16} />
            Risk Management
          </TabsTrigger>
          <TabsTrigger value="execution" className="gap-2">
            <Play size={16} />
            Execution Control
          </TabsTrigger>
          <TabsTrigger value="hft" className="gap-2">
            <Lightning size={16} />
            HFT Engine
          </TabsTrigger>
        </TabsList>

        {/* Risk Management Tab */}
        <TabsContent value="risk" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Risk Profile Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield size={20} />
                  Risk Profile Builder
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Risk Profile</Label>
                  <Select value={riskProfile} onValueChange={setRiskProfile}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="conservative">Conservative</SelectItem>
                      <SelectItem value="moderate">Moderate</SelectItem>
                      <SelectItem value="aggressive">Aggressive</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label>Maximum Position Size (USD)</Label>
                  <Slider
                    value={maxPositionSize}
                    onValueChange={setMaxPositionSize}
                    max={100000}
                    min={1000}
                    step={1000}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Current: ${maxPositionSize[0].toLocaleString()}
                  </p>
                </div>

                <div className="space-y-3">
                  <Label>Auto Stop Loss (%)</Label>
                  <Slider
                    value={stopLossPercent}
                    onValueChange={setStopLossPercent}
                    max={10}
                    min={0.5}
                    step={0.1}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Current: {stopLossPercent[0]}%
                  </p>
                </div>

                <div className="space-y-3">
                  <Label>Risk Profile Comparison</Label>
                  <div className="space-y-2">
                    {riskProfiles.map((profile) => (
                      <div key={profile.name} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-medium">{profile.name}</span>
                          <span className="text-sm text-muted-foreground">
                            Target: {profile.targetReturn}%
                          </span>
                        </div>
                        <div className="flex gap-4 text-sm">
                          <span>Risk: {profile.risk}%</span>
                          <span>Max DD: {profile.maxDrawdown}%</span>
                        </div>
                        <Progress value={profile.risk} className="mt-2" />
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Risk Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 size={20} />
                  Risk Analytics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-lg font-bold">$1,420</div>
                    <div className="text-sm text-muted-foreground">VaR 95%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold">$2,180</div>
                    <div className="text-sm text-muted-foreground">VaR 99%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold">1.48</div>
                    <div className="text-sm text-muted-foreground">Sharpe Ratio</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold">-3.2%</div>
                    <div className="text-sm text-muted-foreground">Max Drawdown</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Portfolio Beta</span>
                    <span>0.85</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Correlation to Market</span>
                    <span>0.72</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Volatility (30d)</span>
                    <span>18.5%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Information Ratio</span>
                    <span>1.23</span>
                  </div>
                </div>

                <div className="pt-4">
                  <Label className="text-sm font-medium">Risk Heatmap</Label>
                  <div className="mt-2 grid grid-cols-5 gap-1">
                    {Array.from({ length: 25 }, (_, i) => (
                      <div
                        key={i}
                        className={`aspect-square rounded ${
                          i < 5 ? 'bg-green-200' :
                          i < 15 ? 'bg-yellow-200' :
                          'bg-red-200'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Risk Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Risk Metrics Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={riskMetrics}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="var95" stroke="#8884d8" name="VaR 95%" />
                  <Line type="monotone" dataKey="var99" stroke="#82ca9d" name="VaR 99%" />
                  <Line type="monotone" dataKey="sharpe" stroke="#ffc658" name="Sharpe Ratio" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Execution Control Tab */}
        <TabsContent value="execution" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Execution Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play size={20} />
                  Execution Gear
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Execution Mode</Label>
                  <Select value={executionMode} onValueChange={setExecutionMode}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">Manual Control</SelectItem>
                      <SelectItem value="semi-auto">Semi-Automatic</SelectItem>
                      <SelectItem value="full-auto">Fully Automatic</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {executionMode === 'manual' && 'All orders require manual confirmation'}
                    {executionMode === 'semi-auto' && 'High-value orders require confirmation'}
                    {executionMode === 'full-auto' && 'All orders execute automatically'}
                  </p>
                </div>

                <div className="space-y-3">
                  <Label>Max Concurrent Orders</Label>
                  <Slider
                    value={maxConcurrentOrders}
                    onValueChange={setMaxConcurrentOrders}
                    max={50}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Current: {maxConcurrentOrders[0]} orders
                  </p>
                </div>

                <div className="space-y-3">
                  <Label>Smart Order Routing</Label>
                  <Select value={routingAlgorithm} onValueChange={setRoutingAlgorithm}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TWAP">TWAP (Time Weighted)</SelectItem>
                      <SelectItem value="VWAP">VWAP (SpeakerHigh Weighted)</SelectItem>
                      <SelectItem value="IS">Implementation Shortfall</SelectItem>
                      <SelectItem value="Custom">Custom Algorithm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" size="sm" className="gap-1">
                    <Play size={12} />
                    Start
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1">
                    <Pause size={12} />
                    Pause
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1">
                    <SkipForward size={12} />
                    Skip
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Order Queue Management */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChartIcon size={20} />
                  Order Queue
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-xl font-bold">8</div>
                    <div className="text-sm text-muted-foreground">Pending</div>
                  </div>
                  <div>
                    <div className="text-xl font-bold">23</div>
                    <div className="text-sm text-muted-foreground">Executing</div>
                  </div>
                  <div>
                    <div className="text-xl font-bold">156</div>
                    <div className="text-sm text-muted-foreground">Completed</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Average Fill Time</span>
                    <span>234ms</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Fill Rate</span>
                    <span className="text-green-600">97.3%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Slippage (avg)</span>
                    <span className="text-orange-600">0.12%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Rejected Orders</span>
                    <span className="text-red-600">4</span>
                  </div>
                </div>

                <div className="pt-4">
                  <Label className="text-sm font-medium">Recent Orders</Label>
                  <div className="mt-2 space-y-2">
                    {[
                      { symbol: 'ETH/USDC', side: 'BUY', amount: 1.5, status: 'filled' },
                      { symbol: 'WBTC/ETH', side: 'SELL', amount: 0.03, status: 'pending' },
                      { symbol: 'DAI/USDC', side: 'BUY', amount: 1000, status: 'executing' },
                    ].map((order, idx) => (
                      <div key={idx} className="flex justify-between text-sm p-2 border rounded">
                        <span>{order.symbol}</span>
                        <span className={`font-medium ${
                          order.side === 'BUY' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {order.side} {order.amount}
                        </span>
                        <Badge variant={
                          order.status === 'filled' ? 'default' :
                          order.status === 'executing' ? 'secondary' : 'outline'
                        }>
                          {order.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Execution Performance Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Execution Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={executionMetrics}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="orders" stackId="1" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                  <Area type="monotone" dataKey="filled" stackId="1" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* HFT Engine Tab */}
        <TabsContent value="hft" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Latency Optimization */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Timer size={20} />
                  Ultra-Low Latency Gear
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Latency Target</Label>
                  <Select value={latencyTarget} onValueChange={setLatencyTarget}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="<100μs">{'<100μs'}</SelectItem>
                      <SelectItem value="<50μs">{'<50μs'}</SelectItem>
                      <SelectItem value="<25μs">{'<25μs'}</SelectItem>
                      <SelectItem value="<10μs">{'<10μs'}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label>CPU Core Affinity</Label>
                  <Slider
                    value={cpuCores}
                    onValueChange={setCpuCores}
                    max={16}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Dedicated cores: {cpuCores[0]}
                  </p>
                </div>

                <div className="space-y-3">
                  <Label>Network Optimization</Label>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Kernel Bypass</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Direct Memory Access</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Hardware Timestamping</span>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity size={20} />
                  Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-xl font-bold text-green-600">42μs</div>
                    <div className="text-sm text-muted-foreground">Average Latency</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-blue-600">15μs</div>
                    <div className="text-sm text-muted-foreground">Min Latency</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">99.8%</div>
                    <div className="text-sm text-muted-foreground">Target Hit Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">2.1μs</div>
                    <div className="text-sm text-muted-foreground">Jitter</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Latency Distribution</Label>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={latencyDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {latencyDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {latencyDistribution.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span>{item.name}: {item.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Book Analysis */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 size={20} />
                Order Book Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-lg font-bold">10</div>
                  <div className="text-sm text-muted-foreground">Book Depth</div>
                </div>
                <div>
                  <div className="text-lg font-bold">$2.3M</div>
                  <div className="text-sm text-muted-foreground">Bid Liquidity</div>
                </div>
                <div>
                  <div className="text-lg font-bold">$2.1M</div>
                  <div className="text-sm text-muted-foreground">Ask Liquidity</div>
                </div>
                <div>
                  <div className="text-lg font-bold">0.02%</div>
                  <div className="text-sm text-muted-foreground">Spread</div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Market Impact (100K)</span>
                  <span>0.08%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Book Imbalance</span>
                  <span className="text-green-600">+0.15</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Price Volatility</span>
                  <span>1.23%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Order Flow Toxicity</span>
                  <span className="text-orange-600">0.34</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

