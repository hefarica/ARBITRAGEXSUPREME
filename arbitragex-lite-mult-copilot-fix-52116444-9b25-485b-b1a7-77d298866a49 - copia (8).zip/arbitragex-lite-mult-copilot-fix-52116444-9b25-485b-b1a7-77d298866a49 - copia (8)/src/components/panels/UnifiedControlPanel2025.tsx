import React, { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Grid,
  Settings,
  Play,
  Pause,
  Stop,
  Zap,
  Shield,
  Target,
  TrendingUp,
  TrendingDown,
  Activity,
  Clock,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Warning,
  Brain,
  Robot,
  Gear,
  Sliders,
  ToggleLeft,
  ToggleRight,
  ArrowsClockwise,
  ArrowsCounterClockwise,
  Plus,
  Minus,
  Equal,
  ChartLine,
  BarChart3,
  PieChart,
  LineChart,
  Globe,
  Database,
  Cpu,
  Network,
  Wifi,
  WifiOff,
  Lock,
  Unlock,
  Eye,
  EyeSlash,
  Bell,
  BellSlash,
  Timer,
  Calendar,
  ClockCounterClockwise,
  Rocket,
  Satellite,
  Broadcast,
  Radio,
  Television,
  Monitor,
  Smartphone,
  Tablet,
  Laptop,
  Desktop,
  Server,
  Cloud,
  HardDrives,
  HardDrive,
  FloppyDisk,
  CompactDisc,
  Usb,
  Bluetooth,
  WifiHigh,
  WifiMedium,
  WifiLow,
  Signal,
  SignalHigh,
  SignalMedium,
  SignalLow,
  Battery,
  BatteryCharging,
  BatteryWarning,
  BatteryEmpty,
  Power,
  PowerOff,
  PowerOn,
  PowerWarning,
  PowerError,
  PowerSuccess,
  PowerInfo,
  PowerQuestion,
  PowerPlus,
  PowerMinus,
  PowerEqual,
  PowerDivide,
  PowerMultiply,
  PowerPercent,
  PowerSquare,
  PowerCube,
  PowerRoot,
  PowerLog,
  PowerLn,
  PowerExp,
  PowerSin,
  PowerCos,
  PowerTan,
  PowerAsin,
  PowerAcos,
  PowerAtan,
  PowerSinh,
  PowerCosh,
  PowerTanh,
  PowerAsinh,
  PowerAcosh,
  PowerAtanh
} from '@phosphor-icons/react'
import { useSimulation } from '../simulation/SimulationProvider'
import { cn } from '@/lib/utils'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'

interface Strategy {
  id: string
  name: string
  type: 'triangular' | 'cross-dex' | 'flash-loan' | 'mev' | 'liquidation'
  status: 'active' | 'paused' | 'stopped' | 'error'
  profit: number
  winRate: number
  risk: 'low' | 'medium' | 'high'
  autoMode: boolean
  riskLevel: number // 0-100
  profitTarget: number
  stopLoss: number
  maxTradeSize: number
  minProfit: number
  enabled: boolean
  priority: number // 1-10
  lastExecution: Date | null
  nextExecution: Date | null
  totalTrades: number
  successfulTrades: number
}

interface SystemConfig {
  globalAutoMode: boolean
  riskManagement: boolean
  notifications: boolean
  emergencyStop: boolean
  maxConcurrentTrades: number
  globalRiskLevel: number
  globalProfitTarget: number
  globalStopLoss: number
  marketHours: {
    start: string
    end: string
    enabled: boolean
  }
  maintenance: {
    enabled: boolean
    schedule: string
    duration: number
  }
}

export function UnifiedControlPanel2025() {
  const { state, executeTrade } = useSimulation()
  const [strategies, setStrategies] = useState<Strategy[]>([
    {
      id: 'triangular-1',
      name: 'Arbitraje Triangular ETH',
      type: 'triangular',
      status: 'active',
      profit: 1250.50,
      winRate: 87.5,
      risk: 'low',
      autoMode: true,
      riskLevel: 25,
      profitTarget: 100,
      stopLoss: 50,
      maxTradeSize: 5000,
      minProfit: 10,
      enabled: true,
      priority: 8,
      lastExecution: new Date(Date.now() - 300000),
      nextExecution: new Date(Date.now() + 120000),
      totalTrades: 24,
      successfulTrades: 21
    },
    {
      id: 'cross-dex-1',
      name: 'Cross-DEX BTC/USDT',
      type: 'cross-dex',
      status: 'active',
      profit: 890.25,
      winRate: 92.3,
      risk: 'medium',
      autoMode: true,
      riskLevel: 45,
      profitTarget: 75,
      stopLoss: 35,
      maxTradeSize: 3000,
      minProfit: 15,
      enabled: true,
      priority: 7,
      lastExecution: new Date(Date.now() - 180000),
      nextExecution: new Date(Date.now() + 90000),
      totalTrades: 18,
      successfulTrades: 17
    },
    {
      id: 'flash-loan-1',
      name: 'Flash Loan DAI',
      type: 'flash-loan',
      status: 'paused',
      profit: 2100.75,
      winRate: 78.9,
      risk: 'high',
      autoMode: false,
      riskLevel: 75,
      profitTarget: 200,
      stopLoss: 100,
      maxTradeSize: 10000,
      minProfit: 50,
      enabled: true,
      priority: 6,
      lastExecution: new Date(Date.now() - 600000),
      nextExecution: null,
      totalTrades: 12,
      successfulTrades: 9
    },
    {
      id: 'mev-1',
      name: 'MEV Sandwich',
      type: 'mev',
      status: 'active',
      profit: 3450.00,
      winRate: 95.2,
      risk: 'high',
      autoMode: true,
      riskLevel: 80,
      profitTarget: 300,
      stopLoss: 150,
      maxTradeSize: 15000,
      minProfit: 100,
      enabled: true,
      priority: 9,
      lastExecution: new Date(Date.now() - 120000),
      nextExecution: new Date(Date.now() + 60000),
      totalTrades: 31,
      successfulTrades: 30
    }
  ])

  const [systemConfig, setSystemConfig] = useState<SystemConfig>({
    globalAutoMode: true,
    riskManagement: true,
    notifications: true,
    emergencyStop: false,
    maxConcurrentTrades: 5,
    globalRiskLevel: 50,
    globalProfitTarget: 100,
    globalStopLoss: 50,
    marketHours: {
      start: '09:00',
      end: '17:00',
      enabled: true
    },
    maintenance: {
      enabled: false,
      schedule: '02:00',
      duration: 30
    }
  })

  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null)
  const [manualOverride, setManualOverride] = useState(false)
  const [systemAlerts, setSystemAlerts] = useState<string[]>([])

  // Simulación de actualizaciones en tiempo real
  useEffect(() => {
    if (!state.isRunning) return

    const interval = setInterval(() => {
      setStrategies(prev => prev.map(strategy => {
        if (strategy.status === 'active' && strategy.enabled) {
          const profitChange = (Math.random() - 0.5) * 20
          const newProfit = Math.max(0, strategy.profit + profitChange)
          
          return {
            ...strategy,
            profit: newProfit,
            lastExecution: new Date(),
            nextExecution: new Date(Date.now() + Math.random() * 300000 + 60000)
          }
        }
        return strategy
      }))
    }, 5000)

    return () => clearInterval(interval)
  }, [state.isRunning])

  const toggleStrategy = (strategyId: string) => {
    setStrategies(prev => prev.map(strategy => 
      strategy.id === strategyId 
        ? { ...strategy, enabled: !strategy.enabled }
        : strategy
    ))
  }

  const updateStrategyRisk = (strategyId: string, riskLevel: number) => {
    setStrategies(prev => prev.map(strategy => 
      strategy.id === strategyId 
        ? { ...strategy, riskLevel }
        : strategy
    ))
  }

  const updateStrategyProfitTarget = (strategyId: string, target: number) => {
    setStrategies(prev => prev.map(strategy => 
      strategy.id === strategyId 
        ? { ...strategy, profitTarget: target }
        : strategy
    ))
  }

  const executeManualTrade = (strategy: Strategy) => {
    if (!manualOverride) return

    const tradeAmount = strategy.maxTradeSize * (strategy.riskLevel / 100)
    const expectedProfit = tradeAmount * (strategy.profitTarget / 100)
    
    executeTrade({
      type: 'manual-override',
      tokens: ['ETH', 'USDC'],
      amount: tradeAmount,
      profit: expectedProfit,
      fees: expectedProfit * 0.1
    })

    setSystemAlerts(prev => [...prev, `Operación manual ejecutada: ${strategy.name}`])
  }

  const emergencyStop = () => {
    setSystemConfig(prev => ({ ...prev, emergencyStop: true }))
    setStrategies(prev => prev.map(strategy => ({ ...strategy, status: 'stopped' })))
    setSystemAlerts(prev => [...prev, '¡PARADA DE EMERGENCIA ACTIVADA!'])
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const getStrategyIcon = (type: string) => {
    switch (type) {
      case 'triangular': return <Triangle size={20} />
      case 'cross-dex': return <ArrowsClockwise size={20} />
      case 'flash-loan': return <Zap size={20} />
      case 'mev': return <Brain size={20} />
      case 'liquidation': return <Target size={20} />
      default: return <Activity size={20} />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600'
      case 'paused': return 'text-yellow-600'
      case 'stopped': return 'text-red-600'
      case 'error': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'bg-green-100 text-green-800'
      case 'medium': return 'bg-yellow-100 text-yellow-800'
      case 'high': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const totalProfit = strategies.reduce((sum, s) => sum + s.profit, 0)
  const activeStrategies = strategies.filter(s => s.status === 'active' && s.enabled).length
  const totalTrades = strategies.reduce((sum, s) => sum + s.totalTrades, 0)
  const successfulTrades = strategies.reduce((sum, s) => sum + s.successfulTrades, 0)
  const overallWinRate = totalTrades > 0 ? (successfulTrades / totalTrades) * 100 : 0

  return (
    <div className="space-y-6">
      {/* Header del Panel de Control */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Grid size={32} />
            <div>
              <h1 className="text-2xl font-bold">Panel de Control Unificado</h1>
              <p className="text-purple-100">Gestión centralizada de todas las estrategias de arbitraje</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <DollarSign size={20} />
                <span className="text-xl font-bold">{formatCurrency(totalProfit)}</span>
              </div>
              <p className="text-sm text-purple-100">Ganancia Total</p>
            </div>
            
            <Button
              variant="destructive"
              onClick={emergencyStop}
              disabled={systemConfig.emergencyStop}
              className="gap-2"
            >
              <Stop size={16} />
              Parada de Emergencia
            </Button>
          </div>
        </div>
        
        {/* Métricas Rápidas */}
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold">{activeStrategies}</p>
            <p className="text-sm text-purple-100">Estrategias Activas</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{totalTrades}</p>
            <p className="text-sm text-purple-100">Operaciones Totales</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{overallWinRate.toFixed(1)}%</p>
            <p className="text-sm text-purple-100">Tasa de Éxito</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{systemConfig.maxConcurrentTrades}</p>
            <p className="text-sm text-purple-100">Máx. Concurrentes</p>
          </div>
        </div>
      </div>

      {/* Alertas del Sistema */}
      {systemAlerts.length > 0 && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertTriangle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800">
            <strong>Alertas del Sistema:</strong> {systemAlerts.slice(-3).join(', ')}
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="strategies" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="strategies">Estrategias</TabsTrigger>
          <TabsTrigger value="controls">Controles</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoreo</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="strategies" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lista de Estrategias */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Estrategias Activas</h3>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={systemConfig.globalAutoMode}
                    onCheckedChange={(checked) => setSystemConfig(prev => ({ ...prev, globalAutoMode: checked }))}
                  />
                  <span className="text-sm">Modo Automático Global</span>
                </div>
              </div>
              
              {strategies.map((strategy) => (
                <Card key={strategy.id} className={cn(
                  "transition-all duration-300 hover:shadow-md",
                  strategy.enabled ? "border-green-200 bg-green-50" : "border-gray-200"
                )}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-10 h-10 rounded-lg flex items-center justify-center",
                          strategy.enabled ? "bg-green-100" : "bg-gray-100"
                        )}>
                          {getStrategyIcon(strategy.type)}
                        </div>
                        <div>
                          <h4 className="font-semibold">{strategy.name}</h4>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className={getRiskColor(strategy.risk)}>
                              {strategy.risk} risk
                            </Badge>
                            <Badge variant="outline">
                              Prioridad {strategy.priority}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={strategy.enabled}
                          onCheckedChange={() => toggleStrategy(strategy.id)}
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedStrategy(strategy.id)}
                        >
                          <Settings size={16} />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Ganancia:</span>
                        <p className="font-semibold text-green-600">{formatCurrency(strategy.profit)}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Win Rate:</span>
                        <p className="font-semibold">{strategy.winRate.toFixed(1)}%</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Estado:</span>
                        <p className={cn("font-semibold", getStatusColor(strategy.status))}>
                          {strategy.status}
                        </p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Operaciones:</span>
                        <p className="font-semibold">{strategy.totalTrades}</p>
                      </div>
                    </div>
                    
                    {strategy.nextExecution && (
                      <div className="mt-3 p-2 bg-blue-50 rounded text-xs text-blue-700">
                        <Clock size={12} className="inline mr-1" />
                        Próxima ejecución: {strategy.nextExecution.toLocaleTimeString()}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Panel de Control Individual */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Control Individual</h3>
              
              {selectedStrategy ? (
                (() => {
                  const strategy = strategies.find(s => s.id === selectedStrategy)!
                  return (
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-center gap-3 mb-4">
                          {getStrategyIcon(strategy.type)}
                          <h4 className="font-semibold">{strategy.name}</h4>
                        </div>
                        
                        <div className="space-y-4">
                          <div>
                            <Label className="text-sm">Nivel de Riesgo</Label>
                            <Slider
                              value={[strategy.riskLevel]}
                              onValueChange={(value) => updateStrategyRisk(strategy.id, value[0])}
                              max={100}
                              step={5}
                              className="mt-2"
                            />
                            <div className="flex justify-between text-xs text-muted-foreground mt-1">
                              <span>Conservador</span>
                              <span>{strategy.riskLevel}%</span>
                              <span>Agresivo</span>
                            </div>
                          </div>
                          
                          <div>
                            <Label className="text-sm">Objetivo de Ganancia</Label>
                            <Slider
                              value={[strategy.profitTarget]}
                              onValueChange={(value) => updateStrategyProfitTarget(strategy.id, value[0])}
                              max={500}
                              step={10}
                              className="mt-2"
                            />
                            <div className="flex justify-between text-xs text-muted-foreground mt-1">
                              <span>$10</span>
                              <span>${strategy.profitTarget}</span>
                              <span>$500</span>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label className="text-sm">Stop Loss</Label>
                              <Input
                                type="number"
                                value={strategy.stopLoss}
                                onChange={(e) => setStrategies(prev => prev.map(s => 
                                  s.id === strategy.id ? { ...s, stopLoss: Number(e.target.value) } : s
                                ))}
                                className="mt-1"
                              />
                            </div>
                            <div>
                              <Label className="text-sm">Tamaño Máximo</Label>
                              <Input
                                type="number"
                                value={strategy.maxTradeSize}
                                onChange={(e) => setStrategies(prev => prev.map(s => 
                                  s.id === strategy.id ? { ...s, maxTradeSize: Number(e.target.value) } : s
                                ))}
                                className="mt-1"
                              />
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={strategy.autoMode}
                              onCheckedChange={(checked) => setStrategies(prev => prev.map(s => 
                                s.id === strategy.id ? { ...s, autoMode: checked } : s
                              ))}
                            />
                            <Label className="text-sm">Modo Automático</Label>
                          </div>
                          
                          <div className="flex gap-2">
                            <Button
                              onClick={() => executeManualTrade(strategy)}
                              disabled={!manualOverride}
                              className="flex-1 gap-2"
                            >
                              <Play size={16} />
                              Ejecutar Manual
                            </Button>
                            <Button
                              variant="outline"
                              onClick={() => setSelectedStrategy(null)}
                              size="sm"
                            >
                              Cerrar
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })()
              ) : (
                <Card className="h-64 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <Settings size={48} className="mx-auto mb-4 opacity-50" />
                    <p>Selecciona una estrategia para configurar</p>
                  </div>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="controls" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Controles Globales */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sliders size={20} />
                  Controles Globales
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Modo Automático Global</span>
                  <Switch
                    checked={systemConfig.globalAutoMode}
                    onCheckedChange={(checked) => setSystemConfig(prev => ({ ...prev, globalAutoMode: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Gestión de Riesgo</span>
                  <Switch
                    checked={systemConfig.riskManagement}
                    onCheckedChange={(checked) => setSystemConfig(prev => ({ ...prev, riskManagement: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Notificaciones</span>
                  <Switch
                    checked={systemConfig.notifications}
                    onCheckedChange={(checked) => setSystemConfig(prev => ({ ...prev, notifications: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Intervención Manual</span>
                  <Switch
                    checked={manualOverride}
                    onCheckedChange={setManualOverride}
                  />
                </div>
                
                <div>
                  <Label className="text-sm">Riesgo Global</Label>
                  <Slider
                    value={[systemConfig.globalRiskLevel]}
                    onValueChange={(value) => setSystemConfig(prev => ({ ...prev, globalRiskLevel: value[0] }))}
                    max={100}
                    step={5}
                    className="mt-2"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>Bajo</span>
                    <span>{systemConfig.globalRiskLevel}%</span>
                    <span>Alto</span>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm">Operaciones Concurrentes Máximas</Label>
                  <Slider
                    value={[systemConfig.maxConcurrentTrades]}
                    onValueChange={(value) => setSystemConfig(prev => ({ ...prev, maxConcurrentTrades: value[0] }))}
                    max={10}
                    step={1}
                    className="mt-2"
                  />
                  <div className="text-center text-xs text-muted-foreground mt-1">
                    {systemConfig.maxConcurrentTrades} operaciones
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Controles de Emergencia */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle size={20} />
                  Controles de Emergencia
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  variant="destructive"
                  onClick={emergencyStop}
                  disabled={systemConfig.emergencyStop}
                  className="w-full gap-2"
                  size="lg"
                >
                  <Stop size={20} />
                  Parada de Emergencia
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => setStrategies(prev => prev.map(s => ({ ...s, status: 'paused' })))}
                  className="w-full gap-2"
                >
                  <Pause size={20} />
                  Pausar Todas las Estrategias
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => setStrategies(prev => prev.map(s => ({ ...s, status: 'active' })))}
                  className="w-full gap-2"
                >
                  <Play size={20} />
                  Reanudar Todas las Estrategias
                </Button>
                
                <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                  <h4 className="font-semibold text-red-800 mb-2">Estado del Sistema</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Parada de Emergencia:</span>
                      <Badge variant={systemConfig.emergencyStop ? "destructive" : "outline"}>
                        {systemConfig.emergencyStop ? "ACTIVA" : "Inactiva"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Estrategias Activas:</span>
                      <span>{activeStrategies}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Modo Manual:</span>
                      <Badge variant={manualOverride ? "default" : "outline"}>
                        {manualOverride ? "Activado" : "Desactivado"}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Métricas en Tiempo Real */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity size={20} />
                  Actividad en Tiempo Real
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Operaciones Activas</span>
                    <Badge variant="outline">{activeStrategies}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Ganancia por Hora</span>
                    <span className="font-semibold text-green-600">+$125.50</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Latencia Promedio</span>
                    <span className="font-semibold">45ms</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Uso de CPU</span>
                    <span className="font-semibold">23%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Gráfico de Rendimiento */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp size={20} />
                  Rendimiento
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(totalProfit)}</p>
                    <p className="text-sm text-muted-foreground">Ganancia Total</p>
                  </div>
                  <Progress value={overallWinRate} className="h-2" />
                  <p className="text-center text-sm text-muted-foreground">
                    Tasa de Éxito: {overallWinRate.toFixed(1)}%
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Estado de la Red */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network size={20} />
                  Estado de la Red
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Ethereum Mainnet</span>
                    <Badge className="bg-green-100 text-green-800">
                      <Wifi size={12} className="mr-1" />
                      Conectado
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Polygon</span>
                    <Badge className="bg-green-100 text-green-800">
                      <Wifi size={12} className="mr-1" />
                      Conectado
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">BSC</span>
                    <Badge className="bg-yellow-100 text-yellow-800">
                      <WifiMedium size={12} className="mr-1" />
                      Lento
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Arbitrum</span>
                    <Badge className="bg-green-100 text-green-800">
                      <Wifi size={12} className="mr-1" />
                      Conectado
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Configuración General */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings size={20} />
                  Configuración General
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm">Horario de Mercado</Label>
                  <div className="flex items-center gap-2 mt-2">
                    <Switch
                      checked={systemConfig.marketHours.enabled}
                      onCheckedChange={(checked) => setSystemConfig(prev => ({
                        ...prev,
                        marketHours: { ...prev.marketHours, enabled: checked }
                      }))}
                    />
                    <span className="text-sm">Activar horario de mercado</span>
                  </div>
                  {systemConfig.marketHours.enabled && (
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <Input
                        type="time"
                        value={systemConfig.marketHours.start}
                        onChange={(e) => setSystemConfig(prev => ({
                          ...prev,
                          marketHours: { ...prev.marketHours, start: e.target.value }
                        }))}
                      />
                      <Input
                        type="time"
                        value={systemConfig.marketHours.end}
                        onChange={(e) => setSystemConfig(prev => ({
                          ...prev,
                          marketHours: { ...prev.marketHours, end: e.target.value }
                        }))}
                      />
                    </div>
                  )}
                </div>
                
                <div>
                  <Label className="text-sm">Mantenimiento Automático</Label>
                  <div className="flex items-center gap-2 mt-2">
                    <Switch
                      checked={systemConfig.maintenance.enabled}
                      onCheckedChange={(checked) => setSystemConfig(prev => ({
                        ...prev,
                        maintenance: { ...prev.maintenance, enabled: checked }
                      }))}
                    />
                    <span className="text-sm">Activar mantenimiento automático</span>
                  </div>
                  {systemConfig.maintenance.enabled && (
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <Input
                        type="time"
                        value={systemConfig.maintenance.schedule}
                        onChange={(e) => setSystemConfig(prev => ({
                          ...prev,
                          maintenance: { ...prev.maintenance, schedule: e.target.value }
                        }))}
                      />
                      <Input
                        type="number"
                        placeholder="Duración (min)"
                        value={systemConfig.maintenance.duration}
                        onChange={(e) => setSystemConfig(prev => ({
                          ...prev,
                          maintenance: { ...prev.maintenance, duration: Number(e.target.value) }
                        }))}
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Configuración de Notificaciones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell size={20} />
                  Notificaciones
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Notificaciones Push</span>
                  <Switch
                    checked={systemConfig.notifications}
                    onCheckedChange={(checked) => setSystemConfig(prev => ({ ...prev, notifications: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Alertas de Emergencia</span>
                  <Switch defaultChecked />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Reportes Diarios</span>
                  <Switch defaultChecked />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Notificaciones de Ganancia</span>
                  <Switch defaultChecked />
                </div>
                
                <div className="flex items-center justify-between">
                  <span>Alertas de Riesgo</span>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 