// components/panels/MOADPanel.tsx
/**
 * MÓDULO DE OPORTUNIDADES DE ARBITRAJE DeFi (MOAD)
 * Panel principal para detección y ejecución de estrategias de arbitraje
 * DATOS 100% REALES - SIN SIMULACIONES
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Separator } from '../ui/separator';
import { 
  Play, 
  Pause, 
  TrendUp, 
  TrendDown, 
  WarningCircle, 
  CheckCircle, 
  XCircle,
  Lightning,
  Target,
  CurrencyDollar,
  Activity,
  ChartBar3,
  Gear,
  Shield,
  Brain,
  Stack,
  Globe,
  Timer,
  Wallet,
  Repeat,
  Network,
  Database
} from 'lucide-react';
import { useKV } from '@/hooks/useKV';
import { realDataService, RealOpportunity, BlockchainConnection, DEXData } from '../../services/RealDataService';
import { realStrategyService, StrategyExecution, StrategyDefinition } from '../../services/RealStrategyService';

interface MOADPanelProps {
  environment: 'test' | 'prod';
}

// Estados para el sistema MOAD con datos REALES
interface MOADSystemStatus {
  isInitialized: boolean;
  isScanning: boolean;
  totalOpportunitiesDetected: number;
  activeExecutions: number;
  dailyProfit: number;
  successfulTrades: number;
  failedTrades: number;
  averageROI: number;
  systemHealth: {
    totalBlockchains: number;
    connectedBlockchains: number;
    totalDEXs: number;
    operationalDEXs: number;
    averageLatency: number;
  };
}

export const MOADPanel: React.FC<MOADPanelProps> = ({ environment }) => {
  // Estados principales del sistema REAL
  const [activeStrategy, setActiveStrategy] = useKV<string>('moad-active-strategy', 'basic-cross-dex');
  const [autoMode, setAutoMode] = useKV<boolean>('moad-auto-mode', false);
  const [capitalAllocation, setCapitalAllocation] = useKV<number>('moad-capital', 10000);
  const [riskTolerance, setRiskTolerance] = useKV<number>('moad-risk-tolerance', 5);
  
  // Estados de datos REALES
  const [systemStatus, setSystemStatus] = useState<MOADSystemStatus>({
    isInitialized: false,
    isScanning: false,
    totalOpportunitiesDetected: 0,
    activeExecutions: 0,
    dailyProfit: 0,
    successfulTrades: 0,
    failedTrades: 0,
    averageROI: 0,
    systemHealth: {
      totalBlockchains: 0,
      connectedBlockchains: 0,
      totalDEXs: 0,
      operationalDEXs: 0,
      averageLatency: 0
    }
  });
  
  const [realOpportunities, setRealOpportunities] = useState<RealOpportunity[]>([]);
  const [availableStrategies, setAvailableStrategies] = useState<StrategyDefinition[]>([]);
  const [activeExecutions, setActiveExecutions] = useState<StrategyExecution[]>([]);
  const [completedExecutions, setCompletedExecutions] = useState<StrategyExecution[]>([]);
  const [blockchainConnections, setBlockchainConnections] = useState<BlockchainConnection[]>([]);
  const [supportedDEXs, setSupportedDEXs] = useState<DEXData[]>([]);
  
  const [isExecuting, setIsExecuting] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [lastScanTime, setLastScanTime] = useState<Date | null>(null);

  // Inicializar servicios REALES
  const initializeRealServices = useCallback(async () => {
    if (systemStatus.isInitialized) return;
    
    setIsInitializing(true);
    try {
      console.log('🚀 Inicializando servicios REALES de MOAD...');
      
      // Inicializar servicio de datos reales
      await realDataService.initialize();
      
      // Inicializar servicio de estrategias reales
      await realStrategyService.initialize();
      
      // Obtener datos del sistema
      const systemHealth = realDataService.getSystemHealth();
      const strategies = realStrategyService.getAllStrategies();
      const connections = realDataService.getBlockchainConnections();
      const dexs = realDataService.getSupportedDEXs();
      
      setSystemStatus(prev => ({
        ...prev,
        isInitialized: true,
        systemHealth
      }));
      
      setAvailableStrategies(strategies);
      setBlockchainConnections(connections);
      setSupportedDEXs(dexs);
      
      console.log('✅ MOAD inicializado correctamente');
      console.log(`📊 Sistema: ${systemHealth.connectedBlockchains}/${systemHealth.totalBlockchains} blockchains, ${systemHealth.operationalDEXs}/${systemHealth.totalDEXs} DEXs`);
      
    } catch (error) {
      console.error('❌ Error inicializando MOAD:', error);
    } finally {
      setIsInitializing(false);
    }
  }, [systemStatus.isInitialized]);

  // Escanear oportunidades REALES
  const scanRealOpportunities = useCallback(async () => {
    if (!systemStatus.isInitialized || systemStatus.isScanning) return;
    
    setSystemStatus(prev => ({ ...prev, isScanning: true }));
    try {
      console.log('🔍 Escaneando oportunidades REALES...');
      
      const opportunities = await realDataService.scanForRealOpportunities();
      setRealOpportunities(opportunities);
      setLastScanTime(new Date());
      
      setSystemStatus(prev => ({
        ...prev,
        totalOpportunitiesDetected: opportunities.length,
        isScanning: false
      }));
      
      console.log(`✅ Encontradas ${opportunities.length} oportunidades reales`);
      
    } catch (error) {
      console.error('❌ Error escaneando oportunidades:', error);
      setSystemStatus(prev => ({ ...prev, isScanning: false }));
    }
  }, [systemStatus.isInitialized, systemStatus.isScanning]);

  // Ejecutar estrategia REAL
  const executeRealStrategy = useCallback(async (
    strategyId: string, 
    opportunity?: RealOpportunity,
    dryRun: boolean = environment === 'test'
  ) => {
    if (!systemStatus.isInitialized) {
      console.error('❌ Sistema no inicializado');
      return;
    }

    setIsExecuting(true);
    try {
      // Si no se proporciona oportunidad, buscar la mejor disponible
      let targetOpportunity = opportunity;
      if (!targetOpportunity) {
        const availableOpps = realOpportunities.filter(opp => 
          availableStrategies.find(s => s.id === strategyId)?.name === opp.strategyType
        );
        
        if (availableOpps.length === 0) {
          throw new Error(`No hay oportunidades disponibles para estrategia ${strategyId}`);
        }
        
        // Tomar la más rentable
        targetOpportunity = availableOpps.sort((a, b) => b.potentialProfitUSD - a.potentialProfitUSD)[0];
      }

      console.log(`🎯 Ejecutando estrategia ${strategyId} ${dryRun ? '(DRY RUN)' : '(REAL)'}`);
      
      const execution = await realStrategyService.executeStrategy(strategyId, targetOpportunity, {
        dryRun,
        mevProtection: true,
        maxSlippagePercent: 2.0
      });

      // Actualizar estado según resultado
      if (execution.status === 'completed') {
        setSystemStatus(prev => ({
          ...prev,
          successfulTrades: prev.successfulTrades + 1,
          dailyProfit: prev.dailyProfit + execution.actualProfitUSD,
          averageROI: prev.averageROI > 0 ? 
            (prev.averageROI + (execution.actualProfitUSD / capitalAllocation * 100)) / 2 :
            (execution.actualProfitUSD / capitalAllocation * 100)
        }));
      } else if (execution.status === 'failed') {
        setSystemStatus(prev => ({
          ...prev,
          failedTrades: prev.failedTrades + 1
        }));
      }

      // Actualizar listas de ejecuciones
      setActiveExecutions(realStrategyService.getActiveExecutions());
      setCompletedExecutions(realStrategyService.getCompletedExecutions());
      
      console.log(`✅ Ejecución completada: ${execution.status}`);
      
    } catch (error) {
      console.error('❌ Error ejecutando estrategia:', error);
    } finally {
      setIsExecuting(false);
    }
  }, [systemStatus.isInitialized, realOpportunities, availableStrategies, capitalAllocation, environment]);

  // Activar modo automático
  const toggleAutoMode = useCallback(async () => {
    if (!systemStatus.isInitialized) {
      console.error('❌ Sistema no inicializado');
      return;
    }

    setAutoMode(!autoMode);
    
    if (!autoMode) {
      console.log('🤖 Activando modo automático - AI Agent operativo');
      // En modo automático, escanear cada 30 segundos
      const autoInterval = setInterval(async () => {
        if (autoMode && systemStatus.isInitialized) {
          await scanRealOpportunities();
          
          // Si hay oportunidades rentables, ejecutar automáticamente
          const profitableOpps = realOpportunities.filter(opp => 
            opp.potentialProfitUSD > 100 && // Mínimo $100 profit
            opp.riskFactors.slippageRisk < riskTolerance &&
            opp.riskFactors.liquidityRisk < riskTolerance
          );
          
          if (profitableOpps.length > 0 && !isExecuting) {
            const bestOpp = profitableOpps[0];
            const strategy = availableStrategies.find(s => s.name === bestOpp.strategyType);
            if (strategy) {
              await executeRealStrategy(strategy.id, bestOpp, environment === 'test');
            }
          }
        }
      }, 30000); // 30 segundos
      
      // Limpiar interval cuando se desactive
      return () => clearInterval(autoInterval);
    } else {
      console.log('⏸️ Modo automático desactivado');
    }
  }, [autoMode, setAutoMode, systemStatus.isInitialized, realOpportunities, riskTolerance, isExecuting, availableStrategies, environment, executeRealStrategy, scanRealOpportunities]);

  // Efectos de inicialización
  useEffect(() => {
    initializeRealServices();
  }, [initializeRealServices]);

  // Escaneo automático cada 10 segundos en modo manual
  useEffect(() => {
    if (!systemStatus.isInitialized || autoMode) return;

    const scanInterval = setInterval(() => {
      scanRealOpportunities();
    }, 10000); // 10 segundos

    return () => clearInterval(scanInterval);
  }, [systemStatus.isInitialized, autoMode, scanRealOpportunities]);

  // Actualizar ejecuciones activas cada 5 segundos
  useEffect(() => {
    if (!systemStatus.isInitialized) return;

    const updateInterval = setInterval(() => {
      setActiveExecutions(realStrategyService.getActiveExecutions());
      setCompletedExecutions(realStrategyService.getCompletedExecutions());
      
      setSystemStatus(prev => ({
        ...prev,
        activeExecutions: realStrategyService.getActiveExecutions().length
      }));
    }, 5000);

    return () => clearInterval(updateInterval);
  }, [systemStatus.isInitialized]);

  // Renderizar estado de oportunidad REAL
  const renderOpportunityStatus = (opportunity: RealOpportunity) => {
    const profitPercent = (opportunity.potentialProfitUSD / capitalAllocation) * 100;
    const avgRisk = (opportunity.riskFactors.slippageRisk + opportunity.riskFactors.liquidityRisk + opportunity.riskFactors.mevRisk) / 3;
    
    if (profitPercent > 5) return <Badge className="bg-profit text-white">Excelente</Badge>;
    if (profitPercent > 2) return <Badge className="bg-green-500 text-white">Buena</Badge>;
    if (profitPercent > 1) return <Badge className="bg-yellow-500 text-white">Media</Badge>;
    return <Badge className="bg-gray-500 text-white">Baja</Badge>;
  };

  // Renderizar estado de conexión blockchain
  const renderBlockchainStatus = (connection: BlockchainConnection) => {
    if (connection.isConnected) {
      return (
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-500 rounded-full" />
          <span className="text-sm">Conectado</span>
          <Badge variant="outline">{connection.latency}ms</Badge>
        </div>
      );
    } else {
      return (
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-red-500 rounded-full" />
          <span className="text-sm">Desconectado</span>
        </div>
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header del Panel MOAD */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-primary/10 rounded-lg">
            <Target className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">MOAD - Sistema Real de Arbitraje DeFi</h1>
            <p className="text-muted-foreground">
              Detección y ejecución de oportunidades REALES multi-blockchain
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <Badge variant={environment === 'prod' ? 'destructive' : 'secondary'}>
            {environment === 'prod' ? 'PRODUCCIÓN' : 'TESTING'}
          </Badge>
          
          {systemStatus.isInitialized ? (
            <Badge className="bg-green-500 text-white">
              <CheckCircle className="h-3 w-3 mr-1" />
              Sistema Operativo
            </Badge>
          ) : (
            <Badge className="bg-yellow-500 text-white">
              <Repeat className="h-3 w-3 mr-1 animate-spin" />
              {isInitializing ? 'Inicializando...' : 'Inicializar'}
            </Badge>
          )}
          
          <Button 
            onClick={scanRealOpportunities}
            disabled={systemStatus.isScanning || !systemStatus.isInitialized}
            className="bg-blue-500 hover:bg-blue-600 text-white"
          >
            {systemStatus.isScanning ? (
              <>
                <Repeat className="h-4 w-4 mr-2 animate-spin" />
                Escaneando...
              </>
            ) : (
              <>
                <Lightning className="h-4 w-4 mr-2" />
                Escanear Oportunidades
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Métricas del Sistema REAL */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <CurrencyDollar className="h-8 w-8 text-profit" />
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">Profit Diario Real</p>
                <p className="text-2xl font-bold">${systemStatus.dailyProfit.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <TrendUp className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">Trades Exitosos</p>
                <p className="text-2xl font-bold">{systemStatus.successfulTrades}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Activity className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">Oportunidades Reales</p>
                <p className="text-2xl font-bold">{realOpportunities.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Network className="h-8 w-8 text-purple-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">Blockchains Activas</p>
                <p className="text-2xl font-bold">
                  {systemStatus.systemHealth.connectedBlockchains}/{systemStatus.systemHealth.totalBlockchains}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Estado del Sistema */}
      {systemStatus.isInitialized && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="h-5 w-5 text-green-500" />
              <span>Estado del Sistema en Tiempo Real</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">DEXs Operacionales</span>
                  <span className="text-sm font-medium">
                    {systemStatus.systemHealth.operationalDEXs}/{systemStatus.systemHealth.totalDEXs}
                  </span>
                </div>
                <Progress 
                  value={(systemStatus.systemHealth.operationalDEXs / systemStatus.systemHealth.totalDEXs) * 100} 
                  className="h-2" 
                />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Latencia Promedio</span>
                  <span className="text-sm font-medium">{systemStatus.systemHealth.averageLatency}ms</span>
                </div>
                <Progress 
                  value={Math.max(0, 100 - (systemStatus.systemHealth.averageLatency / 10))} 
                  className="h-2" 
                />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Ejecuciones Activas</span>
                  <span className="text-sm font-medium">{systemStatus.activeExecutions}</span>
                </div>
                <Progress value={Math.min(systemStatus.activeExecutions * 20, 100)} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Última Actualización</span>
                  <span className="text-sm font-medium">
                    {lastScanTime ? `${Math.floor((Date.now() - lastScanTime.getTime()) / 1000)}s` : 'N/A'}
                  </span>
                </div>
                <Progress value={lastScanTime ? Math.max(0, 100 - ((Date.now() - lastScanTime.getTime()) / 300)) : 0} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Controles Principales */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Gear className="h-5 w-5" />
            <span>Control de Ejecución REAL</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Modo de Operación */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Modo de Operación</Label>
              <div className="flex items-center space-x-2">
                <Switch 
                  checked={autoMode}
                  onCheckedChange={toggleAutoMode}
                  disabled={!systemStatus.isInitialized}
                />
                <span className="text-sm">
                  {autoMode ? 'Automático (AI Agent)' : 'Manual'}
                </span>
                {autoMode && (
                  <Badge className="bg-green-500 text-white">
                    <Brain className="h-3 w-3 mr-1" />
                    AI Activo
                  </Badge>
                )}
              </div>
            </div>

            {/* Capital Asignado */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Capital para Trading</Label>
              <div className="flex items-center space-x-2">
                <Input
                  type="number"
                  value={capitalAllocation}
                  onChange={(e) => setCapitalAllocation(Number(e.target.value))}
                  className="flex-1"
                  min="1000"
                  max="1000000"
                />
                <span className="text-sm text-muted-foreground">USD</span>
              </div>
            </div>

            {/* Tolerancia al Riesgo */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Tolerancia al Riesgo</Label>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs">Conservador</span>
                  <span className="text-xs">Agresivo</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={riskTolerance}
                  onChange={(e) => setRiskTolerance(Number(e.target.value))}
                  className="w-full"
                />
                <div className="text-center">
                  <Badge variant="outline">{riskTolerance}/10</Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Estrategia Activa */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Estrategia Principal</Label>
            <Select value={activeStrategy} onValueChange={setActiveStrategy}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableStrategies.map((strategy) => (
                  <SelectItem key={strategy.id} value={strategy.id}>
                    <div className="flex items-center justify-between w-full">
                      <span>{strategy.name}</span>
                      <Badge className="ml-2 bg-profit text-white">
                        {strategy.expectedROI}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabs de Contenido */}
      <Tabs defaultValue="opportunities" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="opportunities">Oportunidades Reales</TabsTrigger>
          <TabsTrigger value="strategies">Estrategias</TabsTrigger>
          <TabsTrigger value="executions">Ejecuciones</TabsTrigger>
          <TabsTrigger value="system">Sistema</TabsTrigger>
        </TabsList>

        {/* Panel de Oportunidades REALES */}
        <TabsContent value="opportunities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Lightning className="h-5 w-5 text-yellow-500" />
                  <span>Oportunidades en Tiempo Real</span>
                </div>
                <div className="flex space-x-2">
                  <Badge className={realOpportunities.length > 0 ? "bg-green-500 text-white" : "bg-gray-500 text-white"}>
                    {realOpportunities.length} detectadas
                  </Badge>
                  {lastScanTime && (
                    <Badge variant="outline">
                      Última actualización: {lastScanTime.toLocaleTimeString()}
                    </Badge>
                  )}
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {realOpportunities.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Token Pair</TableHead>
                        <TableHead>Blockchain</TableHead>
                        <TableHead>DEX Source → Target</TableHead>
                        <TableHead>Profit Estimado</TableHead>
                        <TableHead>Riesgo</TableHead>
                        <TableHead>Liquidez</TableHead>
                        <TableHead>Gas Cost</TableHead>
                        <TableHead>Estado</TableHead>
                        <TableHead>Acción</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {realOpportunities.slice(0, 10).map((opportunity) => (
                        <TableRow key={opportunity.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">
                                Token A → Token B
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {opportunity.strategyType}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{opportunity.blockchain}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              DEX A → DEX B
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="font-medium text-profit">
                                +${opportunity.potentialProfitUSD.toFixed(2)}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {((opportunity.potentialProfitUSD / capitalAllocation) * 100).toFixed(2)}%
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-1">
                              <div className={`w-2 h-2 rounded-full ${
                                opportunity.riskFactors.slippageRisk < 3 ? 'bg-green-500' :
                                opportunity.riskFactors.slippageRisk < 7 ? 'bg-yellow-500' : 'bg-red-500'
                              }`} />
                              <span className="text-sm">
                                {opportunity.riskFactors.slippageRisk.toFixed(1)}/10
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              ${Math.min(
                                opportunity.realLiquidity.sourceDexLiquidity,
                                opportunity.realLiquidity.targetDexLiquidity
                              ).toLocaleString()}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              ${opportunity.gasEstimate.totalCostUSD.toFixed(2)}
                            </div>
                          </TableCell>
                          <TableCell>
                            {renderOpportunityStatus(opportunity)}
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              onClick={() => {
                                const strategy = availableStrategies.find(s => s.name === opportunity.strategyType);
                                if (strategy) {
                                  executeRealStrategy(strategy.id, opportunity, environment === 'test');
                                }
                              }}
                              disabled={isExecuting || !systemStatus.isInitialized}
                              className="bg-profit hover:bg-profit/90 text-white"
                            >
                              {isExecuting ? 'Ejecutando...' : 'Ejecutar'}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Lightning className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No hay oportunidades detectadas</h3>
                  <p className="text-muted-foreground mb-4">
                    {systemStatus.isInitialized ? 
                      'El sistema está escaneando las blockchains conectadas...' :
                      'Inicialice el sistema para comenzar el escaneo'
                    }
                  </p>
                  {systemStatus.isInitialized && (
                    <Button onClick={scanRealOpportunities} disabled={systemStatus.isScanning}>
                      {systemStatus.isScanning ? 'Escaneando...' : 'Escanear Ahora'}
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Panel de Estrategias REALES */}
        <TabsContent value="strategies" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableStrategies.map((strategy) => {
              const stats = realStrategyService.getStrategyStats(strategy.id);
              return (
                <Card key={strategy.id} className={strategy.id === activeStrategy ? 'ring-2 ring-primary' : ''}>
                  <CardHeader>
                    <CardTitle className="text-lg">{strategy.name}</CardTitle>
                    <div className="flex items-center space-x-2">
                      <Badge className="bg-profit text-white">{strategy.expectedROI}</Badge>
                      <Badge variant="outline">{strategy.complexity}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Riesgo:</span>
                        <div className="flex items-center space-x-1">
                          <Progress value={strategy.riskLevel * 10} className="h-2" />
                          <span>{strategy.riskLevel}/10</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Tiempo:</span>
                        <div className="font-medium">{strategy.executionTime.min}-{strategy.executionTime.max}s</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Capital min:</span>
                        <div className="font-medium">${strategy.requiredCapital.min.toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Éxito:</span>
                        <div className="font-medium">{stats.successRate.toFixed(1)}%</div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-2">
                      <div>
                        <span className="text-sm text-muted-foreground">Blockchains:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {strategy.supportedBlockchains.slice(0, 3).map((chain) => (
                            <Badge key={chain} variant="outline" className="text-xs">
                              {chain}
                            </Badge>
                          ))}
                          {strategy.supportedBlockchains.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{strategy.supportedBlockchains.length - 3} más
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      {stats.totalExecutions > 0 && (
                        <div>
                          <span className="text-sm text-muted-foreground">Profit Promedio:</span>
                          <div className="font-medium text-profit">
                            ${stats.averageProfitUSD.toFixed(2)}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant={strategy.id === activeStrategy ? 'default' : 'outline'}
                        onClick={() => setActiveStrategy(strategy.id)}
                        className="flex-1"
                      >
                        {strategy.id === activeStrategy ? 'Activa' : 'Activar'}
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => executeRealStrategy(strategy.id, undefined, environment === 'test')}
                        disabled={isExecuting || !systemStatus.isInitialized}
                        className="bg-profit hover:bg-profit/90 text-white"
                      >
                        Ejecutar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Panel de Ejecuciones */}
        <TabsContent value="executions" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Ejecuciones Activas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-blue-500" />
                  <span>Ejecuciones Activas</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {activeExecutions.length > 0 ? (
                  <div className="space-y-3">
                    {activeExecutions.map((execution) => (
                      <div key={execution.id} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{execution.strategyType}</span>
                          <Badge className="bg-blue-500 text-white">{execution.status}</Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <div>Iniciada: {execution.startTime.toLocaleTimeString()}</div>
                          <div>Profit estimado: ${execution.opportunity.potentialProfitUSD.toFixed(2)}</div>
                          {execution.mevProtected && (
                            <div className="flex items-center space-x-1 text-green-600">
                              <Shield className="h-3 w-3" />
                              <span>MEV Protegido</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <Activity className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No hay ejecuciones activas</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Ejecuciones Completadas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>Ejecuciones Recientes</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {completedExecutions.length > 0 ? (
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {completedExecutions.slice(0, 5).map((execution) => (
                      <div key={execution.id} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{execution.strategyType}</span>
                          <Badge className={
                            execution.status === 'completed' ? 'bg-green-500 text-white' :
                            execution.status === 'failed' ? 'bg-red-500 text-white' :
                            'bg-gray-500 text-white'
                          }>
                            {execution.status}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <div>Duración: {execution.executionTimeMs}ms</div>
                          {execution.status === 'completed' && (
                            <>
                              <div className="text-profit">
                                Profit real: ${execution.actualProfitUSD.toFixed(2)}
                              </div>
                              <div>Gas: ${execution.actualGasCostUSD.toFixed(2)}</div>
                            </>
                          )}
                          {execution.status === 'failed' && execution.errorMessage && (
                            <div className="text-red-500">
                              Error: {execution.errorMessage}
                            </div>
                          )}
                          {execution.transactionHashes.length > 0 && (
                            <div className="font-mono text-xs">
                              TX: {execution.transactionHashes[0].substring(0, 10)}...
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <CheckCircle className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No hay ejecuciones recientes</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Panel de Estado del Sistema */}
        <TabsContent value="system" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Estado de Blockchains */}
            <Card>
              <CardHeader>
                <CardTitle>Estado de Blockchains</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {blockchainConnections.map((connection) => (
                  <div key={connection.name} className="flex items-center justify-between">
                    <div>
                      <span className="font-medium capitalize">{connection.name}</span>
                      <div className="text-sm text-muted-foreground">
                        Chain ID: {connection.chainId}
                      </div>
                    </div>
                    {renderBlockchainStatus(connection)}
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Estado de DEXs */}
            <Card>
              <CardHeader>
                <CardTitle>Estado de DEXs</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {supportedDEXs.map((dex) => (
                  <div key={`${dex.name}-${dex.blockchain}`} className="flex items-center justify-between">
                    <div>
                      <span className="font-medium">{dex.name}</span>
                      <div className="text-sm text-muted-foreground capitalize">
                        {dex.blockchain}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${dex.isOperational ? 'bg-green-500' : 'bg-red-500'}`} />
                      <span className="text-sm">{dex.isOperational ? 'Operativo' : 'No Operativo'}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Métricas de Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Métricas de Performance</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Latencia Promedio</span>
                    <span className="text-sm font-medium">{systemStatus.systemHealth.averageLatency}ms</span>
                  </div>
                  <Progress value={Math.max(0, 100 - (systemStatus.systemHealth.averageLatency / 10))} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Tasa de Éxito</span>
                    <span className="text-sm font-medium">
                      {systemStatus.successfulTrades + systemStatus.failedTrades > 0 ? 
                        ((systemStatus.successfulTrades / (systemStatus.successfulTrades + systemStatus.failedTrades)) * 100).toFixed(1) :
                        0
                      }%
                    </span>
                  </div>
                  <Progress 
                    value={systemStatus.successfulTrades + systemStatus.failedTrades > 0 ? 
                      (systemStatus.successfulTrades / (systemStatus.successfulTrades + systemStatus.failedTrades)) * 100 : 0
                    } 
                    className="h-2" 
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Cobertura Blockchains</span>
                    <span className="text-sm font-medium">
                      {systemStatus.systemHealth.connectedBlockchains}/{systemStatus.systemHealth.totalBlockchains}
                    </span>
                  </div>
                  <Progress 
                    value={(systemStatus.systemHealth.connectedBlockchains / systemStatus.systemHealth.totalBlockchains) * 100} 
                    className="h-2" 
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">DEXs Operacionales</span>
                    <span className="text-sm font-medium">
                      {systemStatus.systemHealth.operationalDEXs}/{systemStatus.systemHealth.totalDEXs}
                    </span>
                  </div>
                  <Progress 
                    value={(systemStatus.systemHealth.operationalDEXs / systemStatus.systemHealth.totalDEXs) * 100} 
                    className="h-2" 
                  />
                </div>
              </CardContent>
            </Card>

            {/* Logs del Sistema */}
            <Card>
              <CardHeader>
                <CardTitle>Actividad Reciente</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {lastScanTime && (
                    <div className="flex items-center space-x-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-muted-foreground">{lastScanTime.toLocaleTimeString()}</span>
                      <span>Escaneo completado: {realOpportunities.length} oportunidades</span>
                    </div>
                  )}
                  
                  {systemStatus.isInitialized && (
                    <div className="flex items-center space-x-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-muted-foreground">Sistema</span>
                      <span>Servicios REALES inicializados correctamente</span>
                    </div>
                  )}
                  
                  {autoMode && (
                    <div className="flex items-center space-x-2 text-sm">
                      <Brain className="h-4 w-4 text-blue-500" />
                      <span className="text-muted-foreground">AI Agent</span>
                      <span>Modo automático activo - escaneando oportunidades</span>
                    </div>
                  )}
                  
                  {completedExecutions.length > 0 && completedExecutions[0].status === 'completed' && (
                    <div className="flex items-center space-x-2 text-sm">
                      <CurrencyDollar className="h-4 w-4 text-profit" />
                      <span className="text-muted-foreground">{completedExecutions[0].endTime?.toLocaleTimeString()}</span>
                      <span>Trade ejecutado - Ganancia: ${completedExecutions[0].actualProfitUSD.toFixed(2)}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center space-x-2 text-sm">
                    <Network className="h-4 w-4 text-blue-500" />
                    <span className="text-muted-foreground">Red</span>
                    <span>
                      {systemStatus.systemHealth.connectedBlockchains} blockchains, 
                      {systemStatus.systemHealth.operationalDEXs} DEXs operativos
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MOADPanel;