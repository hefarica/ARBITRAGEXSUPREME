import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  TrendingUp, 
  Zap, 
  Shield, 
  Brain, 
  Activity, 
  Target,
  Rocket,
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  BarChart3
} from 'lucide-react'
import { advancedArbitrageEngine2025, AdvancedStrategy, FlashLoanOpportunity, CrossChainArbitrage, MEVProtection } from '../../core/AdvancedArbitrageEngine2025'

interface StrategyStatus {
  id: string
  isActive: boolean
  lastExecution: Date | null
  successRate: number
  totalProfit: number
  riskLevel: 'low' | 'medium' | 'high'
}

export const AdvancedStrategiesPanel2025: React.FC = () => {
  const [strategies, setStrategies] = useState<AdvancedStrategy[]>([])
  const [flashLoanOpportunities, setFlashLoanOpportunities] = useState<FlashLoanOpportunity[]>([])
  const [crossChainOpportunities, setCrossChainOpportunities] = useState<CrossChainArbitrage[]>([])
  const [mevProtection, setMevProtection] = useState<MEVProtection | null>(null)
  const [systemStatus, setSystemStatus] = useState<{ isRunning: boolean; activeStrategies: number; totalProfit: number }>({
    isRunning: false,
    activeStrategies: 0,
    totalProfit: 0
  })
  const [strategyStatuses, setStrategyStatuses] = useState<Map<string, StrategyStatus>>(new Map())

  useEffect(() => {
    loadStrategies()
    const interval = setInterval(updateData, 5000) // Actualizar cada 5 segundos
    return () => clearInterval(interval)
  }, [])

  const loadStrategies = () => {
    const strategiesList = advancedArbitrageEngine2025.getStrategies()
    setStrategies(strategiesList)
    
    // Inicializar estados de estrategias
    const statuses = new Map<string, StrategyStatus>()
    strategiesList.forEach(strategy => {
      statuses.set(strategy.id, {
        id: strategy.id,
        isActive: strategy.isActive,
        lastExecution: null,
        successRate: Math.random() * 100,
        totalProfit: Math.random() * 1000,
        riskLevel: strategy.riskLevel
      })
    })
    setStrategyStatuses(statuses)
  }

  const updateData = () => {
    setFlashLoanOpportunities(advancedArbitrageEngine2025.getFlashLoanOpportunities())
    setCrossChainOpportunities(advancedArbitrageEngine2025.getCrossChainOpportunities())
    setMevProtection(advancedArbitrageEngine2025.getMEVProtection())
    setSystemStatus(advancedArbitrageEngine2025.getSystemStatus())
  }

  const toggleStrategy = async (strategyId: string) => {
    const strategy = strategies.find(s => s.id === strategyId)
    if (strategy) {
      // Aquí implementarías la lógica real para activar/desactivar estrategias
      console.log(`Toggle strategy: ${strategyId}`)
      
      // Actualizar estado local
      const newStatuses = new Map(strategyStatuses)
      const currentStatus = newStatuses.get(strategyId)
      if (currentStatus) {
        currentStatus.isActive = !currentStatus.isActive
        newStatuses.set(strategyId, currentStatus)
        setStrategyStatuses(newStatuses)
      }
    }
  }

  const startEngine = async () => {
    try {
      await advancedArbitrageEngine2025.startEngine()
      setSystemStatus(prev => ({ ...prev, isRunning: true }))
    } catch (error) {
      console.error('Error starting engine:', error)
    }
  }

  const stopEngine = async () => {
    try {
      await advancedArbitrageEngine2025.stopEngine()
      setSystemStatus(prev => ({ ...prev, isRunning: false }))
    } catch (error) {
      console.error('Error stopping engine:', error)
    }
  }

  const getStrategyIcon = (category: string) => {
    switch (category) {
      case 'prediction': return <Target className="h-4 w-4" />
      case 'flashloan': return <Zap className="h-4 w-4" />
      case 'crosschain': return <Activity className="h-4 w-4" />
      case 'mev': return <Shield className="h-4 w-4" />
      case 'ml': return <Brain className="h-4 w-4" />
      case 'risk': return <AlertTriangle className="h-4 w-4" />
      default: return <TrendingUp className="h-4 w-4" />
    }
  }

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'low': return 'bg-green-100 text-green-800'
      case 'medium': return 'bg-yellow-100 text-yellow-800'
      case 'high': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getAutomationColor = (level: string) => {
    switch (level) {
      case 'manual': return 'bg-blue-100 text-blue-800'
      case 'semi-auto': return 'bg-orange-100 text-orange-800'
      case 'full-auto': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header con estado del sistema */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Rocket className="h-6 w-6" />
            Advanced Strategies Panel 2025
          </CardTitle>
          <CardDescription>
            Panel de control para las 11 estrategias especializadas de arbitraje DeFi
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-blue-600">Estado del Motor</p>
                <p className="text-2xl font-bold text-blue-900">
                  {systemStatus.isRunning ? '🟢 Activo' : '🔴 Inactivo'}
                </p>
              </div>
              <Activity className="h-8 w-8 text-blue-600" />
            </div>
            
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-green-600">Estrategias Activas</p>
                <p className="text-2xl font-bold text-green-900">{systemStatus.activeStrategies}/11</p>
              </div>
              <Target className="h-8 w-8 text-green-600" />
            </div>
            
            <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-purple-600">Ganancia Total</p>
                <p className="text-2xl font-bold text-purple-900">${systemStatus.totalProfit.toFixed(2)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600" />
            </div>
            
            <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-orange-600">Oportunidades</p>
                <p className="text-2xl font-bold text-orange-900">
                  {flashLoanOpportunities.length + crossChainOpportunities.length}
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-orange-600" />
            </div>
          </div>
          
          <div className="flex gap-2 mt-4">
            <Button 
              onClick={startEngine} 
              disabled={systemStatus.isRunning}
              className="bg-green-600 hover:bg-green-700"
            >
              <Rocket className="h-4 w-4 mr-2" />
              Iniciar Motor
            </Button>
            <Button 
              onClick={stopEngine} 
              disabled={!systemStatus.isRunning}
              variant="destructive"
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              Detener Motor
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabs para diferentes categorías */}
      <Tabs defaultValue="strategies" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="strategies">Estrategias</TabsTrigger>
          <TabsTrigger value="flashloans">Flash Loans</TabsTrigger>
          <TabsTrigger value="crosschain">Cross-Chain</TabsTrigger>
          <TabsTrigger value="mev">MEV Protection</TabsTrigger>
        </TabsList>

        <TabsContent value="strategies" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {strategies.map((strategy) => {
              const status = strategyStatuses.get(strategy.id)
              return (
                <Card key={strategy.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getStrategyIcon(strategy.category)}
                        <CardTitle className="text-lg">{strategy.name}</CardTitle>
                      </div>
                      <Switch
                        checked={status?.isActive || false}
                        onCheckedChange={() => toggleStrategy(strategy.id)}
                      />
                    </div>
                    <CardDescription className="text-sm">
                      {strategy.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Umbral de Ganancia:</span>
                      <Badge variant="outline">{(strategy.profitThreshold * 100).toFixed(1)}%</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Nivel de Riesgo:</span>
                      <Badge className={getRiskColor(strategy.riskLevel)}>
                        {strategy.riskLevel.toUpperCase()}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Automatización:</span>
                      <Badge className={getAutomationColor(strategy.automationLevel)}>
                        {strategy.automationLevel.replace('-', ' ').toUpperCase()}
                      </Badge>
                    </div>
                    
                    {status && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Éxito:</span>
                          <span className="font-medium">{status.successRate.toFixed(1)}%</span>
                        </div>
                        <Progress value={status.successRate} className="h-2" />
                        
                        <div className="flex items-center justify-between text-sm">
                          <span>Ganancia:</span>
                          <span className="font-medium text-green-600">${status.totalProfit.toFixed(2)}</span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="flashloans" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Flash Loan Opportunities
              </CardTitle>
              <CardDescription>
                Oportunidades de arbitraje usando flash loans
              </CardDescription>
            </CardHeader>
            <CardContent>
              {flashLoanOpportunities.length === 0 ? (
                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertDescription>
                    No hay oportunidades de flash loan disponibles en este momento.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-3">
                  {flashLoanOpportunities.map((opportunity, index) => (
                    <div key={index} className="p-4 border rounded-lg bg-gradient-to-r from-blue-50 to-purple-50">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{opportunity.tokenBorrow}</h4>
                        <Badge className={getRiskColor(opportunity.riskLevel)}>
                          {opportunity.riskLevel.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Cantidad:</span>
                          <p className="font-medium">{opportunity.amount}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Ganancia Esperada:</span>
                          <p className="font-medium text-green-600">{(opportunity.expectedProfit * 100).toFixed(2)}%</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Gas Estimado:</span>
                          <p className="font-medium">{opportunity.gasEstimate.toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Estrategia:</span>
                          <p className="font-medium">{opportunity.strategy}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="crosschain" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Cross-Chain Arbitrage
              </CardTitle>
              <CardDescription>
                Oportunidades de arbitraje entre diferentes blockchains
              </CardDescription>
            </CardHeader>
            <CardContent>
              {crossChainOpportunities.length === 0 ? (
                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertDescription>
                    No hay oportunidades cross-chain disponibles en este momento.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-3">
                  {crossChainOpportunities.map((opportunity, index) => (
                    <div key={index} className="p-4 border rounded-lg bg-gradient-to-r from-green-50 to-blue-50">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{opportunity.token}</h4>
                        <Badge className="bg-green-100 text-green-800">
                          {(opportunity.estimatedProfit * 100).toFixed(2)}% Profit
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Ruta:</span>
                          <p className="font-medium">{opportunity.sourceChain} → {opportunity.targetChain}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Diferencia de Precio:</span>
                          <p className="font-medium text-green-600">{(opportunity.priceDifference * 100).toFixed(2)}%</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Fee de Bridge:</span>
                          <p className="font-medium">{(opportunity.bridgeFee * 100).toFixed(2)}%</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Tiempo:</span>
                          <p className="font-medium">{new Date(opportunity.executionTime).toLocaleTimeString()}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mev" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                MEV Protection System
              </CardTitle>
              <CardDescription>
                Configuración y estado del sistema de protección MEV
              </CardDescription>
            </CardHeader>
            <CardContent>
              {mevProtection ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Estrategia de Protección</h4>
                      <Badge className="bg-blue-100 text-blue-800">
                        {mevProtection.strategy.toUpperCase()}
                      </Badge>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Nivel de Protección</h4>
                      <Badge className="bg-purple-100 text-purple-800">
                        {mevProtection.protectionLevel.toUpperCase()}
                      </Badge>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Gas Price</h4>
                      <p className="text-lg font-medium">{mevProtection.gasPrice} Gwei</p>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Max Priority Fee</h4>
                      <p className="text-lg font-medium">{mevProtection.maxPriorityFee} Gwei</p>
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg bg-green-50">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <h4 className="font-semibold text-green-800">MEV Protection Activo</h4>
                    </div>
                    <p className="text-sm text-green-700 mt-1">
                      El sistema está protegido contra ataques MEV usando {mevProtection.strategy}
                    </p>
                  </div>
                </div>
              ) : (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Sistema de protección MEV no disponible.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 