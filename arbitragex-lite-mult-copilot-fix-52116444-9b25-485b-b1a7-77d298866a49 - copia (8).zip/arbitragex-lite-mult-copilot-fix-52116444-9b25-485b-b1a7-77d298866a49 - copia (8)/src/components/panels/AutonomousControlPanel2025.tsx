import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Switch } from '@/components/ui/switch'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Play, 
  Square, 
  Zap, 
  Shield, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Settings,
  BarChart3,
  Activity,
  Target,
  DollarSign,
  Clock,
  Gauge
} from 'lucide-react'

import { 
  autonomousArbitrageEngine2025, 
  AutonomousStrategy, 
  ArbitrageOpportunity, 
  ExecutionResult,
  MEVProtectionConfig,
  RiskManagementConfig
} from '../../core/AutonomousArbitrageEngine2025'

export const AutonomousControlPanel2025: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false)
  const [strategies, setStrategies] = useState<AutonomousStrategy[]>([])
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([])
  const [executionHistory, setExecutionHistory] = useState<ExecutionResult[]>([])
  const [dailyStats, setDailyStats] = useState<any>({})
  const [mevConfig, setMevConfig] = useState<MEVProtectionConfig>({
    flashbotsEnabled: true,
    bundleTimeout: 30000,
    maxGasPrice: '100',
    priorityFee: '2',
    targetBlockOffset: 1,
    bundleSimulation: true
  })
  const [riskConfig, setRiskConfig] = useState<RiskManagementConfig>({
    maxPositionSize: '10',
    maxDailyLoss: '5',
    maxSlippage: 0.5,
    circuitBreakerEnabled: true,
    stopLossPercentage: 2,
    takeProfitPercentage: 5,
    cooldownPeriod: 30000
  })
  const [showSettings, setShowSettings] = useState(false)
  const [autoRefresh, setAutoRefresh] = useState(true)

  useEffect(() => {
    loadData()
    const interval = setInterval(() => {
      if (autoRefresh) {
        loadData()
      }
    }, 5000) // Actualizar cada 5 segundos

    return () => clearInterval(interval)
  }, [autoRefresh])

  const loadData = () => {
    const status = autonomousArbitrageEngine2025.getStatus()
    setIsRunning(status.isRunning)
    setStrategies(autonomousArbitrageEngine2025.getStrategies())
    setOpportunities(autonomousArbitrageEngine2025.getOpportunities())
    setExecutionHistory(autonomousArbitrageEngine2025.getExecutionHistory())
    setDailyStats(autonomousArbitrageEngine2025.getDailyStats())
  }

  const handleStartEngine = async () => {
    try {
      await autonomousArbitrageEngine2025.startAutonomousEngine()
      setIsRunning(true)
    } catch (error) {
      console.error('Error iniciando motor:', error)
    }
  }

  const handleStopEngine = async () => {
    try {
      await autonomousArbitrageEngine2025.stopAutonomousEngine()
      setIsRunning(false)
    } catch (error) {
      console.error('Error deteniendo motor:', error)
    }
  }

  const handleStrategyToggle = (strategyId: string, enabled: boolean) => {
    autonomousArbitrageEngine2025.updateStrategy(strategyId, { enabled })
    setStrategies(autonomousArbitrageEngine2025.getStrategies())
  }

  const handleMEVConfigUpdate = (config: Partial<MEVProtectionConfig>) => {
    const newConfig = { ...mevConfig, ...config }
    setMevConfig(newConfig)
    autonomousArbitrageEngine2025.updateMEVProtection(newConfig)
  }

  const handleRiskConfigUpdate = (config: Partial<RiskManagementConfig>) => {
    const newConfig = { ...riskConfig, ...config }
    setRiskConfig(newConfig)
    autonomousArbitrageEngine2025.updateRiskManagement(newConfig)
  }

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800'
      case 'medium': return 'bg-yellow-100 text-yellow-800'
      case 'high': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (success: boolean) => {
    return success ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />
  }

  const formatProfit = (profit: string) => {
    const num = parseFloat(profit)
    return num >= 0 ? `+${num.toFixed(4)} ETH` : `${num.toFixed(4)} ETH`
  }

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString()
  }

  return (
    <div className="space-y-6">
      {/* Header con estado del sistema */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-6 h-6" />
                Motor de Arbitraje Autónomo 2025
              </CardTitle>
              <CardDescription>
                Sistema autónomo con protección MEV y estrategias combinadas infalibles
              </CardDescription>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant={isRunning ? "default" : "secondary"}>
                {isRunning ? "🟢 Ejecutándose" : "🔴 Detenido"}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowSettings(!showSettings)}
              >
                <Settings className="w-4 h-4 mr-2" />
                Configuración
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3">
              <DollarSign className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Ganancia Total</p>
                <p className="font-semibold">{formatProfit(dailyStats.totalProfit || '0')}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Activity className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Operaciones</p>
                <p className="font-semibold">{dailyStats.totalTrades || 0}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Target className="w-5 h-5 text-purple-500" />
              <div>
                <p className="text-sm text-muted-foreground">Éxito</p>
                <p className="font-semibold">{dailyStats.successfulTrades || 0}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Gauge className="w-5 h-5 text-orange-500" />
              <div>
                <p className="text-sm text-muted-foreground">Gas Total</p>
                <p className="font-semibold">{dailyStats.totalGasUsed || '0'} ETH</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Controles principales */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Play className="w-5 h-5" />
            Controles Principales
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Button
              onClick={handleStartEngine}
              disabled={isRunning}
              className="flex items-center gap-2"
            >
              <Play className="w-4 h-4" />
              Iniciar Motor Autónomo
            </Button>
            <Button
              variant="destructive"
              onClick={handleStopEngine}
              disabled={!isRunning}
              className="flex items-center gap-2"
            >
              <Square className="w-4 h-4" />
              Detener Motor
            </Button>
            <div className="flex items-center gap-2">
              <Switch
                checked={autoRefresh}
                onCheckedChange={setAutoRefresh}
              />
              <Label>Auto-refresh</Label>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Configuración avanzada */}
      {showSettings && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Configuración Avanzada
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Configuración MEV */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Protección MEV
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Flashbots Habilitado</Label>
                    <Switch
                      checked={mevConfig.flashbotsEnabled}
                      onCheckedChange={(checked) => handleMEVConfigUpdate({ flashbotsEnabled: checked })}
                    />
                  </div>
                  <div>
                    <Label>Gas Máximo (Gwei)</Label>
                    <Input
                      type="number"
                      value={mevConfig.maxGasPrice}
                      onChange={(e) => handleMEVConfigUpdate({ maxGasPrice: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Fee de Prioridad (Gwei)</Label>
                    <Input
                      type="number"
                      value={mevConfig.priorityFee}
                      onChange={(e) => handleMEVConfigUpdate({ priorityFee: e.target.value })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Simulación de Bundle</Label>
                    <Switch
                      checked={mevConfig.bundleSimulation}
                      onCheckedChange={(checked) => handleMEVConfigUpdate({ bundleSimulation: checked })}
                    />
                  </div>
                </div>
              </div>

              {/* Gestión de Riesgo */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  Gestión de Riesgo
                </h3>
                <div className="space-y-3">
                  <div>
                    <Label>Tamaño Máximo de Posición (ETH)</Label>
                    <Input
                      type="number"
                      value={riskConfig.maxPositionSize}
                      onChange={(e) => handleRiskConfigUpdate({ maxPositionSize: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Pérdida Máxima Diaria (ETH)</Label>
                    <Input
                      type="number"
                      value={riskConfig.maxDailyLoss}
                      onChange={(e) => handleRiskConfigUpdate({ maxDailyLoss: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Slippage Máximo (%)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={riskConfig.maxSlippage}
                      onChange={(e) => handleRiskConfigUpdate({ maxSlippage: parseFloat(e.target.value) })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Circuit Breaker</Label>
                    <Switch
                      checked={riskConfig.circuitBreakerEnabled}
                      onCheckedChange={(checked) => handleRiskConfigUpdate({ circuitBreakerEnabled: checked })}
                    />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Estrategias */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Estrategias Autónomas
          </CardTitle>
          <CardDescription>
            Gestiona las estrategias de arbitraje automatizadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {strategies.map((strategy) => (
              <div key={strategy.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Switch
                      checked={strategy.enabled}
                      onCheckedChange={(checked) => handleStrategyToggle(strategy.id, checked)}
                    />
                    <div>
                      <h4 className="font-semibold">{strategy.name}</h4>
                      <p className="text-sm text-muted-foreground">{strategy.description}</p>
                    </div>
                  </div>
                  <Badge className={getRiskLevelColor(strategy.riskLevel)}>
                    {strategy.riskLevel.toUpperCase()}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Prioridad</p>
                    <p className="font-medium">{strategy.priority}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Ganancia Total</p>
                    <p className="font-medium">{formatProfit(strategy.totalProfit)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Tasa de Éxito</p>
                    <p className="font-medium">{(strategy.successRate * 100).toFixed(1)}%</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Operaciones</p>
                    <p className="font-medium">{strategy.totalTrades}</p>
                  </div>
                </div>
                <div className="mt-3">
                  <Progress value={strategy.successRate * 100} className="h-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Oportunidades Activas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Oportunidades Activas
          </CardTitle>
          <CardDescription>
            Oportunidades de arbitraje detectadas en tiempo real
          </CardDescription>
        </CardHeader>
        <CardContent>
          {opportunities.length === 0 ? (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                No hay oportunidades activas en este momento. El sistema está escaneando continuamente.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-3">
              {opportunities.slice(0, 10).map((opportunity) => (
                <div key={opportunity.id} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{opportunity.executionStrategy}</Badge>
                      <span className="font-medium">{opportunity.tokenSymbol}</span>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-green-600">
                        {formatProfit(opportunity.expectedProfit)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {opportunity.priceDifference.toFixed(2)}% diferencia
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                    <div>
                      <p className="text-muted-foreground">Origen</p>
                      <p>{opportunity.sourceChain} → {opportunity.targetChain}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">DEX</p>
                      <p>{opportunity.sourceDEX} → {opportunity.targetDEX}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Gas Estimado</p>
                      <p>{opportunity.gasEstimate}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Riesgo</p>
                      <p>{(opportunity.riskScore * 100).toFixed(0)}%</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Historial de Ejecución */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Historial de Ejecución
          </CardTitle>
          <CardDescription>
            Últimas 50 operaciones ejecutadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {executionHistory.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No hay historial de ejecución disponible
              </p>
            ) : (
              executionHistory.map((execution, index) => (
                <div key={index} className="flex items-center justify-between p-2 border rounded">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(execution.success)}
                    <div>
                      <p className="font-medium">{execution.strategy}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatTime(execution.executionTime)} • {execution.executionTime}ms
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    {execution.success ? (
                      <div>
                        <p className="font-semibold text-green-600">
                          {formatProfit(execution.profit || '0')}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Gas: {execution.gasUsed || '0'}
                        </p>
                      </div>
                    ) : (
                      <p className="text-red-600 text-sm">{execution.error}</p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 