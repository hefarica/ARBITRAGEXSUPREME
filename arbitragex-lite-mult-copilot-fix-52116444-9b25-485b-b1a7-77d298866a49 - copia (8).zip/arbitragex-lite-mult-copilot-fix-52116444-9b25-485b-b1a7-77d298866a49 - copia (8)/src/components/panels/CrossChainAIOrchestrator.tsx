import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Progress } from '@/components/ui/progress'
import { 
  Network, 
  Brain, 
  TrendUp, 
  Lightning,
  Robot,
  ChatCircle,
  Code,
  ArrowsLeftRight,
  Cpu,
  Database,
  Eye,
  Lightbulb,
  Play,
  Gear
} from '@phosphor-icons/react'
import { useKV } from '@/hooks/useKV'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts'

interface CrossChainAIOrchestatorProps {
  environment: 'test' | 'prod'
}

// Mock data for demonstration
const crossChainMetrics = [
  { chain: 'Ethereum', volume: 45600, fees: 89, latency: 12, opportunities: 8 },
  { chain: 'Polygon', volume: 23400, fees: 2, latency: 3, opportunities: 12 },
  { chain: 'Arbitrum', volume: 34500, fees: 15, latency: 2, opportunities: 6 },
  { chain: 'Optimism', volume: 19800, fees: 8, latency: 2, opportunities: 9 },
  { chain: 'BNB Chain', volume: 56700, fees: 1, latency: 4, opportunities: 15 },
]

const bridgePerformance = [
  { time: '00:00', multichain: 85, layerzero: 92, wormhole: 78, hop: 88 },
  { time: '04:00', multichain: 88, layerzero: 94, wormhole: 82, hop: 90 },
  { time: '08:00', multichain: 82, layerzero: 89, wormhole: 85, hop: 87 },
  { time: '12:00', multichain: 90, layerzero: 96, wormhole: 79, hop: 92 },
  { time: '16:00', multichain: 87, layerzero: 91, wormhole: 83, hop: 89 },
  { time: '20:00', multichain: 91, layerzero: 95, wormhole: 86, hop: 93 },
]

const aiPredictions = [
  { time: '1h', btc: 45200, eth: 2890, prediction: 'bullish', confidence: 0.87 },
  { time: '4h', btc: 45800, eth: 2920, prediction: 'bullish', confidence: 0.92 },
  { time: '12h', btc: 44900, eth: 2850, prediction: 'bearish', confidence: 0.78 },
  { time: '24h', btc: 46500, eth: 2980, prediction: 'bullish', confidence: 0.85 },
]

const radarData = [
  { subject: 'Latency', A: 120, B: 110, fullMark: 150 },
  { subject: 'Accuracy', A: 98, B: 85, fullMark: 100 },
  { subject: 'Coverage', A: 86, B: 95, fullMark: 100 },
  { subject: 'Cost', A: 99, B: 89, fullMark: 100 },
  { subject: 'Reliability', A: 85, B: 90, fullMark: 100 },
  { subject: 'Scalability', A: 65, B: 78, fullMark: 100 },
]

export const CrossChainAIOrchestrator = ({ environment }: CrossChainAIOrchestatorProps) => {
  const [enabledNetworks, setEnabledNetworks] = useKV('enabled-networks', ['ethereum', 'polygon', 'arbitrum'])
  const [gasStrategy, setGasStrategy] = useKV('gas-strategy', 'balanced')
  const [preferredBridges, setPreferredBridges] = useKV('preferred-bridges', ['layerzero', 'multichain'])
  const [aiModel, setAiModel] = useKV('ai-model', 'gpt-4-turbo')
  const [aiPersonality, setAiPersonality] = useKV('ai-personality', 'conservative')
  const [autonomyLevel, setAutonomyLevel] = useKV('ai-autonomy-level', [1])
  const [predictionModels, setPredictionModels] = useKV('prediction-models', ['technical', 'sentiment'])

  const [aiConnected, setAiConnected] = useState(true)
  const [chatMessages, setChatMessages] = useState([
    { role: 'assistant', content: 'Hello! I\'m your AI trading assistant. How can I help you optimize your cross-chain strategies today?', timestamp: '10:30 AM' },
    { role: 'user', content: 'What are the best arbitrage opportunities right now?', timestamp: '10:31 AM' },
    { role: 'assistant', content: 'I\'ve detected 3 high-confidence opportunities: ETH/USDC between Ethereum and Polygon (1.2% profit), WBTC/ETH on Arbitrum vs Optimism (0.8% profit), and a triangular opportunity across BNB-Polygon-Ethereum. Shall I execute the highest confidence trade?', timestamp: '10:32 AM' },
  ])

  const handlePaperPlaneMessage = (message: string) => {
    setChatMessages([
      ...chatMessages,
      { role: 'user', content: message, timestamp: new Date().toLocaleTimeString() }
    ])
    // Simulate AI response
    setTimeout(() => {
      setChatMessages(prev => [
        ...prev,
        { role: 'assistant', content: 'Analyzing your request and market conditions...', timestamp: new Date().toLocaleTimeString() }
      ])
    }, 1000)
  }

  return (
    <div className="p-6 space-y-6 pt-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Network size={32} className="text-primary" />
            Cross-Chain AI Orchestrator
          </h1>
          <p className="text-muted-foreground mt-1">
            Multi-Chain Manager + AI Assistant + Predictive Insights
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant={environment === 'test' ? 'secondary' : 'destructive'}>
            {environment === 'test' ? 'Testnet Mode' : 'Mainnet Active'}
          </Badge>
          <Badge 
            variant={aiConnected ? 'default' : 'outline'}
            className="gap-1"
          >
            <Brain size={12} />
            AI {aiConnected ? 'Online' : 'Offline'}
          </Badge>
        </div>
      </div>

      {/* Quick Cross-Chain Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Chains</p>
                <p className="text-2xl font-bold">{enabledNetworks.length}</p>
              </div>
              <Network className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Cross-Chain SpeakerHigh</p>
                <p className="text-2xl font-bold">$2.3M</p>
              </div>
              <ArrowsLeftRight className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">AI Predictions</p>
                <p className="text-2xl font-bold">89%</p>
              </div>
              <Brain className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Opportunities</p>
                <p className="text-2xl font-bold">42</p>
              </div>
              <TrendUp className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Orchestrator Tabs */}
      <Tabs defaultValue="multichain" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="multichain" className="gap-2">
            <Network size={16} />
            Multi-Chain Manager
          </TabsTrigger>
          <TabsTrigger value="ai-assistant" className="gap-2">
            <Brain size={16} />
            AI Assistant Pro
          </TabsTrigger>
          <TabsTrigger value="predictions" className="gap-2">
            <TrendUp size={16} />
            AI Predictions
          </TabsTrigger>
        </TabsList>

        {/* Multi-Chain Manager Tab */}
        <TabsContent value="multichain" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Network Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gear size={20} />
                  Network Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Active Networks</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {['ethereum', 'polygon', 'arbitrum', 'optimism', 'bnb-chain', 'avalanche'].map((network) => (
                      <div key={network} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={enabledNetworks.includes(network)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setEnabledNetworks([...enabledNetworks, network])
                            } else {
                              setEnabledNetworks(enabledNetworks.filter(n => n !== network))
                            }
                          }}
                          className="rounded"
                        />
                        <Label className="capitalize">{network.replace('-', ' ')}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Gas Optimization Strategy</Label>
                  <Select value={gasStrategy} onValueChange={setGasStrategy}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="lowest">Lowest Cost</SelectItem>
                      <SelectItem value="fastest">Fastest Execution</SelectItem>
                      <SelectItem value="balanced">Balanced</SelectItem>
                      <SelectItem value="custom">Custom EIP-1559</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label>Preferred Bridges</Label>
                  <div className="space-y-2">
                    {['layerzero', 'multichain', 'wormhole', 'hop', 'synapse'].map((bridge) => (
                      <div key={bridge} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={preferredBridges.includes(bridge)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setPreferredBridges([...preferredBridges, bridge])
                            } else {
                              setPreferredBridges(preferredBridges.filter(b => b !== bridge))
                            }
                          }}
                          className="rounded"
                        />
                        <Label className="capitalize">{bridge}</Label>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Cross-Chain Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart />
                  Network Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {crossChainMetrics.map((network) => (
                    <div key={network.chain} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{network.chain}</span>
                        <Badge variant="outline">{network.opportunities} ops</Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-sm text-muted-foreground">
                        <div>Vol: ${(network.volume / 1000).toFixed(0)}K</div>
                        <div>Fee: ${network.fees}</div>
                        <div>Lat: {network.latency}s</div>
                      </div>
                      <Progress value={(network.opportunities / 20) * 100} className="mt-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Bridge Performance Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Bridge Performance Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={bridgePerformance}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="layerzero" stroke="#8884d8" name="LayerZero" />
                  <Line type="monotone" dataKey="multichain" stroke="#82ca9d" name="Multichain" />
                  <Line type="monotone" dataKey="wormhole" stroke="#ffc658" name="Wormhole" />
                  <Line type="monotone" dataKey="hop" stroke="#ff7300" name="Hop Protocol" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Cross-Chain Opportunities Scanner */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye size={20} />
                Cross-Chain Opportunities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { pair: 'ETH/USDC', chains: 'Ethereum → Polygon', profit: 1.24, confidence: 95 },
                  { pair: 'WBTC/ETH', chains: 'Arbitrum → Optimism', profit: 0.87, confidence: 88 },
                  { pair: 'MATIC/USDT', chains: 'Polygon → BNB Chain', profit: 2.15, confidence: 92 },
                ].map((opp, idx) => (
                  <div key={idx} className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">{opp.pair}</span>
                      <span className="text-green-600 font-medium">+{opp.profit}%</span>
                    </div>
                    <div className="text-sm text-muted-foreground mb-2">{opp.chains}</div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Confidence: {opp.confidence}%</span>
                      <Button size="sm" variant="outline">Execute</Button>
                    </div>
                    <Progress value={opp.confidence} className="mt-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Assistant Tab */}
        <TabsContent value="ai-assistant" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* AI Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Robot size={20} />
                  AI Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>AI Model</Label>
                  <Select value={aiModel} onValueChange={setAiModel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gpt-4-turbo">GPT-4 Turbo</SelectItem>
                      <SelectItem value="gpt-4o">GPT-4o</SelectItem>
                      <SelectItem value="claude-3.5-sonnet">Claude 3.5 Sonnet</SelectItem>
                      <SelectItem value="gemini-pro">Gemini Pro</SelectItem>
                      <SelectItem value="custom">Custom Local Model</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label>AI Personality</Label>
                  <Select value={aiPersonality} onValueChange={setAiPersonality}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="conservative">Conservative Advisor</SelectItem>
                      <SelectItem value="aggressive">Aggressive Trader</SelectItem>
                      <SelectItem value="risk-manager">Risk Manager</SelectItem>
                      <SelectItem value="technical">Technical Analyst</SelectItem>
                      <SelectItem value="custom">Custom Prompt</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label>Autonomy Level</Label>
                  <Slider
                    value={autonomyLevel}
                    onValueChange={setAutonomyLevel}
                    max={3}
                    min={0}
                    step={1}
                    className="w-full"
                  />
                  <div className="text-sm text-muted-foreground">
                    {autonomyLevel[0] === 0 && 'Only Consultations'}
                    {autonomyLevel[0] === 1 && 'Recommendations'}
                    {autonomyLevel[0] === 2 && 'Supervised Execution'}
                    {autonomyLevel[0] === 3 && 'Full Autonomy'}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Memory & Learning</Label>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Remember Conversations</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Learn Trading Patterns</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Continuous Learning</span>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Assistant Chat */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ChatCircle size={20} />
                  AI Assistant Chat
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Chat Messages */}
                  <div className="h-64 overflow-y-auto space-y-3 p-3 border rounded-lg">
                    {chatMessages.map((message, idx) => (
                      <div key={idx} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-2 rounded-lg ${
                          message.role === 'user' 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted'
                        }`}>
                          <p className="text-sm">{message.content}</p>
                          <p className="text-xs opacity-70 mt-1">{message.timestamp}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Chat Input */}
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Ask the AI assistant..."
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && e.currentTarget.value) {
                          handlePaperPlaneMessage(e.currentTarget.value)
                          e.currentTarget.value = ''
                        }
                      }}
                    />
                    <Button size="sm">PaperPlane</Button>
                  </div>

                  {/* Quick Actions */}
                  <div className="flex flex-wrap gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handlePaperPlaneMessage('Analyze current market conditions')}
                    >
                      Market Analysis
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handlePaperPlaneMessage('Suggest optimization strategies')}
                    >
                      Optimize Strategy
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handlePaperPlaneMessage('Generate risk report')}
                    >
                      Risk Report
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Code Generation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code size={20} />
                AI Code Generation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <Label>Generate Strategy Code</Label>
                  <Textarea 
                    placeholder="Describe your trading strategy..."
                    className="h-24"
                  />
                  <Select defaultValue="javascript">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="javascript">JavaScript</SelectItem>
                      <SelectItem value="python">Python</SelectItem>
                      <SelectItem value="rust">Rust</SelectItem>
                      <SelectItem value="solidity">Solidity</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button className="w-full">Generate Code</Button>
                </div>
                <div className="space-y-3">
                  <Label>Generated Code Preview</Label>
                  <div className="h-40 p-3 bg-muted rounded-lg font-mono text-sm overflow-y-auto">
                    <div className="text-green-600">// AI-Generated Strategy Code</div>
                    <div>function arbitrageStrategy() {'{'}</div>
                    <div className="ml-4">const threshold = 0.5;</div>
                    <div className="ml-4">const maxSlippage = 1.0;</div>
                    <div className="ml-4">// Implementation...</div>
                    <div>{'}'}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Predictions Tab */}
        <TabsContent value="predictions" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Prediction Models */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu size={20} />
                  Prediction Models
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Active Models</Label>
                  <div className="space-y-2">
                    {['technical', 'sentiment', 'fundamental', 'onchain', 'macro'].map((model) => (
                      <div key={model} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={predictionModels.includes(model)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setPredictionModels([...predictionModels, model])
                            } else {
                              setPredictionModels(predictionModels.filter(m => m !== model))
                            }
                          }}
                          className="rounded"
                        />
                        <Label className="capitalize">{model} Analysis</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Model Performance</Label>
                  <ResponsiveContainer width="100%" height={200}>
                    <RadarChart data={radarData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="subject" />
                      <PolarRadiusAxis />
                      <Radar name="Model A" dataKey="A" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                      <Radar name="Model B" dataKey="B" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Prediction Results */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb size={20} />
                  AI Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-600">89%</div>
                    <div className="text-sm text-muted-foreground">Accuracy (7d)</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-blue-600">94%</div>
                    <div className="text-sm text-muted-foreground">Confidence</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <p className="text-sm font-medium">Bullish Signal</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      BTC expected to reach $46,500 in next 24h (85% confidence)
                    </p>
                  </div>
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <p className="text-sm font-medium">Cross-Chain Opportunity</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      ETH arbitrage window opening between Polygon and Arbitrum
                    </p>
                  </div>
                  <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                    <p className="text-sm font-medium">Risk Alert</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Increased volatility expected due to Fed announcement
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Sentiment Score</span>
                    <span className="text-green-600">+0.73</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Fear & Greed Index</span>
                    <span>68 (Greed)</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>On-chain Activity</span>
                    <span className="text-blue-600">High</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Prediction Timeline */}
          <Card>
            <CardHeader>
              <CardTitle>AI Price Predictions</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={aiPredictions}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="btc" stackId="1" stroke="#f7931a" fill="#f7931a" fillOpacity={0.6} name="BTC" />
                  <Area type="monotone" dataKey="eth" stackId="2" stroke="#627eea" fill="#627eea" fillOpacity={0.6} name="ETH" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Backtesting Results */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database size={20} />
                Backtesting & Validation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-lg font-bold">89.3%</div>
                  <div className="text-sm text-muted-foreground">Accuracy</div>
                </div>
                <div>
                  <div className="text-lg font-bold">+24.7%</div>
                  <div className="text-sm text-muted-foreground">Returns</div>
                </div>
                <div>
                  <div className="text-lg font-bold">1.84</div>
                  <div className="text-sm text-muted-foreground">Sharpe Ratio</div>
                </div>
                <div>
                  <div className="text-lg font-bold">-3.2%</div>
                  <div className="text-sm text-muted-foreground">Max Drawdown</div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm">Run Backtest</Button>
                <Button variant="outline" size="sm">Export Results</Button>
                <Button variant="outline" size="sm">Compare Models</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

