import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Switch } from '@/components/ui/switch'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Play, 
  Square, 
  Zap, 
  Shield, 
  TrendingUp, 
  AlertTriangle, 
  Settings, 
  BarChart3,
  Activity,
  Target,
  Clock,
  DollarSign,
  Gauge,
  Brain,
  Rocket,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  RefreshCw,
  CheckCircle,
  XCircle,
  Info
} from 'lucide-react'

import { 
  advancedMEVEngine2025, 
  MEVStrategy, 
  MEVExecution,
  MEVProtectionConfig,
  AdvancedMEVConfig
} from '../../core/AdvancedMEVEngine2025'
import { 
  eigenPhiIntelligenceService, 
  MarketIntelligence,
  FlashLoanOpportunity,
  MEVTransaction
} from '../../services/EigenPhiIntelligenceService'

export const AdvancedMEVControlPanel2025: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false)
  const [strategies, setStrategies] = useState<MEVStrategy[]>([])
  const [executions, setExecutions] = useState<MEVExecution[]>([])
  const [marketIntelligence, setMarketIntelligence] = useState<MarketIntelligence | null>(null)
  const [flashLoanOpportunities, setFlashLoanOpportunities] = useState<FlashLoanOpportunity[]>([])
  const [mevPatterns, setMevPatterns] = useState<MEVTransaction[]>([])
  const [config, setConfig] = useState<AdvancedMEVConfig | null>(null)
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null)
  const [alerts, setAlerts] = useState<string[]>([])
  const [showAdvancedConfig, setShowAdvancedConfig] = useState(false)

  useEffect(() => {
    initializePanel()
    const interval = setInterval(updateData, 5000) // Actualizar cada 5 segundos
    return () => clearInterval(interval)
  }, [])

  const initializePanel = async () => {
    try {
      await advancedMEVEngine2025.initialize()
      await eigenPhiIntelligenceService.initialize()
      
      updateData()
      
      // Configurar alertas
      eigenPhiIntelligenceService.onAlert((alert: string) => {
        setAlerts(prev => [alert, ...prev.slice(0, 9)]) // Mantener solo las últimas 10 alertas
      })
    } catch (error) {
      console.error('Error inicializando panel:', error)
    }
  }

  const updateData = () => {
    setStrategies(advancedMEVEngine2025.getStrategies())
    setExecutions(advancedMEVEngine2025.getExecutions())
    setConfig(advancedMEVEngine2025.getConfig())
    setMarketIntelligence(eigenPhiIntelligenceService.getMarketIntelligence())
    setFlashLoanOpportunities(eigenPhiIntelligenceService.getFlashLoanOpportunities())
    setMevPatterns(eigenPhiIntelligenceService.getMEVPatterns())
  }

  const handleStartEngine = async () => {
    try {
      await advancedMEVEngine2025.startEngine()
      setIsRunning(true)
    } catch (error) {
      console.error('Error iniciando motor:', error)
    }
  }

  const handleStopEngine = async () => {
    try {
      await advancedMEVEngine2025.stopEngine()
      setIsRunning(false)
    } catch (error) {
      console.error('Error deteniendo motor:', error)
    }
  }

  const handleToggleStrategy = (strategyId: string, enabled: boolean) => {
    advancedMEVEngine2025.toggleStrategy(strategyId, enabled)
    updateData()
  }

  const handleUpdateConfig = (newConfig: Partial<AdvancedMEVConfig>) => {
    if (config) {
      advancedMEVEngine2025.updateConfig(newConfig)
      setConfig({ ...config, ...newConfig })
    }
  }

  const getStrategyIcon = (type: string) => {
    switch (type) {
      case 'triangular': return <Target className="h-4 w-4" />
      case 'sandwich': return <Shield className="h-4 w-4" />
      case 'liquidation': return <AlertTriangle className="h-4 w-4" />
      case 'jit': return <Clock className="h-4 w-4" />
      case 'cross-chain': return <Zap className="h-4 w-4" />
      case 'flash-loan': return <Rocket className="h-4 w-4" />
      default: return <Activity className="h-4 w-4" />
    }
  }

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'low': return 'bg-green-100 text-green-800'
      case 'medium': return 'bg-yellow-100 text-yellow-800'
      case 'high': return 'bg-orange-100 text-orange-800'
      case 'extreme': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'bullish': return 'text-green-600'
      case 'bearish': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const formatProfit = (profit: number) => {
    return `${profit > 0 ? '+' : ''}${profit.toFixed(2)}%`
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount)
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">🤖 Advanced MEV Engine 2025</h1>
          <p className="text-gray-600">Motor de arbitraje MEV con técnicas punta de lanza</p>
        </div>
        <div className="flex items-center space-x-4">
          <Button
            onClick={isRunning ? handleStopEngine : handleStartEngine}
            variant={isRunning ? "destructive" : "default"}
            size="lg"
            className="flex items-center space-x-2"
          >
            {isRunning ? <Square className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            <span>{isRunning ? 'Detener Motor' : 'Iniciar Motor'}</span>
          </Button>
          <Button
            onClick={() => setShowAdvancedConfig(!showAdvancedConfig)}
            variant="outline"
            size="lg"
          >
            <Settings className="h-5 w-5 mr-2" />
            Configuración
          </Button>
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estado del Motor</CardTitle>
            <Activity className={`h-4 w-4 ${isRunning ? 'text-green-600' : 'text-red-600'}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isRunning ? 'Activo' : 'Inactivo'}</div>
            <p className="text-xs text-muted-foreground">
              {isRunning ? 'Ejecutando estrategias' : 'Motor detenido'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estrategias Activas</CardTitle>
            <Target className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{strategies.filter(s => s.isActive).length}</div>
            <p className="text-xs text-muted-foreground">
              de {strategies.length} estrategias disponibles
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ejecuciones Hoy</CardTitle>
            <BarChart3 className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {executions.filter(e => Date.now() - e.timestamp < 86400000).length}
            </div>
            <p className="text-xs text-muted-foreground">
              Últimas 24 horas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sentimiento de Mercado</CardTitle>
            <TrendingUp className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getSentimentColor(marketIntelligence?.marketSentiment || 'neutral')}`}>
              {marketIntelligence?.marketSentiment || 'neutral'}
            </div>
            <p className="text-xs text-muted-foreground">
              Volatilidad: {(marketIntelligence?.volatilityIndex || 0).toFixed(2)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* MEV Strategies */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5" />
            <span>Estrategias MEV Avanzadas 2025</span>
          </CardTitle>
          <CardDescription>
            Técnicas punta de lanza para arbitraje y flash loans con protección MEV
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {strategies.map((strategy) => {
              const metrics = advancedMEVEngine2025.getStrategyMetrics(strategy.id)
              return (
                <Card key={strategy.id} className="border-l-4 border-l-blue-500">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {getStrategyIcon(strategy.type)}
                        <CardTitle className="text-lg">{strategy.name}</CardTitle>
                      </div>
                      <Switch
                        checked={strategy.isActive}
                        onCheckedChange={(enabled) => handleToggleStrategy(strategy.id, enabled)}
                      />
                    </div>
                    <CardDescription>{strategy.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Umbral de Ganancia:</span>
                      <Badge variant="outline">{strategy.profitThreshold}%</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Nivel de Riesgo:</span>
                      <Badge className={getRiskColor(strategy.riskLevel)}>
                        {strategy.riskLevel}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Tasa de Éxito:</span>
                      <span className="font-medium">{(strategy.successRate * 100).toFixed(1)}%</span>
                    </div>
                    {metrics && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Ejecuciones (24h):</span>
                          <span>{metrics.totalExecutions}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span>Ganancia Total:</span>
                          <span className="font-medium text-green-600">
                            {formatProfit(metrics.totalProfit)}
                          </span>
                        </div>
                        <Progress value={metrics.successRate * 100} className="h-2" />
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Flash Loan Opportunities */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Rocket className="h-5 w-5" />
            <span>Oportunidades de Flash Loan</span>
          </CardTitle>
          <CardDescription>
            Oportunidades detectadas por EigenPhi Intelligence
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {flashLoanOpportunities.slice(0, 5).map((opportunity) => (
              <div key={opportunity.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="flex flex-col">
                    <span className="font-medium">{opportunity.strategy}</span>
                    <span className="text-sm text-gray-600">
                      {opportunity.sourceProtocol} → {opportunity.targetProtocol}
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="font-medium text-green-600">
                      {formatProfit(opportunity.expectedProfit)}
                    </div>
                    <div className="text-sm text-gray-600">
                      Riesgo: {opportunity.riskScore}/10
                    </div>
                  </div>
                  <Button size="sm" variant="outline">
                    Ejecutar
                  </Button>
                </div>
              </div>
            ))}
            {flashLoanOpportunities.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No hay oportunidades de flash loan disponibles
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* MEV Patterns */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5" />
            <span>Patrones MEV Detectados</span>
          </CardTitle>
          <CardDescription>
            Análisis en tiempo real de transacciones MEV
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mevPatterns.slice(0, 5).map((pattern) => (
              <div key={pattern.txHash} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Badge variant="outline">{pattern.type}</Badge>
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">
                      {pattern.protocol} - {pattern.tokens.join(', ')}
                    </span>
                    <span className="text-xs text-gray-600">
                      Block #{pattern.blockNumber}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-green-600">
                    {formatProfit(pattern.profit)}
                  </div>
                  <div className="text-sm text-gray-600">
                    Gas: {pattern.gasUsed.toLocaleString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Executions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5" />
            <span>Ejecuciones Recientes</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {executions.slice(0, 10).map((execution) => (
              <div key={execution.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  {execution.success ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600" />
                  )}
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">
                      {strategies.find(s => s.id === execution.strategyId)?.name || execution.strategyId}
                    </span>
                    <span className="text-xs text-gray-600">
                      {new Date(execution.timestamp).toLocaleString()}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  {execution.success ? (
                    <div className="font-medium text-green-600">
                      {formatProfit(execution.profit)}
                    </div>
                  ) : (
                    <div className="text-sm text-red-600">
                      {execution.error}
                    </div>
                  )}
                  {execution.txHash && (
                    <div className="text-xs text-gray-600">
                      {execution.txHash.slice(0, 8)}...{execution.txHash.slice(-6)}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Alerts */}
      {alerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <span>Alertas en Tiempo Real</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {alerts.map((alert, index) => (
                <Alert key={index}>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{alert}</AlertDescription>
                </Alert>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Advanced Configuration */}
      {showAdvancedConfig && config && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="h-5 w-5" />
              <span>Configuración Avanzada</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* MEV Protection */}
            <div>
              <h3 className="text-lg font-medium mb-4">Protección MEV</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Usar Flashbots</Label>
                  <Switch
                    checked={config.protection.useFlashbots}
                    onCheckedChange={(enabled) => 
                      handleUpdateConfig({
                        protection: { ...config.protection, useFlashbots: enabled }
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Pools Privados</Label>
                  <Switch
                    checked={config.protection.usePrivatePools}
                    onCheckedChange={(enabled) => 
                      handleUpdateConfig({
                        protection: { ...config.protection, usePrivatePools: enabled }
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>MEV-Share</Label>
                  <Switch
                    checked={config.protection.useMEVShare}
                    onCheckedChange={(enabled) => 
                      handleUpdateConfig({
                        protection: { ...config.protection, useMEVShare: enabled }
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Simulación</Label>
                  <Switch
                    checked={config.protection.enableSimulation}
                    onCheckedChange={(enabled) => 
                      handleUpdateConfig({
                        protection: { ...config.protection, enableSimulation: enabled }
                      })
                    }
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Thresholds */}
            <div>
              <h3 className="text-lg font-medium mb-4">Umbrales</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Umbral Mínimo de Ganancia (%)</Label>
                  <Input
                    type="number"
                    value={config.minProfitThreshold}
                    onChange={(e) => 
                      handleUpdateConfig({ minProfitThreshold: parseFloat(e.target.value) })
                    }
                    step="0.1"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Gas Price Máximo (Gwei)</Label>
                  <Input
                    type="number"
                    value={config.protection.maxGasPrice}
                    onChange={(e) => 
                      handleUpdateConfig({
                        protection: { ...config.protection, maxGasPrice: parseInt(e.target.value) }
                      })
                    }
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Features */}
            <div>
              <h3 className="text-lg font-medium mb-4">Características</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Ejecución Automática</Label>
                  <Switch
                    checked={config.enableAutoExecution}
                    onCheckedChange={(enabled) => 
                      handleUpdateConfig({ enableAutoExecution: enabled })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Cross-Chain</Label>
                  <Switch
                    checked={config.enableCrossChain}
                    onCheckedChange={(enabled) => 
                      handleUpdateConfig({ enableCrossChain: enabled })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Análisis Predictivo</Label>
                  <Switch
                    checked={config.enablePredictiveAnalysis}
                    onCheckedChange={(enabled) => 
                      handleUpdateConfig({ enablePredictiveAnalysis: enabled })
                    }
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
} 