import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { 
  Lock, 
  ShieldCheck, 
  Eye,
  ChatTeardrop,
  TrendUp,
  TrendDown,
  WarningCircle,
  CheckCircle,
  Users,
  Heart,
  MessageSquare,
  ShareNetwork,
  Key,
  Fingerprint,
  Globe,
  Shield,
  Clock,
  Activity
} from '@phosphor-icons/react'
import { useKV } from '@/hooks/useKV'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar } from 'recharts'

interface SecuritySentimentHubProps {
  environment: 'test' | 'prod'
}

// Mock data for demonstration
const securityEvents = [
  { time: '00:00', threats: 2, blocked: 5, suspicious: 1 },
  { time: '04:00', threats: 0, blocked: 3, suspicious: 2 },
  { time: '08:00', threats: 1, blocked: 8, suspicious: 0 },
  { time: '12:00', threats: 3, blocked: 12, suspicious: 4 },
  { time: '16:00', threats: 1, blocked: 6, suspicious: 1 },
  { time: '20:00', threats: 0, blocked: 4, suspicious: 0 },
]

const sentimentData = [
  { time: '00:00', sentiment: 0.65, volume: 1200, mentions: 450 },
  { time: '04:00', sentiment: 0.72, volume: 980, mentions: 380 },
  { time: '08:00', sentiment: 0.58, volume: 1560, mentions: 620 },
  { time: '12:00', sentiment: 0.45, volume: 2100, mentions: 850 },
  { time: '16:00', sentiment: 0.38, volume: 1890, mentions: 720 },
  { time: '20:00', sentiment: 0.61, volume: 1340, mentions: 510 },
]

const socialMetrics = [
  { platform: 'Twitter', sentiment: 0.68, mentions: 12400, engagement: 89 },
  { platform: 'Reddit', sentiment: 0.72, mentions: 3200, engagement: 94 },
  { platform: 'Telegram', sentiment: 0.55, mentions: 8700, engagement: 76 },
  { platform: 'Discord', sentiment: 0.61, mentions: 2100, engagement: 82 },
]

const influencerData = [
  { name: 'CryptoPundit', followers: 450000, credibility: 92, influence: 88, sentiment: 'bullish' },
  { name: 'DeFiGuru', followers: 280000, credibility: 96, influence: 85, sentiment: 'neutral' },
  { name: 'BlockchainBear', followers: 180000, credibility: 78, influence: 72, sentiment: 'bearish' },
  { name: 'YieldFarmer', followers: 320000, credibility: 89, influence: 79, sentiment: 'bullish' },
]

const threatTypes = [
  { name: 'Phishing', value: 35, color: '#ef4444' },
  { name: 'Malware', value: 25, color: '#f97316' },
  { name: 'Social Engineering', value: 20, color: '#eab308' },
  { name: 'DDoS', value: 15, color: '#8b5cf6' },
  { name: 'Other', value: 5, color: '#6b7280' },
]

export const SecuritySentimentHub = ({ environment }: SecuritySentimentHubProps) => {
  const [mfaEnabled, setMfaEnabled] = useKV('security-mfa-enabled', true)
  const [biometricAuth, setBiometricAuth] = useKV('security-biometric-auth', false)
  const [ipWhitelist, setIpWhitelist] = useKV('security-ip-whitelist', [])
  const [sentimentSources, setSentimentSources] = useKV('sentiment-sources', ['twitter', 'reddit'])
  const [sentimentThreshold, setSentimentThreshold] = useKV('sentiment-threshold', [0.3])
  const [influencerTracking, setInfluencerTracking] = useKV('influencer-tracking', true)

  const [securityLevel, setSecurityLevel] = useState<'low' | 'medium' | 'high' | 'critical'>('high')
  const [sentimentScore, setSentimentScore] = useState(0.64)

  return (
    <div className="p-6 space-y-6 pt-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Lock size={32} className="text-primary" />
            Security & Sentiment Hub
          </h1>
          <p className="text-muted-foreground mt-1">
            Advanced Security Center + Sentiment Trading Analytics
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant={environment === 'test' ? 'secondary' : 'destructive'}>
            {environment === 'test' ? 'Secure Test' : 'Production Security'}
          </Badge>
          <Badge 
            variant={securityLevel === 'high' ? 'default' : 
                   securityLevel === 'medium' ? 'secondary' : 'destructive'}
            className="gap-1"
          >
            <Shield size={12} />
            {securityLevel.charAt(0).toUpperCase() + securityLevel.slice(1)} Security
          </Badge>
        </div>
      </div>

      {/* Quick Security & Sentiment Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Security Score</p>
                <p className="text-2xl font-bold">96%</p>
              </div>
              <ShieldCheck className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Threats Blocked</p>
                <p className="text-2xl font-bold">47</p>
              </div>
              <Shield className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Sentiment Score</p>
                <p className="text-2xl font-bold">{(sentimentScore * 100).toFixed(0)}%</p>
              </div>
              {sentimentScore > 0.6 ? 
                <TrendUp className="h-8 w-8 text-green-600" /> :
                <TrendDown className="h-8 w-8 text-red-600" />
              }
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Social Mentions</p>
                <p className="text-2xl font-bold">28.4K</p>
              </div>
              <ChatTeardrop className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security & Sentiment Tabs */}
      <Tabs defaultValue="security" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="security" className="gap-2">
            <Lock size={16} />
            Security Center
          </TabsTrigger>
          <TabsTrigger value="sentiment" className="gap-2">
            <ChatTeardrop size={16} />
            Sentiment Trading
          </TabsTrigger>
          <TabsTrigger value="social" className="gap-2">
            <Users size={16} />
            Social Analytics
          </TabsTrigger>
        </TabsList>

        {/* Security Center Tab */}
        <TabsContent value="security" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Authentication & Access */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key size={20} />
                  Authentication & Access
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <Label>Multi-Factor Authentication</Label>
                  <Switch
                    checked={mfaEnabled}
                    onCheckedChange={setMfaEnabled}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>Biometric Authentication</Label>
                  <Switch
                    checked={biometricAuth}
                    onCheckedChange={setBiometricAuth}
                  />
                </div>

                <div className="space-y-3">
                  <Label>Authentication Methods</Label>
                  <div className="space-y-2">
                    {[
                      'JWT + ArrowClockwise Tokens',
                      '2FA/TOTP',
                      'Hardware Keys (FIDO2)',
                      'Biometric (WebAuthn)',
                      'Zero-Knowledge Proofs'
                    ].map((method) => (
                      <div key={method} className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked className="rounded" />
                        <Label className="text-sm">{method}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Session Configuration</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Timeout (minutes)</Label>
                      <Input type="number" defaultValue="30" />
                    </div>
                    <div>
                      <Label className="text-xs">Max Sessions</Label>
                      <Input type="number" defaultValue="3" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Threat Detection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye size={20} />
                  Threat Detection
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-xl font-bold text-red-600">7</div>
                    <div className="text-sm text-muted-foreground">Active Threats</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-green-600">47</div>
                    <div className="text-sm text-muted-foreground">Blocked Today</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">99.2%</div>
                    <div className="text-sm text-muted-foreground">Detection Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">12ms</div>
                    <div className="text-sm text-muted-foreground">Response Time</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Threat Distribution</Label>
                  <ResponsiveContainer width="100%" height={150}>
                    <PieChart>
                      <Pie
                        data={threatTypes}
                        cx="50%"
                        cy="50%"
                        innerRadius={30}
                        outerRadius={60}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {threatTypes.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-2 gap-1 text-xs">
                    {threatTypes.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span>{item.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Security Events Timeline */}
          <Card>
            <CardHeader>
              <CardTitle>Security Events (24h)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={securityEvents}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="threats" stackId="1" stroke="#ef4444" fill="#ef4444" fillOpacity={0.6} name="Threats" />
                  <Area type="monotone" dataKey="blocked" stackId="1" stroke="#22c55e" fill="#22c55e" fillOpacity={0.6} name="Blocked" />
                  <Area type="monotone" dataKey="suspicious" stackId="1" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.6} name="Suspicious" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Access Control & IP Management */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe size={20} />
                  IP Whitelist & Geofencing
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <Label>IP Whitelist Management</Label>
                  <div className="space-y-2">
                    {['192.168.1.100', '10.0.0.50', '203.45.67.89'].map((ip, idx) => (
                      <div key={idx} className="flex justify-between items-center p-2 border rounded">
                        <span className="font-mono text-sm">{ip}</span>
                        <div className="flex gap-2">
                          <Badge variant="outline">Active</Badge>
                          <Button variant="destructive" size="sm">Remove</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input placeholder="Add IP address..." />
                    <Button>Add</Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Geographic Restrictions</Label>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Block Suspicious Countries</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">VPN/Proxy Detection</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Tor Network Blocking</span>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShieldCheck size={20} />
                  Role-Based Access Control
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <Label>User Roles</Label>
                  <div className="space-y-2">
                    {[
                      { role: 'Admin', users: 2, permissions: 'Full Access' },
                      { role: 'Trader', users: 8, permissions: 'Trading Only' },
                      { role: 'Analyst', users: 12, permissions: 'Read Only' },
                      { role: 'Guest', users: 25, permissions: 'Dashboard View' },
                    ].map((roleInfo, idx) => (
                      <div key={idx} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-medium">{roleInfo.role}</span>
                          <Badge variant="outline">{roleInfo.users} users</Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {roleInfo.permissions}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Recent Security Events</Label>
                  <div className="space-y-2">
                    {[
                      { event: 'Failed login attempt', user: '***@gmail.com', time: '2 min ago', severity: 'warning' },
                      { event: 'Successful 2FA login', user: 'admin@company.com', time: '15 min ago', severity: 'success' },
                      { event: 'IP whitelist violation', user: 'Unknown', time: '1 hour ago', severity: 'danger' },
                    ].map((event, idx) => (
                      <div key={idx} className="flex items-center gap-3 p-2 border rounded">
                        {event.severity === 'warning' && <WarningCircle size={16} className="text-orange-500" />}
                        {event.severity === 'success' && <CheckCircle size={16} className="text-green-500" />}
                        {event.severity === 'danger' && <WarningCircle size={16} className="text-red-500" />}
                        <div className="flex-1">
                          <div className="text-sm">{event.event}</div>
                          <div className="text-xs text-muted-foreground">{event.user} • {event.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Sentiment Trading Tab */}
        <TabsContent value="sentiment" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Sentiment Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ChatTeardrop size={20} />
                  Sentiment Analysis Config
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Data Sources</Label>
                  <div className="space-y-2">
                    {['twitter', 'reddit', 'telegram', 'discord', 'news'].map((source) => (
                      <div key={source} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={sentimentSources.includes(source)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSentimentSources([...sentimentSources, source])
                            } else {
                              setSentimentSources(sentimentSources.filter(s => s !== source))
                            }
                          }}
                          className="rounded"
                        />
                        <Label className="capitalize">{source}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Sentiment Threshold</Label>
                  <Slider
                    value={sentimentThreshold}
                    onValueChange={setSentimentThreshold}
                    max={1}
                    min={0}
                    step={0.1}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Alert threshold: {sentimentThreshold[0]}
                  </p>
                </div>

                <div className="space-y-3">
                  <Label>NLP Model Configuration</Label>
                  <Select defaultValue="finbert">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bert">BERT</SelectItem>
                      <SelectItem value="roberta">RoBERTa</SelectItem>
                      <SelectItem value="finbert">FinBERT</SelectItem>
                      <SelectItem value="custom">Custom Model</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <Label>Influencer Tracking</Label>
                  <Switch
                    checked={influencerTracking}
                    onCheckedChange={setInfluencerTracking}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Sentiment Triggers */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity size={20} />
                  Sentiment Triggers
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-lg font-bold text-green-600">+64%</div>
                    <div className="text-sm text-muted-foreground">Bullish</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-gray-600">22%</div>
                    <div className="text-sm text-muted-foreground">Neutral</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-red-600">14%</div>
                    <div className="text-sm text-muted-foreground">Bearish</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Active Triggers</Label>
                  <div className="space-y-2">
                    {[
                      { condition: 'Sentiment > 0.8', action: 'Buy Signal', status: 'active' },
                      { condition: 'Sentiment < 0.2', action: 'Sell Signal', status: 'active' },
                      { condition: 'SpeakerHigh Spike + Positive', action: 'High Confidence Buy', status: 'triggered' },
                      { condition: 'Influencer Negative', action: 'Risk Alert', status: 'inactive' },
                    ].map((trigger, idx) => (
                      <div key={idx} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">{trigger.condition}</span>
                          <Badge 
                            variant={trigger.status === 'active' ? 'default' : 
                                   trigger.status === 'triggered' ? 'secondary' : 'outline'}
                          >
                            {trigger.status}
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground">{trigger.action}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <Button className="w-full">Add New Trigger</Button>
              </CardContent>
            </Card>
          </div>

          {/* Sentiment Timeline */}
          <Card>
            <CardHeader>
              <CardTitle>Sentiment Analysis (24h)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={sentimentData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="sentiment" stroke="#8884d8" name="Sentiment Score" />
                  <Line type="monotone" dataKey="volume" stroke="#82ca9d" name="SpeakerHigh" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Price-Sentiment Correlation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendUp size={20} />
                Price-Sentiment Correlation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-lg font-bold">0.78</div>
                  <div className="text-sm text-muted-foreground">Correlation</div>
                </div>
                <div>
                  <div className="text-lg font-bold">89.3%</div>
                  <div className="text-sm text-muted-foreground">Accuracy</div>
                </div>
                <div>
                  <div className="text-lg font-bold">2.4h</div>
                  <div className="text-sm text-muted-foreground">Lead Time</div>
                </div>
                <div>
                  <div className="text-lg font-bold">+12.7%</div>
                  <div className="text-sm text-muted-foreground">Alpha Generated</div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Twitter Sentiment Weight</span>
                  <span>35%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Reddit Sentiment Weight</span>
                  <span>25%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>News Sentiment Weight</span>
                  <span>20%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Telegram Sentiment Weight</span>
                  <span>20%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Social Analytics Tab */}
        <TabsContent value="social" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Social Platform Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare size={20} />
                  Platform Analytics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {socialMetrics.map((platform) => (
                    <div key={platform.platform} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{platform.platform}</span>
                        <Badge 
                          variant={platform.sentiment > 0.6 ? 'default' : 'outline'}
                          className={platform.sentiment > 0.6 ? 'bg-green-100 text-green-800' : ''}
                        >
                          {platform.sentiment > 0.6 ? 'Bullish' : platform.sentiment > 0.4 ? 'Neutral' : 'Bearish'}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-sm text-muted-foreground">
                        <div>Sentiment: {(platform.sentiment * 100).toFixed(0)}%</div>
                        <div>Mentions: {(platform.mentions / 1000).toFixed(1)}K</div>
                        <div>Engagement: {platform.engagement}%</div>
                      </div>
                      <Progress value={platform.sentiment * 100} className="mt-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Influencer Tracking */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users size={20} />
                  Influencer Tracking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {influencerData.map((influencer) => (
                    <div key={influencer.name} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{influencer.name}</span>
                        <Badge 
                          variant={influencer.sentiment === 'bullish' ? 'default' : 
                                 influencer.sentiment === 'bearish' ? 'destructive' : 'outline'}
                        >
                          {influencer.sentiment}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground mb-2">
                        <div>Followers: {(influencer.followers / 1000).toFixed(0)}K</div>
                        <div>Credibility: {influencer.credibility}%</div>
                        <div>Influence: {influencer.influence}%</div>
                      </div>
                      <div className="flex gap-1">
                        <Progress value={influencer.credibility} className="flex-1" />
                        <Progress value={influencer.influence} className="flex-1" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Social SpeakerHigh & Engagement */}
          <Card>
            <CardHeader>
              <CardTitle>Social SpeakerHigh & Engagement</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={sentimentData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="mentions" fill="#8884d8" name="Mentions" />
                  <Bar dataKey="volume" fill="#82ca9d" name="SpeakerHigh" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Social Sentiment Heatmap */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart size={20} />
                  Engagement Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-xl font-bold">1.2M</div>
                    <div className="text-sm text-muted-foreground">Total Reach</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">89K</div>
                    <div className="text-sm text-muted-foreground">Interactions</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">7.4%</div>
                    <div className="text-sm text-muted-foreground">Engagement Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">12.3K</div>
                    <div className="text-sm text-muted-foreground">ShareNetworks</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Likes</span>
                    <span>45.2K</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Comments</span>
                    <span>23.8K</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Retweets/ShareNetworks</span>
                    <span>12.3K</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Mentions</span>
                    <span>8.1K</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShareNetwork size={20} />
                  Viral Content Tracker
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    { content: 'Bitcoin ETF approval rumors spreading...', score: 8.7, platform: 'Twitter' },
                    { content: 'Major DeFi protocol announces v3...', score: 7.2, platform: 'Reddit' },
                    { content: 'Whale wallet movements detected...', score: 9.1, platform: 'Telegram' },
                  ].map((item, idx) => (
                    <div key={idx} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <Badge variant="outline">{item.platform}</Badge>
                        <span className="text-sm font-medium">Score: {item.score}/10</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{item.content}</p>
                      <Progress value={item.score * 10} className="mt-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

