import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  CheckCircle, 
  AlertCircle, 
  Shield, 
  Zap, 
  Database, 
  Globe, 
  TrendingUp,
  Settings,
  Play,
  Stop,
  RefreshCw,
  Activity
} from 'lucide-react'
import { CredentialsSetupPanel } from '../configuration/CredentialsSetupPanel'
import { credentialsManager } from '../../services/CredentialsManager'
import { realDeFiService } from '../../services/RealDeFiService'

interface ProductionStatus {
  credentialsReady: boolean
  connectionsActive: boolean
  dataSource: 'real' | 'mixed' | 'simulated'
  opportunitiesFound: number
  lastExecution: number
  systemHealth: 'healthy' | 'degraded' | 'critical'
}

export const ProductionPanel: React.FC = () => {
  const [status, setStatus] = useState<ProductionStatus>({
    credentialsReady: false,
    connectionsActive: false,
    dataSource: 'simulated',
    opportunitiesFound: 0,
    lastExecution: 0,
    systemHealth: 'critical'
  })
  const [isRunning, setIsRunning] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [opportunities, setOpportunities] = useState<any[]>([])
  const [connections, setConnections] = useState<any[]>([])

  useEffect(() => {
    checkSystemStatus()
    const interval = setInterval(checkSystemStatus, 5000)
    return () => clearInterval(interval)
  }, [])

  const checkSystemStatus = async () => {
    try {
      // Verificar credenciales
      const credentialsStats = credentialsManager.getCredentialsStats()
      const credentialsReady = credentialsStats.missing === 0

      // Verificar conexiones
      const connectionStatus = realDeFiService.getConnectionStatus()
      const connectionsActive = connectionStatus.filter(c => c.connected).length >= 2

      // Verificar fuente de datos
      const systemStats = realDeFiService.getSystemStats()
      const dataSource = systemStats.dataSource

      // Verificar oportunidades
      const currentOpportunities = await realDeFiService.findArbitrageOpportunities()
      const opportunitiesFound = currentOpportunities.length

      // Determinar salud del sistema
      let systemHealth: 'healthy' | 'degraded' | 'critical' = 'critical'
      if (credentialsReady && connectionsActive && dataSource === 'real') {
        systemHealth = 'healthy'
      } else if (credentialsReady && connectionsActive) {
        systemHealth = 'degraded'
      }

      setStatus({
        credentialsReady,
        connectionsActive,
        dataSource,
        opportunitiesFound,
        lastExecution: Date.now(),
        systemHealth
      })

      setConnections(connectionStatus)
      setOpportunities(currentOpportunities)
    } catch (error) {
      console.error('Error checking system status:', error)
    }
  }

  const startProduction = async () => {
    setIsLoading(true)
    try {
      // Verificar que el sistema esté listo
      const productionReady = await credentialsManager.isProductionReady()
      if (!productionReady.ready) {
        alert(`Sistema no listo para producción:\n${productionReady.issues.join('\n')}`)
        return
      }

      setIsRunning(true)
      // Aquí se iniciaría el sistema de producción real
      console.log('🚀 Sistema de producción iniciado')
    } catch (error) {
      console.error('Error starting production:', error)
      alert('Error al iniciar producción')
    } finally {
      setIsLoading(false)
    }
  }

  const stopProduction = () => {
    setIsRunning(false)
    console.log('⏹️ Sistema de producción detenido')
  }

  const getStatusBadge = (health: string) => {
    switch (health) {
      case 'healthy':
        return <Badge variant="default" className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Saludable</Badge>
      case 'degraded':
        return <Badge variant="secondary"><AlertCircle className="h-3 w-3 mr-1" />Degradado</Badge>
      case 'critical':
        return <Badge variant="destructive"><AlertCircle className="h-3 w-3 mr-1" />Crítico</Badge>
      default:
        return <Badge variant="outline">Desconocido</Badge>
    }
  }

  const getDataSourceBadge = (source: string) => {
    switch (source) {
      case 'real':
        return <Badge variant="default" className="bg-green-500">Datos Reales</Badge>
      case 'mixed':
        return <Badge variant="secondary">Datos Mixtos</Badge>
      case 'simulated':
        return <Badge variant="destructive">Datos Simulados</Badge>
      default:
        return <Badge variant="outline">Desconocido</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Header con estado del sistema */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Panel de Producción
            </div>
            {getStatusBadge(status.systemHealth)}
          </CardTitle>
          <CardDescription>
            Sistema de arbitraje DeFi con datos reales
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{status.opportunitiesFound}</div>
              <div className="text-sm text-muted-foreground">Oportunidades</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{connections.filter(c => c.connected).length}</div>
              <div className="text-sm text-muted-foreground">Conexiones Activas</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">
                {getDataSourceBadge(status.dataSource)}
              </div>
              <div className="text-sm text-muted-foreground">Fuente de Datos</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">
                {isRunning ? (
                  <Badge variant="default" className="bg-green-500">
                    <Play className="h-3 w-3 mr-1" />Activo
                  </Badge>
                ) : (
                  <Badge variant="secondary">
                    <Stop className="h-3 w-3 mr-1" />Detenido
                  </Badge>
                )}
              </div>
              <div className="text-sm text-muted-foreground">Estado</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Alertas del sistema */}
      {status.systemHealth === 'critical' && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Sistema no listo para producción.</strong> Configura las credenciales requeridas para conectar con servicios reales.
          </AlertDescription>
        </Alert>
      )}

      {status.dataSource === 'simulated' && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Datos simulados detectados.</strong> El sistema está operando con datos de prueba. Configura credenciales reales para producción.
          </AlertDescription>
        </Alert>
      )}

      {/* Controles principales */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Controles de Producción
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Button 
              onClick={startProduction}
              disabled={!status.credentialsReady || isLoading}
              className="flex-1"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Iniciando...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Iniciar Producción
                </>
              )}
            </Button>
            <Button 
              onClick={stopProduction}
              disabled={!isRunning}
              variant="destructive"
              className="flex-1"
            >
              <Stop className="h-4 w-4 mr-2" />
              Detener Producción
            </Button>
            <Button 
              onClick={checkSystemStatus}
              variant="outline"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Actualizar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabs principales */}
      <Tabs defaultValue="credentials" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="credentials">Credenciales</TabsTrigger>
          <TabsTrigger value="connections">Conexiones</TabsTrigger>
          <TabsTrigger value="opportunities">Oportunidades</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoreo</TabsTrigger>
        </TabsList>

        <TabsContent value="credentials" className="space-y-4">
          <CredentialsSetupPanel />
        </TabsContent>

        <TabsContent value="connections" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Estado de Conexiones Blockchain
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {connections.map(connection => (
                  <div key={connection.blockchain} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${connection.connected ? 'bg-green-500' : 'bg-red-500'}`} />
                      <div>
                        <div className="font-medium capitalize">{connection.blockchain}</div>
                        <div className="text-sm text-muted-foreground">
                          {connection.connected ? `Latencia: ${connection.latency}ms` : connection.error}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={connection.connected ? 'default' : 'destructive'}>
                        {connection.connected ? 'Conectado' : 'Desconectado'}
                      </Badge>
                      {connection.connected && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Bloque: {connection.lastBlock.toLocaleString()}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="opportunities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Oportunidades de Arbitraje
              </CardTitle>
              <CardDescription>
                {opportunities.length} oportunidades detectadas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {opportunities.slice(0, 10).map(opportunity => (
                  <div key={opportunity.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <div className="font-medium">
                        {opportunity.tokenA} → {opportunity.tokenB}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {opportunity.dexA} → {opportunity.dexB} • {opportunity.blockchain}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600">
                        +{opportunity.profitPercentage.toFixed(2)}%
                      </div>
                      <div className="text-sm text-muted-foreground">
                        ${opportunity.estimatedProfit.toFixed(2)}
                      </div>
                      <Badge variant={opportunity.risk === 'high' ? 'destructive' : opportunity.risk === 'medium' ? 'secondary' : 'default'}>
                        {opportunity.risk}
                      </Badge>
                    </div>
                  </div>
                ))}
                {opportunities.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    No se encontraron oportunidades de arbitraje
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Monitoreo del Sistema
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Métricas de rendimiento */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Métricas de Rendimiento</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">
                        {connections.filter(c => c.connected).length}/{connections.length}
                      </div>
                      <div className="text-sm text-muted-foreground">Conexiones</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {connections.filter(c => c.connected).reduce((sum, c) => sum + c.latency, 0) / Math.max(connections.filter(c => c.connected).length, 1)}ms
                      </div>
                      <div className="text-sm text-muted-foreground">Latencia Promedio</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {opportunities.length}
                      </div>
                      <div className="text-sm text-muted-foreground">Oportunidades</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">
                        {status.lastExecution ? new Date(status.lastExecution).toLocaleTimeString() : 'N/A'}
                      </div>
                      <div className="text-sm text-muted-foreground">Última Ejecución</div>
                    </div>
                  </div>
                </div>

                {/* Estado de credenciales */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Estado de Credenciales</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span>Credenciales Configuradas</span>
                      <Badge variant={status.credentialsReady ? 'default' : 'destructive'}>
                        {status.credentialsReady ? 'Completo' : 'Incompleto'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Conexiones Activas</span>
                      <Badge variant={status.connectionsActive ? 'default' : 'destructive'}>
                        {status.connectionsActive ? 'Conectado' : 'Desconectado'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Fuente de Datos</span>
                      {getDataSourceBadge(status.dataSource)}
                    </div>
                  </div>
                </div>

                {/* Progreso hacia producción */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Progreso hacia Producción</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span>Configuración Completa</span>
                      <Badge variant={status.credentialsReady ? 'default' : 'secondary'}>
                        {status.credentialsReady ? '✅' : '⏳'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Conexiones Estables</span>
                      <Badge variant={status.connectionsActive ? 'default' : 'secondary'}>
                        {status.connectionsActive ? '✅' : '⏳'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Datos Reales</span>
                      <Badge variant={status.dataSource === 'real' ? 'default' : 'secondary'}>
                        {status.dataSource === 'real' ? '✅' : '⏳'}
                      </Badge>
                    </div>
                  </div>
                  <Progress 
                    value={
                      [status.credentialsReady, status.connectionsActive, status.dataSource === 'real']
                        .filter(Boolean).length / 3 * 100
                    } 
                    className="mt-4" 
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 