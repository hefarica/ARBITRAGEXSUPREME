import React from 'react'
import SecurityControlPanel from '../security/SecurityControlPanel'

interface SecuritySentimentHubProps {
  environment: 'test' | 'prod'
}

export default function SecuritySentimentHub({ environment }: SecuritySentimentHubProps) {
  return (
    <div className="space-y-6">
      {/* Zero-Trust Security Control Panel */}
      <SecurityControlPanel environment={environment} />
    </div>
  )
}