import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { 
  CheckCircle, 
  WarningCircle, 
  XCircle, 
  Spinner, 
  Play, 
  Gear,
  Shield,
  Database,
  Globe,
  Brain,
  Lightning
} from '@phosphor-icons/react'
import { useKV } from '@/hooks/useKV'
import { toast } from 'sonner'

interface SystemValidationProps {
  environment: 'test' | 'prod'
}

interface ValidationItem {
  id: string
  category: string
  name: string
  description: string
  status: 'pending' | 'checking' | 'success' | 'warning' | 'error'
  message?: string
  details?: any
  critical: boolean
}

interface SystemHealth {
  overall: number
  critical: number
  warnings: number
  passed: number
  total: number
}

const SystemValidation: React.FC<SystemValidationProps> = ({ environment }) => {
  const [validationItems, setValidationItems] = useState<ValidationItem[]>([])
  const [isValidating, setIsValidating] = useState(false)
  const [systemHealth, setSystemHealth] = useState<SystemHealth>({
    overall: 0,
    critical: 0,
    warnings: 0,
    passed: 0,
    total: 0
  })
  const [readyToStart, setReadyToStart] = useState(false)
  const [validationProgress, setValidationProgress] = useState(0)

  // Configuration states from KV
  const [blockchainConfigs] = useKV('blockchain-configs', {})
  const [aiConfigs] = useKV('ai-configs', {})
  const [databaseConfigs] = useKV('database-configs', {})
  const [notificationConfigs] = useKV('notification-configs', {})
  const [mevConfigs] = useKV('mev-configs', {})
  const [securityConfigs] = useKV('security-configs', {})

  // Initialize validation items
  useEffect(() => {
    const items: ValidationItem[] = [
      // Blockchain validations
      {
        id: 'blockchain-ethereum',
        category: 'Blockchain',
        name: 'Ethereum Connection',
        description: 'Verificar conectividad con red Ethereum',
        status: 'pending',
        critical: true
      },
      {
        id: 'blockchain-polygon',
        category: 'Blockchain',
        name: 'Polygon Connection',
        description: 'Verificar conectividad con red Polygon',
        status: 'pending',
        critical: false
      },
      {
        id: 'blockchain-bsc',
        category: 'Blockchain',
        name: 'BSC Connection',
        description: 'Verificar conectividad con Binance Smart Chain',
        status: 'pending',
        critical: false
      },
      // Database validations
      {
        id: 'database-mongodb',
        category: 'Database',
        name: 'MongoDB Connection',
        description: 'Verificar conexión a base de datos principal',
        status: 'pending',
        critical: true
      },
      {
        id: 'database-redis',
        category: 'Database',
        name: 'Redis Cache',
        description: 'Verificar conexión a caché Redis',
        status: 'pending',
        critical: true
      },
      // Security validations
      {
        id: 'security-jwt',
        category: 'Security',
        name: 'JWT Authentication',
        description: 'Verificar configuración JWT',
        status: 'pending',
        critical: true
      },
      {
        id: 'security-encryption',
        category: 'Security',
        name: 'AES Encryption',
        description: 'Verificar cifrado AES-256-GCM',
        status: 'pending',
        critical: true
      },
      // AI/LLM validations
      {
        id: 'ai-openai',
        category: 'AI/LLM',
        name: 'OpenAI API',
        description: 'Verificar conectividad con OpenAI',
        status: 'pending',
        critical: false
      },
      // MEV Protection validations
      {
        id: 'mev-flashbots',
        category: 'MEV Protection',
        name: 'Flashbots Relay',
        description: 'Verificar conexión con Flashbots',
        status: 'pending',
        critical: false
      },
      // Notification validations
      {
        id: 'notification-telegram',
        category: 'Notifications',
        name: 'Telegram Bot',
        description: 'Verificar configuración de Telegram',
        status: 'pending',
        critical: false
      },
      // System health validations
      {
        id: 'system-memory',
        category: 'System',
        name: 'Memory Usage',
        description: 'Verificar uso de memoria del sistema',
        status: 'pending',
        critical: false
      },
      {
        id: 'system-cpu',
        category: 'System',
        name: 'CPU Usage',
        description: 'Verificar uso de CPU del sistema',
        status: 'pending',
        critical: false
      },
      {
        id: 'system-disk',
        category: 'System',
        name: 'Disk Space',
        description: 'Verificar espacio en disco disponible',
        status: 'pending',
        critical: false
      }
    ]
    
    setValidationItems(items)
  }, [])

  // Calculate system health
  useEffect(() => {
    const total = validationItems.length
    const passed = validationItems.filter(item => item.status === 'success').length
    const warnings = validationItems.filter(item => item.status === 'warning').length
    const critical = validationItems.filter(item => item.status === 'error' && item.critical).length
    const overall = total > 0 ? Math.round((passed / total) * 100) : 0
    
    setSystemHealth({ overall, critical, warnings, passed, total })
    setReadyToStart(critical === 0 && passed >= Math.ceil(total * 0.7)) // At least 70% passed, no critical errors
  }, [validationItems])

  // Mock validation function
  const performValidation = async (item: ValidationItem): Promise<ValidationItem> => {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 500))
    
    // Mock validation logic based on configurations
    let status: 'success' | 'warning' | 'error' = 'success'
    let message = 'Validation successful'
    let details = {}

    switch (item.id) {
      case 'blockchain-ethereum':
        const ethConfig = blockchainConfigs['ethereum']
        if (!ethConfig?.enabled) {
          status = 'warning'
          message = 'Ethereum not configured or disabled'
        } else if (!ethConfig?.rpc_primary) {
          status = 'error'
          message = 'Missing RPC URL'
        } else {
          details = { rpc: ethConfig.rpc_primary, chainId: ethConfig.chain_id }
        }
        break
        
      case 'database-mongodb':
        const mongoConfig = databaseConfigs['mongodb']
        if (!mongoConfig?.enabled) {
          status = 'error'
          message = 'MongoDB not configured'
        } else if (!mongoConfig?.connection_string) {
          status = 'error'
          message = 'Missing connection string'
        } else {
          details = { maxConnections: mongoConfig.max_connections }
        }
        break
        
      case 'security-jwt':
        const jwtConfig = securityConfigs['jwt']
        if (!jwtConfig?.enabled) {
          status = 'error'
          message = 'JWT authentication not configured'
        } else {
          details = { algorithm: 'RS256', enabled: true }
        }
        break
        
      case 'ai-openai':
        const openaiConfig = aiConfigs['openai']
        if (!openaiConfig?.enabled) {
          status = 'warning'
          message = 'OpenAI not configured'
        } else if (!openaiConfig?.api_key) {
          status = 'warning'
          message = 'Missing API key'
        } else {
          details = { model: openaiConfig.model }
        }
        break
        
      case 'mev-flashbots':
        const flashbotsConfig = mevConfigs['flashbots']
        if (!flashbotsConfig?.enabled) {
          status = 'warning'
          message = 'Flashbots protection not enabled'
        } else {
          details = { relayUrl: flashbotsConfig.relay_url }
        }
        break
        
      case 'system-memory':
        // Simulate memory check
        const memoryUsage = Math.random() * 100
        if (memoryUsage > 90) {
          status = 'error'
          message = `High memory usage: ${memoryUsage.toFixed(1)}%`
        } else if (memoryUsage > 75) {
          status = 'warning'
          message = `Moderate memory usage: ${memoryUsage.toFixed(1)}%`
        } else {
          message = `Memory usage: ${memoryUsage.toFixed(1)}%`
        }
        details = { usage: memoryUsage }
        break
        
      default:
        // Random validation for other items
        const random = Math.random()
        if (random < 0.1) {
          status = 'error'
          message = 'Validation failed'
        } else if (random < 0.3) {
          status = 'warning'
          message = 'Validation completed with warnings'
        }
    }

    return {
      ...item,
      status,
      message,
      details
    }
  }

  // Run all validations
  const runValidations = async () => {
    setIsValidating(true)
    setValidationProgress(0)
    
    // Reset all items to checking state
    setValidationItems(items => items.map(item => ({ ...item, status: 'checking' as const })))
    
    try {
      for (let i = 0; i < validationItems.length; i++) {
        const item = validationItems[i]
        
        // Update current item to checking
        setValidationItems(items => 
          items.map(it => it.id === item.id ? { ...it, status: 'checking' } : it)
        )
        
        // Perform validation
        const result = await performValidation(item)
        
        // Update with result
        setValidationItems(items => 
          items.map(it => it.id === item.id ? result : it)
        )
        
        // Update progress
        setValidationProgress(Math.round(((i + 1) / validationItems.length) * 100))
        
        // Show toast for critical errors
        if (result.status === 'error' && result.critical) {
          toast.error(`Critical error: ${result.name} - ${result.message}`)
        }
      }
      
      toast.success('System validation completed')
    } catch (error) {
      toast.error('Validation process failed')
      console.error('Validation error:', error)
    } finally {
      setIsValidating(false)
    }
  }

  // Status icon component
  const StatusIcon = ({ status }: { status: string }) => {
    switch (status) {
      case 'success':
        return <CheckCircle size={20} className="text-green-500" />
      case 'warning':
        return <WarningCircle size={20} className="text-yellow-500" />
      case 'error':
        return <XCircle size={20} className="text-red-500" />
      case 'checking':
        return <Spinner size={20} className="text-blue-500 animate-spin" />
      default:
        return <div className="w-5 h-5 rounded-full border-2 border-gray-300" />
    }
  }

  // Category icon component
  const CategoryIcon = ({ category }: { category: string }) => {
    switch (category) {
      case 'Blockchain':
        return <Globe size={16} />
      case 'Database':
        return <Database size={16} />
      case 'Security':
        return <Shield size={16} />
      case 'AI/LLM':
        return <Brain size={16} />
      case 'MEV Protection':
        return <Shield size={16} />
      case 'Notifications':
        return <Lightning size={16} />
      case 'System':
        return <Gear size={16} />
      default:
        return <Gear size={16} />
    }
  }

  // Group items by category
  const groupedItems = validationItems.reduce((groups, item) => {
    const category = item.category
    if (!groups[category]) {
      groups[category] = []
    }
    groups[category].push(item)
    return groups
  }, {} as Record<string, ValidationItem[]>)

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Gear size={24} />
                System Validation - {environment.toUpperCase()}
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Verificación completa del sistema antes del inicio
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Button 
                onClick={runValidations}
                disabled={isValidating}
                variant="outline"
              >
                {isValidating ? 'Validating...' : 'Run Validation'}
              </Button>
              <Button 
                disabled={!readyToStart || isValidating}
                className="gap-2"
              >
                <Play size={16} />
                Start ArbitrageX
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{systemHealth.overall}%</div>
              <div className="text-sm text-muted-foreground">Overall Health</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-500">{systemHealth.passed}</div>
              <div className="text-sm text-muted-foreground">Passed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-500">{systemHealth.warnings}</div>
              <div className="text-sm text-muted-foreground">Warnings</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-500">{systemHealth.critical}</div>
              <div className="text-sm text-muted-foreground">Critical Errors</div>
            </div>
          </div>
          {isValidating && (
            <div className="mt-4">
              <Progress value={validationProgress} className="w-full" />
              <p className="text-sm text-muted-foreground mt-2 text-center">
                Validating system components... {validationProgress}%
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* System Status */}
      <Card>
        <CardHeader>
          <CardTitle>System Readiness</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              {readyToStart ? (
                <CheckCircle size={24} className="text-green-500" />
              ) : (
                <WarningCircle size={24} className="text-yellow-500" />
              )}
              <div>
                <div className="font-medium">
                  {readyToStart ? 'System Ready' : 'System Not Ready'}
                </div>
                <div className="text-sm text-muted-foreground">
                  {readyToStart 
                    ? 'All critical components validated successfully'
                    : 'Some critical components need attention'
                  }
                </div>
              </div>
            </div>
            <Badge variant={readyToStart ? 'default' : 'destructive'}>
              {readyToStart ? 'Ready to Start' : 'Not Ready'}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Validation Results */}
      <Card>
        <CardHeader>
          <CardTitle>Validation Results</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All ({validationItems.length})</TabsTrigger>
              <TabsTrigger value="errors">
                Errors ({validationItems.filter(i => i.status === 'error').length})
              </TabsTrigger>
              <TabsTrigger value="warnings">
                Warnings ({validationItems.filter(i => i.status === 'warning').length})
              </TabsTrigger>
              <TabsTrigger value="success">
                Passed ({validationItems.filter(i => i.status === 'success').length})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="space-y-4">
              <ScrollArea className="h-96">
                {Object.entries(groupedItems).map(([category, items]) => (
                  <div key={category} className="space-y-2 mb-6">
                    <div className="flex items-center gap-2 font-medium text-sm border-b pb-2">
                      <CategoryIcon category={category} />
                      {category}
                    </div>
                    {items.map(item => (
                      <div 
                        key={item.id} 
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50"
                      >
                        <div className="flex items-center gap-3">
                          <StatusIcon status={item.status} />
                          <div>
                            <div className="font-medium text-sm">{item.name}</div>
                            <div className="text-xs text-muted-foreground">{item.description}</div>
                            {item.message && (
                              <div className={`text-xs mt-1 ${
                                item.status === 'error' ? 'text-red-500' :
                                item.status === 'warning' ? 'text-yellow-500' :
                                'text-green-500'
                              }`}>
                                {item.message}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {item.critical && (
                            <Badge variant="destructive" className="text-xs">Critical</Badge>
                          )}
                          <Badge variant="outline" className="text-xs">
                            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </ScrollArea>
            </TabsContent>
            
            {/* Error Tab */}
            <TabsContent value="errors">
              <ScrollArea className="h-96">
                {validationItems.filter(item => item.status === 'error').map(item => (
                  <div key={item.id} className="p-3 border border-red-200 rounded-lg mb-2 bg-red-50">
                    <div className="flex items-center gap-2 font-medium text-red-700">
                      <XCircle size={16} />
                      {item.name}
                      {item.critical && <Badge variant="destructive" className="text-xs">Critical</Badge>}
                    </div>
                    <div className="text-sm text-red-600 mt-1">{item.message}</div>
                    <div className="text-xs text-red-500 mt-1">{item.description}</div>
                  </div>
                ))}
              </ScrollArea>
            </TabsContent>
            
            {/* Warning Tab */}
            <TabsContent value="warnings">
              <ScrollArea className="h-96">
                {validationItems.filter(item => item.status === 'warning').map(item => (
                  <div key={item.id} className="p-3 border border-yellow-200 rounded-lg mb-2 bg-yellow-50">
                    <div className="flex items-center gap-2 font-medium text-yellow-700">
                      <WarningCircle size={16} />
                      {item.name}
                    </div>
                    <div className="text-sm text-yellow-600 mt-1">{item.message}</div>
                    <div className="text-xs text-yellow-500 mt-1">{item.description}</div>
                  </div>
                ))}
              </ScrollArea>
            </TabsContent>
            
            {/* Success Tab */}
            <TabsContent value="success">
              <ScrollArea className="h-96">
                {validationItems.filter(item => item.status === 'success').map(item => (
                  <div key={item.id} className="p-3 border border-green-200 rounded-lg mb-2 bg-green-50">
                    <div className="flex items-center gap-2 font-medium text-green-700">
                      <CheckCircle size={16} />
                      {item.name}
                    </div>
                    <div className="text-sm text-green-600 mt-1">{item.message}</div>
                    <div className="text-xs text-green-500 mt-1">{item.description}</div>
                  </div>
                ))}
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

export default SystemValidation