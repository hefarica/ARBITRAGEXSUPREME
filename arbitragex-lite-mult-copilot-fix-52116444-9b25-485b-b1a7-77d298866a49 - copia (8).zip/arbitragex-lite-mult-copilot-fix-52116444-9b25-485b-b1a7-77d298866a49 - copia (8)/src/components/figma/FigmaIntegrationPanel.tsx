import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Alert, AlertDescription } from '../ui/alert';
import { Loader2, Download, Search, RefreshCw, FileImage } from 'lucide-react';

interface FigmaAsset {
  id: string;
  name: string;
  url: string;
  format: 'png' | 'jpg' | 'svg' | 'pdf';
  scale: number;
}

interface FigmaDesign {
  id: string;
  name: string;
  lastModified: string;
  thumbnailUrl: string;
  version: string;
}

interface FigmaComponent {
  id: string;
  name: string;
  description: string;
  key: string;
}

export const FigmaIntegrationPanel: React.FC = () => {
  const [fileId, setFileId] = useState('');
  const [accessToken, setAccessToken] = useState('');
  const [fileInfo, setFileInfo] = useState<FigmaDesign | null>(null);
  const [components, setComponents] = useState<FigmaComponent[]>([]);
  const [selectedComponents, setSelectedComponents] = useState<string[]>([]);
  const [assets, setAssets] = useState<FigmaAsset[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [format, setFormat] = useState<'png' | 'jpg' | 'svg' | 'pdf'>('png');
  const [scale, setScale] = useState<number>(2);

  // Cargar token desde localStorage
  useEffect(() => {
    const savedToken = localStorage.getItem('figma_access_token');
    if (savedToken) {
      setAccessToken(savedToken);
    }
  }, []);

  // Guardar token en localStorage
  const saveToken = (token: string) => {
    localStorage.setItem('figma_access_token', token);
    setAccessToken(token);
  };

  // Obtener información del archivo
  const getFileInfo = async () => {
    if (!fileId || !accessToken) {
      setError('File ID y Access Token son requeridos');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/figma/file/${fileId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error('Error obteniendo información del archivo');
      }

      const data = await response.json();
      setFileInfo(data.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido');
    } finally {
      setLoading(false);
    }
  };

  // Listar componentes
  const listComponents = async () => {
    if (!fileId || !accessToken) return;

    setLoading(true);
    try {
      const response = await fetch(`/api/figma/components/${fileId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setComponents(data.data);
      }
    } catch (err) {
      setError('Error listando componentes');
    } finally {
      setLoading(false);
    }
  };

  // Obtener assets
  const getAssets = async () => {
    if (!fileId || !accessToken || selectedComponents.length === 0) {
      setError('Selecciona al menos un componente');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/figma/assets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          fileId,
          nodeIds: selectedComponents,
          format,
          scale
        })
      });

      if (!response.ok) {
        throw new Error('Error obteniendo assets');
      }

      const data = await response.json();
      setAssets(data.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido');
    } finally {
      setLoading(false);
    }
  };

  // Sincronizar assets
  const syncAssets = async () => {
    if (!fileId || !accessToken) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/figma/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          fileId,
          outputDir: 'frontend/images/figma-assets'
        })
      });

      if (!response.ok) {
        throw new Error('Error en sincronización');
      }

      const data = await response.json();
      if (data.success) {
        setError(null);
        // Recargar componentes y assets
        await listComponents();
      } else {
        setError(data.message);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido');
    } finally {
      setLoading(false);
    }
  };

  // Buscar componentes
  const searchComponents = async () => {
    if (!fileId || !accessToken || !searchTerm) return;

    setLoading(true);
    try {
      const response = await fetch(`/api/figma/search/${fileId}?q=${encodeURIComponent(searchTerm)}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setComponents(data.data);
      }
    } catch (err) {
      setError('Error en búsqueda');
    } finally {
      setLoading(false);
    }
  };

  // Seleccionar/deseleccionar componente
  const toggleComponent = (componentId: string) => {
    setSelectedComponents(prev => 
      prev.includes(componentId)
        ? prev.filter(id => id !== componentId)
        : [...prev, componentId]
    );
  };

  // Descargar asset individual
  const downloadAsset = (asset: FigmaAsset) => {
    const link = document.createElement('a');
    link.href = asset.url;
    link.download = `${asset.name}_${asset.id}.${asset.format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileImage className="h-5 w-5" />
            Integración con Figma
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Configuración */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="access-token">Access Token de Figma</Label>
              <Input
                id="access-token"
                type="password"
                placeholder="Ingresa tu access token"
                value={accessToken}
                onChange={(e) => setAccessToken(e.target.value)}
              />
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => saveToken(accessToken)}
              >
                Guardar Token
              </Button>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="file-id">File ID de Figma</Label>
              <Input
                id="file-id"
                placeholder="Ej: abcdefghijklmnop"
                value={fileId}
                onChange={(e) => setFileId(e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={getFileInfo} disabled={loading || !fileId || !accessToken}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
              Obtener Info
            </Button>
            <Button onClick={listComponents} disabled={loading || !fileId || !accessToken}>
              Listar Componentes
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Información del archivo */}
      {fileInfo && (
        <Card>
          <CardHeader>
            <CardTitle>Información del Archivo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Nombre</Label>
                <p className="font-medium">{fileInfo.name}</p>
              </div>
              <div>
                <Label>Versión</Label>
                <p className="font-medium">{fileInfo.version}</p>
              </div>
              <div>
                <Label>Última modificación</Label>
                <p className="font-medium">
                  {new Date(fileInfo.lastModified).toLocaleDateString()}
                </p>
              </div>
              <div>
                <Label>ID del archivo</Label>
                <p className="font-medium font-mono text-sm">{fileInfo.id}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Componentes y Assets */}
      <Tabs defaultValue="components" className="w-full">
        <TabsList>
          <TabsTrigger value="components">Componentes</TabsTrigger>
          <TabsTrigger value="assets">Assets</TabsTrigger>
        </TabsList>

        <TabsContent value="components" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Componentes del Archivo</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Búsqueda */}
              <div className="flex gap-2 mb-4">
                <Input
                  placeholder="Buscar componentes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Button onClick={searchComponents} disabled={loading}>
                  <Search className="h-4 w-4" />
                </Button>
              </div>

              {/* Lista de componentes */}
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {components.map((component) => (
                  <div
                    key={component.id}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      selectedComponents.includes(component.id)
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => toggleComponent(component.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{component.name}</p>
                        {component.description && (
                          <p className="text-sm text-gray-600">{component.description}</p>
                        )}
                      </div>
                      <Badge variant={selectedComponents.includes(component.id) ? "default" : "secondary"}>
                        {selectedComponents.includes(component.id) ? "Seleccionado" : "No seleccionado"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>

              {components.length === 0 && (
                <p className="text-center text-gray-500 py-4">
                  No hay componentes disponibles
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assets" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Assets</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Formato</Label>
                  <Select value={format} onValueChange={(value: any) => setFormat(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="png">PNG</SelectItem>
                      <SelectItem value="jpg">JPG</SelectItem>
                      <SelectItem value="svg">SVG</SelectItem>
                      <SelectItem value="pdf">PDF</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Escala</Label>
                  <Select value={scale.toString()} onValueChange={(value) => setScale(Number(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1x</SelectItem>
                      <SelectItem value="2">2x</SelectItem>
                      <SelectItem value="3">3x</SelectItem>
                      <SelectItem value="4">4x</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Acciones</Label>
                  <div className="flex gap-2">
                    <Button onClick={getAssets} disabled={loading || selectedComponents.length === 0}>
                      Obtener Assets
                    </Button>
                    <Button onClick={syncAssets} disabled={loading}>
                      Sincronizar Todo
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Lista de assets */}
          {assets.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Assets Disponibles ({assets.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {assets.map((asset) => (
                    <div key={asset.id} className="border rounded-lg p-4 space-y-3">
                      <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
                        <FileImage className="h-8 w-8 text-gray-400" />
                      </div>
                      <div className="space-y-2">
                        <p className="font-medium text-sm">{asset.name}</p>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <Badge variant="outline">{asset.format.toUpperCase()}</Badge>
                          <Badge variant="outline">{asset.scale}x</Badge>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => downloadAsset(asset)}
                          className="w-full"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Descargar
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Errores */}
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
    </div>
  );
};
