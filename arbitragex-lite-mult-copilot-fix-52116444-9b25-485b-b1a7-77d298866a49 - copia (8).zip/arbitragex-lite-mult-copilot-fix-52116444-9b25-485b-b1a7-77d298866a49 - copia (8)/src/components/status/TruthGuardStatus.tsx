import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Badge } from '../ui/badge'
import { Button } from '../ui/button'
import { Alert, AlertDescription } from '../ui/alert'
import { Progress } from '../ui/progress'
import { Separator } from '../ui/separator'
import { 
  Shield, 
  CheckCircle, 
  XCircle, 
  WarningCircle, 
  Database,
  Activity,
  Lightning,
  Gear,
  LinkSimple,
  Clock,
  Repeat
} from '@phosphor-icons/react'
import { useMockDataAudit } from '../../services/mockDataAuditService'
import { useServiceValidation } from '../../services/serviceConfigValidator'

interface TruthGuardStatusProps {
  environment: 'test' | 'prod'
}

export function TruthGuardStatus({ environment }: TruthGuardStatusProps) {
  const { 
    report, 
    isLoading, 
    error, 
    runAudit, 
    config, 
    updateConfig 
  } = useMockDataAudit()
  
  const { 
    validationResult, 
    isValidating, 
    runValidation 
  } = useServiceValidation()

  const [systemHealth, setSystemHealth] = useState<'healthy' | 'degraded' | 'critical'>('healthy')

  useEffect(() => {
    // Determine overall system health
    if (report && validationResult) {
      if (report.total_violations > 0) {
        setSystemHealth('critical')
      } else if (validationResult.overall_status === 'partial') {
        setSystemHealth('degraded')
      } else if (validationResult.overall_status === 'valid') {
        setSystemHealth('healthy')
      } else {
        setSystemHealth('critical')
      }
    }
  }, [report, validationResult])

  const getHealthColor = (health: string) => {
    switch (health) {
      case 'healthy': return 'text-green-600'
      case 'degraded': return 'text-yellow-600'
      case 'critical': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const getHealthIcon = (health: string) => {
    switch (health) {
      case 'healthy': return <CheckCircle className="h-5 w-5 text-green-600" />
      case 'degraded': return <WarningCircle className="h-5 w-5 text-yellow-600" />
      case 'critical': return <XCircle className="h-5 w-5 text-red-600" />
      default: return <Clock className="h-5 w-5 text-gray-600" />
    }
  }

  return (
    <div className="space-y-6">
      {/* System Health Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Truth Guard System Status
            <Badge variant={environment === 'prod' ? 'destructive' : 'secondary'}>
              {environment.toUpperCase()}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4">
            {getHealthIcon(systemHealth)}
            <div>
              <h3 className={`font-semibold ${getHealthColor(systemHealth)}`}>
                System Status: {systemHealth.charAt(0).toUpperCase() + systemHealth.slice(1)}
              </h3>
              <p className="text-sm text-muted-foreground">
                {systemHealth === 'healthy' && 'All systems operational with real data sources'}
                {systemHealth === 'degraded' && 'Some services need configuration, but core functions work'}
                {systemHealth === 'critical' && 'Critical issues detected - immediate action required'}
              </p>
            </div>
          </div>

          {systemHealth === 'critical' && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>CRITICAL:</strong> Mock data detected or required services not configured. 
                System cannot operate safely until resolved.
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Database className="h-4 w-4" />
                <span className="font-medium">Mock Data Status</span>
              </div>
              {report ? (
                <div>
                  {report.total_violations === 0 ? (
                    <div className="flex items-center gap-2 text-green-600">
                      <CheckCircle className="h-4 w-4" />
                      <span className="text-sm">Clean</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-red-600">
                      <XCircle className="h-4 w-4" />
                      <span className="text-sm">{report.total_violations} violations</span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-sm text-muted-foreground">Loading...</div>
              )}
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="h-4 w-4" />
                <span className="font-medium">Service Status</span>
              </div>
              {validationResult ? (
                <div>
                  <div className="text-sm">
                    {validationResult.valid_services}/{validationResult.total_services} configured
                  </div>
                  <Progress 
                    value={(validationResult.valid_services / validationResult.total_services) * 100} 
                    className="mt-1"
                  />
                </div>
              ) : (
                <div className="text-sm text-muted-foreground">Validating...</div>
              )}
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Lightning className="h-4 w-4" />
                <span className="font-medium">Real-time Desktoping</span>
              </div>
              <div className="flex items-center gap-2">
                {config.realtime_monitoring ? (
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle className="h-4 w-4" />
                    <span className="text-sm">Active</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Clock className="h-4 w-4" />
                    <span className="text-sm">Inactive</span>
                  </div>
                )}
              </div>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button 
              onClick={runAudit} 
              disabled={isLoading}
              variant="outline"
            >
              {isLoading ? (
                <>
                  <Repeat className="h-4 w-4 mr-2 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Database className="h-4 w-4 mr-2" />
                  Run Mock Data Audit
                </>
              )}
            </Button>

            <Button 
              onClick={runValidation} 
              disabled={isValidating}
              variant="outline"
            >
              {isValidating ? (
                <>
                  <Repeat className="h-4 w-4 mr-2 animate-spin" />
                  Validating...
                </>
              ) : (
                <>
                  <Activity className="h-4 w-4 mr-2" />
                  Validate Services
                </>
              )}
            </Button>

            <Button 
              onClick={() => updateConfig({ realtime_monitoring: !config.realtime_monitoring })}
              variant="outline"
            >
              <Lightning className="h-4 w-4 mr-2" />
              {config.realtime_monitoring ? 'Stop' : 'Start'} Real-time Desktoping
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Service Configuration Status */}
      {validationResult && (
        <Card>
          <CardHeader>
            <CardTitle>Service Configuration Status</CardTitle>
          </CardHeader>
          <CardContent>
            {validationResult.missing_services.length > 0 && (
              <div className="mb-4">
                <h4 className="font-medium text-red-600 mb-2">Missing Required Services</h4>
                <div className="space-y-2">
                  {validationResult.missing_services.map((service, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 bg-red-50 rounded">
                      <XCircle className="h-4 w-4 text-red-600" />
                      <span className="text-sm">{service}</span>
                      <Button size="sm" variant="outline" className="ml-auto">
                        <LinkSimple className="h-3 w-3 mr-1" />
                        Configure
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {validationResult.invalid_services.length > 0 && (
              <div className="mb-4">
                <h4 className="font-medium text-yellow-600 mb-2">Invalid Configurations</h4>
                <div className="space-y-2">
                  {validationResult.invalid_services.map((service, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 bg-yellow-50 rounded">
                      <WarningCircle className="h-4 w-4 text-yellow-600" />
                      <span className="text-sm">{service}</span>
                      <Button size="sm" variant="outline" className="ml-auto">
                        <Gear className="h-3 w-3 mr-1" />
                        Fix
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {validationResult.next_steps.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Next Steps</h4>
                <ol className="list-decimal list-inside space-y-1 text-sm">
                  {validationResult.next_steps.map((step, index) => (
                    <li key={index} className="text-muted-foreground">{step}</li>
                  ))}
                </ol>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Mock Data Violations */}
      {report && report.violations.length > 0 && (
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="text-red-600">Mock Data Violations Detected</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="mb-4 border-red-200 bg-red-50">
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>CRITICAL:</strong> {report.violations.length} mock data violations found. 
                System will not operate until these are resolved.
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              {report.violations.slice(0, 5).map((violation, index) => (
                <div key={index} className="p-3 border border-red-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="destructive">{violation.severity.toUpperCase()}</Badge>
                    <code className="text-sm">{violation.field}</code>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{violation.content}</p>
                  <div className="text-xs text-muted-foreground">
                    📁 {violation.file}:{violation.line} → Configure: {violation.service_needed}
                  </div>
                </div>
              ))}
              
              {report.violations.length > 5 && (
                <p className="text-sm text-muted-foreground">
                  ... and {report.violations.length - 5} more violations. 
                  Run full audit to see all details.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Success State */}
      {systemHealth === 'healthy' && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="text-center">
              <CheckCircle className="h-16 w-16 mx-auto mb-4 text-green-600" />
              <h3 className="text-lg font-semibold text-green-800 mb-2">System Ready</h3>
              <p className="text-green-700 mb-4">
                All services are configured and no mock data detected. 
                The system is ready for {environment === 'prod' ? 'production' : 'testing'} operations.
              </p>
              <Button className="bg-green-600 hover:bg-green-700">
                <Activity className="h-4 w-4 mr-2" />
                Start Trading Operations
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default TruthGuardStatus