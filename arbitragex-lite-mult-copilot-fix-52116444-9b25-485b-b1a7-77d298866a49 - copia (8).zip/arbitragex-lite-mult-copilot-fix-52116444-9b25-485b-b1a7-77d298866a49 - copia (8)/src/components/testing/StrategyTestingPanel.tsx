/**
 * StrategyTestingPanel.tsx
 * Panel completo para testing de las 11 estrategias de arbitraje DeFi
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Checkbox } from '../ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { 
  Play, 
  Pause,
  Square,
  CheckCircle, 
  XCircle,
  Clock, 
  TrendUp,
  Target,
  Repeat,
  PlayCircle,
  ChartBar3,
  Activity,
  TestTube
} from 'lucide-react';

// Tipos de datos para testing
interface StrategyTestResult {
  strategyId: string;
  strategyName: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  startTime: Date;
  endTime?: Date;
  testOpportunity?: TestOpportunity;
  execution?: ExecutionResult;
  error?: string;
}

interface TestSession {
  id: string;
  startTime: Date;
  endTime?: Date;
  status: 'running' | 'completed' | 'stopped';
  strategies: StrategyTestResult[];
  totalExecuted: number;
  totalSuccessful: number;
  totalFailed: number;
  totalProfitUSD: number;
  averageExecutionTime: number;
}

interface TestOpportunity {
  id: string;
  blockchain: string;
  potentialProfitUSD: number;
  requiredCapitalUSD: number;
  estimatedGas: {
    gasUnits: number;
    gasPriceGwei: number;
    totalCostUSD: number;
  };
  riskMetrics: {
    liquidityRisk: number;
    slippageRisk: number;
    competitionRisk: number;
  };
  marketData: {
    sourceDexLiquidity: number;
    targetDexLiquidity: number;
    poolDepth: number;
  };
  priceData: {
    tokenAPrice: number;
    tokenBPrice: number;
    lastUpdated: Date;
  };
  timeWindow: {
    expiresAt: Date;
    estimatedDurationMs: number;
  };
  dexInfo: {
    sourceDEX: string;
    targetDEX: string;
    sourcePair: string;
    targetPair: string;
  };
}

interface ExecutionResult {
  success: boolean;
  actualProfitUSD: number;
  executionTimeMs: number;
  gasUsed: number;
  actualSlippage: number;
  transactionHash?: string;
  failureReason?: string;
}

// Estrategias disponibles con metadatos de testing
const availableStrategies = [
  {
    id: 'cross-chain-multi-hop-flash',
    name: 'Cross-Chain Multi-Hop Flash-Loan',
    category: 'Advanced Cross-Chain',
    expectedROI: '15-25%',
    riskLevel: 9,
    complexity: 'Very High',
    requiredCapital: { min: 50000, max: 500000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum'],
    estimatedTime: '45-90s',
    description: 'Combina flash loans con arbitraje multi-salto cross-chain'
  },
  {
    id: 'cross-chain-cross-dex',
    name: 'Cross-Chain Cross-DEX',
    category: 'Cross-Chain',
    expectedROI: '12-20%',
    riskLevel: 8,
    complexity: 'High',
    requiredCapital: { min: 25000, max: 200000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc', 'avalanche'],
    estimatedTime: '30-60s',
    description: 'Arbitraje directo entre DEXs de diferentes blockchains'
  },
  {
    id: 'flash-loan-triangular-cross-dex',
    name: 'Flash-Loan Triangular Cross-DEX',
    category: 'Flash Loan Advanced',
    expectedROI: '10-18%',
    riskLevel: 7,
    complexity: 'High',
    requiredCapital: { min: 20000, max: 300000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc'],
    estimatedTime: '25-45s',
    description: 'Arbitraje triangular usando flash loans entre múltiples DEXs'
  },
  {
    id: 'multi-hop-cross-dex',
    name: 'Multi-Hop Cross-DEX',
    category: 'Multi-Hop',
    expectedROI: '8-15%',
    riskLevel: 6,
    complexity: 'Medium-High',
    requiredCapital: { min: 15000, max: 150000 },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum'],
    estimatedTime: '20-40s',
    description: 'Optimización de rutas complejas entre múltiples DEXs'
  },
  {
    id: 'flash-loan-cross-dex',
    name: 'Flash-Loan Cross-DEX',
    category: 'Flash Loan',
    expectedROI: '7-14%',
    riskLevel: 5,
    complexity: 'Medium',
    requiredCapital: { min: 10000, max: 250000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc', 'optimism'],
    estimatedTime: '15-30s',
    description: 'Arbitraje simple entre DEXs usando capital prestado'
  },
  {
    id: 'triangular-inter-dex',
    name: 'Triangular Inter-DEX',
    category: 'Triangular',
    expectedROI: '6-12%',
    riskLevel: 4,
    complexity: 'Medium',
    requiredCapital: { min: 8000, max: 100000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc'],
    estimatedTime: '10-25s',
    description: 'Arbitraje triangular entre diferentes DEXs del mismo blockchain'
  },
  {
    id: 'triangular-intra-dex',
    name: 'Triangular Intra-DEX',
    category: 'Triangular',
    expectedROI: '5-10%',
    riskLevel: 3,
    complexity: 'Low-Medium',
    requiredCapital: { min: 5000, max: 75000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum'],
    estimatedTime: '8-20s',
    description: 'Arbitraje triangular dentro del mismo DEX'
  },
  {
    id: 'atomic-swap-cross-dex',
    name: 'Atomic Swap Cross-DEX',
    category: 'Atomic Swap',
    expectedROI: '4-9%',
    riskLevel: 5,
    complexity: 'Medium',
    requiredCapital: { min: 12000, max: 120000 },
    supportedBlockchains: ['ethereum', 'bsc', 'polygon', 'avalanche'],
    estimatedTime: '60-120s',
    description: 'Swaps atómicos entre diferentes DEXs usando HTLC'
  },
  {
    id: 'atomic-swap-intra-dex',
    name: 'Atomic Swap Intra-DEX',
    category: 'Atomic Swap',
    expectedROI: '3-7%',
    riskLevel: 2,
    complexity: 'Low',
    requiredCapital: { min: 3000, max: 50000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc'],
    estimatedTime: '5-15s',
    description: 'Swaps atómicos optimizados dentro del mismo DEX'
  },
  {
    id: 'basic-cross-dex',
    name: 'Basic Cross-DEX',
    category: 'Basic',
    expectedROI: '2-6%',
    riskLevel: 2,
    complexity: 'Low',
    requiredCapital: { min: 2000, max: 40000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum'],
    estimatedTime: '3-12s',
    description: 'Arbitraje básico entre dos DEXs diferentes'
  },
  {
    id: 'basic-flash-loan',
    name: 'Basic Flash-Loan',
    category: 'Flash Loan Basic',
    expectedROI: '1-5%',
    riskLevel: 1,
    complexity: 'Low',
    requiredCapital: { min: 1000, max: 30000 },
    supportedBlockchains: ['ethereum', 'polygon', 'bsc'],
    estimatedTime: '5-10s',
    description: 'Flash loan básico para arbitraje simple'
  }
];

const StrategyTestingPanel: React.FC = () => {
  // Estados principales
  const [selectedStrategies, setSelectedStrategies] = useState<string[]>(availableStrategies.map(s => s.id));
  const [testMode, setTestMode] = useState<'sequential' | 'parallel'>('sequential');
  const [isInitialized, setIsInitialized] = useState(false);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [testProgress, setTestProgress] = useState(0);
  const [testResults, setTestResults] = useState<StrategyTestResult[]>([]);
  const [currentTestSession, setCurrentTestSession] = useState<TestSession | null>(null);

  // Servicio de inicialización simulado
  const initializeServices = useCallback(async () => {
    if (isInitialized) return;

    console.log('🔧 Inicializando servicios de testing...');
    
    // Simular inicialización de servicios
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    console.log('✅ Servicios de testing inicializados');
    setIsInitialized(true);
  }, [isInitialized]);

  // Generar oportunidad de testing para una estrategia
  const generateTestOpportunity = useCallback((strategy: typeof availableStrategies[0]): TestOpportunity => {
    const blockchain = strategy.supportedBlockchains[0];
    const profitRange = strategy.expectedROI.split('-');
    const minProfit = parseInt(profitRange[0]);
    const maxProfit = parseInt(profitRange[1]);
    const estimatedProfit = (minProfit + Math.random() * (maxProfit - minProfit)) / 100;
    
    return {
      id: `test-opp-${strategy.id}-${Date.now()}`,
      blockchain,
      potentialProfitUSD: strategy.requiredCapital.min * estimatedProfit,
      requiredCapitalUSD: strategy.requiredCapital.min + Math.random() * (strategy.requiredCapital.max - strategy.requiredCapital.min),
      estimatedGas: {
        gasUnits: 200000 + Math.random() * 300000,
        gasPriceGwei: 20 + Math.random() * 80,
        totalCostUSD: 50 + Math.random() * 200
      },
      riskMetrics: {
        liquidityRisk: strategy.riskLevel - 1 + Math.random() * 2,
        slippageRisk: Math.random() * 5,
        competitionRisk: Math.random() * 3
      },
      marketData: {
        sourceDexLiquidity: strategy.requiredCapital.min * 10,
        targetDexLiquidity: strategy.requiredCapital.min * 8,
        poolDepth: strategy.requiredCapital.min * 5
      },
      priceData: {
        tokenAPrice: 100 + Math.random() * 1000,
        tokenBPrice: 100 + Math.random() * 1000,
        lastUpdated: new Date()
      },
      timeWindow: {
        expiresAt: new Date(Date.now() + 60000), // 1 minuto
        estimatedDurationMs: parseInt(strategy.estimatedTime.split('-')[0]) * 1000
      },
      dexInfo: {
        sourceDEX: 'Test DEX A',
        targetDEX: 'Test DEX B',
        sourcePair: 'TOKEN-A/USDC',
        targetPair: 'TOKEN-A/USDT'
      }
    };
  }, []);

  // Ejecutar test de una estrategia específica
  const testStrategy = useCallback(async (strategy: typeof availableStrategies[0]): Promise<StrategyTestResult> => {
    console.log(`🧪 Iniciando test de estrategia: ${strategy.name}`);
    
    const result: StrategyTestResult = {
      strategyId: strategy.id,
      strategyName: strategy.name,
      status: 'running',
      startTime: new Date(),
      testOpportunity: generateTestOpportunity(strategy)
    };

    try {
      // Simular ejecución de estrategia
      const executionTime = 1000 + Math.random() * 3000; // 1-4 segundos
      await new Promise(resolve => setTimeout(resolve, executionTime));

      // Simular resultado basado en la complejidad de la estrategia
      const successRate = Math.max(0.7, 1 - (strategy.riskLevel / 15));
      const isSuccess = Math.random() < successRate;

      if (isSuccess) {
        const actualProfit = result.testOpportunity!.potentialProfitUSD * (0.8 + Math.random() * 0.4);
        
        result.execution = {
          success: true,
          actualProfitUSD: actualProfit,
          executionTimeMs: executionTime,
          gasUsed: result.testOpportunity!.estimatedGas.gasUnits * (0.9 + Math.random() * 0.2),
          actualSlippage: Math.random() * 0.5,
          transactionHash: `0x${Math.random().toString(16).substring(2, 66)}`
        };
        result.status = 'completed';
      } else {
        result.execution = {
          success: false,
          actualProfitUSD: 0,
          executionTimeMs: executionTime,
          gasUsed: result.testOpportunity!.estimatedGas.gasUnits,
          actualSlippage: 2 + Math.random() * 3,
          failureReason: 'Slippage excedió límites configurados'
        };
        result.status = 'failed';
      }

      result.endTime = new Date();
      
      console.log(`✅ Test completado: ${strategy.name} - ${result.status}`);
    } catch (error: any) {
      result.status = 'failed';
      result.error = error.message;
      result.endTime = new Date();
      
      console.error(`❌ Test fallido: ${strategy.name} - ${error.message}`);
    }

    return result;
  }, [generateTestOpportunity]);

  // Ejecutar todos los tests
  const runAllTests = useCallback(async () => {
    if (!isInitialized || isRunningTests) return;

    setIsRunningTests(true);
    setTestProgress(0);

    const session: TestSession = {
      id: `test-session-${Date.now()}`,
      startTime: new Date(),
      status: 'running',
      strategies: [],
      totalExecuted: 0,
      totalSuccessful: 0,
      totalFailed: 0,
      totalProfitUSD: 0,
      averageExecutionTime: 0
    };

    setCurrentTestSession(session);
    setTestResults([]);

    try {
      const strategiesToTest = availableStrategies.filter(s => selectedStrategies.includes(s.id));
      console.log(`🚀 Iniciando testing de ${strategiesToTest.length} estrategias en modo ${testMode}`);

      let results: StrategyTestResult[] = [];

      if (testMode === 'sequential') {
        // Ejecutar secuencialmente
        for (let i = 0; i < strategiesToTest.length; i++) {
          const strategy = strategiesToTest[i];
          const result = await testStrategy(strategy);
          results.push(result);
          setTestResults([...results]);
          setTestProgress(((i + 1) / strategiesToTest.length) * 100);
        }
      } else {
        // Ejecutar en paralelo
        const promises = strategiesToTest.map(strategy => testStrategy(strategy));
        results = await Promise.all(promises);
        setTestResults(results);
        setTestProgress(100);
      }

      // Calcular estadísticas
      const successful = results.filter(r => r.status === 'completed');
      const failed = results.filter(r => r.status === 'failed');
      const totalProfit = successful.reduce((sum, r) => sum + (r.execution?.actualProfitUSD || 0), 0);
      const totalTime = successful.reduce((sum, r) => sum + (r.execution?.executionTimeMs || 0), 0);

      session.endTime = new Date();
      session.status = 'completed';
      session.strategies = results;
      session.totalExecuted = results.length;
      session.totalSuccessful = successful.length;
      session.totalFailed = failed.length;
      session.totalProfitUSD = totalProfit;
      session.averageExecutionTime = successful.length > 0 ? totalTime / successful.length : 0;

      setCurrentTestSession(session);

      console.log(`✅ Testing completado:`);
      console.log(`  - Estrategias ejecutadas: ${results.length}`);
      console.log(`  - Exitosas: ${successful.length}`);
      console.log(`  - Fallidas: ${failed.length}`);
      console.log(`  - Profit total: $${totalProfit.toFixed(2)}`);
      console.log(`  - Tiempo promedio: ${(totalTime / successful.length).toFixed(0)}ms`);

    } catch (error) {
      console.error('❌ Error en testing:', error);
      session.status = 'completed';
      session.endTime = new Date();
      setCurrentTestSession(session);
    } finally {
      setIsRunningTests(false);
    }
  }, [isInitialized, isRunningTests, testMode, selectedStrategies, testStrategy]);

  // Detener testing
  const stopTesting = useCallback(() => {
    setIsRunningTests(false);
    if (currentTestSession) {
      setCurrentTestSession({
        ...currentTestSession,
        status: 'stopped',
        endTime: new Date()
      });
    }
  }, [currentTestSession]);

  // Efectos
  useEffect(() => {
    initializeServices();
  }, [initializeServices]);

  // Renderizar estado de estrategia
  const renderStrategyStatus = (result: StrategyTestResult) => {
    switch (result.status) {
      case 'pending':
        return <Badge variant="outline"><Clock className="h-3 w-3 mr-1" />Pendiente</Badge>;
      case 'running':
        return <Badge className="bg-blue-500 text-white"><Repeat className="h-3 w-3 mr-1 animate-spin" />Ejecutando</Badge>;
      case 'completed':
        return <Badge className="bg-green-500 text-white"><CheckCircle className="h-3 w-3 mr-1" />Completado</Badge>;
      case 'failed':
        return <Badge className="bg-red-500 text-white"><XCircle className="h-3 w-3 mr-1" />Fallido</Badge>;
      default:
        return <Badge variant="outline">Desconocido</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-blue-500/10 rounded-lg">
            <TestTube className="h-8 w-8 text-blue-500" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Testing de Estrategias DeFi</h1>
            <p className="text-muted-foreground">
              Prueba las 11 estrategias de arbitraje en modo seguro (DRY RUN)
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <Badge variant="secondary" className="bg-blue-500/20 text-blue-700">
            <TestTube className="h-3 w-3 mr-1" />
            MODO TEST
          </Badge>
          
          {isInitialized ? (
            <Badge className="bg-green-500 text-white">
              <CheckCircle className="h-3 w-3 mr-1" />
              Sistema Listo
            </Badge>
          ) : (
            <Badge className="bg-yellow-500 text-white">
              <Repeat className="h-3 w-3 mr-1 animate-spin" />
              Inicializando...
            </Badge>
          )}
        </div>
      </div>

      {/* Configuración y controles */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Target className="h-5 w-5 mr-2" />
            Configuración de Testing
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Selección de estrategias */}
          <div>
            <h3 className="font-semibold mb-3">Estrategias a Probar ({selectedStrategies.length}/11)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {availableStrategies.map((strategy) => (
                <div key={strategy.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={strategy.id}
                    checked={selectedStrategies.includes(strategy.id)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setSelectedStrategies([...selectedStrategies, strategy.id]);
                      } else {
                        setSelectedStrategies(selectedStrategies.filter(id => id !== strategy.id));
                      }
                    }}
                  />
                  <label
                    htmlFor={strategy.id}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {strategy.name}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Configuraciones de ejecución */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="text-sm font-medium mb-2 block">Modo de Ejecución</label>
              <Select value={testMode} onValueChange={(value: 'sequential' | 'parallel') => setTestMode(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sequential">Secuencial (una por una)</SelectItem>
                  <SelectItem value="parallel">Paralelo (todas juntas)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button
                onClick={runAllTests}
                disabled={!isInitialized || isRunningTests || selectedStrategies.length === 0}
                className="w-full"
              >
                {isRunningTests ? (
                  <>
                    <Repeat className="h-4 w-4 mr-2 animate-spin" />
                    Ejecutando Tests...
                  </>
                ) : (
                  <>
                    <PlayCircle className="h-4 w-4 mr-2" />
                    Iniciar Testing
                  </>
                )}
              </Button>
            </div>

            <div className="flex items-end">
              <Button
                onClick={stopTesting}
                disabled={!isRunningTests}
                variant="destructive"
                className="w-full"
              >
                <Square className="h-4 w-4 mr-2" />
                Detener Testing
              </Button>
            </div>
          </div>

          {/* Progreso */}
          {isRunningTests && (
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Progreso del Testing</span>
                <span>{Math.round(testProgress)}%</span>
              </div>
              <Progress value={testProgress} className="w-full" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resultados */}
      <Tabs defaultValue="results" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="results">Resultados</TabsTrigger>
          <TabsTrigger value="strategies">Estrategias</TabsTrigger>
          <TabsTrigger value="session">Sesión</TabsTrigger>
        </TabsList>

        {/* Tab de Resultados */}
        <TabsContent value="results">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="h-5 w-5 mr-2" />
                Resultados de Testing
              </CardTitle>
            </CardHeader>
            <CardContent>
              {testResults.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Estrategia</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Profit USD</TableHead>
                      <TableHead>Tiempo (ms)</TableHead>
                      <TableHead>Gas Usado</TableHead>
                      <TableHead>Slippage</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {testResults.map((result) => (
                      <TableRow key={result.strategyId}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{result.strategyName}</div>
                            <div className="text-sm text-muted-foreground">{result.strategyId}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {renderStrategyStatus(result)}
                        </TableCell>
                        <TableCell>
                          {result.execution ? (
                            result.execution.success ? (
                              <span className="text-green-600 font-medium">
                                +${result.execution.actualProfitUSD.toFixed(2)}
                              </span>
                            ) : (
                              <span className="text-red-600">$0.00</span>
                            )
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {result.execution ? (
                            <span>{result.execution.executionTimeMs.toFixed(0)}ms</span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {result.execution ? (
                            <span>{result.execution.gasUsed.toLocaleString()}</span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {result.execution ? (
                            <span className={result.execution.actualSlippage > 1 ? 'text-red-600' : 'text-green-600'}>
                              {result.execution.actualSlippage.toFixed(3)}%
                            </span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8">
                  <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No hay resultados</h3>
                  <p className="text-muted-foreground">
                    Ejecuta un testing para ver los resultados aquí
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Estrategias */}
        <TabsContent value="strategies">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableStrategies.map((strategy) => (
              <Card key={strategy.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{strategy.name}</CardTitle>
                    <Badge variant="secondary">{strategy.category}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">ROI esperado:</span>
                      <span className="font-medium text-green-600">{strategy.expectedROI}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Riesgo:</span>
                      <span className={`font-medium ${
                        strategy.riskLevel <= 3 ? 'text-green-600' : 
                        strategy.riskLevel <= 6 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {strategy.riskLevel}/10
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Tiempo:</span>
                      <span className="font-medium">{strategy.estimatedTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Capital:</span>
                      <span className="font-medium">
                        ${strategy.requiredCapital.min.toLocaleString()} - ${strategy.requiredCapital.max.toLocaleString()}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    {strategy.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab de Sesión */}
        <TabsContent value="session">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2" />
                Información de Sesión
              </CardTitle>
            </CardHeader>
            <CardContent>
              {currentTestSession ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <span className="text-sm text-muted-foreground">ID de Sesión</span>
                      <div className="font-mono text-sm">{currentTestSession.id}</div>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Inicio</span>
                      <div className="text-sm">{currentTestSession.startTime.toLocaleString()}</div>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Estado</span>
                      <div>
                        <Badge 
                          className={
                            currentTestSession.status === 'running' ? 'bg-blue-500 text-white' :
                            currentTestSession.status === 'completed' ? 'bg-green-500 text-white' :
                            'bg-gray-500 text-white'
                          }
                        >
                          {currentTestSession.status}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Duración</span>
                      <div className="text-sm">
                        {currentTestSession.endTime 
                          ? Math.round((currentTestSession.endTime.getTime() - currentTestSession.startTime.getTime()) / 1000) + 's'
                          : 'En curso...'
                        }
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
                    <div className="text-center">
                      <div className="text-3xl font-bold">{currentTestSession.totalExecuted}</div>
                      <div className="text-sm text-muted-foreground">Total Ejecutadas</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-500">{currentTestSession.totalSuccessful}</div>
                      <div className="text-sm text-muted-foreground">Exitosas</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-red-500">{currentTestSession.totalFailed}</div>
                      <div className="text-sm text-muted-foreground">Fallidas</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold">
                        {currentTestSession.totalExecuted > 0 
                          ? Math.round((currentTestSession.totalSuccessful / currentTestSession.totalExecuted) * 100)
                          : 0
                        }%
                      </div>
                      <div className="text-sm text-muted-foreground">Tasa de Éxito</div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No hay sesión activa</h3>
                  <p className="text-muted-foreground">
                    Inicia un testing para ver la información de la sesión
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default StrategyTestingPanel;