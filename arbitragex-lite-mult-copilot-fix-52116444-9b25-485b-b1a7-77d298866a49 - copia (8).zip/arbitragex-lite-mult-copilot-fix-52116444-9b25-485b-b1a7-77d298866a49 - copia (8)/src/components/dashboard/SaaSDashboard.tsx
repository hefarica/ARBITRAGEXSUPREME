import React, { useState, useEffect, useCallback } from 'react';
import { RealTimeDashboard } from '../RealTimeDashboard';
import { NavigationSidebar } from '../layout/NavigationSidebar';
import { StatusBar } from '../layout/StatusBar';
import { CommandPalette } from '../CommandPalette';
import { apiService } from '../../services/ApiService';

// Tipos del sistema SaaS
interface SaaSMetrics {
  // Métricas de negocio
  totalRevenue: string;
  monthlyRecurringRevenue: string;
  activeUsers: number;
  conversionRate: number;
  
  // Métricas técnicas
  systemUptime: number;
  averageResponseTime: number;
  errorRate: number;
  throughput: number;
  
  // Métricas de arbitraje
  totalArbitrages: number;
  successRate: number;
  averageProfit: string;
  totalVolume: string;
}

interface DashboardConfig {
  id: string;
  name: string;
  description: string;
  icon: string;
  component: React.ComponentType<any>;
  metrics: string[];
}

export const SaaSDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [metrics, setMetrics] = useState<SaaSMetrics>({
    totalRevenue: '0',
    monthlyRecurringRevenue: '0',
    activeUsers: 0,
    conversionRate: 0,
    systemUptime: 0,
    averageResponseTime: 0,
    errorRate: 0,
    throughput: 0,
    totalArbitrages: 0,
    successRate: 0,
    averageProfit: '0',
    totalVolume: '0'
  });

  const [showCommandPalette, setShowCommandPalette] = useState(false);

  // Configuración de dashboards disponibles
  const dashboardConfigs: DashboardConfig[] = [
    {
      id: 'dashboard',
      name: 'Dashboard Principal',
      description: 'Vista general del sistema y métricas clave',
      icon: '📊',
      component: RealTimeDashboard,
      metrics: ['totalRevenue', 'activeUsers', 'systemUptime', 'totalArbitrages']
    },
    {
      id: 'arbitrage',
      name: 'Arbitraje',
      description: 'Gestión y monitoreo de oportunidades de arbitraje',
      icon: '💰',
      component: RealTimeDashboard,
      metrics: ['totalArbitrages', 'successRate', 'averageProfit', 'totalVolume']
    },
    {
      id: 'strategies',
      name: 'Estrategias',
      description: 'Configuración y rendimiento de estrategias',
      icon: '🎯',
      component: RealTimeDashboard,
      metrics: ['successRate', 'throughput', 'errorRate']
    },
    {
      id: 'dexs',
      name: 'DEXs',
      description: 'Monitoreo de exchanges descentralizados',
      icon: '🏪',
      component: RealTimeDashboard,
      metrics: ['totalVolume', 'throughput', 'errorRate']
    },
    {
      id: 'blockchains',
      name: 'Blockchains',
      description: 'Estado y rendimiento de las cadenas soportadas',
      icon: '⛓️',
      component: RealTimeDashboard,
      metrics: ['systemUptime', 'averageResponseTime', 'activeUsers']
    },
    {
      id: 'pools',
      name: 'Pools',
      description: 'Monitoreo de pools de liquidez',
      icon: '🏊',
      component: RealTimeDashboard,
      metrics: ['totalVolume', 'throughput', 'activeUsers']
    },
    {
      id: 'execution',
      name: 'Ejecución',
      description: 'Control de ejecución de transacciones',
      icon: '⚡',
      component: RealTimeDashboard,
      metrics: ['successRate', 'averageResponseTime', 'totalArbitrages']
    },
    {
      id: 'status',
      name: 'Estado',
      description: 'Estado general del sistema y salud',
      icon: '🔍',
      component: RealTimeDashboard,
      metrics: ['systemUptime', 'errorRate', 'averageResponseTime']
    },
    {
      id: 'configuration',
      name: 'Configuración',
      description: 'Ajustes del sistema y preferencias',
      icon: '⚙️',
      component: RealTimeDashboard,
      metrics: ['activeUsers', 'conversionRate']
    }
  ];

  // Cargar métricas en tiempo real
  const loadMetrics = useCallback(async () => {
    try {
      const [businessMetrics, technicalMetrics, arbitrageMetrics] = await Promise.all([
        apiService.get('/metrics/business'),
        apiService.get('/metrics/technical'),
        apiService.get('/metrics/arbitrage')
      ]);

      setMetrics({
        ...businessMetrics,
        ...technicalMetrics,
        ...arbitrageMetrics
      });
    } catch (error) {
      console.error('❌ Error cargando métricas:', error);
    }
  }, []);

  // Cargar métricas iniciales y configurar actualización automática
  useEffect(() => {
    loadMetrics();
    const interval = setInterval(loadMetrics, 5000); // Actualizar cada 5 segundos
    return () => clearInterval(interval);
  }, [loadMetrics]);

  // Manejar atajos de teclado
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 'k':
            e.preventDefault();
            setShowCommandPalette(true);
            break;
          case 'b':
            e.preventDefault();
            setSidebarOpen(prev => !prev);
            break;
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Renderizar dashboard activo
  const renderActiveDashboard = () => {
    const config = dashboardConfigs.find(c => c.id === activeTab);
    if (!config) return <div>Dashboard no encontrado</div>;

    const DashboardComponent = config.component;
    return <DashboardComponent />;
  };

  return (
    <div className="saas-dashboard">
      {/* Barra de navegación superior */}
      <header className="dashboard-header">
        <div className="header-left">
          <button
            className="sidebar-toggle"
            onClick={() => setSidebarOpen(prev => !prev)}
          >
            ☰
          </button>
          <h1 className="dashboard-title">
            🚀 ArbitrageX Pro SaaS
          </h1>
        </div>

        <div className="header-center">
          <div className="quick-metrics">
            <div className="metric-item">
              <span className="metric-label">Ingresos:</span>
              <span className="metric-value">${metrics.totalRevenue}</span>
            </div>
            <div className="metric-item">
              <span className="metric-label">Usuarios:</span>
              <span className="metric-value">{metrics.activeUsers}</span>
            </div>
            <div className="metric-item">
              <span className="metric-label">Uptime:</span>
              <span className="metric-value">{metrics.systemUptime.toFixed(2)}%</span>
            </div>
          </div>
        </div>

        <div className="header-right">
          <button
            className="command-palette-btn"
            onClick={() => setShowCommandPalette(true)}
          >
            ⌘K
          </button>
          <button className="notifications-btn">
            🔔
          </button>
        </div>
      </header>

      {/* Contenido principal */}
      <main className="dashboard-main">
        {/* Sidebar de navegación */}
        <NavigationSidebar
          isOpen={sidebarOpen}
          items={dashboardConfigs.map(config => ({
            id: config.id,
            name: config.name,
            icon: config.icon,
            description: config.description
          }))}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onClose={() => setSidebarOpen(false)}
        />

        {/* Área de contenido */}
        <div className="dashboard-content">
          {renderActiveDashboard()}
        </div>
      </main>

      {/* Barra de estado */}
      <StatusBar
        systemStatus={{
          isConnected: true,
          activeChains: 12,
          totalPools: parseInt(metrics.totalVolume) || 0,
          opportunities: metrics.totalArbitrages,
          lastUpdate: new Date(),
          systemHealth: metrics.errorRate > 5 ? 'warning' : 'healthy'
        }}
        userPreferences={{
          theme: 'auto',
          refreshInterval: 5000,
          notifications: true,
          autoExecution: false
        }}
      />

      {/* Paleta de comandos */}
      {showCommandPalette && (
        <CommandPalette
          onClose={() => setShowCommandPalette(false)}
          onExecute={(command) => {
            console.log('Ejecutando comando:', command);
            setShowCommandPalette(false);
          }}
        />
      )}
    </div>
  );
};
