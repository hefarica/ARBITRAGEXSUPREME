import { useEffect, useState } from 'react'
import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { RealtimePerformanceDashboard } from './RealtimePerformanceDashboard'
import { TrendUp, TrendDown, Activity, Target, Lightning, ChartBar3, Eye } from '@phosphor-icons/react'

export function Dashboard() {
  const { state, executeTrade } = useSimulation()
  const [opportunities, setOpportunities] = useState<Array<{
    id: string
    type: string
    pair: string
    profit: number
    probability: number
    risk: 'low' | 'medium' | 'high'
  }>>([])

  // Simulate arbitrage opportunities
  useEffect(() => {
    if (!state.isRunning) return

    const generateOpportunity = () => {
      const types = ['Triangular Arbitrage', 'Cross-DEX Arbitrage', 'Flash Loan Arbitrage']
      const pairs = ['ETH/USDC', 'BTC/USDT', 'DAI/USDC', 'WETH/DAI']
      const risks: Array<'low' | 'medium' | 'high'> = ['low', 'medium', 'high']
      
      return {
        id: crypto.randomUUID(),
        type: types[Math.floor(Math.random() * types.length)],
        pair: pairs[Math.floor(Math.random() * pairs.length)],
        profit: Math.random() * 50 + 5, // $5-55 profit
        probability: Math.random() * 40 + 60, // 60-100% probability
        risk: risks[Math.floor(Math.random() * risks.length)]
      }
    }

    const interval = setInterval(() => {
      if (Math.random() > 0.7) { // 30% chance to generate new opportunity
        setOpportunities(prev => {
          const newOpp = generateOpportunity()
          return [newOpp, ...prev.slice(0, 4)] // Keep max 5 opportunities
        })
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [state.isRunning])

  const executeArbitrage = (opportunity: typeof opportunities[0]) => {
    const fees = opportunity.profit * 0.1 // 10% fees
    const actualProfit = opportunity.profit - fees
    
    executeTrade({
      type: 'arbitrage',
      tokens: opportunity.pair.split('/'),
      amount: 1000, // $1000 trade size
      profit: actualProfit,
      fees
    })

    // Remove the executed opportunity
    setOpportunities(prev => prev.filter(opp => opp.id !== opportunity.id))
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'bg-profit text-profit-foreground'
      case 'medium': return 'bg-warning text-warning-foreground'
      case 'high': return 'bg-destructive text-destructive-foreground'
      default: return 'bg-muted text-muted-foreground'
    }
  }

  const successfulTrades = state.trades.filter(t => t.profit > 0).length
  const winRate = state.trades.length > 0 ? (successfulTrades / state.trades.length) * 100 : 0

  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Trading Overview</TabsTrigger>
          <TabsTrigger value="performance">Real-time Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Portfolio Value</p>
                    <p className="text-2xl font-bold">{formatCurrency(state.balance)}</p>
                  </div>
                  <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <TrendUp size={24} className="text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total P&L</p>
                    <p className={`text-2xl font-bold ${state.totalPnL >= 0 ? 'profit' : 'loss'}`}>
                      {formatCurrency(state.totalPnL)}
                    </p>
                  </div>
                  <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                    state.totalPnL >= 0 ? 'bg-profit/10' : 'bg-destructive/10'
                  }`}>
                    {state.totalPnL >= 0 ? 
                      <TrendUp size={24} className="text-profit" /> : 
                      <TrendDown size={24} className="text-destructive" />
                    }
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Win Rate</p>
                    <p className="text-2xl font-bold">{winRate.toFixed(1)}%</p>
                  </div>
                  <div className="h-12 w-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <Target size={24} className="text-accent" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Opportunities</p>
                    <p className="text-2xl font-bold">{opportunities.length}</p>
                  </div>
                  <div className="h-12 w-12 bg-warning/10 rounded-lg flex items-center justify-center">
                    <Activity size={24} className="text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Live Opportunities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightning size={20} />
                Live Arbitrage Opportunities
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!state.isRunning ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Activity size={48} className="mx-auto mb-4 opacity-50" />
                  <p>Start the simulation to see live arbitrage opportunities</p>
                </div>
              ) : opportunities.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Target size={48} className="mx-auto mb-4 opacity-50" />
                  <p>Scanning for arbitrage opportunities...</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {opportunities.map((opp) => (
                    <div key={opp.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-semibold">{opp.type}</h4>
                          <Badge variant="outline">{opp.pair}</Badge>
                          <Badge className={getRiskColor(opp.risk)} variant="secondary">
                            {opp.risk} risk
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>Profit: <span className="font-semibold text-profit">{formatCurrency(opp.profit)}</span></span>
                          <span>Probability: <span className="font-semibold">{opp.probability.toFixed(1)}%</span></span>
                        </div>
                      </div>
                      <Button
                        onClick={() => executeArbitrage(opp)}
                        className="gap-2"
                      >
                        <Lightning size={16} />
                        Execute
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Trades */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Trades</CardTitle>
            </CardHeader>
            <CardContent>
              {state.trades.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <TrendUp size={48} className="mx-auto mb-4 opacity-50" />
                  <p>No trades executed yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {state.trades.slice(0, 5).map((trade) => (
                    <div key={trade.id} className="flex items-center justify-between p-3 bg-card border rounded-lg">
                      <div>
                        <p className="font-medium">{trade.type.replace('-', ' ').toUpperCase()}</p>
                        <p className="text-sm text-muted-foreground">
                          {trade.tokens.join('/')} • {new Date(trade.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${trade.profit >= 0 ? 'profit' : 'loss'}`}>
                          {formatCurrency(trade.profit)}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Fees: {formatCurrency(trade.fees)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <RealtimePerformanceDashboard />
        </TabsContent>
      </Tabs>
    </div>
  )
}