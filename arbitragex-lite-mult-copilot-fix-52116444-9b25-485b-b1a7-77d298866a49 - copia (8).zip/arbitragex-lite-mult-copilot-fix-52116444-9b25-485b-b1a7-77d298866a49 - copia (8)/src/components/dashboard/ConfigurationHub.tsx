import React, { useState, useEffect, useCallback } from 'react';
import { ApiService } from '../../services/ApiService';

// Interfaces para datos reales
interface BlockchainConfig {
  id: string;
  chainId: number;
  name: string;
  rpcUrl: string;
  wsUrl: string;
  explorerUrl: string;
  isEnabled: boolean;
  isTestnet: boolean;
  nativeCurrency: {
    name: string;
    symbol: string;
    decimals: number;
  };
  blockTime: number;
  lastBlock: number;
  gasPrice: number;
  status: 'active' | 'inactive' | 'error' | 'syncing';
}

interface DEXConfig {
  id: string;
  name: string;
  chainId: number;
  factoryAddress: string;
  routerAddress: string;
  isEnabled: boolean;
  isVerified: boolean;
  pairCount: number;
  tvl: number;
  volume24h: number;
  lastUpdate: Date;
  status: 'active' | 'inactive' | 'error' | 'maintenance';
}

interface StrategyConfig {
  id: string;
  name: string;
  description: string;
  category: 'basic' | 'advanced' | 'specialized' | 'ai-powered';
  risk: 'low' | 'medium' | 'high';
  isEnabled: boolean;
  isActive: boolean;
  minProfitThreshold: number;
  maxGasPrice: number;
  maxSlippage: number;
  supportedChains: number[];
  lastExecution?: Date;
  successRate: number;
  totalExecutions: number;
  totalProfit: number;
}

export const ConfigurationHub: React.FC = () => {
  const [blockchains, setBlockchains] = useState<BlockchainConfig[]>([]);
  const [dexes, setDexes] = useState<DEXConfig[]>([]);
  const [strategies, setStrategies] = useState<StrategyConfig[]>([]);
  const [activeTab, setActiveTab] = useState<'blockchains' | 'dexes' | 'strategies'>('blockchains');
  const [isLoading, setIsLoading] = useState(false);
  const [apiService] = useState(() => new ApiService());

  // Cargar configuraciones de blockchain reales desde el backend
  useEffect(() => {
    const loadBlockchains = async () => {
      try {
        const realBlockchains = await apiService.getBlockchainConfigurations();
        setBlockchains(realBlockchains);
      } catch (error) {
        console.error('Error cargando configuraciones de blockchain:', error);
      }
    };
    
    loadBlockchains();
  }, [apiService]);

  // Cargar configuraciones de DEX reales desde el backend
  useEffect(() => {
    const loadDexes = async () => {
      try {
        const realDexes = await apiService.getDEXConfigurations();
        setDexes(realDexes);
      } catch (error) {
        console.error('Error cargando configuraciones de DEX:', error);
      }
    };
    
    loadDexes();
  }, [apiService]);

  // Cargar configuraciones de estrategias reales desde el backend
  useEffect(() => {
    const loadStrategies = async () => {
      try {
        const realStrategies = await apiService.getStrategyConfigurations();
        setStrategies(realStrategies);
      } catch (error) {
        console.error('Error cargando configuraciones de estrategias:', error);
      }
    };
    
    loadStrategies();
  }, [apiService]);

  // Toggle blockchain
  const toggleBlockchain = useCallback(async (chainId: number) => {
    try {
      const updatedBlockchain = await apiService.toggleBlockchain(chainId);
      setBlockchains(prev => 
        prev.map(b => b.chainId === chainId ? updatedBlockchain : b)
      );
    } catch (error) {
      console.error('Error toggleando blockchain:', error);
    }
  }, [apiService]);

  // Toggle DEX
  const toggleDEX = useCallback(async (dexId: string) => {
    try {
      const updatedDEX = await apiService.toggleDEX(dexId);
      setDexes(prev => 
        prev.map(d => d.id === dexId ? updatedDEX : d)
      );
    } catch (error) {
      console.error('Error toggleando DEX:', error);
    }
  }, [apiService]);

  // Toggle estrategia
  const toggleStrategy = useCallback(async (strategyId: string) => {
    try {
      const updatedStrategy = await apiService.toggleStrategy(strategyId);
      setStrategies(prev => 
        prev.map(s => s.id === strategyId ? updatedStrategy : s)
      );
    } catch (error) {
      console.error('Error toggleando estrategia:', error);
    }
  }, [apiService]);

  // Obtener color del estado de blockchain
  const getBlockchainStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'inactive': return 'text-gray-400';
      case 'error': return 'text-red-400';
      case 'syncing': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener color del estado de DEX
  const getDEXStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'inactive': return 'text-gray-400';
      case 'error': return 'text-red-400';
      case 'maintenance': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener color del riesgo de estrategia
  const getStrategyRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener icono de la blockchain
  const getBlockchainIcon = (chainId: number) => {
    const chainIcons: { [key: number]: string } = {
      1: '🔷', // Ethereum
      56: '🟡', // BSC
      137: '🟣', // Polygon
      43114: '🔴', // Avalanche
      250: '🔵', // Fantom
      42161: '🟦', // Arbitrum
      10: '🟠', // Optimism
      139: '🟢', // Polygon ZKEVM
      25: '🟤', // Cronos
      100: '⚪', // Gnosis
      1284: '🌙', // Moonbeam
      8453: '🔵' // Base
    };
    return chainIcons[chainId] || '⛓️';
  };

  // Obtener nombre de la blockchain
  const getBlockchainName = (chainId: number) => {
    const chains: { [key: number]: string } = {
      1: 'Ethereum',
      56: 'BSC',
      137: 'Polygon',
      43114: 'Avalanche',
      250: 'Fantom',
      42161: 'Arbitrum',
      10: 'Optimism',
      139: 'Polygon ZKEVM',
      25: 'Cronos',
      100: 'Gnosis',
      1284: 'Moonbeam',
      8453: 'Base'
    };
    return chains[chainId] || `Chain ${chainId}`;
  };

  // Calcular métricas agregadas
  const calculateAggregatedMetrics = useCallback(() => {
    const totalBlockchains = blockchains.length;
    const enabledBlockchains = blockchains.filter(b => b.isEnabled).length;
    const activeBlockchains = blockchains.filter(b => b.status === 'active').length;
    
    const totalDexes = dexes.length;
    const enabledDexes = dexes.filter(d => d.isEnabled).length;
    const activeDexes = dexes.filter(d => d.status === 'active').length;
    
    const totalStrategies = strategies.length;
    const enabledStrategies = strategies.filter(s => s.isEnabled).length;
    const activeStrategies = strategies.filter(s => s.isActive).length;
    
    return {
      totalBlockchains,
      enabledBlockchains,
      activeBlockchains,
      totalDexes,
      enabledDexes,
      activeDexes,
      totalStrategies,
      enabledStrategies,
      activeStrategies
    };
  }, [blockchains, dexes, strategies]);

  const aggregatedMetrics = calculateAggregatedMetrics();

  return (
    <div className="space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard de Configuración</h1>
          <p className="text-blue-300">Gestión centralizada del sistema de arbitraje</p>
        </div>
      </div>

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-black/20 rounded-lg p-4 border border-blue-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-300 text-sm">Blockchains</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.enabledBlockchains}/{aggregatedMetrics.totalBlockchains}</p>
            </div>
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">⛓️</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-blue-300">
            {aggregatedMetrics.activeBlockchains} activas
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-green-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-300 text-sm">DEXs</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.enabledDexes}/{aggregatedMetrics.totalDexes}</p>
            </div>
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">💱</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-green-300">
            {aggregatedMetrics.activeDexes} activos
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-yellow-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-300 text-sm">Estrategias</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.enabledStrategies}/{aggregatedMetrics.totalStrategies}</p>
            </div>
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">⚡</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-yellow-300">
            {aggregatedMetrics.activeStrategies} activas
          </div>
        </div>
      </div>

      {/* Tabs de Configuración */}
      <div className="bg-black/20 rounded-lg border border-blue-500/30">
        <div className="border-b border-blue-500/30">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('blockchains')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'blockchains'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
              }`}
            >
              ⛓️ Blockchains ({aggregatedMetrics.totalBlockchains})
            </button>
            <button
              onClick={() => setActiveTab('dexes')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'dexes'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
              }`}
            >
              💱 DEXs ({aggregatedMetrics.totalDexes})
            </button>
            <button
              onClick={() => setActiveTab('strategies')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'strategies'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
              }`}
            >
              ⚡ Estrategias ({aggregatedMetrics.totalStrategies})
            </button>
          </nav>
        </div>

        <div className="p-6">
          {/* Tab de Blockchains */}
          {activeTab === 'blockchains' && (
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Configuración de Blockchains</h2>
              {blockchains.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">⛓️</div>
                  <h3 className="text-xl font-semibold text-white mb-2">Sin Blockchains</h3>
                  <p className="text-blue-300">No hay blockchains configuradas</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {blockchains.map((blockchain) => (
                    <div key={blockchain.id} className="bg-black/30 rounded-lg p-4 border border-blue-500/20">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          <span className="text-lg">{getBlockchainIcon(blockchain.chainId)}</span>
                          <span className="font-semibold text-white">{getBlockchainName(blockchain.chainId)}</span>
                        </div>
                        <div className={`px-2 py-1 rounded text-xs font-medium ${
                          blockchain.status === 'active' ? 'bg-green-500/20 text-green-400' :
                          blockchain.status === 'syncing' ? 'bg-yellow-500/20 text-yellow-400' :
                          blockchain.status === 'error' ? 'bg-red-500/20 text-red-400' :
                          'bg-gray-500/20 text-gray-400'
                        }`}>
                          {blockchain.status.toUpperCase()}
                        </div>
                      </div>
                      
                      <div className="space-y-2 text-sm mb-4">
                        <div className="flex justify-between">
                          <span className="text-blue-300">Chain ID:</span>
                          <span className="text-white">{blockchain.chainId}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-blue-300">Moneda:</span>
                          <span className="text-white">{blockchain.nativeCurrency.symbol}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-blue-300">Tiempo de Bloque:</span>
                          <span className="text-white">{blockchain.blockTime}s</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-blue-300">Último Bloque:</span>
                          <span className="text-white">{blockchain.lastBlock.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-blue-300">Gas Price:</span>
                          <span className="text-white">{blockchain.gasPrice} gwei</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={blockchain.isEnabled}
                            onChange={() => toggleBlockchain(blockchain.chainId)}
                            className="w-4 h-4 text-blue-600 bg-black border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                          />
                          <span className="text-sm text-white">Habilitada</span>
                        </label>
                        <span className={`text-xs ${
                          blockchain.isTestnet ? 'text-yellow-400' : 'text-green-400'
                        }`}>
                          {blockchain.isTestnet ? 'TESTNET' : 'MAINNET'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Tab de DEXs */}
          {activeTab === 'dexes' && (
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Configuración de DEXs</h2>
              {dexes.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">💱</div>
                  <h3 className="text-xl font-semibold text-white mb-2">Sin DEXs</h3>
                  <p className="text-green-300">No hay DEXs configurados</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {dexes.map((dex) => (
                    <div key={dex.id} className="bg-black/30 rounded-lg p-4 border border-green-500/20">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          <span className="text-lg">💱</span>
                          <span className="font-semibold text-white">{dex.name}</span>
                        </div>
                        <div className={`px-2 py-1 rounded text-xs font-medium ${
                          dex.status === 'active' ? 'bg-green-500/20 text-green-400' :
                          dex.status === 'maintenance' ? 'bg-yellow-500/20 text-yellow-400' :
                          dex.status === 'error' ? 'bg-red-500/20 text-red-400' :
                          'bg-gray-500/20 text-gray-400'
                        }`}>
                          {dex.status.toUpperCase()}
                        </div>
                      </div>
                      
                      <div className="space-y-2 text-sm mb-4">
                        <div className="flex justify-between">
                          <span className="text-green-300">Chain ID:</span>
                          <span className="text-white">{dex.chainId}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-green-300">Pares:</span>
                          <span className="text-white">{dex.pairCount}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-green-300">TVL:</span>
                          <span className="text-white">${dex.tvl.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-green-300">Volumen 24h:</span>
                          <span className="text-white">${dex.volume24h.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-green-300">Verificado:</span>
                          <span className={dex.isVerified ? 'text-green-400' : 'text-red-400'}>
                            {dex.isVerified ? '✅ Sí' : '❌ No'}
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={dex.isEnabled}
                            onChange={() => toggleDEX(dex.id)}
                            className="w-4 h-4 text-green-600 bg-black border-gray-600 rounded focus:ring-green-500 focus:ring-2"
                          />
                          <span className="text-sm text-white">Habilitado</span>
                        </label>
                        <span className="text-xs text-gray-400">
                          {dex.lastUpdate.toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Tab de Estrategias */}
          {activeTab === 'strategies' && (
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Configuración de Estrategias</h2>
              {strategies.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">⚡</div>
                  <h3 className="text-xl font-semibold text-white mb-2">Sin Estrategias</h3>
                  <p className="text-yellow-300">No hay estrategias configuradas</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {strategies.map((strategy) => (
                    <div key={strategy.id} className="bg-black/30 rounded-lg p-4 border border-yellow-500/20">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          <span className="text-lg">⚡</span>
                          <span className="font-semibold text-white">{strategy.name}</span>
                        </div>
                        <div className={`px-2 py-1 rounded text-xs font-medium ${
                          strategy.category === 'basic' ? 'bg-blue-500/20 text-blue-400' :
                          strategy.category === 'advanced' ? 'bg-yellow-500/20 text-yellow-400' :
                          strategy.category === 'specialized' ? 'bg-purple-500/20 text-purple-400' :
                          'bg-indigo-500/20 text-indigo-400'
                        }`}>
                          {strategy.category.toUpperCase()}
                        </div>
                      </div>
                      
                      <p className="text-sm text-yellow-300 mb-3">{strategy.description}</p>
                      
                      <div className="space-y-2 text-sm mb-4">
                        <div className="flex justify-between">
                          <span className="text-yellow-300">Riesgo:</span>
                          <span className={`font-medium ${getStrategyRiskColor(strategy.risk)}`}>
                            {strategy.risk.toUpperCase()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-yellow-300">Umbral Mínimo:</span>
                          <span className="text-white">${strategy.minProfitThreshold.toFixed(4)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-yellow-300">Gas Máximo:</span>
                          <span className="text-white">{strategy.maxGasPrice} gwei</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-yellow-300">Slippage:</span>
                          <span className="text-white">{strategy.maxSlippage}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-yellow-300">Chains:</span>
                          <span className="text-white">{strategy.supportedChains.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-yellow-300">Éxito:</span>
                          <span className="text-white">{strategy.successRate.toFixed(1)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-yellow-300">Ejecuciones:</span>
                          <span className="text-white">{strategy.totalExecutions}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-yellow-300">Ganancia Total:</span>
                          <span className="text-white">${strategy.totalProfit.toFixed(4)}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={strategy.isEnabled}
                            onChange={() => toggleStrategy(strategy.id)}
                            className="w-4 h-4 text-yellow-600 bg-black border-gray-600 rounded focus:ring-yellow-500 focus:ring-2"
                          />
                          <span className="text-sm text-white">Habilitada</span>
                        </label>
                        <span className={`text-xs ${
                          strategy.isActive ? 'text-green-400' : 'text-gray-400'
                        }`}>
                          {strategy.isActive ? 'ACTIVA' : 'INACTIVA'}
                        </span>
                      </div>
                      
                      {strategy.lastExecution && (
                        <div className="mt-2 text-xs text-gray-400">
                          Última ejecución: {strategy.lastExecution.toLocaleTimeString()}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
