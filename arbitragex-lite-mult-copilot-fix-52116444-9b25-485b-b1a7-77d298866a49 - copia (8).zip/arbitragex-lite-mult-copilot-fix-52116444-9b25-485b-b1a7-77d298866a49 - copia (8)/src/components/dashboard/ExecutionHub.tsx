import React, { useState, useEffect, useCallback } from 'react';
import { MEVProtectedExecutor } from '../../core/MEVProtectedExecutor';
import { ApiService } from '../../services/ApiService';

// Interfaces para datos reales
interface Execution {
  id: string;
  strategyId: string;
  strategyName: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  startTime: Date;
  endTime?: Date;
  expectedProfit: number;
  actualProfit?: number;
  gasUsed?: number;
  gasPrice?: number;
  txHash?: string;
  chainId: number;
  tokens: string[];
  dexes: string[];
  priority: 'low' | 'medium' | 'high' | 'critical';
  risk: 'low' | 'medium' | 'high';
  progress: number;
}

interface StrategyExecution {
  id: string;
  name: string;
  description: string;
  category: 'basic' | 'advanced' | 'specialized' | 'ai-powered';
  risk: 'low' | 'medium' | 'high';
  status: 'active' | 'paused' | 'stopped';
  lastExecution?: Date;
  successRate: number;
  totalExecutions: number;
  totalProfit: number;
  avgExecutionTime: number;
  isEnabled: boolean;
}

interface ExecutionHubProps {
  mevExecutor: MEVProtectedExecutor;
  systemStatus: 'running' | 'stopped' | 'error' | 'maintenance';
  onStartSystem: () => void;
  onStopSystem: () => void;
}

export const ExecutionHub: React.FC<ExecutionHubProps> = ({ 
  mevExecutor, 
  systemStatus, 
  onStartSystem, 
  onStopSystem 
}) => {
  const [activeExecutions, setActiveExecutions] = useState<Execution[]>([]);
  const [executionHistory, setExecutionHistory] = useState<Execution[]>([]);
  const [strategies, setStrategies] = useState<StrategyExecution[]>([]);
  const [selectedStrategy, setSelectedStrategy] = useState<string>('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [apiService] = useState(() => new ApiService());

  // Cargar estrategias reales desde el backend
  useEffect(() => {
    const loadStrategies = async () => {
      try {
        const realStrategies = await apiService.getStrategies();
        setStrategies(realStrategies);
      } catch (error) {
        console.error('Error cargando estrategias:', error);
      }
    };
    
    loadStrategies();
  }, [apiService]);

  // Cargar ejecuciones activas desde el backend
  useEffect(() => {
    const loadActiveExecutions = async () => {
      try {
        const realActiveExecutions = await apiService.getActiveExecutions();
        setActiveExecutions(realActiveExecutions);
      } catch (error) {
        console.error('Error cargando ejecuciones activas:', error);
      }
    };
    
    loadActiveExecutions();
    
    // Actualizar cada 30 segundos
    const interval = setInterval(loadActiveExecutions, 30000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Cargar historial de ejecuciones desde el backend
  useEffect(() => {
    const loadExecutionHistory = async () => {
      try {
        const realExecutionHistory = await apiService.getExecutionHistory();
        setExecutionHistory(realExecutionHistory);
      } catch (error) {
        console.error('Error cargando historial de ejecuciones:', error);
      }
    };
    
    loadExecutionHistory();
    
    // Actualizar cada 2 minutos
    const interval = setInterval(loadExecutionHistory, 120000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Ejecutar estrategia seleccionada
  const executeStrategy = useCallback(async (strategyId: string) => {
    if (!strategyId) return;
    
    setIsExecuting(true);
    try {
      // Ejecutar estrategia real a través del backend
      const executionResult = await apiService.executeStrategy(strategyId);
      
      if (executionResult.success) {
        // Agregar a ejecuciones activas
        const newExecution: Execution = {
          id: executionResult.executionId,
          strategyId: strategyId,
          strategyName: strategies.find(s => s.id === strategyId)?.name || 'Desconocida',
          status: 'running',
          startTime: new Date(),
          expectedProfit: executionResult.expectedProfit,
          gasUsed: executionResult.gasEstimate,
          gasPrice: executionResult.gasPrice,
          chainId: executionResult.chainId,
          tokens: executionResult.tokens,
          dexes: executionResult.dexes,
          priority: executionResult.priority || 'medium',
          risk: executionResult.risk || 'medium',
          progress: 0
        };
        
        setActiveExecutions(prev => [newExecution, ...prev]);
        setSelectedStrategy('');
      }
    } catch (error) {
      console.error('Error ejecutando estrategia:', error);
    } finally {
      setIsExecuting(false);
    }
  }, [selectedStrategy, strategies, apiService]);

  // Pausar ejecución
  const pauseExecution = useCallback(async (executionId: string) => {
    try {
      await apiService.pauseExecution(executionId);
      setActiveExecutions(prev => 
        prev.map(exec => 
          exec.id === executionId 
            ? { ...exec, status: 'paused' as any }
            : exec
        )
      );
    } catch (error) {
      console.error('Error pausando ejecución:', error);
    }
  }, [apiService]);

  // Cancelar ejecución
  const cancelExecution = useCallback(async (executionId: string) => {
    try {
      await apiService.cancelExecution(executionId);
      setActiveExecutions(prev => 
        prev.map(exec => 
          exec.id === executionId 
            ? { ...exec, status: 'cancelled' as any }
            : exec
        )
      );
    } catch (error) {
      console.error('Error cancelando ejecución:', error);
    }
  }, [apiService]);

  // Obtener color del estado
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-400';
      case 'pending': return 'text-yellow-400';
      case 'completed': return 'text-blue-400';
      case 'failed': return 'text-red-400';
      case 'cancelled': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener color del riesgo
  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard de Ejecución</h1>
          <p className="text-blue-300">Control y monitoreo de estrategias de arbitraje</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${
              systemStatus === 'running' ? 'bg-green-500' :
              systemStatus === 'stopped' ? 'bg-red-500' :
              systemStatus === 'error' ? 'bg-yellow-500' :
              'bg-blue-500'
            }`} />
            <span className="text-sm text-blue-300 capitalize">
              Sistema: {systemStatus}
            </span>
          </div>
          
          <button
            onClick={onStartSystem}
            disabled={systemStatus === 'running'}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg font-medium transition-colors"
          >
            ▶️ Iniciar Sistema
          </button>
          
          <button
            onClick={onStopSystem}
            disabled={systemStatus === 'stopped'}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg font-medium transition-colors"
          >
            ⏹️ Detener Sistema
          </button>
        </div>
      </div>

      {/* Control de Estrategias */}
      <div className="bg-black/20 rounded-lg border border-blue-500/30">
        <div className="p-6 border-b border-blue-500/30">
          <h2 className="text-xl font-semibold text-white">Control de Estrategias</h2>
          <p className="text-blue-300">Ejecutar y gestionar estrategias de arbitraje</p>
        </div>
        
        <div className="p-6">
          <div className="flex items-center space-x-4 mb-6">
            <select
              value={selectedStrategy}
              onChange={(e) => setSelectedStrategy(e.target.value)}
              className="flex-1 px-4 py-2 bg-black/30 border border-blue-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            >
              <option value="">Seleccionar estrategia...</option>
              {strategies.filter(s => s.isEnabled).map(strategy => (
                <option key={strategy.id} value={strategy.id}>
                  {strategy.name} ({strategy.category})
                </option>
              ))}
            </select>
            
            <button
              onClick={() => executeStrategy(selectedStrategy)}
              disabled={!selectedStrategy || isExecuting || systemStatus !== 'running'}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg font-medium transition-colors"
            >
              {isExecuting ? '⚡ Ejecutando...' : '⚡ Ejecutar'}
            </button>
          </div>

          {/* Lista de Estrategias */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {strategies.map(strategy => (
              <div key={strategy.id} className="bg-black/30 rounded-lg p-4 border border-blue-500/20">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                    <span className="text-lg">⚡</span>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-medium ${
                    strategy.status === 'active' ? 'bg-green-500/20 text-green-400' :
                    strategy.status === 'paused' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {strategy.status.toUpperCase()}
                  </div>
                </div>
                
                <h3 className="font-semibold text-white mb-2">{strategy.name}</h3>
                <p className="text-sm text-blue-300 mb-3">{strategy.description}</p>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-blue-300">Categoría:</span>
                    <span className="text-white capitalize">{strategy.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-300">Riesgo:</span>
                    <span className={`font-medium ${getRiskColor(strategy.risk)}`}>
                      {strategy.risk.toUpperCase()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-300">Éxito:</span>
                    <span className="text-white">{strategy.successRate.toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-300">Ejecuciones:</span>
                    <span className="text-white">{strategy.totalExecutions}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-300">Ganancia:</span>
                    <span className="text-green-400">${strategy.totalProfit.toLocaleString()}</span>
                  </div>
                </div>
                
                {strategy.lastExecution && (
                  <div className="mt-3 text-xs text-blue-300">
                    Última ejecución: {strategy.lastExecution.toLocaleTimeString()}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Ejecuciones Activas */}
      <div className="bg-black/20 rounded-lg border border-green-500/30">
        <div className="p-6 border-b border-green-500/30">
          <h2 className="text-xl font-semibold text-white">Ejecuciones Activas</h2>
          <p className="text-green-300">Estrategias ejecutándose en tiempo real</p>
        </div>
        
        <div className="p-6">
          {activeExecutions.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">⚡</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Ejecuciones Activas</h3>
              <p className="text-green-300">No hay estrategias ejecutándose en este momento</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeExecutions.map((execution) => (
                <div key={execution.id} className="bg-black/30 rounded-lg p-4 border border-green-500/20">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                        <span className="text-xl">⚡</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{execution.strategyName}</h4>
                        <p className="text-sm text-green-300">
                          Chain {execution.chainId} • {execution.tokens.join(' → ')}
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className={`text-sm font-medium ${getStatusColor(execution.status)}`}>
                        {execution.status.toUpperCase()}
                      </div>
                      <div className="text-xs text-blue-300">
                        {execution.startTime.toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <div className="text-xs text-green-300">Ganancia Esperada</div>
                      <div className="text-sm font-medium text-white">
                        ${execution.expectedProfit.toFixed(4)}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-300">Gas Estimado</div>
                      <div className="text-sm font-medium text-white">
                        {execution.gasUsed ? `${execution.gasUsed.toFixed(4)} ETH` : 'Calculando...'}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-300">Prioridad</div>
                      <div className="text-sm font-medium text-white capitalize">
                        {execution.priority}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-300">Riesgo</div>
                      <div className={`text-sm font-medium ${getRiskColor(execution.risk)}`}>
                        {execution.risk.toUpperCase()}
                      </div>
                    </div>
                  </div>
                  
                  {/* Barra de Progreso */}
                  <div className="mb-4">
                    <div className="flex justify-between text-xs text-blue-300 mb-1">
                      <span>Progreso</span>
                      <span>{execution.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${execution.progress}%` }}
                      />
                    </div>
                  </div>
                  
                  {/* Controles */}
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-blue-300">
                      DEXs: {execution.dexes.join(', ')}
                    </div>
                    
                    <div className="flex space-x-2">
                      {execution.status === 'running' && (
                        <>
                          <button
                            onClick={() => pauseExecution(execution.id)}
                            className="px-3 py-1 bg-yellow-600 hover:bg-yellow-700 text-white text-xs rounded-lg transition-colors"
                          >
                            ⏸️ Pausar
                          </button>
                          <button
                            onClick={() => cancelExecution(execution.id)}
                            className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-xs rounded-lg transition-colors"
                          >
                            ❌ Cancelar
                          </button>
                        </>
                      )}
                      
                      {execution.txHash && (
                        <a
                          href={`https://etherscan.io/tx/${execution.txHash}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs rounded-lg transition-colors"
                        >
                          🔍 Ver TX
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Historial de Ejecuciones */}
      <div className="bg-black/20 rounded-lg border border-purple-500/30">
        <div className="p-6 border-b border-purple-500/30">
          <h2 className="text-xl font-semibold text-white">Historial de Ejecuciones</h2>
          <p className="text-purple-300">Registro de ejecuciones completadas</p>
        </div>
        
        <div className="p-6">
          {executionHistory.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📊</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Historial</h3>
              <p className="text-purple-300">No hay ejecuciones en el historial</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-purple-500/30">
                    <th className="text-left py-2 text-purple-300">Estrategia</th>
                    <th className="text-left py-2 text-purple-300">Estado</th>
                    <th className="text-left py-2 text-purple-300">Ganancia</th>
                    <th className="text-left py-2 text-purple-300">Gas</th>
                    <th className="text-left py-2 text-purple-300">Duración</th>
                    <th className="text-left py-2 text-purple-300">Fecha</th>
                  </tr>
                </thead>
                <tbody>
                  {executionHistory.slice(0, 20).map((execution) => (
                    <tr key={execution.id} className="border-b border-purple-500/20">
                      <td className="py-2 text-white">{execution.strategyName}</td>
                      <td className="py-2">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          execution.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                          execution.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                          'bg-gray-500/20 text-gray-400'
                        }`}>
                          {execution.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-2">
                        <span className={execution.actualProfit && execution.actualProfit > 0 ? 'text-green-400' : 'text-red-400'}>
                          ${execution.actualProfit ? execution.actualProfit.toFixed(4) : '0.0000'}
                        </span>
                      </td>
                      <td className="py-2 text-white">
                        {execution.gasUsed ? `${execution.gasUsed.toFixed(4)} ETH` : '-'}
                      </td>
                      <td className="py-2 text-white">
                        {execution.startTime && execution.endTime ? 
                          `${Math.round((execution.endTime.getTime() - execution.startTime.getTime()) / 1000)}s` : 
                          '-'
                        }
                      </td>
                      <td className="py-2 text-blue-300">
                        {execution.startTime.toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              
              {executionHistory.length > 20 && (
                <div className="text-center py-4">
                  <button className="px-6 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg font-medium transition-colors">
                    Ver Todo ({executionHistory.length})
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
