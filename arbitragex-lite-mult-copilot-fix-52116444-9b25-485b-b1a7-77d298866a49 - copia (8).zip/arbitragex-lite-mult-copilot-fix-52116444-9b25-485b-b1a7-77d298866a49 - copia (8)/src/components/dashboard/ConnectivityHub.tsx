import React, { useState, useEffect, useCallback } from 'react';
import { ApiService } from '../../services/ApiService';

// Interfaces para datos reales
interface ConnectionStatus {
  id: string;
  name: string;
  type: 'rpc' | 'api' | 'database' | 'websocket' | 'external';
  url: string;
  status: 'connected' | 'disconnected' | 'error' | 'connecting';
  latency: number;
  lastCheck: Date;
  uptime: number;
  errorCount: number;
  lastError?: string;
}

interface BlockchainConnection {
  id: string;
  chainId: number;
  name: string;
  rpcUrl: string;
  status: 'connected' | 'disconnected' | 'error' | 'syncing';
  lastBlock: number;
  blockTime: number;
  peers: number;
  syncProgress: number;
  gasPrice: number;
  lastUpdate: Date;
}

interface SystemHealth {
  cpu: number;
  memory: number;
  disk: number;
  network: number;
  uptime: number;
  temperature: number;
  loadAverage: number[];
  processCount: number;
  threadCount: number;
}

interface NetworkMetrics {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  avgResponseTime: number;
  bandwidth: number;
  activeConnections: number;
  requestsPerSecond: number;
  errorRate: number;
}

export const ConnectivityHub: React.FC = () => {
  const [connections, setConnections] = useState<ConnectionStatus[]>([]);
  const [blockchainConnections, setBlockchainConnections] = useState<BlockchainConnection[]>([]);
  const [systemHealth, setSystemHealth] = useState<SystemHealth>({
    cpu: 0,
    memory: 0,
    disk: 0,
    network: 0,
    uptime: 0,
    temperature: 0,
    loadAverage: [0, 0, 0],
    processCount: 0,
    threadCount: 0
  });
  const [networkMetrics, setNetworkMetrics] = useState<NetworkMetrics>({
    totalRequests: 0,
    successfulRequests: 0,
    failedRequests: 0,
    avgResponseTime: 0,
    bandwidth: 0,
    activeConnections: 0,
    requestsPerSecond: 0,
    errorRate: 0
  });
  const [isLoading, setIsLoading] = useState(false);
  const [apiService] = useState(() => new ApiService());

  // Cargar estado de conexiones real desde el backend
  useEffect(() => {
    const loadConnections = async () => {
      try {
        const realConnections = await apiService.getConnectionStatus();
        setConnections(realConnections);
      } catch (error) {
        console.error('Error cargando estado de conexiones:', error);
      }
    };
    
    loadConnections();
    
    // Actualizar cada 30 segundos
    const interval = setInterval(loadConnections, 30000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Cargar conexiones de blockchain reales desde el backend
  useEffect(() => {
    const loadBlockchainConnections = async () => {
      try {
        const realBlockchainConnections = await apiService.getBlockchainConnections();
        setBlockchainConnections(realBlockchainConnections);
      } catch (error) {
        console.error('Error cargando conexiones de blockchain:', error);
      }
    };
    
    loadBlockchainConnections();
    
    // Actualizar cada 15 segundos
    const interval = setInterval(loadBlockchainConnections, 15000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Cargar salud del sistema real desde el backend
  useEffect(() => {
    const loadSystemHealth = async () => {
      try {
        const realSystemHealth = await apiService.getSystemHealth();
        setSystemHealth(realSystemHealth);
      } catch (error) {
        console.error('Error cargando salud del sistema:', error);
      }
    };
    
    loadSystemHealth();
    
    // Actualizar cada 10 segundos
    const interval = setInterval(loadSystemHealth, 10000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Cargar métricas de red reales desde el backend
  useEffect(() => {
    const loadNetworkMetrics = async () => {
      try {
        const realNetworkMetrics = await apiService.getNetworkMetrics();
        setNetworkMetrics(realNetworkMetrics);
      } catch (error) {
        console.error('Error cargando métricas de red:', error);
      }
    };
    
    loadNetworkMetrics();
    
    // Actualizar cada 5 segundos
    const interval = setInterval(loadNetworkMetrics, 5000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Obtener color del estado de conexión
  const getConnectionStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'text-green-400';
      case 'connecting': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      case 'disconnected': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener color del estado de blockchain
  const getBlockchainStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'text-green-400';
      case 'syncing': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      case 'disconnected': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener icono del estado de conexión
  const getConnectionStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return '🟢';
      case 'connecting': return '🟡';
      case 'error': return '🔴';
      case 'disconnected': return '⚫';
      default: return '⚪';
    }
  };

  // Obtener icono del estado de blockchain
  const getBlockchainStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return '🟢';
      case 'syncing': return '🟡';
      case 'error': return '🔴';
      case 'disconnected': return '⚫';
      default: return '⚪';
    }
  };

  // Obtener nombre de la blockchain
  const getBlockchainName = (chainId: number) => {
    const chains: { [key: number]: string } = {
      1: 'Ethereum',
      56: 'BSC',
      137: 'Polygon',
      43114: 'Avalanche',
      250: 'Fantom',
      42161: 'Arbitrum',
      10: 'Optimism',
      139: 'Polygon ZKEVM',
      25: 'Cronos',
      100: 'Gnosis',
      1284: 'Moonbeam',
      8453: 'Base'
    };
    return chains[chainId] || `Chain ${chainId}`;
  };

  // Obtener icono de la blockchain
  const getBlockchainIcon = (chainId: number) => {
    const chainIcons: { [key: number]: string } = {
      1: '🔷', // Ethereum
      56: '🟡', // BSC
      137: '🟣', // Polygon
      43114: '🔴', // Avalanche
      250: '🔵', // Fantom
      42161: '🟦', // Arbitrum
      10: '🟠', // Optimism
      139: '🟢', // Polygon ZKEVM
      25: '🟤', // Cronos
      100: '⚪', // Gnosis
      1284: '🌙', // Moonbeam
      8453: '🔵' // Base
    };
    return chainIcons[chainId] || '⛓️';
  };

  // Calcular métricas agregadas
  const calculateAggregatedMetrics = useCallback(() => {
    const totalConnections = connections.length;
    const connectedConnections = connections.filter(c => c.status === 'connected').length;
    const errorConnections = connections.filter(c => c.status === 'error').length;
    const avgLatency = connections.length > 0 ? 
      connections.reduce((acc, c) => acc + c.latency, 0) / connections.length : 0;
    
    const totalBlockchains = blockchainConnections.length;
    const connectedBlockchains = blockchainConnections.filter(b => b.status === 'connected').length;
    const syncingBlockchains = blockchainConnections.filter(b => b.status === 'syncing').length;
    
    return {
      totalConnections,
      connectedConnections,
      errorConnections,
      avgLatency,
      totalBlockchains,
      connectedBlockchains,
      syncingBlockchains
    };
  }, [connections, blockchainConnections]);

  const aggregatedMetrics = calculateAggregatedMetrics();

  return (
    <div className="space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard de Conectividad</h1>
          <p className="text-blue-300">Estado de infraestructura y conectividad del sistema</p>
        </div>
      </div>

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-black/20 rounded-lg p-4 border border-blue-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-300 text-sm">Conexiones</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.connectedConnections}/{aggregatedMetrics.totalConnections}</p>
            </div>
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">🔌</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-blue-300">
            {aggregatedMetrics.errorConnections} con errores
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-green-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-300 text-sm">Blockchains</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.connectedBlockchains}/{aggregatedMetrics.totalBlockchains}</p>
            </div>
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">⛓️</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-green-300">
            {aggregatedMetrics.syncingBlockchains} sincronizando
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-yellow-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-300 text-sm">Latencia Promedio</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.avgLatency.toFixed(0)}ms</p>
            </div>
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">⏱️</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-yellow-300">
            Tiempo de respuesta
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-purple-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-300 text-sm">Uptime Sistema</p>
              <p className="text-2xl font-bold text-white">{systemHealth.uptime.toFixed(1)}%</p>
            </div>
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">💻</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-purple-300">
            Tiempo activo
          </div>
        </div>
      </div>

      {/* Estado de Conexiones */}
      <div className="bg-black/20 rounded-lg border border-blue-500/30">
        <div className="p-6 border-b border-blue-500/30">
          <h2 className="text-xl font-semibold text-white">Estado de Conexiones</h2>
          <p className="text-blue-300">Monitoreo de servicios y APIs del sistema</p>
        </div>
        
        <div className="p-6">
          {connections.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔌</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Conexiones</h3>
              <p className="text-blue-300">No hay conexiones configuradas para monitorear</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {connections.map((connection) => (
                <div key={connection.id} className="bg-black/30 rounded-lg p-4 border border-blue-500/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <span className="text-lg">🔌</span>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-medium ${
                      connection.status === 'connected' ? 'bg-green-500/20 text-green-400' :
                      connection.status === 'connecting' ? 'bg-yellow-500/20 text-yellow-400' :
                      connection.status === 'error' ? 'bg-red-500/20 text-red-400' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {connection.status.toUpperCase()}
                    </div>
                  </div>
                  
                  <h3 className="font-semibold text-white mb-2">{connection.name}</h3>
                  <p className="text-sm text-blue-300 mb-3">{connection.type.toUpperCase()}</p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-blue-300">URL:</span>
                      <span className="text-white text-xs max-w-32 truncate" title={connection.url}>
                        {connection.url}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-300">Latencia:</span>
                      <span className="text-white">{connection.latency}ms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-300">Uptime:</span>
                      <span className="text-white">{connection.uptime.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-300">Errores:</span>
                      <span className="text-white">{connection.errorCount}</span>
                    </div>
                  </div>
                  
                  <div className="mt-3 text-xs text-blue-300">
                    Última verificación: {connection.lastCheck.toLocaleTimeString()}
                  </div>
                  
                  {connection.lastError && (
                    <div className="mt-2 text-xs text-red-400 bg-red-500/10 p-2 rounded">
                      Error: {connection.lastError}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Conexiones de Blockchain */}
      <div className="bg-black/20 rounded-lg border border-green-500/30">
        <div className="p-6 border-b border-green-500/30">
          <h2 className="text-xl font-semibold text-white">Conexiones de Blockchain</h2>
          <p className="text-green-300">Estado de las conexiones a las diferentes blockchains</p>
        </div>
        
        <div className="p-6">
          {blockchainConnections.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">⛓️</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Conexiones de Blockchain</h3>
              <p className="text-green-300">No hay conexiones de blockchain configuradas</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {blockchainConnections.map((blockchain) => (
                <div key={blockchain.id} className="bg-black/30 rounded-lg p-4 border border-green-500/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{getBlockchainIcon(blockchain.chainId)}</span>
                      <span className="font-semibold text-white">{getBlockchainName(blockchain.chainId)}</span>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-medium ${
                      blockchain.status === 'connected' ? 'bg-green-500/20 text-green-400' :
                      blockchain.status === 'syncing' ? 'bg-yellow-500/20 text-yellow-400' :
                      blockchain.status === 'error' ? 'bg-red-500/20 text-red-400' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {blockchain.status.toUpperCase()}
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-green-300">Último Bloque:</span>
                      <span className="text-white">{blockchain.lastBlock.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Tiempo de Bloque:</span>
                      <span className="text-white">{blockchain.blockTime}s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Peers:</span>
                      <span className="text-white">{blockchain.peers}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Sincronización:</span>
                      <span className="text-white">{blockchain.syncProgress.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Gas:</span>
                      <span className="text-white">{blockchain.gasPrice} gwei</span>
                    </div>
                  </div>
                  
                  <div className="mt-3 text-xs text-blue-300">
                    Actualizado: {blockchain.lastUpdate.toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Salud del Sistema */}
      <div className="bg-black/20 rounded-lg border border-yellow-500/30">
        <div className="p-6 border-b border-yellow-500/30">
          <h2 className="text-xl font-semibold text-white">Salud del Sistema</h2>
          <p className="text-yellow-300">Métricas de rendimiento y recursos del sistema</p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-black/30 rounded-lg p-4 border border-yellow-500/20">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-2">{systemHealth.cpu.toFixed(1)}%</div>
                <div className="text-sm text-yellow-300">CPU</div>
                <div className="w-full bg-black/30 rounded-full h-2 mt-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      systemHealth.cpu < 50 ? 'bg-green-500' :
                      systemHealth.cpu < 80 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${systemHealth.cpu}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4 border border-yellow-500/20">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-2">{systemHealth.memory.toFixed(1)}%</div>
                <div className="text-sm text-yellow-300">Memoria</div>
                <div className="w-full bg-black/30 rounded-full h-2 mt-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      systemHealth.memory < 70 ? 'bg-green-500' :
                      systemHealth.memory < 90 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${systemHealth.memory}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4 border border-yellow-500/20">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-2">{systemHealth.disk.toFixed(1)}%</div>
                <div className="text-sm text-yellow-300">Disco</div>
                <div className="w-full bg-black/30 rounded-full h-2 mt-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      systemHealth.disk < 80 ? 'bg-green-500' :
                      systemHealth.disk < 95 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${systemHealth.disk}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4 border border-yellow-500/20">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-2">{systemHealth.network.toFixed(1)}%</div>
                <div className="text-sm text-yellow-300">Red</div>
                <div className="w-full bg-black/30 rounded-full h-2 mt-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      systemHealth.network < 50 ? 'bg-green-500' :
                      systemHealth.network < 80 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${systemHealth.network}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="bg-black/30 rounded-lg p-4 border border-yellow-500/20">
              <h3 className="font-semibold text-white mb-3">Información del Sistema</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-yellow-300">Uptime:</span>
                  <span className="text-white">{systemHealth.uptime.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-yellow-300">Temperatura:</span>
                  <span className="text-white">{systemHealth.temperature.toFixed(1)}°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-yellow-300">Procesos:</span>
                  <span className="text-white">{systemHealth.processCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-yellow-300">Hilos:</span>
                  <span className="text-white">{systemHealth.threadCount}</span>
                </div>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4 border border-yellow-500/20">
              <h3 className="font-semibold text-white mb-3">Carga del Sistema</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-yellow-300">1 min:</span>
                  <span className="text-white">{systemHealth.loadAverage[0].toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-yellow-300">5 min:</span>
                  <span className="text-white">{systemHealth.loadAverage[1].toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-yellow-300">15 min:</span>
                  <span className="text-white">{systemHealth.loadAverage[2].toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Métricas de Red */}
      <div className="bg-black/20 rounded-lg border border-purple-500/30">
        <div className="p-6 border-b border-purple-500/30">
          <h2 className="text-xl font-semibold text-white">Métricas de Red</h2>
          <p className="text-purple-300">Estadísticas de tráfico y rendimiento de red</p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-2">{networkMetrics.totalRequests.toLocaleString()}</div>
                <div className="text-sm text-purple-300">Total Requests</div>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-2">{networkMetrics.requestsPerSecond.toFixed(1)}</div>
                <div className="text-sm text-purple-300">Requests/s</div>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-2">{networkMetrics.avgResponseTime.toFixed(0)}ms</div>
                <div className="text-sm text-purple-300">Tiempo Respuesta</div>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
              <div className="text-center">
                <div className="text-2xl font-bold text-white mb-2">{networkMetrics.activeConnections}</div>
                <div className="text-sm text-purple-300">Conexiones Activas</div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
              <h3 className="font-semibold text-white mb-3">Estadísticas de Éxito</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-purple-300">Exitosas:</span>
                  <span className="text-green-400">{networkMetrics.successfulRequests.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-300">Fallidas:</span>
                  <span className="text-red-400">{networkMetrics.failedRequests.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-300">Tasa de Error:</span>
                  <span className="text-white">{networkMetrics.errorRate.toFixed(2)}%</span>
                </div>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
              <h3 className="font-semibold text-white mb-3">Ancho de Banda</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-purple-300">Actual:</span>
                  <span className="text-white">{networkMetrics.bandwidth.toFixed(1)} MB/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-300">Promedio:</span>
                  <span className="text-white">{(networkMetrics.bandwidth * 0.8).toFixed(1)} MB/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-300">Pico:</span>
                  <span className="text-white">{(networkMetrics.bandwidth * 1.5).toFixed(1)} MB/s</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
