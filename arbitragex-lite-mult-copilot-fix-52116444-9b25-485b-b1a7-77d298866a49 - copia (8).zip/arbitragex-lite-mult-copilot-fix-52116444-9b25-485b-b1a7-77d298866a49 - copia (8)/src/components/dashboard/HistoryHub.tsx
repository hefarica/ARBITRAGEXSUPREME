import React, { useState, useEffect, useCallback } from 'react';
import { ApiService } from '../../services/ApiService';

// Interfaces para datos reales
interface HistoricalData {
  id: string;
  date: Date;
  totalProfit: number;
  totalTransactions: number;
  successRate: number;
  avgGasUsed: number;
  avgGasPrice: number;
  volume: number;
  roi: number;
  opportunities: number;
  strategies: string[];
  chains: number[];
}

interface StrategyPerformance {
  id: string;
  name: string;
  category: 'basic' | 'advanced' | 'specialized' | 'ai-powered';
  totalExecutions: number;
  successRate: number;
  totalProfit: number;
  avgProfit: number;
  bestDay: Date;
  worstDay: Date;
  avgExecutionTime: number;
  gasEfficiency: number;
}

interface MarketCondition {
  id: string;
  date: Date;
  ethPrice: number;
  gasPrice: number;
  marketVolatility: number;
  arbitrageOpportunities: number;
  avgProfitMargin: number;
  totalVolume: number;
  activeStrategies: number;
  marketTrend: 'bullish' | 'bearish' | 'sideways';
}

export const HistoryHub: React.FC = () => {
  const [historicalData, setHistoricalData] = useState<HistoricalData[]>([]);
  const [strategyPerformance, setStrategyPerformance] = useState<StrategyPerformance[]>([]);
  const [marketConditions, setMarketConditions] = useState<MarketCondition[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<'1d' | '7d' | '30d' | '90d' | '1y'>('7d');
  const [selectedMetric, setSelectedMetric] = useState<'profit' | 'transactions' | 'volume' | 'roi'>('profit');
  const [isLoading, setIsLoading] = useState(false);
  const [apiService] = useState(() => new ApiService());

  // Cargar datos históricos reales desde el backend
  useEffect(() => {
    const loadHistoricalData = async () => {
      setIsLoading(true);
      try {
        const realHistoricalData = await apiService.getHistoricalData(selectedPeriod);
        setHistoricalData(realHistoricalData);
      } catch (error) {
        console.error('Error cargando datos históricos:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadHistoricalData();
  }, [selectedPeriod, apiService]);

  // Cargar rendimiento de estrategias real desde el backend
  useEffect(() => {
    const loadStrategyPerformance = async () => {
      try {
        const realStrategyPerformance = await apiService.getStrategyPerformance(selectedPeriod);
        setStrategyPerformance(realStrategyPerformance);
      } catch (error) {
        console.error('Error cargando rendimiento de estrategias:', error);
      }
    };
    
    loadStrategyPerformance();
  }, [selectedPeriod, apiService]);

  // Cargar condiciones de mercado reales desde el backend
  useEffect(() => {
    const loadMarketConditions = async () => {
      try {
        const realMarketConditions = await apiService.getMarketConditions(selectedPeriod);
        setMarketConditions(realMarketConditions);
      } catch (error) {
        console.error('Error cargando condiciones de mercado:', error);
      }
    };
    
    loadMarketConditions();
  }, [selectedPeriod, apiService]);

  // Calcular métricas agregadas
  const calculateAggregatedMetrics = useCallback(() => {
    if (historicalData.length === 0) return null;
    
    const totalProfit = historicalData.reduce((acc, data) => acc + data.totalProfit, 0);
    const totalTransactions = historicalData.reduce((acc, data) => acc + data.totalTransactions, 0);
    const avgSuccessRate = historicalData.reduce((acc, data) => acc + data.successRate, 0) / historicalData.length;
    const totalVolume = historicalData.reduce((acc, data) => acc + data.volume, 0);
    const avgROI = historicalData.reduce((acc, data) => acc + data.roi, 0) / historicalData.length;
    
    return {
      totalProfit,
      totalTransactions,
      avgSuccessRate,
      totalVolume,
      avgROI
    };
  }, [historicalData]);

  // Obtener color del rendimiento
  const getPerformanceColor = (value: number, threshold: number) => {
    if (value >= threshold * 0.8) return 'text-green-400';
    if (value >= threshold * 0.6) return 'text-yellow-400';
    return 'text-red-400';
  };

  // Obtener color de la tendencia del mercado
  const getMarketTrendColor = (trend: string) => {
    switch (trend) {
      case 'bullish': return 'text-green-400';
      case 'bearish': return 'text-red-400';
      case 'sideways': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener icono de la tendencia del mercado
  const getMarketTrendIcon = (trend: string) => {
    switch (trend) {
      case 'bullish': return '📈';
      case 'bearish': return '📉';
      case 'sideways': return '➡️';
      default: return '📊';
    }
  };

  const aggregatedMetrics = calculateAggregatedMetrics();

  return (
    <div className="space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard de Historiales</h1>
          <p className="text-blue-300">Análisis histórico y reportes de rendimiento</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value as any)}
            className="px-4 py-2 bg-black/30 border border-blue-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          >
            <option value="1d">Último Día</option>
            <option value="7d">Última Semana</option>
            <option value="30d">Último Mes</option>
            <option value="90d">Últimos 3 Meses</option>
            <option value="1y">Último Año</option>
          </select>
          
          <select
            value={selectedMetric}
            onChange={(e) => setSelectedMetric(e.target.value as any)}
            className="px-4 py-2 bg-black/30 border border-blue-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          >
            <option value="profit">Ganancia</option>
            <option value="transactions">Transacciones</option>
            <option value="volume">Volumen</option>
            <option value="roi">ROI</option>
          </select>
        </div>
      </div>

      {/* Métricas Principales */}
      {aggregatedMetrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="bg-black/20 rounded-lg p-4 border border-blue-500/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-300 text-sm">Ganancia Total</p>
                <p className="text-2xl font-bold text-white">${aggregatedMetrics.totalProfit.toFixed(4)}</p>
              </div>
              <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <span className="text-lg">💰</span>
              </div>
            </div>
          </div>

          <div className="bg-black/20 rounded-lg p-4 border border-green-500/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-300 text-sm">Transacciones</p>
                <p className="text-2xl font-bold text-white">{aggregatedMetrics.totalTransactions}</p>
              </div>
              <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <span className="text-lg">💱</span>
              </div>
            </div>
          </div>

          <div className="bg-black/20 rounded-lg p-4 border border-yellow-500/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-300 text-sm">Tasa de Éxito</p>
                <p className="text-2xl font-bold text-white">{aggregatedMetrics.avgSuccessRate.toFixed(1)}%</p>
              </div>
              <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                <span className="text-lg">✅</span>
              </div>
            </div>
          </div>

          <div className="bg-black/20 rounded-lg p-4 border border-purple-500/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm">Volumen Total</p>
                <p className="text-2xl font-bold text-white">${aggregatedMetrics.totalVolume.toLocaleString()}</p>
              </div>
              <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <span className="text-lg">📊</span>
              </div>
            </div>
          </div>

          <div className="bg-black/20 rounded-lg p-4 border border-indigo-500/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-indigo-300 text-sm">ROI Promedio</p>
                <p className="text-2xl font-bold text-white">{aggregatedMetrics.avgROI.toFixed(2)}%</p>
              </div>
              <div className="w-10 h-10 bg-indigo-500/20 rounded-lg flex items-center justify-center">
                <span className="text-lg">📈</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Datos Históricos */}
      <div className="bg-black/20 rounded-lg border border-blue-500/30">
        <div className="p-6 border-b border-blue-500/30">
          <h2 className="text-xl font-semibold text-white">Datos Históricos</h2>
          <p className="text-blue-300">Rendimiento del sistema a lo largo del tiempo</p>
        </div>
        
        <div className="p-6">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">⏳</div>
              <h3 className="text-xl font-semibold text-white mb-2">Cargando Datos</h3>
              <p className="text-blue-300">Obteniendo información histórica del sistema...</p>
            </div>
          ) : historicalData.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📊</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Datos Históricos</h3>
              <p className="text-blue-300">No hay datos históricos disponibles para el período seleccionado</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-blue-500/30">
                    <th className="text-left py-3 text-blue-300">Fecha</th>
                    <th className="text-left py-3 text-blue-300">Ganancia</th>
                    <th className="text-left py-3 text-blue-300">Transacciones</th>
                    <th className="text-left py-3 text-blue-300">Éxito</th>
                    <th className="text-left py-3 text-blue-300">Gas Promedio</th>
                    <th className="text-left py-3 text-blue-300">Volumen</th>
                    <th className="text-left py-3 text-blue-300">ROI</th>
                    <th className="text-left py-3 text-blue-300">Oportunidades</th>
                  </tr>
                </thead>
                <tbody>
                  {historicalData.map((data) => (
                    <tr key={data.id} className="border-b border-blue-500/20 hover:bg-black/30 transition-colors">
                      <td className="py-3 text-white">
                        {data.date.toLocaleDateString()}
                      </td>
                      <td className="py-3">
                        <span className={getPerformanceColor(data.totalProfit, 0.1)}>
                          ${data.totalProfit.toFixed(4)}
                        </span>
                      </td>
                      <td className="py-3 text-white">
                        {data.totalTransactions}
                      </td>
                      <td className="py-3">
                        <span className={getPerformanceColor(data.successRate, 80)}>
                          {data.successRate.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-3 text-white">
                        {(data.avgGasUsed * 0.000000001).toFixed(4)} ETH
                      </td>
                      <td className="py-3 text-white">
                        ${data.volume.toLocaleString()}
                      </td>
                      <td className="py-3">
                        <span className={getPerformanceColor(data.roi, 5)}>
                          {data.roi.toFixed(2)}%
                        </span>
                      </td>
                      <td className="py-3 text-white">
                        {data.opportunities}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Rendimiento de Estrategias */}
      <div className="bg-black/20 rounded-lg border border-green-500/30">
        <div className="p-6 border-b border-green-500/30">
          <h2 className="text-xl font-semibold text-white">Rendimiento de Estrategias</h2>
          <p className="text-green-300">Análisis detallado del rendimiento por estrategia</p>
        </div>
        
        <div className="p-6">
          {strategyPerformance.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">⚡</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Datos de Estrategias</h3>
              <p className="text-green-300">No hay datos de rendimiento de estrategias disponibles</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {strategyPerformance.map((strategy) => (
                <div key={strategy.id} className="bg-black/30 rounded-lg p-4 border border-green-500/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <span className="text-lg">⚡</span>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-medium ${
                      strategy.category === 'basic' ? 'bg-blue-500/20 text-blue-400' :
                      strategy.category === 'advanced' ? 'bg-yellow-500/20 text-yellow-400' :
                      strategy.category === 'specialized' ? 'bg-purple-500/20 text-purple-400' :
                      'bg-indigo-500/20 text-indigo-400'
                    }`}>
                      {strategy.category.toUpperCase()}
                    </div>
                  </div>
                  
                  <h3 className="font-semibold text-white mb-2">{strategy.name}</h3>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-green-300">Ejecuciones:</span>
                      <span className="text-white">{strategy.totalExecutions}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Éxito:</span>
                      <span className={getPerformanceColor(strategy.successRate, 80)}>
                        {strategy.successRate.toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Ganancia:</span>
                      <span className="text-white">${strategy.totalProfit.toFixed(4)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Promedio:</span>
                      <span className="text-white">${strategy.avgProfit.toFixed(4)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Tiempo:</span>
                      <span className="text-white">{strategy.avgExecutionTime.toFixed(1)}s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-300">Eficiencia Gas:</span>
                      <span className={getPerformanceColor(strategy.gasEfficiency, 0.8)}>
                        {(strategy.gasEfficiency * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-3 text-xs text-blue-300">
                    <div>Mejor día: {strategy.bestDay.toLocaleDateString()}</div>
                    <div>Peor día: {strategy.worstDay.toLocaleDateString()}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Condiciones de Mercado */}
      <div className="bg-black/20 rounded-lg border border-purple-500/30">
        <div className="p-6 border-b border-purple-500/30">
          <h2 className="text-xl font-semibold text-white">Condiciones de Mercado</h2>
          <p className="text-purple-300">Análisis de las condiciones del mercado y su impacto</p>
        </div>
        
        <div className="p-6">
          {marketConditions.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📊</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Datos de Mercado</h3>
              <p className="text-purple-300">No hay datos de condiciones de mercado disponibles</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {marketConditions.map((condition) => (
                <div key={condition.id} className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                      <span className="text-lg">{getMarketTrendIcon(condition.marketTrend)}</span>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-medium ${
                      condition.marketTrend === 'bullish' ? 'bg-green-500/20 text-green-400' :
                      condition.marketTrend === 'bearish' ? 'bg-red-500/20 text-red-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {condition.marketTrend.toUpperCase()}
                    </div>
                  </div>
                  
                  <div className="text-center mb-3">
                    <div className="text-sm text-purple-300">Fecha</div>
                    <div className="text-white font-medium">{condition.date.toLocaleDateString()}</div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-purple-300">Precio ETH:</span>
                      <span className="text-white">${condition.ethPrice.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-300">Gas:</span>
                      <span className="text-white">{condition.gasPrice} gwei</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-300">Volatilidad:</span>
                      <span className="text-white">{condition.marketVolatility.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-300">Oportunidades:</span>
                      <span className="text-white">{condition.arbitrageOpportunities}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-300">Margen Promedio:</span>
                      <span className="text-white">{condition.avgProfitMargin.toFixed(2)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-300">Volumen:</span>
                      <span className="text-white">${condition.totalVolume.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-300">Estrategias Activas:</span>
                      <span className="text-white">{condition.activeStrategies}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
