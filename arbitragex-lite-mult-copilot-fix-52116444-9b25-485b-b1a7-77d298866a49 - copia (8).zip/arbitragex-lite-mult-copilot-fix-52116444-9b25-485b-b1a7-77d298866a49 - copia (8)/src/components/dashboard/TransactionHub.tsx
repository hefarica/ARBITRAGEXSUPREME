import React, { useState, useEffect, useCallback } from 'react';
import { ApiService } from '../../services/ApiService';

// Interfaces para datos reales
interface Transaction {
  id: string;
  hash: string;
  chainId: number;
  strategyId: string;
  strategyName: string;
  status: 'pending' | 'confirmed' | 'failed' | 'reverted';
  blockNumber?: number;
  timestamp: Date;
  from: string;
  to: string;
  value: number;
  gasUsed: number;
  gasPrice: number;
  actualProfit?: number;
  expectedProfit: number;
  tokens: string[];
  dexes: string[];
  priority: 'low' | 'medium' | 'high' | 'critical';
  risk: 'low' | 'medium' | 'high';
  nonce: number;
  input: string;
  confirmations: number;
  maxFeePerGas?: number;
  maxPriorityFeePerGas?: number;
}

interface TransactionStats {
  totalTransactions: number;
  successfulTransactions: number;
  failedTransactions: number;
  totalGasUsed: number;
  totalProfit: number;
  avgGasPrice: number;
  avgConfirmationTime: number;
  successRate: number;
  totalValue: number;
  avgProfit: number;
}

export const TransactionHub: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState<TransactionStats>({
    totalTransactions: 0,
    successfulTransactions: 0,
    failedTransactions: 0,
    totalGasUsed: 0,
    totalProfit: 0,
    avgGasPrice: 0,
    avgConfirmationTime: 0,
    successRate: 0,
    totalValue: 0,
    avgProfit: 0
  });
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterChain, setFilterChain] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<keyof Transaction>('timestamp');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [transactionsPerPage] = useState(20);
  const [apiService] = useState(() => new ApiService());

  // Cargar transacciones reales desde el backend
  useEffect(() => {
    const loadTransactions = async () => {
      try {
        const realTransactions = await apiService.getTransactions();
        setTransactions(realTransactions);
      } catch (error) {
        console.error('Error cargando transacciones:', error);
      }
    };
    
    loadTransactions();
    
    // Actualizar cada 30 segundos
    const interval = setInterval(loadTransactions, 30000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Calcular estadísticas basadas en transacciones reales
  useEffect(() => {
    if (transactions.length === 0) return;
    
    const totalTx = transactions.length;
    const successfulTx = transactions.filter(tx => tx.status === 'confirmed').length;
    const failedTx = transactions.filter(tx => tx.status === 'failed' || tx.status === 'reverted').length;
    const totalGas = transactions.reduce((acc, tx) => acc + tx.gasUsed, 0);
    const totalProfit = transactions.reduce((acc, tx) => acc + (tx.actualProfit || 0), 0);
    const avgGas = transactions.reduce((acc, tx) => acc + tx.gasPrice, 0) / totalTx;
    const totalValue = transactions.reduce((acc, tx) => acc + tx.value, 0);
    
    // Calcular tiempo promedio de confirmación
    const confirmedTxs = transactions.filter(tx => tx.status === 'confirmed' && tx.blockNumber);
    const avgConfirmationTime = confirmedTxs.length > 0 ? 
      confirmedTxs.reduce((acc, tx) => acc + tx.confirmations, 0) / confirmedTxs.length : 0;
    
    setStats({
      totalTransactions: totalTx,
      successfulTransactions: successfulTx,
      failedTransactions: failedTx,
      totalGasUsed: totalGas,
      totalProfit: totalProfit,
      avgGasPrice: avgGas,
      avgConfirmationTime: avgConfirmationTime,
      successRate: totalTx > 0 ? (successfulTx / totalTx) * 100 : 0,
      totalValue: totalValue,
      avgProfit: totalTx > 0 ? totalProfit / totalTx : 0
    });
  }, [transactions]);

  // Filtrar y ordenar transacciones
  const filteredAndSortedTransactions = useCallback(() => {
    let filtered = transactions.filter(tx => {
      const matchesStatus = filterStatus === 'all' || tx.status === filterStatus;
      const matchesChain = filterChain === 'all' || tx.chainId.toString() === filterChain;
      const matchesSearch = searchQuery === '' || 
        tx.hash.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.strategyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.to.toLowerCase().includes(searchQuery.toLowerCase());
      
      return matchesStatus && matchesChain && matchesSearch;
    });

    // Ordenar
    filtered.sort((a, b) => {
      const aValue = a[sortBy];
      const bValue = b[sortBy];
      
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortOrder === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      }
      
      if (aValue instanceof Date && bValue instanceof Date) {
        return sortOrder === 'asc' ? aValue.getTime() - bValue.getTime() : bValue.getTime() - aValue.getTime();
      }
      
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        return sortOrder === 'asc' ? aValue - bValue : bValue - aValue;
      }
      
      return 0;
    });

    return filtered;
  }, [transactions, filterStatus, filterChain, searchQuery, sortBy, sortOrder]);

  // Paginación
  const paginatedTransactions = useCallback(() => {
    const filtered = filteredAndSortedTransactions();
    const startIndex = (currentPage - 1) * transactionsPerPage;
    return filtered.slice(startIndex, startIndex + transactionsPerPage);
  }, [filteredAndSortedTransactions, currentPage, transactionsPerPage]);

  // Cambiar página
  const changePage = (page: number) => {
    setCurrentPage(page);
  };

  // Obtener color del estado
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'text-green-400';
      case 'pending': return 'text-yellow-400';
      case 'failed': return 'text-red-400';
      case 'reverted': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener color del riesgo
  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener nombre de la blockchain
  const getChainName = (chainId: number) => {
    const chains: { [key: number]: string } = {
      1: 'Ethereum',
      56: 'BSC',
      137: 'Polygon',
      43114: 'Avalanche',
      250: 'Fantom',
      42161: 'Arbitrum',
      10: 'Optimism',
      139: 'Polygon ZKEVM',
      25: 'Cronos',
      100: 'Gnosis',
      1284: 'Moonbeam',
      8453: 'Base'
    };
    return chains[chainId] || `Chain ${chainId}`;
  };

  // Obtener icono de la blockchain
  const getChainIcon = (chainId: number) => {
    const chainIcons: { [key: number]: string } = {
      1: '🔷', // Ethereum
      56: '🟡', // BSC
      137: '🟣', // Polygon
      43114: '🔴', // Avalanche
      250: '🔵', // Fantom
      42161: '🟦', // Arbitrum
      10: '🟠', // Optimism
      139: '🟢', // Polygon ZKEVM
      25: '🟤', // Cronos
      100: '⚪', // Gnosis
      1284: '🌙', // Moonbeam
      8453: '🔵' // Base
    };
    return chainIcons[chainId] || '⛓️';
  };

  return (
    <div className="space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard de Transacciones</h1>
          <p className="text-blue-300">Gestión y análisis de transacciones de arbitraje</p>
        </div>
      </div>

      {/* Estadísticas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-black/20 rounded-lg p-4 border border-blue-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-300 text-sm">Total TX</p>
              <p className="text-2xl font-bold text-white">{stats.totalTransactions}</p>
            </div>
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">📊</span>
            </div>
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-green-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-300 text-sm">Exitosas</p>
              <p className="text-2xl font-bold text-white">{stats.successfulTransactions}</p>
            </div>
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-red-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-300 text-sm">Fallidas</p>
              <p className="text-2xl font-bold text-white">{stats.failedTransactions}</p>
            </div>
            <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">❌</span>
            </div>
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-yellow-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-300 text-sm">Gas Total</p>
              <p className="text-2xl font-bold text-white">{(stats.totalGasUsed * 0.000000001).toFixed(4)}</p>
            </div>
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">⛽</span>
            </div>
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-purple-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-300 text-sm">Ganancia</p>
              <p className="text-2xl font-bold text-white">${stats.totalProfit.toFixed(4)}</p>
            </div>
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">💰</span>
            </div>
          </div>
        </div>
      </div>

      {/* Métricas Secundarias */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-black/20 rounded-lg p-4 border border-blue-500/30">
          <div className="text-center">
            <p className="text-blue-300 text-sm">Tasa de Éxito</p>
            <p className="text-xl font-bold text-white">{stats.successRate.toFixed(1)}%</p>
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-green-500/30">
          <div className="text-center">
            <p className="text-green-300 text-sm">Gas Promedio</p>
            <p className="text-xl font-bold text-white">{(stats.avgGasPrice * 0.000000001).toFixed(2)} ETH</p>
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-yellow-500/30">
          <div className="text-center">
            <p className="text-yellow-300 text-sm">Valor Total</p>
            <p className="text-xl font-bold text-white">${(stats.totalValue * 0.000000001 * 2000).toFixed(4)}</p>
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-purple-500/30">
          <div className="text-center">
            <p className="text-purple-300 text-sm">Ganancia Promedio</p>
            <p className="text-xl font-bold text-white">${stats.avgProfit.toFixed(4)}</p>
          </div>
        </div>
      </div>

      {/* Filtros y Búsqueda */}
      <div className="bg-black/20 rounded-lg border border-blue-500/30">
        <div className="p-6 border-b border-blue-500/30">
          <h2 className="text-xl font-semibold text-white">Filtros y Búsqueda</h2>
          <p className="text-blue-300">Filtrar transacciones por estado, blockchain y búsqueda</p>
        </div>
        
        <div className="p-6">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <label className="block text-sm font-medium text-blue-300 mb-2">Buscar Transacción</label>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por hash de transacción..."
                className="w-full px-4 py-2 bg-black/30 border border-blue-500/30 rounded-lg text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500"
              />
            </div>
            
            <div className="w-full md:w-48">
              <label className="block text-sm font-medium text-blue-300 mb-2">Estado</label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full px-4 py-2 bg-black/30 border border-blue-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                <option value="all">Todos los Estados</option>
                <option value="pending">Pendiente</option>
                <option value="confirmed">Confirmada</option>
                <option value="failed">Fallida</option>
                <option value="reverted">Revertida</option>
              </select>
            </div>
            
            <div className="w-full md:w-48">
              <label className="block text-sm font-medium text-blue-300 mb-2">Blockchain</label>
              <select
                value={filterChain}
                onChange={(e) => setFilterChain(e.target.value)}
                className="w-full px-4 py-2 bg-black/30 border border-blue-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                <option value="all">Todas las Chains</option>
                <option value="1">Ethereum</option>
                <option value="56">BSC</option>
                <option value="137">Polygon</option>
                <option value="43114">Avalanche</option>
                <option value="250">Fantom</option>
                <option value="42161">Arbitrum</option>
                <option value="10">Optimism</option>
                <option value="139">Polygon ZKEVM</option>
                <option value="25">Cronos</option>
                <option value="100">Gnosis</option>
                <option value="1284">Moonbeam</option>
                <option value="8453">Base</option>
              </select>
            </div>
          </div>

          {/* Ordenamiento */}
          <div className="flex items-center space-x-4">
            <label className="text-sm font-medium text-blue-300">Ordenar por:</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as keyof Transaction)}
              className="px-3 py-1 bg-black/30 border border-blue-500/30 rounded text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            >
              <option value="timestamp">Fecha</option>
              <option value="status">Estado</option>
              <option value="actualProfit">Ganancia</option>
              <option value="gasUsed">Gas</option>
              <option value="value">Valor</option>
              <option value="chainId">Blockchain</option>
            </select>
            
            <button
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded text-white text-sm transition-colors"
            >
              {sortOrder === 'asc' ? '↑ Ascendente' : '↓ Descendente'}
            </button>
          </div>
        </div>
      </div>

      {/* Tabla de Transacciones */}
      <div className="bg-black/20 rounded-lg border border-green-500/30">
        <div className="p-6 border-b border-green-500/30">
          <h2 className="text-xl font-semibold text-white">Transacciones</h2>
          <p className="text-green-300">Lista de transacciones con filtros aplicados</p>
        </div>
        
        <div className="p-6">
          {paginatedTransactions().length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Transacciones</h3>
              <p className="text-green-300">No se encontraron transacciones con los filtros aplicados</p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-green-500/30">
                      <th className="text-left py-3 text-green-300">Hash</th>
                      <th className="text-left py-3 text-green-300">Chain</th>
                      <th className="text-left py-3 text-green-300">Estrategia</th>
                      <th className="text-left py-3 text-green-300">Estado</th>
                      <th className="text-left py-3 text-green-300">Ganancia</th>
                      <th className="text-left py-3 text-green-300">Gas</th>
                      <th className="text-left py-3 text-green-300">Valor</th>
                      <th className="text-left py-3 text-green-300">Fecha</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedTransactions().map((tx) => (
                      <tr key={tx.id} className="border-b border-green-500/20 hover:bg-black/30 transition-colors">
                        <td className="py-3">
                          <div className="flex items-center space-x-2">
                            <span className="text-white font-mono text-xs">
                              {tx.hash.substring(0, 8)}...{tx.hash.substring(tx.hash.length - 6)}
                            </span>
                            <button className="text-blue-400 hover:text-blue-300 text-xs">
                              🔗
                            </button>
                          </div>
                        </td>
                        
                        <td className="py-3">
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{getChainIcon(tx.chainId)}</span>
                            <span className="text-white text-xs">{getChainName(tx.chainId)}</span>
                          </div>
                        </td>
                        
                        <td className="py-3">
                          <div className="text-white text-xs max-w-32 truncate" title={tx.strategyName}>
                            {tx.strategyName}
                          </div>
                        </td>
                        
                        <td className="py-3">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            tx.status === 'confirmed' ? 'bg-green-500/20 text-green-400' :
                            tx.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {tx.status.toUpperCase()}
                          </span>
                        </td>
                        
                        <td className="py-3">
                          <span className={tx.actualProfit && tx.actualProfit > 0 ? 'text-green-400' : 'text-red-400'}>
                            ${tx.actualProfit ? tx.actualProfit.toFixed(4) : '0.0000'}
                          </span>
                        </td>
                        
                        <td className="py-3">
                          <div className="text-white text-xs">
                            <div>{(tx.gasUsed * 0.000000001).toFixed(4)} ETH</div>
                            <div className="text-blue-300">{(tx.gasPrice * 0.000000001).toFixed(2)} gwei</div>
                          </div>
                        </td>
                        
                        <td className="py-3">
                          <div className="text-white text-xs">
                            <div>{(tx.value * 0.000000001).toFixed(4)} ETH</div>
                            <div className="text-blue-300">${(tx.value * 0.000000001 * 2000).toFixed(4)}</div>
                          </div>
                        </td>
                        
                        <td className="py-3">
                          <div className="text-blue-300 text-xs">
                            <div>{tx.timestamp.toLocaleDateString()}</div>
                            <div>{tx.timestamp.toLocaleTimeString()}</div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Paginación */}
              {filteredAndSortedTransactions().length > transactionsPerPage && (
                <div className="flex items-center justify-between mt-6">
                  <div className="text-sm text-blue-300">
                    Mostrando {((currentPage - 1) * transactionsPerPage) + 1} - {Math.min(currentPage * transactionsPerPage, filteredAndSortedTransactions().length)} de {filteredAndSortedTransactions().length} transacciones
                  </div>
                  
                  <div className="flex space-x-2">
                    <button
                      onClick={() => changePage(currentPage - 1)}
                      disabled={currentPage === 1}
                      className="px-3 py-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded text-white text-sm transition-colors"
                    >
                      ← Anterior
                    </button>
                    
                    <span className="px-3 py-1 bg-black/30 border border-blue-500/30 rounded text-white text-sm">
                      Página {currentPage}
                    </span>
                    
                    <button
                      onClick={() => changePage(currentPage + 1)}
                      disabled={currentPage >= Math.ceil(filteredAndSortedTransactions().length / transactionsPerPage)}
                      className="px-3 py-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded text-white text-sm transition-colors"
                    >
                      Siguiente →
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
