import React, { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Badge } from '../../ui/badge'
import { Button } from '../../ui/button'
import { Progress } from '../../ui/progress'
import { Alert, AlertDescription } from '../../ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../ui/tabs'
import { 
  Activity, 
  Zap, 
  TrendingUp, 
  AlertTriangle, 
  Clock, 
  DollarSign,
  Network,
  Shield,
  Target,
  BarChart3,
  Play,
  Pause,
  RefreshCw
} from 'lucide-react'
import { mevLatencyMonitor, LatencyMetrics, MEVOpportunity, NetworkPerformance } from '../../services/MEVLatencyMonitor'
import { mevStrategyOptimizer, MEVStrategy, ExecutionRecommendation } from '../../services/MEVStrategyOptimizer'
import { AdvancedROICalculator, ROICalculation } from '../../services/AdvancedROICalculator'

interface DashboardState {
  isMonitoring: boolean
  isOptimizing: boolean
  latencyMetrics: Map<number, LatencyMetrics>
  networkPerformance: NetworkPerformance[]
  mevOpportunities: MEVOpportunity[]
  strategies: MEVStrategy[]
  recommendations: Map<string, ExecutionRecommendation>
  selectedNetwork: number
  selectedStrategy: string | null
  refreshInterval: number
}

export const MEVAdvancedDashboard: React.FC = () => {
  const [state, setState] = useState<DashboardState>({
    isMonitoring: false,
    isOptimizing: false,
    latencyMetrics: new Map(),
    networkPerformance: [],
    mevOpportunities: [],
    strategies: [],
    recommendations: new Map(),
    selectedNetwork: 1,
    selectedStrategy: null,
    refreshInterval: 5000
  })

  const [roiCalculator] = useState(new AdvancedROICalculator())

  // Inicializar servicios
  useEffect(() => {
    initializeServices()
    return () => {
      cleanupServices()
    }
  }, [])

  // Actualizar datos en tiempo real
  useEffect(() => {
    if (state.isMonitoring) {
      const interval = setInterval(updateDashboardData, state.refreshInterval)
      return () => clearInterval(interval)
    }
  }, [state.isMonitoring, state.refreshInterval])

  const initializeServices = useCallback(async () => {
    try {
      // Iniciar monitoreo de latencia
      await mevLatencyMonitor.startMonitoring()
      setState(prev => ({ ...prev, isMonitoring: true }))

      // Iniciar optimización de estrategias
      await mevStrategyOptimizer.startOptimization()
      setState(prev => ({ ...prev, isOptimizing: true }))

      // Cargar datos iniciales
      await updateDashboardData()
    } catch (error) {
      console.error('Error inicializando servicios MEV:', error)
    }
  }, [])

  const cleanupServices = useCallback(() => {
    mevLatencyMonitor.stopMonitoring()
    mevStrategyOptimizer.stopOptimization()
  }, [])

  const updateDashboardData = useCallback(async () => {
    try {
      // Obtener métricas de latencia para todas las redes
      const networks = [1, 137, 56, 42161, 10, 43114, 250, 25]
      const latencyMetrics = new Map()
      
      for (const chainId of networks) {
        const metrics = await mevLatencyMonitor.getLatencyMetrics(chainId)
        latencyMetrics.set(chainId, metrics)
      }

      // Obtener rendimiento de red
      const networkPerformance = mevLatencyMonitor.getNetworkPerformance()
      
      // Obtener oportunidades MEV
      const mevOpportunities = mevLatencyMonitor.getActiveMEVOpportunities()
      
      // Obtener estrategias optimizadas
      const strategies = mevStrategyOptimizer.getOptimizedStrategies()
      
      // Obtener recomendaciones para estrategias seleccionadas
      const recommendations = new Map()
      for (const strategy of strategies.slice(0, 10)) { // Solo primeras 10
        try {
          const recommendation = await mevStrategyOptimizer.getExecutionRecommendation(strategy.id)
          recommendations.set(strategy.id, recommendation)
        } catch (error) {
          // Ignorar errores de recomendaciones individuales
        }
      }

      setState(prev => ({
        ...prev,
        latencyMetrics,
        networkPerformance,
        mevOpportunities,
        strategies,
        recommendations
      }))
    } catch (error) {
      console.error('Error actualizando datos del dashboard:', error)
    }
  }, [])

  const toggleMonitoring = useCallback(async () => {
    if (state.isMonitoring) {
      mevLatencyMonitor.stopMonitoring()
      setState(prev => ({ ...prev, isMonitoring: false }))
    } else {
      await mevLatencyMonitor.startMonitoring()
      setState(prev => ({ ...prev, isMonitoring: true }))
    }
  }, [state.isMonitoring])

  const toggleOptimization = useCallback(async () => {
    if (state.isOptimizing) {
      mevStrategyOptimizer.stopOptimization()
      setState(prev => ({ ...prev, isOptimizing: false }))
    } else {
      await mevStrategyOptimizer.startOptimization()
      setState(prev => ({ ...prev, isOptimizing: true }))
    }
  }, [state.isOptimizing])

  const getNetworkName = (chainId: number): string => {
    const networks: { [key: number]: string } = {
      1: 'Ethereum',
      137: 'Polygon',
      56: 'BSC',
      42161: 'Arbitrum',
      10: 'Optimism',
      43114: 'Avalanche',
      250: 'Fantom',
      25: 'Cronos'
    }
    return networks[chainId] || 'Unknown'
  }

  const getRiskColor = (riskLevel: string): string => {
    const colors = {
      'low': 'bg-green-100 text-green-800',
      'medium': 'bg-yellow-100 text-yellow-800',
      'high': 'bg-orange-100 text-orange-800',
      'extreme': 'bg-red-100 text-red-800'
    }
    return colors[riskLevel as keyof typeof colors] || colors.medium
  }

  const getRecommendationColor = (recommendation: string): string => {
    const colors = {
      'execute': 'bg-green-100 text-green-800',
      'wait': 'bg-yellow-100 text-yellow-800',
      'skip': 'bg-red-100 text-red-800',
      'optimize': 'bg-blue-100 text-blue-800'
    }
    return colors[recommendation as keyof typeof colors] || colors.medium
  }

  const formatLatency = (latency: number): string => {
    if (latency < 1000) return `${latency}ms`
    if (latency < 60000) return `${(latency / 1000).toFixed(1)}s`
    return `${(latency / 60000).toFixed(1)}m`
  }

  const formatCurrency = (amount: number): string => {
    if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}k`
    return `$${amount.toFixed(0)}`
  }

  const getLatencyStatus = (latency: number): { color: string; status: string } => {
    if (latency < 2000) return { color: 'text-green-600', status: 'Excelente' }
    if (latency < 5000) return { color: 'text-yellow-600', status: 'Buena' }
    if (latency < 10000) return { color: 'text-orange-600', status: 'Aceptable' }
    return { color: 'text-red-600', status: 'Crítica' }
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard MEV Avanzado</h1>
          <p className="text-gray-600">Monitoreo en tiempo real de latencia, estrategias y oportunidades MEV</p>
        </div>
        <div className="flex space-x-3">
          <Button
            variant={state.isMonitoring ? "destructive" : "default"}
            onClick={toggleMonitoring}
            className="flex items-center space-x-2"
          >
            {state.isMonitoring ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{state.isMonitoring ? "Detener" : "Iniciar"} Monitoreo</span>
          </Button>
          <Button
            variant={state.isOptimizing ? "destructive" : "default"}
            onClick={toggleOptimization}
            className="flex items-center space-x-2"
          >
            {state.isOptimizing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{state.isOptimizing ? "Detener" : "Iniciar"} Optimización</span>
          </Button>
          <Button
            variant="outline"
            onClick={updateDashboardData}
            className="flex items-center space-x-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Actualizar</span>
          </Button>
        </div>
      </div>

      {/* Métricas de Estado */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estado Monitoreo</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {state.isMonitoring ? "Activo" : "Inactivo"}
            </div>
            <p className="text-xs text-muted-foreground">
              {state.isMonitoring ? "Monitoreando redes en tiempo real" : "Servicio detenido"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Optimización</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {state.isOptimizing ? "Activa" : "Inactiva"}
            </div>
            <p className="text-xs text-muted-foreground">
              {state.isOptimizing ? "Optimizando estrategias" : "Optimización detenida"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Oportunidades MEV</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{state.mevOpportunities.length}</div>
            <p className="text-xs text-muted-foreground">
              Oportunidades activas detectadas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estrategias</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{state.strategies.length}</div>
            <p className="text-xs text-muted-foreground">
              Estrategias optimizadas
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Dashboard Principal */}
      <Tabs defaultValue="latency" className="space-y-4">
        <TabsList>
          <TabsTrigger value="latency">Monitoreo de Latencia</TabsTrigger>
          <TabsTrigger value="strategies">Estrategias MEV</TabsTrigger>
          <TabsTrigger value="opportunities">Oportunidades</TabsTrigger>
          <TabsTrigger value="networks">Redes</TabsTrigger>
        </TabsList>

        {/* Tab de Monitoreo de Latencia */}
        <TabsContent value="latency" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Métricas de Latencia por Red */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="w-5 h-5" />
                  <span>Métricas de Latencia por Red</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Array.from(state.latencyMetrics.entries()).map(([chainId, metrics]) => (
                  <div key={chainId} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold">{getNetworkName(chainId)}</h4>
                      <Badge variant="outline">{formatLatency(metrics.totalLatency)}</Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Latencia de Red:</span>
                        <span className={getLatencyStatus(metrics.networkLatency).color}>
                          {formatLatency(metrics.networkLatency)}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Tiempo de Bloque:</span>
                        <span>{formatLatency(metrics.blockTime)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Detección MEV:</span>
                        <span>{formatLatency(metrics.mevDetectionLatency)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Confianza:</span>
                        <span className="text-blue-600">{(metrics.confidence * 100).toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Alertas de Latencia */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Alertas de Latencia</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {mevLatencyMonitor.getActiveAlerts().length > 0 ? (
                  <div className="space-y-3">
                    {mevLatencyMonitor.getActiveAlerts().slice(0, 5).map((alert) => (
                      <Alert key={alert.id} className={`
                        ${alert.severity === 'critical' ? 'border-red-500 bg-red-50' : ''}
                        ${alert.severity === 'high' ? 'border-orange-500 bg-orange-50' : ''}
                        ${alert.severity === 'medium' ? 'border-yellow-500 bg-yellow-50' : ''}
                        ${alert.severity === 'low' ? 'border-blue-500 bg-blue-50' : ''}
                      `}>
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{alert.message}</span>
                            <Badge variant="outline" className="ml-2">
                              {getNetworkName(alert.chainId)}
                            </Badge>
                          </div>
                          <div className="text-xs text-gray-600 mt-1">
                            {new Date(alert.timestamp).toLocaleTimeString()}
                          </div>
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    <Shield className="w-12 h-12 mx-auto mb-2 text-green-500" />
                    <p>No hay alertas activas</p>
                    <p className="text-sm">Todas las redes funcionando normalmente</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab de Estrategias MEV */}
        <TabsContent value="strategies" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-5 h-5" />
                <span>Estrategias MEV Optimizadas</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {state.strategies.map((strategy) => {
                  const recommendation = state.recommendations.get(strategy.id)
                  return (
                    <div key={strategy.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-lg">{strategy.name}</h4>
                          <p className="text-sm text-gray-600">{strategy.description}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getRiskColor(strategy.riskLevel)}>
                            {strategy.riskLevel.toUpperCase()}
                          </Badge>
                          {recommendation && (
                            <Badge className={getRecommendationColor(recommendation.recommendation)}>
                              {recommendation.recommendation.toUpperCase()}
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600">
                            {strategy.expectedROI.toFixed(1)}%
                          </div>
                          <div className="text-xs text-gray-600">ROI Esperado</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600">
                            {formatCurrency(strategy.minimumCapital)}
                          </div>
                          <div className="text-xs text-gray-600">Capital Mínimo</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-purple-600">
                            {strategy.gasEfficiency}/10
                          </div>
                          <div className="text-xs text-gray-600">Eficiencia Gas</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-orange-600">
                            {strategy.optimizationScore}
                          </div>
                          <div className="text-xs text-gray-600">Score Optimización</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Red:</span> {getNetworkName(strategy.chainId)}
                        </div>
                        <div>
                          <span className="font-medium">Gas Price:</span> {strategy.estimatedGasPrice} gwei
                        </div>
                        <div>
                          <span className="font-medium">Tiempo Ejecución:</span> {formatLatency(strategy.executionTime)}
                        </div>
                        <div>
                          <span className="font-medium">Tasa Éxito:</span> {(strategy.successRate * 100).toFixed(1)}%
                        </div>
                        <div>
                          <span className="font-medium">Flashbots:</span> {strategy.flashbotsCompatible ? "Sí" : "No"}
                        </div>
                        <div>
                          <span className="font-medium">Protección MEV:</span> {strategy.mevProtection ? "Sí" : "No"}
                        </div>
                      </div>
                      
                      {recommendation && (
                        <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium">Recomendación:</span>
                            <span className="text-sm text-gray-600">
                              Confianza: {(recommendation.confidence * 100).toFixed(1)}%
                            </span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">{recommendation.reason}</p>
                          <div className="text-xs text-gray-600">
                            <span className="font-medium">Gas Price Óptimo:</span> {recommendation.expectedGasPrice} gwei | 
                            <span className="font-medium ml-2">Priority Fee:</span> {recommendation.priorityFee} gwei
                          </div>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Oportunidades MEV */}
        <TabsContent value="opportunities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5" />
                <span>Oportunidades MEV Activas</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {state.mevOpportunities.length > 0 ? (
                <div className="space-y-4">
                  {state.mevOpportunities.map((opportunity) => (
                    <div key={opportunity.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-semibold capitalize">{opportunity.type} Opportunity</h4>
                          <p className="text-sm text-gray-600">
                            {getNetworkName(opportunity.chainId)} • Bloque {opportunity.blockNumber}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getRiskColor(opportunity.riskLevel)}>
                            {opportunity.riskLevel.toUpperCase()}
                          </Badge>
                          <Badge variant="outline">
                            {opportunity.source.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600">
                            {formatCurrency(opportunity.expectedProfit)}
                          </div>
                          <div className="text-xs text-gray-600">Profit Esperado</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600">
                            {opportunity.roi.toFixed(1)}%
                          </div>
                          <div className="text-xs text-gray-600">ROI</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-purple-600">
                            {opportunity.gasEfficiency}/10
                          </div>
                          <div className="text-xs text-gray-600">Eficiencia Gas</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-orange-600">
                            {formatCurrency(opportunity.minimumCapital)}
                          </div>
                          <div className="text-xs text-gray-600">Capital Mínimo</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Gas Price:</span> {opportunity.gasPrice} gwei
                        </div>
                        <div>
                          <span className="font-medium">Priority Fee:</span> {opportunity.priorityFee} gwei
                        </div>
                        <div>
                          <span className="font-medium">Ventana Ejecución:</span> {formatLatency(opportunity.executionWindow)}
                        </div>
                        <div>
                          <span className="font-medium">Confianza:</span> {(opportunity.confidence * 100).toFixed(1)}%
                        </div>
                        <div>
                          <span className="font-medium">Expira en:</span> {formatLatency(opportunity.expiresAt - Date.now())}
                        </div>
                        <div>
                          <span className="font-medium">Detectado:</span> {new Date(opportunity.detectedAt).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-gray-500 py-8">
                  <Target className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                  <p>No hay oportunidades MEV activas</p>
                  <p className="text-sm">El sistema está monitoreando continuamente</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Redes */}
        <TabsContent value="networks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Network className="w-5 h-5" />
                <span>Rendimiento de Redes</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {state.networkPerformance.map((network) => (
                  <div key={network.chainId} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-lg">{network.networkName}</h4>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">
                          {(network.uptime).toFixed(1)}% Uptime
                        </Badge>
                        <Badge variant="outline">
                          {(network.successRate * 100).toFixed(1)}% Éxito
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          {formatLatency(network.averageBlockTime)}
                        </div>
                        <div className="text-xs text-gray-600">Tiempo Bloque Promedio</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {formatLatency(network.averageLatency)}
                        </div>
                        <div className="text-xs text-gray-600">Latencia Promedio</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">
                          {(network.mevOpportunityRate * 100).toFixed(1)}%
                        </div>
                        <div className="text-xs text-gray-600">Tasa Oportunidades MEV</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">
                          {network.gasPriceVolatility.toFixed(1)}
                        </div>
                        <div className="text-xs text-gray-600">Volatilidad Gas Price</div>
                      </div>
                    </div>
                    
                    <div className="text-xs text-gray-600 text-right">
                      Última actualización: {new Date(network.lastUpdate).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
