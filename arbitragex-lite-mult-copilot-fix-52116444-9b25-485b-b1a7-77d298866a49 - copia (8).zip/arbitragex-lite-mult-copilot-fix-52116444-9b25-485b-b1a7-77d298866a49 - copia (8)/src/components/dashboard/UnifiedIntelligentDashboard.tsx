import React, { useState, useEffect, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  TrendUp, 
  TrendDown, 
  Activity, 
  Target, 
  Lightning, 
  ChartBar3, 
  Eye,
  Robot,
  Brain,
  Shield,
  Warning,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  Zap,
  DollarSign,
  Clock,
  AlertTriangle,
  Bell,
  Settings,
  BarChart3,
  PieChart,
  LineChart,
  Globe,
  Database,
  Cpu,
  Network,
  Wifi,
  WifiOff
} from '@phosphor-icons/react'
import { useArbitrageEngine } from '@/hooks/useArbitrageEngine'
import { useRealTimeData } from '@/hooks/useRealTimeData'
import { useOpportunities } from '@/hooks/useOpportunities'
import { apiService } from '@/services/ApiService'

interface DashboardConfig {
  layout: 'minimal' | 'standard' | 'advanced' | 'trader'
  autoRefresh: boolean
  refreshInterval: number
  showPredictions: boolean
  riskLevel: 'conservative' | 'moderate' | 'aggressive'
  preferredChains: string[]
  alertsEnabled: boolean
}

interface SystemHealth {
  backend: 'online' | 'offline' | 'degraded'
  apis: 'healthy' | 'issues' | 'down'
  latency: number
  uptime: number
  memoryUsage: number
  cpuUsage: number
}

export default function UnifiedIntelligentDashboard() {
  // Estados principales
  const [config, setConfig] = useState<DashboardConfig>({
    layout: 'standard',
    autoRefresh: true,
    refreshInterval: 5000,
    showPredictions: true,
    riskLevel: 'moderate',
    preferredChains: ['ethereum', 'bsc', 'polygon'],
    alertsEnabled: true
  })

  const [systemHealth, setSystemHealth] = useState<SystemHealth>({
    backend: 'online',
    apis: 'healthy',
    latency: 142,
    uptime: 99.9,
    memoryUsage: 65,
    cpuUsage: 23
  })

  const [isSystemActive, setIsSystemActive] = useState(false)
  const [selectedView, setSelectedView] = useState('overview')

  // Hooks para datos
  const { metrics, status, startEngine, stopEngine } = useArbitrageEngine()
  const { priceData, gasData, isConnected } = useRealTimeData()
  const { opportunities, executeOpportunity } = useOpportunities()

  // Datos computados
  const totalProfit = useMemo(() => {
    return opportunities
      .filter(opp => opp.status === 'executed')
      .reduce((sum, opp) => sum + opp.profit, 0)
  }, [opportunities])

  const avgExecutionTime = useMemo(() => {
    const executedOpps = opportunities.filter(opp => opp.status === 'executed')
    if (executedOpps.length === 0) return 0
    return executedOpps.reduce((sum, opp) => sum + opp.executionTime, 0) / executedOpps.length
  }, [opportunities])

  const successRate = useMemo(() => {
    const total = opportunities.length
    const successful = opportunities.filter(opp => opp.status === 'executed').length
    return total > 0 ? (successful / total) * 100 : 0
  }, [opportunities])

  // Control del sistema
  const handleSystemToggle = async () => {
    if (isSystemActive) {
      await stopEngine()
      setIsSystemActive(false)
    } else {
      await startEngine()
      setIsSystemActive(true)
    }
  }

  // Monitoreo de salud del sistema
  useEffect(() => {
    const checkSystemHealth = async () => {
      try {
        const health = await apiService.checkHealth()
        setSystemHealth(prev => ({
          ...prev,
          backend: health ? 'online' : 'offline',
          apis: isConnected ? 'healthy' : 'issues'
        }))
      } catch (error) {
        setSystemHealth(prev => ({
          ...prev,
          backend: 'offline',
          apis: 'down'
        }))
      }
    }

    const interval = setInterval(checkSystemHealth, 10000)
    checkSystemHealth()
    return () => clearInterval(interval)
  }, [isConnected])

  // Función para renderizar métricas principales
  const renderMainMetrics = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {/* GAP Score */}
      <div className="metric-container">
        <div className="flex items-center justify-between mb-4">
          <div className="metric-label">GAP Score</div>
          <ChartBar3 className="w-6 h-6 text-blue-500" />
        </div>
        <div className="metric-value text-blue-600">{metrics?.gapScore?.toFixed(1) || '0.0'}</div>
        <div className="metric-change-positive">
          <TrendUp className="w-4 h-4 mr-1" />
          <span>+2.3% vs ayer</span>
        </div>
      </div>

      {/* Profit Total */}
      <div className="metric-container">
        <div className="flex items-center justify-between mb-4">
          <div className="metric-label">Profit Hoy</div>
          <DollarSign className="w-6 h-6 text-green-500" />
        </div>
        <div className="metric-value profit-positive">${totalProfit.toFixed(2)}</div>
        <div className="metric-change-positive">
          <TrendUp className="w-4 h-4 mr-1" />
          <span>+{successRate.toFixed(1)}% éxito</span>
        </div>
      </div>

      {/* Latencia */}
      <div className="metric-container">
        <div className="flex items-center justify-between mb-4">
          <div className="metric-label">Latencia Avg</div>
          <Clock className="w-6 h-6 text-yellow-500" />
        </div>
        <div className="metric-value text-yellow-600">{avgExecutionTime.toFixed(0)}ms</div>
        <div className="metric-change-positive">
          <TrendDown className="w-4 h-4 mr-1" />
          <span>-8ms vs ayer</span>
        </div>
      </div>

      {/* Oportunidades Activas */}
      <div className="metric-container">
        <div className="flex items-center justify-between mb-4">
          <div className="metric-label">Oportunidades</div>
          <Target className="w-6 h-6 text-purple-500" />
        </div>
        <div className="metric-value text-purple-600">{opportunities.filter(o => o.status === 'pending').length}</div>
        <div className="text-gray-500 text-sm mt-2">{opportunities.length} total detectadas</div>
      </div>
    </div>
  )

  // Función para renderizar estado del sistema
  const renderSystemStatus = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      {/* Control Principal */}
      <div className="arbitrage-card">
        <div className="arbitrage-card-header">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold flex items-center">
              <Robot className="w-5 h-5 mr-2 text-blue-500" />
              Control del Sistema
            </h3>
            <div className="flex items-center space-x-3">
              <Switch
                checked={isSystemActive}
                onCheckedChange={handleSystemToggle}
              />
              <Button
                onClick={handleSystemToggle}
                className={isSystemActive ? 'btn-danger' : 'btn-success'}
              >
                {isSystemActive ? (
                  <>
                    <Pause className="w-4 h-4 mr-2" />
                    Detener
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Iniciar
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
        <div className="arbitrage-card-body">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Estado del Motor</span>
              <div className={`status-indicator ${isSystemActive ? 'status-success' : 'status-warning'}`}>
                {isSystemActive ? 'Activo' : 'Inactivo'}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Backend</span>
              <div className={`status-indicator ${systemHealth.backend === 'online' ? 'status-success' : 'status-error'}`}>
                {systemHealth.backend === 'online' ? 'Conectado' : 'Desconectado'}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">APIs Externas</span>
              <div className={`status-indicator ${systemHealth.apis === 'healthy' ? 'status-success' : 'status-warning'}`}>
                {systemHealth.apis === 'healthy' ? 'Saludables' : 'Con problemas'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Performance del Sistema */}
      <div className="arbitrage-card">
        <div className="arbitrage-card-header">
          <h3 className="text-xl font-semibold flex items-center">
            <Activity className="w-5 h-5 mr-2 text-green-500" />
            Performance del Sistema
          </h3>
        </div>
        <div className="arbitrage-card-body">
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">Uso de Memoria</span>
                <span className="text-sm font-medium">{systemHealth.memoryUsage}%</span>
              </div>
              <Progress value={systemHealth.memoryUsage} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">Uso de CPU</span>
                <span className="text-sm font-medium">{systemHealth.cpuUsage}%</span>
              </div>
              <Progress value={systemHealth.cpuUsage} className="h-2" />
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Uptime</span>
              <span className="font-medium text-green-600">{systemHealth.uptime}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  // Función para renderizar oportunidades
  const renderOpportunities = () => (
    <div className="arbitrage-card">
      <div className="arbitrage-card-header">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-semibold flex items-center">
            <Lightning className="w-5 h-5 mr-2 text-yellow-500" />
            Oportunidades Detectadas
          </h3>
          <Badge variant="secondary">
            {opportunities.filter(o => o.status === 'pending').length} activas
          </Badge>
        </div>
      </div>
      <div className="arbitrage-card-body">
        <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
          {opportunities.slice(0, 10).map((opportunity) => (
            <div key={opportunity.id} className={`opportunity-card p-4 ${
              opportunity.profit > 100 ? 'opportunity-high-profit' : 
              opportunity.profit > 50 ? 'opportunity-medium-profit' : 
              'opportunity-low-profit'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <Badge variant={opportunity.status === 'executed' ? 'default' : 'secondary'}>
                    {opportunity.type}
                  </Badge>
                  <span className="text-sm text-gray-600">{opportunity.pair}</span>
                </div>
                <div className="profit-positive font-semibold">
                  ${opportunity.profit.toFixed(2)}
                </div>
              </div>
              <div className="flex items-center justify-between text-sm text-gray-500">
                <span>Probabilidad: {opportunity.probability.toFixed(1)}%</span>
                <span>{opportunity.timestamp}</span>
              </div>
              {opportunity.status === 'pending' && (
                <Button
                  size="sm"
                  className="mt-2 btn-primary"
                  onClick={() => executeOpportunity(opportunity.id)}
                >
                  <Zap className="w-4 h-4 mr-1" />
                  Ejecutar
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              ArbitrageX Pro 2025
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Dashboard Inteligente Unificado
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm">
              <Settings className="w-4 h-4 mr-2" />
              Configurar
            </Button>
            <div className={`status-indicator ${isConnected ? 'status-success' : 'status-error'}`}>
              {isConnected ? (
                <>
                  <Wifi className="w-4 h-4 mr-1" />
                  Conectado
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4 mr-1" />
                  Desconectado
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Contenido Principal */}
      <div className="p-6">
        <Tabs value={selectedView} onValueChange={setSelectedView} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Vista General</TabsTrigger>
            <TabsTrigger value="trading">Trading</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="system">Sistema</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 fade-in">
            {renderMainMetrics()}
            {renderSystemStatus()}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {renderOpportunities()}
              <div className="arbitrage-card">
                <div className="arbitrage-card-header">
                  <h3 className="text-xl font-semibold flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2 text-blue-500" />
                    Resumen de Trading
                  </h3>
                </div>
                <div className="arbitrage-card-body">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{successRate.toFixed(1)}%</div>
                      <div className="text-sm text-gray-500">Tasa de Éxito</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">{opportunities.length}</div>
                      <div className="text-sm text-gray-500">Oportunidades</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">{avgExecutionTime.toFixed(0)}ms</div>
                      <div className="text-sm text-gray-500">Latencia Avg</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">${totalProfit.toFixed(2)}</div>
                      <div className="text-sm text-gray-500">Profit Total</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="trading" className="fade-in">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Vista de Trading en desarrollo. Todas las funcionalidades de arbitraje están disponibles en la vista general.
              </AlertDescription>
            </Alert>
          </TabsContent>

          <TabsContent value="analytics" className="fade-in">
            <Alert>
              <BarChart3 className="h-4 w-4" />
              <AlertDescription>
                Vista de Analytics en desarrollo. Las métricas principales están disponibles en la vista general.
              </AlertDescription>
            </Alert>
          </TabsContent>

          <TabsContent value="system" className="fade-in">
            {renderSystemStatus()}
            <div className="arbitrage-card">
              <div className="arbitrage-card-header">
                <h3 className="text-xl font-semibold">Configuración del Sistema</h3>
              </div>
              <div className="arbitrage-card-body">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="font-medium">Auto Refresh</label>
                      <Switch
                        checked={config.autoRefresh}
                        onCheckedChange={(checked) => setConfig(prev => ({ ...prev, autoRefresh: checked }))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="font-medium">Mostrar Predicciones</label>
                      <Switch
                        checked={config.showPredictions}
                        onCheckedChange={(checked) => setConfig(prev => ({ ...prev, showPredictions: checked }))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="font-medium">Alertas</label>
                      <Switch
                        checked={config.alertsEnabled}
                        onCheckedChange={(checked) => setConfig(prev => ({ ...prev, alertsEnabled: checked }))}
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className="font-medium block mb-2">Nivel de Riesgo</label>
                      <select
                        value={config.riskLevel}
                        onChange={(e) => setConfig(prev => ({ ...prev, riskLevel: e.target.value as any }))}
                        className="w-full p-2 border rounded-lg"
                      >
                        <option value="conservative">Conservador</option>
                        <option value="moderate">Moderado</option>
                        <option value="aggressive">Agresivo</option>
                      </select>
                    </div>
                    <div>
                      <label className="font-medium block mb-2">Layout</label>
                      <select
                        value={config.layout}
                        onChange={(e) => setConfig(prev => ({ ...prev, layout: e.target.value as any }))}
                        className="w-full p-2 border rounded-lg"
                      >
                        <option value="minimal">Minimal</option>
                        <option value="standard">Standard</option>
                        <option value="advanced">Avanzado</option>
                        <option value="trader">Trader Pro</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
