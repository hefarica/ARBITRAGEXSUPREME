import { useState, useEffect } from 'react'
import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { PortfolioChart } from '../charts/PortfolioChart'
import { 
  TrendUp, 
  TrendDown, 
  Activity, 
  Target,
  Lightning,
  Shield,
  Eye,
  Clock,
  ChartBar3,
  CurrencyDollar,
  WarningCircle,
  CheckCircle
} from '@phosphor-icons/react'

interface RealtimeMetric {
  label: string
  value: string
  change: number
  changeLabel: string
  status: 'positive' | 'negative' | 'neutral'
  icon: React.ReactNode
}

export function RealtimePerformanceDashboard() {
  const { state } = useSimulation()
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [isLive, setIsLive] = useState(true)

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value.toFixed(2)}%`
  }

  const formatCompactNumber = (value: number) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`
    } else if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}K`
    }
    return value.toFixed(0)
  }

  // Update timestamp periodically
  useEffect(() => {
    if (!isLive) return

    const interval = setInterval(() => {
      setLastUpdate(new Date())
    }, 1000)

    return () => clearInterval(interval)
  }, [isLive])

  // Calculate real-time metrics
  const calculateMetrics = (): RealtimeMetric[] => {
    const totalReturn = ((state.balance - 10000) / 10000) * 100
    const totalPnL = state.totalPnL
    const totalTrades = state.trades.length
    const recentTrades = state.trades.filter(t => Date.now() - t.timestamp < 3600000) // Last hour
    const winRate = state.trades.length > 0 ? 
      (state.trades.filter(t => t.profit > 0).length / state.trades.length) * 100 : 0

    // Calculate current drawdown
    let runningBalance = 10000
    let maxBalance = 10000
    let currentDrawdown = 0

    Array.from(state.trades).reverse().forEach(trade => {
      runningBalance += trade.profit - trade.fees
      if (runningBalance > maxBalance) {
        maxBalance = runningBalance
      }
      currentDrawdown = Math.max(currentDrawdown, (maxBalance - runningBalance) / maxBalance * 100)
    })

    // Calculate today's performance
    const startOfDay = new Date()
    startOfDay.setHours(0, 0, 0, 0)
    const todayTrades = state.trades.filter(t => t.timestamp >= startOfDay.getTime())
    const todayPnL = todayTrades.reduce((sum, t) => sum + t.profit - t.fees, 0)

    // Calculate volatility
    const returns = state.trades.map(t => (t.profit - t.fees) / t.amount)
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length
    const volatility = Math.sqrt(variance) * Math.sqrt(252) * 100

    return [
      {
        label: 'Portfolio Value',
        value: formatCurrency(state.balance),
        change: totalReturn,
        changeLabel: formatPercentage(totalReturn),
        status: totalReturn >= 0 ? 'positive' : 'negative',
        icon: <CurrencyDollar size={20} />
      },
      {
        label: 'Total P&L',
        value: formatCurrency(totalPnL),
        change: totalPnL,
        changeLabel: formatCurrency(totalPnL),
        status: totalPnL >= 0 ? 'positive' : 'negative',
        icon: totalPnL >= 0 ? <TrendUp size={20} /> : <TrendDown size={20} />
      },
      {
        label: 'Win Rate',
        value: formatPercentage(winRate),
        change: winRate - 50, // Deviation from 50%
        changeLabel: `${totalTrades} trades`,
        status: winRate >= 60 ? 'positive' : winRate >= 40 ? 'neutral' : 'negative',
        icon: <Target size={20} />
      },
      {
        label: 'Max Drawdown',
        value: formatPercentage(currentDrawdown),
        change: currentDrawdown,
        changeLabel: currentDrawdown > 15 ? 'High Risk' : currentDrawdown > 10 ? 'Medium Risk' : 'Low Risk',
        status: currentDrawdown > 15 ? 'negative' : currentDrawdown > 10 ? 'neutral' : 'positive',
        icon: <Shield size={20} />
      },
      {
        label: 'Today\'s P&L',
        value: formatCurrency(todayPnL),
        change: todayPnL,
        changeLabel: `${todayTrades.length} trades`,
        status: todayPnL >= 0 ? 'positive' : 'negative',
        icon: <Activity size={20} />
      },
      {
        label: 'Volatility',
        value: formatPercentage(volatility),
        change: volatility - 25, // Deviation from 25%
        changeLabel: volatility > 40 ? 'High' : volatility > 20 ? 'Normal' : 'Low',
        status: volatility > 40 ? 'negative' : volatility > 20 ? 'neutral' : 'positive',
        icon: <BarChart3 size={20} />
      }
    ]
  }

  const metrics = calculateMetrics()

  const getStatusColor = (status: 'positive' | 'negative' | 'neutral') => {
    switch (status) {
      case 'positive': return 'text-profit'
      case 'negative': return 'text-destructive'
      case 'neutral': return 'text-warning'
      default: return 'text-foreground'
    }
  }

  const getStatusBg = (status: 'positive' | 'negative' | 'neutral') => {
    switch (status) {
      case 'positive': return 'bg-profit/10'
      case 'negative': return 'bg-destructive/10'
      case 'neutral': return 'bg-warning/10'
      default: return 'bg-muted/10'
    }
  }

  // Performance health score
  const healthScore = (() => {
    let score = 50 // Base score
    
    // Portfolio return component (0-30 points)
    const returnScore = Math.min(30, Math.max(0, ((state.balance - 10000) / 10000) * 100 + 15))
    score += returnScore
    
    // Win rate component (0-25 points)
    const winRateScore = Math.min(25, Math.max(0, (metrics.find(m => m.label === 'Win Rate')?.change || 0) + 10))
    score += winRateScore
    
    // Drawdown component (-25 to 0 points)
    const currentDrawdown = parseFloat(metrics.find(m => m.label === 'Max Drawdown')?.value.replace('%', '') || '0')
    const drawdownScore = Math.max(-25, -currentDrawdown)
    score += drawdownScore
    
    return Math.min(100, Math.max(0, score))
  })()

  const getHealthStatus = (score: number) => {
    if (score >= 80) return { label: 'Excellent', color: 'text-profit', bg: 'bg-profit' }
    if (score >= 60) return { label: 'Good', color: 'text-profit', bg: 'bg-profit' }
    if (score >= 40) return { label: 'Fair', color: 'text-warning', bg: 'bg-warning' }
    if (score >= 20) return { label: 'Poor', color: 'text-destructive', bg: 'bg-destructive' }
    return { label: 'Critical', color: 'text-destructive', bg: 'bg-destructive' }
  }

  const healthStatus = getHealthStatus(healthScore)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Real-time Performance Dashboard</h2>
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-profit animate-pulse' : 'bg-muted'}`} />
              <span className="text-sm">{isLive ? 'Live' : 'Paused'}</span>
            </div>
            <span className="text-sm">•</span>
            <span className="text-sm">Last update: {lastUpdate.toLocaleTimeString()}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setIsLive(!isLive)}
            className="gap-2"
          >
            {isLive ? <Eye size={16} /> : <Clock size={16} />}
            {isLive ? 'Pause' : 'Resume'}
          </Button>
          
          <Badge className={`${healthStatus.bg} text-white`}>
            {healthStatus.label} Health
          </Badge>
        </div>
      </div>

      {/* Performance Health Score */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold">Performance Health Score</h3>
              <p className="text-muted-foreground">Overall portfolio performance assessment</p>
            </div>
            <div className="text-right">
              <p className={`text-3xl font-bold ${healthStatus.color}`}>
                {healthScore.toFixed(0)}/100
              </p>
              <p className="text-sm text-muted-foreground">{healthStatus.label}</p>
            </div>
          </div>
          
          <Progress 
            value={healthScore} 
            className={`h-3 ${healthScore >= 60 ? '[&>div]:bg-profit' : 
                              healthScore >= 40 ? '[&>div]:bg-warning' : 
                              '[&>div]:bg-destructive'}`}
          />
          
          <div className="grid grid-cols-3 gap-4 mt-4 text-sm">
            <div className="text-center">
              <p className="text-muted-foreground">Returns</p>
              <p className="font-medium">
                {formatPercentage(((state.balance - 10000) / 10000) * 100)}
              </p>
            </div>
            <div className="text-center">
              <p className="text-muted-foreground">Win Rate</p>
              <p className="font-medium">
                {formatPercentage(state.trades.length > 0 ? 
                  (state.trades.filter(t => t.profit > 0).length / state.trades.length) * 100 : 0)}
              </p>
            </div>
            <div className="text-center">
              <p className="text-muted-foreground">Risk Level</p>
              <p className="font-medium">{healthStatus.label}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Real-time Metrics GridFour */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map((metric, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                  <p className="text-xl font-bold">{metric.value}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-sm font-medium ${getStatusColor(metric.status)}`}>
                      {metric.status === 'positive' && '+'}
                      {metric.changeLabel}
                    </span>
                    {metric.status === 'positive' && <CheckCircle size={14} className="text-profit" />}
                    {metric.status === 'negative' && <WarningCircle size={14} className="text-destructive" />}
                  </div>
                </div>
                <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${getStatusBg(metric.status)}`}>
                  <div className={getStatusColor(metric.status)}>
                    {metric.icon}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Portfolio Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity size={20} />
            Portfolio Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PortfolioChart />
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button className="gap-2 h-12">
              <Lightning size={16} />
              Execute Strategy
            </Button>
            <Button variant="outline" className="gap-2 h-12">
              <Shield size={16} />
              Risk Check
            </Button>
            <Button variant="outline" className="gap-2 h-12">
              <Eye size={16} />
              Market Scan
            </Button>
            <Button variant="outline" className="gap-2 h-12">
              <BarChart3 size={16} />
              View Analytics
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}