import React, { useState, useEffect, useCallback } from 'react';
import { ApiService } from '../../services/ApiService';

// Interfaces para datos reales
interface PerformanceMetrics {
  id: string;
  name: string;
  category: 'cpu' | 'memory' | 'network' | 'disk' | 'database' | 'cache';
  value: number;
  unit: string;
  threshold: number;
  status: 'normal' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
  lastUpdate: Date;
  description: string;
}

interface Alert {
  id: string;
  type: 'info' | 'warning' | 'error' | 'critical';
  title: string;
  message: string;
  source: string;
  timestamp: Date;
  acknowledged: boolean;
  severity: number;
  category: 'system' | 'security' | 'performance' | 'business';
}

interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'debug' | 'info' | 'warn' | 'error' | 'fatal';
  source: string;
  message: string;
  metadata: Record<string, any>;
  traceId?: string;
  userId?: string;
}

interface SystemEvent {
  id: string;
  type: 'startup' | 'shutdown' | 'maintenance' | 'backup' | 'update' | 'alert';
  title: string;
  description: string;
  timestamp: Date;
  duration?: number;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  affectedServices: string[];
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export const AdvancedMonitoringHub: React.FC = () => {
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [systemEvents, setSystemEvents] = useState<SystemEvent[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'cpu' | 'memory' | 'network' | 'disk' | 'database' | 'cache'>('all');
  const [selectedLogLevel, setSelectedLogLevel] = useState<'all' | 'debug' | 'info' | 'warn' | 'error' | 'fatal'>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [apiService] = useState(() => new ApiService());

  // Cargar métricas de rendimiento reales desde el backend
  useEffect(() => {
    const loadPerformanceMetrics = async () => {
      try {
        const realPerformanceMetrics = await apiService.getPerformanceMetrics(selectedCategory);
        setPerformanceMetrics(realPerformanceMetrics);
      } catch (error) {
        console.error('Error cargando métricas de rendimiento:', error);
      }
    };
    
    loadPerformanceMetrics();
    
    // Actualizar cada 10 segundos
    const interval = setInterval(loadPerformanceMetrics, 10000);
    return () => clearInterval(interval);
  }, [selectedCategory, apiService]);

  // Cargar alertas reales desde el backend
  useEffect(() => {
    const loadAlerts = async () => {
      try {
        const realAlerts = await apiService.getSystemAlerts();
        setAlerts(realAlerts);
      } catch (error) {
        console.error('Error cargando alertas:', error);
      }
    };
    
    loadAlerts();
    
    // Actualizar cada 30 segundos
    const interval = setInterval(loadAlerts, 30000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Cargar logs reales desde el backend
  useEffect(() => {
    const loadLogs = async () => {
      try {
        const realLogs = await apiService.getSystemLogs(selectedLogLevel);
        setLogs(realLogs);
      } catch (error) {
        console.error('Error cargando logs:', error);
      }
    };
    
    loadLogs();
    
    // Actualizar cada 15 segundos
    const interval = setInterval(loadLogs, 15000);
    return () => clearInterval(interval);
  }, [selectedLogLevel, apiService]);

  // Cargar eventos del sistema reales desde el backend
  useEffect(() => {
    const loadSystemEvents = async () => {
      try {
        const realSystemEvents = await apiService.getSystemEvents();
        setSystemEvents(realSystemEvents);
      } catch (error) {
        console.error('Error cargando eventos del sistema:', error);
      }
    };
    
    loadSystemEvents();
    
    // Actualizar cada 60 segundos
    const interval = setInterval(loadSystemEvents, 60000);
    return () => clearInterval(interval);
  }, [apiService]);

  // Obtener color del estado de métrica
  const getMetricStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener color del tipo de alerta
  const getAlertTypeColor = (type: string) => {
    switch (type) {
      case 'info': return 'text-blue-400';
      case 'warning': return 'text-yellow-400';
      case 'error': return 'text-orange-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener color del nivel de log
  const getLogLevelColor = (level: string) => {
    switch (level) {
      case 'debug': return 'text-gray-400';
      case 'info': return 'text-blue-400';
      case 'warn': return 'text-yellow-400';
      case 'error': return 'text-orange-400';
      case 'fatal': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Obtener icono de la tendencia
  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return '📈';
      case 'down': return '📉';
      case 'stable': return '➡️';
      default: return '📊';
    }
  };

  // Obtener icono del tipo de evento
  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case 'startup': return '🚀';
      case 'shutdown': return '🛑';
      case 'maintenance': return '🔧';
      case 'backup': return '💾';
      case 'update': return '🔄';
      case 'alert': return '🚨';
      default: return '📝';
    }
  };

  // Obtener color del estado del evento
  const getEventStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-400';
      case 'in_progress': return 'text-blue-400';
      case 'completed': return 'text-green-400';
      case 'failed': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Calcular métricas agregadas
  const calculateAggregatedMetrics = useCallback(() => {
    const totalMetrics = performanceMetrics.length;
    const criticalMetrics = performanceMetrics.filter(m => m.status === 'critical').length;
    const warningMetrics = performanceMetrics.filter(m => m.status === 'warning').length;
    const normalMetrics = performanceMetrics.filter(m => m.status === 'normal').length;
    
    const totalAlerts = alerts.length;
    const unacknowledgedAlerts = alerts.filter(a => !a.acknowledged).length;
    const criticalAlerts = alerts.filter(a => a.type === 'critical').length;
    
    const totalLogs = logs.length;
    const errorLogs = logs.filter(l => l.level === 'error' || l.level === 'fatal').length;
    const warningLogs = logs.filter(l => l.level === 'warn').length;
    
    return {
      totalMetrics,
      criticalMetrics,
      warningMetrics,
      normalMetrics,
      totalAlerts,
      unacknowledgedAlerts,
      criticalAlerts,
      totalLogs,
      errorLogs,
      warningLogs
    };
  }, [performanceMetrics, alerts, logs]);

  const aggregatedMetrics = calculateAggregatedMetrics();

  return (
    <div className="space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard de Monitoreo Avanzado</h1>
          <p className="text-blue-300">Métricas técnicas detalladas y monitoreo del sistema</p>
        </div>
      </div>

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-black/20 rounded-lg p-4 border border-blue-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-300 text-sm">Métricas</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.totalMetrics}</p>
            </div>
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">📊</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-blue-300">
            {aggregatedMetrics.criticalMetrics} críticas
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-green-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-300 text-sm">Alertas</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.totalAlerts}</p>
            </div>
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">🚨</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-green-300">
            {aggregatedMetrics.unacknowledgedAlerts} pendientes
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-yellow-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-300 text-sm">Logs</p>
              <p className="text-2xl font-bold text-white">{aggregatedMetrics.totalLogs}</p>
            </div>
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">📝</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-yellow-300">
            {aggregatedMetrics.errorLogs} errores
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-purple-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-300 text-sm">Eventos</p>
              <p className="text-2xl font-bold text-white">{systemEvents.length}</p>
            </div>
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">⚡</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-purple-300">
            Sistema activo
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 border border-indigo-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-indigo-300 text-sm">Estado</p>
              <p className="text-2xl font-bold text-white">
                {aggregatedMetrics.criticalMetrics > 0 ? '⚠️' : '✅'}
              </p>
            </div>
            <div className="w-10 h-10 bg-indigo-500/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">🔬</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-indigo-300">
            {aggregatedMetrics.criticalMetrics > 0 ? 'Crítico' : 'Normal'}
          </div>
        </div>
      </div>

      {/* Métricas de Rendimiento */}
      <div className="bg-black/20 rounded-lg border border-blue-500/30">
        <div className="p-6 border-b border-blue-500/30">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-white">Métricas de Rendimiento</h2>
              <p className="text-blue-300">Monitoreo en tiempo real de recursos del sistema</p>
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as any)}
              className="px-4 py-2 bg-black/30 border border-blue-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            >
              <option value="all">Todas las Categorías</option>
              <option value="cpu">CPU</option>
              <option value="memory">Memoria</option>
              <option value="network">Red</option>
              <option value="disk">Disco</option>
              <option value="database">Base de Datos</option>
              <option value="cache">Cache</option>
            </select>
          </div>
        </div>
        
        <div className="p-6">
          {performanceMetrics.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📊</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Métricas</h3>
              <p className="text-blue-300">No hay métricas de rendimiento disponibles</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {performanceMetrics.map((metric) => (
                <div key={metric.id} className="bg-black/30 rounded-lg p-4 border border-blue-500/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <span className="text-lg">📊</span>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-medium ${
                      metric.status === 'normal' ? 'bg-green-500/20 text-green-400' :
                      metric.status === 'warning' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-red-500/20 text-red-400'
                    }`}>
                      {metric.status.toUpperCase()}
                    </div>
                  </div>
                  
                  <h3 className="font-semibold text-white mb-2">{metric.name}</h3>
                  <p className="text-sm text-blue-300 mb-3">{metric.description}</p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-blue-300">Valor:</span>
                      <span className={`text-white font-medium ${getMetricStatusColor(metric.status)}`}>
                        {metric.value} {metric.unit}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-300">Umbral:</span>
                      <span className="text-white">{metric.threshold} {metric.unit}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-300">Tendencia:</span>
                      <span className="text-white flex items-center">
                        {getTrendIcon(metric.trend)} {metric.trend}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-3 text-xs text-blue-300">
                    Actualizado: {metric.lastUpdate.toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Alertas del Sistema */}
      <div className="bg-black/20 rounded-lg border border-red-500/30">
        <div className="p-6 border-b border-red-500/30">
          <h2 className="text-xl font-semibold text-white">Alertas del Sistema</h2>
          <p className="text-red-300">Notificaciones y alertas en tiempo real</p>
        </div>
        
        <div className="p-6">
          {alerts.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">✅</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Alertas</h3>
              <p className="text-red-300">El sistema está funcionando normalmente</p>
            </div>
          ) : (
            <div className="space-y-4">
              {alerts.map((alert) => (
                <div key={alert.id} className={`bg-black/30 rounded-lg p-4 border ${
                  alert.type === 'critical' ? 'border-red-500/50 bg-red-500/10' :
                  alert.type === 'error' ? 'border-orange-500/50 bg-orange-500/10' :
                  alert.type === 'warning' ? 'border-yellow-500/50 bg-yellow-500/10' :
                  'border-blue-500/50 bg-blue-500/10'
                }`}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        alert.type === 'critical' ? 'bg-red-500/20' :
                        alert.type === 'error' ? 'bg-orange-500/20' :
                        alert.type === 'warning' ? 'bg-yellow-500/20' :
                        'bg-blue-500/20'
                      }`}>
                        <span className="text-lg">🚨</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{alert.title}</h3>
                        <p className="text-sm text-gray-300">{alert.source}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        alert.type === 'critical' ? 'bg-red-500/20 text-red-400' :
                        alert.type === 'error' ? 'bg-orange-500/20 text-orange-400' :
                        alert.type === 'warning' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-blue-500/20 text-blue-400'
                      }`}>
                        {alert.type.toUpperCase()}
                      </div>
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        alert.category === 'system' ? 'bg-purple-500/20 text-purple-400' :
                        alert.category === 'security' ? 'bg-red-500/20 text-red-400' :
                        alert.category === 'performance' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {alert.category.toUpperCase()}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-white mb-3">{alert.message}</p>
                  
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-4">
                      <span className="text-gray-300">
                        Severidad: {alert.severity}/10
                      </span>
                      <span className="text-gray-300">
                        {alert.acknowledged ? '✅ Reconocida' : '⏳ Pendiente'}
                      </span>
                    </div>
                    <span className="text-gray-300">
                      {alert.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Logs del Sistema */}
      <div className="bg-black/20 rounded-lg border border-yellow-500/30">
        <div className="p-6 border-b border-yellow-500/30">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-white">Logs del Sistema</h2>
              <p className="text-yellow-300">Registro de eventos y actividades del sistema</p>
            </div>
            <select
              value={selectedLogLevel}
              onChange={(e) => setSelectedLogLevel(e.target.value as any)}
              className="px-4 py-2 bg-black/30 border border-yellow-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500/50"
            >
              <option value="all">Todos los Niveles</option>
              <option value="debug">Debug</option>
              <option value="info">Info</option>
              <option value="warn">Warning</option>
              <option value="error">Error</option>
              <option value="fatal">Fatal</option>
            </select>
          </div>
        </div>
        
        <div className="p-6">
          {logs.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Logs</h3>
              <p className="text-yellow-300">No hay logs disponibles para el nivel seleccionado</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {logs.map((log) => (
                <div key={log.id} className="bg-black/30 rounded-lg p-3 border border-yellow-500/20">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        log.level === 'fatal' ? 'bg-red-500/20 text-red-400' :
                        log.level === 'error' ? 'bg-orange-500/20 text-orange-400' :
                        log.level === 'warn' ? 'bg-yellow-500/20 text-yellow-400' :
                        log.level === 'info' ? 'bg-blue-500/20 text-blue-400' :
                        'bg-gray-500/20 text-gray-400'
                      }`}>
                        {log.level.toUpperCase()}
                      </div>
                      <span className="text-sm text-white font-medium">{log.source}</span>
                    </div>
                    <span className="text-xs text-gray-300">
                      {log.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                  
                  <p className={`text-sm ${getLogLevelColor(log.level)}`}>
                    {log.message}
                  </p>
                  
                  {log.traceId && (
                    <div className="mt-2 text-xs text-gray-400">
                      Trace ID: {log.traceId}
                    </div>
                  )}
                  
                  {log.userId && (
                    <div className="mt-1 text-xs text-gray-400">
                      User ID: {log.userId}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Eventos del Sistema */}
      <div className="bg-black/20 rounded-lg border border-purple-500/30">
        <div className="p-6 border-b border-purple-500/30">
          <h2 className="text-xl font-semibold text-white">Eventos del Sistema</h2>
          <p className="text-purple-300">Historial de eventos y cambios del sistema</p>
        </div>
        
        <div className="p-6">
          {systemEvents.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">⚡</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Eventos</h3>
              <p className="text-purple-300">No hay eventos del sistema registrados</p>
            </div>
          ) : (
            <div className="space-y-4">
              {systemEvents.map((event) => (
                <div key={event.id} className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                        <span className="text-lg">{getEventTypeIcon(event.type)}</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{event.title}</h3>
                        <p className="text-sm text-purple-300">{event.type.toUpperCase()}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        event.priority === 'critical' ? 'bg-red-500/20 text-red-400' :
                        event.priority === 'high' ? 'bg-orange-500/20 text-orange-400' :
                        event.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {event.priority.toUpperCase()}
                      </div>
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        event.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                        event.status === 'in_progress' ? 'bg-blue-500/20 text-blue-400' :
                        event.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        {event.status.replace('_', ' ').toUpperCase()}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-white mb-3">{event.description}</p>
                  
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-4">
                      <span className="text-gray-300">
                        {event.timestamp.toLocaleTimeString()}
                      </span>
                      {event.duration && (
                        <span className="text-gray-300">
                          Duración: {event.duration}s
                        </span>
                      )}
                    </div>
                    <div className="text-gray-300">
                      Servicios: {event.affectedServices.join(', ')}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
