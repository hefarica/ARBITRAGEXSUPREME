import React, { useState, useEffect, useCallback } from 'react';
import { RealTimeDataIngestion } from '../../core/RealTimeDataIngestion';
import { ArbitrageDetectionEngine } from '../../core/ArbitrageDetectionEngine';
import { ApiService } from '../../services/ApiService';

// Interfaces para datos reales
interface SystemMetrics {
  totalOpportunities: number;
  activeStrategies: number;
  totalProfit: number;
  systemEfficiency: number;
  riskScore: number;
  operationsPerHour: number;
  uptime: number;
  errorRate: number;
  successRate: number;
  reconnectionAttempts: number;
}

interface Opportunity {
  id: string;
  token0: string;
  token1: string;
  chainId: number;
  dex0: string;
  dex1: string;
  profit: number;
  volume: number;
  probability: number;
  risk: 'low' | 'medium' | 'high';
  timestamp: Date;
}

interface PoolState {
  id: string;
  token0: string;
  token1: string;
  chainId: number;
  dex: string;
  reserve0: string;
  reserve1: string;
  tvl: number;
  volume24h: number;
  fee: number;
  lastUpdate: Date;
}

interface MonitoringHubProps {
  systemMetrics: SystemMetrics;
  dataIngestion: RealTimeDataIngestion;
  arbitrageEngine: ArbitrageDetectionEngine;
}

export const MonitoringHub: React.FC<MonitoringHubProps> = ({ 
  systemMetrics, 
  dataIngestion, 
  arbitrageEngine 
}) => {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [poolStates, setPoolStates] = useState<PoolState[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [lastScanTime, setLastScanTime] = useState<Date | null>(null);
  const [apiService] = useState(() => new ApiService());

  // Escanear oportunidades en tiempo real
  const scanOpportunities = useCallback(async () => {
    setIsScanning(true);
    setScanProgress(0);
    
    try {
      // Obtener oportunidades reales desde el backend
      const realOpportunities = await apiService.getArbitrageOpportunities();
      setOpportunities(realOpportunities);
      
      // Simular progreso de escaneo (en producción sería real)
      for (let i = 0; i <= 100; i += 10) {
        setScanProgress(i);
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      setLastScanTime(new Date());
    } catch (error) {
      console.error('Error escaneando oportunidades:', error);
    } finally {
      setIsScanning(false);
      setScanProgress(100);
    }
  }, [apiService]);

  // Actualizar estados de pools en tiempo real
  const updatePoolStates = useCallback(async () => {
    try {
      // Obtener estados reales de pools desde el backend
      const realPoolStates = await apiService.getPoolStates();
      setPoolStates(realPoolStates);
    } catch (error) {
      console.error('Error actualizando estados de pools:', error);
    }
  }, [apiService]);

  // Escuchar actualizaciones de pools en tiempo real
  useEffect(() => {
    const handlePoolStateUpdate = (poolState: PoolState) => {
      setPoolStates(prev => {
        const existing = prev.find(p => p.id === poolState.id);
        if (existing) {
          return prev.map(p => p.id === poolState.id ? poolState : p);
        } else {
          return [...prev, poolState];
        }
      });
    };

    dataIngestion.onPoolStateUpdate(handlePoolStateUpdate);
    return () => dataIngestion.removePoolStateUpdateListener(handlePoolStateUpdate);
  }, [dataIngestion]);

  // Actualizar datos cada 30 segundos
  useEffect(() => {
    updatePoolStates();
    const interval = setInterval(updatePoolStates, 30000);
    return () => clearInterval(interval);
  }, [updatePoolStates]);

  // Escanear oportunidades cada 2 minutos
  useEffect(() => {
    scanOpportunities();
    const interval = setInterval(scanOpportunities, 120000);
    return () => clearInterval(interval);
  }, [scanOpportunities]);

  // Calcular TVL usando precios reales del backend
  const calculateTVL = useCallback(async (reserve0: string, reserve1: string, token0: string, token1: string): Promise<number> => {
    try {
      // Obtener precios reales desde el backend
      const prices = await apiService.getTokenPrices([token0, token1]);
      const token0Price = prices[token0] || 0;
      const token1Price = prices[token1] || 0;
      
      const reserve0Value = parseFloat(reserve0) * token0Price;
      const reserve1Value = parseFloat(reserve1) * token1Price;
      
      return reserve0Value + reserve1Value;
    } catch (error) {
      console.error('Error calculando TVL:', error);
      return 0;
    }
  }, [apiService]);

  return (
    <div className="space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard de Monitoreo</h1>
          <p className="text-blue-300">Seguimiento en tiempo real del sistema de arbitraje</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <button
            onClick={scanOpportunities}
            disabled={isScanning}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg font-medium transition-colors"
          >
            {isScanning ? '🔍 Escaneando...' : '🔍 Escanear Oportunidades'}
          </button>
          
          {lastScanTime && (
            <div className="text-sm text-blue-300">
              Último escaneo: {lastScanTime.toLocaleTimeString()}
            </div>
          )}
        </div>
      </div>

      {/* Progreso de Escaneo */}
      {isScanning && (
        <div className="bg-black/20 rounded-lg p-4 border border-blue-500/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-blue-300">Escaneando oportunidades...</span>
            <span className="text-white font-medium">{scanProgress}%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${scanProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-black/20 rounded-lg p-6 border border-blue-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-300 text-sm">Oportunidades Detectadas</p>
              <p className="text-2xl font-bold text-white">{opportunities.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <span className="text-2xl">🎯</span>
            </div>
          </div>
          <div className="mt-4 text-sm text-blue-300">
            {opportunities.length > 0 ? 
              `+${opportunities.filter(o => o.probability > 80).length} de alta probabilidad` : 
              'Sin oportunidades activas'
            }
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-6 border border-green-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-300 text-sm">Pools Activos</p>
              <p className="text-2xl font-bold text-white">{poolStates.length}</p>
            </div>
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <span className="text-2xl">💧</span>
            </div>
          </div>
          <div className="mt-4 text-sm text-green-300">
            {poolStates.length > 0 ? 
              `+${poolStates.filter(p => p.tvl > 1000000).length} de alto TVL` : 
              'Sin pools activos'
            }
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-6 border border-yellow-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-300 text-sm">Estrategias Activas</p>
              <p className="text-2xl font-bold text-white">{systemMetrics.activeStrategies}</p>
            </div>
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <span className="text-2xl">⚡</span>
            </div>
          </div>
          <div className="mt-4 text-sm text-yellow-300">
            {systemMetrics.activeStrategies > 0 ? 
              `+${systemMetrics.activeStrategies} ejecutándose` : 
              'Sin estrategias activas'
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-6 border border-purple-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-300 text-sm">Ganancia Total</p>
              <p className="text-2xl font-bold text-white">${systemMetrics.totalProfit.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <span className="text-2xl">💰</span>
            </div>
          </div>
          <div className="mt-4 text-sm text-purple-300">
            {systemMetrics.totalProfit > 0 ? 
              `+${((systemMetrics.totalProfit / 1000) * 100).toFixed(1)}% vs meta` : 
              'Sin ganancias registradas'
            }
          </div>
        </div>
      </div>

      {/* Oportunidades Detectadas */}
      <div className="bg-black/20 rounded-lg border border-blue-500/30">
        <div className="p-6 border-b border-blue-500/30">
          <h2 className="text-xl font-semibold text-white">Oportunidades de Arbitraje</h2>
          <p className="text-blue-300">Oportunidades detectadas en tiempo real</p>
        </div>
        
        <div className="p-6">
          {opportunities.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Oportunidades</h3>
              <p className="text-blue-300">No se han detectado oportunidades de arbitraje en este momento</p>
              <button
                onClick={scanOpportunities}
                className="mt-4 px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors"
              >
                Escanear Ahora
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {opportunities.slice(0, 10).map((opportunity) => (
                <div key={opportunity.id} className="bg-black/30 rounded-lg p-4 border border-blue-500/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                        <span className="text-xl">💱</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">
                          {opportunity.token0}/{opportunity.token1}
                        </h4>
                        <p className="text-sm text-blue-300">
                          Chain {opportunity.chainId} • {opportunity.dex0} → {opportunity.dex1}
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-lg font-bold text-green-400">
                        ${opportunity.profit.toFixed(4)}
                      </div>
                      <div className="text-sm text-blue-300">
                        Vol: ${opportunity.volume.toLocaleString()}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-blue-300">Probabilidad:</span>
                        <span className={`text-sm font-medium ${
                          opportunity.probability > 80 ? 'text-green-400' :
                          opportunity.probability > 60 ? 'text-yellow-400' : 'text-red-400'
                        }`}>
                          {opportunity.probability}%
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-blue-300">Riesgo:</span>
                        <span className={`text-sm font-medium ${
                          opportunity.risk === 'low' ? 'text-green-400' :
                          opportunity.risk === 'medium' ? 'text-yellow-400' : 'text-red-400'
                        }`}>
                          {opportunity.risk.toUpperCase()}
                        </span>
                      </div>
                    </div>
                    
                    <div className="text-xs text-blue-300">
                      {opportunity.timestamp.toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))}
              
              {opportunities.length > 10 && (
                <div className="text-center py-4">
                  <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors">
                    Ver Todas ({opportunities.length})
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Estados de Pools */}
      <div className="bg-black/20 rounded-lg border border-green-500/30">
        <div className="p-6 border-b border-green-500/30">
          <h2 className="text-xl font-semibold text-white">Estados de Pools</h2>
          <p className="text-green-300">Monitoreo en tiempo real de pools de liquidez</p>
        </div>
        
        <div className="p-6">
          {poolStates.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">💧</div>
              <h3 className="text-xl font-semibold text-white mb-2">Sin Pools Activos</h3>
              <p className="text-green-300">No hay pools de liquidez siendo monitoreados</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {poolStates.slice(0, 12).map((pool) => (
                <div key={pool.id} className="bg-black/30 rounded-lg p-4 border border-green-500/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <span className="text-lg">💧</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-green-300">{pool.dex}</div>
                      <div className="text-xs text-blue-300">Chain {pool.chainId}</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <div className="text-xs text-green-300">Par</div>
                      <div className="text-sm font-medium text-white">
                        {pool.token0}/{pool.token1}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-300">TVL</div>
                      <div className="text-sm font-medium text-white">
                        ${pool.tvl.toLocaleString()}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-300">Volumen 24h</div>
                      <div className="text-sm font-medium text-white">
                        ${pool.volume24h.toLocaleString()}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-300">Fee</div>
                      <div className="text-sm font-medium text-white">
                        {pool.fee}%
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-3 text-xs text-blue-300">
                    Actualizado: {pool.lastUpdate.toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
