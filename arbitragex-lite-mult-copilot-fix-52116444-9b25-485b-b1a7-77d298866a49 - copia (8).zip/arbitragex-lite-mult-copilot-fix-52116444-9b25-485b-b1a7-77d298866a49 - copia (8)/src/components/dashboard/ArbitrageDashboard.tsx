import React, { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Activity,
  TrendUp,
  TrendDown,
  Lightning,
  Target,
  Shield,
  WifiHigh,
  WarningCircle,
  CheckCircle,
  Clock,
  CurrencyDollar,
  ChartLine,
  // 🆕 NUEVOS ICONOS PARA SERVICIOS AVANZADOS
  Robot,
  Rocket,
  Globe,
  Gauge,
  Zap,
  Lock,
  Bank,
  ArrowsLeftRight
} from '@phosphor-icons/react'
import { ArbitrageEngine } from '@/core/ArbitrageEngine'
import { RealTimePriceMonitor } from '@/core/RealTimePriceMonitor'
import { FlashLoanExecutor } from '@/core/FlashLoanExecutor'
import { MultiDEXConnector } from '@/core/MultiDEXConnector'
import { MEVProtectionService2025 } from '@/core/MEVProtectionService2025'
import { FlashLoanService2025 } from '@/core/FlashLoanService2025'
import { CrossChainArbitrageService2025 } from '@/core/CrossChainArbitrageService2025'
import { PerformanceMonitoringService2025 } from '@/core/PerformanceMonitoringService2025'
import { ArbitrageOpportunity, PriceQuote, SUPPORTED_DEXES, SUPPORTED_CHAINS, RiskParameters } from '@/core/types'
import { apiService } from '@/services/ApiService'

interface ArbitrageDashboardProps {
  environment: 'test' | 'prod'
}

interface DashboardStats {
  totalOpportunities: number
  totalProfit: number
  successRate: number
  activeMonitoring: boolean
  averageROI: number
  executedTrades: number
  gasUsed: number
  networksConnected: number
  // 🆕 NUEVAS ESTADÍSTICAS AVANZADAS
  mevProtectionLevel: string
  flashLoanSuccessRate: number
  crossChainOpportunities: number
  performanceScore: number
}

export default function ArbitrageDashboard({ environment }: ArbitrageDashboardProps) {
  // State management
  const [arbitrageEngine, setArbitrageEngine] = useState<ArbitrageEngine | null>(null)
  const [priceMonitor, setPriceMonitor] = useState<RealTimePriceMonitor | null>(null)
  const [flashLoanExecutor, setFlashLoanExecutor] = useState<FlashLoanExecutor | null>(null)
  const [dexConnector, setDexConnector] = useState<MultiDEXConnector | null>(null)
  
  // 🆕 NUEVOS SERVICIOS AVANZADOS
  const [mevProtectionService, setMevProtectionService] = useState<MEVProtectionService2025 | null>(null)
  const [flashLoanService2025, setFlashLoanService2025] = useState<FlashLoanService2025 | null>(null)
  const [crossChainArbitrageService, setCrossChainArbitrageService] = useState<CrossChainArbitrageService2025 | null>(null)
  const [performanceMonitoringService, setPerformanceMonitoringService] = useState<PerformanceMonitoringService2025 | null>(null)
  
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([])
  const [currentPrices, setCurrentPrices] = useState<PriceQuote[]>([])
  const [dashboardStats, setDashboardStats] = useState<DashboardStats>({
    totalOpportunities: 0,
    totalProfit: 0,
    successRate: 0,
    activeMonitoring: false,
    averageROI: 0,
    executedTrades: 0,
    gasUsed: 0,
    networksConnected: 0,
    // 🆕 NUEVAS ESTADÍSTICAS AVANZADAS
    mevProtectionLevel: 'Basic',
    flashLoanSuccessRate: 0,
    crossChainOpportunities: 0,
    performanceScore: 0
  })
  
  const [selectedOpportunity, setSelectedOpportunity] = useState<ArbitrageOpportunity | null>(null)
  const [isExecuting, setIsExecuting] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())
  const [connectionStatus, setConnectionStatus] = useState<Record<string, boolean>>({})

  // Risk parameters
  const [riskParams, setRiskParams] = useState<RiskParameters>({
    maxSlippage: 2.0,
    maxGasPrice: 100,
    maxPositionSize: '10000',
    minProfitThreshold: environment === 'prod' ? 4.0 : 1.0, // 4% for prod, 1% for test
    maxPriceImpact: 5.0,
    maxExecutionTime: 120,
    enableFlashLoans: true,
    maxFlashLoanAmount: '100000'
  })

  // Initialize core systems
  useEffect(() => {
    const initializeSystems = async () => {
      try {
        // RPC URLs (in production, these would come from environment variables)
        const rpcUrls = {
          1: process.env.VITE_ETHEREUM_RPC_URL || 'https://eth-mainnet.g.alchemy.com/v2/demo',
          56: process.env.VITE_BSC_RPC_URL || 'https://bsc-dataseed.binance.org',
          137: process.env.VITE_POLYGON_RPC_URL || 'https://polygon-rpc.com',
          42161: process.env.VITE_ARBITRUM_RPC_URL || 'https://arb1.arbitrum.io/rpc',
          10: process.env.VITE_OPTIMISM_RPC_URL || 'https://mainnet.optimism.io'
        }

        // Initialize arbitrage engine
        const engine = new ArbitrageEngine(riskParams)
        setArbitrageEngine(engine)

        // Initialize price monitor
        const monitor = new RealTimePriceMonitor(rpcUrls)
        setPriceMonitor(monitor)

        // Initialize flash loan executor
        const flashLoan = new FlashLoanExecutor(rpcUrls)
        setFlashLoanExecutor(flashLoan)

        // Initialize DEX connector
        const dex = new MultiDEXConnector(rpcUrls)
        setDexConnector(dex)

        // 🆕 INICIALIZAR NUEVOS SERVICIOS AVANZADOS
        const mevService = new MEVProtectionService2025(rpcUrls, environment)
        setMevProtectionService(mevService)

        const flashLoanService = new FlashLoanService2025(rpcUrls, environment)
        setFlashLoanService2025(flashLoanService)

        const crossChainService = new CrossChainArbitrageService2025(rpcUrls, environment)
        setCrossChainArbitrageService(crossChainService)

        const performanceService = new PerformanceMonitoringService2025(environment)
        setPerformanceMonitoringService(performanceService)

        // Initialize all services
        await Promise.all([
          mevService.initialize(),
          flashLoanService.initialize(),
          crossChainService.initialize(),
          performanceService.initialize()
        ])

        console.log('🚀 Todos los servicios avanzados inicializados exitosamente')

      } catch (error) {
        console.error('Error initializing systems:', error)
      }
    }

    initializeSystems()
  }, [environment, riskParams])

  // 🆕 ACTUALIZAR ESTADÍSTICAS AVANZADAS DESDE EL BACKEND
  useEffect(() => {
    const updateAdvancedStats = async () => {
      try {
        // Obtener datos reales del backend
        const mevStats = await apiService.getMEVProtectionStats()
        const flashLoanStats = await apiService.getFlashLoanStats()
        const crossChainStats = await apiService.getCrossChainStats()
        const performanceStats = await apiService.getPerformanceStats()

        setDashboardStats(prev => ({
          ...prev,
          mevProtectionLevel: mevStats.currentProtectionLevel || 'Basic',
          flashLoanSuccessRate: flashLoanStats.successRate || 0,
          crossChainOpportunities: crossChainStats.totalOpportunities || 0,
          performanceScore: performanceStats.overallScore || 0
        }))
      } catch (error) {
        console.error('Error updating advanced stats from backend:', error)
      }
    }

    const interval = setInterval(updateAdvancedStats, 5000)
    updateAdvancedStats() // Initial update
    return () => clearInterval(interval)
  }, [])

  // Subscribe to price updates
  useEffect(() => {
    if (!priceMonitor) return

    const unsubscribe = priceMonitor.subscribe((update) => {
      if (update.type === 'price_update') {
        setCurrentPrices(prev => {
          const filtered = prev.filter(p => 
            !(p.chainId === update.chainId && 
              p.tokenIn === (update.data as any).tokenAddress)
          )
          return [...filtered, update.data as any]
        })
      }
      
      setLastUpdate(new Date())
    })

    return unsubscribe
  }, [priceMonitor])

  // 🆕 ACTUALIZAR OPORTUNIDADES DESDE EL BACKEND
  useEffect(() => {
    const updateOpportunities = async () => {
      try {
        // Obtener oportunidades reales del backend
        const newOpportunities = await apiService.getArbitrageOpportunities()
        setOpportunities(newOpportunities)
        
        // Update stats
        const totalProfit = newOpportunities.reduce((sum, opp) => 
          sum + parseFloat(opp.netProfit), 0
        )
        const averageROI = newOpportunities.length > 0 
          ? newOpportunities.reduce((sum, opp) => sum + opp.netProfitPercentage, 0) / newOpportunities.length
          : 0

        setDashboardStats(prev => ({
          ...prev,
          totalOpportunities: newOpportunities.length,
          totalProfit,
          averageROI,
          activeMonitoring: true,
          networksConnected: Object.keys(SUPPORTED_CHAINS).length
        }))
      } catch (error) {
        console.error('Error updating opportunities from backend:', error)
      }
    }

    const interval = setInterval(updateOpportunities, 2000)
    updateOpportunities() // Initial update

    return () => clearInterval(interval)
  }, [])

  // Update connection status
  useEffect(() => {
    if (!priceMonitor) return

    const updateStatus = () => {
      const status = priceMonitor.getConnectionStatus()
      setConnectionStatus(status)
    }

    const interval = setInterval(updateStatus, 5000)
    updateStatus() // Initial update

    return () => clearInterval(interval)
  }, [priceMonitor])

  // 🆕 EJECUTAR ARBITRAJE DESDE EL BACKEND
  const executeOpportunity = useCallback(async (opportunity: ArbitrageOpportunity) => {
    if (isExecuting) return

    setIsExecuting(true)
    try {
      // Ejecutar arbitraje a través del backend
      const result = await apiService.executeArbitrage(opportunity.id)
      
      if (result.success) {
        setDashboardStats(prev => ({
          ...prev,
          executedTrades: prev.executedTrades + 1,
          successRate: ((prev.executedTrades * prev.successRate + 100) / (prev.executedTrades + 1)),
          gasUsed: prev.gasUsed + (result.data?.gasUsed || 0)
        }))
        
        console.log('Arbitraje ejecutado exitosamente desde backend:', result)
      } else {
        console.error('Arbitraje falló en backend:', result.error)
      }
    } catch (error) {
      console.error('Error ejecutando arbitraje desde backend:', error)
    } finally {
      setIsExecuting(false)
    }
  }, [isExecuting])

  // Update risk parameters
  const updateRiskParameters = useCallback((newParams: Partial<RiskParameters>) => {
    const updatedParams = { ...riskParams, ...newParams }
    setRiskParams(updatedParams)
    arbitrageEngine?.updateRiskParameters(updatedParams)
  }, [arbitrageEngine, riskParams])

  // Format currency
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount)
  }

  // Format percentage
  const formatPercentage = (percentage: number): string => {
    return `${percentage >= 0 ? '+' : ''}${percentage.toFixed(2)}%`
  }

  // Get status icon
  const getStatusIcon = (status: boolean) => {
    return status ? (
      <CheckCircle size={16} className="text-green-500" />
    ) : (
      <WarningCircle size={16} className="text-red-500" />
    )
  }

  // Get opportunity priority color
  const getOpportunityColor = (roi: number) => {
    if (roi >= 10) return 'text-green-600 bg-green-50 border-green-200'
    if (roi >= 5) return 'text-blue-600 bg-blue-50 border-blue-200'
    if (roi >= 2) return 'text-yellow-600 bg-yellow-50 border-yellow-200'
    return 'text-gray-600 bg-gray-50 border-gray-200'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">ArbitrageX Pro 2025</h1>
          <p className="text-muted-foreground">
            Advanced Multi-DEX Arbitrage Platform • {environment.toUpperCase()} Environment
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1">
            <Activity size={12} />
            {dashboardStats.activeMonitoring ? 'Active' : 'Inactive'}
          </Badge>
          <Badge variant="outline" className="gap-1">
            <Clock size={12} />
            Updated {lastUpdate.toLocaleTimeString()}
          </Badge>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Opportunities</CardTitle>
            <Target size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardStats.totalOpportunities}</div>
            <p className="text-xs text-muted-foreground">
              Live arbitrage opportunities
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Profit</CardTitle>
            <CurrencyDollar size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(dashboardStats.totalProfit)}</div>
            <p className="text-xs text-muted-foreground">
              Potential profit today
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average ROI</CardTitle>
            <TrendUp size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatPercentage(dashboardStats.averageROI)}</div>
            <p className="text-xs text-muted-foreground">
              Return on investment
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <Shield size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardStats.successRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              Successful executions
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Advanced Services Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="mev-protection">MEV Protection</TabsTrigger>
          <TabsTrigger value="flash-loans">Flash Loans</TabsTrigger>
          <TabsTrigger value="cross-chain">Cross-Chain</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Connection Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <WifiHigh size={20} />
                System Connectivity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(connectionStatus).map(([network, status]) => (
                  <div key={network} className="flex items-center gap-2">
                    {getStatusIcon(status)}
                    <span className="text-sm font-medium">{network}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Opportunities List */}
          <Card>
            <CardHeader>
              <CardTitle>Live Opportunities</CardTitle>
              <CardDescription>
                Real-time arbitrage opportunities from backend
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-2">
                  {opportunities.map((opportunity) => (
                    <div
                      key={opportunity.id}
                      className={`p-4 rounded-lg border ${getOpportunityColor(opportunity.netProfitPercentage)}`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">Path: {opportunity.path.join(' → ')}</h4>
                          <p className="text-sm text-muted-foreground">
                            Profit: {formatCurrency(parseFloat(opportunity.netProfit))} ({formatPercentage(opportunity.netProfitPercentage)})
                          </p>
                        </div>
                        <Button
                          onClick={() => executeOpportunity(opportunity)}
                          disabled={isExecuting}
                          size="sm"
                        >
                          {isExecuting ? 'Executing...' : 'Execute'}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mev-protection" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Robot size={20} />
                MEV Protection Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Protection Level:</span>
                  <Badge variant="outline">{dashboardStats.mevProtectionLevel}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Status:</span>
                  <Badge variant="outline" className="text-green-600">
                    Active
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flash-loans" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bank size={20} />
                Flash Loan Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Success Rate:</span>
                  <span className="font-medium">{dashboardStats.flashLoanSuccessRate.toFixed(1)}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Status:</span>
                  <Badge variant="outline" className="text-green-600">
                    Enabled
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cross-chain" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe size={20} />
                Cross-Chain Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Opportunities:</span>
                  <span className="font-medium">{dashboardStats.crossChainOpportunities}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Status:</span>
                  <Badge variant="outline" className="text-green-600">
                    Active
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gauge size={20} />
                Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Overall Score:</span>
                  <span className="font-medium">{dashboardStats.performanceScore.toFixed(1)}/100</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Status:</span>
                  <Badge variant="outline" className="text-green-600">
                    Monitoring
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}