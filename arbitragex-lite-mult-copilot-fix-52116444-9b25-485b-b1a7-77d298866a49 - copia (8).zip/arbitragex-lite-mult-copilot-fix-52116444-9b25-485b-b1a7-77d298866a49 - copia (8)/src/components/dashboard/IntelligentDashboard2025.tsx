import React, { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  TrendUp, 
  TrendDown, 
  Activity, 
  Target, 
  Lightning, 
  ChartBar3, 
  Eye,
  Robot,
  Brain,
  Shield,
  Warning,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  Zap,
  DollarSign,
  Clock,
  AlertTriangle,
  Bell,
  Settings,
  BarChart3,
  PieChart,
  LineChart,
  Globe,
  Smartphone,
  Monitor,
  Database,
  Cpu,
  Network,
  Wifi,
  WifiOff
} from '@phosphor-icons/react'
import { useSimulation } from '../simulation/SimulationProvider'
import { cn } from '@/lib/utils'

interface AIInsight {
  id: string
  type: 'opportunity' | 'warning' | 'success' | 'info'
  title: string
  description: string
  priority: 'low' | 'medium' | 'high' | 'critical'
  timestamp: Date
  actionable: boolean
  action?: string
}

interface SystemStatus {
  overall: 'optimal' | 'warning' | 'critical' | 'offline'
  arbitrageEngine: 'running' | 'paused' | 'error'
  marketData: 'connected' | 'disconnected' | 'lagging'
  riskManagement: 'active' | 'bypass' | 'error'
  notifications: 'enabled' | 'disabled'
  autoMode: 'enabled' | 'disabled'
}

interface Opportunity {
  id: string
  type: string
  pair: string
  profit: number
  probability: number
  risk: 'low' | 'medium' | 'high'
  aiConfidence: number
  timeWindow: number // seconds
  exchanges: string[]
  estimatedFees: number
  marketConditions: 'favorable' | 'neutral' | 'unfavorable'
}

export function IntelligentDashboard2025() {
  const { state, executeTrade } = useSimulation()
  const [systemStatus, setSystemStatus] = useState<SystemStatus>({
    overall: 'optimal',
    arbitrageEngine: 'running',
    marketData: 'connected',
    riskManagement: 'active',
    notifications: 'enabled',
    autoMode: 'enabled'
  })
  
  const [opportunities, setOpportunities] = useState<Opportunity[]>([])
  const [aiInsights, setAiInsights] = useState<AIInsight[]>([])
  const [autoMode, setAutoMode] = useState(true)
  const [criticalAlerts, setCriticalAlerts] = useState<string[]>([])
  const [performanceMetrics, setPerformanceMetrics] = useState({
    totalProfit: 0,
    winRate: 0,
    avgTradeSize: 0,
    successRate: 0,
    riskScore: 0,
    efficiency: 0
  })

  // Simulación de datos en tiempo real
  useEffect(() => {
    if (!state.isRunning) return

    const updateMetrics = () => {
      const successfulTrades = state.trades.filter(t => t.profit > 0)
      const totalProfit = state.trades.reduce((sum, t) => sum + t.profit, 0)
      const winRate = state.trades.length > 0 ? (successfulTrades.length / state.trades.length) * 100 : 0
      const avgTradeSize = state.trades.length > 0 ? state.trades.reduce((sum, t) => sum + Math.abs(t.profit), 0) / state.trades.length : 0
      
      setPerformanceMetrics({
        totalProfit,
        winRate,
        avgTradeSize,
        successRate: winRate,
        riskScore: Math.max(0, 100 - winRate),
        efficiency: Math.min(100, (totalProfit / Math.max(1, state.trades.length)) * 10)
      })
    }

    const interval = setInterval(updateMetrics, 1000)
    return () => clearInterval(interval)
  }, [state.isRunning, state.trades])

  // Generación de oportunidades con IA
  useEffect(() => {
    if (!state.isRunning) return

    const generateAIOpportunity = (): Opportunity => {
      const types = ['Triangular Arbitrage', 'Cross-DEX Arbitrage', 'Flash Loan Arbitrage', 'MEV Sandwich', 'Liquidation Arbitrage']
      const pairs = ['ETH/USDC', 'BTC/USDT', 'DAI/USDC', 'WETH/DAI', 'UNI/ETH', 'LINK/USDT']
      const exchanges = ['Uniswap V3', 'SushiSwap', 'PancakeSwap', 'Curve', 'Balancer']
      const risks: Array<'low' | 'medium' | 'high'> = ['low', 'medium', 'high']
      
      const profit = Math.random() * 100 + 10
      const probability = Math.random() * 30 + 70
      const aiConfidence = Math.random() * 20 + 80
      
      return {
        id: crypto.randomUUID(),
        type: types[Math.floor(Math.random() * types.length)],
        pair: pairs[Math.floor(Math.random() * pairs.length)],
        profit,
        probability,
        risk: risks[Math.floor(Math.random() * risks.length)],
        aiConfidence,
        timeWindow: Math.floor(Math.random() * 300) + 60, // 1-6 minutes
        exchanges: exchanges.slice(0, Math.floor(Math.random() * 3) + 2),
        estimatedFees: profit * (Math.random() * 0.15 + 0.05),
        marketConditions: Math.random() > 0.7 ? 'favorable' : Math.random() > 0.4 ? 'neutral' : 'unfavorable'
      }
    }

    const generateAIInsight = (): AIInsight => {
      const insights = [
        {
          type: 'opportunity' as const,
          title: 'Oportunidad de Alto Valor Detectada',
          description: 'Arbitraje triangular detectado con 95% de confianza en ETH/USDC/DAI',
          priority: 'high' as const,
          actionable: true,
          action: 'Ejecutar automáticamente'
        },
        {
          type: 'warning' as const,
          title: 'Volatilidad de Mercado Aumentada',
          description: 'Los spreads se están ampliando, considerar pausar operaciones de alto riesgo',
          priority: 'medium' as const,
          actionable: true,
          action: 'Ajustar parámetros de riesgo'
        },
        {
          type: 'success' as const,
          title: 'Estrategia Optimizada',
          description: 'La IA ha optimizado los parámetros de ejecución, eficiencia mejorada 15%',
          priority: 'low' as const,
          actionable: false
        }
      ]
      
      return {
        id: crypto.randomUUID(),
        ...insights[Math.floor(Math.random() * insights.length)],
        timestamp: new Date()
      }
    }

    const opportunityInterval = setInterval(() => {
      if (Math.random() > 0.6) {
        setOpportunities(prev => {
          const newOpp = generateAIOpportunity()
          return [newOpp, ...prev.slice(0, 4)]
        })
      }
    }, 3000)

    const insightInterval = setInterval(() => {
      if (Math.random() > 0.8) {
        setAiInsights(prev => {
          const newInsight = generateAIInsight()
          return [newInsight, ...prev.slice(0, 2)]
        })
      }
    }, 5000)

    return () => {
      clearInterval(opportunityInterval)
      clearInterval(insightInterval)
    }
  }, [state.isRunning])

  // Ejecución automática de oportunidades
  const executeOpportunity = useCallback((opportunity: Opportunity) => {
    const actualProfit = opportunity.profit - opportunity.estimatedFees
    
    executeTrade({
      type: 'arbitrage',
      tokens: opportunity.pair.split('/'),
      amount: 1000,
      profit: actualProfit,
      fees: opportunity.estimatedFees
    })

    setOpportunities(prev => prev.filter(opp => opp.id !== opportunity.id))
    
    // Agregar insight de éxito
    setAiInsights(prev => [{
      id: crypto.randomUUID(),
      type: 'success',
      title: 'Operación Ejecutada Exitosamente',
      description: `${opportunity.type} en ${opportunity.pair} completado con ganancia de $${actualProfit.toFixed(2)}`,
      priority: 'low',
      timestamp: new Date(),
      actionable: false
    }, ...prev.slice(0, 2)])
  }, [executeTrade])

  // Modo automático
  useEffect(() => {
    if (!autoMode || !state.isRunning) return

    const autoExecuteInterval = setInterval(() => {
      const highConfidenceOpps = opportunities.filter(opp => 
        opp.aiConfidence > 90 && opp.probability > 85 && opp.risk === 'low'
      )
      
      if (highConfidenceOpps.length > 0) {
        executeOpportunity(highConfidenceOpps[0])
      }
    }, 2000)

    return () => clearInterval(autoExecuteInterval)
  }, [autoMode, state.isRunning, opportunities, executeOpportunity])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimal':
      case 'running':
      case 'connected':
      case 'active':
      case 'enabled':
        return 'text-green-500'
      case 'warning':
      case 'paused':
      case 'lagging':
      case 'bypass':
        return 'text-yellow-500'
      case 'critical':
      case 'error':
      case 'disconnected':
        return 'text-red-500'
      case 'offline':
      case 'disabled':
        return 'text-gray-500'
      default:
        return 'text-gray-500'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'optimal':
      case 'running':
      case 'connected':
      case 'active':
      case 'enabled':
        return <CheckCircle size={16} className="text-green-500" />
      case 'warning':
      case 'paused':
      case 'lagging':
      case 'bypass':
        return <AlertTriangle size={16} className="text-yellow-500" />
      case 'critical':
      case 'error':
      case 'disconnected':
        return <XCircle size={16} className="text-red-500" />
      case 'offline':
      case 'disabled':
        return <WifiOff size={16} className="text-gray-500" />
      default:
        return <XCircle size={16} className="text-gray-500" />
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  return (
    <div className="space-y-6">
      {/* Header con Estado del Sistema */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Robot size={24} className="text-primary" />
            <h1 className="text-2xl font-bold">Dashboard Inteligente 2025</h1>
          </div>
          <Badge variant={systemStatus.overall === 'optimal' ? 'default' : 'destructive'}>
            {systemStatus.overall === 'optimal' ? 'SISTEMA ÓPTIMO' : 'ATENCIÓN REQUERIDA'}
          </Badge>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Switch
              checked={autoMode}
              onCheckedChange={setAutoMode}
            />
            <span className="text-sm font-medium">Modo Piloto Automático</span>
          </div>
          <Button variant="outline" size="sm">
            <Settings size={16} />
            Configuración
          </Button>
        </div>
      </div>

      {/* Indicadores de Estado - Semáforo Visual */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card className={cn(
          "border-2 transition-all duration-300",
          systemStatus.arbitrageEngine === 'running' ? "border-green-500 bg-green-50" :
          systemStatus.arbitrageEngine === 'paused' ? "border-yellow-500 bg-yellow-50" :
          "border-red-500 bg-red-50"
        )}>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              {getStatusIcon(systemStatus.arbitrageEngine)}
            </div>
            <p className="text-xs font-medium">Motor de Arbitraje</p>
            <p className="text-xs text-muted-foreground capitalize">{systemStatus.arbitrageEngine}</p>
          </CardContent>
        </Card>

        <Card className={cn(
          "border-2 transition-all duration-300",
          systemStatus.marketData === 'connected' ? "border-green-500 bg-green-50" :
          systemStatus.marketData === 'lagging' ? "border-yellow-500 bg-yellow-50" :
          "border-red-500 bg-red-50"
        )}>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              {getStatusIcon(systemStatus.marketData)}
            </div>
            <p className="text-xs font-medium">Datos de Mercado</p>
            <p className="text-xs text-muted-foreground capitalize">{systemStatus.marketData}</p>
          </CardContent>
        </Card>

        <Card className={cn(
          "border-2 transition-all duration-300",
          systemStatus.riskManagement === 'active' ? "border-green-500 bg-green-50" :
          systemStatus.riskManagement === 'bypass' ? "border-yellow-500 bg-yellow-50" :
          "border-red-500 bg-red-50"
        )}>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              {getStatusIcon(systemStatus.riskManagement)}
            </div>
            <p className="text-xs font-medium">Gestión de Riesgo</p>
            <p className="text-xs text-muted-foreground capitalize">{systemStatus.riskManagement}</p>
          </CardContent>
        </Card>

        <Card className={cn(
          "border-2 transition-all duration-300",
          systemStatus.notifications === 'enabled' ? "border-green-500 bg-green-50" :
          "border-gray-500 bg-gray-50"
        )}>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              {getStatusIcon(systemStatus.notifications)}
            </div>
            <p className="text-xs font-medium">Notificaciones</p>
            <p className="text-xs text-muted-foreground capitalize">{systemStatus.notifications}</p>
          </CardContent>
        </Card>

        <Card className={cn(
          "border-2 transition-all duration-300",
          systemStatus.autoMode === 'enabled' ? "border-green-500 bg-green-50" :
          "border-gray-500 bg-gray-50"
        )}>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              {getStatusIcon(systemStatus.autoMode)}
            </div>
            <p className="text-xs font-medium">Modo Automático</p>
            <p className="text-xs text-muted-foreground capitalize">{systemStatus.autoMode}</p>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-500 bg-blue-50">
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <Brain size={16} className="text-blue-500" />
            </div>
            <p className="text-xs font-medium">IA Activa</p>
            <p className="text-xs text-muted-foreground">Analizando</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Resumen Ejecutivo</TabsTrigger>
          <TabsTrigger value="opportunities">Oportunidades IA</TabsTrigger>
          <TabsTrigger value="insights">Insights IA</TabsTrigger>
          <TabsTrigger value="performance">Rendimiento</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Métricas Clave con Proyecciones */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-l-4 border-l-green-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Valor del Portafolio</p>
                    <p className="text-2xl font-bold">{formatCurrency(state.balance)}</p>
                    <p className="text-xs text-green-600">+2.3% hoy</p>
                  </div>
                  <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <TrendUp size={24} className="text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-blue-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">P&L Total</p>
                    <p className={`text-2xl font-bold ${performanceMetrics.totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(performanceMetrics.totalProfit)}
                    </p>
                    <p className="text-xs text-blue-600">Proyección: +15% mes</p>
                  </div>
                  <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                    performanceMetrics.totalProfit >= 0 ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {performanceMetrics.totalProfit >= 0 ? 
                      <TrendUp size={24} className="text-green-600" /> : 
                      <TrendDown size={24} className="text-red-600" />
                    }
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Tasa de Éxito</p>
                    <p className="text-2xl font-bold">{performanceMetrics.winRate.toFixed(1)}%</p>
                    <p className="text-xs text-purple-600">IA Optimizada</p>
                  </div>
                  <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Target size={24} className="text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-orange-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Oportunidades Activas</p>
                    <p className="text-2xl font-bold">{opportunities.length}</p>
                    <p className="text-xs text-orange-600">Escaneando...</p>
                  </div>
                  <div className="h-12 w-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Activity size={24} className="text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Alertas Inteligentes */}
          {criticalAlerts.length > 0 && (
            <Alert className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <strong>Alertas Críticas:</strong> {criticalAlerts.join(', ')}
              </AlertDescription>
            </Alert>
          )}

          {/* Métricas de Rendimiento Avanzadas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <BarChart3 size={16} />
                  Eficiencia del Sistema
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Eficiencia General</span>
                    <span>{performanceMetrics.efficiency.toFixed(1)}%</span>
                  </div>
                  <Progress value={performanceMetrics.efficiency} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Shield size={16} />
                  Puntuación de Riesgo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Riesgo Actual</span>
                    <span>{performanceMetrics.riskScore.toFixed(1)}%</span>
                  </div>
                  <Progress 
                    value={performanceMetrics.riskScore} 
                    className="h-2"
                    style={{
                      '--progress-background': performanceMetrics.riskScore > 70 ? '#ef4444' : 
                                               performanceMetrics.riskScore > 40 ? '#f59e0b' : '#10b981'
                    } as React.CSSProperties}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Zap size={16} />
                  Operaciones por Hora
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-2xl font-bold">{state.trades.length}</p>
                  <p className="text-xs text-muted-foreground">Total ejecutadas</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="opportunities" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain size={20} />
                Oportunidades Detectadas por IA
                {autoMode && (
                  <Badge variant="secondary" className="ml-2">
                    <Play size={12} className="mr-1" />
                    Auto-Ejecución
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!state.isRunning ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Activity size={48} className="mx-auto mb-4 opacity-50" />
                  <p>Inicia la simulación para ver oportunidades de arbitraje</p>
                </div>
              ) : opportunities.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Target size={48} className="mx-auto mb-4 opacity-50" />
                  <p>IA escaneando mercados en busca de oportunidades...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {opportunities.map((opp) => (
                    <div key={opp.id} className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="font-semibold text-blue-900">{opp.type}</h4>
                            <Badge variant="outline" className="border-blue-300 text-blue-700">
                              {opp.pair}
                            </Badge>
                            <Badge className={cn(
                              "text-white",
                              opp.risk === 'low' ? "bg-green-500" :
                              opp.risk === 'medium' ? "bg-yellow-500" : "bg-red-500"
                            )}>
                              {opp.risk} risk
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Ganancia:</span>
                              <p className="font-semibold text-green-600">{formatCurrency(opp.profit)}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Confianza IA:</span>
                              <p className="font-semibold text-blue-600">{opp.aiConfidence.toFixed(1)}%</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Probabilidad:</span>
                              <p className="font-semibold">{opp.probability.toFixed(1)}%</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Ventana:</span>
                              <p className="font-semibold">{Math.floor(opp.timeWindow / 60)}m {opp.timeWindow % 60}s</p>
                            </div>
                          </div>

                          <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Exchanges: {opp.exchanges.join(', ')}</span>
                            <span>Fees: {formatCurrency(opp.estimatedFees)}</span>
                            <span className={cn(
                              "capitalize",
                              opp.marketConditions === 'favorable' ? "text-green-600" :
                              opp.marketConditions === 'neutral' ? "text-yellow-600" : "text-red-600"
                            )}>
                              Mercado: {opp.marketConditions}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex flex-col gap-2">
                          {!autoMode && (
                            <Button
                              onClick={() => executeOpportunity(opp)}
                              className="gap-2 bg-blue-600 hover:bg-blue-700"
                              size="sm"
                            >
                              <Lightning size={16} />
                              Ejecutar
                            </Button>
                          )}
                          <Button variant="outline" size="sm">
                            <Eye size={16} />
                            Detalles
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain size={20} />
                Insights de Inteligencia Artificial
              </CardTitle>
            </CardHeader>
            <CardContent>
              {aiInsights.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Brain size={48} className="mx-auto mb-4 opacity-50" />
                  <p>La IA está analizando datos y generando insights...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {aiInsights.map((insight) => (
                    <div key={insight.id} className={cn(
                      "p-4 rounded-lg border",
                      insight.type === 'opportunity' ? "bg-green-50 border-green-200" :
                      insight.type === 'warning' ? "bg-yellow-50 border-yellow-200" :
                      insight.type === 'success' ? "bg-blue-50 border-blue-200" :
                      "bg-gray-50 border-gray-200"
                    )}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-semibold">{insight.title}</h4>
                            <Badge className={cn(
                              "text-white",
                              insight.priority === 'critical' ? "bg-red-500" :
                              insight.priority === 'high' ? "bg-orange-500" :
                              insight.priority === 'medium' ? "bg-yellow-500" : "bg-green-500"
                            )}>
                              {insight.priority}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{insight.description}</p>
                          <p className="text-xs text-muted-foreground">
                            {insight.timestamp.toLocaleTimeString()}
                          </p>
                        </div>
                        {insight.actionable && insight.action && (
                          <Button variant="outline" size="sm">
                            {insight.action}
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart size={20} />
                  Rendimiento en Tiempo Real
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Ganancia Acumulada</span>
                    <span className="font-semibold">{formatCurrency(performanceMetrics.totalProfit)}</span>
                  </div>
                  <Progress value={Math.min(100, Math.max(0, (performanceMetrics.totalProfit / 1000) * 100))} />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Tasa de Éxito</span>
                    <span className="font-semibold">{performanceMetrics.winRate.toFixed(1)}%</span>
                  </div>
                  <Progress value={performanceMetrics.winRate} />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Eficiencia del Sistema</span>
                    <span className="font-semibold">{performanceMetrics.efficiency.toFixed(1)}%</span>
                  </div>
                  <Progress value={performanceMetrics.efficiency} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart size={20} />
                  Distribución de Operaciones
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Operaciones Exitosas</span>
                    <span className="font-semibold text-green-600">
                      {state.trades.filter(t => t.profit > 0).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Operaciones Fallidas</span>
                    <span className="font-semibold text-red-600">
                      {state.trades.filter(t => t.profit <= 0).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Total de Operaciones</span>
                    <span className="font-semibold">{state.trades.length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Promedio por Operación</span>
                    <span className="font-semibold">{formatCurrency(performanceMetrics.avgTradeSize)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 