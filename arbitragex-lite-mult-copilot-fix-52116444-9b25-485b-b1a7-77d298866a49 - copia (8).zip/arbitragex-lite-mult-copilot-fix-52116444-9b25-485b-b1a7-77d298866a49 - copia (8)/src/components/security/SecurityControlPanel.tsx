import React, { useState, useEffect } from 'react'
import { useKV } from '@/hooks/useKV'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Switch } from '../ui/switch'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { Alert, AlertDescription } from '../ui/alert'
import { Badge } from '../ui/badge'
import { Progress } from '../ui/progress'
import { Separator } from '../ui/separator'
import { 
  Shield, 
  Key, 
  Lock, 
  Fingerprint, 
  DeviceMobile, 
  WarningCircle, 
  CheckCircle, 
  XCircle, 
  Gear, 
  Eye, 
  EyeSlash,
  Repeat,
  Activity,
  Server,
  Database
} from 'lucide-react'
import { ZeroTrustSecurityConfig } from '../../security/core/ZeroTrustSecurityManager'

interface SecurityControlPanelProps {
  environment: 'test' | 'prod'
}

export default function SecurityControlPanel({ environment }: SecurityControlPanelProps) {
  // Persistent security configuration
  const [securityConfig, setSecurityConfig] = useKV<ZeroTrustSecurityConfig>('security-config', {
    authentication: {
      jwt: {
        enabled: true,
        algorithm: 'RS256',
        keyRotationInterval: 24,
        tokenLifetime: 60
      },
      mfa: {
        enabled: true,
        mandatory: environment === 'prod',
        methods: ['TOTP', 'Hardware'],
        backupCodes: true
      },
      hardware: {
        enabled: true,
        fido2Support: true,
        requiredDevices: [],
        fallbackAllowed: true
      },
      biometric: {
        enabled: false,
        methods: ['fingerprint', 'faceId'],
        threshold: 0.95,
        fallbackTimeout: 30
      },
      sessionManagement: {
        enabled: true,
        maxSessions: 3,
        timeoutMinutes: 30,
        ipWhitelist: false,
        geoRestrictions: false
      }
    },
    dataProtection: {
      encryption: {
        enabled: true,
        algorithm: 'AES-256-GCM',
        keySize: 256,
        ivLength: 12,
        tagLength: 16
      },
      endToEndEncryption: {
        enabled: true,
        keyExchange: 'ECDH-P256',
        perfectForwardSecrecy: true
      },
      keyRotation: {
        enabled: true,
        intervalDays: 90,
        automaticRotation: true,
        retentionCount: 10
      },
      hsmIntegration: {
        enabled: false,
        provider: 'AWS_CloudHSM',
        keyGeneration: true,
        signOperations: true
      },
      zeroKnowledgeProofs: {
        enabled: false,
        protocol: 'zk-SNARKs',
        proofGeneration: false,
        verification: false
      }
    }
  })

  const [securityStatus, setSecurityStatus] = useKV('security-status', {
    overallScore: 85,
    activeThreats: 0,
    lastAudit: Date.now(),
    systemHealth: 'HEALTHY' as 'HEALTHY' | 'WARNING' | 'CRITICAL'
  })

  const [showAdvanced, setShowAdvanced] = useState(false)
  const [auditInProgress, setAuditInProgress] = useState(false)

  // Security event simulation
  const [securityEvents] = useKV('security-events', [
    { id: '1', timestamp: Date.now() - 300000, event: 'JWT_TOKEN_VERIFIED', severity: 'LOW' as const, details: 'User authentication successful' },
    { id: '2', timestamp: Date.now() - 600000, event: 'MFA_VERIFICATION_SUCCESS', severity: 'LOW' as const, details: 'TOTP verification completed' },
    { id: '3', timestamp: Date.now() - 900000, event: 'ENCRYPTION_KEY_ROTATION', severity: 'MEDIUM' as const, details: 'Automatic key rotation completed' },
    { id: '4', timestamp: Date.now() - 1200000, event: 'SECURITY_AUDIT_COMPLETED', severity: 'LOW' as const, details: 'Scheduled security audit passed' }
  ])

  const updateSecurityConfig = (updates: Partial<ZeroTrustSecurityConfig>) => {
    setSecurityConfig(current => ({
      ...current,
      ...updates,
      authentication: { ...current.authentication, ...updates.authentication },
      dataProtection: { ...current.dataProtection, ...updates.dataProtection }
    }))
  }

  const runSecurityAudit = async () => {
    setAuditInProgress(true)
    
    // Simulate audit process
    await new Promise(resolve => setTimeout(resolve, 3000))
    
    setSecurityStatus(current => ({
      ...current,
      lastAudit: Date.now(),
      overallScore: Math.floor(Math.random() * 20) + 80, // 80-100
      systemHealth: 'HEALTHY' as const
    }))
    
    setAuditInProgress(false)
  }

  const getSecurityScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600'
    if (score >= 70) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getHealthStatusColor = (status: string) => {
    switch (status) {
      case 'HEALTHY': return 'text-green-600'
      case 'WARNING': return 'text-yellow-600'
      case 'CRITICAL': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Shield className="text-blue-600" size={32} />
            Zero-Trust Security Control Panel
          </h1>
          <p className="text-muted-foreground mt-2">
            Military-grade security configuration for ArbitrageX Pro 2
          </p>
        </div>
        <Badge variant={environment === 'prod' ? 'destructive' : 'secondary'} className="text-sm px-3 py-1">
          {environment.toUpperCase()} ENVIRONMENT
        </Badge>
      </div>

      {/* Critical Security Alert */}
      {!securityConfig.authentication.mfa.mandatory && environment === 'prod' && (
        <Alert className="border-red-500 bg-red-50">
          <WarningCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>CRITICAL SECURITY WARNING:</strong> MFA is not mandatory in production environment. 
            This significantly reduces security. Enable mandatory MFA immediately.
          </AlertDescription>
        </Alert>
      )}

      {/* Security Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Security Score</p>
                <p className={`text-2xl font-bold ${getSecurityScoreColor(securityStatus.overallScore)}`}>
                  {securityStatus.overallScore}%
                </p>
              </div>
              <Shield className="h-8 w-8 text-blue-600" />
            </div>
            <Progress value={securityStatus.overallScore} className="mt-3" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">System Health</p>
                <p className={`text-2xl font-bold ${getHealthStatusColor(securityStatus.systemHealth)}`}>
                  {securityStatus.systemHealth}
                </p>
              </div>
              <Activity className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Threats</p>
                <p className="text-2xl font-bold text-green-600">{securityStatus.activeThreats}</p>
              </div>
              <WarningCircle className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Last Audit</p>
                <p className="text-sm font-bold">
                  {new Date(securityStatus.lastAudit).toLocaleDateString()}
                </p>
              </div>
              <Button 
                onClick={runSecurityAudit} 
                disabled={auditInProgress}
                size="sm"
                variant="outline"
              >
                {auditInProgress ? <Repeat className="h-4 w-4 animate-spin" /> : 'Audit'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Configuration Tabs */}
      <Tabs defaultValue="authentication" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="authentication">Authentication</TabsTrigger>
          <TabsTrigger value="encryption">Data Protection</TabsTrigger>
          <TabsTrigger value="monitoring">Desktoping</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
        </TabsList>

        {/* Authentication Tab */}
        <TabsContent value="authentication" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* JWT Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key size={20} />
                  JWT Authentication (RS256)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>JWT Enabled (MANDATORY)</Label>
                  <Switch 
                    checked={true} 
                    disabled={true}
                  />
                </div>
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    JWT with RS256 is always enabled for critical security compliance
                  </AlertDescription>
                </Alert>
                
                <div className="space-y-2">
                  <Label>Key Rotation Interval (hours)</Label>
                  <Input 
                    type="number" 
                    value={securityConfig.authentication.jwt.keyRotationInterval}
                    onChange={(e) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        jwt: {
                          ...securityConfig.authentication.jwt,
                          keyRotationInterval: parseInt(e.target.value) || 24
                        }
                      }
                    })}
                    min={1}
                    max={168}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Token Lifetime (minutes)</Label>
                  <Input 
                    type="number" 
                    value={securityConfig.authentication.jwt.tokenLifetime}
                    onChange={(e) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        jwt: {
                          ...securityConfig.authentication.jwt,
                          tokenLifetime: parseInt(e.target.value) || 60
                        }
                      }
                    })}
                    min={5}
                    max={1440}
                  />
                </div>
              </CardContent>
            </Card>

            {/* MFA Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DeviceMobile size={20} />
                  Multi-Factor Authentication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>MFA Enabled</Label>
                  <Switch 
                    checked={securityConfig.authentication.mfa.enabled}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        mfa: {
                          ...securityConfig.authentication.mfa,
                          enabled: checked
                        }
                      }
                    })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>MFA Mandatory (RECOMMENDED)</Label>
                  <Switch 
                    checked={securityConfig.authentication.mfa.mandatory}
                    onCheckedChange={(checked) => {
                      if (!checked && environment === 'prod') {
                        // Show confirmation dialog in real implementation
                        console.warn('Disabling mandatory MFA in production is not recommended')
                      }
                      updateSecurityConfig({
                        authentication: {
                          ...securityConfig.authentication,
                          mfa: {
                            ...securityConfig.authentication.mfa,
                            mandatory: checked
                          }
                        }
                      })
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Enabled Methods</Label>
                  <div className="flex flex-wrap gap-2">
                    {['TOTP', 'SMS', 'Email', 'Hardware'].map(method => (
                      <Badge 
                        key={method}
                        variant={securityConfig.authentication.mfa.methods.includes(method as any) ? 'default' : 'outline'}
                        className="cursor-pointer"
                        onClick={() => {
                          const methods = securityConfig.authentication.mfa.methods
                          const newMethods = methods.includes(method as any)
                            ? methods.filter(m => m !== method)
                            : [...methods, method as any]
                          
                          updateSecurityConfig({
                            authentication: {
                              ...securityConfig.authentication,
                              mfa: {
                                ...securityConfig.authentication.mfa,
                                methods: newMethods
                              }
                            }
                          })
                        }}
                      >
                        {method}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Label>Backup Codes</Label>
                  <Switch 
                    checked={securityConfig.authentication.mfa.backupCodes}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        mfa: {
                          ...securityConfig.authentication.mfa,
                          backupCodes: checked
                        }
                      }
                    })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Hardware Keys */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock size={20} />
                  Hardware Keys (FIDO2)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Hardware Keys Enabled</Label>
                  <Switch 
                    checked={securityConfig.authentication.hardware.enabled}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        hardware: {
                          ...securityConfig.authentication.hardware,
                          enabled: checked
                        }
                      }
                    })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>FIDO2/WebAuthn Support</Label>
                  <Switch 
                    checked={securityConfig.authentication.hardware.fido2Support}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        hardware: {
                          ...securityConfig.authentication.hardware,
                          fido2Support: checked
                        }
                      }
                    })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>Allow Fallback Methods</Label>
                  <Switch 
                    checked={securityConfig.authentication.hardware.fallbackAllowed}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        hardware: {
                          ...securityConfig.authentication.hardware,
                          fallbackAllowed: checked
                        }
                      }
                    })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Biometric Authentication */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Fingerprint size={20} />
                  Biometric Authentication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Biometric Enabled</Label>
                  <Switch 
                    checked={securityConfig.authentication.biometric.enabled}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        biometric: {
                          ...securityConfig.authentication.biometric,
                          enabled: checked
                        }
                      }
                    })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Confidence Threshold</Label>
                  <Input 
                    type="number" 
                    value={securityConfig.authentication.biometric.threshold}
                    onChange={(e) => updateSecurityConfig({
                      authentication: {
                        ...securityConfig.authentication,
                        biometric: {
                          ...securityConfig.authentication.biometric,
                          threshold: parseFloat(e.target.value) || 0.95
                        }
                      }
                    })}
                    min={0.5}
                    max={1}
                    step={0.01}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Enabled Methods</Label>
                  <div className="flex flex-wrap gap-2">
                    {['fingerprint', 'faceId', 'voiceprint', 'retina'].map(method => (
                      <Badge 
                        key={method}
                        variant={securityConfig.authentication.biometric.methods.includes(method as any) ? 'default' : 'outline'}
                        className="cursor-pointer"
                        onClick={() => {
                          const methods = securityConfig.authentication.biometric.methods
                          const newMethods = methods.includes(method as any)
                            ? methods.filter(m => m !== method)
                            : [...methods, method as any]
                          
                          updateSecurityConfig({
                            authentication: {
                              ...securityConfig.authentication,
                              biometric: {
                                ...securityConfig.authentication.biometric,
                                methods: newMethods
                              }
                            }
                          })
                        }}
                      >
                        {method}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Data Protection Tab */}
        <TabsContent value="encryption" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* AES Encryption */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock size={20} />
                  AES-256-GCM Encryption
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Encryption Enabled (MANDATORY)</Label>
                  <Switch checked={true} disabled={true} />
                </div>
                
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    AES-256-GCM encryption is always enabled for critical data protection
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <Label>Algorithm: AES-256-GCM</Label>
                  <Input value="AES-256-GCM" disabled />
                </div>

                <div className="space-y-2">
                  <Label>Key Size: 256 bits</Label>
                  <Input value="256" disabled />
                </div>

                <div className="space-y-2">
                  <Label>IV Length: 12 bytes</Label>
                  <Input value="12" disabled />
                </div>
              </CardContent>
            </Card>

            {/* Key Rotation */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Repeat size={20} />
                  Automatic Key Rotation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Key Rotation Enabled</Label>
                  <Switch 
                    checked={securityConfig.dataProtection.keyRotation.enabled}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        keyRotation: {
                          ...securityConfig.dataProtection.keyRotation,
                          enabled: checked
                        }
                      }
                    })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Rotation Interval (days)</Label>
                  <Input 
                    type="number" 
                    value={securityConfig.dataProtection.keyRotation.intervalDays}
                    onChange={(e) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        keyRotation: {
                          ...securityConfig.dataProtection.keyRotation,
                          intervalDays: parseInt(e.target.value) || 90
                        }
                      }
                    })}
                    min={1}
                    max={365}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>Automatic Rotation</Label>
                  <Switch 
                    checked={securityConfig.dataProtection.keyRotation.automaticRotation}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        keyRotation: {
                          ...securityConfig.dataProtection.keyRotation,
                          automaticRotation: checked
                        }
                      }
                    })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Key Retention Count</Label>
                  <Input 
                    type="number" 
                    value={securityConfig.dataProtection.keyRotation.retentionCount}
                    onChange={(e) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        keyRotation: {
                          ...securityConfig.dataProtection.keyRotation,
                          retentionCount: parseInt(e.target.value) || 10
                        }
                      }
                    })}
                    min={1}
                    max={50}
                  />
                </div>
              </CardContent>
            </Card>

            {/* HSM Integration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Server size={20} />
                  HSM Integration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>HSM Integration</Label>
                  <Switch 
                    checked={securityConfig.dataProtection.hsmIntegration.enabled}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        hsmIntegration: {
                          ...securityConfig.dataProtection.hsmIntegration,
                          enabled: checked
                        }
                      }
                    })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>HSM Provider</Label>
                  <select 
                    className="w-full p-2 border rounded"
                    value={securityConfig.dataProtection.hsmIntegration.provider}
                    onChange={(e) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        hsmIntegration: {
                          ...securityConfig.dataProtection.hsmIntegration,
                          provider: e.target.value as any
                        }
                      }
                    })}
                  >
                    <option value="AWS_CloudHSM">AWS CloudHSM</option>
                    <option value="Azure_HSM">Azure Dedicated HSM</option>
                    <option value="Hardware_HSM">Hardware HSM</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <Label>HSM Key Generation</Label>
                  <Switch 
                    checked={securityConfig.dataProtection.hsmIntegration.keyGeneration}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        hsmIntegration: {
                          ...securityConfig.dataProtection.hsmIntegration,
                          keyGeneration: checked
                        }
                      }
                    })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Zero-Knowledge Proofs */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye size={20} />
                  Zero-Knowledge Proofs
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>ZK Proofs Enabled</Label>
                  <Switch 
                    checked={securityConfig.dataProtection.zeroKnowledgeProofs.enabled}
                    onCheckedChange={(checked) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        zeroKnowledgeProofs: {
                          ...securityConfig.dataProtection.zeroKnowledgeProofs,
                          enabled: checked
                        }
                      }
                    })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>ZK Protocol</Label>
                  <select 
                    className="w-full p-2 border rounded"
                    value={securityConfig.dataProtection.zeroKnowledgeProofs.protocol}
                    onChange={(e) => updateSecurityConfig({
                      dataProtection: {
                        ...securityConfig.dataProtection,
                        zeroKnowledgeProofs: {
                          ...securityConfig.dataProtection.zeroKnowledgeProofs,
                          protocol: e.target.value as any
                        }
                      }
                    })}
                  >
                    <option value="zk-SNARKs">zk-SNARKs</option>
                    <option value="zk-STARKs">zk-STARKs</option>
                    <option value="Bulletproofs">Bulletproofs</option>
                  </select>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Desktoping Tab */}
        <TabsContent value="monitoring" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Security Events */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity size={20} />
                  Recent Security Events
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {securityEvents.slice(0, 10).map(event => (
                    <div key={event.id} className="flex items-center justify-between p-2 border rounded">
                      <div className="flex items-center gap-2">
                        {event.severity === 'LOW' && <CheckCircle size={16} className="text-green-600" />}
                        {event.severity === 'MEDIUM' && <WarningCircle size={16} className="text-yellow-600" />}
                        {event.severity === 'HIGH' && <XCircle size={16} className="text-red-600" />}
                        <div>
                          <p className="text-sm font-medium">{event.event.replace(/_/g, ' ')}</p>
                          <p className="text-xs text-muted-foreground">{event.details}</p>
                        </div>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(event.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* System Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database size={20} />
                  Security Module Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { name: 'JWT Security Module', status: 'HEALTHY', uptime: '99.9%' },
                    { name: 'MFA Security Module', status: 'HEALTHY', uptime: '99.8%' },
                    { name: 'Encryption Module', status: 'HEALTHY', uptime: '100%' },
                    { name: 'Hardware Key Module', status: 'WARNING', uptime: '98.5%' },
                    { name: 'HSM Integration', status: 'DISABLED', uptime: 'N/A' }
                  ].map(module => (
                    <div key={module.name} className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <p className="text-sm font-medium">{module.name}</p>
                        <p className="text-xs text-muted-foreground">Uptime: {module.uptime}</p>
                      </div>
                      <Badge 
                        variant={
                          module.status === 'HEALTHY' ? 'default' : 
                          module.status === 'WARNING' ? 'secondary' : 
                          'outline'
                        }
                      >
                        {module.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Compliance Tab */}
        <TabsContent value="compliance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Compliance Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle size={20} />
                  Compliance Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { framework: 'SOC 2 Type II', status: 'COMPLIANT', score: 95 },
                    { framework: 'ISO 27001', status: 'COMPLIANT', score: 92 },
                    { framework: 'GDPR', status: 'COMPLIANT', score: 88 },
                    { framework: 'CCPA', status: 'COMPLIANT', score: 90 },
                    { framework: 'PCI DSS', status: 'PARTIAL', score: 75 }
                  ].map(item => (
                    <div key={item.framework} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{item.framework}</span>
                        <Badge variant={item.status === 'COMPLIANT' ? 'default' : 'secondary'}>
                          {item.status}
                        </Badge>
                      </div>
                      <Progress value={item.score} className="h-2" />
                      <span className="text-xs text-muted-foreground">{item.score}% compliant</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Audit Schedule */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gear size={20} />
                  Audit & Compliance Schedule
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { audit: 'Daily Security Scan', next: '2025-01-15 00:00', frequency: 'Daily' },
                    { audit: 'Weekly Vulnerability Assessment', next: '2025-01-20 02:00', frequency: 'Weekly' },
                    { audit: 'Monthly Compliance Review', next: '2025-02-01 10:00', frequency: 'Monthly' },
                    { audit: 'Quarterly Penetration Test', next: '2025-04-01 09:00', frequency: 'Quarterly' },
                    { audit: 'Annual Security Audit', next: '2025-12-01 09:00', frequency: 'Annual' }
                  ].map(item => (
                    <div key={item.audit} className="flex justify-between items-center p-2 border rounded">
                      <div>
                        <p className="text-sm font-medium">{item.audit}</p>
                        <p className="text-xs text-muted-foreground">Next: {item.next}</p>
                      </div>
                      <Badge variant="outline">{item.frequency}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Advanced Configuration Toggle */}
      <div className="flex items-center justify-between pt-6 border-t">
        <div className="flex items-center gap-2">
          <Switch 
            checked={showAdvanced}
            onCheckedChange={setShowAdvanced}
          />
          <Label>Show Advanced Configuration</Label>
        </div>
        
        <Button onClick={runSecurityAudit} disabled={auditInProgress}>
          {auditInProgress ? (
            <>
              <Repeat className="mr-2 h-4 w-4 animate-spin" />
              Running Security Audit...
            </>
          ) : (
            <>
              <Shield className="mr-2 h-4 w-4" />
              Run Full Security Audit
            </>
          )}
        </Button>
      </div>

      {/* Advanced Configuration */}
      {showAdvanced && (
        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">⚠️ Advanced Security Configuration</CardTitle>
            <p className="text-sm text-muted-foreground">
              These settings should only be modified by security professionals. 
              Improper configuration may compromise system security.
            </p>
          </CardHeader>
          <CardContent>
            <Alert className="border-red-500 bg-red-50">
              <WarningCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <strong>WARNING:</strong> Advanced configuration changes require security audit approval 
                and may affect system availability. All changes are logged and monitored.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}
    </div>
  )
}