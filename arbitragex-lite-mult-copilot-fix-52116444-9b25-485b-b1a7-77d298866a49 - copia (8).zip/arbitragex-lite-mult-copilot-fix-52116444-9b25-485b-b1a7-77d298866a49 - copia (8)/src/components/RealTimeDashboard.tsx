import React, { useState, useEffect, useCallback } from 'react';
import { ethers } from 'ethers';
import { RealTimeDataIngestion } from '../core/RealTimeDataIngestion';
import { ArbitrageDetectionEngine } from '../core/ArbitrageDetectionEngine';
import { MEVProtectedExecutor } from '../core/MEVProtectedExecutor';

interface RealTimeMetrics {
  totalPools: number;
  activeOpportunities: number;
  totalVolume24h: string;
  averageROI: number;
  gasPrice: string;
  networkLatency: number;
  lastBlockNumber: number;
  connectedChains: number;
}

interface ArbitrageOpportunity {
  id: string;
  path: string[];
  dexes: string[];
  pools: string[];
  amountIn: string;
  expectedAmountOut: string;
  netProfit: string;
  confidence: number;
  executionDeadline: number;
  chainId: number;
  timestamp: number;
}

interface PoolState {
  address: string;
  token0: string;
  token1: string;
  reserve0: string;
  reserve1: string;
  fee: number;
  volume24h: string;
  tvl: string;
}

export const RealTimeDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<RealTimeMetrics>({
    totalPools: 0,
    activeOpportunities: 0,
    totalVolume24h: '0',
    averageROI: 0,
    gasPrice: '0',
    networkLatency: 0,
    lastBlockNumber: 0,
    connectedChains: 0
  });

  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([]);
  const [poolStates, setPoolStates] = useState<PoolState[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [error, setError] = useState<string | null>(null);

  // Inicializar servicios reales
  const [dataIngestion] = useState(() => {
    const rpcConfigs = [
      { chainId: 1, wsUrl: 'wss://mainnet.infura.io/ws/v3/YOUR_INFURA_KEY' },
      { chainId: 56, wsUrl: 'wss://bsc-dataseed.binance.org' },
      { chainId: 137, wsUrl: 'wss://polygon-rpc.com' },
      { chainId: 43114, wsUrl: 'wss://api.avax.network/ext/bc/C/ws' },
      { chainId: 250, wsUrl: 'wss://rpc.ftm.tools' },
      { chainId: 42161, wsUrl: 'wss://arb1.arbitrum.io/ws' },
      { chainId: 10, wsUrl: 'wss://mainnet.optimism.io' },
      { chainId: 8453, wsUrl: 'wss://mainnet.base.org' }
    ];
    return new RealTimeDataIngestion(rpcConfigs);
  });

  const [arbitrageEngine] = useState(() => new ArbitrageDetectionEngine(dataIngestion));

  // Configurar listeners para datos en tiempo real
  useEffect(() => {
    const handlePoolStateUpdate = (event: CustomEvent) => {
      const { poolState, chainId } = event.detail;
      updatePoolState(poolState, chainId);
    };

    dataIngestion.onPoolStateUpdate(handlePoolStateUpdate);

    return () => {
      dataIngestion.removePoolStateUpdateListener(handlePoolStateUpdate);
    };
  }, [dataIngestion]);

  // Actualizar estado de pools en tiempo real
  const updatePoolState = useCallback((poolState: any, chainId: number) => {
    setPoolStates(prev => {
      const existingIndex = prev.findIndex(p => p.address === poolState.address);
      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...poolState,
          reserve0: ethers.utils.formatEther(poolState.reserve0),
          reserve1: ethers.utils.formatEther(poolState.reserve1),
          volume24h: '0', // Obtener desde API de volumen
          tvl: calculateTVL(poolState.reserve0, poolState.reserve1, poolState.token0, poolState.token1)
        };
        return updated;
      } else {
        return [...prev, {
          ...poolState,
          reserve0: ethers.utils.formatEther(poolState.reserve0),
          reserve1: ethers.utils.formatEther(poolState.reserve1),
          volume24h: '0',
          tvl: calculateTVL(poolState.reserve0, poolState.reserve1, poolState.token0, poolState.token1)
        }];
      }
    });
  }, []);

  // Calcular TVL aproximado
  const calculateTVL = (reserve0: ethers.BigNumber, reserve1: ethers.BigNumber, token0: string, token1: string): string => {
    // En producción, esto se obtendría desde APIs de precios reales
    // Por ahora usamos valores aproximados
    const ethPrice = 2000; // USD
    const usdcPrice = 1; // USD
    
    let tvl = 0;
    if (token0.toLowerCase() === '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2') { // WETH
      tvl += parseFloat(ethers.utils.formatEther(reserve0)) * ethPrice;
    } else if (token0.toLowerCase() === '0xa0b86a33e6441b8c4c8c8c8c8c8c8c8c8c8c8c8') { // USDC
      tvl += parseFloat(ethers.utils.formatEther(reserve0)) * usdcPrice;
    }
    
    if (token1.toLowerCase() === '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2') { // WETH
      tvl += parseFloat(ethers.utils.formatEther(reserve1)) * ethPrice;
    } else if (token1.toLowerCase() === '0xa0b86a33e6441b8c4c8c8c8c8c8c8c8c8c8c8c8') { // USDC
      tvl += parseFloat(ethers.utils.formatEther(reserve1)) * usdcPrice;
    }
    
    return tvl.toFixed(2);
  };

  // Actualizar métricas en tiempo real
  const updateMetrics = useCallback(async () => {
    try {
      // Obtener métricas reales desde el backend
      const response = await fetch('/api/arbitrage/metrics');
      if (response.ok) {
        const realMetrics = await response.json();
        setMetrics(realMetrics);
      } else {
        // Fallback a métricas calculadas localmente
        const connectionStatus = dataIngestion.getConnectionStatus();
        const connectedChains = Object.values(connectionStatus).filter(Boolean).length;
        
        setMetrics(prev => ({
          ...prev,
          totalPools: poolStates.length,
          activeOpportunities: opportunities.length,
          connectedChains,
          lastUpdate: new Date()
        }));
      }
    } catch (error) {
      console.error('Error actualizando métricas:', error);
      setError('Error conectando con el backend');
    }
  }, [poolStates.length, opportunities.length, dataIngestion]);

  // Buscar oportunidades de arbitraje en tiempo real
  const searchOpportunities = useCallback(async () => {
    try {
      // Obtener tokens activos desde pools
      const activeTokens = Array.from(new Set(
        poolStates.flatMap(pool => [pool.token0, pool.token1])
      )).slice(0, 50); // Limitar a 50 tokens para performance

      // Buscar oportunidades en cada chain
      const allOpportunities: ArbitrageOpportunity[] = [];
      
      for (const chainId of [1, 56, 137, 43114, 250, 42161, 10, 8453]) {
        try {
          const chainOpportunities = await arbitrageEngine.detectArbitrageOpportunities(
            activeTokens,
            chainId
          );
          
          const formattedOpportunities = chainOpportunities.map(opp => ({
            id: `${opp.chainId}-${opp.timestamp}`,
            path: opp.path,
            dexes: opp.dexes,
            pools: opp.pools,
            amountIn: ethers.utils.formatEther(opp.amountIn),
            expectedAmountOut: ethers.utils.formatEther(opp.expectedAmountOut),
            netProfit: ethers.utils.formatEther(opp.netProfit),
            confidence: opp.confidence,
            executionDeadline: opp.executionDeadline,
            chainId: opp.chainId,
            timestamp: opp.timestamp
          }));
          
          allOpportunities.push(...formattedOpportunities);
        } catch (error) {
          console.error(`Error buscando oportunidades en chain ${chainId}:`, error);
        }
      }
      
      // Filtrar y ordenar oportunidades
      const validOpportunities = allOpportunities
        .filter(opp => opp.confidence > 70 && parseFloat(opp.netProfit) > 0.001)
        .sort((a, b) => parseFloat(b.netProfit) - parseFloat(a.netProfit));
      
      setOpportunities(validOpportunities);
      setError(null);
      
    } catch (error) {
      console.error('Error buscando oportunidades:', error);
      setError('Error detectando oportunidades de arbitraje');
    }
  }, [arbitrageEngine, poolStates]);

  // Actualizar datos cada 5 segundos
  useEffect(() => {
    const interval = setInterval(() => {
      updateMetrics();
      searchOpportunities();
      setLastUpdate(new Date());
    }, 5000);

    return () => clearInterval(interval);
  }, [updateMetrics, searchOpportunities]);

  // Actualización inicial
  useEffect(() => {
    updateMetrics();
    searchOpportunities();
    setIsConnected(true);
  }, [updateMetrics, searchOpportunities]);

  // Formatear números para display
  const formatNumber = (value: number | string, decimals: number = 2): string => {
    const num = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(num)) return '0';
    return num.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  };

  // Formatear dirección de wallet
  const formatAddress = (address: string): string => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  // Obtener nombre de la chain
  const getChainName = (chainId: number): string => {
    const chainNames: { [key: number]: string } = {
      1: 'Ethereum',
      56: 'BSC',
      137: 'Polygon',
      43114: 'Avalanche',
      250: 'Fantom',
      42161: 'Arbitrum',
      10: 'Optimism',
      8453: 'Base'
    };
    return chainNames[chainId] || `Chain ${chainId}`;
  };

  return (
    <div className="real-time-dashboard">
      {/* Header con métricas principales */}
      <div className="dashboard-header">
        <h1>🚀 ArbitrageX Pro - Dashboard en Tiempo Real</h1>
        <div className="connection-status">
          <span className={`status-indicator ${isConnected ? 'connected' : 'disconnected'}`}>
            {isConnected ? '🟢 Conectado' : '🔴 Desconectado'}
          </span>
          <span className="last-update">
            Última actualización: {lastUpdate.toLocaleTimeString()}
          </span>
        </div>
      </div>

      {/* Métricas principales */}
      <div className="metrics-grid">
        <div className="metric-card">
          <h3>📊 Pools Activos</h3>
          <div className="metric-value">{metrics.totalPools.toLocaleString()}</div>
          <div className="metric-label">Total de pools monitoreados</div>
        </div>
        
        <div className="metric-card">
          <h3>💰 Oportunidades</h3>
          <div className="metric-value">{metrics.activeOpportunities}</div>
          <div className="metric-label">Oportunidades activas</div>
        </div>
        
        <div className="metric-card">
          <h3>📈 Volumen 24h</h3>
          <div className="metric-value">${formatNumber(metrics.totalVolume24h)}</div>
          <div className="metric-label">Volumen total en 24 horas</div>
        </div>
        
        <div className="metric-card">
          <h3>🎯 ROI Promedio</h3>
          <div className="metric-value">{formatNumber(metrics.averageROI)}%</div>
          <div className="metric-label">Retorno promedio</div>
        </div>
        
        <div className="metric-card">
          <h3>⛽ Precio Gas</h3>
          <div className="metric-value">{formatNumber(metrics.gasPrice)} gwei</div>
          <div className="metric-label">Precio actual del gas</div>
        </div>
        
        <div className="metric-card">
          <h3>🌐 Chains Conectadas</h3>
          <div className="metric-value">{metrics.connectedChains}/8</div>
          <div className="metric-label">Blockchains activas</div>
        </div>
      </div>

      {/* Oportunidades de arbitraje en tiempo real */}
      <div className="opportunities-section">
        <h2>🎯 Oportunidades de Arbitraje Activas</h2>
        {error && (
          <div className="error-message">
            ⚠️ {error}
          </div>
        )}
        
        {opportunities.length === 0 ? (
          <div className="no-opportunities">
            🔍 Analizando mercados en tiempo real...
          </div>
        ) : (
          <div className="opportunities-grid">
            {opportunities.slice(0, 10).map((opportunity) => (
              <div key={opportunity.id} className="opportunity-card">
                <div className="opportunity-header">
                  <span className="chain-badge">{getChainName(opportunity.chainId)}</span>
                  <span className="confidence-badge">
                    {opportunity.confidence}% confianza
                  </span>
                </div>
                
                <div className="opportunity-path">
                  <span className="path-label">Ruta:</span>
                  <div className="path-tokens">
                    {opportunity.path.map((token, index) => (
                      <React.Fragment key={index}>
                        <span className="token">{formatAddress(token)}</span>
                        {index < opportunity.path.length - 1 && <span>→</span>}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
                
                <div className="opportunity-details">
                  <div className="detail-row">
                    <span>Input:</span>
                    <span>{formatNumber(opportunity.amountIn)} ETH</span>
                  </div>
                  <div className="detail-row">
                    <span>Output Esperado:</span>
                    <span>{formatNumber(opportunity.expectedAmountOut)} ETH</span>
                  </div>
                  <div className="detail-row">
                    <span>Ganancia Neta:</span>
                    <span className="profit">{formatNumber(opportunity.netProfit)} ETH</span>
                  </div>
                  <div className="detail-row">
                    <span>DEXs:</span>
                    <span>{opportunity.dexes.join(', ')}</span>
                  </div>
                </div>
                
                <div className="opportunity-actions">
                  <button className="btn-execute" disabled>
                    ⚡ Ejecutar
                  </button>
                  <button className="btn-details">
                    📊 Detalles
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Estado de pools en tiempo real */}
      <div className="pools-section">
        <h2>🏊 Estado de Pools en Tiempo Real</h2>
        <div className="pools-table">
          <table>
            <thead>
              <tr>
                <th>Pool</th>
                <th>Token 0</th>
                <th>Token 1</th>
                <th>Reserve 0</th>
                <th>Reserve 1</th>
                <th>TVL (USD)</th>
                <th>Fee</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              {poolStates.slice(0, 20).map((pool, index) => (
                <tr key={index}>
                  <td>{formatAddress(pool.address)}</td>
                  <td>{formatAddress(pool.token0)}</td>
                  <td>{formatAddress(pool.token1)}</td>
                  <td>{formatNumber(pool.reserve0)}</td>
                  <td>{formatNumber(pool.reserve1)}</td>
                  <td>${pool.tvl}</td>
                  <td>{pool.fee}%</td>
                  <td>
                    <span className="status-active">🟢 Activo</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer con estadísticas del motor */}
      <div className="dashboard-footer">
        <div className="engine-stats">
          <h3>🔧 Estadísticas del Motor</h3>
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-label">Ciclos Analizados:</span>
              <span className="stat-value">0</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Oportunidades Encontradas:</span>
              <span className="stat-value">0</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Confianza Promedio:</span>
              <span className="stat-value">0%</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Última Actualización:</span>
              <span className="stat-value">0</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RealTimeDashboard;
