import React from 'react';

interface SystemMetrics {
  totalOpportunities: number;
  activeStrategies: number;
  totalProfit: number;
  systemEfficiency: number;
  riskScore: number;
  operationsPerHour: number;
  uptime: number;
  errorRate: number;
  successRate: number;
  reconnectionAttempts: number;
}

interface NavigationSidebarProps {
  activeDashboard: 'configuration' | 'monitoring' | 'execution' | 'transactions' | 'history' | 'connectivity' | 'advanced-monitoring';
  onDashboardChange: (dashboard: 'configuration' | 'monitoring' | 'execution' | 'transactions' | 'history' | 'connectivity' | 'advanced-monitoring') => void;
  systemMetrics: SystemMetrics;
}

export const NavigationSidebar: React.FC<NavigationSidebarProps> = ({
  activeDashboard,
  onDashboardChange,
  systemMetrics
}) => {
  const navigationItems = [
    {
      id: 'configuration',
      name: 'Configuración',
      icon: '⚙️',
      description: 'Gestión centralizada del sistema',
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-500/10',
      borderColor: 'border-blue-500/30',
      metrics: {
        label: 'Blockchains',
        value: '12',
        unit: 'activas'
      }
    },
    {
      id: 'monitoring',
      name: 'Seguimiento',
      icon: '📊',
      description: 'Monitoreo en tiempo real',
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-500/10',
      borderColor: 'border-green-500/30',
      metrics: {
        label: 'Oportunidades',
        value: systemMetrics.totalOpportunities.toString(),
        unit: 'detectadas'
      }
    },
    {
      id: 'execution',
      name: 'Ejecución',
      icon: '⚡',
      description: 'Control de estrategias',
      color: 'from-yellow-500 to-yellow-600',
      bgColor: 'bg-yellow-500/10',
      borderColor: 'border-yellow-500/30',
      metrics: {
        label: 'Estrategias',
        value: systemMetrics.activeStrategies.toString(),
        unit: 'activas'
      }
    },
    {
      id: 'transactions',
      name: 'Transacciones',
      icon: '💱',
      description: 'Gestión de operaciones',
      color: 'from-orange-500 to-orange-600',
      bgColor: 'bg-orange-500/10',
      borderColor: 'border-orange-500/30',
      metrics: {
        label: 'Operaciones',
        value: systemMetrics.operationsPerHour.toString(),
        unit: '/hora'
      }
    },
    {
      id: 'history',
      name: 'Historiales',
      icon: '📈',
      description: 'Análisis y reportes',
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/30',
      metrics: {
        label: 'Ganancias',
        value: `$${systemMetrics.totalProfit.toLocaleString()}`,
        unit: 'total'
      }
    },
    {
      id: 'connectivity',
      name: 'Conectividad',
      icon: '🔌',
      description: 'Estado de infraestructura',
      color: 'from-red-500 to-red-600',
      bgColor: 'bg-red-500/10',
      borderColor: 'border-red-500/30',
      metrics: {
        label: 'Uptime',
        value: `${systemMetrics.uptime.toFixed(1)}%`,
        unit: 'sistema'
      }
    },
    {
      id: 'advanced-monitoring',
      name: 'Monitoreo Avanzado',
      icon: '🔬',
      description: 'Métricas técnicas detalladas',
      color: 'from-indigo-500 to-indigo-600',
      bgColor: 'bg-indigo-500/10',
      borderColor: 'border-indigo-500/30',
      metrics: {
        label: 'Alertas',
        value: '0',
        unit: 'activas'
      }
    }
  ];

  return (
    <div className="w-80 bg-black/30 backdrop-blur-lg border-r border-blue-500/30 overflow-y-auto">
      {/* Header del Sidebar */}
      <div className="p-6 border-b border-blue-500/20">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
            <span className="text-sm font-bold">AX</span>
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">Navegación</h2>
            <p className="text-xs text-blue-300">Dashboards del Sistema</p>
          </div>
        </div>
      </div>

      {/* Métricas del Sistema */}
      <div className="p-6 border-b border-blue-500/20">
        <h3 className="text-sm font-medium text-blue-300 mb-4">Estado del Sistema</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-black/20 rounded-lg p-3 border border-blue-500/20">
            <div className="text-xs text-blue-300 mb-1">Eficiencia</div>
            <div className="text-lg font-bold text-green-400">
              {systemMetrics.systemEfficiency.toFixed(1)}%
            </div>
          </div>
          <div className="bg-black/20 rounded-lg p-3 border border-blue-500/20">
            <div className="text-xs text-blue-300 mb-1">Riesgo</div>
            <div className={`text-lg font-bold ${
              systemMetrics.riskScore < 30 ? 'text-green-400' :
              systemMetrics.riskScore < 70 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {systemMetrics.riskScore.toFixed(1)}
            </div>
          </div>
          <div className="bg-black/20 rounded-lg p-3 border border-blue-500/20">
            <div className="text-xs text-blue-300 mb-1">Éxito</div>
            <div className="text-lg font-bold text-green-400">
              {systemMetrics.successRate.toFixed(1)}%
            </div>
          </div>
          <div className="bg-black/20 rounded-lg p-3 border border-blue-500/20">
            <div className="text-xs text-blue-300 mb-1">Errores</div>
            <div className="text-lg font-bold text-red-400">
              {systemMetrics.errorRate.toFixed(1)}%
            </div>
          </div>
        </div>
      </div>

      {/* Navegación Principal */}
      <div className="p-4">
        <nav className="space-y-2">
          {navigationItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onDashboardChange(item.id as any)}
              className={`w-full text-left p-4 rounded-xl transition-all duration-200 group ${
                activeDashboard === item.id
                  ? `${item.bgColor} ${item.borderColor} border-2 shadow-lg`
                  : 'hover:bg-black/20 border border-transparent'
              }`}
            >
              <div className="flex items-center space-x-3 mb-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl ${
                  activeDashboard === item.id
                    ? `bg-gradient-to-r ${item.color} text-white`
                    : 'bg-black/30 text-blue-300 group-hover:text-blue-200'
                }`}>
                  {item.icon}
                </div>
                <div className="flex-1">
                  <h3 className={`font-semibold ${
                    activeDashboard === item.id ? 'text-white' : 'text-blue-100'
                  }`}>
                    {item.name}
                  </h3>
                  <p className="text-xs text-blue-300 group-hover:text-blue-200">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Métricas del Dashboard */}
              <div className="flex items-center justify-between">
                <div className="text-xs text-blue-300">
                  {item.metrics.label}
                </div>
                <div className="text-right">
                  <div className={`text-sm font-bold ${
                    activeDashboard === item.id ? 'text-white' : 'text-blue-200'
                  }`}>
                    {item.metrics.value}
                  </div>
                  <div className="text-xs text-blue-300">
                    {item.metrics.unit}
                  </div>
                </div>
              </div>

              {/* Indicador de Actividad */}
              {activeDashboard === item.id && (
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                  <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${item.color}`} />
                </div>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Footer del Sidebar */}
      <div className="p-6 border-t border-blue-500/20 mt-auto">
        <div className="text-center">
          <div className="text-xs text-blue-300 mb-2">
            Última actualización
          </div>
          <div className="text-sm font-medium text-white">
            {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    </div>
  );
};
