/**
 * Orquestrador de Slots para ArbitrageX Pro 2025
 * Maneja la renderización dinámica de features por slots
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  getFeaturesBySlot, 
  subscribeToRegistry,
  getAvailableFeatures,
  type Feature 
} from '../../features/registry';

interface SlotOrchestratorProps {
  slot: string;
  className?: string;
  maxItems?: number;
  sortBy?: 'priority' | 'name' | 'category';
  filterBy?: {
    category?: string;
    requiresAuth?: boolean;
    hasRealTimeData?: boolean;
  };
  userPermissions?: {
    roles?: string[];
    accessLevel?: string;
  };
  onFeatureClick?: (feature: Feature) => void;
  children?: (features: Feature[]) => React.ReactNode;
}

export function SlotOrchestrator({
  slot,
  className = '',
  maxItems,
  sortBy = 'priority',
  filterBy,
  userPermissions,
  onFeatureClick,
  children
}: SlotOrchestratorProps) {
  const [features, setFeatures] = useState<Feature[]>([]);
  const [loading, setLoading] = useState(true);

  // Actualizar features cuando cambie el registry
  useEffect(() => {
    const updateFeatures = () => {
      try {
        let slotFeatures = getFeaturesBySlot(slot);
        
        // Aplicar filtros de permisos
        if (userPermissions) {
          slotFeatures = getAvailableFeatures(userPermissions).filter(f => f.slot === slot);
        }
        
        // Aplicar filtros adicionales
        if (filterBy) {
          slotFeatures = slotFeatures.filter(feature => {
            if (filterBy.category && feature.category !== filterBy.category) {
              return false;
            }
            
            if (filterBy.requiresAuth !== undefined && 
                feature.permissions.requiresAuth !== filterBy.requiresAuth) {
              return false;
            }
            
            if (filterBy.hasRealTimeData !== undefined) {
              const hasRealTime = feature.dataDeps.realTimeData && 
                                 feature.dataDeps.realTimeData.length > 0;
              if (hasRealTime !== filterBy.hasRealTimeData) {
                return false;
              }
            }
            
            return true;
          });
        }
        
        setFeatures(slotFeatures);
        setLoading(false);
      } catch (error) {
        console.error(`Error actualizando features para slot ${slot}:`, error);
        setFeatures([]);
        setLoading(false);
      }
    };

    // Actualizar inmediatamente
    updateFeatures();

    // Suscribirse a cambios
    const unsubscribe = subscribeToRegistry(updateFeatures);

    return unsubscribe;
  }, [slot, filterBy, userPermissions]);

  // Procesar y ordenar features
  const processedFeatures = useMemo(() => {
    let sortedFeatures = [...features];

    // Ordenar
    switch (sortBy) {
      case 'priority':
        sortedFeatures.sort((a, b) => 
          (a.placement.priority || 50) - (b.placement.priority || 50)
        );
        break;
      
      case 'name':
        sortedFeatures.sort((a, b) => a.name.localeCompare(b.name));
        break;
      
      case 'category':
        sortedFeatures.sort((a, b) => 
          (a.category || 'other').localeCompare(b.category || 'other')
        );
        break;
    }

    // Limitar cantidad
    if (maxItems && maxItems > 0) {
      sortedFeatures = sortedFeatures.slice(0, maxItems);
    }

    return sortedFeatures;
  }, [features, sortBy, maxItems]);

  const handleFeatureClick = (feature: Feature) => {
    if (onFeatureClick) {
      onFeatureClick(feature);
    } else {
      // Comportamiento por defecto
      if (feature.path) {
        window.location.href = feature.path;
      } else if (feature.component) {
        // Emitir evento personalizado
        window.dispatchEvent(new CustomEvent('navigate-to-feature', {
          detail: { featureId: feature.id, component: feature.component }
        }));
      }
    }
  };

  if (loading) {
    return (
      <div className={`slot-orchestrator loading ${className}`}>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  if (processedFeatures.length === 0) {
    return (
      <div className={`slot-orchestrator empty ${className}`}>
        <p className="text-gray-500 text-sm">
          No hay features disponibles para el slot "{slot}"
        </p>
      </div>
    );
  }

  // Si se proporciona children, usarlo como render prop
  if (children) {
    return (
      <div className={`slot-orchestrator ${className}`} data-slot={slot}>
        {children(processedFeatures)}
      </div>
    );
  }

  // Renderizado por defecto
  return (
    <div className={`slot-orchestrator ${className}`} data-slot={slot}>
      {processedFeatures.map((feature) => (
        <FeatureRenderer
          key={feature.id}
          feature={feature}
          onClick={() => handleFeatureClick(feature)}
        />
      ))}
    </div>
  );
}

// Componente para renderizar una feature individual
interface FeatureRendererProps {
  feature: Feature;
  onClick: () => void;
}

function FeatureRenderer({ feature, onClick }: FeatureRendererProps) {
  const getSizeClass = (size?: string) => {
    const sizeClasses = {
      xs: 'w-16 h-16',
      sm: 'w-24 h-24',
      md: 'w-32 h-32',
      lg: 'w-48 h-48',
      xl: 'w-64 h-64',
      full: 'w-full h-full'
    };
    return sizeClasses[size as keyof typeof sizeClasses] || sizeClasses.md;
  };

  const getCategoryIcon = (category?: string) => {
    const icons = {
      arbitrage: '⚡',
      monitoring: '📊',
      security: '🛡️',
      admin: '⚙️',
      tools: '🔧',
      dashboard: '📄'
    };
    return icons[category as keyof typeof icons] || '📄';
  };

  const hasRealTimeData = feature.dataDeps.realTimeData && 
                         feature.dataDeps.realTimeData.length > 0;

  return (
    <div 
      className={`
        feature-item 
        ${getSizeClass(feature.placement.size)}
        bg-white dark:bg-gray-800 
        rounded-lg shadow-sm hover:shadow-md
        border border-gray-200 dark:border-gray-700
        cursor-pointer transition-all duration-200
        p-3 flex flex-col justify-between
        ${feature.placement.isMainPage ? 'ring-2 ring-blue-500' : ''}
      `}
      onClick={onClick}
      title={feature.description}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-lg">{getCategoryIcon(feature.category)}</span>
            <h3 className="font-medium text-sm text-gray-900 dark:text-gray-100 truncate">
              {feature.name}
            </h3>
          </div>
          
          {feature.description && (
            <p className="text-xs text-gray-600 dark:text-gray-400 line-clamp-2">
              {feature.description}
            </p>
          )}
        </div>
        
        <div className="flex flex-col items-end gap-1">
          {hasRealTimeData && (
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" 
                 title="Datos en tiempo real" />
          )}
          
          {feature.permissions.requiresAuth && (
            <div className="text-xs text-amber-600">🔒</div>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100 dark:border-gray-700">
        <span className="text-xs text-gray-500 dark:text-gray-400 capitalize">
          {feature.category || 'General'}
        </span>
        
        {feature.placement.priority && feature.placement.priority < 30 && (
          <span className="text-xs bg-blue-100 text-blue-800 px-1 rounded">
            Alta
          </span>
        )}
      </div>
    </div>
  );
}

// Hook para usar el orquestrador fácilmente
export function useSlotFeatures(slot: string, options?: {
  maxItems?: number;
  sortBy?: 'priority' | 'name' | 'category';
  filterBy?: {
    category?: string;
    requiresAuth?: boolean;
    hasRealTimeData?: boolean;
  };
  userPermissions?: {
    roles?: string[];
    accessLevel?: string;
  };
}) {
  const [features, setFeatures] = useState<Feature[]>([]);

  useEffect(() => {
    const updateFeatures = () => {
      let slotFeatures = getFeaturesBySlot(slot);
      
      if (options?.userPermissions) {
        slotFeatures = getAvailableFeatures(options.userPermissions)
          .filter(f => f.slot === slot);
      }
      
      if (options?.filterBy) {
        slotFeatures = slotFeatures.filter(feature => {
          if (options.filterBy!.category && feature.category !== options.filterBy!.category) {
            return false;
          }
          
          if (options.filterBy!.requiresAuth !== undefined && 
              feature.permissions.requiresAuth !== options.filterBy!.requiresAuth) {
            return false;
          }
          
          if (options.filterBy!.hasRealTimeData !== undefined) {
            const hasRealTime = feature.dataDeps.realTimeData && 
                               feature.dataDeps.realTimeData.length > 0;
            if (hasRealTime !== options.filterBy!.hasRealTimeData) {
              return false;
            }
          }
          
          return true;
        });
      }

      // Ordenar
      if (options?.sortBy === 'priority') {
        slotFeatures.sort((a, b) => 
          (a.placement.priority || 50) - (b.placement.priority || 50)
        );
      } else if (options?.sortBy === 'name') {
        slotFeatures.sort((a, b) => a.name.localeCompare(b.name));
      } else if (options?.sortBy === 'category') {
        slotFeatures.sort((a, b) => 
          (a.category || 'other').localeCompare(b.category || 'other')
        );
      }

      // Limitar
      if (options?.maxItems && options.maxItems > 0) {
        slotFeatures = slotFeatures.slice(0, options.maxItems);
      }

      setFeatures(slotFeatures);
    };

    updateFeatures();
    return subscribeToRegistry(updateFeatures);
  }, [slot, options]);

  return features;
}
