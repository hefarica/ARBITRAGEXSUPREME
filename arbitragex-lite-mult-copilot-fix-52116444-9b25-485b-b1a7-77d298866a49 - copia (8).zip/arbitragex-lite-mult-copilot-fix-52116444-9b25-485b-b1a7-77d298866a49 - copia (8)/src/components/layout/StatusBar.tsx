import React from 'react';

interface SystemMetrics {
  totalOpportunities: number;
  activeStrategies: number;
  totalProfit: number;
  systemEfficiency: number;
  riskScore: number;
  operationsPerHour: number;
  uptime: number;
  errorRate: number;
  successRate: number;
  reconnectionAttempts: number;
}

interface StatusBarProps {
  systemStatus: 'running' | 'stopped' | 'error' | 'maintenance';
  lastUpdate: Date;
  systemMetrics: SystemMetrics;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  systemStatus,
  lastUpdate,
  systemMetrics
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
        return 'text-green-400';
      case 'stopped':
        return 'text-red-400';
      case 'error':
        return 'text-yellow-400';
      case 'maintenance':
        return 'text-blue-400';
      default:
        return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return '🟢';
      case 'stopped':
        return '🔴';
      case 'error':
        return '🟡';
      case 'maintenance':
        return '🔵';
      default:
        return '⚪';
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-lg border-t border-blue-500/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-12">
          {/* Estado del Sistema */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-lg">{getStatusIcon(systemStatus)}</span>
              <span className={`text-sm font-medium capitalize ${getStatusColor(systemStatus)}`}>
                {systemStatus}
              </span>
            </div>

            {/* Separador */}
            <div className="w-px h-4 bg-blue-500/30" />

            {/* Uptime del Sistema */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-blue-300">Uptime:</span>
              <span className="text-sm font-medium text-white">
                {systemMetrics.uptime.toFixed(1)}%
              </span>
            </div>

            {/* Eficiencia del Sistema */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-blue-300">Eficiencia:</span>
              <span className="text-sm font-medium text-green-400">
                {systemMetrics.systemEfficiency.toFixed(1)}%
              </span>
            </div>

            {/* Tasa de Éxito */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-blue-300">Éxito:</span>
              <span className="text-sm font-medium text-green-400">
                {systemMetrics.successRate.toFixed(1)}%
              </span>
            </div>
          </div>

          {/* Métricas de Rendimiento */}
          <div className="flex items-center space-x-6">
            {/* Oportunidades Activas */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-blue-300">Oportunidades:</span>
              <span className="text-sm font-bold text-white">
                {systemMetrics.totalOpportunities.toLocaleString()}
              </span>
            </div>

            {/* Estrategias Activas */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-blue-300">Estrategias:</span>
              <span className="text-sm font-bold text-yellow-400">
                {systemMetrics.activeStrategies}/41
              </span>
            </div>

            {/* Operaciones por Hora */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-blue-300">Ops/h:</span>
              <span className="text-sm font-bold text-orange-400">
                {systemMetrics.operationsPerHour}
              </span>
            </div>

            {/* Ganancias Totales */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-blue-300">Ganancias:</span>
              <span className="text-sm font-bold text-green-400">
                ${systemMetrics.totalProfit.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Información de Tiempo */}
          <div className="flex items-center space-x-4">
            {/* Última Actualización */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-blue-300">Última actualización:</span>
              <span className="text-sm font-medium text-white">
                {lastUpdate.toLocaleTimeString()}
              </span>
            </div>

            {/* Indicador de Latencia */}
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-xs text-green-400">En tiempo real</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
