"use client"

import { ComponentProps } from "react"
import * as ContextListPrimitive from "@radix-ui/react-context-menu"
import CheckIcon from "lucide-react/dist/esm/icons/check";
import CaretRightIcon from "lucide-react/dist/esm/icons/chevron-right"
import CircleIcon from "lucide-react/dist/esm/icons/circle"

import { cn } from "@/lib/utils"

function ContextList({
  ...props
}: ComponentProps<typeof ContextListPrimitive.Root>) {
  return <ContextListPrimitive.Root data-slot="context-menu" {...props} />
}

function ContextListTrigger({
  ...props
}: ComponentProps<typeof ContextListPrimitive.Trigger>) {
  return (
    <ContextListPrimitive.Trigger data-slot="context-menu-trigger" {...props} />
  )
}

function ContextListGroup({
  ...props
}: ComponentProps<typeof ContextListPrimitive.Group>) {
  return (
    <ContextListPrimitive.Group data-slot="context-menu-group" {...props} />
  )
}

function ContextListPortal({
  ...props
}: ComponentProps<typeof ContextListPrimitive.Portal>) {
  return (
    <ContextListPrimitive.Portal data-slot="context-menu-portal" {...props} />
  )
}

function ContextListSub({
  ...props
}: ComponentProps<typeof ContextListPrimitive.Sub>) {
  return <ContextListPrimitive.Sub data-slot="context-menu-sub" {...props} />
}

function ContextListRadioGroup({
  ...props
}: ComponentProps<typeof ContextListPrimitive.RadioGroup>) {
  return (
    <ContextListPrimitive.RadioGroup
      data-slot="context-menu-radio-group"
      {...props}
    />
  )
}

function ContextListSubTrigger({
  className,
  inset,
  children,
  ...props
}: ComponentProps<typeof ContextListPrimitive.SubTrigger> & {
  inset?: boolean
}) {
  return (
    <ContextListPrimitive.SubTrigger
      data-slot="context-menu-sub-trigger"
      data-inset={inset}
      className={cn(
        "focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground flex cursor-default items-center rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      {children}
      <CaretRightIcon className="ml-auto" />
    </ContextListPrimitive.SubTrigger>
  )
}

function ContextListSubContent({
  className,
  ...props
}: ComponentProps<typeof ContextListPrimitive.SubContent>) {
  return (
    <ContextListPrimitive.SubContent
      data-slot="context-menu-sub-content"
      className={cn(
        "bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 min-w-[8rem] origin-(--radix-context-menu-content-transform-origin) overflow-hidden rounded-md border p-1 shadow-lg",
        className
      )}
      {...props}
    />
  )
}

function ContextListContent({
  className,
  ...props
}: ComponentProps<typeof ContextListPrimitive.Content>) {
  return (
    <ContextListPrimitive.Portal>
      <ContextListPrimitive.Content
        data-slot="context-menu-content"
        className={cn(
          "bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--radix-context-menu-content-available-height) min-w-[8rem] origin-(--radix-context-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md",
          className
        )}
        {...props}
      />
    </ContextListPrimitive.Portal>
  )
}

function ContextListItem({
  className,
  inset,
  variant = "default",
  ...props
}: ComponentProps<typeof ContextListPrimitive.Item> & {
  inset?: boolean
  variant?: "default" | "destructive"
}) {
  return (
    <ContextListPrimitive.Item
      data-slot="context-menu-item"
      data-inset={inset}
      data-variant={variant}
      className={cn(
        "focus:bg-accent focus:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 dark:data-[variant=destructive]:focus:bg-destructive/20 data-[variant=destructive]:focus:text-destructive data-[variant=destructive]:*:[svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    />
  )
}

function ContextListCheckboxItem({
  className,
  children,
  checked,
  ...props
}: ComponentProps<typeof ContextListPrimitive.CheckboxItem>) {
  return (
    <ContextListPrimitive.CheckboxItem
      data-slot="context-menu-checkbox-item"
      className={cn(
        "focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      checked={checked}
      {...props}
    >
      <span className="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center">
        <ContextListPrimitive.ItemIndicator>
          <CheckIcon className="size-4" />
        </ContextListPrimitive.ItemIndicator>
      </span>
      {children}
    </ContextListPrimitive.CheckboxItem>
  )
}

function ContextListRadioItem({
  className,
  children,
  ...props
}: ComponentProps<typeof ContextListPrimitive.RadioItem>) {
  return (
    <ContextListPrimitive.RadioItem
      data-slot="context-menu-radio-item"
      className={cn(
        "focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      <span className="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center">
        <ContextListPrimitive.ItemIndicator>
          <CircleIcon className="size-2 fill-current" />
        </ContextListPrimitive.ItemIndicator>
      </span>
      {children}
    </ContextListPrimitive.RadioItem>
  )
}

function ContextListLabel({
  className,
  inset,
  ...props
}: ComponentProps<typeof ContextListPrimitive.Label> & {
  inset?: boolean
}) {
  return (
    <ContextListPrimitive.Label
      data-slot="context-menu-label"
      data-inset={inset}
      className={cn(
        "text-foreground px-2 py-1.5 text-sm font-medium data-[inset]:pl-8",
        className
      )}
      {...props}
    />
  )
}

function ContextListSeparator({
  className,
  ...props
}: ComponentProps<typeof ContextListPrimitive.Separator>) {
  return (
    <ContextListPrimitive.Separator
      data-slot="context-menu-separator"
      className={cn("bg-border -mx-1 my-1 h-px", className)}
      {...props}
    />
  )
}

function ContextListShortcut({
  className,
  ...props
}: ComponentProps<"span">) {
  return (
    <span
      data-slot="context-menu-shortcut"
      className={cn(
        "text-muted-foreground ml-auto text-xs tracking-widest",
        className
      )}
      {...props}
    />
  )
}

export {
  ContextList,
  ContextListTrigger,
  ContextListContent,
  ContextListItem,
  ContextListCheckboxItem,
  ContextListRadioItem,
  ContextListLabel,
  ContextListSeparator,
  ContextListShortcut,
  ContextListGroup,
  ContextListPortal,
  ContextListSub,
  ContextListSubContent,
  ContextListSubTrigger,
  ContextListRadioGroup,
}
