"use client"

import { ComponentProps } from "react"
import * as DropdownListPrimitive from "@radix-ui/react-dropdown-menu"
import CheckIcon from "lucide-react/dist/esm/icons/check"
import CaretRightIcon from "lucide-react/dist/esm/icons/chevron-right"
import CircleIcon from "lucide-react/dist/esm/icons/circle"

import { cn } from "@/lib/utils"

function DropdownList({
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Root>) {
  return <DropdownListPrimitive.Root data-slot="dropdown-menu" {...props} />
}

function DropdownListPortal({
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Portal>) {
  return (
    <DropdownListPrimitive.Portal data-slot="dropdown-menu-portal" {...props} />
  )
}

function DropdownListTrigger({
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Trigger>) {
  return (
    <DropdownListPrimitive.Trigger
      data-slot="dropdown-menu-trigger"
      {...props}
    />
  )
}

function DropdownListContent({
  className,
  sideOffset = 4,
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Content>) {
  return (
    <DropdownListPrimitive.Portal>
      <DropdownListPrimitive.Content
        data-slot="dropdown-menu-content"
        sideOffset={sideOffset}
        className={cn(
          "bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--radix-dropdown-menu-content-available-height) min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md",
          className
        )}
        {...props}
      />
    </DropdownListPrimitive.Portal>
  )
}

function DropdownListGroup({
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Group>) {
  return (
    <DropdownListPrimitive.Group data-slot="dropdown-menu-group" {...props} />
  )
}

function DropdownListItem({
  className,
  inset,
  variant = "default",
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Item> & {
  inset?: boolean
  variant?: "default" | "destructive"
}) {
  return (
    <DropdownListPrimitive.Item
      data-slot="dropdown-menu-item"
      data-inset={inset}
      data-variant={variant}
      className={cn(
        "focus:bg-accent focus:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 dark:data-[variant=destructive]:focus:bg-destructive/20 data-[variant=destructive]:focus:text-destructive data-[variant=destructive]:*:[svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    />
  )
}

function DropdownListCheckboxItem({
  className,
  children,
  checked,
  ...props
}: ComponentProps<typeof DropdownListPrimitive.CheckboxItem>) {
  return (
    <DropdownListPrimitive.CheckboxItem
      data-slot="dropdown-menu-checkbox-item"
      className={cn(
        "focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      checked={checked}
      {...props}
    >
      <span className="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center">
        <DropdownListPrimitive.ItemIndicator>
          <CheckIcon className="size-4" />
        </DropdownListPrimitive.ItemIndicator>
      </span>
      {children}
    </DropdownListPrimitive.CheckboxItem>
  )
}

function DropdownListRadioGroup({
  ...props
}: ComponentProps<typeof DropdownListPrimitive.RadioGroup>) {
  return (
    <DropdownListPrimitive.RadioGroup
      data-slot="dropdown-menu-radio-group"
      {...props}
    />
  )
}

function DropdownListRadioItem({
  className,
  children,
  ...props
}: ComponentProps<typeof DropdownListPrimitive.RadioItem>) {
  return (
    <DropdownListPrimitive.RadioItem
      data-slot="dropdown-menu-radio-item"
      className={cn(
        "focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      <span className="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center">
        <DropdownListPrimitive.ItemIndicator>
          <CircleIcon className="size-2 fill-current" />
        </DropdownListPrimitive.ItemIndicator>
      </span>
      {children}
    </DropdownListPrimitive.RadioItem>
  )
}

function DropdownListLabel({
  className,
  inset,
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Label> & {
  inset?: boolean
}) {
  return (
    <DropdownListPrimitive.Label
      data-slot="dropdown-menu-label"
      data-inset={inset}
      className={cn(
        "px-2 py-1.5 text-sm font-medium data-[inset]:pl-8",
        className
      )}
      {...props}
    />
  )
}

function DropdownListSeparator({
  className,
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Separator>) {
  return (
    <DropdownListPrimitive.Separator
      data-slot="dropdown-menu-separator"
      className={cn("bg-border -mx-1 my-1 h-px", className)}
      {...props}
    />
  )
}

function DropdownListShortcut({
  className,
  ...props
}: ComponentProps<"span">) {
  return (
    <span
      data-slot="dropdown-menu-shortcut"
      className={cn(
        "text-muted-foreground ml-auto text-xs tracking-widest",
        className
      )}
      {...props}
    />
  )
}

function DropdownListSub({
  ...props
}: ComponentProps<typeof DropdownListPrimitive.Sub>) {
  return <DropdownListPrimitive.Sub data-slot="dropdown-menu-sub" {...props} />
}

function DropdownListSubTrigger({
  className,
  inset,
  children,
  ...props
}: ComponentProps<typeof DropdownListPrimitive.SubTrigger> & {
  inset?: boolean
}) {
  return (
    <DropdownListPrimitive.SubTrigger
      data-slot="dropdown-menu-sub-trigger"
      data-inset={inset}
      className={cn(
        "focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground flex cursor-default items-center rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[inset]:pl-8",
        className
      )}
      {...props}
    >
      {children}
      <CaretRightIcon className="ml-auto size-4" />
    </DropdownListPrimitive.SubTrigger>
  )
}

function DropdownListSubContent({
  className,
  ...props
}: ComponentProps<typeof DropdownListPrimitive.SubContent>) {
  return (
    <DropdownListPrimitive.SubContent
      data-slot="dropdown-menu-sub-content"
      className={cn(
        "bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-hidden rounded-md border p-1 shadow-lg",
        className
      )}
      {...props}
    />
  )
}

export {
  DropdownList,
  DropdownListPortal,
  DropdownListTrigger,
  DropdownListContent,
  DropdownListGroup,
  DropdownListLabel,
  DropdownListItem,
  DropdownListCheckboxItem,
  DropdownListRadioGroup,
  DropdownListRadioItem,
  DropdownListSeparator,
  DropdownListShortcut,
  DropdownListSub,
  DropdownListSubTrigger,
  DropdownListSubContent,
}
