import React, { useEffect, useState } from 'react';

// Interfaces
interface DexInfo {
  id: string;
  name: string;
  enabled: boolean;
  pairCount?: number;
  lastValidated?: number;
  tvl?: number;
  source?: string;
}

interface DexStats {
  totalDexes: number;
  enabledDexes: number;
  disabledDexes: number;
  chains: number;
  lastUpdated: number;
}

// Constantes
const CHAINS = [
  'ethereum', 'bsc', 'polygon', 'avalanche', 'fantom',
  'arbitrum', 'optimism', 'cronos', 'gnosis', 'moonbeam', 'base'
];

const API_BASE = 'http://localhost:8000'; // FastAPI backend

export default function ConfigDexes() {
  const [selectedChain, setSelectedChain] = useState('bsc');
  const [dexes, setDexes] = useState<DexInfo[]>([]);
  const [stats, setStats] = useState<DexStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showOnlyEnabled, setShowOnlyEnabled] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Cargar datos iniciales
  useEffect(() => {
    loadData();
  }, [selectedChain]);

  // Cargar datos de DEX para la blockchain seleccionada
  const loadData = async (chain: string = selectedChain) => {
    setLoading(true);
    setError(null);
    
    try {
      // Cargar lista de DEX
      const dexResponse = await fetch(`${API_BASE}/dexes/list?chain=${chain}&only_enabled=false&include_metrics=true`);
      if (!dexResponse.ok) throw new Error('Error cargando lista de DEX');
      
      const dexData = await dexResponse.json();
      setDexes(dexData.dexes || []);

      // Cargar estadísticas
      const statsResponse = await fetch(`${API_BASE}/dexes/stats?chain=${chain}`);
      if (statsResponse.ok) {
        const statsData = await statsResponse.json();
        setStats(statsData);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido');
      console.error('Error cargando datos:', err);
    } finally {
      setLoading(false);
    }
  };

  // Cambiar estado de un DEX
  const handleToggle = async (dexId: string, enabled: boolean) => {
    try {
      const response = await fetch(`${API_BASE}/dexes/toggle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chain: selectedChain,
          dex_id: dexId,
          enabled: enabled,
          note: `Cambiado manualmente a ${enabled ? 'habilitado' : 'deshabilitado'}`
        })
      });

      if (!response.ok) throw new Error('Error actualizando DEX');
      
      // Recargar datos
      await loadData();
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error actualizando DEX');
      console.error('Error actualizando DEX:', err);
    }
  };

  // Filtrar DEX por búsqueda y estado
  const filteredDexes = dexes.filter(dex => {
    const matchesSearch = dex.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         dex.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = !showOnlyEnabled || dex.enabled;
    return matchesSearch && matchesFilter;
  });

  // Formatear timestamp
  const formatTimestamp = (timestamp?: number) => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp * 1000).toLocaleString('es-ES');
  };

  // Formatear TVL
  const formatTVL = (tvl?: number) => {
    if (!tvl) return 'N/A';
    if (tvl >= 1e9) return `$${(tvl / 1e9).toFixed(2)}B`;
    if (tvl >= 1e6) return `$${(tvl / 1e6).toFixed(2)}M`;
    if (tvl >= 1e3) return `$${(tvl / 1e3).toFixed(2)}K`;
    return `$${tvl.toFixed(2)}`;
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Configuración de DEX
        </h1>
        <p className="text-gray-600">
          Gestiona qué DEX están habilitados para cada blockchain en tus estrategias de arbitraje
        </p>
      </div>

      {/* Estadísticas generales */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow border">
            <div className="text-2xl font-bold text-blue-600">{stats.totalDexes}</div>
            <div className="text-sm text-gray-600">Total DEX</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow border">
            <div className="text-2xl font-bold text-green-600">{stats.enabledDexes}</div>
            <div className="text-sm text-gray-600">Habilitados</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow border">
            <div className="text-2xl font-bold text-red-600">{stats.disabledDexes}</div>
            <div className="text-sm text-gray-600">Deshabilitados</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow border">
            <div className="text-2xl font-bold text-purple-600">{stats.chains}</div>
            <div className="text-sm text-gray-600">Blockchains</div>
          </div>
        </div>
      )}

      {/* Controles principales */}
      <div className="bg-white p-6 rounded-lg shadow border mb-6">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          {/* Selector de blockchain */}
          <div className="flex items-center gap-3">
            <label className="text-sm font-medium text-gray-700">Blockchain:</label>
            <select
              value={selectedChain}
              onChange={(e) => setSelectedChain(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {CHAINS.map(chain => (
                <option key={chain} value={chain}>
                  {chain.charAt(0).toUpperCase() + chain.slice(1)}
                </option>
              ))}
            </select>
          </div>

          {/* Búsqueda */}
          <div className="flex items-center gap-3">
            <input
              type="text"
              placeholder="Buscar DEX..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Filtros */}
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={showOnlyEnabled}
                onChange={(e) => setShowOnlyEnabled(e.target.checked)}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Solo habilitados</span>
            </label>
          </div>

          {/* Botón de recarga */}
          <button
            onClick={() => loadData()}
            disabled={loading}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Cargando...' : 'Recargar'}
          </button>
        </div>
      </div>

      {/* Mensaje de error */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {/* Tabla de DEX */}
      <div className="bg-white rounded-lg shadow border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  DEX
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Estado
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pairs
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  TVL
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Última Validación
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Fuente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredDexes.map((dex) => (
                <tr key={dex.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{dex.name}</div>
                      <div className="text-sm text-gray-500">{dex.id}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      dex.enabled 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {dex.enabled ? 'Habilitado' : 'Deshabilitado'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {dex.pairCount || 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatTVL(dex.tvl)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatTimestamp(dex.lastValidated)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {dex.source || 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => handleToggle(dex.id, !dex.enabled)}
                      className={`px-3 py-1 rounded-md text-xs font-medium ${
                        dex.enabled
                          ? 'bg-red-100 text-red-700 hover:bg-red-200'
                          : 'bg-green-100 text-green-700 hover:bg-green-200'
                      }`}
                    >
                      {dex.enabled ? 'Deshabilitar' : 'Habilitar'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Estado vacío */}
        {filteredDexes.length === 0 && !loading && (
          <div className="text-center py-12">
            <div className="text-gray-500">
              {searchTerm || showOnlyEnabled 
                ? 'No se encontraron DEX que coincidan con los filtros'
                : 'No hay DEX registrados para esta blockchain'
              }
            </div>
          </div>
        )}
      </div>

      {/* Información adicional */}
      <div className="mt-6 text-center text-sm text-gray-500">
        <p>
          Los DEX deshabilitados no serán considerados por las estrategias de arbitraje.
          Los cambios se aplican inmediatamente.
        </p>
        {stats?.lastUpdated && (
          <p className="mt-2">
            Última actualización: {formatTimestamp(stats.lastUpdated)}
          </p>
        )}
      </div>
    </div>
  );
}
