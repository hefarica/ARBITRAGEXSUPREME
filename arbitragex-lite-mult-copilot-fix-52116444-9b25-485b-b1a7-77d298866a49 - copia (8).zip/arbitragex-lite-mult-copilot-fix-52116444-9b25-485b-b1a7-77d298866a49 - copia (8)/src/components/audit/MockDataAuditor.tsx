import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  WarningCircle, 
  CheckCircle, 
  XCircle, 
  MagnifyingGlass, 
  Repeat,
  FileText,
  Database,
  Code,
  Gear
} from 'lucide-react';

export interface MockDataDetection {
  id: string;
  type: 'HARDCODED_DATA' | 'MOCK_API' | 'FAKE_DATABASE' | 'SAMPLE_FILE';
  location: string;
  content: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  realSourceSuggestion: string;
  status: 'DETECTED' | 'FIXED' | 'PENDING';
}

interface MockDataIssue {
  id: string;
  type: 'HARDCODED_DATA' | 'MOCK_API' | 'FAKE_DATABASE' | 'SAMPLE_FILE';
  location: string;
  content: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  realSourceSuggestion: string;
  status: 'DETECTED' | 'FIXED' | 'PENDING';
}

interface AuditResult {
  totalFiles: number;
  scannedFiles: number;
  issuesFound: number;
  criticalIssues: number;
  highIssues: number;
  mediumIssues: number;
  lowIssues: number;
  issues: MockDataIssue[];
}

const MockDataAuditor: React.FC = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [auditResult, setAuditResult] = useState<AuditResult | null>(null);
  const [selectedIssue, setSelectedIssue] = useState<MockDataIssue | null>(null);

  // Simulated mock data patterns for demonstration
  const mockPatterns = [
    /mock/i, /fake/i, /dummy/i, /sample/i, /test/i, /demo/i, /example/i, 
    /placeholder/i, /lorem/i, /ipsum/i, /temp/i, /temporal/i, /prueba/i, 
    /ejemplo/i, /ficticio/i, /simulado/i,
    /test@[\w.]+/i, /demo@[\w.]+/i, /example@[\w.]+/i, /mock@[\w.]+/i,
    /000-000|111-111|123-456|555-555|999-999/,
    /John Doe|Jane Smith|Test User|Demo User|Usuario Prueba/i,
    /123 Main St|Test Address|Sample Street|Fake Avenue/i,
    /\b100\.00\b|\b999\.99\b/, /\b2023-01-01\b/
  ];

  const startAudit = async () => {
    setIsScanning(true);
    setScanProgress(0);
    
    // Simulate scanning process
    const mockIssues: MockDataIssue[] = [
      {
        id: '1',
        type: 'HARDCODED_DATA',
        location: 'src/components/user/UserProfile.tsx:45',
        content: 'const mockUser = { name: "John Doe", email: "test@example.com" }',
        severity: 'CRITICAL',
        realSourceSuggestion: 'Integrar con Active Directory/LDAP para datos reales de usuario',
        status: 'DETECTED'
      },
      {
        id: '2',
        type: 'MOCK_API',
        location: 'src/api/products.ts:23',
        content: 'return { products: mockProductList }',
        severity: 'HIGH',
        realSourceSuggestion: 'Conectar con API del sistema ERP/PIM real',
        status: 'DETECTED'
      },
      {
        id: '3',
        type: 'FAKE_DATABASE',
        location: 'src/data/sample-transactions.json',
        content: 'Archivo completo con transacciones de prueba',
        severity: 'MEDIUM',
        realSourceSuggestion: 'Integrar con base de datos contable real',
        status: 'DETECTED'
      },
      {
        id: '4',
        type: 'SAMPLE_FILE',
        location: 'src/config/demo-settings.ts:12',
        content: 'apiUrl: "http://demo.api.example.com"',
        severity: 'HIGH',
        realSourceSuggestion: 'Configurar URL de API de producción real',
        status: 'DETECTED'
      }
    ];

    // Simulate progress
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 200));
      setScanProgress(i);
    }

    setAuditResult({
      totalFiles: 156,
      scannedFiles: 156,
      issuesFound: mockIssues.length,
      criticalIssues: mockIssues.filter(i => i.severity === 'CRITICAL').length,
      highIssues: mockIssues.filter(i => i.severity === 'HIGH').length,
      mediumIssues: mockIssues.filter(i => i.severity === 'MEDIUM').length,
      lowIssues: mockIssues.filter(i => i.severity === 'LOW').length,
      issues: mockIssues
    });

    setIsScanning(false);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return 'destructive';
      case 'HIGH': return 'destructive';
      case 'MEDIUM': return 'default';
      case 'LOW': return 'secondary';
      default: return 'default';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'HARDCODED_DATA': return <Code className="h-4 w-4" />;
      case 'MOCK_API': return <Gear className="h-4 w-4" />;
      case 'FAKE_DATABASE': return <Database className="h-4 w-4" />;
      case 'SAMPLE_FILE': return <FileText className="h-4 w-4" />;
      default: return <WarningCircle className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Auditor de Datos Mock</h2>
          <p className="text-muted-foreground">
            Detección y remediación de datos ficticios y de prueba
          </p>
        </div>
        <Button 
          onClick={startAudit}
          disabled={isScanning}
          className="flex items-center gap-2"
        >
          {isScanning ? (
            <Repeat className="h-4 w-4 animate-spin" />
          ) : (
            <MagnifyingGlass className="h-4 w-4" />
          )}
          {isScanning ? 'Escaneando...' : 'Iniciar Auditoría'}
        </Button>
      </div>

      {/* Scan Progress */}
      {isScanning && (
        <Card className="p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-medium">Progreso del Escaneo</span>
              <span className="text-sm text-muted-foreground">{scanProgress}%</span>
            </div>
            <Progress value={scanProgress} className="w-full" />
            <p className="text-sm text-muted-foreground">
              Analizando archivos en busca de patrones de datos mock...
            </p>
          </div>
        </Card>
      )}

      {/* Results Summary */}
      {auditResult && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm font-medium">Archivos Escaneados</p>
                <p className="text-2xl font-bold">{auditResult.scannedFiles}</p>
              </div>
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="flex items-center gap-2">
              <WarningCircle className="h-5 w-5 text-destructive" />
              <div>
                <p className="text-sm font-medium">Issues Encontrados</p>
                <p className="text-2xl font-bold text-destructive">{auditResult.issuesFound}</p>
              </div>
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="flex items-center gap-2">
              <XCircle className="h-5 w-5 text-destructive" />
              <div>
                <p className="text-sm font-medium">Críticos</p>
                <p className="text-2xl font-bold text-destructive">{auditResult.criticalIssues}</p>
              </div>
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-profit" />
              <div>
                <p className="text-sm font-medium">Mock Data Ratio</p>
                <p className="text-2xl font-bold text-destructive">
                  {auditResult.issuesFound > 0 ? `${((auditResult.issuesFound / auditResult.scannedFiles) * 100).toFixed(1)}%` : '0%'}
                </p>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Issues List */}
      {auditResult && auditResult.issues.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Issues Detectados</h3>
          
          {auditResult.criticalIssues > 0 && (
            <Alert className="mb-4">
              <WarningCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>TOLERANCIA CERO:</strong> Se detectaron {auditResult.criticalIssues} issues críticos. 
                Estos datos mock deben ser reemplazados inmediatamente con fuentes reales antes de cualquier deploy.
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-3">
            {auditResult.issues.map((issue) => (
              <div
                key={issue.id}
                className="border rounded-lg p-4 hover:bg-muted/50 cursor-pointer transition-colors"
                onClick={() => setSelectedIssue(issue)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(issue.type)}
                      <Badge variant={getSeverityColor(issue.severity)}>
                        {issue.severity}
                      </Badge>
                    </div>
                    
                    <div className="flex-1">
                      <p className="font-medium text-sm">{issue.location}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {issue.content.length > 100 
                          ? `${issue.content.substring(0, 100)}...` 
                          : issue.content
                        }
                      </p>
                      <p className="text-xs text-profit mt-2">
                        <strong>Solución:</strong> {issue.realSourceSuggestion}
                      </p>
                    </div>
                  </div>
                  
                  <Badge variant="outline" className="ml-2">
                    {issue.type.replace('_', ' ')}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Zero Mock Data Policy */}
      <Card className="p-6 border-destructive bg-destructive/5">
        <h3 className="text-lg font-semibold text-destructive mb-4">
          Política Zero Mock Data
        </h3>
        <div className="space-y-2 text-sm">
          <p><strong>OBJETIVO:</strong> Garantizar que NUNCA se despliegue datos ficticios a producción.</p>
          <p><strong>TOLERANCIA:</strong> 0% - Ningún dato mock permitido.</p>
          <p><strong>ACCIÓN REQUERIDA:</strong> Integración inmediata con fuentes reales.</p>
          <p><strong>FUENTES VÁLIDAS:</strong> Active Directory, APIs ERP, sistemas contables, servicios de geocodificación.</p>
        </div>
      </Card>
    </div>
  );
};

export default MockDataAuditor;