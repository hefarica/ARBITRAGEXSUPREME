/**
 * AuditDashboard.tsx - Dashboard de Auditoría Zero-Mock Data
 * Interfaz para ejecutar y visualizar auditorías de datos mock
 * Incluye remediación automática y tracking de progreso
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  WarningCircle, 
  Shield, 
  Database, 
  Lightning, 
  CheckCircle, 
  XCircle, 
  Clock,
  Repeat,
  FileText,
  Download,
  Play,
  Pause
} from 'lucide-react';
import MockDataAuditor from './MockDataAuditor';

interface AuditProgress {
  currentPhase: string;
  totalPhases: number;
  currentPhaseProgress: number;
  overallProgress: number;
  isRunning: boolean;
  startTime?: Date;
  estimatedCompletion?: Date;
}

interface RemediationProgress {
  detectionId: string;
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
  progress: number;
  lastUpdate: Date;
  estimatedCompletion?: Date;
}

export const AuditDashboard: React.FC = () => {
  const [auditor] = useState(() => new MockDataAuditor());
  const [detections, setDetections] = useState<MockDataDetection[]>([]);
  const [auditProgress, setAuditProgress] = useState<AuditProgress>({
    currentPhase: 'Inicializado',
    totalPhases: 6,
    currentPhaseProgress: 0,
    overallProgress: 0,
    isRunning: false
  });
  const [remediationProgress, setRemediationProgress] = useState<RemediationProgress[]>([]);
  const [selectedDetection, setSelectedDetection] = useState<MockDataDetection | null>(null);
  const [isAuditing, setIsAuditing] = useState(false);
  const [lastAuditTime, setLastAuditTime] = useState<Date | null>(null);

  /**
   * Ejecuta auditoría completa del sistema
   */
  const runCompleteAudit = async () => {
    setIsAuditing(true);
    setAuditProgress(prev => ({
      ...prev,
      isRunning: true,
      startTime: new Date(),
      overallProgress: 0
    }));

    try {
      const phases = [
        'Auditando MOAD Panel',
        'Auditando Trading Engines', 
        'Auditando Conexiones Blockchain',
        'Auditando Datos Financieros',
        'Auditando Sistema de Autenticación',
        'Auditando Datos en Tiempo Real'
      ];

      for (let i = 0; i < phases.length; i++) {
        setAuditProgress(prev => ({
          ...prev,
          currentPhase: phases[i],
          currentPhaseProgress: 0,
          overallProgress: (i / phases.length) * 100
        }));

        // Simular progreso de fase
        for (let progress = 0; progress <= 100; progress += 20) {
          setAuditProgress(prev => ({
            ...prev,
            currentPhaseProgress: progress,
            overallProgress: ((i + progress/100) / phases.length) * 100
          }));
          await new Promise(resolve => setTimeout(resolve, 200));
        }
      }

      // Ejecutar auditoría real
      const results = await auditor.startCompleteAudit();
      setDetections(results);
      setLastAuditTime(new Date());

      setAuditProgress(prev => ({
        ...prev,
        isRunning: false,
        overallProgress: 100,
        currentPhase: 'Auditoría Completa'
      }));

    } catch (error) {
      console.error('Error en auditoría:', error);
      setAuditProgress(prev => ({
        ...prev,
        isRunning: false,
        currentPhase: 'Error en Auditoría'
      }));
    } finally {
      setIsAuditing(false);
    }
  };

  /**
   * Obtiene color de badge según severidad
   */
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return 'destructive';
      case 'HIGH': return 'destructive';
      case 'MEDIUM': return 'default';
      case 'LOW': return 'secondary';
      default: return 'default';
    }
  };

  /**
   * Obtiene ícono según severidad
   */
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'HIGH': return <WarningCircle className="h-4 w-4 text-orange-500" />;
      case 'MEDIUM': return <WarningCircle className="h-4 w-4 text-yellow-500" />;
      case 'LOW': return <Clock className="h-4 w-4 text-blue-500" />;
      default: return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
  };

  /**
   * Genera reporte de auditoría para descarga
   */
  const generateAuditReport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      summary: {
        total: detections.length,
        critical: detections.filter(d => d.severity === 'CRITICAL').length,
        high: detections.filter(d => d.severity === 'HIGH').length,
        medium: detections.filter(d => d.severity === 'MEDIUM').length,
        low: detections.filter(d => d.severity === 'LOW').length
      },
      executiveSummary: auditor.getExecutiveSummary(),
      productionReadiness: auditor.isProductionReady(),
      detections: detections
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { 
      type: 'application/json' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-report-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const criticalCount = detections.filter(d => d.severity === 'CRITICAL').length;
  const highCount = detections.filter(d => d.severity === 'HIGH').length;
  const isProductionReady = criticalCount === 0 && highCount === 0;

  return (
    <div className="space-y-6">
      {/* Header de Auditoría */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">🔍 Auditoría Zero-Mock Data</h1>
          <p className="text-muted-foreground">
            Sistema de detección y remediación de datos ficticios - TOLERANCIA CERO
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            onClick={runCompleteAudit}
            disabled={isAuditing}
            className="min-w-[150px]"
          >
            {isAuditing ? (
              <>
                <Repeat className="mr-2 h-4 w-4 animate-spin" />
                Auditando...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Iniciar Auditoría
              </>
            )}
          </Button>
          {detections.length > 0 && (
            <Button variant="outline" onClick={generateAuditReport}>
              <Download className="mr-2 h-4 w-4" />
              Descargar Reporte
            </Button>
          )}
        </div>
      </div>

      {/* Estado de Producción */}
      <Alert variant={isProductionReady ? "default" : "destructive"}>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          <div className="flex items-center justify-between">
            <span>
              <strong>Estado de Producción:</strong> {
                isProductionReady ? 
                "✅ APTO PARA PRODUCCIÓN" : 
                "🚨 NO APTO PARA PRODUCCIÓN"
              }
            </span>
            {!isProductionReady && (
              <Badge variant="destructive">
                {criticalCount + highCount} Issues Bloqueantes
              </Badge>
            )}
          </div>
        </AlertDescription>
      </Alert>

      {/* Progreso de Auditoría */}
      {auditProgress.isRunning && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Repeat className="mr-2 h-5 w-5 animate-spin" />
              Ejecutando Auditoría
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>{auditProgress.currentPhase}</span>
                <span>{Math.round(auditProgress.overallProgress)}%</span>
              </div>
              <Progress value={auditProgress.overallProgress} className="h-2" />
            </div>
            <div className="text-sm text-muted-foreground">
              Fase {Math.ceil(auditProgress.overallProgress / (100 / auditProgress.totalPhases))} de {auditProgress.totalPhases}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Resumen de Detecciones */}
      {detections.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-600 dark:text-red-400 text-sm font-medium">Críticos</p>
                  <p className="text-2xl font-bold text-red-700 dark:text-red-300">
                    {detections.filter(d => d.severity === 'CRITICAL').length}
                  </p>
                </div>
                <XCircle className="h-8 w-8 text-red-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-orange-50 dark:bg-orange-900/10 border-orange-200 dark:border-orange-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-600 dark:text-orange-400 text-sm font-medium">Altos</p>
                  <p className="text-2xl font-bold text-orange-700 dark:text-orange-300">
                    {detections.filter(d => d.severity === 'HIGH').length}
                  </p>
                </div>
                <WarningCircle className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-yellow-50 dark:bg-yellow-900/10 border-yellow-200 dark:border-yellow-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-600 dark:text-yellow-400 text-sm font-medium">Medios</p>
                  <p className="text-2xl font-bold text-yellow-700 dark:text-yellow-300">
                    {detections.filter(d => d.severity === 'MEDIUM').length}
                  </p>
                </div>
                <WarningCircle className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 dark:bg-blue-900/10 border-blue-200 dark:border-blue-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-600 dark:text-blue-400 text-sm font-medium">Bajos</p>
                  <p className="text-2xl font-bold text-blue-700 dark:text-blue-300">
                    {detections.filter(d => d.severity === 'LOW').length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tabs de Detalles */}
      {detections.length > 0 && (
        <Tabs defaultValue="detections" className="space-y-4">
          <TabsList>
            <TabsTrigger value="detections">Detecciones</TabsTrigger>
            <TabsTrigger value="remediation">Plan de Remediación</TabsTrigger>
            <TabsTrigger value="summary">Resumen Ejecutivo</TabsTrigger>
          </TabsList>

          <TabsContent value="detections" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Detecciones de Mock Data</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {detections.map((detection, index) => (
                    <div 
                      key={detection.id}
                      className="border rounded-lg p-4 hover:bg-accent/50 cursor-pointer"
                      onClick={() => setSelectedDetection(detection)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            {getSeverityIcon(detection.severity)}
                            <Badge variant={getSeverityColor(detection.severity) as any}>
                              {detection.severity}
                            </Badge>
                            <Badge variant="outline">
                              {detection.type}
                            </Badge>
                          </div>
                          <h4 className="font-semibold mb-1">
                            {detection.affectedFunctionality}
                          </h4>
                          <p className="text-sm text-muted-foreground mb-2">
                            {detection.content}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            📁 {detection.location}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">
                            {detection.realSourceRequired.estimatedIntegrationTime}h estimadas
                          </p>
                          <Badge variant="secondary" className="mt-1">
                            {detection.realSourceRequired.businessCriticality}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="remediation" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Plan de Remediación</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <Alert variant="destructive">
                    <WarningCircle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>ACCIONES INMEDIATAS REQUERIDAS:</strong>
                      <ul className="mt-2 space-y-1">
                        <li>🚨 Deshabilitar modo automático en MOAD Panel</li>
                        <li>🚨 Bloquear todas las funciones de trading real</li>
                        <li>🚨 Agregar disclaimers masivos de simulación</li>
                        <li>🚨 Restringir acceso solo a desarrolladores</li>
                      </ul>
                    </AlertDescription>
                  </Alert>

                  <div>
                    <h4 className="font-semibold mb-3">Integraciones Críticas por Prioridad</h4>
                    <div className="space-y-3">
                      {detections
                        .filter(d => d.severity === 'CRITICAL')
                        .sort((a, b) => a.realSourceRequired.estimatedIntegrationTime - b.realSourceRequired.estimatedIntegrationTime)
                        .map((detection, index) => (
                          <div key={detection.id} className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium">
                                #{index + 1} - {detection.affectedFunctionality}
                              </span>
                              <Badge variant="destructive">
                                {detection.realSourceRequired.estimatedIntegrationTime}h
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">
                              {detection.realSourceRequired.recommendedSource}
                            </p>
                            <div className="text-xs">
                              <strong>Credenciales necesarias:</strong>
                              <ul className="mt-1 space-y-1">
                                {detection.missingCredentials.requiredForIntegration.slice(0, 3).map((cred, idx) => (
                                  <li key={idx} className="text-muted-foreground">• {cred}</li>
                                ))}
                                {detection.missingCredentials.requiredForIntegration.length > 3 && (
                                  <li className="text-muted-foreground">• ... y {detection.missingCredentials.requiredForIntegration.length - 3} más</li>
                                )}
                              </ul>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="summary" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Resumen Ejecutivo</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="whitespace-pre-wrap text-sm bg-muted p-4 rounded-lg">
                  {auditor.getExecutiveSummary()}
                </pre>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* Modal de Detección Detallada */}
      {selectedDetection && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  {getSeverityIcon(selectedDetection.severity)}
                  <span>{selectedDetection.affectedFunctionality}</span>
                </CardTitle>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setSelectedDetection(null)}
                >
                  ✕
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Información básica */}
              <div>
                <h4 className="font-semibold mb-2">Información General</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Ubicación:</span>
                    <p className="text-muted-foreground">{selectedDetection.location}</p>
                  </div>
                  <div>
                    <span className="font-medium">Tipo:</span>
                    <p className="text-muted-foreground">{selectedDetection.type}</p>
                  </div>
                  <div>
                    <span className="font-medium">Ámbito:</span>
                    <p className="text-muted-foreground">{selectedDetection.scope}</p>
                  </div>
                  <div>
                    <span className="font-medium">Tiempo estimado:</span>
                    <p className="text-muted-foreground">
                      {selectedDetection.realSourceRequired.estimatedIntegrationTime} horas
                    </p>
                  </div>
                </div>
              </div>

              {/* Fuente real requerida */}
              <div>
                <h4 className="font-semibold mb-2">Fuente Real Requerida</h4>
                <p className="text-sm text-muted-foreground mb-2">
                  {selectedDetection.realSourceRequired.recommendedSource}
                </p>
                <div className="flex space-x-2">
                  <Badge>{selectedDetection.realSourceRequired.integrationType}</Badge>
                  <Badge variant="outline">
                    {selectedDetection.realSourceRequired.authenticationNeeded ? 'Auth Requerida' : 'Sin Auth'}
                  </Badge>
                  <Badge variant="secondary">
                    {selectedDetection.realSourceRequired.businessCriticality}
                  </Badge>
                </div>
              </div>

              {/* Credenciales faltantes */}
              <div>
                <h4 className="font-semibold mb-2">Credenciales Faltantes</h4>
                <div className="bg-muted p-3 rounded-lg text-sm">
                  <p className="mb-2">
                    <strong>Responsable:</strong> {selectedDetection.missingCredentials.responsibleTeam}
                  </p>
                  <p className="mb-2">
                    <strong>Contacto:</strong> {selectedDetection.missingCredentials.escalationContact}
                  </p>
                  <p className="mb-2">
                    <strong>Cómo obtener:</strong> {selectedDetection.missingCredentials.whereToObtain}
                  </p>
                  <div>
                    <strong>Credenciales requeridas:</strong>
                    <ul className="mt-1 space-y-1">
                      {selectedDetection.missingCredentials.requiredForIntegration.map((cred, idx) => (
                        <li key={idx} className="text-muted-foreground">• {cred}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Plan de remediación */}
              <div>
                <h4 className="font-semibold mb-2">Plan de Remediación</h4>
                <Tabs defaultValue="immediate" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="immediate">Inmediato</TabsTrigger>
                    <TabsTrigger value="integration">Integración</TabsTrigger>
                    <TabsTrigger value="testing">Testing</TabsTrigger>
                    <TabsTrigger value="success">Criterios</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="immediate" className="mt-4">
                    <ul className="space-y-2 text-sm">
                      {selectedDetection.remediationPlan.immediateActions.map((action, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <span className="text-orange-500">•</span>
                          <span>{action}</span>
                        </li>
                      ))}
                    </ul>
                  </TabsContent>
                  
                  <TabsContent value="integration" className="mt-4">
                    <ul className="space-y-2 text-sm">
                      {selectedDetection.remediationPlan.integrationSteps.map((step, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <span className="text-blue-500">{idx + 1}.</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ul>
                  </TabsContent>
                  
                  <TabsContent value="testing" className="mt-4">
                    <ul className="space-y-2 text-sm">
                      {selectedDetection.remediationPlan.testingRequirements.map((test, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <span className="text-green-500">✓</span>
                          <span>{test}</span>
                        </li>
                      ))}
                    </ul>
                  </TabsContent>
                  
                  <TabsContent value="success" className="mt-4">
                    <ul className="space-y-2 text-sm">
                      {selectedDetection.remediationPlan.successCriteria.map((criteria, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <span className="text-purple-500">🎯</span>
                          <span>{criteria}</span>
                        </li>
                      ))}
                    </ul>
                  </TabsContent>
                </Tabs>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Información de última auditoría */}
      {lastAuditTime && !isAuditing && (
        <div className="text-center text-sm text-muted-foreground">
          Última auditoría: {lastAuditTime.toLocaleString()}
        </div>
      )}
    </div>
  );
};

export default AuditDashboard;