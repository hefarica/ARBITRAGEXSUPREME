import React, { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Terminal, 
  Play, 
  CheckCircle, 
  XCircle, 
  WarningCircle, 
  Download,
  Gear
} from '@phosphor-icons/react'

interface AuditScript {
  id: string
  name: string
  description: string
  category: 'infrastructure' | 'security' | 'performance' | 'compliance'
  script: string
  expectedOutput?: string
  critical: boolean
  timeout: number
}

interface AuditResult {
  scriptId: string
  status: 'running' | 'passed' | 'failed' | 'timeout'
  output: string
  duration: number
  timestamp: number
}

export const AutomatedAuditRunner: React.FC = () => {
  const [results, setResults] = useState<Record<string, AuditResult>>({})
  const [isRunning, setIsRunning] = useState(false)
  const [currentScript, setCurrentScript] = useState<string | null>(null)

  const auditScripts: AuditScript[] = [
    // Infrastructure Scripts
    {
      id: 'backend-health',
      name: 'Backend Services Health Check',
      description: 'Verify all microservices are running and responding',
      category: 'infrastructure',
      script: `
        # Check Arbitrage Engine (Port 4001)
        curl -f http://localhost:4001/api/health || echo "FAIL: Arbitrage Engine"
        
        # Check Risk Manager (Port 4002)
        curl -f http://localhost:4002/api/health || echo "FAIL: Risk Manager"
        
        # Check MEV Protection (Port 4003)
        grpcurl -plaintext localhost:4003 health.Check || echo "FAIL: MEV Protection"
        
        echo "All services health checked"
      `,
      expectedOutput: 'All services health checked',
      critical: true,
      timeout: 30000
    },
    {
      id: 'database-connectivity',
      name: 'Database Connectivity',
      description: 'Verify MongoDB, Redis, and MemGraph connections',
      category: 'infrastructure',
      script: `
        # MongoDB Connection
        mongosh --eval "db.runCommand({ping: 1})" || echo "FAIL: MongoDB"
        
        # Redis Connection
        redis-cli ping || echo "FAIL: Redis"
        
        # Check versions
        mongosh --eval "db.runCommand({serverStatus: 1}).version" | grep "6\\."
        redis-cli info server | grep "redis_version:7\\."
        
        echo "Database connectivity verified"
      `,
      expectedOutput: 'Database connectivity verified',
      critical: true,
      timeout: 15000
    },

    // Performance Scripts
    {
      id: 'latency-benchmarks',
      name: 'Latency Benchmarks',
      description: 'Verify API response times and WebSocket latency',
      category: 'performance',
      script: `
        # API Response Time Test
        curl -w "%{time_total}\\n" -o /dev/null -s http://localhost:4001/api/arbitrage/opportunities
        
        # WebSocket Latency Test
        node -e "
          const WebSocket = require('ws');
          const ws = new WebSocket('ws://localhost:4001/ws');
          const start = Date.now();
          ws.on('open', () => {
            ws.send('ping');
          });
          ws.on('message', () => {
            console.log('WebSocket latency:', Date.now() - start, 'ms');
            process.exit(0);
          });
        "
        
        echo "Latency benchmarks completed"
      `,
      expectedOutput: 'Latency benchmarks completed',
      critical: true,
      timeout: 10000
    },
    {
      id: 'throughput-test',
      name: 'Throughput Testing',
      description: 'Test system throughput under load',
      category: 'performance',
      script: `
        # Load test with curl
        seq 1 100 | xargs -n1 -P10 -I{} curl -s http://localhost:4001/api/health > /dev/null
        
        # Memory usage check
        ps aux | grep node | awk '{sum += $6} END {print "Memory usage:", sum/1024, "MB"}'
        
        echo "Throughput testing completed"
      `,
      expectedOutput: 'Throughput testing completed',
      critical: false,
      timeout: 20000
    },

    // Security Scripts
    {
      id: 'security-scan',
      name: 'Security Vulnerability Scan',
      description: 'Run security audit and vulnerability checks',
      category: 'security',
      script: `
        # NPM Audit
        npm audit --audit-level=moderate
        
        # Check for HTTPS enforcement
        curl -I http://localhost:3000 | grep -i "strict-transport-security" || echo "WARNING: HSTS not found"
        
        # Check JWT configuration
        curl -H "Authorization: Bearer invalid-token" http://localhost:4001/api/protected 2>&1 | grep -i "unauthorized" || echo "WARNING: JWT validation issue"
        
        echo "Security scan completed"
      `,
      expectedOutput: 'Security scan completed',
      critical: true,
      timeout: 30000
    },
    {
      id: 'rate-limiting',
      name: 'Rate Limiting Test',
      description: 'Verify rate limiting is properly configured',
      category: 'security',
      script: `
        # Test rate limiting
        for i in {1..110}; do
          curl -s -o /dev/null -w "%{http_code}\\n" http://localhost:4001/api/health
        done | tail -10 | grep -q "429" && echo "Rate limiting working" || echo "FAIL: Rate limiting not working"
        
        echo "Rate limiting test completed"
      `,
      expectedOutput: 'Rate limiting test completed',
      critical: true,
      timeout: 15000
    },

    // Compliance Scripts
    {
      id: 'arbitrage-strategies',
      name: 'Arbitrage Strategy Verification',
      description: 'Verify all arbitrage strategies are implemented correctly',
      category: 'compliance',
      script: `
        # Check triangular arbitrage
        test -f "./backend/strategies/triangular_arbitrage.py" && echo "✅ Triangular arbitrage found" || echo "❌ Triangular arbitrage missing"
        
        # Check cross-DEX
        test -f "./contracts/PathfinderV5.sol" && echo "✅ PathfinderV5 found" || echo "❌ PathfinderV5 missing"
        
        # Check flash loans
        test -f "./contracts/AaveV3FlashLoan.sol" && echo "✅ Aave V3 flash loan found" || echo "❌ Aave V3 flash loan missing"
        
        echo "Arbitrage strategies verification completed"
      `,
      expectedOutput: 'Arbitrage strategies verification completed',
      critical: true,
      timeout: 5000
    },
    {
      id: 'mev-protection',
      name: 'MEV Protection Verification',
      description: 'Verify MEV protection mechanisms are in place',
      category: 'compliance',
      script: `
        # Check MEV protection service
        test -d "./services/mev-protection" && echo "✅ MEV protection service found" || echo "❌ MEV protection service missing"
        
        # Check Flashbots integration
        grep -r "flashbots" ./services/mev-protection/ && echo "✅ Flashbots integration found" || echo "❌ Flashbots integration missing"
        
        # Check private mempool
        grep -r "private.*mempool" ./services/mev-protection/ && echo "✅ Private mempool found" || echo "❌ Private mempool missing"
        
        echo "MEV protection verification completed"
      `,
      expectedOutput: 'MEV protection verification completed',
      critical: true,
      timeout: 10000
    }
  ]

  const runScript = async (script: AuditScript): Promise<AuditResult> => {
    const startTime = Date.now()
    setCurrentScript(script.id)

    try {
      // Simulate script execution (in real implementation, this would execute the actual script)
      await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 1000))
      
      // Simulate different outcomes based on script type
      const success = Math.random() > 0.1 // 90% success rate for demo
      const duration = Date.now() - startTime

      return {
        scriptId: script.id,
        status: success ? 'passed' : 'failed',
        output: success ? 
          `${script.expectedOutput}\n✅ All checks passed\nExecution time: ${duration}ms` :
          `❌ Script failed with error\nExecution time: ${duration}ms\nError: Mock failure for demo`,
        duration,
        timestamp: Date.now()
      }
    } catch (error) {
      return {
        scriptId: script.id,
        status: 'failed',
        output: `❌ Script execution failed: ${error}`,
        duration: Date.now() - startTime,
        timestamp: Date.now()
      }
    } finally {
      setCurrentScript(null)
    }
  }

  const runAllAudits = async () => {
    setIsRunning(true)
    setResults({})

    for (const script of auditScripts) {
      const result = await runScript(script)
      setResults(prev => ({ ...prev, [script.id]: result }))
    }

    setIsRunning(false)
  }

  const runCategoryAudits = async (category: string) => {
    setIsRunning(true)
    const categoryScripts = auditScripts.filter(s => s.category === category)

    for (const script of categoryScripts) {
      const result = await runScript(script)
      setResults(prev => ({ ...prev, [script.id]: result }))
    }

    setIsRunning(false)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed': return <CheckCircle className="text-green-500" weight="fill" />
      case 'failed': return <XCircle className="text-red-500" weight="fill" />
      case 'running': return <Gear className="text-blue-500 animate-spin" />
      default: return <WarningCircle className="text-gray-500" />
    }
  }

  const getOverallStatus = () => {
    const criticalScripts = auditScripts.filter(s => s.critical)
    const criticalResults = criticalScripts.map(s => results[s.id]).filter(Boolean)
    
    if (criticalResults.length === 0) return 'pending'
    if (criticalResults.every(r => r.status === 'passed')) return 'passed'
    if (criticalResults.some(r => r.status === 'failed')) return 'failed'
    return 'partial'
  }

  const generateReport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      overallStatus: getOverallStatus(),
      results: Object.values(results),
      summary: {
        total: auditScripts.length,
        passed: Object.values(results).filter(r => r.status === 'passed').length,
        failed: Object.values(results).filter(r => r.status === 'failed').length,
        critical: auditScripts.filter(s => s.critical).length
      }
    }

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `audit-execution-report-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const categoryScripts = {
    infrastructure: auditScripts.filter(s => s.category === 'infrastructure'),
    performance: auditScripts.filter(s => s.category === 'performance'),
    security: auditScripts.filter(s => s.category === 'security'),
    compliance: auditScripts.filter(s => s.category === 'compliance')
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Terminal size={32} className="text-primary" />
          <div>
            <h1 className="text-2xl font-bold">Automated Audit Execution</h1>
            <p className="text-muted-foreground">Real-time script execution and validation</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Badge variant={getOverallStatus() === 'passed' ? 'default' : 'destructive'}>
            {getOverallStatus().toUpperCase()}
          </Badge>
          
          <Button onClick={runAllAudits} disabled={isRunning}>
            {isRunning ? (
              <>
                <Gear className="mr-2 animate-spin" size={16} />
                Running...
              </>
            ) : (
              <>
                <Play className="mr-2" size={16} />
                Run All Audits
              </>
            )}
          </Button>

          <Button variant="outline" onClick={generateReport} disabled={Object.keys(results).length === 0}>
            <Download className="mr-2" size={16} />
            Export Report
          </Button>
        </div>
      </div>

      {/* Overall Progress */}
      {isRunning && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Audit Progress</span>
                <span>{Object.keys(results).length} / {auditScripts.length}</span>
              </div>
              <Progress value={(Object.keys(results).length / auditScripts.length) * 100} />
              {currentScript && (
                <p className="text-sm text-muted-foreground">
                  Currently running: {auditScripts.find(s => s.id === currentScript)?.name}
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Results by Category */}
      <Card>
        <CardHeader>
          <CardTitle>Audit Script Execution</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="infrastructure" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="infrastructure">Infrastructure</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
            </TabsList>

            {Object.entries(categoryScripts).map(([category, scripts]) => (
              <TabsContent key={category} value={category}>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium capitalize">{category} Audits</h3>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => runCategoryAudits(category)}
                      disabled={isRunning}
                    >
                      <Play className="mr-2" size={14} />
                      Run {category}
                    </Button>
                  </div>

                  <ScrollArea className="h-[500px]">
                    <div className="space-y-4">
                      {scripts.map((script) => {
                        const result = results[script.id]
                        const status = currentScript === script.id ? 'running' : result?.status || 'pending'

                        return (
                          <Card key={script.id} className="border">
                            <CardHeader className="pb-3">
                              <div className="flex items-center justify-between">
                                <CardTitle className="text-base flex items-center gap-2">
                                  {getStatusIcon(status)}
                                  {script.name}
                                  {script.critical && (
                                    <Badge variant="destructive" className="ml-2">CRITICAL</Badge>
                                  )}
                                </CardTitle>
                                <Badge variant="outline">
                                  {script.timeout / 1000}s timeout
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">{script.description}</p>
                            </CardHeader>
                            
                            <CardContent className="pt-0">
                              {/* Script Content */}
                              <div className="mb-4">
                                <h5 className="font-medium text-sm mb-2">Script:</h5>
                                <pre className="text-xs bg-gray-100 p-3 rounded-md overflow-x-auto">
                                  {script.script.trim()}
                                </pre>
                              </div>

                              {/* Result Output */}
                              {result && (
                                <div className="space-y-2">
                                  <div className="flex justify-between items-center">
                                    <h5 className="font-medium text-sm">Output:</h5>
                                    <span className="text-xs text-muted-foreground">
                                      Duration: {result.duration}ms
                                    </span>
                                  </div>
                                  <pre className={`text-xs p-3 rounded-md overflow-x-auto ${
                                    result.status === 'passed' ? 'bg-green-50 text-green-800' :
                                    result.status === 'failed' ? 'bg-red-50 text-red-800' :
                                    'bg-gray-50 text-gray-800'
                                  }`}>
                                    {result.output}
                                  </pre>
                                </div>
                              )}

                              {/* Status indicator */}
                              {status === 'running' && (
                                <Alert>
                                  <Gear className="h-4 w-4 animate-spin" />
                                  <AlertDescription>
                                    Script is currently executing...
                                  </AlertDescription>
                                </Alert>
                              )}
                            </CardContent>
                          </Card>
                        )
                      })}
                    </div>
                  </ScrollArea>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}