import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Alert, AlertDescription } from '../ui/alert';
import { Progress } from '../ui/progress';
import { Repeat, WarningCircle, CheckCircle, XCircle, Info, LinkSimple } from 'lucide-react';
import { useConfigAudit, ConfigGap } from '../../hooks/useConfigAudit';

const RealTimeGapAuditor: React.FC = () => {
  const {
    gaps,
    isScanning,
    lastScan,
    totalScans,
    healthScore,
    runAudit,
    getGapsByCategory,
    getCriticalCount,
    getCategories
  } = useConfigAudit();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const getCategoryEmoji = (category: string): string => {
    const emojis = {
      'PRICE_FEED': '💰',
      'BLOCKCHAIN_RPC': '⛓️',
      'MEV_PROTECTION': '🛡️',
      'DEFI_PROTOCOL': '🏦',
      'AI_SERVICE': '🤖',
      'NOTIFICATION': '📱',
      'DATABASE': '🗃️',
      'OTHER': '❓'
    };
    return emojis[category] || '❓';
  };

  const getSeverityColor = (severity: string): string => {
    switch (severity) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getSeverityTextColor = (severity: string): string => {
    switch (severity) {
      case 'critical': return 'text-red-600';
      case 'high': return 'text-orange-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };

  const getServiceDocUrl = (service: string): string => {
    // URLs de documentación para cada servicio
    const docUrls: Record<string, string> = {
      'CoinGecko Pro API - Price feeds premium': 'https://www.coingecko.com/en/api/documentation',
      'Ethereum RPC - Mainnet/Goerli/Sepolia': 'https://ethereum.org/en/developers/docs/apis/json-rpc/',
      'Polygon RPC - Matic network': 'https://docs.polygon.technology/docs/develop/network-details/network/',
      'Flashbots Protect - MEV protection': 'https://docs.flashbots.net/flashbots-protect/quick-start',
      'OpenAI GPT-4 API - Trading decisions': 'https://platform.openai.com/docs/api-reference',
      'Aave Protocol API - Flash loans': 'https://docs.aave.com/developers/',
      'Telegram Bot API': 'https://core.telegram.org/bots/api',
      'MongoDB Atlas or local': 'https://docs.mongodb.com/atlas/'
    };
    
    return docUrls[service] || '#';
  };

  const categories = getCategories();
  const filteredGaps = getGapsByCategory(selectedCategory);
  const criticalCount = getCriticalCount();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">🔍 Auditoría de Configuración en Tiempo Real</h2>
          <p className="text-muted-foreground">
            Detecta servicios no configurados que pueden causar huecos de datos • Total de escaneos: {totalScans}
          </p>
        </div>
        <Button 
          onClick={runAudit} 
          disabled={isScanning}
          variant="outline"
          size="sm"
        >
          <Repeat className={`w-4 h-4 mr-2 ${isScanning ? 'animate-spin' : ''}`} />
          {isScanning ? 'Escaneando...' : 'Escanear Ahora'}
        </Button>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              {gaps.length === 0 ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : criticalCount > 0 ? (
                <XCircle className="w-5 h-5 text-red-500" />
              ) : (
                <WarningCircle className="w-5 h-5 text-yellow-500" />
              )}
              <div>
                <p className="text-sm font-medium">Estado General</p>
                <p className="text-2xl font-bold">
                  {gaps.length === 0 ? 'Perfecto' : criticalCount > 0 ? 'Crítico' : 'Atención'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Info className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm font-medium">Huecos Detectados</p>
                <p className="text-2xl font-bold">{gaps.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <WarningCircle className="w-5 h-5 text-red-500" />
              <div>
                <p className="text-sm font-medium">Críticos</p>
                <p className="text-2xl font-bold">{criticalCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div>
              <p className="text-sm font-medium mb-2">Salud del Sistema</p>
              <Progress value={healthScore} className="mb-2" />
              <p className="text-2xl font-bold">{healthScore}%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Funnel */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros de Categoría</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category === 'all' ? '🔍 Todos' : `${getCategoryEmoji(category)} ${category}`}
                {category !== 'all' && (
                  <Badge variant="secondary" className="ml-2">
                    {getGapsByCategory(category).length}
                  </Badge>
                )}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {gaps.length === 0 ? (
        <Alert>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>
            ✅ <strong>Excelente!</strong> No se detectaron huecos de configuración. 
            Todos los servicios DeFi están configurados correctamente.
          </AlertDescription>
        </Alert>
      ) : (
        <div className="space-y-4">
          {filteredGaps.map((gap, index) => (
            <Card key={index} className={`border-l-4 ${criticalCount > 0 ? 'border-l-red-500' : 'border-l-yellow-500'}`}>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg">{getCategoryEmoji(gap.category)}</span>
                        <Badge variant="outline">{gap.category}</Badge>
                        <Badge className={`text-white ${getSeverityColor(gap.severity)}`}>
                          {gap.severity.toUpperCase()}
                        </Badge>
                      </div>
                      
                      {gap.description && (
                        <p className="text-sm text-muted-foreground max-w-2xl">
                          {gap.description}
                        </p>
                      )}
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      asChild
                    >
                      <a 
                        href={getServiceDocUrl(gap.service)} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center"
                      >
                        <LinkSimple className="w-4 h-4 mr-2" />
                        Documentación
                      </a>
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Archivo</p>
                      <p className="font-mono text-sm bg-muted p-2 rounded">{gap.file}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Clave</p>
                      <p className="font-mono text-sm bg-muted p-2 rounded">{gap.key}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Valor Actual</p>
                      <p className="font-mono text-sm bg-red-50 text-red-700 p-2 rounded border border-red-200">
                        {gap.value}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Servicio Requerido</p>
                      <p className="text-sm bg-green-50 text-green-700 p-2 rounded border border-green-200">
                        {gap.service}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Action Plan */}
      {gaps.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>📋 Plan de Acción Inmediato</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {criticalCount > 0 && (
                <div>
                  <h4 className="font-semibold text-red-600 mb-2 flex items-center">
                    <WarningCircle className="w-4 h-4 mr-2" />
                    🚨 CRÍTICO - Configurar AHORA:
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-sm ml-6">
                    {[...new Set(gaps.filter(g => g.severity === 'critical').map(g => g.service))].map(service => (
                      <li key={service} className="text-red-600">{service}</li>
                    ))}
                  </ul>
                </div>
              )}

              {gaps.filter(g => g.severity === 'high').length > 0 && (
                <div>
                  <h4 className="font-semibold text-orange-600 mb-2">⚠️ IMPORTANTE - Configurar esta semana:</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm ml-6">
                    {[...new Set(gaps.filter(g => g.severity === 'high').map(g => g.service))].map(service => (
                      <li key={service} className="text-orange-600">{service}</li>
                    ))}
                  </ul>
                </div>
              )}
              
              <div>
                <h4 className="font-semibold text-green-600 mb-2 flex items-center">
                  <Info className="w-4 h-4 mr-2" />
                  💡 RECOMENDACIÓN:
                </h4>
                <ol className="list-decimal list-inside space-y-1 text-sm ml-6">
                  <li>Configurar servicios críticos primero</li>
                  <li>Obtener API keys de los proveedores</li>
                  <li>Actualizar archivos .env y de configuración</li>
                  <li>Ejecutar esta auditoría nuevamente</li>
                  <li>Verificar que todos los servicios respondan correctamente</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Last Scan Info */}
      {lastScan && (
        <div className="text-sm text-muted-foreground text-center p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center justify-center space-x-4">
            <span>Último escaneo: {lastScan.toLocaleTimeString()}</span>
            <span>•</span>
            <span>Próximo escaneo automático en 2 minutos</span>
            <span>•</span>
            <span className={`font-medium ${gaps.length === 0 ? 'text-green-600' : criticalCount > 0 ? 'text-red-600' : 'text-yellow-600'}`}>
              Sistema {gaps.length === 0 ? 'SALUDABLE' : criticalCount > 0 ? 'REQUIERE ATENCIÓN CRÍTICA' : 'NECESITA MEJORAS'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default RealTimeGapAuditor;