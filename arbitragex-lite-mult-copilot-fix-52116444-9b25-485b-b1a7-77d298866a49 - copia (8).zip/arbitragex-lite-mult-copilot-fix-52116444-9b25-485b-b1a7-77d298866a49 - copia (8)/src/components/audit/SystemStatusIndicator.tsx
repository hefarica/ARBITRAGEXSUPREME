import React from 'react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Card, CardContent } from '@/components/ui/card'
import { useAuditSystem } from '@/hooks/useAuditSystem'
import { 
  Shield, 
  CheckCircle, 
  XCircle, 
  WarningCircle,
  Gear,
  CalendarBlank 
} from '@phosphor-icons/react'

interface SystemStatusIndicatorProps {
  environment: 'test' | 'prod'
  compact?: boolean
  showDetails?: boolean
}

export const SystemStatusIndicator: React.FC<SystemStatusIndicatorProps> = ({ 
  environment, 
  compact = false, 
  showDetails = false 
}) => {
  const { auditState, runFullAudit, isRunning } = useAuditSystem()

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PASS': return 'bg-green-500'
      case 'FAIL': return 'bg-red-500'
      default: return 'bg-yellow-500'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PASS': return <CheckCircle className="text-green-500" weight="fill" size={16} />
      case 'FAIL': return <XCircle className="text-red-500" weight="fill" size={16} />
      default: return <WarningCircle className="text-yellow-500" weight="fill" size={16} />
    }
  }

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${getStatusColor(auditState.overallStatus)}`} />
        <Badge 
          variant={auditState.productionReady ? "default" : "destructive"}
          className="text-xs"
        >
          {auditState.productionReady ? "CERTIFIED" : "NOT READY"}
        </Badge>
        {environment === 'prod' && !auditState.productionReady && (
          <Badge variant="destructive" className="text-xs animate-pulse">
            BLOCKED
          </Badge>
        )}
      </div>
    )
  }

  return (
    <Card className={`${auditState.productionReady ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
      <CardContent className="pt-4">
        <div className="space-y-4">
          {/* Main Status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield size={24} className={auditState.productionReady ? 'text-green-600' : 'text-red-600'} />
              <div>
                <h3 className="font-semibold">System Audit Status</h3>
                <p className="text-sm text-muted-foreground">
                  Production deployment readiness verification
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {getStatusIcon(auditState.overallStatus)}
              <Badge 
                variant={auditState.productionReady ? "default" : "destructive"}
                className="font-medium"
              >
                {auditState.productionReady ? "PRODUCTION READY" : "DEPLOYMENT BLOCKED"}
              </Badge>
            </div>
          </div>

          {/* Critical Alert for Production */}
          {environment === 'prod' && !auditState.productionReady && (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>CRITICAL:</strong> Production deployment is blocked due to {auditState.criticalFailures} critical audit failures. 
                All issues must be resolved before proceeding.
              </AlertDescription>
            </Alert>
          )}

          {/* Detailed Status */}
          {showDetails && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Total Checks</p>
                  <p className="font-semibold">{auditState.totalChecks}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Passed</p>
                  <p className="font-semibold text-green-600">{auditState.passedChecks}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Critical Failures</p>
                  <p className="font-semibold text-red-600">{auditState.criticalFailures}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Last Audit</p>
                  <p className="font-semibold">
                    {auditState.lastAudit ? 
                      new Date(auditState.lastAudit).toLocaleDateString() : 
                      'Never'
                    }
                  </p>
                </div>
              </div>

              {/* Recent Results */}
              {auditState.results.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Recent Results:</h4>
                  <div className="space-y-1">
                    {auditState.results.slice(0, 3).map((result, index) => (
                      <div key={index} className="flex items-center justify-between text-xs">
                        <span className="truncate">{result.component}</span>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(result.status)}
                          <span className={result.status === 'PASS' ? 'text-green-600' : 'text-red-600'}>
                            {result.score}%
                          </span>
                        </div>
                      </div>
                    ))}
                    {auditState.results.length > 3 && (
                      <p className="text-xs text-muted-foreground">
                        +{auditState.results.length - 3} more components
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Action Button */}
              <Button 
                onClick={runFullAudit} 
                disabled={isRunning}
                size="sm"
                variant={auditState.productionReady ? "outline" : "default"}
                className="w-full"
              >
                {isRunning ? (
                  <>
                    <Gear className="mr-2 animate-spin" size={14} />
                    Running Audit...
                  </>
                ) : (
                  <>
                    <Shield className="mr-2" size={14} />
                    {auditState.lastAudit ? 'Re-run Audit' : 'Run Initial Audit'}
                  </>
                )}
              </Button>
            </div>
          )}

          {/* Certification Info */}
          {auditState.productionReady && (
            <div className="border-t pt-3">
              <div className="flex items-center gap-2 text-sm text-green-700">
                <CalendarBlank size={14} />
                <span>Certified for production deployment</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Valid until: {new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toLocaleDateString()}
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}