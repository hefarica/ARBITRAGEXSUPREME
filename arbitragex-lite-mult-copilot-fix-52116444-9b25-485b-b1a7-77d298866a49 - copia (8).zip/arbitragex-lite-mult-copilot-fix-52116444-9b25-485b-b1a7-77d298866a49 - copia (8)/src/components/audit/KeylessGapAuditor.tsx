import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Activity, 
  Database, 
  Cpu, 
  Network, 
  Shield, 
  Zap, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  DollarSign,
  BarChart3,
  Settings,
  Play,
  Pause,
  RotateCcw,
  Eye,
  EyeSlash,
  Wifi,
  WifiOff
} from 'lucide-react';

interface KeylessGapAuditorProps {
  environment?: 'development' | 'production';
}

interface GapEvent {
  id: string;
  timestamp: Date;
  gapScore: number;
  priceGap: number;
  depthGap: number;
  latencyGap: number;
  riskGap: number;
  roiNet: number;
  collisionProb: number;
  status: 'detected' | 'simulated' | 'executed' | 'failed';
  route: string[];
  blockchains: string[];
  estimatedProfit: number;
  gasCost: number;
  mempoolStatus: 'synchronized' | 'desynchronized';
}

interface NodeStatus {
  name: string;
  url: string;
  status: 'connected' | 'disconnected' | 'syncing';
  blockNumber: number;
  gasPrice: number;
  pendingTxs: number;
  lastUpdate: Date;
}

interface GapAuditorConfig {
  rpcLocal: string;
  subgraphUni: string;
  llamaEndpoint: string;
  flashbotsRelay: string;
  anvilForkUrl: string;
  clickhouseUrl: string;
  grafanaUrl: string;
  collectionInterval: number;
  decisionLatency: number;
  minGapScore: number;
  minRoiNet: number;
  maxCollisionProb: number;
}

const DEFAULT_CONFIG: GapAuditorConfig = {
  rpcLocal: 'https://eth-mainnet.g.alchemy.com/v2/demo',
  subgraphUni: 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3',
  llamaEndpoint: 'https://api.llama.fi',
  flashbotsRelay: 'https://relay.flashbots.net',
  anvilForkUrl: 'http://localhost:8548',
  clickhouseUrl: 'http://localhost:8123',
  grafanaUrl: 'http://localhost:3001',
  collectionInterval: 500,
  decisionLatency: 150,
  minGapScore: 75,
  minRoiNet: 0.4,
  maxCollisionProb: 0.25
};

// Función para encontrar puerto disponible del backend
const findBackendPort = async (): Promise<string> => {
  const ports = [3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010];
  
  for (const port of ports) {
    try {
      const response = await fetch(`http://localhost:${port}/health`, {
        method: 'GET',
        signal: AbortSignal.timeout(1000) // Timeout de 1 segundo
      });
      if (response.ok) {
        return port.toString();
      }
    } catch (error) {
      // Puerto no disponible, continuar al siguiente
      continue;
    }
  }
  
  // Si no encuentra ningún puerto, usar el primero como fallback
  return '3002';
};

export default function KeylessGapAuditor({ environment = 'development' }: KeylessGapAuditorProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [config, setConfig] = useState<GapAuditorConfig>(DEFAULT_CONFIG);
  const [events, setEvents] = useState<GapEvent[]>([]);
  const [nodeStatuses, setNodeStatuses] = useState<NodeStatus[]>([]);
  const [currentMetrics, setCurrentMetrics] = useState({
    gapScore: 0,
    priceGap: 0,
    depthGap: 0,
    latencyGap: 0,
    riskGap: 0,
    roiNet: 0,
    collisionProb: 0,
    decisionLatency: 0
  });
  const [showConfig, setShowConfig] = useState(false);
  const [simulationMode, setSimulationMode] = useState(environment === 'development');
  const [backendConnected, setBackendConnected] = useState(false);
  const [backendPort, setBackendPort] = useState<string>('3002');
  const [eventSource, setEventSource] = useState<EventSource | null>(null);

  // Detectar puerto del backend
  useEffect(() => {
    const detectBackendPort = async () => {
      const port = await findBackendPort();
      setBackendPort(port);
      console.log(`🔍 Backend detectado en puerto: ${port}`);
    };

    detectBackendPort();
    const interval = setInterval(detectBackendPort, 10000); // Verificar cada 10 segundos
    return () => clearInterval(interval);
  }, []);

  // Check backend connection
  useEffect(() => {
    const checkBackend = async () => {
      try {
        const response = await fetch(`http://localhost:${backendPort}/health`);
        if (response.ok) {
          setBackendConnected(true);
          console.log(`✅ Backend connected on port ${backendPort}`);
        } else {
          setBackendConnected(false);
          console.log(`❌ Backend not responding on port ${backendPort}`);
        }
      } catch (error) {
        setBackendConnected(false);
        console.log(`❌ Backend connection failed on port ${backendPort}`);
      }
    };

    if (backendPort) {
      checkBackend();
      const interval = setInterval(checkBackend, 5000);
      return () => clearInterval(interval);
    }
  }, [backendPort]);

  // Load initial data from backend
  useEffect(() => {
    if (backendConnected && backendPort) {
      loadInitialData();
    }
  }, [backendConnected, backendPort]);

  const loadInitialData = async () => {
    try {
      const apiBaseUrl = `http://localhost:${backendPort}/api`;
      
      // Load metrics
      const metricsResponse = await fetch(`${apiBaseUrl}/metrics`);
      if (metricsResponse.ok) {
        const metrics = await metricsResponse.json();
        setCurrentMetrics(metrics);
      }

      // Load events
      const eventsResponse = await fetch(`${apiBaseUrl}/events`);
      if (eventsResponse.ok) {
        const eventsData = await eventsResponse.json();
        setEvents(eventsData.map((event: any) => ({
          ...event,
          timestamp: new Date(event.timestamp)
        })));
      }

      // Load node statuses
      const nodesResponse = await fetch(`${apiBaseUrl}/nodes`);
      if (nodesResponse.ok) {
        const nodesData = await nodesResponse.json();
        setNodeStatuses(nodesData.map((node: any) => ({
          ...node,
          lastUpdate: new Date(node.lastUpdate)
        })));
      }

      // Load config
      const configResponse = await fetch(`${apiBaseUrl}/config`);
      if (configResponse.ok) {
        const configData = await configResponse.json();
        setConfig(configData);
      }
    } catch (error) {
      console.error('Error loading initial data:', error);
    }
  };

  // Setup SSE connection for real-time updates
  useEffect(() => {
    if (backendConnected && isRunning && backendPort) {
      const eventSource = new EventSource(`http://localhost:${backendPort}/api/stream`);
      
      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.gapScore !== undefined) {
            // Metrics update
            setCurrentMetrics(data);
          } else if (data.id) {
            // Event update
            setEvents(prev => [{
              ...data,
              timestamp: new Date(data.timestamp)
            }, ...prev.slice(0, 9)]);
          }
        } catch (error) {
          console.error('Error parsing SSE data:', error);
        }
      };

      eventSource.onerror = (error) => {
        console.error('SSE connection error:', error);
        eventSource.close();
      };

      setEventSource(eventSource);

      return () => {
        eventSource.close();
      };
    }
  }, [backendConnected, isRunning, backendPort]);

  const startAuditor = async () => {
    if (simulationMode) {
      // Local simulation mode
      setIsRunning(true);
      setTimeout(() => {
        setEvents(prev => [{
          id: 'startup',
          timestamp: new Date(),
          gapScore: 0,
          priceGap: 0,
          depthGap: 0,
          latencyGap: 0,
          riskGap: 0,
          roiNet: 0,
          collisionProb: 0,
          status: 'detected',
          route: [],
          blockchains: [],
          estimatedProfit: 0,
          gasCost: 0,
          mempoolStatus: 'synchronized'
        }, ...prev.slice(0, 9)]);
      }, 1000);
    } else {
      // Production mode - call backend
      try {
        const response = await fetch(`http://localhost:${backendPort}/api/start`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' }
        });
        
        if (response.ok) {
          setIsRunning(true);
          console.log('✅ Auditor started on backend');
        } else {
          console.error('❌ Failed to start auditor');
        }
      } catch (error) {
        console.error('❌ Error starting auditor:', error);
      }
    }
  };

  const stopAuditor = async () => {
    if (simulationMode) {
      setIsRunning(false);
    } else {
      try {
        const response = await fetch(`http://localhost:${backendPort}/api/stop`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' }
        });
        
        if (response.ok) {
          setIsRunning(false);
          console.log('✅ Auditor stopped on backend');
        } else {
          console.error('❌ Failed to stop auditor');
        }
      } catch (error) {
        console.error('❌ Error stopping auditor:', error);
      }
    }
  };

  const updateConfig = async (newConfig: Partial<GapAuditorConfig>) => {
    if (simulationMode) {
      setConfig(prev => ({ ...prev, ...newConfig }));
    } else {
      try {
        const response = await fetch(`http://localhost:${backendPort}/api/config`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newConfig)
        });
        
        if (response.ok) {
          const result = await response.json();
          setConfig(result.config);
          console.log('✅ Configuration updated');
        } else {
          console.error('❌ Failed to update configuration');
        }
      } catch (error) {
        console.error('❌ Error updating configuration:', error);
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-100 text-green-800';
      case 'disconnected': return 'bg-red-100 text-red-800';
      case 'syncing': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getEventStatusColor = (status: string) => {
    switch (status) {
      case 'detected': return 'bg-blue-100 text-blue-800';
      case 'simulated': return 'bg-yellow-100 text-yellow-800';
      case 'executed': return 'bg-green-100 text-green-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Activity size={32} />
            <div>
              <h1 className="text-2xl font-bold">Real-Time GAP Auditor – Keyless Edition</h1>
              <p className="text-purple-100">
                {simulationMode ? 'Modo Simulación' : 'Modo Producción'} 
                {backendConnected ? ` - Backend Conectado (Puerto ${backendPort})` : ' - Backend Desconectado'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <Cpu size={20} />
                <span className="text-xl font-bold">{currentMetrics.gapScore.toFixed(1)}</span>
              </div>
              <p className="text-sm text-purple-100">GAP Score</p>
            </div>
            
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <DollarSign size={20} />
                <span className="text-xl font-bold">{currentMetrics.roiNet.toFixed(2)}%</span>
              </div>
              <p className="text-sm text-purple-100">ROI Net</p>
            </div>
          </div>
        </div>
        
        {/* Métricas principales */}
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold">{currentMetrics.priceGap.toFixed(2)}%</p>
            <p className="text-sm text-purple-100">Price Gap</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{currentMetrics.depthGap.toFixed(1)}</p>
            <p className="text-sm text-purple-100">Depth Gap</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{currentMetrics.latencyGap.toFixed(0)}ms</p>
            <p className="text-sm text-purple-100">Latency Gap</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{currentMetrics.decisionLatency.toFixed(0)}ms</p>
            <p className="text-sm text-purple-100">Decision Latency</p>
          </div>
        </div>
      </div>

      {/* Backend Status Alert */}
      {!backendConnected && !simulationMode && (
        <Alert>
          <WifiOff size={16} />
          <AlertDescription>
            Backend no conectado en puerto {backendPort}. Cambiando a modo simulación automáticamente.
          </AlertDescription>
        </Alert>
      )}

      {/* Controles */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            onClick={isRunning ? stopAuditor : startAuditor}
            className={isRunning ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
            disabled={!simulationMode && !backendConnected}
          >
            {isRunning ? <Pause size={16} /> : <Play size={16} />}
            {isRunning ? 'Detener Auditor' : 'Iniciar Auditor'}
          </Button>
          
          <Button variant="outline" onClick={() => setShowConfig(!showConfig)}>
            <Settings size={16} />
            Configuración
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => setSimulationMode(!simulationMode)}
            disabled={!backendConnected}
          >
            {simulationMode ? <Eye size={16} /> : <EyeSlash size={16} />}
            {simulationMode ? 'Modo Simulación' : 'Modo Producción'}
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${isRunning ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-sm text-muted-foreground">
            {isRunning ? 'Auditor Activo' : 'Auditor Inactivo'}
          </span>
          {backendConnected && (
            <div className="flex items-center gap-1">
              <Wifi size={12} className="text-green-500" />
              <span className="text-xs text-green-600">Backend {backendPort}</span>
            </div>
          )}
        </div>
      </div>

      <Tabs defaultValue="metrics" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="metrics">Métricas GAP</TabsTrigger>
          <TabsTrigger value="nodes">Nodos Blockchain</TabsTrigger>
          <TabsTrigger value="events">Eventos</TabsTrigger>
          <TabsTrigger value="config">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="metrics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* GAP Score */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity size={20} />
                  GAP Score
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-4xl font-bold text-blue-600">{currentMetrics.gapScore.toFixed(1)}</p>
                    <p className="text-sm text-muted-foreground">Puntuación GAP (0-100)</p>
                  </div>
                  <Progress value={currentMetrics.gapScore} className="h-3" />
                  <div className="flex justify-between text-sm">
                    <span>Bajo</span>
                    <span>Medio</span>
                    <span>Alto</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* ROI Net */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp size={20} />
                  ROI Net
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-4xl font-bold text-green-600">{currentMetrics.roiNet.toFixed(2)}%</p>
                    <p className="text-sm text-muted-foreground">Retorno sobre inversión neto</p>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Mínimo: {config.minRoiNet}%</span>
                    <span>Actual: {currentMetrics.roiNet.toFixed(2)}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Métricas Detalladas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 size={20} />
                  Métricas Detalladas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Price Gap:</span>
                    <Badge variant="outline">{currentMetrics.priceGap.toFixed(2)}%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Depth Gap:</span>
                    <Badge variant="outline">{currentMetrics.depthGap.toFixed(1)}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Latency Gap:</span>
                    <Badge variant="outline">{currentMetrics.latencyGap.toFixed(0)}ms</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Risk Gap:</span>
                    <Badge variant="outline">{currentMetrics.riskGap.toFixed(1)}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Probabilidad de Colisión */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield size={20} />
                  Probabilidad de Colisión
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-4xl font-bold text-orange-600">{(currentMetrics.collisionProb * 100).toFixed(1)}%</p>
                    <p className="text-sm text-muted-foreground">Riesgo de colisión MEV</p>
                  </div>
                  <Progress value={currentMetrics.collisionProb * 100} className="h-3" />
                  <div className="flex justify-between text-sm">
                    <span>Bajo</span>
                    <span>Máximo: {(config.maxCollisionProb * 100).toFixed(0)}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="nodes" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {nodeStatuses.map((node) => (
              <Card key={node.name}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Network size={20} />
                    {node.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Estado:</span>
                      <Badge className={getStatusColor(node.status)}>
                        {node.status}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Bloque:</span>
                      <span className="font-mono">{node.blockNumber.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Gas Price:</span>
                      <span className="font-mono">{node.gasPrice.toFixed(0)} Gwei</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">TXs Pendientes:</span>
                      <span className="font-mono">{node.pendingTxs}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Última Actualización:</span>
                      <span className="text-xs">{node.lastUpdate.toLocaleTimeString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <div className="space-y-4">
            {events.length === 0 ? (
              <Alert>
                <AlertTriangle size={16} />
                <AlertDescription>
                  No hay eventos registrados. Inicia el auditor para comenzar a detectar oportunidades.
                </AlertDescription>
              </Alert>
            ) : (
              events.map((event) => (
                <Card key={event.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Badge className={getEventStatusColor(event.status)}>
                          {event.status}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {event.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">${event.estimatedProfit.toFixed(2)}</p>
                        <p className="text-sm text-muted-foreground">Profit estimado</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">GAP Score:</span>
                        <p className="font-semibold">{event.gapScore.toFixed(1)}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">ROI Net:</span>
                        <p className="font-semibold text-green-600">{event.roiNet.toFixed(2)}%</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Gas Cost:</span>
                        <p className="font-semibold">${event.gasCost.toFixed(2)}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Colisión:</span>
                        <p className="font-semibold">{(event.collisionProb * 100).toFixed(1)}%</p>
                      </div>
                    </div>
                    
                    <div className="mt-3">
                      <span className="text-sm text-muted-foreground">Ruta:</span>
                      <div className="flex gap-2 mt-1">
                        {event.route.map((step, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {step}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="config" className="space-y-6">
          {showConfig && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings size={20} />
                  Configuración del Auditor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-semibold">Configuración de Red</h4>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">RPC Local:</label>
                      <input 
                        type="text" 
                        value={config.rpcLocal}
                        onChange={(e) => updateConfig({ rpcLocal: e.target.value })}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Subgraph Uniswap:</label>
                      <input 
                        type="text" 
                        value={config.subgraphUni}
                        onChange={(e) => updateConfig({ subgraphUni: e.target.value })}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Flashbots Relay:</label>
                      <input 
                        type="text" 
                        value={config.flashbotsRelay}
                        onChange={(e) => updateConfig({ flashbotsRelay: e.target.value })}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-semibold">Configuración de Ejecución</h4>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Intervalo de Recolección (ms):</label>
                      <input 
                        type="number" 
                        value={config.collectionInterval}
                        onChange={(e) => updateConfig({ collectionInterval: parseInt(e.target.value) })}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Latencia de Decisión (ms):</label>
                      <input 
                        type="number" 
                        value={config.decisionLatency}
                        onChange={(e) => updateConfig({ decisionLatency: parseInt(e.target.value) })}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">GAP Score Mínimo:</label>
                      <input 
                        type="number" 
                        value={config.minGapScore}
                        onChange={(e) => updateConfig({ minGapScore: parseInt(e.target.value) })}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">ROI Net Mínimo (%):</label>
                      <input 
                        type="number" 
                        step="0.1"
                        value={config.minRoiNet}
                        onChange={(e) => updateConfig({ minRoiNet: parseFloat(e.target.value) })}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
} 