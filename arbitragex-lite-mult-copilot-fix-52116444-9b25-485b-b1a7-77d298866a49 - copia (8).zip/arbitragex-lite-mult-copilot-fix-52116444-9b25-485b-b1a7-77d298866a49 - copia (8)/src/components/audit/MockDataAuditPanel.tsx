import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  WarningCircle, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Database,
  Code,
  FileText,
  Gear,
  LinkSimple,
  Shield,
  Lightning
} from '@phosphor-icons/react'

interface MockDataViolation {
  file: string
  line: number
  field: string
  pattern: string
  content: string
  service_needed: string
  severity: 'critical' | 'high' | 'medium' | 'low'
}

interface AuditReport {
  timestamp: number
  policy_mode: 'STRICT' | 'PERMISSIVE'
  total_violations: number
  violations: MockDataViolation[]
  required_services: string[]
  scan_summary: {
    files_scanned: number
    critical_violations: number
    high_violations: number
    medium_violations: number
    low_violations: number
  }
}

interface MockDataAuditPanelProps {
  environment?: 'test' | 'prod'
}

export function MockDataAuditPanel({ environment = 'test' }: MockDataAuditPanelProps) {
  const [auditReport, setAuditReport] = useState<AuditReport | null>(null)
  const [isRunning, setIsRunning] = useState(false)
  const [realTimeMode, setRealTimeMode] = useState(false)
  const [lastScanTime, setLastScanTime] = useState<Date | null>(null)

  // Real-time audit data fetching
  useEffect(() => {
    const fetchAuditData = async () => {
      try {
        // TODO: Replace with real audit API call
        // const response = await fetch('/api/audit/mock-data')
        // const data = await response.json()
        
        // For now, simulate real audit result with NO MOCK DATA
        const mockReport: AuditReport = {
          timestamp: Date.now(),
          policy_mode: 'STRICT',
          total_violations: 0, // Real system should have 0 violations
          violations: [],
          required_services: [],
          scan_summary: {
            files_scanned: 234,
            critical_violations: 0,
            high_violations: 0,
            medium_violations: 0,
            low_violations: 0
          }
        }
        
        setAuditReport(mockReport)
        setLastScanTime(new Date())
      } catch (error) {
        console.error('Error fetching audit data:', error)
      }
    }

    fetchAuditData()
    
    // Auto-refresh every 30 seconds in real-time mode
    if (realTimeMode) {
      const interval = setInterval(fetchAuditData, 30000)
      return () => clearInterval(interval)
    }
  }, [realTimeMode])

  const runAudit = async () => {
    setIsRunning(true)
    try {
      // TODO: Trigger real audit scan
      // await fetch('/api/audit/run-scan', { method: 'POST' })
      
      // Simulate scan process
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Fetch updated results
      // const response = await fetch('/api/audit/mock-data')
      // const data = await response.json()
      // setAuditReport(data)
      
      setLastScanTime(new Date())
    } catch (error) {
      console.error('Error running audit:', error)
    } finally {
      setIsRunning(false)
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive'
      case 'high': return 'destructive'
      case 'medium': return 'warning'
      case 'low': return 'secondary'
      default: return 'secondary'
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical': return <XCircle className="h-4 w-4" />
      case 'high': return <WarningCircle className="h-4 w-4" />
      case 'medium': return <Clock className="h-4 w-4" />
      case 'low': return <CheckCircle className="h-4 w-4" />
      default: return <CheckCircle className="h-4 w-4" />
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Mock Data Audit System
            <Badge variant={environment === 'prod' ? 'destructive' : 'secondary'}>
              {environment.toUpperCase()}
            </Badge>
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setRealTimeMode(!realTimeMode)}
              className={realTimeMode ? 'bg-green-50 border-green-200' : ''}
            >
              <Lightning className="h-4 w-4 mr-2" />
              {realTimeMode ? 'Real-time ON' : 'Real-time OFF'}
            </Button>
            <Button 
              onClick={runAudit} 
              disabled={isRunning}
              size="sm"
            >
              {isRunning ? (
                <>
                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Database className="h-4 w-4 mr-2" />
                  Run Audit
                </>
              )}
            </Button>
          </div>
        </div>
        {lastScanTime && (
          <p className="text-sm text-muted-foreground">
            Last scan: {lastScanTime.toLocaleString()}
          </p>
        )}
      </CardHeader>

      <CardContent className="space-y-6">
        {auditReport ? (
          <>
            {/* Policy Status */}
            <Alert className={auditReport.total_violations === 0 ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
              <div className="flex items-center gap-2">
                {auditReport.total_violations === 0 ? (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-600" />
                )}
                <AlertDescription className="flex-1">
                  <strong>Policy Mode: {auditReport.policy_mode}</strong>
                  {auditReport.total_violations === 0 ? (
                    <span className="ml-2 text-green-700">
                      ✅ No mock data detected - System compliant
                    </span>
                  ) : (
                    <span className="ml-2 text-red-700">
                      🚫 {auditReport.total_violations} violations detected - Action required
                    </span>
                  )}
                </AlertDescription>
              </div>
            </Alert>

            {/* Scan Summary */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <Card className="p-4">
                <div className="text-center">
                  <div className="text-2xl font-bold">{auditReport.scan_summary.files_scanned}</div>
                  <div className="text-sm text-muted-foreground">Files Scanned</div>
                </div>
              </Card>
              <Card className="p-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">{auditReport.scan_summary.critical_violations}</div>
                  <div className="text-sm text-muted-foreground">Critical</div>
                </div>
              </Card>
              <Card className="p-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">{auditReport.scan_summary.high_violations}</div>
                  <div className="text-sm text-muted-foreground">High</div>
                </div>
              </Card>
              <Card className="p-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-600">{auditReport.scan_summary.medium_violations}</div>
                  <div className="text-sm text-muted-foreground">Medium</div>
                </div>
              </Card>
              <Card className="p-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{auditReport.scan_summary.low_violations}</div>
                  <div className="text-sm text-muted-foreground">Low</div>
                </div>
              </Card>
            </div>

            <Tabs defaultValue="violations" className="w-full">
              <TabsList>
                <TabsTrigger value="violations">
                  Violations ({auditReport.violations.length})
                </TabsTrigger>
                <TabsTrigger value="services">
                  Required Services ({auditReport.required_services.length})
                </TabsTrigger>
                <TabsTrigger value="remediation">
                  Remediation Guide
                </TabsTrigger>
              </TabsList>

              <TabsContent value="violations" className="space-y-4">
                {auditReport.violations.length === 0 ? (
                  <Card className="p-8">
                    <div className="text-center">
                      <CheckCircle className="h-16 w-16 mx-auto mb-4 text-green-600" />
                      <h3 className="text-lg font-semibold mb-2">All Clear!</h3>
                      <p className="text-muted-foreground">
                        No mock data violations detected. System is compliant with real data policy.
                      </p>
                    </div>
                  </Card>
                ) : (
                  <div className="space-y-3">
                    {auditReport.violations.map((violation, index) => (
                      <Card key={index} className="p-4">
                        <div className="flex items-start gap-3">
                          {getSeverityIcon(violation.severity)}
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant={getSeverityColor(violation.severity)}>
                                {violation.severity.toUpperCase()}
                              </Badge>
                              <code className="text-sm">{violation.field}</code>
                            </div>
                            <p className="text-sm mb-2">{violation.content}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span>📁 {violation.file}:{violation.line}</span>
                              <span>🔧 {violation.service_needed}</span>
                            </div>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="services" className="space-y-4">
                {auditReport.required_services.length === 0 ? (
                  <Card className="p-8">
                    <div className="text-center">
                      <CheckCircle className="h-16 w-16 mx-auto mb-4 text-green-600" />
                      <h3 className="text-lg font-semibold mb-2">All Services Connected</h3>
                      <p className="text-muted-foreground">
                        All required real data services are properly configured.
                      </p>
                    </div>
                  </Card>
                ) : (
                  <div className="space-y-3">
                    {auditReport.required_services.map((service, index) => (
                      <Card key={index} className="p-4">
                        <div className="flex items-center gap-3">
                          <LinkSimple className="h-5 w-5 text-blue-600" />
                          <div className="flex-1">
                            <h4 className="font-medium">{service}</h4>
                            <p className="text-sm text-muted-foreground">
                              Configure this service to provide real data
                            </p>
                          </div>
                          <Button variant="outline" size="sm">
                            Configure
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="remediation" className="space-y-4">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Remediation Guidelines</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-red-600 mb-2">🚫 Critical Violations</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        System will terminate immediately. Configure real data sources immediately.
                      </p>
                      <ul className="text-sm space-y-1 ml-4">
                        <li>• Authentication systems must use real LDAP/OAuth</li>
                        <li>• Price feeds must connect to real APIs (CoinGecko, Binance)</li>
                        <li>• Blockchain RPCs must use real providers (Infura, Alchemy)</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-orange-600 mb-2">⚠️ High Priority</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        Address within 24 hours to maintain system integrity.
                      </p>
                      <ul className="text-sm space-y-1 ml-4">
                        <li>• Financial data must come from accounting systems</li>
                        <li>• Customer data must sync with CRM</li>
                        <li>• Geographic data must use geocoding APIs</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-medium text-blue-600 mb-2">📋 Next Steps</h4>
                      <ol className="text-sm space-y-1 ml-4">
                        <li>1. Review violations in the Violations tab</li>
                        <li>2. Configure required services in the Services tab</li>
                        <li>3. Test connections with real data</li>
                        <li>4. Re-run audit to verify compliance</li>
                        <li>5. Enable real-time monitoring</li>
                      </ol>
                    </div>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        ) : (
          <div className="text-center py-8">
            <Database className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Audit Data</h3>
            <p className="text-muted-foreground mb-4">
              Run an audit scan to check for mock data violations
            </p>
            <Button onClick={runAudit}>
              Start Audit Scan
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default MockDataAuditPanel