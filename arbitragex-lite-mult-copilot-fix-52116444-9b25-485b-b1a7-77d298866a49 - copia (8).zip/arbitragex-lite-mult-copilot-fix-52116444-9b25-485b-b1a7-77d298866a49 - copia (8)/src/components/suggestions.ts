// Suggestions for the user about the MOAD system
export const moadSuggestions = [
  "Configura tu primera estrategia de arbitraje",
  "Explora las 11 estrategias DeFi disponibles", 
  "Activa el modo automático para trading 24/7"
]