import { useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { useSimulation } from '../simulation/SimulationProvider'

interface ProfitDataPoint {
  period: string
  profit: number
  loss: number
  net: number
  trades: number
}

export function ProfitLossChart() {
  const { state } = useSimulation()

  const profitLossData = useMemo(() => {
    if (state.trades.length === 0) return []

    // Group trades by day
    const dailyData = new Map<string, { profit: number; loss: number; trades: number }>()
    
    state.trades.forEach(trade => {
      const date = new Date(trade.timestamp)
      const dateKey = date.toISOString().split('T')[0] // YYYY-MM-DD format
      const netPnL = trade.profit - trade.fees
      
      if (!dailyData.has(dateKey)) {
        dailyData.set(dateKey, { profit: 0, loss: 0, trades: 0 })
      }
      
      const dayData = dailyData.get(dateKey)!
      dayData.trades++
      
      if (netPnL > 0) {
        dayData.profit += netPnL
      } else {
        dayData.loss += Math.abs(netPnL)
      }
    })

    // Convert to array and format
    const result: ProfitDataPoint[] = Array.from(dailyData.entries())
      .map(([date, data]) => ({
        period: new Date(date).toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric' 
        }),
        profit: data.profit,
        loss: data.loss,
        net: data.profit - data.loss,
        trades: data.trades
      }))
      .sort((a, b) => new Date(a.period).getTime() - new Date(b.period).getTime())
      .slice(-14) // Last 14 days

    return result
  }, [state.trades])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(Math.abs(value))
  }

  const formatTooltipValue = (value: number, name: string) => {
    const formatted = formatCurrency(value)
    if (name === 'profit') return [formatted, 'Profit']
    if (name === 'loss') return [formatted, 'Loss']
    if (name === 'net') return [formatCurrency(value), 'Net P&L']
    return [value, name]
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="font-medium mb-2">{label}</p>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between gap-4">
              <span className="text-profit">Profit:</span>
              <span className="font-medium">{formatCurrency(data.profit)}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-destructive">Loss:</span>
              <span className="font-medium">{formatCurrency(data.loss)}</span>
            </div>
            <div className="flex justify-between gap-4 border-t border-border pt-1">
              <span className={data.net >= 0 ? 'text-profit' : 'text-destructive'}>Net:</span>
              <span className="font-medium">{formatCurrency(data.net)}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Trades:</span>
              <span className="font-medium">{data.trades}</span>
            </div>
          </div>
        </div>
      )
    }
    return null
  }

  if (profitLossData.length === 0) {
    return (
      <div className="h-80 flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <p className="text-lg font-medium">No trading data yet</p>
          <p className="text-sm">Execute some trades to see profit/loss analysis</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={profitLossData}
          margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
        >
          <CartesianGrid 
            strokeDasharray="3 3" 
            stroke="hsl(var(--border))"
            opacity={0.3}
          />
          
          <XAxis 
            dataKey="period"
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
          />
          
          <YAxis 
            tickFormatter={formatCurrency}
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
          />
          
          <Tooltip content={<CustomTooltip />} />
          
          <Bar dataKey="profit" fill="hsl(var(--profit))" radius={[2, 2, 0, 0]} />
          <Bar dataKey="loss" fill="hsl(var(--destructive))" radius={[2, 2, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}