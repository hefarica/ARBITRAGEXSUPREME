import { useEffect, useRef, useMemo } from 'react'
import * as d3 from 'd3'
import { useSimulation } from '../simulation/SimulationProvider'

interface RiskDataPoint {
  date: Date
  value: number
  drawdown: number
  volatility: number
}

export function RiskMetricsChart() {
  const svgRef = useRef<SVGSVGElement>(null)
  const { state } = useSimulation()

  const riskData = useMemo(() => {
    if (state.trades.length < 2) return []

    let runningBalance = 10000
    let maxBalance = 10000
    const returns: number[] = []
    
    const data: RiskDataPoint[] = []

    // Sort trades chronologically
    const sortedTrades = Array.from(state.trades).reverse()

    sortedTrades.forEach((trade, index) => {
      const netPnL = trade.profit - trade.fees
      const previousBalance = runningBalance
      runningBalance += netPnL
      
      // Calculate return
      const returnPct = netPnL / previousBalance
      returns.push(returnPct)
      
      // Track max balance for drawdown calculation
      if (runningBalance > maxBalance) {
        maxBalance = runningBalance
      }
      
      // Calculate drawdown
      const drawdown = (maxBalance - runningBalance) / maxBalance
      
      // Calculate rolling volatility (last 10 trades)
      const recentReturns = returns.slice(Math.max(0, returns.length - 10))
      const meanReturn = recentReturns.reduce((sum, r) => sum + r, 0) / recentReturns.length
      const variance = recentReturns.reduce((sum, r) => sum + Math.pow(r - meanReturn, 2), 0) / recentReturns.length
      const volatility = Math.sqrt(variance) * Math.sqrt(252) // Annualized volatility
      
      data.push({
        date: new Date(trade.timestamp),
        value: runningBalance,
        drawdown: drawdown,
        volatility: volatility
      })
    })

    return data
  }, [state.trades])

  useEffect(() => {
    if (!svgRef.current || riskData.length === 0) return

    const svg = d3.select(svgRef.current)
    svg.selectAll("*").remove()

    const margin = { top: 20, right: 60, bottom: 40, left: 60 }
    const width = 600 - margin.left - margin.right
    const height = 320 - margin.bottom - margin.top

    const container = svg
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)

    const g = container
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`)

    // Scales
    const xScale = d3.scaleTime()
      .domain(d3.extent(riskData, d => d.date) as [Date, Date])
      .range([0, width])

    const yScale = d3.scaleLinear()
      .domain(d3.extent(riskData, d => d.value) as [number, number])
      .range([height, 0])

    const drawdownScale = d3.scaleLinear()
      .domain([0, d3.max(riskData, d => d.drawdown) || 0.1])
      .range([height, height * 0.7])

    // Create line generators
    const valueLine = d3.line<RiskDataPoint>()
      .x(d => xScale(d.date))
      .y(d => yScale(d.value))
      .curve(d3.curveMonotoneX)

    const drawdownArea = d3.area<RiskDataPoint>()
      .x(d => xScale(d.date))
      .y0(height)
      .y1(d => drawdownScale(d.drawdown))
      .curve(d3.curveMonotoneX)

    // Add grid
    g.append("g")
      .attr("class", "grid")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(xScale)
        .tickSize(-height)
        .tickFormat(() => "")
      )
      .style("stroke-dasharray", "3,3")
      .style("opacity", 0.3)
      .style("stroke", "hsl(var(--border))")

    g.append("g")
      .attr("class", "grid")
      .call(d3.axisLeft(yScale)
        .tickSize(-width)
        .tickFormat(() => "")
      )
      .style("stroke-dasharray", "3,3")
      .style("opacity", 0.3)
      .style("stroke", "hsl(var(--border))")

    // Add drawdown area
    g.append("path")
      .datum(riskData)
      .attr("fill", "hsl(var(--destructive))")
      .attr("fill-opacity", 0.2)
      .attr("d", drawdownArea)

    // Add portfolio value line
    g.append("path")
      .datum(riskData)
      .attr("fill", "none")
      .attr("stroke", "hsl(var(--primary))")
      .attr("stroke-width", 2)
      .attr("d", valueLine)

    // Add axes
    g.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(xScale)
        .tickFormat(d3.timeFormat("%m/%d"))
      )
      .style("color", "hsl(var(--muted-foreground))")

    g.append("g")
      .call(d3.axisLeft(yScale)
        .tickFormat(d3.format("$,.0f"))
      )
      .style("color", "hsl(var(--muted-foreground))")

    // Add right axis for drawdown
    g.append("g")
      .attr("transform", `translate(${width},0)`)
      .call(d3.axisRight(drawdownScale)
        .tickFormat(d3.format(".1%"))
      )
      .style("color", "hsl(var(--destructive))")

    // Add labels
    g.append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 0 - margin.left)
      .attr("x", 0 - (height / 2))
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .style("fill", "hsl(var(--muted-foreground))")
      .style("font-size", "12px")
      .text("Portfolio Value ($)")

    g.append("text")
      .attr("transform", `rotate(-90) translate(${-height/2}, ${width + margin.right - 10})`)
      .style("text-anchor", "middle")
      .style("fill", "hsl(var(--destructive))")
      .style("font-size", "12px")
      .text("Drawdown (%)")

    // Add hover tooltip
    const focus = g.append("g")
      .attr("class", "focus")
      .style("display", "none")

    focus.append("circle")
      .attr("r", 4)
      .style("fill", "hsl(var(--primary))")
      .style("stroke", "hsl(var(--background))")
      .style("stroke-width", 2)

    const tooltip = focus.append("g")
      .attr("class", "tooltip")

    const tooltipRect = tooltip.append("rect")
      .attr("width", 120)
      .attr("height", 60)
      .attr("fill", "hsl(var(--card))")
      .attr("stroke", "hsl(var(--border))")
      .attr("rx", 4)

    const tooltipText = tooltip.append("text")
      .attr("x", 8)
      .attr("y", 15)
      .style("font-size", "12px")
      .style("fill", "hsl(var(--foreground))")

    g.append("rect")
      .attr("class", "overlay")
      .attr("width", width)
      .attr("height", height)
      .style("fill", "none")
      .style("pointer-events", "all")
      .on("mouseover", () => focus.style("display", null))
      .on("mouseout", () => focus.style("display", "none"))
      .on("mousemove", function(event) {
        const [mouseX] = d3.pointer(event)
        const date = xScale.invert(mouseX)
        
        // Find closest data point
        const bisectDate = d3.bisector((d: RiskDataPoint) => d.date).left
        const i = bisectDate(riskData, date, 1)
        const d0 = riskData[i - 1]
        const d1 = riskData[i]
        const d = d1 && (date.getTime() - d0.date.getTime() > d1.date.getTime() - date.getTime()) ? d1 : d0

        if (d) {
          focus.attr("transform", `translate(${xScale(d.date)},${yScale(d.value)})`)
          
          tooltipText.selectAll("tspan").remove()
          
          tooltipText.append("tspan")
            .attr("x", 8)
            .attr("dy", "0")
            .text(`Value: $${d.value.toLocaleString()}`)
          
          tooltipText.append("tspan")
            .attr("x", 8)
            .attr("dy", "14")
            .text(`Drawdown: ${(d.drawdown * 100).toFixed(1)}%`)
          
          tooltipText.append("tspan")
            .attr("x", 8)
            .attr("dy", "14")
            .text(`Volatility: ${(d.volatility * 100).toFixed(1)}%`)

          // Position tooltip
          const tooltipX = mouseX > width - 130 ? mouseX - 130 : mouseX + 10
          const tooltipY = yScale(d.value) > 70 ? yScale(d.value) - 70 : yScale(d.value) + 10
          tooltip.attr("transform", `translate(${tooltipX - xScale(d.date)},${tooltipY - yScale(d.value)})`)
        }
      })

  }, [riskData])

  if (riskData.length === 0) {
    return (
      <div className="h-80 flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <p className="text-lg font-medium">Insufficient data for risk analysis</p>
          <p className="text-sm">Execute more trades to see risk metrics</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-80 w-full">
      <svg ref={svgRef} className="w-full h-full" />
    </div>
  )
}