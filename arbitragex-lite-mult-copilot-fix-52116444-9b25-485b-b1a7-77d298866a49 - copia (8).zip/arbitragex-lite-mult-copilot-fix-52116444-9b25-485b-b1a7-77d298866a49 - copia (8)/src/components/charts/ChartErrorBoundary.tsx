import React from 'react'
import { ErrorBoundary } from 'react-error-boundary'
import { WarningCircle } from 'lucide-react'
import { Button } from '../ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'

interface ChartErrorFallbackProps {
  error: Error
  resetErrorBoundary: () => void
}

const ChartErrorFallback: React.FC<ChartErrorFallbackProps> = ({ error, resetErrorBoundary }) => {
  return (
    <Card className="border-destructive">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-destructive">
          <WarningCircle size={20} />
          Chart Error
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          There was an error loading this chart component.
        </p>
        <details className="text-xs">
          <summary className="cursor-pointer font-medium">Error Details</summary>
          <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-auto">
            {error.message}
          </pre>
        </details>
        <Button onClick={resetErrorBoundary} variant="outline" size="sm">
          Try Again
        </Button>
      </CardContent>
    </Card>
  )
}

interface ChartErrorBoundaryProps {
  children: React.ReactNode
  fallback?: React.ComponentType<ChartErrorFallbackProps>
}

export const ChartErrorBoundary: React.FC<ChartErrorBoundaryProps> = ({ 
  children, 
  fallback = ChartErrorFallback 
}) => {
  return (
    <ErrorBoundary
      FallbackComponent={fallback}
      onError={(error, errorInfo) => {
        console.error('Chart Error:', error, errorInfo)
      }}
    >
      {children}
    </ErrorBoundary>
  )
}