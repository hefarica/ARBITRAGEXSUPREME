import { useMemo } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'
import { useSimulation } from '../simulation/SimulationProvider'

interface PortfolioDataPoint {
  timestamp: number
  balance: number
  totalPnL: number
  cumulativePnL: number
  formattedDate: string
}

export function PortfolioChart() {
  const { state } = useSimulation()
  
  const portfolioData = useMemo(() => {
    if (state.trades.length === 0) {
      return [{
        timestamp: Date.now(),
        balance: state.balance,
        totalPnL: 0,
        cumulativePnL: 0,
        formattedDate: new Date().toLocaleDateString()
      }]
    }

    let runningBalance = 10000 // Starting balance
    let cumulativePnL = 0
    
    const data: PortfolioDataPoint[] = [{
      timestamp: Date.now() - (state.trades.length * 60000), // Assume 1 minute between trades
      balance: runningBalance,
      totalPnL: 0,
      cumulativePnL: 0,
      formattedDate: new Date(Date.now() - (state.trades.length * 60000)).toLocaleDateString()
    }]

    // Process trades in reverse chronological order (oldest first)
    const sortedTrades = Array.from(state.trades).reverse()
    
    sortedTrades.forEach((trade, index) => {
      const netPnL = trade.profit - trade.fees
      runningBalance += netPnL
      cumulativePnL += netPnL
      
      data.push({
        timestamp: trade.timestamp,
        balance: runningBalance,
        totalPnL: netPnL,
        cumulativePnL: cumulativePnL,
        formattedDate: new Date(trade.timestamp).toLocaleDateString()
      })
    })

    return data
  }, [state.trades, state.balance])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const formatTooltipValue = (value: number, name: string) => {
    if (name === 'balance') return [formatCurrency(value), 'Portfolio Value']
    if (name === 'cumulativePnL') return [formatCurrency(value), 'Cumulative P&L']
    return [formatCurrency(value), name]
  }

  const formatTooltipLabel = (label: number) => {
    return new Date(label).toLocaleString()
  }

  const currentValue = portfolioData[portfolioData.length - 1]?.balance || state.balance
  const isProfit = currentValue >= 10000

  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={portfolioData}
          margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
        >
          <CartesianGrid 
            strokeDasharray="3 3" 
            stroke="hsl(var(--border))"
            opacity={0.3}
          />
          
          <XAxis 
            dataKey="timestamp"
            type="number"
            scale="time"
            domain={['dataMin', 'dataMax']}
            tickFormatter={(value) => new Date(value).toLocaleDateString()}
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
          />
          
          <YAxis 
            tickFormatter={formatCurrency}
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
          />
          
          <Tooltip 
            formatter={formatTooltipValue}
            labelFormatter={formatTooltipLabel}
            contentStyle={{
              backgroundColor: 'hsl(var(--card))',
              border: '1px solid hsl(var(--border))',
              borderRadius: 'var(--radius)',
              boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
            }}
          />

          {/* Reference line at starting balance */}
          <ReferenceLine 
            y={10000} 
            stroke="hsl(var(--muted-foreground))" 
            strokeDasharray="5 5" 
            opacity={0.5}
          />
          
          <Line
            type="monotone"
            dataKey="balance"
            stroke={isProfit ? 'hsl(var(--profit))' : 'hsl(var(--destructive))'}
            strokeWidth={2}
            dot={false}
            activeDot={{ 
              r: 4, 
              fill: isProfit ? 'hsl(var(--profit))' : 'hsl(var(--destructive))',
              stroke: 'hsl(var(--background))',
              strokeWidth: 2
            }}
          />
          
          <Line
            type="monotone"
            dataKey="cumulativePnL"
            stroke="hsl(var(--primary))"
            strokeWidth={1}
            strokeDasharray="3 3"
            dot={false}
            opacity={0.7}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}