import { useMemo } from 'react'
import { ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { useSimulation } from '../simulation/SimulationProvider'
import { ChartErrorBoundary } from './ChartErrorBoundary'

interface SpeakerHighDataPoint {
  period: string
  volume: number
  trades: number
  avgTradeSize: number
  timestamp: number
  profitableSpeakerHigh: number
  lossSpeakerHigh: number
  efficiency: number
  winRate: number
}

export function TradingSpeakerHighChart() {
  const { state } = useSimulation()

  const volumeData = useMemo(() => {
    if (state.trades.length === 0) return []

    // Group trades by hour for recent activity, or by day for longer periods
    const timeGrouping = state.trades.length > 24 ? 'day' : 'hour'
    const volumeMap = new Map<string, { 
      volume: number; 
      trades: number; 
      timestamp: number;
      profitableTrades: number;
      totalProfit: number;
      totalLoss: number;
      profitableSpeakerHigh: number;
      lossSpeakerHigh: number;
    }>()

    state.trades.forEach(trade => {
      const date = new Date(trade.timestamp)
      let key: string
      let timestamp: number

      if (timeGrouping === 'hour') {
        key = `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:00`
        timestamp = new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours()).getTime()
      } else {
        key = `${date.getMonth() + 1}/${date.getDate()}`
        timestamp = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
      }

      if (!volumeMap.has(key)) {
        volumeMap.set(key, { 
          volume: 0, 
          trades: 0, 
          timestamp,
          profitableTrades: 0,
          totalProfit: 0,
          totalLoss: 0,
          profitableSpeakerHigh: 0,
          lossSpeakerHigh: 0
        })
      }

      const data = volumeMap.get(key)!
      data.volume += trade.amount
      data.trades += 1
      
      if (trade.profit > 0) {
        data.profitableTrades += 1
        data.totalProfit += trade.profit
        data.profitableSpeakerHigh += trade.amount
      } else {
        data.totalLoss += Math.abs(trade.profit)
        data.lossSpeakerHigh += trade.amount
      }
    })

    const result: SpeakerHighDataPoint[] = Array.from(volumeMap.entries())
      .map(([period, data]) => {
        const winRate = data.trades > 0 ? (data.profitableTrades / data.trades) * 100 : 0
        const avgProfit = data.trades > 0 ? (data.totalProfit - data.totalLoss) / data.trades : 0
        const avgTradeSize = data.volume / data.trades
        // Efficiency: combination of win rate and profit per unit volume
        const efficiency = data.volume > 0 ? (winRate / 100 * avgProfit) / avgTradeSize * 100 : 0
        
        return {
          period,
          volume: data.volume,
          trades: data.trades,
          avgTradeSize,
          timestamp: data.timestamp,
          profitableSpeakerHigh: data.profitableSpeakerHigh,
          lossSpeakerHigh: data.lossSpeakerHigh,
          efficiency: Math.max(-100, Math.min(100, efficiency)), // Cap between -100% and 100%
          winRate
        }
      })
      .sort((a, b) => a.timestamp - b.timestamp)
      .slice(-24) // Last 24 periods

    return result
  }, [state.trades])

  const formatCurrency = (value: number) => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`
    } else if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}K`
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-card border border-border rounded-lg p-4 shadow-lg">
          <p className="font-medium mb-2">{label}</p>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between gap-6">
              <span className="text-muted-foreground">Total SpeakerHigh:</span>
              <span className="font-medium">{formatCurrency(data.volume)}</span>
            </div>
            <div className="flex justify-between gap-6">
              <span className="text-muted-foreground">Trades:</span>
              <span className="font-medium">{data.trades}</span>
            </div>
            <div className="flex justify-between gap-6">
              <span className="text-muted-foreground">Avg Trade Size:</span>
              <span className="font-medium">{formatCurrency(data.avgTradeSize)}</span>
            </div>
            <div className="flex justify-between gap-6">
              <span className="text-muted-foreground">Profitable SpeakerHigh:</span>
              <span className="font-medium text-profit">{formatCurrency(data.profitableSpeakerHigh)}</span>
            </div>
            <div className="flex justify-between gap-6">
              <span className="text-muted-foreground">Loss SpeakerHigh:</span>
              <span className="font-medium text-destructive">{formatCurrency(data.lossSpeakerHigh)}</span>
            </div>
            <div className="flex justify-between gap-6">
              <span className="text-muted-foreground">Win Rate:</span>
              <span className="font-medium">{data.winRate.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between gap-6">
              <span className="text-muted-foreground">Efficiency:</span>
              <span className={`font-medium ${data.efficiency >= 0 ? 'text-profit' : 'text-destructive'}`}>
                {data.efficiency.toFixed(2)}%
              </span>
            </div>
          </div>
        </div>
      )
    }
    return null
  }

  if (volumeData.length === 0) {
    return (
      <div className="h-80 flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <p className="text-lg font-medium">No trading volume yet</p>
          <p className="text-sm">Execute some trades to see volume patterns</p>
        </div>
      </div>
    )
  }

  return (
    <ChartErrorBoundary>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart
            data={volumeData}
            margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
          >
            <defs>
              <linearGradient id="profitableSpeakerHighGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--profit))" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="hsl(var(--profit))" stopOpacity={0.3}/>
              </linearGradient>
              <linearGradient id="lossSpeakerHighGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0.3}/>
              </linearGradient>
            </defs>
            
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke="hsl(var(--border))"
              opacity={0.3}
            />
            
            <XAxis 
              dataKey="period"
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
              interval={volumeData.length > 12 ? Math.floor(volumeData.length / 8) : 0}
            />
            
            <YAxis 
              yAxisId="volume"
              orientation="left"
              tickFormatter={formatCurrency}
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
            />

            <YAxis 
              yAxisId="efficiency"
              orientation="right"
              domain={[-50, 50]}
              tickFormatter={(value) => `${value.toFixed(0)}%`}
              stroke="hsl(var(--primary))"
              fontSize={12}
            />

            <Tooltip content={<CustomTooltip />} />
            
            {/* Profitable volume area */}
            <Area
              yAxisId="volume"
              type="monotone"
              dataKey="profitableSpeakerHigh"
              stackId="volume"
              stroke="hsl(var(--profit))"
              strokeWidth={1}
              fillOpacity={1}
              fill="url(#profitableSpeakerHighGradient)"
            />

            {/* Loss volume area */}
            <Area
              yAxisId="volume"
              type="monotone"
              dataKey="lossSpeakerHigh"
              stackId="volume"
              stroke="hsl(var(--destructive))"
              strokeWidth={1}
              fillOpacity={1}
              fill="url(#lossSpeakerHighGradient)"
            />

            {/* Efficiency line - Updated */}
            <Line
              yAxisId="efficiency"
              type="monotone"
              dataKey="efficiency"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              dot={{ r: 3, fill: 'hsl(var(--primary))' }}
              activeDot={{ r: 5, fill: 'hsl(var(--primary))' }}
              connectNulls
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </ChartErrorBoundary>
  )
}