import { useMemo } from 'react'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts'
import { useSimulation } from '../simulation/SimulationProvider'

interface StrategyAllocation {
  name: string
  value: number
  percentage: number
  trades: number
  color: string
}

const STRATEGY_COLORS = {
  'arbitrage': 'hsl(var(--primary))',
  'triangular': 'hsl(var(--accent))',
  'flash-loan': 'hsl(var(--secondary))',
  'other': 'hsl(var(--muted))'
}

export function StrategyAllocationChart() {
  const { state } = useSimulation()

  const allocationData = useMemo(() => {
    if (state.trades.length === 0) return []

    // Calculate total allocation by strategy type
    const strategyTotals = state.trades.reduce((acc, trade) => {
      const netPnL = trade.profit - trade.fees
      if (!acc[trade.type]) {
        acc[trade.type] = { profit: 0, trades: 0 }
      }
      acc[trade.type].profit += Math.abs(netPnL) // Use absolute value for allocation size
      acc[trade.type].trades++
      return acc
    }, {} as Record<string, { profit: number; trades: number }>)

    const totalValue = Object.values(strategyTotals).reduce((sum, s) => sum + s.profit, 0)

    if (totalValue === 0) return []

    const result: StrategyAllocation[] = Object.entries(strategyTotals).map(([strategy, data]) => ({
      name: strategy.charAt(0).toUpperCase() + strategy.slice(1).replace('-', ' '),
      value: data.profit,
      percentage: (data.profit / totalValue) * 100,
      trades: data.trades,
      color: STRATEGY_COLORS[strategy as keyof typeof STRATEGY_COLORS] || STRATEGY_COLORS.other
    }))

    return result.sort((a, b) => b.value - a.value)
  }, [state.trades])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="font-medium mb-2">{data.name} Strategy</p>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">SpeakerHigh:</span>
              <span className="font-medium">{formatCurrency(data.value)}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">ShareNetwork:</span>
              <span className="font-medium">{data.percentage.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Trades:</span>
              <span className="font-medium">{data.trades}</span>
            </div>
          </div>
        </div>
      )
    }
    return null
  }

  const CustomLegend = ({ payload }: any) => {
    return (
      <div className="flex flex-wrap justify-center gap-4 mt-4">
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div 
              className="w-3 h-3 rounded-sm" 
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-muted-foreground">{entry.value}</span>
            <span className="font-medium">
              {entry.payload.percentage.toFixed(1)}%
            </span>
          </div>
        ))}
      </div>
    )
  }

  if (allocationData.length === 0) {
    return (
      <div className="h-80 flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <p className="text-lg font-medium">No strategy data yet</p>
          <p className="text-sm">Execute trades to see strategy allocation</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-80">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={allocationData}
            cx="50%"
            cy="40%"
            innerRadius={60}
            outerRadius={100}
            paddingAngle={2}
            dataKey="value"
          >
            {allocationData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend content={<CustomLegend />} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}