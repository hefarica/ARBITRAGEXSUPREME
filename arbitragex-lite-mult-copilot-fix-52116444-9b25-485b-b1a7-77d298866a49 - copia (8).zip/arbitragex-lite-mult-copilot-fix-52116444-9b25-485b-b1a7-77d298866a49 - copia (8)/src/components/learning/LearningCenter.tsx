import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useKV } from '@/hooks/useKV'
import { BookOpen, CheckCircle, PlayCircle, Trophy, GraduationCap, Target } from '@phosphor-icons/react'

interface LearningModule {
  id: string
  title: string
  description: string
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced'
  duration: string
  topics: string[]
  completed: boolean
  progress: number
}

interface Quiz {
  id: string
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
}

export function LearningCenter() {
  const [completedModules, setCompletedModules] = useKV<string[]>("completed-modules", [])
  const [selectedModule, setSelectedModule] = useState<LearningModule | null>(null)
  const [showQuiz, setShowQuiz] = useState(false)
  const [currentQuiz, setCurrentQuiz] = useState(0)
  const [quizAnswers, setQuizAnswers] = useState<number[]>([])

  const modules: LearningModule[] = [
    {
      id: 'arbitrage-basics',
      title: 'Arbitrage Fundamentals',
      description: 'Learn the core concepts of arbitrage trading in DeFi markets',
      difficulty: 'Beginner',
      duration: '15 min',
      topics: ['What is Arbitrage?', 'Types of Arbitrage', 'Risk Factors', 'Market Efficiency'],
      completed: completedModules.includes('arbitrage-basics'),
      progress: completedModules.includes('arbitrage-basics') ? 100 : 0
    },
    {
      id: 'triangular-arbitrage',
      title: 'Triangular Arbitrage',
      description: 'Understand three-way arbitrage opportunities and execution strategies',
      difficulty: 'Beginner',
      duration: '20 min',
      topics: ['Three-Token Loops', 'Price Calculation', 'Execution Order', 'Profit Optimization'],
      completed: completedModules.includes('triangular-arbitrage'),
      progress: completedModules.includes('triangular-arbitrage') ? 100 : 0
    },
    {
      id: 'cross-dex-arbitrage',
      title: 'Cross-DEX Arbitrage',
      description: 'Exploit price differences between different decentralized exchanges',
      difficulty: 'Intermediate',
      duration: '25 min',
      topics: ['DEX Comparison', 'Liquidity Analysis', 'Gas Optimization', 'Timing Strategies'],
      completed: completedModules.includes('cross-dex-arbitrage'),
      progress: completedModules.includes('cross-dex-arbitrage') ? 100 : 0
    },
    {
      id: 'flash-loans',
      title: 'Flash Loan Arbitrage',
      description: 'Use borrowed funds for large-scale arbitrage without initial capital',
      difficulty: 'Advanced',
      duration: '30 min',
      topics: ['Flash Loan Basics', 'Aave Protocol', 'Smart Contracts', 'Risk Management'],
      completed: completedModules.includes('flash-loans'),
      progress: completedModules.includes('flash-loans') ? 100 : 0
    },
    {
      id: 'mev-protection',
      title: 'MEV and Protection Strategies',
      description: 'Understand Maximum Extractable Value and how to protect against it',
      difficulty: 'Advanced',
      duration: '35 min',
      topics: ['MEV Basics', 'Sandwich Attacks', 'Private Mempools', 'Protection Methods'],
      completed: completedModules.includes('mev-protection'),
      progress: completedModules.includes('mev-protection') ? 100 : 0
    },
    {
      id: 'risk-management',
      title: 'Risk Management',
      description: 'Learn to assess and manage risks in arbitrage trading',
      difficulty: 'Intermediate',
      duration: '20 min',
      topics: ['Risk Types', 'Position Sizing', 'Stop Losses', 'Portfolio Management'],
      completed: completedModules.includes('risk-management'),
      progress: completedModules.includes('risk-management') ? 100 : 0
    }
  ]

  const quizzes: Quiz[] = [
    {
      id: 'q1',
      question: 'What is arbitrage in cryptocurrency trading?',
      options: [
        'Buying low and selling high on the same exchange',
        'Profiting from price differences between markets',
        'Holding assets for long-term gains',
        'Trading based on technical analysis'
      ],
      correctAnswer: 1,
      explanation: 'Arbitrage involves profiting from price differences of the same asset across different markets or exchanges.'
    },
    {
      id: 'q2',
      question: 'What is the main risk in triangular arbitrage?',
      options: [
        'Market volatility',
        'Execution speed and slippage',
        'Regulatory changes',
        'Technical analysis failure'
      ],
      correctAnswer: 1,
      explanation: 'The main risk is execution speed and slippage, as prices can change rapidly during the multi-step process.'
    },
    {
      id: 'q3',
      question: 'What enables flash loan arbitrage?',
      options: [
        'High initial capital requirements',
        'Borrowing funds within a single transaction',
        'Long-term market analysis',
        'Multiple exchange accounts'
      ],
      correctAnswer: 1,
      explanation: 'Flash loans allow borrowing large amounts within a single transaction, enabling arbitrage without initial capital.'
    }
  ]

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-profit text-profit-foreground'
      case 'Intermediate': return 'bg-warning text-warning-foreground'
      case 'Advanced': return 'bg-destructive text-destructive-foreground'
      default: return 'bg-muted text-muted-foreground'
    }
  }

  const completeModule = (moduleId: string) => {
    if (!completedModules.includes(moduleId)) {
      setCompletedModules([...completedModules, moduleId])
    }
    setSelectedModule(null)
  }

  const startQuiz = () => {
    setShowQuiz(true)
    setCurrentQuiz(0)
    setQuizAnswers([])
  }

  const answerQuiz = (answerIndex: number) => {
    const newAnswers = [...quizAnswers, answerIndex]
    setQuizAnswers(newAnswers)
    
    if (currentQuiz < quizzes.length - 1) {
      setCurrentQuiz(currentQuiz + 1)
    } else {
      // Quiz completed
      const score = newAnswers.reduce((acc, answer, index) => {
        return acc + (answer === quizzes[index].correctAnswer ? 1 : 0)
      }, 0)
      
      // If score is good enough, complete the module
      if (score >= Math.ceil(quizzes.length * 0.7)) {
        completeModule('quiz-completion')
      }
      
      setShowQuiz(false)
    }
  }

  const totalModules = modules.length
  const completedCount = completedModules.length
  const overallProgress = (completedCount / totalModules) * 100

  if (selectedModule) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <Button 
          variant="outline" 
          onClick={() => setSelectedModule(null)}
          className="mb-4"
        >
          ← Back to Learning Center
        </Button>
        
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-3">
                  <BookOpen size={24} />
                  {selectedModule.title}
                </CardTitle>
                <p className="text-muted-foreground mt-2">{selectedModule.description}</p>
              </div>
              <Badge className={getDifficultyColor(selectedModule.difficulty)}>
                {selectedModule.difficulty}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div>
              <h4 className="font-semibold mb-3">Learning Objectives</h4>
              <ul className="space-y-2">
                {selectedModule.topics.map((topic, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <CheckCircle size={16} className="text-profit" />
                    {topic}
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="bg-muted/50 rounded-lg p-6">
              <h4 className="font-semibold mb-3">Interactive Content</h4>
              <p className="text-muted-foreground mb-4">
                This module would contain interactive content, videos, and hands-on exercises 
                to teach {selectedModule.title.toLowerCase()}.
              </p>
              <div className="flex gap-2">
                <Button onClick={() => completeModule(selectedModule.id)}>
                  Mark as Complete
                </Button>
                <Button variant="outline" onClick={startQuiz}>
                  Take Quiz
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (showQuiz) {
    const currentQuizData = quizzes[currentQuiz]
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Knowledge Quiz</h3>
          <span className="text-sm text-muted-foreground">
            {currentQuiz + 1} of {quizzes.length}
          </span>
        </div>
        
        <Card>
          <CardContent className="p-6">
            <h4 className="font-semibold mb-4">{currentQuizData.question}</h4>
            <div className="space-y-3">
              {currentQuizData.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full text-left justify-start h-auto p-4"
                  onClick={() => answerQuiz(index)}
                >
                  {option}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold">Learning Progress</h3>
              <p className="text-muted-foreground">Track your arbitrage education journey</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold">{completedCount}/{totalModules}</p>
              <p className="text-sm text-muted-foreground">Modules Completed</p>
            </div>
          </div>
          <Progress value={overallProgress} className="h-2" />
          <p className="text-sm text-muted-foreground mt-2">
            {overallProgress.toFixed(0)}% Complete
          </p>
        </CardContent>
      </Card>

      <Tabs defaultValue="modules" className="space-y-6">
        <TabsList>
          <TabsTrigger value="modules">Learning Modules</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
        </TabsList>

        <TabsContent value="modules" className="space-y-4">
          <div className="grid gap-4">
            {modules.map((module) => (
              <Card 
                key={module.id} 
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setSelectedModule(module)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold">{module.title}</h4>
                        <Badge className={getDifficultyColor(module.difficulty)}>
                          {module.difficulty}
                        </Badge>
                        {module.completed && (
                          <Badge className="bg-profit text-profit-foreground">
                            <CheckCircle size={14} className="mr-1" />
                            Completed
                          </Badge>
                        )}
                      </div>
                      <p className="text-muted-foreground mb-3">{module.description}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>⏱️ {module.duration}</span>
                        <span>📚 {module.topics.length} topics</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {module.completed ? (
                        <CheckCircle size={24} className="text-profit" />
                      ) : (
                        <PlayCircle size={24} className="text-primary" />
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="achievements">
          <div className="grid gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <Trophy size={48} className="mx-auto mb-4 text-warning" />
                <h4 className="font-semibold mb-2">First Steps</h4>
                <p className="text-muted-foreground mb-4">Complete your first learning module</p>
                <Badge className={completedCount > 0 ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                  {completedCount > 0 ? 'LockOpened' : 'Locked'}
                </Badge>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <GraduationCap size={48} className="mx-auto mb-4 text-primary" />
                <h4 className="font-semibold mb-2">Scholar</h4>
                <p className="text-muted-foreground mb-4">Complete 3 learning modules</p>
                <Badge className={completedCount >= 3 ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                  {completedCount >= 3 ? 'LockOpened' : `${completedCount}/3`}
                </Badge>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <Target size={48} className="mx-auto mb-4 text-accent" />
                <h4 className="font-semibold mb-2">Expert</h4>
                <p className="text-muted-foreground mb-4">Complete all learning modules</p>
                <Badge className={completedCount === totalModules ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                  {completedCount === totalModules ? 'LockOpened' : `${completedCount}/${totalModules}`}
                </Badge>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="resources">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Additional Resources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <BookOpen size={20} className="text-primary" />
                    <div>
                      <h5 className="font-medium">DeFi Pulse - Arbitrage Guide</h5>
                      <p className="text-sm text-muted-foreground">Comprehensive guide to DeFi arbitrage strategies</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <PlayCircle size={20} className="text-primary" />
                    <div>
                      <h5 className="font-medium">Uniswap V3 Documentation</h5>
                      <p className="text-sm text-muted-foreground">Technical documentation for understanding AMM mechanics</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <Target size={20} className="text-primary" />
                    <div>
                      <h5 className="font-medium">Flashloan Attack Vectors</h5>
                      <p className="text-sm text-muted-foreground">Learn about common attack patterns to avoid pitfalls</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}