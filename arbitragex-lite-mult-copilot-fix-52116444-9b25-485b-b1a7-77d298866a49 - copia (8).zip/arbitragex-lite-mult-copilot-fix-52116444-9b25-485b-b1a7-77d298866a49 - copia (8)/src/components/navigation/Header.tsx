import { useSimulation } from '../simulation/SimulationProvider'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { SystemStatusIndicator } from '@/components/audit/SystemStatusIndicator'
import { 
  Play, 
  Pause, 
  Square, 
  List, 
  TestTube, 
  Rocket, 
  Cpu, 
  Activity,
  Globe
} from '@phosphor-icons/react'
import type { Tab } from '../../App'

interface HeaderProps {
  activeTab: Tab
  onListToggle: () => void
  environment: 'test' | 'prod'
  onEnvironmentChange: (env: 'test' | 'prod') => void
}

const tabTitles: Record<Tab, string> = {
  'unified-command': 'Unified Command Center',
  'smart-trading': 'Smart Trading Engine',
  'risk-execution': 'Risk & Execution Control',
  'cross-chain-ai': 'Cross-Chain AI Orchestrator',
  'security-sentiment': 'Security & Sentiment Hub',
  'advanced-automation': 'Advanced Automation Center',
  'audit-compliance': '🚨 Audit & Compliance Center'
}

export function Header({ activeTab, onListToggle, environment, onEnvironmentChange }: HeaderProps) {
  const { state, startSimulation, stopSimulation, resetSimulation } = useSimulation()

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 4
    }).format(value)
  }

  const getStatusColor = () => {
    if (state.isRunning) return 'bg-profit'
    return 'bg-muted'
  }

  const getStatusText = () => {
    if (state.isRunning) return 'Active'
    return 'Stopped'
  }

  // Simulated real-time metrics
  const latency = Math.random() * 2 + 0.5 // 0.5-2.5ms
  const throughput = Math.floor(Math.random() * 1000 + 500) // 500-1500 TPS

  return (
    <header className="bg-card border-b border-border px-6 py-4 sticky top-0 z-[100]">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onListToggle}
            className="lg:hidden h-8 w-8 p-0"
          >
            <List size={16} />
          </Button>
          
          <div>
            <h2 className="text-xl font-bold text-foreground">{tabTitles[activeTab]}</h2>
            <div className="flex items-center gap-6 mt-1">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${getStatusColor()}`} />
                <span className="text-sm text-muted-foreground">
                  Simulation {getStatusText()}
                </span>
              </div>
              
              <div className="hidden md:flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <Activity size={14} className="text-muted-foreground" />
                  <span className="text-muted-foreground">Latency: </span>
                  <span className="font-semibold text-profit">{latency.toFixed(1)}ms</span>
                </div>
                <div className="flex items-center gap-2">
                  <Cpu size={14} className="text-muted-foreground" />
                  <span className="text-muted-foreground">TPS: </span>
                  <span className="font-semibold">{throughput.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Globe size={14} className="text-muted-foreground" />
                  <span className="text-muted-foreground">Balance: </span>
                  <span className="font-semibold">{formatCurrency(state.balance)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* System Status Indicator */}
          <SystemStatusIndicator environment={environment} compact={true} />
          
          <div className="hidden sm:flex items-center gap-2">
            <Button
              size="sm"
              variant={environment === 'test' ? 'default' : 'outline'}
              onClick={() => onEnvironmentChange('test')}
              className="gap-2 h-8"
            >
              <TestTube size={14} />
              Test
            </Button>
            <Button
              size="sm"
              variant={environment === 'prod' ? 'default' : 'outline'}
              onClick={() => onEnvironmentChange('prod')}
              className="gap-2 h-8"
            >
              <Rocket size={14} />
              Prod
            </Button>
          </div>
          
          <div className="flex items-center gap-1">
            {!state.isRunning ? (
              <Button
                size="sm"
                onClick={startSimulation}
                className="gap-2"
              >
                <Play size={16} />
                Start
              </Button>
            ) : (
              <Button
                size="sm"
                variant="secondary"
                onClick={stopSimulation}
                className="gap-2"
              >
                <Pause size={16} />
                Pause
              </Button>
            )}
            
            <Button
              size="sm"
              variant="outline"
              onClick={resetSimulation}
              className="gap-2"
            >
              <Square size={16} />
              Reset
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}