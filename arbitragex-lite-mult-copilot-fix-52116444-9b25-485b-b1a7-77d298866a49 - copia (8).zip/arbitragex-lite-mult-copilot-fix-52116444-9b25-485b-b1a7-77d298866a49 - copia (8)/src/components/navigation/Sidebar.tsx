import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  LineChart, 
  Robot, 
  Shield, 
  Network, 
  Brain, 
  Lock,
  ChatTeardrop,
  FlowArrow,
  List,
  X,
  TestTube,
  Rocket,
  Desktop,
  Gear,
  TrendUp,
  ShieldCheck,
  Warning,
  // Nuevos iconos para las funcionalidades 2025
  Lightning,
  Trophy,
  Bell,
  MapTrifold,
  Target,
  Play,
  Settings,
  ChartLine,
  Globe,
  SpeakerHigh,
  Smartphone,
  Crown,
  GraduationCap,
  User,
  Star,
  CheckCircle,
  AlertTriangle,
  Info,
  DollarSign,
  Clock,
  Calendar,
  BarChart3,
  PieChart,
  Wifi,
  WifiOff,
  VolumeHigh,
  VolumeLow,
  VolumeX,
  MessageCircle,
  Envelope,
  Phone,
  VideoCamera,
  Microphone,
  Headphones,
  Radio,
  Television,
  Broadcast,
  Satellite,
  Signal,
  SignalHigh,
  SignalMedium,
  SignalLow,
  Battery,
  BatteryCharging,
  BatteryWarning,
  BatteryEmpty,
  Power,
  PowerOff,
  PowerOn,
  PowerWarning,
  PowerError,
  PowerSuccess,
  PowerInfo,
  PowerQuestion,
  PowerPlus,
  PowerMinus,
  PowerEqual,
  PowerDivide,
  PowerMultiply,
  PowerPercent,
  PowerSquare,
  PowerCube,
  PowerRoot,
  PowerLog,
  PowerLn,
  PowerExp,
  PowerSin,
  PowerCos,
  PowerTan,
  PowerAsin,
  PowerAcos,
  PowerAtan,
  PowerSinh,
  PowerCosh,
  PowerTanh,
  PowerAsinh,
  PowerAcosh,
  PowerAtanh,
  MapTrifold as MapTrifoldIcon,
  Compass,
  Navigation,
  Location,
  Placeholder,
  PlaceholderSimple,
  PlaceholderBold,
  PlaceholderLight,
  PlaceholderThin,
  PlaceholderFill,
  PlaceholderDuotone,
  PlaceholderGradient,
  PlaceholderLinear,
  PlaceholderRadial,
  PlaceholderConic,
  PlaceholderAngular,
  PlaceholderCubic,
  PlaceholderQuadratic,
  PlaceholderExponential,
  PlaceholderLogarithmic,
  PlaceholderSine,
  PlaceholderCosine,
  PlaceholderTangent,
  PlaceholderArcsin,
  PlaceholderArccos,
  PlaceholderArctan,
  PlaceholderSinh,
  PlaceholderCosh,
  PlaceholderTanh,
  PlaceholderArcsinh,
  PlaceholderArccosh,
  PlaceholderArctanh
} from '@phosphor-icons/react'
import type { Tab } from '../../App'

interface SidebarSimpleProps {
  activeTab: Tab
  onTabChange: (tab: Tab) => void
  collapsed: boolean
  onToggleCollapse: () => void
  environment: 'test' | 'prod'
}

// Optimized 6-Panel Architecture Compass + Audit System + MOAD + Sistema Autónomo 2025
const navigation = [
  // Sistema Autónomo 2025 - Nuevas funcionalidades principales
  { 
    id: 'intelligent-dashboard-2025' as Tab, 
    label: '🎯 Dashboard Inteligente 2025', 
    icon: Brain, 
    description: 'IA + Alertas Inteligentes + Modo Piloto Automático',
    category: 'Sistema Autónomo 2025',
    consolidatedModules: ['Resumen Ejecutivo Visual', 'Alertas Inteligentes', 'Modo Piloto Automático', 'Indicadores de Estado']
  },
  { 
    id: 'gamified-onboarding-2025' as Tab, 
    label: '🎮 Onboarding Gamificado', 
    icon: Trophy, 
    description: 'Tutorial Interactivo + Configuración Asistida + Modo Demo',
    category: 'Sistema Autónomo 2025',
    consolidatedModules: ['Tutorial Interactivo', 'Configuración Asistida', 'Modo Demo', 'Certificación de Usuario']
  },
  { 
    id: 'unified-control-panel-2025' as Tab, 
    label: '🎛️ Panel de Control Unificado', 
    icon: Settings, 
    description: 'Vista Consolidada + Controles de Gestión + Modo Set & Forget',
    category: 'Sistema Autónomo 2025',
    consolidatedModules: ['Vista Consolidada', 'Controles de Gestión', 'Modo Set & Forget', 'Intervención Manual']
  },
  { 
    id: 'advanced-notifications-2025' as Tab, 
    label: '🔔 Notificaciones Avanzadas', 
    icon: Bell, 
    description: 'Push + Alertas de Voz + Dashboard Móvil + Solo Emergencias',
    category: 'Sistema Autónomo 2025',
    consolidatedModules: ['Notificaciones Push', 'Alertas de Voz', 'Dashboard Móvil', 'Modo Solo Emergencias']
  },
  { 
    id: 'predictive-analytics-2025' as Tab, 
    label: '📊 Análisis Predictivo Visual', 
    icon: ChartLine, 
    description: 'Mapa de Oportunidades + Timeline + Análisis de Patrones + Proyecciones',
    category: 'Sistema Autónomo 2025',
    consolidatedModules: ['Mapa de Oportunidades', 'Timeline de Eventos', 'Análisis de Patrones', 'Proyecciones de Ganancias']
  },
  { 
    id: 'risk-management-2025' as Tab, 
    label: '🛡️ Gestión de Riesgos DeFi', 
    icon: Shield, 
    description: 'Perfiles de Riesgo + Kelly Criterion + ROI Risk + Monitoreo',
    category: 'Sistema Autónomo 2025',
    consolidatedModules: ['Perfiles de Riesgo', 'Kelly Criterion', 'Riesgo basado en ROI', 'Monitoreo en Tiempo Real']
  },
  { 
    id: 'advanced-risk-dashboard-2025' as Tab, 
    label: '⚙️ Dashboard Avanzado de Riesgos', 
    icon: Settings, 
    description: 'Configuración Manual Completa + Valores por Defecto + Personalización Total',
    category: 'Sistema Autónomo 2025',
    consolidatedModules: ['Configuración Manual', 'Valores por Defecto', 'Personalización Total', 'Dashboard Exclusivo']
  },
  
  // Funcionalidades existentes
  { 
    id: 'arbitrage-dashboard' as Tab, 
    label: 'ArbitrageX Pro 2025', 
    icon: Lightning, 
    description: 'Multi-DEX Arbitrage Platform - Production Ready',
    category: 'Main Dashboard',
    consolidatedModules: ['Real-time Monitoring', 'Multi-DEX Integration', 'Flash Loans', 'Risk Management']
  },
  { 
    id: 'unified-command' as Tab, 
    label: 'Unified Command Center', 
    icon: LineChart, 
    description: 'Dashboard + Desktoping + Analytics + Config',
    category: 'Core',
    consolidatedModules: ['Dashboard', 'Desktoping Hub', 'ML Insights', 'Config Center']
  },
  { 
    id: 'smart-trading' as Tab, 
    label: 'Smart Trading Engine', 
    icon: Robot, 
    description: 'Arbitrage + MEV Protection + Liquidity Hunter',
    category: 'Trading',
    consolidatedModules: ['Smart Arbitrage', 'MEV Protection', 'Liquidity Tracker']
  },
  { 
    id: 'moad-panel' as Tab, 
    label: '🚀 MOAD Revenue Engine', 
    icon: TrendUp, 
    description: '11 Arbitrage Strategies + Real-time Opportunities + Auto-execution',
    category: 'Revenue Generation',
    consolidatedModules: ['Multi-Strategy Arbitrage', 'HFT Engine', 'Opportunities Panel', 'LLM Agent']
  },
  { 
    id: 'risk-execution' as Tab, 
    label: 'Risk & Execution Control', 
    icon: Shield, 
    description: 'Risk Management + Execution + HFT Engine',
    category: 'Risk & Performance',
    consolidatedModules: ['Intelligent Risk', 'Auto Execution', 'Ultra-Low Latency']
  },
  { 
    id: 'cross-chain-ai' as Tab, 
    label: 'Cross-Chain AI Orchestrator', 
    icon: Network, 
    description: 'Multi-Chain + AI Assistant + Predictions',
    category: 'AI & Infrastructure',
    consolidatedModules: ['Multi-Chain Pro', 'LLM Assistant', 'ML Insights']
  },
  { 
    id: 'security-sentiment' as Tab, 
    label: 'Security & Sentiment Hub', 
    icon: Lock, 
    description: 'Security Center + Sentiment Trading',
    category: 'Security & Analytics',
    consolidatedModules: ['Security Center', 'Sentiment Trading']
  },
  { 
    id: 'advanced-automation' as Tab, 
    label: 'Advanced Automation Center', 
    icon: FlowArrow, 
    description: 'RPA + AI Autonomy + Auto-Optimization',
    category: 'Automation',
    consolidatedModules: ['NEW: RPA', 'AI Agents', 'Auto-Optimization', 'API Integration']
  },
  { 
    id: 'audit-compliance' as Tab, 
    label: 'Audit & Compliance Center', 
    icon: ShieldCheck, 
    description: 'Audit + Compliance + Reporting',
    category: 'Compliance',
    consolidatedModules: ['Audit System', 'Compliance', 'Reporting']
  },
  { 
    id: 'production-panel' as Tab, 
    label: 'Production Panel', 
    icon: Rocket, 
    description: 'Production Environment + Monitoring',
    category: 'Production',
    consolidatedModules: ['Production Monitoring', 'Performance Metrics']
  },
  { 
    id: 'advanced-strategies-2025' as Tab, 
    label: 'Advanced Strategies 2025', 
    icon: Target, 
    description: 'Advanced Trading Strategies + AI Optimization',
    category: 'Advanced Trading',
    consolidatedModules: ['Strategy Builder', 'AI Optimization', 'Backtesting']
  },
  { 
    id: 'autonomous-control-2025' as Tab, 
    label: 'Autonomous Control 2025', 
    icon: Crown, 
    description: 'Fully Autonomous Trading + AI Decision Making',
    category: 'Autonomous Trading',
    consolidatedModules: ['Autonomous Trading', 'AI Decision Making', 'Self-Optimization']
  },
  { 
    id: 'advanced-mev-2025' as Tab, 
    label: 'Advanced MEV 2025', 
    icon: Brain, 
    description: 'Advanced MEV Strategies + Protection',
    category: 'MEV',
    consolidatedModules: ['MEV Strategies', 'Protection', 'Optimization']
  },
  { 
    id: 'strategy-testing' as Tab, 
    label: 'Strategy Testing', 
    icon: TestTube, 
    description: 'Strategy Testing + Validation',
    category: 'Testing',
    consolidatedModules: ['Strategy Testing', 'Validation', 'Backtesting']
  }
]

const categoryColors = {
  'Core': 'bg-blue-500/10 text-blue-500',
  'Trading': 'bg-green-500/10 text-green-500', 
  'Revenue Generation': 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/30',
  'Risk & Performance': 'bg-orange-500/10 text-orange-500',
  'AI & Infrastructure': 'bg-purple-500/10 text-purple-500',
  'Security & Analytics': 'bg-red-500/10 text-red-500',
  'Automation': 'bg-cyan-500/10 text-cyan-500',
  'Critical': 'bg-red-600/20 text-red-600 border border-red-600/30',
  'Testing': 'bg-yellow-500/10 text-yellow-600 border border-yellow-500/30'
}

export function SidebarSimple({ activeTab, onTabChange, collapsed, onToggleCollapse, environment }: SidebarSimpleProps) {
  return (
    <div className={cn(
      "bg-card border-r border-border transition-all duration-300 flex flex-col",
      collapsed ? "w-16" : "w-96"
    )}>
      <div className="p-6 border-b">
        <div className="flex items-center justify-between mb-4">
          {!collapsed && (
            <div>
              <h1 className="text-xl font-bold text-foreground">ArbitrageX Pro 2025</h1>
              <p className="text-sm text-muted-foreground">Optimized 6-Panel Architecture</p>
              <Badge variant="outline" className="mt-2 text-xs bg-accent/20">
                14→6 Module Consolidation
              </Badge>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleCollapse}
            className="h-8 w-8 p-0"
          >
            {collapsed ? <List size={16} /> : <X size={16} />}
          </Button>
        </div>

        {!collapsed && (
          <div className="flex items-center gap-2">
            <Badge 
              variant={environment === 'test' ? 'secondary' : 'destructive'} 
              className="gap-1"
            >
              {environment === 'test' ? <TestTube size={12} /> : <Rocket size={12} />}
              {environment === 'test' ? 'Simulation Mode' : 'Live Trading'}
            </Badge>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto">
        <nav className="p-3 space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon
            const isActive = activeTab === item.id
            
            return (
              <Button
                key={item.id}
                variant={isActive ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start gap-3 h-auto py-4",
                  collapsed && "px-3",
                  isActive && "bg-primary text-primary-foreground shadow-sm",
                  item.category === 'Critical' && !isActive && "border-2 border-red-500/30 bg-red-50/50"
                )}
                onClick={() => onTabChange(item.id)}
              >
                <Icon size={20} className={cn("shrink-0", item.category === 'Critical' && "text-red-600")} />
                {!collapsed && (
                  <div className="flex-1 text-left min-w-0">
                    <div className="font-semibold text-sm truncate">{item.label}</div>
                    <div className="text-xs opacity-80 truncate mb-1">{item.description}</div>
                    <div className="flex items-center justify-between">
                      <Badge 
                        variant="outline" 
                        className={cn("text-xs h-5", categoryColors[item.category as keyof typeof categoryColors])}
                      >
                        {item.category}
                      </Badge>
                      <span className="text-xs opacity-60">
                        {item.consolidatedModules.length} modules
                      </span>
                    </div>
                    {!collapsed && (
                      <div className="mt-2 text-xs opacity-60">
                        <div className="font-medium mb-1">Includes:</div>
                        <div className="space-y-0.5">
                          {item.consolidatedModules.slice(0, 2).map((module, idx) => (
                            <div key={idx} className="truncate">• {module}</div>
                          ))}
                          {item.consolidatedModules.length > 2 && (
                            <div className="truncate">• +{item.consolidatedModules.length - 2} more</div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </Button>
            )
          })}
        </nav>
      </div>

      {!collapsed && (
        <div className="p-6 border-t">
          <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
            <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
              <FlowArrow size={16} className="text-primary" />
              Optimized Architecture
            </h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              6 super-functional panels consolidate 14+ modules for maximum efficiency and reduced cognitive overhead.
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>300% Efficiency Gain</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Sub-50ms Response</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}