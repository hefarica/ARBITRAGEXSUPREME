import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Typography,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  FormControlLabel,
  Switch,
  Box,
  GridFour,
  Divider,
  LinearProgress,
  Paper,
  Alert
} from '@mui/material'
import {
  TrendUp,
  Clock,
  Shield,
  Network,
  CheckCircle,
  Warning,
  ExpandMore,
  ExpandLess
} from '@mui/icons-material'
import { strategies, StrategyInfo, getStrategyComplexityColor, getStrategyRiskColor } from './strategies'
import { formatCurrency, formatPercentage } from '@/lib/utils'
import { useKV } from '@/hooks/useKV'
import { toast } from 'sonner'

interface StrategySelectorPanelProps {
  selectedStrategy: string
  onStrategyChange: (strategyId: string) => void
  environment: 'test' | 'prod'
}

interface StrategyCardProps {
  strategy: StrategyInfo
  isSelected: boolean
  isEnabled: boolean
  onSelect: () => void
  onToggleEnabled: (enabled: boolean) => void
  environment: 'test' | 'prod'
}

const StrategyCard: React.FC<StrategyCardProps> = ({
  strategy,
  isSelected,
  isEnabled,
  onSelect,
  onToggleEnabled,
  environment
}) => {
  const [isExpanded, setIsExpanded] = useState(false)

  const handleToggleEnabled = (enabled: boolean) => {
    onToggleEnabled(enabled)
    
    if (enabled) {
      toast.success(`✅ Estrategia "${strategy.label}" habilitada`)
    } else {
      toast.info(`⏸️ Estrategia "${strategy.label}" deshabilitada`)
    }
  }

  const getROIBadgeColor = (roi: number) => {
    if (roi >= 8) return 'success'
    if (roi >= 6) return 'warning'
    return 'error'
  }

  const getCapitalBadge = (capital: number) => {
    if (capital === 0) return { label: 'SIN CAPITAL', color: 'success' }
    if (capital <= 100) return { label: 'CAPITAL BAJO', color: 'warning' }
    return { label: 'CAPITAL MEDIO', color: 'error' }
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
    >
      <Card
        elevation={isSelected ? 6 : 2}
        className={`
          hover:shadow-lg transition-all duration-300 cursor-pointer
          ${isSelected ? 'ring-2 ring-primary border-primary' : ''}
          ${!isEnabled ? 'opacity-60' : ''}
        `}
        onClick={() => !isSelected && onSelect()}
      >
        <CardContent className="p-4">
          {/* Header con ROI y toggles */}
          <Box className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <Chip 
                label={`ROI: ${strategy.roi2025}/10`}
                color={getROIBadgeColor(strategy.roi2025)}
                size="small"
                variant="filled"
              />
              <Chip 
                label={strategy.complexity.toUpperCase()}
                color={getStrategyComplexityColor(strategy.complexity) as any}
                size="small"
                variant="outlined"
              />
            </div>
            
            <FormControlLabel
              control={
                <Switch
                  checked={isEnabled}
                  onChange={(e) => handleToggleEnabled(e.target.checked)}
                  color="primary"
                />
              }
              label=""
              onClick={(e) => e.stopPropagation()}
            />
          </Box>

          {/* Título y descripción */}
          <Typography variant="h6" className="font-bold mb-2 text-foreground">
            {strategy.label}
          </Typography>
          
          <Typography variant="body2" className="text-muted-foreground mb-3 line-clamp-2">
            {strategy.description}
          </Typography>

          {/* Métricas clave */}
          <GridFour container spacing={2} className="mb-3">
            <GridFour item xs={6}>
              <Box className="text-center p-2 bg-gray-50 dark:bg-gray-800/50 rounded">
                <Typography variant="caption" className="text-muted-foreground">
                  Profit Avg
                </Typography>
                <Typography variant="body2" className="font-bold text-green-600">
                  {formatPercentage(strategy.avgProfitPercentage)}
                </Typography>
              </Box>
            </GridFour>
            <GridFour item xs={6}>
              <Box className="text-center p-2 bg-gray-50 dark:bg-gray-800/50 rounded">
                <Typography variant="caption" className="text-muted-foreground">
                  Éxito
                </Typography>
                <Typography variant="body2" className="font-bold">
                  {formatPercentage(strategy.successRate)}
                </Typography>
              </Box>
            </GridFour>
          </GridFour>

          {/* Badges informativos */}
          <Box className="flex flex-wrap gap-1 mb-3">
            <Chip 
              label={getCapitalBadge(strategy.capitalRequirement).label}
              color={getCapitalBadge(strategy.capitalRequirement).color as any}
              size="small"
            />
            <Chip 
              label={`${strategy.executionTimeMs}ms`}
              icon={<Clock className="w-3 h-3" />}
              size="small"
              variant="outlined"
            />
            <Chip 
              label={strategy.riskLevel.toUpperCase()}
              color={getStrategyRiskColor(strategy.riskLevel) as any}
              size="small"
              variant="outlined"
            />
          </Box>

          {/* Información expandible */}
          <AnimatePresence>
            {(isSelected || isExpanded) && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <Divider className="my-3" />
                
                {/* Detalles técnicos */}
                <Typography variant="subtitle2" className="font-bold mb-2">
                  🔧 Detalles Técnicos
                </Typography>
                <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Gas:</span>
                    <Chip 
                      label={strategy.technicalDetails.gasUsage}
                      size="small"
                      color={strategy.technicalDetails.gasUsage === 'low' ? 'success' : 'warning'}
                    />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">MEV Risk:</span>
                    <Chip 
                      label={strategy.technicalDetails.mevVulnerability}
                      size="small"
                      color={strategy.technicalDetails.mevVulnerability === 'low' ? 'success' : 'error'}
                    />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Capital:</span>
                    <span className="font-medium">
                      {strategy.capitalRequirement === 0 
                        ? 'Flash Loan' 
                        : formatCurrency(strategy.capitalRequirement)
                      }
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Liquidez:</span>
                    <span className="font-medium">{strategy.technicalDetails.liquidityDependency}</span>
                  </div>
                </div>

                {/* Requisitos */}
                <Typography variant="subtitle2" className="font-bold mb-2">
                  📋 Requisitos
                </Typography>
                <div className="flex flex-wrap gap-1 mb-3">
                  {strategy.requirements.flashLoanAvailable && (
                    <Chip label="Flash Loan" icon={<CheckCircle className="w-3 h-3" />} size="small" color="success" />
                  )}
                  {strategy.requirements.crossChain && (
                    <Chip label="Cross-Chain" icon={<Network className="w-3 h-3" />} size="small" color="primary" />
                  )}
                  {strategy.requirements.multiDex && (
                    <Chip label="Multi-DEX" icon={<TrendUp className="w-3 h-3" />} size="small" color="secondary" />
                  )}
                  {strategy.requirements.atomicSwap && (
                    <Chip label="Atomic Swap" icon={<Shield className="w-3 h-3" />} size="small" color="info" />
                  )}
                </div>

                {/* Blockchains soportadas */}
                <Typography variant="subtitle2" className="font-bold mb-2">
                  🌐 Blockchains Soportadas
                </Typography>
                <div className="flex flex-wrap gap-1">
                  {strategy.supportedBlockchains.map(blockchain => (
                    <Chip 
                      key={blockchain}
                      label={blockchain}
                      size="small"
                      variant="outlined"
                    />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>

        <CardActions className="px-4 pb-4">
          <div className="flex items-center justify-between w-full">
            <Button
              variant="outlined"
              size="small"
              onClick={(e) => {
                e.stopPropagation()
                setIsExpanded(!isExpanded)
              }}
              endIcon={isExpanded ? <ExpandLess /> : <ExpandMore />}
            >
              {isExpanded ? 'Menos detalles' : 'Más detalles'}
            </Button>

            {isSelected && (
              <Chip
                label="SELECCIONADA"
                color="primary"
                variant="filled"
                size="small"
              />
            )}
          </div>
        </CardActions>
      </Card>
    </motion.div>
  )
}

export const StrategySelectorPanel: React.FC<StrategySelectorPanelProps> = ({
  selectedStrategy,
  onStrategyChange,
  environment
}) => {
  const [enabledStrategies, setEnabledStrategies] = useKV<string[]>('enabled-strategies', [
    'crossChainFlashLoanMultiHop',
    'triangular-inter-dex',
    'basic-cross-dex'
  ])

  const [sortBy, setSortBy] = useState<'roi' | 'complexity' | 'risk' | 'profit'>('roi')

  const handleStrategyToggle = (strategyId: string, enabled: boolean) => {
    setEnabledStrategies(prev => 
      enabled 
        ? [...prev, strategyId]
        : prev.filter(id => id !== strategyId)
    )
  }

  // Ordenar estrategias
  const sortedStrategies = [...strategies].sort((a, b) => {
    switch (sortBy) {
      case 'roi':
        return b.roi2025 - a.roi2025
      case 'complexity':
        const complexityOrder = { low: 1, medium: 2, high: 3, expert: 4 }
        return complexityOrder[a.complexity] - complexityOrder[b.complexity]
      case 'risk':
        const riskOrder = { low: 1, medium: 2, high: 3 }
        return riskOrder[a.riskLevel] - riskOrder[b.riskLevel]
      case 'profit':
        return b.avgProfitPercentage - a.avgProfitPercentage
      default:
        return b.roi2025 - a.roi2025
    }
  })

  const enabledCount = enabledStrategies.length
  const totalPotentialProfit = sortedStrategies
    .filter(s => enabledStrategies.includes(s.id))
    .reduce((sum, s) => sum + s.avgProfitPercentage, 0)

  return (
    <Paper elevation={3} className="p-6">
      {/* Header */}
      <Box className="mb-6">
        <Typography variant="h5" className="font-bold mb-2">
          🎯 Selector de Estrategias de Arbitraje
        </Typography>
        <Typography variant="subtitle2" className="text-muted-foreground mb-4">
          Configura y selecciona las estrategias de trading automático
        </Typography>

        {/* Estadísticas */}
        <GridFour container spacing={3} className="mb-4">
          <GridFour item xs={12} sm={4}>
            <Box className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <Typography variant="h4" className="font-bold text-blue-600">
                {enabledCount}
              </Typography>
              <Typography variant="caption" className="text-muted-foreground">
                Estrategias Habilitadas
              </Typography>
            </Box>
          </GridFour>
          <GridFour item xs={12} sm={4}>
            <Box className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <Typography variant="h4" className="font-bold text-green-600">
                {formatPercentage(totalPotentialProfit)}
              </Typography>
              <Typography variant="caption" className="text-muted-foreground">
                Potencial Combinado
              </Typography>
            </Box>
          </GridFour>
          <GridFour item xs={12} sm={4}>
            <Box className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <Typography variant="h4" className="font-bold text-purple-600">
                {strategies.length}
              </Typography>
              <Typography variant="caption" className="text-muted-foreground">
                Estrategias Disponibles
              </Typography>
            </Box>
          </GridFour>
        </GridFour>

        {/* Alertas */}
        {environment === 'prod' && enabledCount > 5 && (
          <Alert severity="warning" className="mb-4">
            <Warning className="w-4 h-4 mr-2" />
            <strong>Atención:</strong> Muchas estrategias habilitadas en PRODUCCIÓN pueden aumentar el riesgo.
          </Alert>
        )}

        {enabledCount === 0 && (
          <Alert severity="error" className="mb-4">
            No hay estrategias habilitadas. Selecciona al menos una para comenzar el trading.
          </Alert>
        )}
      </Box>

      {/* GridFour de estrategias */}
      <GridFour container spacing={3}>
        {sortedStrategies.map(strategy => (
          <GridFour item xs={12} md={6} lg={4} key={strategy.id}>
            <StrategyCard
              strategy={strategy}
              isSelected={selectedStrategy === strategy.id}
              isEnabled={enabledStrategies.includes(strategy.id)}
              onSelect={() => onStrategyChange(strategy.id)}
              onToggleEnabled={(enabled) => handleStrategyToggle(strategy.id, enabled)}
              environment={environment}
            />
          </GridFour>
        ))}
      </GridFour>
    </Paper>
  )
}

export default StrategySelectorPanel