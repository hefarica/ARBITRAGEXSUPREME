// 💰 REVENUE DASHBOARD - Dashboard principal de ingresos con arquitectura modular
// Inspirado en las mejores prácticas de Balancer V2, Uniswap V4 y Hummingbot

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Badge } from '../ui/badge'
import { 
  CurrencyDollar, 
  TrendUp, 
  Activity, 
  Gear,
  ChartBar3,
  Target,
  Lightning,
  ArrowRight,
  Funnel,
  Repeat
} from 'lucide-react'
import { useKV } from '@/hooks/useKV'
import { useQuery } from '@tanstack/react-query'

// Importar los componentes principales
import { ArbitrageEngineCard } from './ArbitrageEngineCard'
import { HFTEngineCard } from './HFTEngineCard'
import { OpportunitiesPanel } from './OpportunitiesPanel'

// Importar configuración de estrategias
import { strategies, getTopStrategiesByROI, getStrategyById } from '../../config/strategies'
import { StrategyInfo } from '../../types/strategy.types'

// Simulación de métricas consolidadas
const fetchConsolidatedMetrics = async () => {
  await new Promise(resolve => setTimeout(resolve, 150))
  
  return {
    totalProfit24h: Math.random() * 15000 + 5000,
    totalProfitAllTime: Math.random() * 100000 + 50000,
    avgDailyROI: Math.random() * 3 + 1,
    totalTrades: Math.floor(Math.random() * 500) + 200,
    successRate: Math.random() * 15 + 85,
    activeStrategies: Math.floor(Math.random() * 5) + 3,
    topPerformingStrategy: strategies[Math.floor(Math.random() * 3)].id,
    marketCapture: Math.random() * 0.5 + 0.3, // 30-80% market capture
    riskScore: Math.random() * 3 + 2, // 2-5 risk score
    nextOpportunityETA: Math.random() * 300 + 30 // 30-330 seconds
  }
}

interface StrategyConfig {
  id: string
  enabled: boolean
  priority: number
  minProfit: number
  maxRisk: number
}

export const RevenueDashboard: React.FC = () => {
  const [selectedStrategy, setSelectedStrategy] = useKV<string>('selected-strategy', 'cross-chain-multi-hop-flash-loan')
  const [activeTab, setActiveTab] = useState<'overview' | 'opportunities' | 'config'>('overview')
  const [strategyConfigs, setStrategyConfigs] = useKV<Record<string, StrategyConfig>>('strategy-configs', {})

  // Query para métricas consolidadas
  const { 
    data: metrics, 
    isLoading: metricsLoading 
  } = useQuery({
    queryKey: ['consolidated-metrics'],
    queryFn: fetchConsolidatedMetrics,
    refetchInterval: 10000, // Actualiza cada 10 segundos
    staleTime: 5000
  })

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const formatPercent = (value: number) => {
    return `${value.toFixed(2)}%`
  }

  const getSelectedStrategyInfo = (): StrategyInfo | undefined => {
    return getStrategyById(selectedStrategy)
  }

  const topStrategies = getTopStrategiesByROI(5)
  const selectedStrategyInfo = getSelectedStrategyInfo()

  // Configurar una estrategia
  const updateStrategyConfig = (strategyId: string, config: Partial<StrategyConfig>) => {
    setStrategyConfigs(prev => ({
      ...prev,
      [strategyId]: {
        id: strategyId,
        enabled: true,
        priority: 1,
        minProfit: 10,
        maxRisk: 5,
        ...prev[strategyId],
        ...config
      }
    }))
  }

  return (
    <div className="space-y-6">
      {/* Header con métricas consolidadas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Ganancia 24h</p>
                <p className="text-2xl font-bold text-profit">
                  {formatCurrency(metrics?.totalProfit24h || 0)}
                </p>
                <p className="text-xs text-muted-foreground">
                  ROI: {formatPercent(metrics?.avgDailyROI || 0)}
                </p>
              </div>
              <CurrencyDollar className="w-8 h-8 text-profit" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Trades</p>
                <p className="text-2xl font-bold">
                  {metrics?.totalTrades || 0}
                </p>
                <p className="text-xs text-muted-foreground">
                  Éxito: {formatPercent(metrics?.successRate || 0)}
                </p>
              </div>
              <BarChart3 className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Estrategias Activas</p>
                <p className="text-2xl font-bold">
                  {metrics?.activeStrategies || 0}
                </p>
                <p className="text-xs text-muted-foreground">
                  de {strategies.filter(s => s.enabled).length} habilitadas
                </p>
              </div>
              <Target className="w-8 h-8 text-secondary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total P&L</p>
                <p className="text-2xl font-bold text-profit">
                  {formatCurrency(metrics?.totalProfitAllTime || 0)}
                </p>
                <p className="text-xs text-muted-foreground">
                  Captura: {formatPercent((metrics?.marketCapture || 0) * 100)}
                </p>
              </div>
              <TrendUp className="w-8 h-8 text-profit" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Selector de estrategia principal */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Gear className="w-5 h-5" />
              Estrategia Principal Activa
            </CardTitle>
            <Badge 
              variant={selectedStrategyInfo?.enabled ? "default" : "secondary"}
              className="text-xs"
            >
              {selectedStrategyInfo?.enabled ? 'Activa' : 'Inactiva'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center">
            <div className="flex-1">
              <Select value={selectedStrategy} onValueChange={setSelectedStrategy}>
                <SelectTrigger className="w-full lg:w-80">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {strategies.map(strategy => (
                    <SelectItem key={strategy.id} value={strategy.id}>
                      <div className="flex items-center justify-between w-full">
                        <span className="truncate">{strategy.label}</span>
                        <div className="flex items-center gap-2 ml-4">
                          <Badge variant="outline" className="text-xs">
                            ROI: {strategy.roi2025}
                          </Badge>
                          <Badge 
                            variant={
                              strategy.riskLevel === 'low' ? 'default' :
                              strategy.riskLevel === 'medium' ? 'secondary' :
                              'destructive'
                            }
                            className="text-xs"
                          >
                            {strategy.riskLevel}
                          </Badge>
                        </div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedStrategyInfo && (
              <div className="flex-1 lg:flex-2">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">ROI Estimado 2025</p>
                      <p className="font-semibold">{selectedStrategyInfo.roi2025}/10</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Complejidad</p>
                      <p className="font-semibold capitalize">{selectedStrategyInfo.complexity}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Capital Mín.</p>
                      <p className="font-semibold">
                        {formatCurrency(selectedStrategyInfo.requirements.minCapital)}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Tasa Éxito</p>
                      <p className="font-semibold text-profit">
                        {formatPercent(selectedStrategyInfo.metrics.successRate)}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    {selectedStrategyInfo.description}
                  </p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tabs principales */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Motores de Ingresos
          </TabsTrigger>
          <TabsTrigger value="opportunities" className="flex items-center gap-2">
            <TrendUp className="w-4 h-4" />
            Oportunidades
          </TabsTrigger>
          <TabsTrigger value="config" className="flex items-center gap-2">
            <Gear className="w-4 h-4" />
            Configuración
          </TabsTrigger>
        </TabsList>

        {/* Tab de Motores de Ingresos */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ArbitrageEngineCard />
            <HFTEngineCard />
          </div>

          {/* Top Strategies Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Top 5 Estrategias por ROI 2025
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {topStrategies.map((strategy, index) => (
                  <div 
                    key={strategy.id}
                    className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="w-8 h-8 rounded-full flex items-center justify-center">
                        {index + 1}
                      </Badge>
                      <div>
                        <p className="font-medium">{strategy.label}</p>
                        <p className="text-xs text-muted-foreground">
                          {strategy.category} • {strategy.complexity}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-semibold">ROI: {strategy.roi2025}/10</p>
                        <p className="text-xs text-muted-foreground">
                          {formatPercent(strategy.metrics.avgProfit)} avg
                        </p>
                      </div>
                      
                      <Button
                        size="sm"
                        variant={strategy.id === selectedStrategy ? "default" : "outline"}
                        onClick={() => setSelectedStrategy(strategy.id)}
                      >
                        {strategy.id === selectedStrategy ? "Activa" : "Seleccionar"}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Oportunidades */}
        <TabsContent value="opportunities" className="space-y-6">
          <OpportunitiesPanel />
        </TabsContent>

        {/* Tab de Configuración */}
        <TabsContent value="config" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Estrategias</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {strategies.slice(0, 8).map(strategy => {
                  const config = strategyConfigs[strategy.id]
                  return (
                    <div 
                      key={strategy.id}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-medium">{strategy.label}</h4>
                          <Badge 
                            variant={strategy.enabled ? "default" : "secondary"}
                            className="text-xs"
                          >
                            {strategy.enabled ? 'Disponible' : 'Deshabilitada'}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {strategy.category}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {strategy.description}
                        </p>
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
                          <span>ROI: {strategy.roi2025}/10</span>
                          <span>Riesgo: {strategy.riskLevel}</span>
                          <span>Min: {formatCurrency(strategy.requirements.minCapital)}</span>
                          <span>Éxito: {formatPercent(strategy.metrics.successRate)}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant={config?.enabled ? "destructive" : "default"}
                          onClick={() => updateStrategyConfig(strategy.id, { 
                            enabled: !config?.enabled 
                          })}
                          disabled={!strategy.enabled}
                        >
                          {config?.enabled ? "Desactivar" : "Activar"}
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}