// src/components/revenue/StrategySelector.tsx
import React, { useState, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import { 
  Strategy, 
  MagnifyingGlass, 
  Funnel, 
  TrendUp, 
  WarningCircle,
  CheckCircle,
  Star,
  CurrencyDollar,
  Clock,
  Shield
} from '@phosphor-icons/react'
import { TRADING_STRATEGIES, getStrategiesByFunnels, calculatePortfolioROI, TradingStrategy } from './strategies'
import { useFeatureFlags } from '@/hooks/useFeatureFlags'

interface StrategySelectorProps {
  selectedStrategies: string[]
  onStrategiesChange: (strategies: string[]) => void
  environment: 'test' | 'prod'
}

export const StrategySelector: React.FC<StrategySelectorProps> = ({
  selectedStrategies,
  onStrategiesChange,
  environment
}) => {
  const { isFeatureEnabled } = useFeatureFlags(environment)
  const [searchTerm, setMagnifyingGlassTerm] = useState('')
  const [filters, setFunnels] = useState({
    category: 'all' as 'all' | TradingStrategy['category'],
    complexity: 'all' as 'all' | TradingStrategy['complexity'],
    riskLevel: 'all' as 'all' | TradingStrategy['riskLevel'],
    enabledOnly: true,
    minROI: 0,
    maxCapital: 1000000
  })
  const [sortBy, setSortBy] = useState<'roi' | 'risk' | 'capital' | 'success'>('roi')

  // Filtrar y ordenar estrategias
  const filteredStrategies = useMemo(() => {
    let strategies = getStrategiesByFunnels({
      category: filters.category === 'all' ? undefined : filters.category,
      complexity: filters.complexity === 'all' ? undefined : filters.complexity,
      riskLevel: filters.riskLevel === 'all' ? undefined : filters.riskLevel,
      enabledOnly: filters.enabledOnly,
      minROI: filters.minROI,
      maxCapital: filters.maxCapital
    })

    // Filtro de búsqueda
    if (searchTerm) {
      strategies = strategies.filter(strategy =>
        strategy.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        strategy.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Ordenamiento
    strategies.sort((a, b) => {
      switch (sortBy) {
        case 'roi':
          return b.expectedROI.daily - a.expectedROI.daily
        case 'risk':
          const riskOrder = { 'low': 1, 'medium': 2, 'high': 3, 'extreme': 4 }
          return riskOrder[a.riskLevel] - riskOrder[b.riskLevel]
        case 'capital':
          return a.requiredCapital - b.requiredCapital
        case 'success':
          return b.successRate - a.successRate
        default:
          return 0
      }
    })

    return strategies
  }, [searchTerm, filters, sortBy])

  // Calcular ROI total del portfolio seleccionado
  const portfolioROI = calculatePortfolioROI(selectedStrategies)

  // Handlers
  const handleStrategyToggle = (strategyId: string) => {
    const newSelection = selectedStrategies.includes(strategyId)
      ? selectedStrategies.filter(id => id !== strategyId)
      : [...selectedStrategies, strategyId]
    
    onStrategiesChange(newSelection)
  }

  const handleSelectAll = () => {
    const enabledStrategies = filteredStrategies.filter(s => s.enabled).map(s => s.id)
    onStrategiesChange(enabledStrategies)
  }

  const handleClearAll = () => {
    onStrategiesChange([])
  }

  const handlePresetSelection = (preset: 'conservative' | 'balanced' | 'aggressive') => {
    let presetStrategies: string[] = []
    
    switch (preset) {
      case 'conservative':
        presetStrategies = filteredStrategies
          .filter(s => s.riskLevel === 'low' && s.enabled)
          .slice(0, 3)
          .map(s => s.id)
        break
      case 'balanced':
        presetStrategies = filteredStrategies
          .filter(s => ['low', 'medium'].includes(s.riskLevel) && s.enabled)
          .slice(0, 5)
          .map(s => s.id)
        break
      case 'aggressive':
        presetStrategies = filteredStrategies
          .filter(s => s.enabled)
          .slice(0, 8)
          .map(s => s.id)
        break
    }
    
    onStrategiesChange(presetStrategies)
  }

  // Componente para renderizar una estrategia individual
  const StrategyCard: React.FC<{ strategy: TradingStrategy }> = ({ strategy }) => {
    const isSelected = selectedStrategies.includes(strategy.id)
    
    const getRiskColor = (risk: TradingStrategy['riskLevel']) => {
      switch (risk) {
        case 'low': return 'text-profit bg-profit/10'
        case 'medium': return 'text-warning bg-warning/10'
        case 'high': return 'text-destructive bg-destructive/10'
        case 'extreme': return 'text-destructive bg-destructive/20'
      }
    }

    const getComplexityIcon = (complexity: TradingStrategy['complexity']) => {
      switch (complexity) {
        case 'basic': return '⭐'
        case 'intermediate': return '⭐⭐'
        case 'advanced': return '⭐⭐⭐'
        case 'expert': return '⭐⭐⭐⭐'
      }
    }

    return (
      <Card 
        className={`cursor-pointer transition-all hover:shadow-md ${
          isSelected ? 'border-primary bg-primary/5' : 'border-border'
        } ${!strategy.enabled ? 'opacity-60' : ''}`}
        onClick={() => strategy.enabled && handleStrategyToggle(strategy.id)}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <Checkbox 
                checked={isSelected} 
                disabled={!strategy.enabled}
                onChange={() => {}} // Controlled by card click
              />
              <div>
                <div className="font-medium text-sm">{strategy.name}</div>
                <div className="text-xs text-muted-foreground">
                  {getComplexityIcon(strategy.complexity)} {strategy.complexity}
                </div>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-lg font-bold text-profit">
                {strategy.expectedROI.daily.toFixed(2)}%
              </div>
              <div className="text-xs text-muted-foreground">diario</div>
            </div>
          </div>

          <div className="text-xs text-muted-foreground mb-3 line-clamp-2">
            {strategy.description}
          </div>

          <div className="flex flex-wrap gap-1 mb-3">
            <Badge variant="outline" className={getRiskColor(strategy.riskLevel)}>
              {strategy.riskLevel} risk
            </Badge>
            <Badge variant="outline">
              {strategy.category}
            </Badge>
            {strategy.gasEfficiency === 'ultra' && (
              <Badge variant="outline" className="text-profit bg-profit/10">
                ⚡ Ultra Gas
              </Badge>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="text-center">
              <div className="font-medium">${(strategy.requiredCapital / 1000).toFixed(0)}k</div>
              <div className="text-muted-foreground">Capital</div>
            </div>
            <div className="text-center">
              <div className="font-medium">{strategy.successRate}%</div>
              <div className="text-muted-foreground">Éxito</div>
            </div>
            <div className="text-center">
              <div className="font-medium">{strategy.averageExecutionTime}s</div>
              <div className="text-muted-foreground">Tiempo</div>
            </div>
          </div>

          {/* Prerequisites */}
          {strategy.prerequisites.length > 0 && (
            <div className="mt-3 pt-2 border-t">
              <div className="text-xs text-muted-foreground mb-1">Requiere:</div>
              <div className="flex flex-wrap gap-1">
                {strategy.prerequisites.map(prereqId => {
                  const prereq = TRADING_STRATEGIES.find(s => s.id === prereqId)
                  const isPrereqSelected = selectedStrategies.includes(prereqId)
                  return prereq ? (
                    <Badge 
                      key={prereqId} 
                      variant="outline" 
                      className={`text-xs ${isPrereqSelected ? 'text-profit' : 'text-warning'}`}
                    >
                      {isPrereqSelected ? '✓' : '!'} {prereq.name.split(' ')[0]}
                    </Badge>
                  ) : null
                })}
              </div>
            </div>
          )}

          {!strategy.enabled && (
            <div className="mt-3 pt-2 border-t">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <WarningCircle className="h-3 w-3" />
                No disponible en {environment.toUpperCase()}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-accent/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Strategy className="h-5 w-5 text-accent" />
            Selector de Estrategias de Trading
          </CardTitle>
          
          {selectedStrategies.length > 0 && (
            <Badge variant="outline" className="bg-primary/10">
              {selectedStrategies.length} seleccionadas
            </Badge>
          )}
        </div>

        {/* Portfolio ROI Summary */}
        {selectedStrategies.length > 0 && (
          <div className="bg-gradient-to-r from-profit/10 to-primary/10 p-4 rounded-lg">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-profit">
                  {portfolioROI.daily.toFixed(2)}%
                </div>
                <div className="text-sm text-muted-foreground">ROI Diario</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-profit">
                  {portfolioROI.monthly.toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">ROI Mensual</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-profit">
                  {portfolioROI.annual.toFixed(0)}%
                </div>
                <div className="text-sm text-muted-foreground">ROI Anual</div>
              </div>
            </div>
          </div>
        )}
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="selector" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="selector">Selector</TabsTrigger>
            <TabsTrigger value="filters">Filtros</TabsTrigger>
          </TabsList>

          <TabsContent value="selector" className="space-y-4">
            {/* Controles principales */}
            <div className="flex flex-wrap gap-2 justify-between items-center">
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handlePresetSelection('conservative')}
                >
                  <Shield className="h-4 w-4 mr-1" />
                  Conservador
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handlePresetSelection('balanced')}
                >
                  <TrendUp className="h-4 w-4 mr-1" />
                  Balanceado
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handlePresetSelection('aggressive')}
                >
                  <Star className="h-4 w-4 mr-1" />
                  Agresivo
                </Button>
              </div>
              
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={handleSelectAll}>
                  Seleccionar Filtradas
                </Button>
                <Button size="sm" variant="outline" onClick={handleClearAll}>
                  Limpiar Todo
                </Button>
              </div>
            </div>

            <Separator />

            {/* Lista de estrategias */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredStrategies.map(strategy => (
                <StrategyCard key={strategy.id} strategy={strategy} />
              ))}
            </div>

            {filteredStrategies.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Strategy className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <div>No se encontraron estrategias con los filtros aplicados</div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="filters" className="space-y-4">
            {/* Búsqueda */}
            <div className="relative">
              <MagnifyingGlass className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar estrategias..."
                value={searchTerm}
                onChange={(e) => setMagnifyingGlassTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filtros */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <Label>Categoría</Label>
                <Select value={filters.category} onValueChange={(value: any) => setFunnels(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    <SelectItem value="arbitrage">Arbitraje</SelectItem>
                    <SelectItem value="hft">HFT</SelectItem>
                    <SelectItem value="hybrid">Híbrido</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Complejidad</Label>
                <Select value={filters.complexity} onValueChange={(value: any) => setFunnels(prev => ({ ...prev, complexity: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    <SelectItem value="basic">Básica</SelectItem>
                    <SelectItem value="intermediate">Intermedia</SelectItem>
                    <SelectItem value="advanced">Avanzada</SelectItem>
                    <SelectItem value="expert">Experto</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Riesgo</Label>
                <Select value={filters.riskLevel} onValueChange={(value: any) => setFunnels(prev => ({ ...prev, riskLevel: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="low">Bajo</SelectItem>
                    <SelectItem value="medium">Medio</SelectItem>
                    <SelectItem value="high">Alto</SelectItem>
                    <SelectItem value="extreme">Extremo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Ordenar por</Label>
                <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="roi">ROI</SelectItem>
                    <SelectItem value="risk">Riesgo</SelectItem>
                    <SelectItem value="capital">Capital</SelectItem>
                    <SelectItem value="success">Éxito</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Filtros adicionales */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enabledOnly"
                  checked={filters.enabledOnly}
                  onCheckedChange={(checked) => setFunnels(prev => ({ ...prev, enabledOnly: !!checked }))}
                />
                <Label htmlFor="enabledOnly">Solo estrategias habilitadas</Label>
              </div>

              <div>
                <Label>ROI mínimo diario (%)</Label>
                <Input
                  type="number"
                  value={filters.minROI}
                  onChange={(e) => setFunnels(prev => ({ ...prev, minROI: parseFloat(e.target.value) || 0 }))}
                  min="0"
                  step="0.1"
                />
              </div>

              <div>
                <Label>Capital máximo (USD)</Label>
                <Input
                  type="number"
                  value={filters.maxCapital}
                  onChange={(e) => setFunnels(prev => ({ ...prev, maxCapital: parseFloat(e.target.value) || 1000000 }))}
                  min="0"
                  step="1000"
                />
              </div>
            </div>

            {/* Estadísticas de filtros */}
            <div className="bg-muted/30 p-4 rounded-lg">
              <div className="text-sm text-muted-foreground mb-2">
                Mostrando {filteredStrategies.length} de {TRADING_STRATEGIES.length} estrategias
              </div>
              <div className="text-xs text-muted-foreground">
                Habilitadas: {filteredStrategies.filter(s => s.enabled).length} | 
                Seleccionadas: {selectedStrategies.length}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}