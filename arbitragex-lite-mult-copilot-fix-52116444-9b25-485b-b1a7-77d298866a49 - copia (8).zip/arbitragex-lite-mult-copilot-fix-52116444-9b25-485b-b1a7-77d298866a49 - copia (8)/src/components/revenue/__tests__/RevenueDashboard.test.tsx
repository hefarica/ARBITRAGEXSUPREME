// src/components/revenue/__tests__/RevenueDashboard.test.tsx

import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { vi, describe, test, expect, beforeEach } from 'vitest'
import RevenueDashboard from '../RevenueDashboard'

// Mock del hook useKV
vi.mock('@github/spark/hooks', () => ({
  useKV: vi.fn(() => [false, vi.fn(), vi.fn()])
}))

// Mock de feature flags
vi.mock('@/hooks/useFeatureFlags', () => ({
  useFeatureFlags: vi.fn(() => ({
    isFeatureEnabled: vi.fn().mockReturnValue(true)
  }))
}))

// Mock de cache hooks
vi.mock('@/hooks/useCacheWithFallback', () => ({
  useCacheWithFallback: vi.fn(() => ({
    data: {
      opportunitiesCount: 5,
      estimatedProfit: 250.75,
      activeStrategies: ['basic-cross-dex'],
      status: 'idle',
      totalProfit24h: 1500.50,
      successRate: 95.5,
      avgExecutionTime: 12.5,
      gasEfficiency: 85.2
    },
    isLoading: false,
    error: null,
    isUsingCachedData: false,
    forceArrowClockwise: vi.fn()
  }))
}))

describe('RevenueDashboard', () => {
  let queryClient: QueryClient

  beforeEach(() => {
    queryClient = new QueryClient({
      defaultOptions: {
        queries: { retry: false },
        mutations: { retry: false }
      }
    })
  })

  const renderDashboard = (environment: 'test' | 'prod' = 'test') => {
    return render(
      <QueryClientProvider client={queryClient}>
        <RevenueDashboard environment={environment} />
      </QueryClientProvider>
    )
  }

  test('renderiza correctamente el dashboard principal', async () => {
    renderDashboard()
    
    // Verificar título principal
    expect(screen.getByText(/Revenue Dashboard - Motores de Ingresos/)).toBeInTheDocument()
    
    // Verificar indicadores de ambiente
    expect(screen.getByText('TEST')).toBeInTheDocument()
    
    // Verificar métricas totales
    expect(screen.getByText('Revenue 24h')).toBeInTheDocument()
    expect(screen.getByText('Oportunidades Activas')).toBeInTheDocument()
  })

  test('valida contratos de los motores de arbitraje y HFT', async () => {
    renderDashboard()
    
    // Verificar que ambos motores están presentes
    await waitFor(() => {
      expect(screen.getByTestId('arbitrage-engine-card')).toBeInTheDocument()
      expect(screen.getByTestId('hft-engine-card')).toBeInTheDocument()
    })
  })

  test('ejecuta arbitraje manual correctamente', async () => {
    const mockMutation = vi.fn().mockResolvedValue({
      profit: 125.50,
      success: true,
      strategies: ['basic-cross-dex']
    })

    global.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockMutation())
    })

    renderDashboard()
    
    const runButton = screen.getByRole('button', { name: /run now/i })
    fireEvent.click(runButton)
    
    await waitFor(() => {
      expect(mockMutation).toHaveBeenCalled()
    })
  })

  test('maneja errores de API correctamente', async () => {
    global.fetch = vi.fn().mockRejectedValue(new Error('API Error'))
    
    renderDashboard()
    
    // El componente debe usar datos de fallback sin fallar
    expect(screen.getByText(/Revenue Dashboard/)).toBeInTheDocument()
  })

  test('valida feature flags en modo producción', () => {
    renderDashboard('prod')
    
    // En producción, verificar que las funcionalidades están controladas
    expect(screen.getByText('PROD')).toBeInTheDocument()
  })
})