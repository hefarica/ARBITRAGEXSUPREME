// src/components/revenue/__tests__/OpportunitiesPanel.test.tsx

import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { vi, describe, test, expect, beforeEach } from 'vitest'
import OpportunitiesPanel from '../OpportunitiesPanel'

// Mock de hooks y dependencias
vi.mock('@github/spark/hooks', () => ({
  useKV: vi.fn(() => [false, vi.fn(), vi.fn()])
}))

vi.mock('@/hooks/useCacheWithFallback', () => ({
  useCacheWithFallback: vi.fn(() => ({
    data: [
      {
        id: 'opp_1',
        strategy: 'basic-cross-dex',
        strategyName: 'Basic Cross-DEX',
        assets: ['ETH', 'USDC'],
        dex: 'Uniswap V3',
        chain: 'ethereum',
        chainId: 1,
        profitUSD: 125.50,
        riskScore: 25,
        executionTime: 8,
        confidence: 0.95,
        gasEstimate: 45,
        expiresAt: new Date(Date.now() + 60000),
        lastDetected: new Date(),
        minCapital: 1000,
        liquidityDepth: 50000,
        competitorCount: 2
      }
    ],
    isLoading: false,
    error: null,
    isUsingCachedData: false,
    forceArrowClockwise: vi.fn()
  }))
}))

vi.mock('@/lib/wasmArbitrage', () => ({
  useWasmArbitrage: vi.fn(() => ({
    findOpportunities: vi.fn(),
    optimizePath: vi.fn(),
    isReady: true,
    error: null
  }))
}))

describe('OpportunitiesPanel', () => {
  let queryClient: QueryClient

  beforeEach(() => {
    queryClient = new QueryClient({
      defaultOptions: {
        queries: { retry: false },
        mutations: { retry: false }
      }
    })
  })

  const renderPanel = (environment: 'test' | 'prod' = 'test') => {
    return render(
      <QueryClientProvider client={queryClient}>
        <OpportunitiesPanel environment={environment} />
      </QueryClientProvider>
    )
  }

  test('renderiza el panel de oportunidades correctamente', async () => {
    renderPanel()
    
    // Verificar título
    expect(screen.getByText(/Panel de Oportunidades en Tiempo Real/)).toBeInTheDocument()
    
    // Verificar estadísticas
    expect(screen.getByText('Oportunidades')).toBeInTheDocument()
    expect(screen.getByText('Profit Total')).toBeInTheDocument()
    
    // Verificar tabla
    expect(screen.getByText('Estrategia')).toBeInTheDocument()
    expect(screen.getByText('Basic Cross-DEX')).toBeInTheDocument()
  })

  test('filtra oportunidades por estrategia correctamente', async () => {
    renderPanel()
    
    // Encontrar y usar el filtro de estrategia
    const strategySelect = screen.getByRole('combobox')
    fireEvent.click(strategySelect)
    
    // En un test real, verificaríamos el filtrado
    expect(screen.getByText('Basic Cross-DEX')).toBeInTheDocument()
  })

  test('ejecuta oportunidad cuando se hace clic en Execute', async () => {
    const mockExecute = vi.fn()
    
    renderPanel()
    
    const executeButton = screen.getByRole('button', { name: /execute/i })
    fireEvent.click(executeButton)
    
    // Verificar que se inicia la ejecución
    await waitFor(() => {
      expect(executeButton).toBeDisabled()
    })
  })

  test('muestra estado de cache cuando usa datos cacheados', () => {
    // Mock para mostrar estado de cache
    vi.mocked(require('@/hooks/useCacheWithFallback').useCacheWithFallback).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
      isUsingCachedData: true,
      forceArrowClockwise: vi.fn()
    })
    
    renderPanel()
    
    expect(screen.getByText('CACHE')).toBeInTheDocument()
  })

  test('valida sistema de filtros completo', async () => {
    renderPanel()
    
    // Verificar controles de filtrado
    expect(screen.getByPlaceholderText(/Min Profit/)).toBeInTheDocument()
    expect(screen.getByPlaceholderText(/Max Risk/)).toBeInTheDocument()
    
    // Verificar botones de ordenamiento
    const sortButton = screen.getByRole('button', { name: /desc/i })
    expect(sortButton).toBeInTheDocument()
  })

  test('maneja errores de API gracefully', () => {
    // Mock error state
    vi.mocked(require('@/hooks/useCacheWithFallback').useCacheWithFallback).mockReturnValue({
      data: null,
      isLoading: false,
      error: new Error('API Error'),
      isUsingCachedData: false,
      forceArrowClockwise: vi.fn()
    })
    
    renderPanel()
    
    expect(screen.getByText(/Error al cargar oportunidades/)).toBeInTheDocument()
  })

  test('refresh manual funciona correctamente', async () => {
    const mockArrowClockwise = vi.fn()
    
    vi.mocked(require('@/hooks/useCacheWithFallback').useCacheWithFallback).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
      isUsingCachedData: false,
      forceArrowClockwise: mockArrowClockwise
    })
    
    renderPanel()
    
    const refreshButton = screen.getByRole('button', { name: /refresh/i })
    fireEvent.click(refreshButton)
    
    expect(mockArrowClockwise).toHaveBeenCalled()
  })
})