import React, { useState, useEffect } from 'react'
import { 
  Paper, 
  Typography, 
  Box, 
  Alert,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  IconButton,
  Button,
  Collapse,
  Badge
} from '@mui/material'
import { 
  WarningCircle, 
  CheckCircle, 
  Info, 
  X, 
  ExpandMore, 
  ExpandLess, 
  Bell, 
  BellOff,
  TrendUp,
  Clock,
  CurrencyDollar,
  Shield
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { formatCurrency } from '@/lib/utils'
import { Opportunity } from './OpportunitiesPanel'
import { toast } from 'sonner'

interface AlertCenterProps {
  environment: 'test' | 'prod'
  systemStatus: 'idle' | 'running' | 'error'
  opportunities: Opportunity[]
}

interface SystemAlert {
  id: string
  type: 'success' | 'warning' | 'error' | 'info'
  title: string
  message: string
  timestamp: Date
  isRead: boolean
  category: 'system' | 'trading' | 'security' | 'opportunity'
  priority: 'low' | 'medium' | 'high' | 'critical'
  data?: any
}

const AlertCenter: React.FC<AlertCenterProps> = ({
  environment,
  systemStatus,
  opportunities
}) => {
  const [alerts, setAlerts] = useState<SystemAlert[]>([])
  const [isExpanded, setIsExpanded] = useState(false)
  const [mutedCategories, setMutedCategories] = useState<string[]>([])

  // Generar alertas del sistema
  useEffect(() => {
    const generateSystemAlerts = () => {
      const newAlerts: SystemAlert[] = []

      // Alert de entorno
      if (environment === 'prod') {
        newAlerts.push({
          id: `env-${Date.now()}`,
          type: 'warning',
          title: 'Modo Producción Activo',
          message: 'El sistema está operando con fondos reales. Extrema precaución.',
          timestamp: new Date(),
          isRead: false,
          category: 'system',
          priority: 'high'
        })
      }

      // Alertas de oportunidades
      const highValueOpportunities = opportunities.filter(opp => 
        opp.estimatedProfit > 1000 && opp.isExecutable
      )
      
      if (highValueOpportunities.length > 0) {
        newAlerts.push({
          id: `high-value-${Date.now()}`,
          type: 'success',
          title: 'Oportunidades de Alto Valor',
          message: `${highValueOpportunities.length} oportunidades >$1,000 USD detectadas`,
          timestamp: new Date(),
          isRead: false,
          category: 'opportunity',
          priority: 'medium',
          data: { count: highValueOpportunities.length }
        })
      }

      // Alertas de riesgo
      const highRiskOpportunities = opportunities.filter(opp => 
        opp.riskScore > 8 && opp.isExecutable
      )
      
      if (highRiskOpportunities.length > 0) {
        newAlerts.push({
          id: `high-risk-${Date.now()}`,
          type: 'warning',
          title: 'Oportunidades de Alto Riesgo',
          message: `${highRiskOpportunities.length} oportunidades con riesgo >8 detectadas`,
          timestamp: new Date(),
          isRead: false,
          category: 'security',
          priority: 'high',
          data: { count: highRiskOpportunities.length }
        })
      }

      // Alertas de sistema
      if (systemStatus === 'error') {
        newAlerts.push({
          id: `system-error-${Date.now()}`,
          type: 'error',
          title: 'Error del Sistema',
          message: 'Se detectó un error en el motor de ejecución',
          timestamp: new Date(),
          isRead: false,
          category: 'system',
          priority: 'critical'
        })
      }

      return newAlerts
    }

    const newAlerts = generateSystemAlerts()
    setAlerts(prev => {
      // Evitar duplicados
      const existingIds = prev.map(a => a.id)
      const uniqueNewAlerts = newAlerts.filter(a => !existingIds.includes(a.id))
      return [...prev, ...uniqueNewAlerts]
    })
  }, [environment, systemStatus, opportunities])

  // Auto-limpiar alertas antiguas
  useEffect(() => {
    const interval = setInterval(() => {
      setAlerts(prev => 
        prev.filter(alert => 
          Date.now() - alert.timestamp.getTime() < 24 * 60 * 60 * 1000 // 24 horas
        )
      )
    }, 60000) // Cada minuto

    return () => clearInterval(interval)
  }, [])

  const getAlertIcon = (type: SystemAlert['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case 'warning':
        return <WarningCircle className="w-5 h-5 text-yellow-500" />
      case 'error':
        return <X className="w-5 h-5 text-red-500" />
      default:
        return <Info className="w-5 h-5 text-blue-500" />
    }
  }

  const getAlertSeverity = (type: SystemAlert['type']) => {
    switch (type) {
      case 'success':
        return 'success'
      case 'warning':
        return 'warning'
      case 'error':
        return 'error'
      default:
        return 'info'
    }
  }

  const markAsRead = (alertId: string) => {
    setAlerts(prev => 
      prev.map(alert => 
        alert.id === alertId ? { ...alert, isRead: true } : alert
      )
    )
  }

  const removeAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId))
  }

  const toggleMuteCategory = (category: string) => {
    setMutedCategories(prev => 
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    )
    
    toast.info(`Categoría "${category}" ${mutedCategories.includes(category) ? 'activada' : 'silenciada'}`)
  }

  const clearAllAlerts = () => {
    setAlerts([])
    toast.success('Todas las alertas han sido eliminadas')
  }

  const unreadAlerts = alerts.filter(alert => !alert.isRead)
  const criticalAlerts = alerts.filter(alert => alert.priority === 'critical')
  const visibleAlerts = alerts.filter(alert => !mutedCategories.includes(alert.category))

  return (
    <Paper elevation={2} className="mt-6">
      {/* Header */}
      <Box 
        className="p-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-900/20"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Badge badgeContent={unreadAlerts.length} color="error">
              <Bell className="w-5 h-5" />
            </Badge>
            <Typography variant="h6" className="font-bold">
              Centro de Alertas
            </Typography>
            {criticalAlerts.length > 0 && (
              <Chip 
                label={`${criticalAlerts.length} CRÍTICAS`}
                color="error"
                size="small"
                className="animate-pulse"
              />
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <Typography variant="caption" className="text-muted-foreground">
              {visibleAlerts.length} alertas
            </Typography>
            {isExpanded ? <ExpandLess /> : <ExpandMore />}
          </div>
        </div>
      </Box>

      {/* Alertas críticas siempre visibles */}
      <AnimatePresence>
        {criticalAlerts.map(alert => (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="px-4 pb-2"
          >
            <Alert 
              severity="error"
              action={
                <IconButton
                  size="small"
                  onClick={() => removeAlert(alert.id)}
                >
                  <X className="w-4 h-4" />
                </IconButton>
              }
              className="animate-pulse"
            >
              <Typography variant="subtitle2" className="font-bold">
                {alert.title}
              </Typography>
              <Typography variant="body2">
                {alert.message}
              </Typography>
            </Alert>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Panel expandible */}
      <Collapse in={isExpanded}>
        <Box className="border-t">
          {/* Controles */}
          <Box className="p-4 bg-gray-50 dark:bg-gray-900/20 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button
                  size="small"
                  variant="outlined"
                  onClick={() => toggleMuteCategory('opportunity')}
                  startIcon={mutedCategories.includes('opportunity') ? <BellOff /> : <Bell />}
                >
                  Oportunidades
                </Button>
                <Button
                  size="small"
                  variant="outlined"
                  onClick={() => toggleMuteCategory('system')}
                  startIcon={mutedCategories.includes('system') ? <BellOff /> : <Bell />}
                >
                  Sistema
                </Button>
                <Button
                  size="small"
                  variant="outlined"
                  onClick={() => toggleMuteCategory('security')}
                  startIcon={mutedCategories.includes('security') ? <BellOff /> : <Bell />}
                >
                  Seguridad
                </Button>
              </div>
              
              <Button
                size="small"
                variant="text"
                color="error"
                onClick={clearAllAlerts}
                disabled={alerts.length === 0}
              >
                Limpiar Todo
              </Button>
            </div>
          </Box>

          {/* Lista de alertas */}
          <Box className="max-h-96 overflow-y-auto">
            {visibleAlerts.length > 0 ? (
              <List>
                <AnimatePresence>
                  {visibleAlerts
                    .sort((a, b) => {
                      // Ordenar por prioridad y fecha
                      const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 }
                      const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority]
                      if (priorityDiff !== 0) return priorityDiff
                      return b.timestamp.getTime() - a.timestamp.getTime()
                    })
                    .map(alert => (
                      <motion.div
                        key={alert.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ duration: 0.3 }}
                      >
                        <ListItem
                          className={`
                            hover:bg-gray-50 dark:hover:bg-gray-900/20 cursor-pointer
                            ${!alert.isRead ? 'bg-blue-50 dark:bg-blue-900/10' : ''}
                          `}
                          onClick={() => markAsRead(alert.id)}
                        >
                          <ListItemIcon>
                            {getAlertIcon(alert.type)}
                          </ListItemIcon>
                          
                          <ListItemText
                            primary={
                              <div className="flex items-center justify-between">
                                <Typography 
                                  variant="subtitle2" 
                                  className={`${!alert.isRead ? 'font-bold' : 'font-medium'}`}
                                >
                                  {alert.title}
                                </Typography>
                                <div className="flex items-center gap-2">
                                  <Chip 
                                    label={alert.category}
                                    size="small"
                                    variant="outlined"
                                  />
                                  <Typography variant="caption" className="text-muted-foreground">
                                    {alert.timestamp.toLocaleTimeString()}
                                  </Typography>
                                </div>
                              </div>
                            }
                            secondary={
                              <Typography variant="body2" className="text-muted-foreground">
                                {alert.message}
                              </Typography>
                            }
                          />
                          
                          <IconButton
                            size="small"
                            onClick={(e) => {
                              e.stopPropagation()
                              removeAlert(alert.id)
                            }}
                          >
                            <X className="w-4 h-4" />
                          </IconButton>
                        </ListItem>
                      </motion.div>
                    ))}
                </AnimatePresence>
              </List>
            ) : (
              <Box className="p-8 text-center">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <Typography variant="h6" className="text-muted-foreground">
                  No hay alertas
                </Typography>
                <Typography variant="body2" className="text-muted-foreground">
                  Todas las alertas han sido atendidas
                </Typography>
              </Box>
            )}
          </Box>
        </Box>
      </Collapse>
    </Paper>
  )
}

export default AlertCenter