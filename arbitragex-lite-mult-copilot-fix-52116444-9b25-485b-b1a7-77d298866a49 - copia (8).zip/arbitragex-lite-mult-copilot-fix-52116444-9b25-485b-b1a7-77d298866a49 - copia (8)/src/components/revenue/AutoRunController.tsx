import React, { useState, useEffect } from 'react'
import { 
  Paper, 
  Typography, 
  GridFour, 
  Card, 
  CardContent,
  Switch,
  Button,
  FormControlLabel,
  Box,
  Slider,
  TextField,
  Select,
  ListItem,
  FormControl,
  InputLabel,
  Alert,
  Chip,
  Divider,
  LinearProgress
} from '@mui/material'
import { 
  Play, 
  Pause, 
  Square, 
  Gear, 
  WarningCircle,
  CheckCircle,
  Clock,
  CurrencyDollar,
  TrendUp,
  Shield,
  Activity,
  Bot
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useKV } from '@/hooks/useKV'
import { formatCurrency } from '@/lib/utils'
import { toast } from 'sonner'

interface AutoRunControllerProps {
  autoRunEnabled: boolean
  onToggleAutoRun: (enabled: boolean) => void
  systemStatus: 'idle' | 'running' | 'error'
  onSystemStatusChange: (status: 'idle' | 'running' | 'error') => void
  environment: 'test' | 'prod'
  currentStrategy: string
}

interface AutoRunConfig {
  minProfitUSD: number
  maxRiskScore: number
  maxGasPriceGwei: number
  executionInterval: number // segundos
  maxDailyOperations: number
  stopLossPercentage: number
  takeProfitPercentage: number
  enableMEVProtection: boolean
  enableNotifications: boolean
  operatingHours: {
    enabled: boolean
    start: string // HH:MM
    end: string // HH:MM
  }
}

interface StatusIndicatorProps {
  status: 'idle' | 'running' | 'error'
  size?: 'small' | 'medium' | 'large'
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({ status, size = 'medium' }) => {
  const sizeClasses = {
    small: 'w-3 h-3',
    medium: 'w-4 h-4',
    large: 'w-6 h-6'
  }

  const getStatusConfig = () => {
    switch (status) {
      case 'running':
        return { 
          color: 'bg-green-500 animate-pulse', 
          label: 'Ejecutando',
          textColor: 'text-green-600'
        }
      case 'error':
        return { 
          color: 'bg-red-500', 
          label: 'Error',
          textColor: 'text-red-600'
        }
      default:
        return { 
          color: 'bg-gray-400', 
          label: 'Inactivo',
          textColor: 'text-gray-600'
        }
    }
  }

  const config = getStatusConfig()

  return (
    <div className="flex items-center gap-2">
      <div className={`${sizeClasses[size]} ${config.color} rounded-full`} />
      <Typography variant="body2" className={config.textColor}>
        {config.label}
      </Typography>
    </div>
  )
}

export const AutoRunController: React.FC<AutoRunControllerProps> = ({
  autoRunEnabled,
  onToggleAutoRun,
  systemStatus,
  onSystemStatusChange,
  environment,
  currentStrategy
}) => {
  // Configuración persistente
  const [config, setConfig] = useKV<AutoRunConfig>('auto-run-config', {
    minProfitUSD: 100,
    maxRiskScore: 5,
    maxGasPriceGwei: 100,
    executionInterval: 10,
    maxDailyOperations: 50,
    stopLossPercentage: 2,
    takeProfitPercentage: 5,
    enableMEVProtection: true,
    enableNotifications: true,
    operatingHours: {
      enabled: false,
      start: '09:00',
      end: '17:00'
    }
  })

  // Estados locales
  const [operationsToday, setOperationsToday] = useState(0)
  const [dailyProfit, setDailyProfit] = useState(0)
  const [dailyLoss, setDailyLoss] = useState(0)
  const [lastExecution, setLastExecution] = useState<Date | null>(null)
  const [nextExecution, setNextExecution] = useState<Date | null>(null)

  // Simulación de estadísticas
  useEffect(() => {
    if (autoRunEnabled && systemStatus === 'running') {
      const interval = setInterval(() => {
        // Simular operaciones ocasionales
        if (Math.random() < 0.3) { // 30% probabilidad cada segundo
          setOperationsToday(prev => prev + 1)
          const profit = Math.random() * 500 + 50
          const isProfit = Math.random() > 0.2 // 80% operaciones exitosas
          
          if (isProfit) {
            setDailyProfit(prev => prev + profit)
          } else {
            setDailyLoss(prev => prev + profit * 0.3)
          }
          
          setLastExecution(new Date())
        }
        
        // Calcular próxima ejecución
        setNextExecution(new Date(Date.now() + config.executionInterval * 1000))
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [autoRunEnabled, systemStatus, config.executionInterval])

  const handleToggleAutoRun = (enabled: boolean) => {
    if (enabled) {
      // Verificaciones antes de activar
      if (environment === 'prod' && config.minProfitUSD < 50) {
        toast.error('En PRODUCCIÓN, el profit mínimo debe ser al menos $50 USD')
        return
      }
      
      if (config.maxRiskScore > 8) {
        toast.warning('Riesgo muy alto. Considera reducir el score máximo.')
      }

      onSystemStatusChange('running')
      toast.success('🤖 Auto-Run activado')
    } else {
      onSystemStatusChange('idle')
      toast.info('⏸️ Auto-Run desactivado')
    }
    
    onToggleAutoRun(enabled)
  }

  const handleEmergencyStop = () => {
    onToggleAutoRun(false)
    onSystemStatusChange('idle')
    toast.error('🛑 PARADA DE EMERGENCIA ACTIVADA')
  }

  const isWithinOperatingHours = () => {
    if (!config.operatingHours.enabled) return true
    
    const now = new Date()
    const currentTime = now.getHours() * 100 + now.getMinutes()
    const startTime = parseInt(config.operatingHours.start.replace(':', ''))
    const endTime = parseInt(config.operatingHours.end.replace(':', ''))
    
    return currentTime >= startTime && currentTime <= endTime
  }

  const dailyProfitNet = dailyProfit - dailyLoss
  const operationsRemaining = Math.max(0, config.maxDailyOperations - operationsToday)

  return (
    <Paper elevation={3} className="p-6">
      {/* Header */}
      <Box className="flex items-center justify-between mb-6">
        <div>
          <Typography variant="h5" className="font-bold flex items-center gap-2">
            <Bot className="w-6 h-6" />
            Control Automático
          </Typography>
          <Typography variant="subtitle2" className="text-muted-foreground">
            Configuración y monitoreo de ejecución automática
          </Typography>
        </div>
        
        <div className="flex items-center gap-4">
          <StatusIndicator status={systemStatus} size="large" />
          <Chip 
            label={environment.toUpperCase()}
            color={environment === 'prod' ? 'error' : 'warning'}
            variant="filled"
          />
        </div>
      </Box>

      <GridFour container spacing={4}>
        {/* Panel de Control Principal */}
        <GridFour item xs={12} md={6}>
          <Card>
            <CardContent className="p-4">
              <Typography variant="h6" className="font-bold mb-4">
                🎮 Control Principal
              </Typography>

              {/* Switch principal */}
              <Box className="mb-4">
                <FormControlLabel
                  control={
                    <Switch
                      checked={autoRunEnabled}
                      onChange={(e) => handleToggleAutoRun(e.target.checked)}
                      size="medium"
                      color="primary"
                    />
                  }
                  label={
                    <Typography variant="body1" className="font-medium">
                      {autoRunEnabled ? 'Auto-Run ACTIVO' : 'Auto-Run INACTIVO'}
                    </Typography>
                  }
                />
              </Box>

              {/* Botones de control */}
              <Box className="flex gap-2 mb-4">
                <Button
                  variant="contained"
                  startIcon={systemStatus === 'running' ? <Pause /> : <Play />}
                  onClick={() => handleToggleAutoRun(!autoRunEnabled)}
                  disabled={systemStatus === 'error'}
                  color={systemStatus === 'running' ? 'warning' : 'primary'}
                  fullWidth
                >
                  {systemStatus === 'running' ? 'Pausar' : 'Iniciar'}
                </Button>

                <Button
                  variant="outlined"
                  startIcon={<Square />}
                  onClick={handleEmergencyStop}
                  color="error"
                  disabled={!autoRunEnabled}
                >
                  STOP
                </Button>
              </Box>

              {/* Estado actual */}
              <Box className="space-y-2">
                <div className="flex justify-between items-center">
                  <Typography variant="body2" className="text-muted-foreground">
                    Estrategia Activa:
                  </Typography>
                  <Chip 
                    label={currentStrategy || 'Ninguna'}
                    size="small"
                    color="primary"
                    variant="outlined"
                  />
                </div>

                {lastExecution && (
                  <div className="flex justify-between items-center">
                    <Typography variant="body2" className="text-muted-foreground">
                      Última Ejecución:
                    </Typography>
                    <Typography variant="body2" className="font-medium">
                      {lastExecution.toLocaleTimeString()}
                    </Typography>
                  </div>
                )}

                {nextExecution && autoRunEnabled && (
                  <div className="flex justify-between items-center">
                    <Typography variant="body2" className="text-muted-foreground">
                      Próxima Ejecución:
                    </Typography>
                    <Typography variant="body2" className="font-medium">
                      {nextExecution.toLocaleTimeString()}
                    </Typography>
                  </div>
                )}
              </Box>

              {/* Alertas */}
              {environment === 'prod' && autoRunEnabled && (
                <Alert severity="warning" className="mt-4">
                  <WarningCircle className="w-4 h-4 mr-2" />
                  Modo PRODUCCIÓN activo. Operaciones con fondos reales.
                </Alert>
              )}

              {!isWithinOperatingHours() && config.operatingHours.enabled && (
                <Alert severity="info" className="mt-4">
                  Fuera del horario operativo ({config.operatingHours.start} - {config.operatingHours.end})
                </Alert>
              )}
            </CardContent>
          </Card>
        </GridFour>

        {/* Estadísticas de Hoy */}
        <GridFour item xs={12} md={6}>
          <Card>
            <CardContent className="p-4">
              <Typography variant="h6" className="font-bold mb-4">
                📊 Estadísticas de Hoy
              </Typography>

              <GridFour container spacing={2}>
                <GridFour item xs={6}>
                  <Box className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <Typography variant="h4" className="font-bold text-blue-600">
                      {operationsToday}
                    </Typography>
                    <Typography variant="caption" className="text-muted-foreground">
                      Operaciones
                    </Typography>
                  </Box>
                </GridFour>
                <GridFour item xs={6}>
                  <Box className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <Typography variant="h4" className="font-bold text-green-600">
                      {operationsRemaining}
                    </Typography>
                    <Typography variant="caption" className="text-muted-foreground">
                      Restantes
                    </Typography>
                  </Box>
                </GridFour>
                <GridFour item xs={12}>
                  <Box className="text-center p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                    <Typography variant="h4" className={`font-bold ${dailyProfitNet >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(dailyProfitNet, 'USD')}
                    </Typography>
                    <Typography variant="caption" className="text-muted-foreground">
                      Profit Neto Hoy
                    </Typography>
                  </Box>
                </GridFour>
              </GridFour>

              {/* Progreso de operaciones diarias */}
              <Box className="mt-4">
                <div className="flex justify-between items-center mb-2">
                  <Typography variant="body2" className="text-muted-foreground">
                    Operaciones Diarias
                  </Typography>
                  <Typography variant="body2" className="font-medium">
                    {operationsToday}/{config.maxDailyOperations}
                  </Typography>
                </div>
                <LinearProgress 
                  variant="determinate" 
                  value={(operationsToday / config.maxDailyOperations) * 100}
                  className="rounded"
                />
              </Box>
            </CardContent>
          </Card>
        </GridFour>

        {/* Configuración Avanzada */}
        <GridFour item xs={12}>
          <Card>
            <CardContent className="p-4">
              <Typography variant="h6" className="font-bold mb-4 flex items-center gap-2">
                <Gear className="w-5 h-5" />
                Configuración Avanzada
              </Typography>

              <GridFour container spacing={4}>
                <GridFour item xs={12} md={6}>
                  <Typography variant="subtitle2" className="font-bold mb-3">
                    💰 Parámetros Financieros
                  </Typography>
                  
                  <Box className="space-y-4">
                    <TextField
                      fullWidth
                      label="Profit Mínimo (USD)"
                      type="number"
                      value={config.minProfitUSD}
                      onChange={(e) => setConfig(prev => ({ 
                        ...prev, 
                        minProfitUSD: Number(e.target.value) 
                      }))}
                      helperText="Profit mínimo requerido para ejecutar"
                    />

                    <Box>
                      <Typography variant="body2" className="mb-2">
                        Riesgo Máximo: {config.maxRiskScore}/10
                      </Typography>
                      <Slider
                        value={config.maxRiskScore}
                        onChange={(_, value) => setConfig(prev => ({ 
                          ...prev, 
                          maxRiskScore: value as number 
                        }))}
                        min={1}
                        max={10}
                        marks
                        step={1}
                        valueLabelDisplay="auto"
                      />
                    </Box>

                    <TextField
                      fullWidth
                      label="Stop Loss (%)"
                      type="number"
                      value={config.stopLossPercentage}
                      onChange={(e) => setConfig(prev => ({ 
                        ...prev, 
                        stopLossPercentage: Number(e.target.value) 
                      }))}
                      helperText="Pérdida máxima antes de parar"
                    />
                  </Box>
                </GridFour>

                <GridFour item xs={12} md={6}>
                  <Typography variant="subtitle2" className="font-bold mb-3">
                    ⚙️ Parámetros Técnicos
                  </Typography>
                  
                  <Box className="space-y-4">
                    <TextField
                      fullWidth
                      label="Intervalo de Ejecución (seg)"
                      type="number"
                      value={config.executionInterval}
                      onChange={(e) => setConfig(prev => ({ 
                        ...prev, 
                        executionInterval: Number(e.target.value) 
                      }))}
                      helperText="Tiempo entre verificaciones"
                    />

                    <TextField
                      fullWidth
                      label="Max Gas Price (Gwei)"
                      type="number"
                      value={config.maxGasPriceGwei}
                      onChange={(e) => setConfig(prev => ({ 
                        ...prev, 
                        maxGasPriceGwei: Number(e.target.value) 
                      }))}
                      helperText="Precio máximo de gas"
                    />

                    <TextField
                      fullWidth
                      label="Operaciones Diarias Máx"
                      type="number"
                      value={config.maxDailyOperations}
                      onChange={(e) => setConfig(prev => ({ 
                        ...prev, 
                        maxDailyOperations: Number(e.target.value) 
                      }))}
                      helperText="Límite diario de operaciones"
                    />
                  </Box>
                </GridFour>

                {/* Switches adicionales */}
                <GridFour item xs={12}>
                  <Divider className="my-4" />
                  <Typography variant="subtitle2" className="font-bold mb-3">
                    🛡️ Opciones de Seguridad
                  </Typography>
                  
                  <Box className="flex flex-wrap gap-4">
                    <FormControlLabel
                      control={
                        <Switch
                          checked={config.enableMEVProtection}
                          onChange={(e) => setConfig(prev => ({ 
                            ...prev, 
                            enableMEVProtection: e.target.checked 
                          }))}
                        />
                      }
                      label="Protección MEV"
                    />

                    <FormControlLabel
                      control={
                        <Switch
                          checked={config.enableNotifications}
                          onChange={(e) => setConfig(prev => ({ 
                            ...prev, 
                            enableNotifications: e.target.checked 
                          }))}
                        />
                      }
                      label="Notificaciones"
                    />

                    <FormControlLabel
                      control={
                        <Switch
                          checked={config.operatingHours.enabled}
                          onChange={(e) => setConfig(prev => ({ 
                            ...prev, 
                            operatingHours: { 
                              ...prev.operatingHours, 
                              enabled: e.target.checked 
                            }
                          }))}
                        />
                      }
                      label="Horario Operativo"
                    />
                  </Box>

                  {config.operatingHours.enabled && (
                    <Box className="flex gap-4 mt-3">
                      <TextField
                        label="Hora Inicio"
                        type="time"
                        value={config.operatingHours.start}
                        onChange={(e) => setConfig(prev => ({ 
                          ...prev, 
                          operatingHours: { 
                            ...prev.operatingHours, 
                            start: e.target.value 
                          }
                        }))}
                        InputLabelProps={{ shrink: true }}
                      />
                      <TextField
                        label="Hora Fin"
                        type="time"
                        value={config.operatingHours.end}
                        onChange={(e) => setConfig(prev => ({ 
                          ...prev, 
                          operatingHours: { 
                            ...prev.operatingHours, 
                            end: e.target.value 
                          }
                        }))}
                        InputLabelProps={{ shrink: true }}
                      />
                    </Box>
                  )}
                </GridFour>
              </GridFour>
            </CardContent>
          </Card>
        </GridFour>
      </GridFour>
    </Paper>
  )
}

export default AutoRunController