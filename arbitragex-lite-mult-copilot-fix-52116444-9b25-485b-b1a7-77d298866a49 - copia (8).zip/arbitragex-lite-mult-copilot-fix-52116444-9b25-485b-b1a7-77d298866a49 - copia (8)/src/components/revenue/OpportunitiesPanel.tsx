// 📊 OPPORTUNITIES PANEL - Panel de oportunidades en tiempo real
// Inspirado en arquitectura de trading institucional con filtros avanzados

import React, { useState, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { Input } from '../ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '../ui/table'
import { 
  Funnel,
  MagnifyingGlass,
  TrendUp,
  Clock,
  CurrencyDollar,
  Shield,
  WarningCircle,
  CheckCircle,
  Play,
  Repeat,
  ArrowUpDown,
  Eye,
  Lightning
} from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Opportunity } from '../../types/strategy.types'
import { strategies, getStrategyById } from '../../config/strategies'

// Simulación de API para oportunidades
const fetchOpportunities = async (): Promise<Opportunity[]> => {
  await new Promise(resolve => setTimeout(resolve, 200))
  
  // Generar oportunidades simuladas realistas
  const opportunities: Opportunity[] = []
  const tokens = ['ETH', 'USDC', 'USDT', 'WBTC', 'DAI', 'LINK', 'UNI', 'AAVE', 'MATIC', 'BNB']
  const blockchains = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism']
  const dexs = ['Uniswap V3', 'SushiSwap', 'PancakeSwap', 'Balancer', 'Curve', '1inch']

  for (let i = 0; i < 25; i++) {
    const strategyIndex = Math.floor(Math.random() * strategies.length)
    const strategy = strategies[strategyIndex]
    const tokenIn = tokens[Math.floor(Math.random() * tokens.length)]
    const tokenOut = tokens[Math.floor(Math.random() * tokens.length)]
    
    if (tokenIn === tokenOut) continue

    const blockchain = blockchains[Math.floor(Math.random() * blockchains.length)]
    const dex1 = dexs[Math.floor(Math.random() * dexs.length)]
    const dex2 = dexs[Math.floor(Math.random() * dexs.length)]
    
    const amountIn = Math.random() * 50000 + 1000
    const profitMargin = Math.random() * 3 + 0.1
    const estimatedProfit = amountIn * (profitMargin / 100)
    
    opportunities.push({
      id: `opp_${i}_${Date.now()}`,
      strategyId: strategy.id,
      timestamp: Date.now() - Math.random() * 300000, // Últimos 5 minutos
      tokens: {
        tokenIn,
        tokenOut,
        amountIn,
        amountOut: amountIn * (1 + profitMargin / 100)
      },
      path: {
        dexs: strategy.category === 'cross-chain' ? [dex1, dex2] : [dex1],
        pools: [`${tokenIn}/${tokenOut}`, `${tokenOut}/${tokenIn}`],
        fees: [0.003, 0.0025] // 0.3% y 0.25%
      },
      blockchain,
      estimatedProfit,
      estimatedGas: Math.random() * 100 + 20,
      profitMargin,
      riskScore: Math.random() * 8 + 1,
      confidence: Math.random() * 0.4 + 0.6,
      executionTime: Math.random() * 45 + 5,
      status: Math.random() > 0.8 ? 'executing' : 'pending',
      mevProtection: strategy.category === 'mev-protection' || Math.random() > 0.6,
      flashLoanRequired: strategy.category === 'flash-loan',
      crossChain: strategy.category === 'cross-chain'
    })
  }

  return opportunities.sort((a, b) => b.estimatedProfit - a.estimatedProfit)
}

// Mutation para ejecutar una oportunidad específica
const executeOpportunity = async (opportunityId: string): Promise<{
  success: boolean
  message: string
  txHash?: string
}> => {
  await new Promise(resolve => setTimeout(resolve, Math.random() * 3000 + 1000))
  
  if (Math.random() > 0.15) { // 85% success rate
    return {
      success: true,
      message: 'Oportunidad ejecutada exitosamente',
      txHash: `0x${Math.random().toString(16).substr(2, 8)}...`
    }
  } else {
    throw new Error('Error ejecutando oportunidad: Condiciones de mercado cambiaron')
  }
}

interface OpportunityRowProps {
  opportunity: Opportunity
  onExecute: (id: string) => void
  isExecuting: boolean
}

const OpportunityRow: React.FC<OpportunityRowProps> = ({ 
  opportunity, 
  onExecute, 
  isExecuting 
}) => {
  const strategy = getStrategyById(opportunity.strategyId)
  
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const formatTime = (seconds: number) => {
    if (seconds < 60) return `${seconds.toFixed(0)}s`
    return `${(seconds / 60).toFixed(1)}m`
  }

  const getRiskColor = (score: number) => {
    if (score <= 3) return 'text-profit bg-profit/10'
    if (score <= 6) return 'text-warning bg-warning/10'
    return 'text-destructive bg-destructive/10'
  }

  const getStatusIcon = () => {
    switch (opportunity.status) {
      case 'executing':
        return <Repeat className="w-4 h-4 animate-spin text-warning" />
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-profit" />
      case 'failed':
        return <WarningCircle className="w-4 h-4 text-destructive" />
      case 'expired':
        return <Clock className="w-4 h-4 text-muted-foreground" />
      default:
        return <Eye className="w-4 h-4 text-muted-foreground" />
    }
  }

  return (
    <TableRow className="hover:bg-muted/50">
      <TableCell>
        <div className="flex items-center gap-2">
          {getStatusIcon()}
          <div>
            <p className="font-medium text-sm">{strategy?.label}</p>
            <p className="text-xs text-muted-foreground">
              {opportunity.tokens.tokenIn} → {opportunity.tokens.tokenOut}
            </p>
          </div>
        </div>
      </TableCell>
      
      <TableCell>
        <div className="text-right">
          <p className="font-medium text-profit">
            {formatCurrency(opportunity.estimatedProfit)}
          </p>
          <p className="text-xs text-muted-foreground">
            {opportunity.profitMargin.toFixed(2)}%
          </p>
        </div>
      </TableCell>
      
      <TableCell>
        <Badge className={getRiskColor(opportunity.riskScore)}>
          {opportunity.riskScore.toFixed(1)}
        </Badge>
      </TableCell>
      
      <TableCell>
        <div className="text-sm">
          <p>{opportunity.path.dexs.join(' → ')}</p>
          <p className="text-xs text-muted-foreground capitalize">
            {opportunity.blockchain}
          </p>
        </div>
      </TableCell>
      
      <TableCell className="text-sm">
        {formatTime(opportunity.executionTime)}
      </TableCell>
      
      <TableCell>
        <div className="flex items-center gap-2">
          {opportunity.flashLoanRequired && (
            <Badge variant="outline" className="text-xs">
              <Lightning className="w-3 h-3 mr-1" />
              Flash
            </Badge>
          )}
          {opportunity.mevProtection && (
            <Badge variant="outline" className="text-xs">
              <Shield className="w-3 h-3 mr-1" />
              MEV
            </Badge>
          )}
          {opportunity.crossChain && (
            <Badge variant="outline" className="text-xs">
              Cross
            </Badge>
          )}
        </div>
      </TableCell>
      
      <TableCell>
        <Button
          size="sm"
          onClick={() => onExecute(opportunity.id)}
          disabled={
            isExecuting || 
            opportunity.status === 'executing' || 
            opportunity.status === 'expired'
          }
          className="w-full"
        >
          {isExecuting ? (
            <Repeat className="w-3 h-3 animate-spin" />
          ) : (
            <Play className="w-3 h-3" />
          )}
        </Button>
      </TableCell>
    </TableRow>
  )
}

export const OpportunitiesPanel: React.FC = () => {
  const queryClient = useQueryClient()
  const [searchTerm, setMagnifyingGlassTerm] = useState('')
  const [selectedStrategy, setSelectedStrategy] = useState<string>('all')
  const [selectedRisk, setSelectedRisk] = useState<string>('all')
  const [selectedBlockchain, setSelectedBlockchain] = useState<string>('all')
  const [sortBy, setSortBy] = useState<'profit' | 'risk' | 'time'>('profit')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc')

  // Query para oportunidades con refetch automático
  const { 
    data: opportunities = [], 
    isLoading, 
    error,
    refetch 
  } = useQuery({
    queryKey: ['opportunities'],
    queryFn: fetchOpportunities,
    refetchInterval: 5000, // Refetch cada 5 segundos
    staleTime: 2000
  })

  // Mutation para ejecutar oportunidad
  const [executingId, setExecutingId] = useState<string | null>(null)
  const executeMutation = useMutation({
    mutationFn: executeOpportunity,
    onMutate: (opportunityId) => {
      setExecutingId(opportunityId)
    },
    onSuccess: (data, opportunityId) => {
      setExecutingId(null)
      queryClient.invalidateQueries({ queryKey: ['opportunities'] })
      queryClient.invalidateQueries({ queryKey: ['arbitrage-metrics'] })
    },
    onError: (error, opportunityId) => {
      setExecutingId(null)
      console.error('Error ejecutando oportunidad:', error)
    }
  })

  // Filtrado y ordenamiento de oportunidades
  const filteredAndSortedOpportunities = useMemo(() => {
    let filtered = opportunities.filter(opp => {
      const strategy = getStrategyById(opp.strategyId)
      const matchesMagnifyingGlass = 
        searchTerm === '' ||
        strategy?.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
        opp.tokens.tokenIn.toLowerCase().includes(searchTerm.toLowerCase()) ||
        opp.tokens.tokenOut.toLowerCase().includes(searchTerm.toLowerCase())
      
      const matchesStrategy = selectedStrategy === 'all' || opp.strategyId === selectedStrategy
      const matchesRisk = selectedRisk === 'all' || 
        (selectedRisk === 'low' && opp.riskScore <= 3) ||
        (selectedRisk === 'medium' && opp.riskScore > 3 && opp.riskScore <= 6) ||
        (selectedRisk === 'high' && opp.riskScore > 6)
      const matchesBlockchain = selectedBlockchain === 'all' || opp.blockchain === selectedBlockchain

      return matchesMagnifyingGlass && matchesStrategy && matchesRisk && matchesBlockchain
    })

    // Ordenamiento
    filtered.sort((a, b) => {
      let comparison = 0
      
      switch (sortBy) {
        case 'profit':
          comparison = a.estimatedProfit - b.estimatedProfit
          break
        case 'risk':
          comparison = a.riskScore - b.riskScore
          break
        case 'time':
          comparison = a.executionTime - b.executionTime
          break
      }
      
      return sortOrder === 'asc' ? comparison : -comparison
    })

    return filtered
  }, [opportunities, searchTerm, selectedStrategy, selectedRisk, selectedBlockchain, sortBy, sortOrder])

  const handleExecute = (opportunityId: string) => {
    executeMutation.mutate(opportunityId)
  }

  const handleSort = (field: 'profit' | 'risk' | 'time') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      setSortBy(field)
      setSortOrder('desc')
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-muted rounded w-1/3"></div>
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="col-span-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendUp className="w-5 h-5 text-primary" />
            Oportunidades en Tiempo Real
            <Badge variant="secondary" className="ml-2">
              {filteredAndSortedOpportunities.length} activas
            </Badge>
          </CardTitle>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => refetch()}
            disabled={isLoading}
          >
            <Repeat className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Actualizar
          </Button>
        </div>

        {/* Filtros */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mt-4">
          <div className="relative">
            <MagnifyingGlass className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar estrategia o token..."
              value={searchTerm}
              onChange={(e) => setMagnifyingGlassTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={selectedStrategy} onValueChange={setSelectedStrategy}>
            <SelectTrigger>
              <SelectValue placeholder="Estrategia" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas las estrategias</SelectItem>
              {strategies.map(strategy => (
                <SelectItem key={strategy.id} value={strategy.id}>
                  {strategy.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedRisk} onValueChange={setSelectedRisk}>
            <SelectTrigger>
              <SelectValue placeholder="Riesgo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los riesgos</SelectItem>
              <SelectItem value="low">Bajo (1-3)</SelectItem>
              <SelectItem value="medium">Medio (4-6)</SelectItem>
              <SelectItem value="high">Alto (7-10)</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedBlockchain} onValueChange={setSelectedBlockchain}>
            <SelectTrigger>
              <SelectValue placeholder="Blockchain" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas las redes</SelectItem>
              <SelectItem value="ethereum">Ethereum</SelectItem>
              <SelectItem value="polygon">Polygon</SelectItem>
              <SelectItem value="bsc">BSC</SelectItem>
              <SelectItem value="arbitrum">Arbitrum</SelectItem>
              <SelectItem value="optimism">Optimism</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center gap-2">
            <Funnel className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              {filteredAndSortedOpportunities.length} resultados
            </span>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Estrategia</TableHead>
                <TableHead className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('profit')}
                    className="h-auto p-0 font-medium"
                  >
                    Ganancia Est.
                    <ArrowUpDown className="w-3 h-3 ml-1" />
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('risk')}
                    className="h-auto p-0 font-medium"
                  >
                    Riesgo
                    <ArrowUpDown className="w-3 h-3 ml-1" />
                  </Button>
                </TableHead>
                <TableHead>DEX / Red</TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleSort('time')}
                    className="h-auto p-0 font-medium"
                  >
                    Tiempo
                    <ArrowUpDown className="w-3 h-3 ml-1" />
                  </Button>
                </TableHead>
                <TableHead>Features</TableHead>
                <TableHead>Acción</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAndSortedOpportunities.map((opportunity) => (
                <OpportunityRow
                  key={opportunity.id}
                  opportunity={opportunity}
                  onExecute={handleExecute}
                  isExecuting={executingId === opportunity.id}
                />
              ))}
            </TableBody>
          </Table>

          {filteredAndSortedOpportunities.length === 0 && (
            <div className="p-8 text-center text-muted-foreground">
              <TrendUp className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>No se encontraron oportunidades con los filtros actuales</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}