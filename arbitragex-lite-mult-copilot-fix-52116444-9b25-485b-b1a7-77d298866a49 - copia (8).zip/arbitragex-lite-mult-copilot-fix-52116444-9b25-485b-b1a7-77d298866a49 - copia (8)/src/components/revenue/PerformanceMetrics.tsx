import React from 'react'
import { Paper, GridFour, Typography, Box, Chip, LinearProgress } from '@mui/material'
import { TrendUp, TrendDown, CurrencyDollar, Activity, Target, Clock } from 'lucide-react'
import { motion } from 'framer-motion'
import { formatCurrency, formatPercentage, formatNumber } from '@/lib/utils'

interface PerformanceMetricsProps {
  totalProfit: number
  arbitrageMetrics: any
  hftMetrics: any
  environment: 'test' | 'prod'
  isLoading: boolean
}

interface MetricCardProps {
  title: string
  value: string | number
  subtitle?: string
  trend?: 'up' | 'down' | 'neutral'
  trendValue?: string
  icon: React.ReactNode
  color?: 'primary' | 'secondary' | 'success' | 'warning' | 'error'
  isLoading?: boolean
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  trend = 'neutral',
  trendValue,
  icon,
  color = 'primary',
  isLoading = false
}) => {
  const getTrendIcon = () => {
    switch (trend) {
      case 'up':
        return <TrendUp className="w-4 h-4 text-green-500" />
      case 'down':
        return <TrendDown className="w-4 h-4 text-red-500" />
      default:
        return null
    }
  }

  const getTrendColor = () => {
    switch (trend) {
      case 'up':
        return 'text-green-600'
      case 'down':
        return 'text-red-600'
      default:
        return 'text-muted-foreground'
    }
  }

  const getColorClasses = () => {
    switch (color) {
      case 'success':
        return 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
      case 'warning':
        return 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800'
      case 'error':
        return 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
      case 'secondary':
        return 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800'
      default:
        return 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Paper 
        elevation={2}
        className={`p-4 border-l-4 ${getColorClasses()} hover:shadow-md transition-shadow duration-300`}
      >
        {isLoading ? (
          <Box className="space-y-2">
            <LinearProgress />
            <Typography variant="caption" className="text-muted-foreground">
              Cargando...
            </Typography>
          </Box>
        ) : (
          <>
            <Box className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {icon}
                <Typography variant="subtitle2" className="font-medium text-muted-foreground">
                  {title}
                </Typography>
              </div>
              {trendValue && (
                <div className="flex items-center gap-1">
                  {getTrendIcon()}
                  <Typography variant="caption" className={getTrendColor()}>
                    {trendValue}
                  </Typography>
                </div>
              )}
            </Box>
            
            <Typography variant="h5" className="font-bold mb-1">
              {value}
            </Typography>
            
            {subtitle && (
              <Typography variant="caption" className="text-muted-foreground">
                {subtitle}
              </Typography>
            )}
          </>
        )}
      </Paper>
    </motion.div>
  )
}

export const PerformanceMetrics: React.FC<PerformanceMetricsProps> = ({
  totalProfit,
  arbitrageMetrics,
  hftMetrics,
  environment,
  isLoading
}) => {
  // Calcular cambios porcentuales (simulados por ahora)
  const getDailyChange = () => {
    const change = Math.random() * 20 - 10 // -10% a +10%
    return {
      value: `${change >= 0 ? '+' : ''}${change.toFixed(1)}%`,
      trend: change >= 0 ? 'up' as const : 'down' as const
    }
  }

  const dailyChange = getDailyChange()
  const weeklyChange = getDailyChange()
  const arbitrageChange = getDailyChange()
  const hftChange = getDailyChange()

  return (
    <GridFour container spacing={3} className="mb-6">
      {/* Profit Total */}
      <GridFour item xs={12} sm={6} md={3}>
        <MetricCard
          title="Profit Total Hoy"
          value={formatCurrency(totalProfit, 'USD')}
          subtitle={`≈ ${formatCurrency(totalProfit * 4000, 'COP')}`}
          icon={<CurrencyDollar className="w-5 h-5" />}
          trend={dailyChange.trend}
          trendValue={dailyChange.value}
          color="success"
          isLoading={isLoading}
        />
      </GridFour>

      {/* Arbitraje Performance */}
      <GridFour item xs={12} sm={6} md={3}>
        <MetricCard
          title="Arbitraje"
          value={arbitrageMetrics ? `${arbitrageMetrics.opportunitiesCount} ops` : '0 ops'}
          subtitle={arbitrageMetrics ? formatCurrency(arbitrageMetrics.estimatedProfitUSD, 'USD') : '$0'}
          icon={<Target className="w-5 h-5" />}
          trend={arbitrageChange.trend}
          trendValue={arbitrageChange.value}
          color="primary"
          isLoading={isLoading}
        />
      </GridFour>

      {/* HFT Performance */}
      <GridFour item xs={12} sm={6} md={3}>
        <MetricCard
          title="HFT Engine"
          value={hftMetrics ? `${hftMetrics.currentLatency}μs` : '0μs'}
          subtitle={hftMetrics ? `${formatNumber(hftMetrics.executionsPerSecond)}/s` : '0/s'}
          icon={<Activity className="w-5 h-5" />}
          trend={hftChange.trend}
          trendValue={hftChange.value}
          color="secondary"
          isLoading={isLoading}
        />
      </GridFour>

      {/* Success Rate */}
      <GridFour item xs={12} sm={6} md={3}>
        <MetricCard
          title="Tasa de Éxito"
          value={
            arbitrageMetrics && hftMetrics 
              ? formatPercentage((arbitrageMetrics.successRate + hftMetrics.successRate) / 2)
              : '0%'
          }
          subtitle="Promedio combinado"
          icon={<Clock className="w-5 h-5" />}
          trend={weeklyChange.trend}
          trendValue={weeklyChange.value}
          color={
            arbitrageMetrics && hftMetrics 
              ? (arbitrageMetrics.successRate + hftMetrics.successRate) / 2 >= 85 
                ? 'success' 
                : 'warning'
              : 'warning'
          }
          isLoading={isLoading}
        />
      </GridFour>

      {/* Environment Status */}
      <GridFour item xs={12}>
        <Box className="flex items-center justify-center gap-4 p-4 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
          <Chip 
            label={`Entorno: ${environment.toUpperCase()}`}
            color={environment === 'prod' ? 'error' : 'warning'}
            variant="filled"
          />
          
          {arbitrageMetrics && (
            <Chip 
              label={`${arbitrageMetrics.activeStrategies}/11 estrategias activas`}
              color="primary"
              variant="outlined"
            />
          )}
          
          {hftMetrics && (
            <Chip 
              label={`${hftMetrics.activeConnections} conexiones HFT`}
              color="secondary"
              variant="outlined"
            />
          )}
          
          <Chip 
            label={isLoading ? 'Actualizando...' : 'Datos en tiempo real'}
            color={isLoading ? 'warning' : 'success'}
            variant="outlined"
          />
        </Box>
      </GridFour>
    </GridFour>
  )
}

export default PerformanceMetrics