/**
 * MOAD Dashboard - Módulo de Oportunidades de Arbitraje DeFi
 * Dashboard principal que integra detección, análisis y ejecución de arbitraje
 * Cumple con PRD-MOAD-001 y arquitectura ArbitrageX Pro 2
 */

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Badge } from '../ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { Alert, AlertDescription } from '../ui/alert'
import { 
  TrendUp, 
  Lightning, 
  Shield, 
  Brain, 
  Activity,
  CurrencyDollar,
  Clock,
  Target,
  WarningCircle,
  CheckCircle,
  Gear,
  Play,
  Pause,
  ChartBar3,
  Bot,
  Eye,
  Funnel
} from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useKV } from '@/hooks/useKV'

// Importar componentes existentes
import { OpportunitiesPanel } from './OpportunitiesPanel'
import { ArbitrageEngineCard } from './ArbitrageEngineCard'
import { HFTEngineCard } from './HFTEngineCard'
import { PerformanceMetrics } from './PerformanceMetrics'
import { StrategySelector } from './StrategySelector'

// Importar tipos
import { 
  MOADConfig, 
  SystemMetrics, 
  ExecutionMode, 
  Opportunity,
  StrategyInfo 
} from '../../types/moad.types'
import { strategies } from './strategies'

// ============================================================================
// INTERFACES Y TIPOS LOCALES
// ============================================================================

interface MOADDashboardProps {
  environment: 'test' | 'prod'
}

interface SystemStatus {
  overall: 'healthy' | 'degraded' | 'critical'
  scanner: 'active' | 'idle' | 'error'
  execution: 'ready' | 'busy' | 'paused'
  llmAgent: 'active' | 'learning' | 'offline'
  riskAssessment: 'normal' | 'elevated' | 'critical'
}

interface DailyTargets {
  profitTarget: number
  currentProfit: number
  operationsTarget: number
  currentOperations: number
  successRateTarget: number
  currentSuccessRate: number
}

// ============================================================================
// SIMULACIÓN DE APIs (EN PRODUCCIÓN SERÍAN CALLS REALES)
// ============================================================================

const fetchSystemStatus = async (): Promise<SystemStatus> => {
  await new Promise(resolve => setTimeout(resolve, 100))
  
  return {
    overall: Math.random() > 0.1 ? 'healthy' : 'degraded',
    scanner: Math.random() > 0.05 ? 'active' : 'error',
    execution: Math.random() > 0.8 ? 'busy' : 'ready',
    llmAgent: Math.random() > 0.1 ? 'active' : 'learning',
    riskAssessment: Math.random() > 0.15 ? 'normal' : 'elevated'
  }
}

const fetchDailyTargets = async (): Promise<DailyTargets> => {
  await new Promise(resolve => setTimeout(resolve, 150))
  
  return {
    profitTarget: 100000,
    currentProfit: Math.random() * 150000 + 50000,
    operationsTarget: 200,
    currentOperations: Math.floor(Math.random() * 250 + 100),
    successRateTarget: 95,
    currentSuccessRate: Math.random() * 10 + 90
  }
}

const fetchSystemMetrics = async (): Promise<SystemMetrics> => {
  await new Promise(resolve => setTimeout(resolve, 200))
  
  return {
    timestamp: Date.now(),
    uptime: Math.random() * 100000 + 86400000, // 1+ días
    performance: {
      avgResponseTime: Math.random() * 20 + 10,
      throughput: Math.random() * 500 + 200,
      errorRate: Math.random() * 2 + 0.1,
      latency: {
        opportunityDetection: Math.random() * 100 + 50,
        riskAssessment: Math.random() * 50 + 25,
        execution: Math.random() * 200 + 100,
        blockchainRPC: Math.random() * 300 + 100
      }
    },
    financial: {
      dailyProfit: Math.random() * 50000 + 75000,
      weeklyProfit: Math.random() * 300000 + 400000,
      monthlyProfit: Math.random() * 1000000 + 1500000,
      totalROI: Math.random() * 30 + 45,
      successRate: Math.random() * 10 + 85,
      avgProfitPerTrade: Math.random() * 1000 + 500
    },
    health: {
      rpcConnections: [
        { blockchain: 'ethereum', status: 'connected', latency: 120, errorRate: 0.1, lastCheck: Date.now() },
        { blockchain: 'polygon', status: 'connected', latency: 80, errorRate: 0.05, lastCheck: Date.now() },
        { blockchain: 'bsc', status: 'degraded', latency: 300, errorRate: 1.2, lastCheck: Date.now() },
        { blockchain: 'arbitrum', status: 'connected', latency: 90, errorRate: 0.08, lastCheck: Date.now() },
        { blockchain: 'optimism', status: 'connected', latency: 95, errorRate: 0.12, lastCheck: Date.now() },
        { blockchain: 'avalanche', status: 'connected', latency: 110, errorRate: 0.15, lastCheck: Date.now() }
      ],
      databaseStatus: Math.random() > 0.05 ? 'healthy' : 'degraded',
      llmAgentStatus: Math.random() > 0.1 ? 'active' : 'idle',
      opportunityDetection: Math.random() > 0.05 ? 'active' : 'degraded'
    }
  }
}

// ============================================================================
// COMPONENTES AUXILIARES
// ============================================================================

const StatusIndicator: React.FC<{ status: string; label: string }> = ({ status, label }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy':
      case 'active':
      case 'ready':
      case 'connected':
      case 'normal':
        return 'bg-profit text-profit-foreground'
      case 'degraded':
      case 'idle':
      case 'learning':
      case 'elevated':
        return 'bg-warning text-warning-foreground'
      case 'critical':
      case 'error':
      case 'offline':
      case 'disconnected':
        return 'bg-destructive text-destructive-foreground'
      case 'busy':
      case 'paused':
        return 'bg-secondary text-secondary-foreground'
      default:
        return 'bg-muted text-muted-foreground'
    }
  }

  return (
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${getStatusColor(status)}`} />
      <span className="text-sm">{label}</span>
    </div>
  )
}

const MetricCard: React.FC<{
  title: string
  value: string | number
  subtitle?: string
  icon: React.ReactNode
  trend?: 'up' | 'down' | 'neutral'
  className?: string
}> = ({ title, value, subtitle, icon, trend, className = '' }) => {
  const getTrendColor = () => {
    switch (trend) {
      case 'up': return 'text-profit'
      case 'down': return 'text-destructive'
      default: return 'text-muted-foreground'
    }
  }

  return (
    <Card className={`hover-lift ${className}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {subtitle && (
              <p className={`text-xs ${getTrendColor()}`}>{subtitle}</p>
            )}
          </div>
          <div className="text-primary opacity-70">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// ============================================================================
// COMPONENTE PRINCIPAL MOAD DASHBOARD
// ============================================================================

export const MOADDashboard: React.FC<MOADDashboardProps> = ({ environment }) => {
  const queryClient = useQueryClient()
  
  // Estados persistentes con useKV
  const [activeMode, setActiveMode] = useKV<ExecutionMode>('moad-execution-mode', 'manual')
  const [autoRunEnabled, setAutoRunEnabled] = useKV<boolean>('moad-auto-run', false)
  const [selectedStrategies, setSelectedStrategies] = useKV<string[]>('moad-selected-strategies', 
    strategies.slice(0, 5).map(s => s.id)
  )
  
  // Estados locales
  const [isSystemActive, setIsSystemActive] = useState(true)
  const [showGear, setShowGear] = useState(false)

  // Queries para datos en tiempo real
  const { data: systemStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['moad-system-status'],
    queryFn: fetchSystemStatus,
    refetchInterval: 3000
  })

  const { data: dailyTargets, isLoading: targetsLoading } = useQuery({
    queryKey: ['moad-daily-targets'],
    queryFn: fetchDailyTargets,
    refetchInterval: 30000
  })

  const { data: systemMetrics, isLoading: metricsLoading } = useQuery({
    queryKey: ['moad-system-metrics'],
    queryFn: fetchSystemMetrics,
    refetchInterval: 10000
  })

  // Mutaciones para control del sistema
  const toggleSystemMutation = useMutation({
    mutationFn: async (active: boolean) => {
      await new Promise(resolve => setTimeout(resolve, 1000))
      return { success: true }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['moad-system-status'] })
    }
  })

  const changeModeMutation = useMutation({
    mutationFn: async (mode: ExecutionMode) => {
      await new Promise(resolve => setTimeout(resolve, 500))
      return { success: true }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['moad-system-status'] })
    }
  })

  // Handlers
  const handleSystemToggle = () => {
    const newState = !isSystemActive
    setIsSystemActive(newState)
    toggleSystemMutation.mutate(newState)
  }

  const handleModeChange = (mode: ExecutionMode) => {
    setActiveMode(mode)
    changeModeMutation.mutate(mode)
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`
  }

  const getProgressPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100)
  }

  if (statusLoading || targetsLoading || metricsLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-muted rounded"></div>
            ))}
          </div>
          <div className="h-96 bg-muted rounded"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header con controles principales */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            MOAD - Sistema de Arbitraje DeFi
          </h1>
          <p className="text-muted-foreground">
            Detección y ejecución automatizada de oportunidades multi-blockchain
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          {/* Badge de ambiente */}
          <Badge variant={environment === 'prod' ? 'destructive' : 'secondary'}>
            {environment === 'prod' ? 'PRODUCCIÓN' : 'TEST'}
          </Badge>
          
          {/* Control principal del sistema */}
          <Button
            onClick={handleSystemToggle}
            disabled={toggleSystemMutation.isPending}
            size="lg"
            variant={isSystemActive ? "destructive" : "default"}
          >
            {isSystemActive ? (
              <>
                <Pause className="w-4 h-4 mr-2" />
                Pausar Sistema
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Activar Sistema
              </>
            )}
          </Button>

          <Button 
            variant="outline" 
            onClick={() => setShowGear(!showGear)}
          >
            <Gear className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Alerta de estado del sistema */}
      {systemStatus && systemStatus.overall !== 'healthy' && (
        <Alert variant="destructive">
          <WarningCircle className="h-4 w-4" />
          <AlertDescription>
            Sistema en estado {systemStatus.overall}. Revisar componentes degradados.
          </AlertDescription>
        </Alert>
      )}

      {/* Métricas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Ganancia Diaria"
          value={formatCurrency(dailyTargets?.currentProfit || 0)}
          subtitle={`Objetivo: ${formatCurrency(dailyTargets?.profitTarget || 100000)}`}
          icon={<CurrencyDollar className="w-6 h-6" />}
          trend={dailyTargets && dailyTargets.currentProfit > dailyTargets.profitTarget ? 'up' : 'neutral'}
        />
        
        <MetricCard
          title="Operaciones Hoy"
          value={dailyTargets?.currentOperations || 0}
          subtitle={`Objetivo: ${dailyTargets?.operationsTarget || 200}`}
          icon={<Activity className="w-6 h-6" />}
          trend="up"
        />
        
        <MetricCard
          title="Tasa de Éxito"
          value={formatPercentage(dailyTargets?.currentSuccessRate || 0)}
          subtitle={`Objetivo: ${formatPercentage(dailyTargets?.successRateTarget || 95)}`}
          icon={<Target className="w-6 h-6" />}
          trend="up"
        />
        
        <MetricCard
          title="ROI Mensual"
          value={formatPercentage(systemMetrics?.financial.totalROI || 0)}
          subtitle="Objetivo: 50-75%"
          icon={<TrendUp className="w-6 h-6" />}
          trend="up"
        />
      </div>

      {/* Barra de progreso hacia objetivos diarios */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Progreso Objetivos Diarios</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Ganancia</span>
                <span className="text-sm font-medium">
                  {getProgressPercentage(
                    dailyTargets?.currentProfit || 0, 
                    dailyTargets?.profitTarget || 100000
                  ).toFixed(0)}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="progress-indicator h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${getProgressPercentage(
                      dailyTargets?.currentProfit || 0, 
                      dailyTargets?.profitTarget || 100000
                    )}%`
                  }}
                />
              </div>
            </div>
            
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Operaciones</span>
                <span className="text-sm font-medium">
                  {getProgressPercentage(
                    dailyTargets?.currentOperations || 0, 
                    dailyTargets?.operationsTarget || 200
                  ).toFixed(0)}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-chart-2 h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${getProgressPercentage(
                      dailyTargets?.currentOperations || 0, 
                      dailyTargets?.operationsTarget || 200
                    )}%`
                  }}
                />
              </div>
            </div>
            
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Tasa Éxito</span>
                <span className="text-sm font-medium">
                  {getProgressPercentage(
                    dailyTargets?.currentSuccessRate || 0, 
                    dailyTargets?.successRateTarget || 95
                  ).toFixed(0)}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-chart-3 h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${getProgressPercentage(
                      dailyTargets?.currentSuccessRate || 0, 
                      dailyTargets?.successRateTarget || 95
                    )}%`
                  }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Indicadores de estado del sistema */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Estado del Sistema
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <StatusIndicator 
              status={systemStatus?.overall || 'unknown'} 
              label="General" 
            />
            <StatusIndicator 
              status={systemStatus?.scanner || 'unknown'} 
              label="Scanner" 
            />
            <StatusIndicator 
              status={systemStatus?.execution || 'unknown'} 
              label="Ejecución" 
            />
            <StatusIndicator 
              status={systemStatus?.llmAgent || 'unknown'} 
              label="LLM Agent" 
            />
            <StatusIndicator 
              status={systemStatus?.riskAssessment || 'unknown'} 
              label="Evaluación Riesgo" 
            />
          </div>
        </CardContent>
      </Card>

      {/* Selector de modo de operación */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <Bot className="w-5 h-5" />
            Modo de Operación
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Tabs value={activeMode} onValueChange={(value) => handleModeChange(value as ExecutionMode)}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="manual" className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Manual
                </TabsTrigger>
                <TabsTrigger value="semi-automatic" className="flex items-center gap-2">
                  <Funnel className="w-4 h-4" />
                  Semi-Auto
                </TabsTrigger>
                <TabsTrigger value="automatic" className="flex items-center gap-2">
                  <Bot className="w-4 h-4" />
                  Automático
                </TabsTrigger>
              </TabsList>
            </Tabs>
            
            <div className="flex items-center gap-2 ml-4">
              <span className="text-sm text-muted-foreground">
                Modo actual: 
              </span>
              <Badge variant="outline">
                {activeMode === 'manual' ? 'Control Manual' : 
                 activeMode === 'semi-automatic' ? 'Semi-Automático' : 
                 'Totalmente Automático'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs principales */}
      <Tabs defaultValue="opportunities" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="opportunities">Oportunidades</TabsTrigger>
          <TabsTrigger value="engines">Motores</TabsTrigger>
          <TabsTrigger value="strategies">Estrategias</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Panel de Oportunidades */}
        <TabsContent value="opportunities">
          <OpportunitiesPanel />
        </TabsContent>

        {/* Panel de Motores */}
        <TabsContent value="engines">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ArbitrageEngineCard 
              environment={environment}
              autoRun={autoRunEnabled}
              onAutoRunChange={setAutoRunEnabled}
            />
            <HFTEngineCard 
              environment={environment}
              autoRun={autoRunEnabled}
              onAutoRunChange={setAutoRunEnabled}
            />
          </div>
        </TabsContent>

        {/* Panel de Estrategias */}
        <TabsContent value="strategies">
          <StrategySelector 
            selectedStrategies={selectedStrategies}
            onSelectionChange={setSelectedStrategies}
            mode={activeMode}
          />
        </TabsContent>

        {/* Panel de Analytics */}
        <TabsContent value="analytics">
          <PerformanceMetrics 
            environment={environment}
            timeRange="24h"
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default MOADDashboard