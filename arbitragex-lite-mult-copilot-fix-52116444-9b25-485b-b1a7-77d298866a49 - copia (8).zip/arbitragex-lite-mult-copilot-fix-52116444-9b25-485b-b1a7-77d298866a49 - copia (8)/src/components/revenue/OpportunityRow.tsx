// src/components/revenue/OpportunityRow.tsx

import React from 'react'
import { TableRow, TableCell } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { 
  Play, 
  Clock, 
  Shield, 
  TrendUp, 
  WarningCircle,
  CheckCircle,
  Lightning,
  Timer
} from '@phosphor-icons/react'

interface Opportunity {
  id: string
  strategy: string
  strategyName: string
  assets: string[]
  dex: string
  chain: string
  chainId: number
  estimatedProfit: number
  profitUSD: number
  riskScore: number
  executionTime: number
  confidence: number
  gasEstimate: number
  slippage: number
  minCapital: number
  lastDetected: Date
  expiresAt: Date
  liquidityDepth: number
  competitorCount: number
}

interface OpportunityRowProps {
  opportunity: Opportunity
  onExecute: () => void
  isExecuting: boolean
  environment: 'test' | 'prod'
}

const OpportunityRow: React.FC<OpportunityRowProps> = ({
  opportunity,
  onExecute,
  isExecuting,
  environment
}) => {
  // Calcular tiempo restante hasta expiración
  const timeToExpiry = Math.max(0, new Date(opportunity.expiresAt).getTime() - Date.now())
  const minutesToExpiry = Math.floor(timeToExpiry / 60000)
  const secondsToExpiry = Math.floor((timeToExpiry % 60000) / 1000)

  // Determinar color de riesgo
  const getRiskColor = (risk: number) => {
    if (risk < 30) return 'text-profit'
    if (risk < 60) return 'text-warning'
    return 'text-destructive'
  }

  // Determinar color de confianza
  const getConfidenceColor = (confidence: number) => {
    if (confidence > 0.8) return 'text-profit'
    if (confidence > 0.6) return 'text-warning'
    return 'text-destructive'
  }

  // Formatear nombre de cadena
  const getChainDisplay = (chain: string) => {
    const chainNames: Record<string, string> = {
      ethereum: 'ETH',
      polygon: 'MATIC',
      arbitrum: 'ARB',
      bsc: 'BSC',
      optimism: 'OP'
    }
    return chainNames[chain] || chain.toUpperCase()
  }

  // Determinar si la oportunidad está por expirar
  const isExpiringSoon = timeToExpiry < 30000 // Menos de 30 segundos

  return (
    <TooltipProvider>
      <TableRow className={`hover:bg-muted/50 transition-colors ${
        isExpiringSoon ? 'bg-warning/5 border-warning/20' : ''
      }`}>
        {/* Estrategia */}
        <TableCell className="font-medium">
          <div className="space-y-1">
            <div className="text-sm font-medium">
              {opportunity.strategyName}
            </div>
            <div className="text-xs text-muted-foreground">
              {opportunity.strategy}
            </div>
          </div>
        </TableCell>

        {/* Activos */}
        <TableCell>
          <div className="flex flex-wrap gap-1">
            {opportunity.assets.map((asset, index) => (
              <Badge key={asset} variant="outline" className="text-xs">
                {asset}
              </Badge>
            ))}
          </div>
        </TableCell>

        {/* DEX / Cadena */}
        <TableCell>
          <div className="space-y-1">
            <div className="text-sm font-medium">{opportunity.dex}</div>
            <div className="flex items-center gap-1">
              <Badge variant="secondary" className="text-xs">
                {getChainDisplay(opportunity.chain)}
              </Badge>
              {opportunity.competitorCount > 0 && (
                <Tooltip>
                  <TooltipTrigger>
                    <Badge variant="outline" className="text-xs text-warning">
                      🏃 {opportunity.competitorCount}
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{opportunity.competitorCount} competidores detectados</p>
                  </TooltipContent>
                </Tooltip>
              )}
            </div>
          </div>
        </TableCell>

        {/* Profit Estimado */}
        <TableCell className="text-right">
          <div className="space-y-1">
            <div className="text-sm font-bold profit">
              ${opportunity.profitUSD.toFixed(2)}
            </div>
            <Tooltip>
              <TooltipTrigger>
                <div className="text-xs text-muted-foreground flex items-center justify-end gap-1">
                  <Lightning className="h-3 w-3" />
                  ${opportunity.gasEstimate.toFixed(0)} gas
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <div className="space-y-1 text-xs">
                  <p>Ganancia bruta: ${(opportunity.profitUSD + opportunity.gasEstimate).toFixed(2)}</p>
                  <p>Gas estimado: ${opportunity.gasEstimate.toFixed(2)}</p>
                  <p>Slippage: {(opportunity.slippage * 100).toFixed(3)}%</p>
                </div>
              </TooltipContent>
            </Tooltip>
          </div>
        </TableCell>

        {/* Risk Score */}
        <TableCell className="text-center">
          <div className="space-y-1">
            <div className={`text-sm font-semibold ${getRiskColor(opportunity.riskScore)}`}>
              {opportunity.riskScore.toFixed(0)}%
            </div>
            <div className="flex items-center justify-center">
              {opportunity.riskScore < 30 ? (
                <CheckCircle className="h-3 w-3 text-profit" />
              ) : opportunity.riskScore < 60 ? (
                <WarningCircle className="h-3 w-3 text-warning" />
              ) : (
                <WarningCircle className="h-3 w-3 text-destructive" />
              )}
            </div>
          </div>
        </TableCell>

        {/* Tiempo de Ejecución */}
        <TableCell className="text-center">
          <div className="space-y-1">
            <div className="text-sm font-medium">
              {opportunity.executionTime.toFixed(0)}s
            </div>
            <Tooltip>
              <TooltipTrigger>
                <div className={`text-xs flex items-center justify-center gap-1 ${
                  isExpiringSoon ? 'text-destructive' : 'text-muted-foreground'
                }`}>
                  <Timer className="h-3 w-3" />
                  {minutesToExpiry}:{secondsToExpiry.toString().padStart(2, '0')}
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Tiempo restante antes de expiración</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </TableCell>

        {/* Confianza */}
        <TableCell className="text-center">
          <div className="space-y-1">
            <div className={`text-sm font-semibold ${getConfidenceColor(opportunity.confidence)}`}>
              {(opportunity.confidence * 100).toFixed(0)}%
            </div>
            <div className="flex items-center justify-center">
              {opportunity.confidence > 0.8 ? (
                <CheckCircle className="h-3 w-3 text-profit" />
              ) : opportunity.confidence > 0.6 ? (
                <Shield className="h-3 w-3 text-warning" />
              ) : (
                <WarningCircle className="h-3 w-3 text-destructive" />
              )}
            </div>
          </div>
        </TableCell>

        {/* Botón de Ejecución */}
        <TableCell className="text-center">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="sm"
                onClick={onExecute}
                disabled={isExecuting || isExpiringSoon}
                className={`flex items-center gap-1 ${
                  isExpiringSoon 
                    ? 'bg-destructive/10 text-destructive hover:bg-destructive/20' 
                    : ''
                }`}
                variant={environment === 'test' ? 'outline' : 'default'}
              >
                {isExecuting ? (
                  <>
                    <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    <span className="hidden sm:inline">Ejecutando...</span>
                  </>
                ) : isExpiringSoon ? (
                  <>
                    <WarningCircle className="h-3 w-3" />
                    <span className="hidden sm:inline">Expirado</span>
                  </>
                ) : (
                  <>
                    <Play className="h-3 w-3" />
                    <span className="hidden sm:inline">Execute</span>
                  </>
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <div className="space-y-1 text-xs max-w-48">
                <p className="font-medium">
                  {isExpiringSoon 
                    ? 'Oportunidad expirada' 
                    : `Ejecutar estrategia ${opportunity.strategyName}`
                  }
                </p>
                {!isExpiringSoon && (
                  <>
                    <p>Capital mínimo: ${opportunity.minCapital.toLocaleString()}</p>
                    <p>Liquidez disponible: ${opportunity.liquidityDepth.toLocaleString()}</p>
                    {environment === 'test' && (
                      <p className="text-warning">🧪 Modo simulación</p>
                    )}
                  </>
                )}
              </div>
            </TooltipContent>
          </Tooltip>
        </TableCell>
      </TableRow>
    </TooltipProvider>
  )
}

export default OpportunityRow