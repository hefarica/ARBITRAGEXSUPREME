// 🚀 ARBITRAGE ENGINE CARD - Inspirado en Balancer V2 + Hummingbot Architecture
// Card principal para el motor de arbitraje con métricas en tiempo real

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Switch } from '../ui/switch'
import { Badge } from '../ui/badge'
import { Progress } from '../ui/progress'
import { 
  TrendUp, 
  Lightning, 
  CurrencyDollar, 
  Activity,
  Target,
  Shield,
  WarningCircle,
  CheckCircle,
  Play,
  Pause
} from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useKV } from '@/hooks/useKV'
import { ArbitrageMetrics, EngineStatus } from '../../types/strategy.types'

// LED de estado reutilizable
const StatusLED: React.FC<{ 
  status: 'error' | 'executing' | 'ready' | 'stopped'
  className?: string 
}> = ({ status, className = "" }) => {
  const getStatusConfig = () => {
    switch (status) {
      case 'error':
        return { color: 'bg-destructive', pulse: 'animate-pulse', label: 'Error' }
      case 'executing':
        return { color: 'bg-warning', pulse: 'animate-pulse', label: 'Ejecutando' }
      case 'ready':
        return { color: 'bg-profit', pulse: '', label: 'Listo' }
      case 'stopped':
        return { color: 'bg-muted', pulse: '', label: 'Detenido' }
      default:
        return { color: 'bg-muted', pulse: '', label: 'Desconocido' }
    }
  }

  const config = getStatusConfig()
  
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className={`w-3 h-3 rounded-full ${config.color} ${config.pulse}`} />
      <span className="text-sm font-medium">{config.label}</span>
    </div>
  )
}

// Simulación de API calls
const fetchArbitrageMetrics = async (): Promise<ArbitrageMetrics> => {
  // En producción esto viene del backend /api/arbitrage/metrics
  await new Promise(resolve => setTimeout(resolve, 100))
  
  return {
    opportunities: {
      total: Math.floor(Math.random() * 50) + 20,
      profitable: Math.floor(Math.random() * 30) + 15,
      executed: Math.floor(Math.random() * 20) + 8,
      missed: Math.floor(Math.random() * 10) + 2
    },
    profitability: {
      totalProfit: Math.random() * 5000 + 1000,
      avgProfitPerTrade: Math.random() * 50 + 10,
      maxProfit: Math.random() * 200 + 50,
      minProfit: Math.random() * 5 + 1,
      profitMargin: Math.random() * 2 + 0.5
    },
    risk: {
      maxDrawdown: Math.random() * 5 + 1,
      volatility: Math.random() * 10 + 5,
      sharpeRatio: Math.random() * 2 + 1,
      sortinoRatio: Math.random() * 3 + 1.5
    },
    execution: {
      avgExecutionTime: Math.random() * 30 + 10,
      successRate: Math.random() * 20 + 80,
      gasEfficiency: Math.floor(Math.random() * 4) + 7,
      mevProtection: Math.random() * 15 + 85
    }
  }
}

const fetchEngineStatus = async (): Promise<EngineStatus> => {
  await new Promise(resolve => setTimeout(resolve, 50))
  
  const isRunning = Math.random() > 0.3
  
  return {
    isRunning,
    mode: isRunning ? 'auto' : 'manual',
    totalOpportunities: Math.floor(Math.random() * 100) + 50,
    executedTrades: Math.floor(Math.random() * 30) + 10,
    totalProfit: Math.random() * 10000 + 2000,
    successRate: Math.random() * 20 + 75,
    currentLatency: Math.random() * 50 + 10,
    lastUpdate: Date.now(),
    errors: isRunning ? [] : ['Conexión RPC inestable', 'Gas price alto'],
    warnings: isRunning ? ['Baja liquidez en ETH/USDC'] : []
  }
}

// Mutations para ejecutar operaciones
const executeArbitrage = async (): Promise<{ success: boolean; message: string }> => {
  await new Promise(resolve => setTimeout(resolve, 2000))
  
  if (Math.random() > 0.2) {
    return { success: true, message: 'Arbitraje ejecutado exitosamente' }
  } else {
    throw new Error('Error al ejecutar arbitraje: Gas price demasiado alto')
  }
}

export const ArbitrageEngineCard: React.FC = () => {
  const queryClient = useQueryClient()
  const [autoRun, setAutoRun] = useKV('arbitrage-auto-run', false)
  const [lastExecution, setLastExecution] = useState<Date | null>(null)

  // Queries para datos en tiempo real
  const { 
    data: metrics, 
    isLoading: metricsLoading,
    error: metricsError 
  } = useQuery({
    queryKey: ['arbitrage-metrics'],
    queryFn: fetchArbitrageMetrics,
    refetchInterval: 5000, // Actualiza cada 5 segundos
    staleTime: 2000
  })

  const { 
    data: status, 
    isLoading: statusLoading 
  } = useQuery({
    queryKey: ['arbitrage-status'],
    queryFn: fetchEngineStatus,
    refetchInterval: 2000, // Actualiza cada 2 segundos
    staleTime: 1000
  })

  // Mutation para ejecutar arbitraje
  const executeMutation = useMutation({
    mutationFn: executeArbitrage,
    onSuccess: (data) => {
      setLastExecution(new Date())
      // Invalidar queries para refrescar datos
      queryClient.invalidateQueries({ queryKey: ['arbitrage-metrics'] })
      queryClient.invalidateQueries({ queryKey: ['arbitrage-status'] })
    },
    onError: (error) => {
      console.error('Error ejecutando arbitraje:', error)
    }
  })

  // Auto-run interval management
  useEffect(() => {
    if (!autoRun || !status?.isRunning) return

    const interval = setInterval(() => {
      // Solo ejecutar si hay oportunidades rentables
      if (metrics && metrics.opportunities.profitable > 0) {
        executeMutation.mutate()
      }
    }, 30000) // Cada 30 segundos

    return () => clearInterval(interval)
  }, [autoRun, status?.isRunning, metrics, executeMutation])

  const handleRunNow = () => {
    executeMutation.mutate()
  }

  const getStatusFromEngine = (): 'error' | 'executing' | 'ready' | 'stopped' => {
    if (!status) return 'stopped'
    if (status.errors.length > 0) return 'error'
    if (executeMutation.isPending) return 'executing'
    if (status.isRunning) return 'ready'
    return 'stopped'
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const formatPercent = (value: number) => {
    return `${value.toFixed(1)}%`
  }

  if (metricsLoading || statusLoading) {
    return (
      <Card className="hover-lift">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="h-32 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (metricsError) {
    return (
      <Card className="hover-lift border-destructive">
        <CardContent className="p-6">
          <div className="text-destructive text-center">
            <WarningCircle className="w-8 h-8 mx-auto mb-2" />
            <p>Error cargando métricas del motor de arbitraje</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="hover-lift">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendUp className="w-5 h-5 text-primary" />
            Motor de Arbitraje Multi-Estrategia
          </CardTitle>
          <StatusLED status={getStatusFromEngine()} />
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Métricas principales */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <CurrencyDollar className="w-4 h-4 text-profit" />
              <span className="text-sm text-muted-foreground">Ganancia Total</span>
            </div>
            <p className="text-2xl font-bold text-profit">
              {formatCurrency(metrics?.profitability.totalProfit || 0)}
            </p>
            <p className="text-xs text-muted-foreground">
              Promedio: {formatCurrency(metrics?.profitability.avgProfitPerTrade || 0)}/trade
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">Tasa de Éxito</span>
            </div>
            <p className="text-2xl font-bold">
              {formatPercent(status?.successRate || 0)}
            </p>
            <p className="text-xs text-muted-foreground">
              {metrics?.opportunities.executed || 0} / {metrics?.opportunities.total || 0} ejecutadas
            </p>
          </div>
        </div>

        {/* Progress bars de rendimiento */}
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Eficiencia de Gas</span>
              <span>{metrics?.execution.gasEfficiency || 0}/10</span>
            </div>
            <Progress 
              value={(metrics?.execution.gasEfficiency || 0) * 10} 
              className="h-2"
            />
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Protección MEV</span>
              <span>{formatPercent(metrics?.execution.mevProtection || 0)}</span>
            </div>
            <Progress 
              value={metrics?.execution.mevProtection || 0} 
              className="h-2"
            />
          </div>
        </div>

        {/* Métricas de riesgo */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 bg-muted/50 rounded">
            <p className="text-xs text-muted-foreground">Sharpe Ratio</p>
            <p className="font-semibold">{metrics?.risk.sharpeRatio.toFixed(2) || 0}</p>
          </div>
          <div className="p-2 bg-muted/50 rounded">
            <p className="text-xs text-muted-foreground">Max Drawdown</p>
            <p className="font-semibold text-destructive">
              -{formatPercent(metrics?.risk.maxDrawdown || 0)}
            </p>
          </div>
          <div className="p-2 bg-muted/50 rounded">
            <p className="text-xs text-muted-foreground">Latencia</p>
            <p className="font-semibold">{status?.currentLatency.toFixed(1) || 0}ms</p>
          </div>
        </div>

        {/* Alertas y avisos */}
        {status?.errors && status.errors.length > 0 && (
          <div className="p-3 bg-destructive/10 border border-destructive/20 rounded">
            <div className="flex items-center gap-2 mb-2">
              <WarningCircle className="w-4 h-4 text-destructive" />
              <span className="text-sm font-medium text-destructive">Errores Activos</span>
            </div>
            <ul className="text-xs space-y-1">
              {status.errors.map((error, index) => (
                <li key={index} className="text-destructive">• {error}</li>
              ))}
            </ul>
          </div>
        )}

        {status?.warnings && status.warnings.length > 0 && (
          <div className="p-3 bg-warning/10 border border-warning/20 rounded">
            <div className="flex items-center gap-2 mb-2">
              <WarningCircle className="w-4 h-4 text-warning" />
              <span className="text-sm font-medium text-warning">Advertencias</span>
            </div>
            <ul className="text-xs space-y-1">
              {status.warnings.map((warning, index) => (
                <li key={index} className="text-warning">• {warning}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Controles de ejecución */}
        <div className="space-y-3 pt-3 border-t">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <label className="text-sm font-medium">Auto-Ejecución</label>
              <p className="text-xs text-muted-foreground">
                Ejecuta automáticamente cuando hay oportunidades
              </p>
            </div>
            <Switch
              checked={autoRun}
              onCheckedChange={setAutoRun}
              disabled={!status?.isRunning}
            />
          </div>

          <Button 
            onClick={handleRunNow}
            disabled={
              executeMutation.isPending || 
              !status?.isRunning || 
              (metrics?.opportunities.profitable || 0) === 0
            }
            className="w-full"
            size="lg"
          >
            {executeMutation.isPending ? (
              <>
                <Activity className="w-4 h-4 mr-2 animate-spin" />
                Ejecutando...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Ejecutar Ahora
              </>
            )}
          </Button>

          {lastExecution && (
            <p className="text-xs text-muted-foreground text-center">
              Última ejecución: {lastExecution.toLocaleTimeString()}
            </p>
          )}
        </div>

        {/* Estado de oportunidades */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-profit rounded-full animate-pulse" />
            <span>
              {metrics?.opportunities.profitable || 0} oportunidades rentables detectadas
            </span>
          </div>
          {metrics?.opportunities.profitable && metrics.opportunities.profitable > 0 && (
            <Badge variant="secondary" className="bg-profit/10 text-profit">
              {metrics.opportunities.profitable} disponibles
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  )
}