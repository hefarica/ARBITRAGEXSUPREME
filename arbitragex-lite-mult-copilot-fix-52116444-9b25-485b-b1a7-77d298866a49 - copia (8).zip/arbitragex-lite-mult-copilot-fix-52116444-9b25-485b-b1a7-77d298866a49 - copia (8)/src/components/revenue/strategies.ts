/**
 * Estrategias de Arbitraje - Ranking ROI 2025
 * Ordenadas por potencial de rentabilidad y complejidad de implementación
 */

export interface StrategyInfo {
  id: string
  label: string
  description: string
  roi2025: number // Puntuación de 1-10 para ordenamiento
  complexity: 'low' | 'medium' | 'high' | 'expert'
  riskLevel: 'low' | 'medium' | 'high'
  avgProfitPercentage: number
  executionTimeMs: number
  capitalRequirement: number // USD mínimo
  successRate: number // Porcentaje histórico
  requirements: {
    flashLoanAvailable?: boolean
    crossChain?: boolean
    multiDex?: boolean
    atomicSwap?: boolean
    advancedRouting?: boolean
  }
  supportedBlockchains: string[]
  technicalDetails: {
    gasUsage: 'low' | 'medium' | 'high'
    mevVulnerability: 'low' | 'medium' | 'high'
    liquidityDependency: 'low' | 'medium' | 'high'
  }
}

export const strategies: StrategyInfo[] = [
  {
    id: 'cross-chain-multi-hop-flash-loan',
    label: 'Cross-Chain Multi-Hop Flash-Loan',
    description: 'Arbitraje complejo que combina flash loans con rutas multi-salto entre diferentes blockchains para maximizar profit mediante optimización de rutas cross-chain.',
    roi2025: 10,
    complexity: 'expert',
    riskLevel: 'high',
    avgProfitPercentage: 2.5,
    executionTimeMs: 8000,
    capitalRequirement: 0, // Flash loan no requiere capital
    successRate: 78,
    requirements: {
      flashLoanAvailable: true,
      crossChain: true,
      multiDex: true,
      advancedRouting: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc'],
    technicalDetails: {
      gasUsage: 'high',
      mevVulnerability: 'high',
      liquidityDependency: 'high'
    }
  },
  {
    id: 'cross-chain-cross-dex',
    label: 'Cross-Chain Cross-DEX',
    description: 'Arbitraje entre diferentes DEXs en distintas blockchains, aprovechando diferencias de precios cross-chain con bridges optimizados.',
    roi2025: 9,
    complexity: 'high',
    riskLevel: 'medium',
    avgProfitPercentage: 1.8,
    executionTimeMs: 6000,
    capitalRequirement: 1000,
    successRate: 85,
    requirements: {
      crossChain: true,
      multiDex: true,
      advancedRouting: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche'],
    technicalDetails: {
      gasUsage: 'high',
      mevVulnerability: 'medium',
      liquidityDependency: 'medium'
    }
  },
  {
    id: 'flash-loan-triangular-cross-dex',
    label: 'Flash-Loan Triangular Cross-DEX',
    description: 'Arbitraje triangular usando flash loans entre múltiples DEXs, optimizando rutas de 3+ tokens para maximizar eficiencia.',
    roi2025: 8,
    complexity: 'high',
    riskLevel: 'medium',
    avgProfitPercentage: 1.5,
    executionTimeMs: 4000,
    capitalRequirement: 0,
    successRate: 82,
    requirements: {
      flashLoanAvailable: true,
      multiDex: true,
      advancedRouting: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'bsc'],
    technicalDetails: {
      gasUsage: 'medium',
      mevVulnerability: 'medium',
      liquidityDependency: 'medium'
    }
  },
  {
    id: 'multi-hop-cross-dex',
    label: 'Multi-Hop Cross-DEX',
    description: 'Arbitraje con múltiples saltos entre DEXs en la misma blockchain, usando rutas optimizadas de 3-5 saltos.',
    roi2025: 7,
    complexity: 'high',
    riskLevel: 'medium',
    avgProfitPercentage: 1.2,
    executionTimeMs: 3000,
    capitalRequirement: 500,
    successRate: 88,
    requirements: {
      multiDex: true,
      advancedRouting: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche'],
    technicalDetails: {
      gasUsage: 'medium',
      mevVulnerability: 'medium',
      liquidityDependency: 'medium'
    }
  },
  {
    id: 'flash-loan-cross-dex',
    label: 'Flash-Loan Cross-DEX',
    description: 'Arbitraje básico usando flash loans entre dos DEXs diferentes en la misma blockchain.',
    roi2025: 6,
    complexity: 'medium',
    riskLevel: 'medium',
    avgProfitPercentage: 0.8,
    executionTimeMs: 2500,
    capitalRequirement: 0,
    successRate: 90,
    requirements: {
      flashLoanAvailable: true,
      multiDex: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'bsc'],
    technicalDetails: {
      gasUsage: 'medium',
      mevVulnerability: 'medium',
      liquidityDependency: 'low'
    }
  },
  {
    id: 'triangular-inter-dex',
    label: 'Triangular Inter-DEX',
    description: 'Arbitraje triangular clásico entre diferentes DEXs usando 3 tokens (A→B→C→A).',
    roi2025: 5,
    complexity: 'medium',
    riskLevel: 'low',
    avgProfitPercentage: 0.6,
    executionTimeMs: 2000,
    capitalRequirement: 100,
    successRate: 92,
    requirements: {
      multiDex: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche'],
    technicalDetails: {
      gasUsage: 'low',
      mevVulnerability: 'low',
      liquidityDependency: 'low'
    }
  },
  {
    id: 'triangular-intra-dex',
    label: 'Triangular Intra-DEX',
    description: 'Arbitraje triangular dentro del mismo DEX, aprovechando ineficiencias en pools relacionados.',
    roi2025: 4,
    complexity: 'low',
    riskLevel: 'low',
    avgProfitPercentage: 0.4,
    executionTimeMs: 1500,
    capitalRequirement: 50,
    successRate: 95,
    requirements: {},
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche'],
    technicalDetails: {
      gasUsage: 'low',
      mevVulnerability: 'low',
      liquidityDependency: 'low'
    }
  },
  {
    id: 'atomic-swap-cross-dex',
    label: 'Atomic Swap Cross-DEX',
    description: 'Intercambios atómicos entre DEXs para garantizar ejecución sin riesgo de contrapartida.',
    roi2025: 3,
    complexity: 'high',
    riskLevel: 'low',
    avgProfitPercentage: 0.5,
    executionTimeMs: 3500,
    capitalRequirement: 200,
    successRate: 98,
    requirements: {
      atomicSwap: true,
      multiDex: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum'],
    technicalDetails: {
      gasUsage: 'medium',
      mevVulnerability: 'low',
      liquidityDependency: 'medium'
    }
  },
  {
    id: 'atomic-swap-intra-dex',
    label: 'Atomic Swap Intra-DEX',
    description: 'Intercambios atómicos dentro del mismo DEX para operaciones sin riesgo.',
    roi2025: 2,
    complexity: 'medium',
    riskLevel: 'low',
    avgProfitPercentage: 0.3,
    executionTimeMs: 2000,
    capitalRequirement: 100,
    successRate: 99,
    requirements: {
      atomicSwap: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc'],
    technicalDetails: {
      gasUsage: 'low',
      mevVulnerability: 'low',
      liquidityDependency: 'low'
    }
  },
  {
    id: 'basic-cross-dex',
    label: 'Basic Cross-DEX',
    description: 'Arbitraje básico entre dos DEXs diferentes aprovechando diferencias de precio simples.',
    roi2025: 1,
    complexity: 'low',
    riskLevel: 'low',
    avgProfitPercentage: 0.2,
    executionTimeMs: 1000,
    capitalRequirement: 50,
    successRate: 96,
    requirements: {
      multiDex: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche'],
    technicalDetails: {
      gasUsage: 'low',
      mevVulnerability: 'low',
      liquidityDependency: 'low'
    }
  },
  {
    id: 'basic-flash-loan',
    label: 'Basic Flash-Loan',
    description: 'Arbitraje básico usando flash loans para operaciones sin capital inicial.',
    roi2025: 1,
    complexity: 'medium',
    riskLevel: 'medium',
    avgProfitPercentage: 0.3,
    executionTimeMs: 1800,
    capitalRequirement: 0,
    successRate: 88,
    requirements: {
      flashLoanAvailable: true
    },
    supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'bsc'],
    technicalDetails: {
      gasUsage: 'medium',
      mevVulnerability: 'medium',
      liquidityDependency: 'low'
    }
  }
]

// Funciones de utilidad para trabajar con estrategias
export const getStrategyById = (id: string): StrategyInfo | undefined => {
  return strategies.find(strategy => strategy.id === id)
}

export const getStrategiesByComplexity = (complexity: StrategyInfo['complexity']): StrategyInfo[] => {
  return strategies.filter(strategy => strategy.complexity === complexity)
}

export const getStrategiesByRisk = (riskLevel: StrategyInfo['riskLevel']): StrategyInfo[] => {
  return strategies.filter(strategy => strategy.riskLevel === riskLevel)
}

export const getStrategiesByBlockchain = (blockchain: string): StrategyInfo[] => {
  return strategies.filter(strategy => strategy.supportedBlockchains.includes(blockchain))
}

export const getTopStrategies = (count: number = 5): StrategyInfo[] => {
  return strategies
    .sort((a, b) => b.roi2025 - a.roi2025)
    .slice(0, count)
}

export const getStrategyComplexityColor = (complexity: StrategyInfo['complexity']): string => {
  switch (complexity) {
    case 'low': return 'success'
    case 'medium': return 'warning'
    case 'high': return 'error'
    case 'expert': return 'secondary'
    default: return 'default'
  }
}

export const getStrategyRiskColor = (riskLevel: StrategyInfo['riskLevel']): string => {
  switch (riskLevel) {
    case 'low': return 'success'
    case 'medium': return 'warning'
    case 'high': return 'error'
    default: return 'default'
  }
}

// Configuración por defecto para estrategias
export const defaultStrategyConfig = {
  maxSlippage: 0.5, // 0.5%
  maxGasPrice: 100, // gwei
  minProfitUSD: 10,
  timeoutMs: 10000,
  retryAttempts: 3,
  mevProtection: true,
  autoExecution: false
}

// Mapeo de estrategias a tipos para TypeScript
export type StrategyType = 
  | 'cross-chain-multi-hop-flash-loan'
  | 'cross-chain-cross-dex'
  | 'flash-loan-triangular-cross-dex'
  | 'multi-hop-cross-dex'
  | 'flash-loan-cross-dex'
  | 'triangular-inter-dex'
  | 'triangular-intra-dex'
  | 'atomic-swap-cross-dex'
  | 'atomic-swap-intra-dex'
  | 'basic-cross-dex'
  | 'basic-flash-loan'