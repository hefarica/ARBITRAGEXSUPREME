// ⚡ HFT ENGINE CARD - Inspirado en arquitectura de trading de alta frecuencia
// Card para motor HFT con métricas de latencia y throughput ultra-optimizadas

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Switch } from '../ui/switch'
import { Badge } from '../ui/badge'
import { Progress } from '../ui/progress'
import { 
  Lightning, 
  Clock, 
  Cpu, 
  MemoryStick,
  Network,
  Activity,
  Gauge,
  Timer,
  Gear,
  WarningCircle,
  CheckCircle,
  Play,
  Square
} from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useKV } from '@/hooks/useKV'
import { HFTMetrics, EngineStatus } from '../../types/strategy.types'

// LED específico para HFT con códigos de colores diferentes
const HFTStatusLED: React.FC<{ 
  latency: number
  className?: string 
}> = ({ latency, className = "" }) => {
  const getLatencyStatus = () => {
    if (latency < 10) {
      return { color: 'bg-green-500', pulse: '', label: 'Ultra-Low', level: 'excellent' }
    } else if (latency < 50) {
      return { color: 'bg-profit', pulse: '', label: 'Low', level: 'good' }
    } else if (latency < 100) {
      return { color: 'bg-warning', pulse: 'animate-pulse', label: 'Medium', level: 'acceptable' }
    } else {
      return { color: 'bg-destructive', pulse: 'animate-pulse', label: 'High', level: 'poor' }
    }
  }

  const config = getLatencyStatus()
  
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className={`w-3 h-3 rounded-full ${config.color} ${config.pulse}`} />
      <span className="text-sm font-medium">{config.label} Latency</span>
      <Badge variant="outline" className="text-xs">
        {latency.toFixed(1)}μs
      </Badge>
    </div>
  )
}

// Simulación de API calls para HFT
const fetchHFTMetrics = async (): Promise<HFTMetrics> => {
  await new Promise(resolve => setTimeout(resolve, 50)) // HFT debe ser más rápido
  
  return {
    latency: {
      orderToExecution: Math.random() * 100 + 5,     // 5-105 μs
      priceUpdate: Math.random() * 20 + 1,           // 1-21 μs  
      networkRoundTrip: Math.random() * 200 + 10     // 10-210 μs
    },
    throughput: {
      ordersPerSecond: Math.random() * 10000 + 5000,   // 5k-15k ops
      updatesPerSecond: Math.random() * 50000 + 25000, // 25k-75k updates/s
      executionsPerSecond: Math.random() * 1000 + 500  // 500-1500 exec/s
    },
    performance: {
      fillRate: Math.random() * 15 + 85,               // 85-100%
      slippage: Math.random() * 0.05,                  // 0-0.05%
      rejectionRate: Math.random() * 5                 // 0-5%
    },
    hardware: {
      cpuUsage: Math.random() * 40 + 20,               // 20-60%
      memoryUsage: Math.random() * 30 + 40,            // 40-70%
      networkBandwidth: Math.random() * 500 + 100      // 100-600 Mbps
    }
  }
}

const fetchHFTStatus = async (): Promise<EngineStatus> => {
  await new Promise(resolve => setTimeout(resolve, 25))
  
  const isRunning = Math.random() > 0.2
  
  return {
    isRunning,
    mode: isRunning ? 'auto' : 'manual',
    totalOpportunities: Math.floor(Math.random() * 1000) + 500,
    executedTrades: Math.floor(Math.random() * 800) + 200,
    totalProfit: Math.random() * 15000 + 5000,
    successRate: Math.random() * 10 + 90, // HFT debe tener alta tasa de éxito
    currentLatency: Math.random() * 50 + 5,
    lastUpdate: Date.now(),
    errors: isRunning ? [] : ['CPU affinity no configurada', 'Memoria insuficiente'],
    warnings: isRunning ? ['Alta latencia de red detectada'] : []
  }
}

// Mutation para HFT
const executeHFT = async (): Promise<{ success: boolean; message: string; execTime: number }> => {
  const execTime = Math.random() * 10 + 2 // 2-12ms
  await new Promise(resolve => setTimeout(resolve, execTime))
  
  if (Math.random() > 0.05) { // 95% tasa de éxito para HFT
    return { 
      success: true, 
      message: `HFT ejecutado en ${execTime.toFixed(2)}ms`, 
      execTime 
    }
  } else {
    throw new Error('Error HFT: Latencia de red excesiva')
  }
}

export const HFTEngineCard: React.FC = () => {
  const queryClient = useQueryClient()
  const [autoRun, setAutoRun] = useKV('hft-auto-run', false)
  const [executionCount, setExecutionCount] = useState(0)
  const [lastExecutionTime, setLastExecutionTime] = useState<number | null>(null)

  // Queries para HFT - con intervalos más frecuentes
  const { 
    data: metrics, 
    isLoading: metricsLoading,
    error: metricsError 
  } = useQuery({
    queryKey: ['hft-metrics'],
    queryFn: fetchHFTMetrics,
    refetchInterval: 1000, // Actualiza cada segundo para HFT
    staleTime: 500
  })

  const { 
    data: status, 
    isLoading: statusLoading 
  } = useQuery({
    queryKey: ['hft-status'],
    queryFn: fetchHFTStatus,
    refetchInterval: 1000,
    staleTime: 500
  })

  // Mutation para HFT
  const executeMutation = useMutation({
    mutationFn: executeHFT,
    onSuccess: (data) => {
      setExecutionCount(prev => prev + 1)
      setLastExecutionTime(data.execTime)
      queryClient.invalidateQueries({ queryKey: ['hft-metrics'] })
      queryClient.invalidateQueries({ queryKey: ['hft-status'] })
    },
    onError: (error) => {
      console.error('Error ejecutando HFT:', error)
    }
  })

  // Auto-run interval para HFT - más frecuente
  useEffect(() => {
    if (!autoRun || !status?.isRunning) return

    const interval = setInterval(() => {
      // HFT ejecuta con mayor frecuencia
      if (metrics && metrics.latency.orderToExecution < 100) {
        executeMutation.mutate()
      }
    }, 5000) // Cada 5 segundos para HFT

    return () => clearInterval(interval)
  }, [autoRun, status?.isRunning, metrics, executeMutation])

  const handleRunNow = () => {
    executeMutation.mutate()
  }

  const getLatencyLevel = (latency: number): 'excellent' | 'good' | 'acceptable' | 'poor' => {
    if (latency < 10) return 'excellent'
    if (latency < 50) return 'good'
    if (latency < 100) return 'acceptable'
    return 'poor'
  }

  const formatNumber = (value: number, decimals = 0) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`
    } else if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}K`
    }
    return value.toFixed(decimals)
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  if (metricsLoading || statusLoading) {
    return (
      <Card className="hover-lift">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="h-32 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (metricsError) {
    return (
      <Card className="hover-lift border-destructive">
        <CardContent className="p-6">
          <div className="text-destructive text-center">
            <WarningCircle className="w-8 h-8 mx-auto mb-2" />
            <p>Error cargando métricas del motor HFT</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="hover-lift">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Lightning className="w-5 h-5 text-yellow-500" />
            Motor HFT Ultra-Baja Latencia
          </CardTitle>
          <HFTStatusLED latency={metrics?.latency.orderToExecution || 0} />
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Métricas de latencia críticas */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-muted/30 rounded-lg">
            <Timer className="w-5 h-5 mx-auto mb-2 text-primary" />
            <p className="text-lg font-bold">
              {metrics?.latency.orderToExecution.toFixed(1)}μs
            </p>
            <p className="text-xs text-muted-foreground">Order → Execution</p>
          </div>

          <div className="text-center p-3 bg-muted/30 rounded-lg">
            <Activity className="w-5 h-5 mx-auto mb-2 text-green-500" />
            <p className="text-lg font-bold">
              {metrics?.latency.priceUpdate.toFixed(1)}μs
            </p>
            <p className="text-xs text-muted-foreground">Price Update</p>
          </div>

          <div className="text-center p-3 bg-muted/30 rounded-lg">
            <Network className="w-5 h-5 mx-auto mb-2 text-blue-500" />
            <p className="text-lg font-bold">
              {metrics?.latency.networkRoundTrip.toFixed(1)}μs
            </p>
            <p className="text-xs text-muted-foreground">Network RTT</p>
          </div>
        </div>

        {/* Throughput metrics */}
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="flex items-center gap-2">
                <Gauge className="w-4 h-4" />
                Órdenes/segundo
              </span>
              <span className="font-mono">
                {formatNumber(metrics?.throughput.ordersPerSecond || 0)}
              </span>
            </div>
            <Progress 
              value={(metrics?.throughput.ordersPerSecond || 0) / 150} // Max 15k
              className="h-2"
            />
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Updates/segundo
              </span>
              <span className="font-mono">
                {formatNumber(metrics?.throughput.updatesPerSecond || 0)}
              </span>
            </div>
            <Progress 
              value={(metrics?.throughput.updatesPerSecond || 0) / 750} // Max 75k
              className="h-2"
            />
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Ejecuciones/segundo
              </span>
              <span className="font-mono">
                {formatNumber(metrics?.throughput.executionsPerSecond || 0)}
              </span>
            </div>
            <Progress 
              value={(metrics?.throughput.executionsPerSecond || 0) / 15} // Max 1.5k
              className="h-2"
            />
          </div>
        </div>

        {/* Performance metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-profit" />
              <span className="text-sm text-muted-foreground">Fill Rate</span>
            </div>
            <p className="text-xl font-bold text-profit">
              {metrics?.performance.fillRate.toFixed(2)}%
            </p>
            <p className="text-xs text-muted-foreground">
              Slippage: {metrics?.performance.slippage.toFixed(3)}%
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <WarningCircle className="w-4 h-4 text-warning" />
              <span className="text-sm text-muted-foreground">Rejection Rate</span>
            </div>
            <p className="text-xl font-bold">
              {metrics?.performance.rejectionRate.toFixed(2)}%
            </p>
            <p className="text-xs text-muted-foreground">
              Total: {formatCurrency(status?.totalProfit || 0)}
            </p>
          </div>
        </div>

        {/* Hardware metrics */}
        <div className="p-3 bg-muted/20 rounded-lg">
          <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
            <Gear className="w-4 h-4" />
            Estado del Hardware
          </h4>
          
          <div className="grid grid-cols-3 gap-3 text-sm">
            <div>
              <div className="flex items-center gap-1 mb-1">
                <Cpu className="w-3 h-3" />
                <span className="text-xs">CPU</span>
              </div>
              <div className="flex items-center gap-2">
                <Progress value={metrics?.hardware.cpuUsage || 0} className="h-1 flex-1" />
                <span className="text-xs font-mono w-8">
                  {(metrics?.hardware.cpuUsage || 0).toFixed(0)}%
                </span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-1 mb-1">
                <MemoryStick className="w-3 h-3" />
                <span className="text-xs">RAM</span>
              </div>
              <div className="flex items-center gap-2">
                <Progress value={metrics?.hardware.memoryUsage || 0} className="h-1 flex-1" />
                <span className="text-xs font-mono w-8">
                  {(metrics?.hardware.memoryUsage || 0).toFixed(0)}%
                </span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-1 mb-1">
                <Network className="w-3 h-3" />
                <span className="text-xs">Net</span>
              </div>
              <div className="flex items-center gap-2">
                <Progress value={(metrics?.hardware.networkBandwidth || 0) / 10} className="h-1 flex-1" />
                <span className="text-xs font-mono w-12">
                  {formatNumber(metrics?.hardware.networkBandwidth || 0)}M
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Errores y warnings específicos de HFT */}
        {status?.errors && status.errors.length > 0 && (
          <div className="p-3 bg-destructive/10 border border-destructive/20 rounded">
            <div className="flex items-center gap-2 mb-2">
              <WarningCircle className="w-4 h-4 text-destructive" />
              <span className="text-sm font-medium text-destructive">Errores HFT</span>
            </div>
            <ul className="text-xs space-y-1">
              {status.errors.map((error, index) => (
                <li key={index} className="text-destructive">• {error}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Controles de ejecución HFT */}
        <div className="space-y-3 pt-3 border-t">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <label className="text-sm font-medium">Auto-Ejecución HFT</label>
              <p className="text-xs text-muted-foreground">
                Ejecución ultra-rápida cuando latencia {'<'} 100μs
              </p>
            </div>
            <Switch
              checked={autoRun}
              onCheckedChange={setAutoRun}
              disabled={!status?.isRunning}
            />
          </div>

          <Button 
            onClick={handleRunNow}
            disabled={
              executeMutation.isPending || 
              !status?.isRunning || 
              (metrics?.latency.orderToExecution || 0) > 100
            }
            className="w-full"
            size="lg"
            variant={getLatencyLevel(metrics?.latency.orderToExecution || 0) === 'excellent' ? 'default' : 'secondary'}
          >
            {executeMutation.isPending ? (
              <>
                <Activity className="w-4 h-4 mr-2 animate-spin" />
                Ejecutando HFT...
              </>
            ) : (
              <>
                <Lightning className="w-4 h-4 mr-2" />
                Ejecutar HFT
              </>
            )}
          </Button>

          {/* Estadísticas de ejecución */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Ejecuciones: {executionCount}</span>
            {lastExecutionTime && (
              <span>Última: {lastExecutionTime.toFixed(2)}ms</span>
            )}
            <span>Éxito: {status?.successRate.toFixed(1)}%</span>
          </div>
        </div>

        {/* Indicador de estado de latencia */}
        <div className="flex items-center justify-center text-sm">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              getLatencyLevel(metrics?.latency.orderToExecution || 0) === 'excellent' 
                ? 'bg-green-500 animate-pulse' 
                : getLatencyLevel(metrics?.latency.orderToExecution || 0) === 'good'
                ? 'bg-profit'
                : 'bg-warning'
            }`} />
            <span>
              Latencia {getLatencyLevel(metrics?.latency.orderToExecution || 0)} - 
              Modo {status?.mode || 'manual'}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}