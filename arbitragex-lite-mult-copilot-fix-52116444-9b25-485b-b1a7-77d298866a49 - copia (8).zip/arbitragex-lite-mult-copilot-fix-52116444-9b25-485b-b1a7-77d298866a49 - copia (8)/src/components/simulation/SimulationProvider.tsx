import React, { createContext, useContext, useState, ReactNode } from 'react'
import { useKV } from '@/hooks/useKV'

interface MarketData {
  symbol: string
  price: number
  change24h: number
  volume24h: number
  lastUpdate: number
}

interface SimulationState {
  isRunning: boolean
  balance: number
  totalPnL: number
  trades: Trade[]
  marketData: MarketData[]
}

interface Trade {
  id: string
  timestamp: number
  type: 'arbitrage' | 'triangular' | 'flash-loan'
  tokens: string[]
  amount: number
  profit: number
  fees: number
  status: 'pending' | 'executed' | 'failed'
}

interface SimulationContextType {
  state: SimulationState
  startSimulation: () => void
  stopSimulation: () => void
  resetSimulation: () => void
  executeTrade: (trade: Omit<Trade, 'id' | 'timestamp' | 'status'>) => void
  updateMarketData: (data: MarketData[]) => void
}

const SimulationContext = createContext<SimulationContextType | undefined>(undefined)

const initialState: SimulationState = {
  isRunning: false,
  balance: 10000, // Starting with $10k virtual balance
  totalPnL: 0,
  trades: [],
  marketData: [
    { symbol: 'ETH/USDC', price: 2150.50, change24h: 2.34, volume24h: 1250000, lastUpdate: Date.now() },
    { symbol: 'BTC/USDC', price: 43250.00, change24h: -1.20, volume24h: 2100000, lastUpdate: Date.now() },
    { symbol: 'USDT/USDC', price: 0.9998, change24h: 0.01, volume24h: 5500000, lastUpdate: Date.now() },
    { symbol: 'DAI/USDC', price: 1.0001, change24h: 0.00, volume24h: 850000, lastUpdate: Date.now() },
  ]
}

export function SimulationProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useKV<SimulationState>("simulation-state", initialState)

  const startSimulation = () => {
    setState(prev => ({ ...prev, isRunning: true }))
  }

  const stopSimulation = () => {
    setState(prev => ({ ...prev, isRunning: false }))
  }

  const resetSimulation = () => {
    setState({
      ...initialState,
      marketData: state.marketData // Keep current market data
    })
  }

  const executeTrade = (tradeInput: Omit<Trade, 'id' | 'timestamp' | 'status'>) => {
    const newTrade: Trade = {
      ...tradeInput,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      status: 'executed'
    }

    setState(prev => ({
      ...prev,
      trades: [newTrade, ...prev.trades].slice(0, 100), // Keep last 100 trades
      balance: prev.balance + newTrade.profit - newTrade.fees,
      totalPnL: prev.totalPnL + newTrade.profit - newTrade.fees
    }))
  }

  const updateMarketData = (data: MarketData[]) => {
    setState(prev => ({ ...prev, marketData: data }))
  }

  const contextValue: SimulationContextType = {
    state,
    startSimulation,
    stopSimulation,
    resetSimulation,
    executeTrade,
    updateMarketData
  }

  return (
    <SimulationContext.Provider value={contextValue}>
      {children}
    </SimulationContext.Provider>
  )
}

export function useSimulation() {
  const context = useContext(SimulationContext)
  if (context === undefined) {
    throw new Error('useSimulation must be used within a SimulationProvider')
  }
  return context
}