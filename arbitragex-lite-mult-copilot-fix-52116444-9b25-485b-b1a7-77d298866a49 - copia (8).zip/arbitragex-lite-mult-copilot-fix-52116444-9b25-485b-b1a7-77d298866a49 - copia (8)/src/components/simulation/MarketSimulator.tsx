import { useEffect, useState } from 'react'
import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { toast } from 'sonner'
import { Play, Pause, Repeat, Activity, CurrencyDollar } from '@phosphor-icons/react'

interface MarketSimulatorProps {
  onTradeGenerated?: () => void
}

export function MarketSimulator({ onTradeGenerated }: MarketSimulatorProps) {
  const { state, executeTrade, updateMarketData } = useSimulation()
  const [isSimulating, setIsSimulating] = useState(false)
  const [autoTrade, setAutoTrade] = useState(false)

  // Simulate market data updates
  useEffect(() => {
    if (!isSimulating) return

    const interval = setInterval(() => {
      const updatedMarketData = state.marketData.map(market => {
        // Simulate price movements with some volatility
        const changePercent = (Math.random() - 0.5) * 0.1 // ±5% max change
        const newPrice = market.price * (1 + changePercent)
        const volumeChange = (Math.random() - 0.5) * 0.2 // ±10% volume change
        const newSpeakerHigh = Math.max(market.volume24h * (1 + volumeChange), 10000)

        return {
          ...market,
          price: Math.max(newPrice, 0.001), // Prevent negative prices
          change24h: market.change24h + changePercent * 100,
          volume24h: newSpeakerHigh,
          lastUpdate: Date.now()
        }
      })

      updateMarketData(updatedMarketData)
    }, 2000) // Update every 2 seconds

    return () => clearInterval(interval)
  }, [isSimulating, state.marketData, updateMarketData])

  // Auto-generate trades for demo purposes
  useEffect(() => {
    if (!autoTrade || !isSimulating) return

    const tradeInterval = setInterval(() => {
      generateRandomTrade()
    }, 5000) // Generate a trade every 5 seconds

    return () => clearInterval(tradeInterval)
  }, [autoTrade, isSimulating])

  const generateRandomTrade = () => {
    const strategies = ['arbitrage', 'triangular', 'flash-loan'] as const
    const strategy = strategies[Math.floor(Math.random() * strategies.length)]
    
    // Get random tokens from market data
    const availableTokens = state.marketData.map(m => m.symbol.split('/')[0])
    const tokens = [
      availableTokens[Math.floor(Math.random() * availableTokens.length)],
      availableTokens[Math.floor(Math.random() * availableTokens.length)]
    ]

    // Generate realistic trade amounts and outcomes
    const amount = Math.random() * 5000 + 100 // $100 - $5,100
    const successRate = strategy === 'arbitrage' ? 0.75 : strategy === 'triangular' ? 0.65 : 0.55
    const isSuccessful = Math.random() < successRate
    
    const profit = isSuccessful 
      ? amount * (0.001 + Math.random() * 0.02) // 0.1% - 2% profit
      : amount * (-0.005 - Math.random() * 0.02) // -0.5% to -2.5% loss
    
    const fees = amount * (0.002 + Math.random() * 0.003) // 0.2% - 0.5% fees

    executeTrade({
      type: strategy,
      tokens,
      amount,
      profit,
      fees
    })

    onTradeGenerated?.()
    
    toast.success(`${strategy} trade executed`, {
      description: `${isSuccessful ? 'Profit' : 'Loss'}: $${profit.toFixed(2)}`
    })
  }

  const handleManualTrade = () => {
    generateRandomTrade()
  }

  const handleToggleSimulation = () => {
    setIsSimulating(!isSimulating)
    if (!isSimulating) {
      toast.success('Market simulation started')
    } else {
      toast.info('Market simulation stopped')
      setAutoTrade(false)
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity size={20} />
          Market Simulator
          <Badge className={isSimulating ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
            {isSimulating ? 'Active' : 'Stopped'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Market Data Updates</span>
          <Button
            variant={isSimulating ? "destructive" : "default"}
            size="sm"
            onClick={handleToggleSimulation}
            className="gap-2"
          >
            {isSimulating ? <Pause size={16} /> : <Play size={16} />}
            {isSimulating ? 'Stop' : 'Start'} Simulation
          </Button>
        </div>

        {isSimulating && (
          <>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Auto-Generate Trades</span>
              <Switch
                checked={autoTrade}
                onCheckedChange={setAutoTrade}
              />
            </div>

            <div className="pt-2 border-t">
              <Button
                variant="outline"
                size="sm"
                onClick={handleManualTrade}
                className="w-full gap-2"
              >
                <CurrencyDollar size={16} />
                Generate Manual Trade
              </Button>
            </div>
          </>
        )}

        {/* Current Market Status */}
        <div className="space-y-2 pt-2 border-t">
          <h4 className="text-sm font-medium">Live Market Data</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {state.marketData.slice(0, 4).map((market) => (
              <div key={market.symbol} className="flex justify-between p-2 bg-muted/50 rounded">
                <span className="font-medium">{market.symbol}</span>
                <div className="text-right">
                  <div className="font-medium">{formatCurrency(market.price)}</div>
                  <div className={`text-xs ${market.change24h >= 0 ? 'profit' : 'loss'}`}>
                    {market.change24h >= 0 ? '+' : ''}{market.change24h.toFixed(2)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Simulation Stats */}
        <div className="space-y-2 pt-2 border-t">
          <h4 className="text-sm font-medium">Simulation Status</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Total Trades</span>
              <p className="font-semibold">{state.trades.length}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Auto Mode</span>
              <p className="font-semibold">{autoTrade ? 'Enabled' : 'Disabled'}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}