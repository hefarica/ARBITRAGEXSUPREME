import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ChatTeardrop } from '@phosphor-icons/react'

interface SentimentTradingEngineProps {
  environment: 'test' | 'prod'
}

export default function SentimentTradingEngine({ environment }: SentimentTradingEngineProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ChatTeardrop size={24} className="text-primary" />
            Sentiment Trading Engine
          </CardTitle>
          <CardDescription>
            Social media analysis and sentiment-based trading decisions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-muted-foreground">
            <ChatTeardrop size={64} className="mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">Social Sentiment Analysis</h3>
            <p>NLP processing, sentiment scoring, and social media trading signals</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}