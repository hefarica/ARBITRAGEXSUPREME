import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { 
  LineChart, 
  TrendUp, 
  TrendDown, 
  Activity, 
  Cpu, 
  Globe, 
  Timer,
  Shield,
  Robot,
  Lightning
} from '@phosphor-icons/react'
import { useSimulation } from '../simulation/SimulationProvider'

interface EnhancedMainModuleProps {
  environment: 'test' | 'prod'
}

// Simulated real-time metrics
const generateMetrics = () => ({
  totalValue: Math.random() * 1000000 + 500000,
  dailyPnL: (Math.random() - 0.5) * 50000,
  winRate: Math.random() * 30 + 70,
  avgLatency: Math.random() * 2 + 0.5,
  throughput: Math.floor(Math.random() * 1000 + 500),
  activeStrategies: Math.floor(Math.random() * 8 + 12),
  riskScore: Math.random() * 40 + 20,
  systemHealth: Math.random() * 20 + 80,
  arbitrageOpportunities: Math.floor(Math.random() * 50 + 25),
  mevProtection: Math.random() * 10 + 90
})

const ModuleStatus = ({ name, status, metric }: { 
  name: string
  status: 'active' | 'warning' | 'error'
  metric?: string 
}) => {
  const statusColors = {
    active: 'bg-profit text-profit-foreground',
    warning: 'bg-warning text-warning-foreground', 
    error: 'bg-destructive text-destructive-foreground'
  }

  return (
    <div className="flex items-center justify-between p-3 border rounded-lg">
      <div className="flex items-center gap-3">
        <div className={`w-2 h-2 rounded-full ${statusColors[status].split(' ')[0]}`} />
        <span className="font-medium text-sm">{name}</span>
      </div>
      <div className="flex items-center gap-2">
        {metric && (
          <span className="text-xs text-muted-foreground">{metric}</span>
        )}
        <Badge 
          variant={status === 'active' ? 'default' : status === 'warning' ? 'secondary' : 'destructive'}
          className="text-xs"
        >
          {status}
        </Badge>
      </div>
    </div>
  )
}

export default function EnhancedMainModule({ environment }: EnhancedMainModuleProps) {
  const { state } = useSimulation()
  const [metrics, setMetrics] = useState(generateMetrics())
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(generateMetrics())
      setLastUpdate(new Date())
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  return (
    <div className="space-y-6">
      {/* Environment Alert */}
      <div className={`p-4 rounded-lg border ${environment === 'prod' ? 'bg-destructive/10 border-destructive/20' : 'bg-accent/10 border-accent/20'}`}>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            {environment === 'prod' ? (
              <Lightning size={20} className="text-destructive" />
            ) : (
              <Shield size={20} className="text-primary" />
            )}
            <h3 className="font-semibold">
              {environment === 'prod' ? 'Production Environment' : 'Test Environment'}
            </h3>
          </div>
          <Badge variant={environment === 'prod' ? 'destructive' : 'secondary'}>
            {environment === 'prod' ? 'Live Trading' : 'Simulation Mode'}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          {environment === 'prod' 
            ? 'All operations are using real funds and blockchain transactions'
            : 'Safe learning environment with simulated data and virtual funds'
          }
        </p>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Portfolio Value</CardTitle>
            <LineChart size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(metrics.totalValue)}</div>
            <p className="text-xs text-muted-foreground">
              +{((metrics.totalValue / 500000 - 1) * 100).toFixed(1)}% from baseline
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">24h P&L</CardTitle>
            {metrics.dailyPnL >= 0 ? (
              <TrendUp size={16} className="text-profit" />
            ) : (
              <TrendDown size={16} className="text-destructive" />
            )}
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${metrics.dailyPnL >= 0 ? 'profit' : 'loss'}`}>
              {formatCurrency(metrics.dailyPnL)}
            </div>
            <p className="text-xs text-muted-foreground">
              Win rate: {metrics.winRate.toFixed(1)}%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Latency</CardTitle>
            <Timer size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-profit">{metrics.avgLatency.toFixed(1)}ms</div>
            <p className="text-xs text-muted-foreground">
              Throughput: {metrics.throughput.toLocaleString()} TPS
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Strategies</CardTitle>
            <Robot size={16} className="text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.activeStrategies}</div>
            <p className="text-xs text-muted-foreground">
              {metrics.arbitrageOpportunities} opportunities detected
            </p>
          </CardContent>
        </Card>
      </div>

      {/* System Health Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity size={20} />
              System Health
            </CardTitle>
            <CardDescription>
              Real-time monitoring of all system components
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Overall Health</span>
                <span className="font-medium">{metrics.systemHealth.toFixed(0)}%</span>
              </div>
              <Progress value={metrics.systemHealth} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Risk Score</span>
                <span className="font-medium">{metrics.riskScore.toFixed(0)}/100</span>
              </div>
              <Progress value={metrics.riskScore} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>MEV Protection</span>
                <span className="font-medium">{metrics.mevProtection.toFixed(0)}%</span>
              </div>
              <Progress value={metrics.mevProtection} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cpu size={20} />
              Module Status
            </CardTitle>
            <CardDescription>
              Status of all advanced trading modules
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <ModuleStatus name="Arbitrage Engine" status="active" metric={`${metrics.arbitrageOpportunities} ops`} />
            <ModuleStatus name="Risk Management" status="active" metric={`${metrics.riskScore.toFixed(0)} score`} />
            <ModuleStatus name="MEV Protection" status="active" metric={`${metrics.mevProtection.toFixed(0)}% protected`} />
            <ModuleStatus name="Multi-Chain" status="warning" metric="2 chains" />
            <ModuleStatus name="AI Assistant" status="active" metric="GPT-4 ready" />
            <ModuleStatus name="Desktoping" status="active" metric="All systems" />
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            Common operations and shortcuts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-auto flex-col gap-2 p-4">
              <Robot size={24} />
              <span className="text-sm">Start Arbitrage</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 p-4">
              <Shield size={24} />
              <span className="text-sm">Risk Gear</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 p-4">
              <Globe size={24} />
              <span className="text-sm">Multi-Chain</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 p-4">
              <LineChart size={24} />
              <span className="text-sm">Analytics</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Last Update Timestamp */}
      <div className="text-center text-xs text-muted-foreground">
        Last updated: {lastUpdate.toLocaleTimeString()}
      </div>
    </div>
  )
}