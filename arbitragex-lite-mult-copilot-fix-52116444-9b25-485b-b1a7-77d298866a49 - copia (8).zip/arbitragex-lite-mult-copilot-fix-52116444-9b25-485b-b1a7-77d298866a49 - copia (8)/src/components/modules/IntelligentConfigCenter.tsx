import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Gear } from '@phosphor-icons/react'

interface IntelligentConfigCenterProps {
  environment: 'test' | 'prod'
}

export default function IntelligentConfigCenter({ environment }: IntelligentConfigCenterProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gear size={24} className="text-primary" />
            Intelligent Config Center
          </CardTitle>
          <CardDescription>
            Global parameters, feature flags, and security policies management
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-muted-foreground">
            <Gear size={64} className="mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">Configuration Management</h3>
            <p>Feature flags, dynamic parameters, and intelligent policy management</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}