/**
 * ArbitrageX Pro 2 - MOAD Strategy Testing
 * Componente para probar todas las estrategias de arbitraje
 */

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { Progress } from '../../ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../ui/tabs'
import { 
  Play, 
  Pause, 
  ArrowCounterClockwise, 
  CheckCircle, 
  XCircle, 
  Clock,
  TrendUp,
  WarningCircle,
  Lightning,
  Target,
  Activity
} from 'lucide-react'
import { ARBITRAGE_STRATEGIES } from './strategies'
import { useExecuteArbitrage } from './hooks'
import { toast } from 'sonner'
import { cn } from '../../../lib/utils'

interface StrategyTestResult {
  strategyId: string
  status: 'pending' | 'running' | 'success' | 'failed'
  profit?: number
  executionTime?: number
  gasUsed?: number
  error?: string
  timestamp?: Date
}

interface MOADStrategyTestingProps {
  environment: 'test' | 'prod'
}

export const MOADStrategyTesting: React.FC<MOADStrategyTestingProps> = ({
  environment
}) => {
  const [testResults, setTestResults] = useState<Record<string, StrategyTestResult>>({})
  const [isRunningAll, setIsRunningAll] = useState(false)
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null)
  
  const executeMutation = useExecuteArbitrage()

  // Inicializar resultados de prueba
  React.useEffect(() => {
    const initialResults: Record<string, StrategyTestResult> = {}
    ARBITRAGE_STRATEGIES.forEach(strategy => {
      initialResults[strategy.id] = {
        strategyId: strategy.id,
        status: 'pending'
      }
    })
    setTestResults(initialResults)
  }, [])

  const executeStrategyTest = async (strategyId: string) => {
    setTestResults(prev => ({
      ...prev,
      [strategyId]: { ...prev[strategyId], status: 'running' }
    }))

    try {
      // Simular test de estrategia
      await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 3000))
      
      // 85% de éxito en testing
      const success = Math.random() > 0.15
      
      if (success) {
        const result = {
          strategyId,
          status: 'success' as const,
          profit: Math.floor(Math.random() * 5000) + 500,
          executionTime: Math.floor(Math.random() * 30) + 5,
          gasUsed: Math.floor(Math.random() * 100000) + 50000,
          timestamp: new Date()
        }
        
        setTestResults(prev => ({ ...prev, [strategyId]: result }))
        toast.success(`${ARBITRAGE_STRATEGIES.find(s => s.id === strategyId)?.label} - Test exitoso`)
      } else {
        const result = {
          strategyId,
          status: 'failed' as const,
          error: 'Condiciones de mercado insuficientes para arbitraje',
          timestamp: new Date()
        }
        
        setTestResults(prev => ({ ...prev, [strategyId]: result }))
        toast.error(`${ARBITRAGE_STRATEGIES.find(s => s.id === strategyId)?.label} - Test fallido`)
      }
    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        [strategyId]: {
          ...prev[strategyId],
          status: 'failed',
          error: 'Error en simulación de test',
          timestamp: new Date()
        }
      }))
    }
  }

  const runAllTests = async () => {
    setIsRunningAll(true)
    
    // Resetear todos los resultados
    const resetResults: Record<string, StrategyTestResult> = {}
    ARBITRAGE_STRATEGIES.forEach(strategy => {
      resetResults[strategy.id] = {
        strategyId: strategy.id,
        status: 'pending'
      }
    })
    setTestResults(resetResults)

    // Ejecutar tests en lotes de 3 para no sobrecargar
    const strategies = [...ARBITRAGE_STRATEGIES]
    for (let i = 0; i < strategies.length; i += 3) {
      const batch = strategies.slice(i, i + 3)
      await Promise.all(
        batch.map(strategy => executeStrategyTest(strategy.id))
      )
      
      // Pausa entre lotes
      if (i + 3 < strategies.length) {
        await new Promise(resolve => setTimeout(resolve, 1000))
      }
    }
    
    setIsRunningAll(false)
    toast.success('Test completo de todas las estrategias finalizado')
  }

  const resetAllTests = () => {
    const resetResults: Record<string, StrategyTestResult> = {}
    ARBITRAGE_STRATEGIES.forEach(strategy => {
      resetResults[strategy.id] = {
        strategyId: strategy.id,
        status: 'pending'
      }
    })
    setTestResults(resetResults)
    toast.info('Resultados de test reiniciados')
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return <Clock className="w-4 h-4 text-yellow-500 animate-pulse" />
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />
      default:
        return <div className="w-4 h-4 rounded-full bg-gray-300" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'border-yellow-300 bg-yellow-50'
      case 'success': return 'border-green-300 bg-green-50'
      case 'failed': return 'border-red-300 bg-red-50'
      default: return 'border-gray-200 bg-gray-50'
    }
  }

  const getTestStats = () => {
    const results = Object.values(testResults)
    const total = results.length
    const completed = results.filter(r => r.status === 'success' || r.status === 'failed').length
    const successful = results.filter(r => r.status === 'success').length
    const failed = results.filter(r => r.status === 'failed').length
    const running = results.filter(r => r.status === 'running').length
    
    const totalProfit = results
      .filter(r => r.status === 'success' && r.profit)
      .reduce((sum, r) => sum + (r.profit || 0), 0)
    
    const avgExecutionTime = results
      .filter(r => r.status === 'success' && r.executionTime)
      .reduce((sum, r, _, arr) => sum + (r.executionTime || 0) / arr.length, 0)

    return {
      total,
      completed,
      successful,
      failed,
      running,
      totalProfit,
      avgExecutionTime,
      successRate: completed > 0 ? (successful / completed) * 100 : 0
    }
  }

  const stats = getTestStats()

  return (
    <div className="space-y-6">
      {/* Header de testing */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Target className="w-6 h-6 text-primary" />
            Testing de Estrategias MOAD
          </h2>
          <p className="text-muted-foreground">
            Validación completa de las 11 estrategias de arbitraje DeFi
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            onClick={resetAllTests}
            disabled={isRunningAll}
          >
            <ArrowCounterClockwise className="w-4 h-4 mr-2" />
            Reset
          </Button>
          
          <Button 
            onClick={runAllTests}
            disabled={isRunningAll}
            className="min-w-[120px]"
          >
            {isRunningAll ? (
              <>
                <Pause className="w-4 h-4 mr-2" />
                Ejecutando...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Test Completo
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Estadísticas de testing */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="text-sm text-muted-foreground">Total</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{stats.successful}</div>
            <div className="text-sm text-muted-foreground">Exitosos</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{stats.failed}</div>
            <div className="text-sm text-muted-foreground">Fallidos</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.running}</div>
            <div className="text-sm text-muted-foreground">Ejecutando</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-profit">${stats.totalProfit.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Profit Total</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold">{stats.successRate.toFixed(1)}%</div>
            <div className="text-sm text-muted-foreground">Tasa Éxito</div>
          </CardContent>
        </Card>
      </div>

      {/* Progress general */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between text-sm mb-2">
            <span>Progreso de Testing</span>
            <span>{stats.completed} / {stats.total} completados</span>
          </div>
          <Progress value={(stats.completed / stats.total) * 100} className="h-3" />
        </CardContent>
      </Card>

      <Tabs defaultValue="grid" className="w-full">
        <TabsList>
          <TabsTrigger value="grid">Vista GridFour</TabsTrigger>
          <TabsTrigger value="details">Vista Detallada</TabsTrigger>
          <TabsTrigger value="results">Resultados</TabsTrigger>
        </TabsList>

        <TabsContent value="grid" className="space-y-4">
          {/* GridFour de estrategias */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {ARBITRAGE_STRATEGIES.map((strategy) => {
              const result = testResults[strategy.id]
              return (
                <Card 
                  key={strategy.id} 
                  className={cn(
                    "cursor-pointer transition-all duration-200 hover-lift",
                    getStatusColor(result?.status || 'pending')
                  )}
                  onClick={() => setSelectedStrategy(strategy.id)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{strategy.icon}</span>
                        <Badge variant="outline">#{strategy.roi2025Score}</Badge>
                      </div>
                      {getStatusIcon(result?.status || 'pending')}
                    </div>
                    <CardTitle className="text-sm">{strategy.label}</CardTitle>
                  </CardHeader>
                  
                  <CardContent className="space-y-2">
                    <div className="text-xs text-muted-foreground">
                      ROI: {strategy.roiExpected} • {strategy.complexity}
                    </div>
                    
                    {result?.status === 'success' && result.profit && (
                      <div className="text-sm text-profit font-medium">
                        +${result.profit.toLocaleString()}
                      </div>
                    )}
                    
                    {result?.status === 'failed' && result.error && (
                      <div className="text-xs text-red-600">
                        {result.error}
                      </div>
                    )}
                    
                    {result?.status === 'running' && (
                      <div className="text-xs text-yellow-600">
                        Ejecutando test...
                      </div>
                    )}
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation()
                        executeStrategyTest(strategy.id)
                      }}
                      disabled={result?.status === 'running' || isRunningAll}
                      className="w-full"
                    >
                      {result?.status === 'running' ? 'Ejecutando...' : 'Test Individual'}
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="details" className="space-y-4">
          {/* Lista detallada */}
          <div className="space-y-2">
            {ARBITRAGE_STRATEGIES.map((strategy) => {
              const result = testResults[strategy.id]
              return (
                <Card key={strategy.id} className={getStatusColor(result?.status || 'pending')}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{strategy.icon}</span>
                          {getStatusIcon(result?.status || 'pending')}
                        </div>
                        
                        <div>
                          <h3 className="font-medium">{strategy.label}</h3>
                          <p className="text-sm text-muted-foreground">
                            {strategy.description}
                          </p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        {result?.status === 'success' && (
                          <div className="space-y-1">
                            <p className="text-sm font-medium text-profit">
                              +${result.profit?.toLocaleString()}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {result.executionTime}s • {result.gasUsed?.toLocaleString()} gas
                            </p>
                          </div>
                        )}
                        
                        {result?.status === 'failed' && (
                          <div className="text-sm text-red-600 max-w-[200px]">
                            {result.error}
                          </div>
                        )}
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => executeStrategyTest(strategy.id)}
                          disabled={result?.status === 'running' || isRunningAll}
                          className="mt-2"
                        >
                          {result?.status === 'running' ? 'Ejecutando...' : 'Test'}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          {/* Análisis de resultados */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Resumen de Performance</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Tasa de Éxito</span>
                    <span>{stats.successRate.toFixed(1)}%</span>
                  </div>
                  <Progress value={stats.successRate} className="h-2" />
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Profit Promedio:</span>
                    <p className="font-medium">
                      ${stats.successful > 0 ? (stats.totalProfit / stats.successful).toLocaleString() : 0}
                    </p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Tiempo Promedio:</span>
                    <p className="font-medium">{stats.avgExecutionTime.toFixed(1)}s</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Estrategias Top Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.values(testResults)
                    .filter(r => r.status === 'success' && r.profit)
                    .sort((a, b) => (b.profit || 0) - (a.profit || 0))
                    .slice(0, 5)
                    .map((result, index) => {
                      const strategy = ARBITRAGE_STRATEGIES.find(s => s.id === result.strategyId)
                      return (
                        <div key={result.strategyId} className="flex items-center justify-between p-2 bg-accent/5 rounded">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{strategy?.icon}</span>
                            <span className="text-sm">{strategy?.label}</span>
                          </div>
                          <span className="text-sm font-medium text-profit">
                            +${result.profit?.toLocaleString()}
                          </span>
                        </div>
                      )
                    })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Información de modo */}
      <div className="text-center text-sm text-muted-foreground">
        Modo {environment.toUpperCase()} • 
        Testing automatizado de las 11 estrategias MOAD • 
        {environment === 'test' ? 'Usando fondos de testnet' : 'CUIDADO: Usando fondos reales'}
      </div>
    </div>
  )
}