/**
 * ArbitrageX Pro 2 - HFT Engine Card
 * Tarjeta de control para el motor de trading de alta frecuencia
 */

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Switch } from '../../ui/switch'
import { Badge } from '../../ui/badge'
import { Progress } from '../../ui/progress'
import { 
  Lightning, 
  Activity, 
  Clock, 
  TrendUp,
  PlayCircle,
  PauseCircle,
  WarningCircle,
  Gauge,
  Network
} from 'lucide-react'
import type { HFTEngineStatus } from './types'
import { cn } from '../../../lib/utils'

interface HFTEngineCardProps {
  status?: HFTEngineStatus
  isLoading: boolean
  onRunNow: () => void
  autoRun: boolean
  onAutoRunChange: (enabled: boolean) => void
  environment: 'test' | 'prod'
  systemActive: boolean
}

export const HFTEngineCard: React.FC<HFTEngineCardProps> = ({
  status,
  isLoading,
  onRunNow,
  autoRun,
  onAutoRunChange,
  environment,
  systemActive
}) => {
  const getStatusLED = () => {
    if (!systemActive) return { color: 'bg-gray-400', label: 'Detenido' }
    if (isLoading) return { color: 'bg-yellow-400 animate-pulse', label: 'Ejecutando' }
    if (status?.isActive) return { color: 'bg-green-400 animate-pulse', label: 'Ultra-Rápido' }
    return { color: 'bg-red-400', label: 'Error' }
  }

  const getNetworkStatusColor = (networkStatus?: string) => {
    switch (networkStatus) {
      case 'optimal': return 'text-green-500'
      case 'normal': return 'text-blue-500'
      case 'degraded': return 'text-yellow-500'
      case 'critical': return 'text-red-500'
      default: return 'text-gray-500'
    }
  }

  const getLatencyColor = (latency: number) => {
    if (latency <= 30) return 'text-green-500'
    if (latency <= 50) return 'text-yellow-500'
    return 'text-red-500'
  }

  const led = getStatusLED()

  return (
    <Card className="hover-lift">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Lightning className="w-5 h-5 text-warning" />
            Motor HFT Ultra-Optimizado
          </CardTitle>
          
          <div className="flex items-center gap-2">
            <div className={cn("w-3 h-3 rounded-full", led.color)} />
            <span className="text-xs text-muted-foreground">{led.label}</span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Métricas de latencia */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Latencia Actual</p>
            <p className={cn("text-xl font-bold", getLatencyColor(status?.currentLatency || 0))}>
              {(status?.currentLatency || 0).toFixed(1)}μs
            </p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Latencia Promedio</p>
            <p className="text-xl font-bold">
              {(status?.avgLatency || 0).toFixed(1)}μs
            </p>
          </div>
        </div>

        {/* Métricas de throughput */}
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center p-2 bg-accent/10 rounded-lg">
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-1">
              <Activity className="w-3 h-3" />
              Ejec/Seg
            </div>
            <p className="font-semibold">{status?.executionsPerSecond || 0}</p>
          </div>
          
          <div className="text-center p-2 bg-accent/10 rounded-lg">
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-1">
              <TrendUp className="w-3 h-3" />
              Total Ejec
            </div>
            <p className="font-semibold">{(status?.totalExecutions || 0).toLocaleString()}</p>
          </div>
          
          <div className="text-center p-2 bg-accent/10 rounded-lg">
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-1">
              <Clock className="w-3 h-3" />
              Ganancia
            </div>
            <p className="font-semibold text-profit">${(status?.profitToday || 0).toLocaleString()}</p>
          </div>
        </div>

        {/* Tasa de éxito HFT */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Tasa de Éxito HFT</span>
            <span className="font-medium">{((status?.successRate || 0) * 100).toFixed(2)}%</span>
          </div>
          <Progress value={(status?.successRate || 0) * 100} className="h-2" />
        </div>

        {/* Estado de la red */}
        <div className="flex items-center gap-2 p-2 bg-warning/10 rounded-lg">
          <Network className="w-4 h-4 text-warning" />
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">Estado de Red</p>
            <p className={cn("text-sm font-medium", getNetworkStatusColor(status?.networkStatus))}>
              {status?.networkStatus?.toUpperCase() || 'DESCONOCIDO'}
            </p>
          </div>
          <Gauge className={cn("w-4 h-4", getNetworkStatusColor(status?.networkStatus))} />
        </div>

        {/* Advertencia de latencia */}
        {status?.currentLatency && status.currentLatency > 50 && (
          <div className="flex items-center gap-2 p-2 bg-destructive/10 rounded-lg text-destructive">
            <WarningCircle className="w-4 h-4" />
            <span className="text-sm">⚠️ Latencia alta detectada</span>
          </div>
        )}

        {/* Controles HFT */}
        <div className="space-y-3 pt-2 border-t border-border">
          {/* Botón Run HFT */}
          <Button
            onClick={onRunNow}
            disabled={!systemActive || isLoading}
            className="w-full"
            size="lg"
            variant="outline"
          >
            {isLoading ? (
              <>
                <PauseCircle className="w-4 h-4 mr-2 animate-spin" />
                Optimizando...
              </>
            ) : (
              <>
                <PlayCircle className="w-4 h-4 mr-2" />
                Boost HFT
              </>
            )}
          </Button>

          {/* Toggle Auto-HFT */}
          <div className="flex items-center justify-between p-3 bg-accent/5 rounded-lg">
            <div className="flex items-center gap-2">
              <Switch
                checked={autoRun}
                onCheckedChange={onAutoRunChange}
                disabled={!systemActive}
                id="auto-run-hft"
              />
              <label htmlFor="auto-run-hft" className="text-sm font-medium">
                HFT Automático
              </label>
            </div>
            
            <Badge variant={autoRun && systemActive ? "default" : "secondary"}>
              {autoRun && systemActive ? 'ULTRA-FAST' : 'MANUAL'}
            </Badge>
          </div>
        </div>

        {/* Información de configuración */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-1 text-muted-foreground">
            <WarningCircle className="w-3 h-3" />
            {environment === 'test' ? 'Simulación HFT' : 'HFT Real'}
          </div>
          
          <div className="flex items-center gap-1 text-muted-foreground">
            <Gauge className="w-3 h-3" />
            Objetivo: &lt;100μs
          </div>
        </div>

        {/* Última ejecución HFT */}
        {status?.lastExecution && (
          <div className="text-xs text-muted-foreground">
            Último boost: {status.lastExecution.toLocaleTimeString()}
          </div>
        )}

        {/* Indicador de performance */}
        <div className="flex items-center justify-between p-2 bg-gradient-to-r from-warning/10 to-profit/10 rounded-lg">
          <span className="text-xs font-medium">Performance Score</span>
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }, (_, i) => (
              <div
                key={i}
                className={cn(
                  "w-2 h-2 rounded-full",
                  i < Math.floor((status?.successRate || 0) * 5) 
                    ? "bg-profit" 
                    : "bg-muted"
                )}
              />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}