/**
 * ArbitrageX Pro 2 - MOAD Strategy Definitions
 * Módulo de Oportunidades de Arbitraje DeFi - Estrategias Implementadas
 * Ordenadas por ROI potencial 2025 (mayor a menor)
 */

export interface StrategyInfo {
  id: string
  label: string
  description: string
  roiExpected: string
  complexity: 'basic' | 'intermediate' | 'advanced' | 'expert'
  timeExecution: string
  minimumCapital: string
  blockchains: string[]
  dexs: string[]
  riskLevel: 'low' | 'medium' | 'high' | 'extreme'
  flashLoanRequired: boolean
  crossChain: boolean
  mevProtection: boolean
  roi2025Score: number
  category: 'flash-loan' | 'cross-dex' | 'intra-dex' | 'cross-chain' | 'multi-hop'
  icon: string
}

export const ARBITRAGE_STRATEGIES: StrategyInfo[] = [
  {
    id: 'cross-chain-multi-hop-flash-loan',
    label: 'Cross-Chain Multi-Hop Flash-Loan',
    description: 'Combina flash loans con arbitraje multi-salto cross-chain para máxima rentabilidad',
    roiExpected: '15-25%',
    complexity: 'expert',
    timeExecution: '45-90 segundos',
    minimumCapital: '$50,000 - $500,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC', 'Arbitrum'],
    dexs: ['Uniswap V3', 'SushiSwap', 'PancakeSwap', 'Balancer'],
    riskLevel: 'extreme',
    flashLoanRequired: true,
    crossChain: true,
    mevProtection: true,
    roi2025Score: 10,
    category: 'flash-loan',
    icon: '🚀'
  },
  {
    id: 'cross-chain-cross-dex',
    label: 'Cross-Chain Cross-DEX',
    description: 'Arbitraje directo entre DEXs de diferentes blockchains',
    roiExpected: '12-20%',
    complexity: 'advanced',
    timeExecution: '30-60 segundos',
    minimumCapital: '$25,000 - $200,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC', 'Avalanche'],
    dexs: ['Uniswap V3', 'QuickSwap', 'PancakeSwap', 'TraderJoe'],
    riskLevel: 'high',
    flashLoanRequired: false,
    crossChain: true,
    mevProtection: true,
    roi2025Score: 9,
    category: 'cross-dex',
    icon: '🔗'
  },
  {
    id: 'flash-loan-triangular-cross-dex',
    label: 'Flash-Loan Triangular Cross-DEX',
    description: 'Arbitraje triangular usando flash loans entre múltiples DEXs',
    roiExpected: '10-18%',
    complexity: 'advanced',
    timeExecution: '25-45 segundos',
    minimumCapital: '$20,000 - $300,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC'],
    dexs: ['Uniswap V3', 'SushiSwap', '1inch', 'Curve'],
    riskLevel: 'high',
    flashLoanRequired: true,
    crossChain: false,
    mevProtection: true,
    roi2025Score: 8,
    category: 'triangular',
    icon: '📐'
  },
  {
    id: 'multi-hop-cross-dex',
    label: 'Multi-Hop Cross-DEX',
    description: 'Optimización de rutas complejas entre múltiples DEXs',
    roiExpected: '8-15%',
    complexity: 'advanced',
    timeExecution: '20-40 segundos',
    minimumCapital: '$15,000 - $150,000',
    blockchains: ['Ethereum', 'Polygon', 'Arbitrum'],
    dexs: ['Uniswap V2/V3', 'SushiSwap', 'Curve', 'Balancer'],
    riskLevel: 'medium',
    flashLoanRequired: false,
    crossChain: false,
    mevProtection: true,
    roi2025Score: 7,
    category: 'multi-hop',
    icon: '🔀'
  },
  {
    id: 'flash-loan-cross-dex',
    label: 'Flash-Loan Cross-DEX',
    description: 'Arbitraje simple entre DEXs usando capital prestado',
    roiExpected: '7-14%',
    complexity: 'intermediate',
    timeExecution: '15-30 segundos',
    minimumCapital: '$10,000 - $250,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC', 'Optimism'],
    dexs: ['Uniswap', 'PancakeSwap', 'QuickSwap', 'Velodrome'],
    riskLevel: 'medium',
    flashLoanRequired: true,
    crossChain: false,
    mevProtection: true,
    roi2025Score: 6,
    category: 'flash-loan',
    icon: '⚡'
  },
  {
    id: 'triangular-inter-dex',
    label: 'Triangular Inter-DEX',
    description: 'Arbitraje triangular entre diferentes DEXs del mismo blockchain',
    roiExpected: '6-12%',
    complexity: 'intermediate',
    timeExecution: '10-25 segundos',
    minimumCapital: '$8,000 - $100,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC'],
    dexs: ['Uniswap V3', 'SushiSwap', 'Curve'],
    riskLevel: 'medium',
    flashLoanRequired: false,
    crossChain: false,
    mevProtection: false,
    roi2025Score: 5,
    category: 'triangular',
    icon: '🔺'
  },
  {
    id: 'triangular-intra-dex',
    label: 'Triangular Intra-DEX',
    description: 'Arbitraje triangular dentro del mismo DEX aprovechando pools desbalanceados',
    roiExpected: '5-10%',
    complexity: 'intermediate',
    timeExecution: '8-20 segundos',
    minimumCapital: '$5,000 - $75,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC', 'Arbitrum'],
    dexs: ['Uniswap V3', 'SushiSwap', 'PancakeSwap'],
    riskLevel: 'low',
    flashLoanRequired: false,
    crossChain: false,
    mevProtection: false,
    roi2025Score: 4,
    category: 'triangular',
    icon: '🔹'
  },
  {
    id: 'atomic-swap-cross-dex',
    label: 'Atomic Swap Cross-DEX',
    description: 'Swaps atómicos entre diferentes DEXs usando HTLC',
    roiExpected: '4-9%',
    complexity: 'advanced',
    timeExecution: '60-120 segundos',
    minimumCapital: '$12,000 - $120,000',
    blockchains: ['Ethereum', 'BSC', 'Polygon', 'Avalanche'],
    dexs: ['Cross-chain compatible DEXs'],
    riskLevel: 'medium',
    flashLoanRequired: false,
    crossChain: true,
    mevProtection: false,
    roi2025Score: 3,
    category: 'cross-dex',
    icon: '⚛️'
  },
  {
    id: 'atomic-swap-intra-dex',
    label: 'Atomic Swap Intra-DEX',
    description: 'Swaps atómicos optimizados dentro del mismo DEX',
    roiExpected: '3-7%',
    complexity: 'basic',
    timeExecution: '5-15 segundos',
    minimumCapital: '$3,000 - $50,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC'],
    dexs: ['Uniswap V3', 'SushiSwap con atomic features'],
    riskLevel: 'low',
    flashLoanRequired: false,
    crossChain: false,
    mevProtection: false,
    roi2025Score: 2,
    category: 'intra-dex',
    icon: '🔄'
  },
  {
    id: 'basic-cross-dex',
    label: 'Basic Cross-DEX',
    description: 'Arbitraje básico entre dos DEXs diferentes',
    roiExpected: '2-6%',
    complexity: 'basic',
    timeExecution: '3-12 segundos',
    minimumCapital: '$2,000 - $40,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC', 'Arbitrum'],
    dexs: ['Cualquier par de DEXs compatibles'],
    riskLevel: 'low',
    flashLoanRequired: false,
    crossChain: false,
    mevProtection: false,
    roi2025Score: 1,
    category: 'cross-dex',
    icon: '🔀'
  },
  {
    id: 'basic-flash-loan',
    label: 'Basic Flash-Loan',
    description: 'Flash loan básico para arbitraje simple',
    roiExpected: '1-5%',
    complexity: 'basic',
    timeExecution: '5-10 segundos',
    minimumCapital: '$1,000 - $30,000',
    blockchains: ['Ethereum', 'Polygon', 'BSC'],
    dexs: ['DEXs con suficiente liquidez'],
    riskLevel: 'low',
    flashLoanRequired: true,
    crossChain: false,
    mevProtection: false,
    roi2025Score: 0.5,
    category: 'flash-loan',
    icon: '💫'
  }
]

// Función para obtener estrategia por ID
export const getStrategyById = (id: string): StrategyInfo | undefined => {
  return ARBITRAGE_STRATEGIES.find(strategy => strategy.id === id)
}

// Función para filtrar estrategias por complejidad
export const getStrategiesByComplexity = (complexity: string): StrategyInfo[] => {
  return ARBITRAGE_STRATEGIES.filter(strategy => strategy.complexity === complexity)
}

// Función para filtrar estrategias por categoría
export const getStrategiesByCategory = (category: string): StrategyInfo[] => {
  return ARBITRAGE_STRATEGIES.filter(strategy => strategy.category === category)
}

// Función para obtener estrategias que requieren flash loan
export const getFlashLoanStrategies = (): StrategyInfo[] => {
  return ARBITRAGE_STRATEGIES.filter(strategy => strategy.flashLoanRequired)
}

// Función para obtener estrategias cross-chain
export const getCrossChainStrategies = (): StrategyInfo[] => {
  return ARBITRAGE_STRATEGIES.filter(strategy => strategy.crossChain)
}

// Función para obtener estadísticas de estrategias
export const getStrategyStats = () => {
  const total = ARBITRAGE_STRATEGIES.length
  const flashLoanCount = getFlashLoanStrategies().length
  const crossChainCount = getCrossChainStrategies().length
  const mevProtectedCount = ARBITRAGE_STRATEGIES.filter(s => s.mevProtection).length
  
  return {
    total,
    flashLoanCount,
    crossChainCount,
    mevProtectedCount,
    byComplexity: {
      basic: getStrategiesByComplexity('basic').length,
      intermediate: getStrategiesByComplexity('intermediate').length,
      advanced: getStrategiesByComplexity('advanced').length,
      expert: getStrategiesByComplexity('expert').length
    },
    byRisk: {
      low: ARBITRAGE_STRATEGIES.filter(s => s.riskLevel === 'low').length,
      medium: ARBITRAGE_STRATEGIES.filter(s => s.riskLevel === 'medium').length,
      high: ARBITRAGE_STRATEGIES.filter(s => s.riskLevel === 'high').length,
      extreme: ARBITRAGE_STRATEGIES.filter(s => s.riskLevel === 'extreme').length
    }
  }
}