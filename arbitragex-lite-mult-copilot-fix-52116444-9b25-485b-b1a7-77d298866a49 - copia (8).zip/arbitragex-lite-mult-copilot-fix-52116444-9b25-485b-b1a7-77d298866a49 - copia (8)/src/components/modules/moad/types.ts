/**
 * ArbitrageX Pro 2 - MOAD Opportunity Types
 * Tipos y interfaces para el sistema de detección de oportunidades
 */

export interface Opportunity {
  id: string
  strategyId: string
  strategyLabel: string
  icon: string
  tokens: {
    input: string
    output: string
    intermediate?: string[]
  }
  path: {
    dexs: string[]
    blockchains: string[]
    pools: string[]
  }
  profitEstimated: number
  profitUSD: number
  riskScore: number
  executionTime: number
  gasEstimated: number
  slippage: number
  liquidityRequired: number
  confidence: number
  lastUpdated: Date
  status: 'active' | 'executing' | 'expired' | 'completed' | 'failed'
  mevProtection: boolean
  flashLoanAmount?: number
  crossChain: boolean
  priority: 'low' | 'medium' | 'high' | 'critical'
}

export interface OpportunityFunnel {
  strategy?: string
  minProfit?: number
  maxRisk?: number
  blockchain?: string
  dex?: string
  token?: string
  flashLoanOnly?: boolean
  crossChainOnly?: boolean
  mevProtected?: boolean
  minConfidence?: number
}

export interface ArbitrageEngineStatus {
  isActive: boolean
  mode: 'manual' | 'semi-auto' | 'auto'
  opportunitiesDetected: number
  opportunitiesExecuted: number
  totalProfit: number
  dailyProfit: number
  successRate: number
  avgExecutionTime: number
  lastExecution?: Date
  currentStrategy?: string
  autoRunEnabled: boolean
}

export interface HFTEngineStatus {
  isActive: boolean
  currentLatency: number
  executionsPerSecond: number
  avgLatency: number
  totalExecutions: number
  successRate: number
  profitToday: number
  lastExecution?: Date
  networkStatus: 'optimal' | 'normal' | 'degraded' | 'critical'
}

export interface RiskAssessment {
  overall: number
  liquidity: number
  slippage: number
  gas: number
  market: number
  technical: number
  mev: number
  factors: {
    name: string
    score: number
    impact: 'low' | 'medium' | 'high'
    description: string
  }[]
}

export interface ExecutionResult {
  id: string
  opportunityId: string
  strategy: string
  success: boolean
  profitRealized: number
  gasUsed: number
  executionTime: number
  txHash?: string
  error?: string
  timestamp: Date
  slippageActual: number
  mevProtected: boolean
}