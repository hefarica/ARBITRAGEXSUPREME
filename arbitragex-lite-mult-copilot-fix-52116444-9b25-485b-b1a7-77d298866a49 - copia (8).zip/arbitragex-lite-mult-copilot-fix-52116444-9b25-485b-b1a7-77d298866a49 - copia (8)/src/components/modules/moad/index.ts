/**
 * ArbitrageX Pro 2 - MOAD Index
 * Barrel export para todos los componentes del módulo MOAD
 */

export { RevenueDashboard } from './RevenueDashboard'
export { ArbitrageEngineCard } from './ArbitrageEngineCard'
export { HFTEngineCard } from './HFTEngineCard'
export { OpportunitiesPanel } from './OpportunitiesPanel'
export { OpportunityRow } from './OpportunityRow'
export { StrategySelector } from './StrategySelector'
export { MOADExecutiveSummary } from './MOADExecutiveSummary'
export { MOADStrategyTesting } from './MOADStrategyTesting'
export { MOADCompleteSystem } from './MOADCompleteSystem'

export { ARBITRAGE_STRATEGIES, getStrategyById, getStrategiesByCategory, getStrategiesByComplexity, getFlashLoanStrategies, getCrossChainStrategies, getStrategyStats } from './strategies'

export {
  useArbitrageStatus,
  useHFTStatus,
  useOpportunities,
  useExecuteArbitrage,
  useExecuteHFT,
  useMOADStats,
  useNetworkDesktoping
} from './hooks'

export {
  MOAD_CONFIG,
  getMOADConfig,
  getStrategyConfig,
  getBlockchainConfig,
  getDEXConfig,
  isFeatureEnabled,
  getEnvironmentConfig
} from './config'

export { moadNotifier, useMOADNotifier } from './notifier'

export type { StrategyInfo } from './strategies'
export type { Opportunity, OpportunityFunnel, ArbitrageEngineStatus, HFTEngineStatus, RiskAssessment, ExecutionResult } from './types'

// Función de inicialización del sistema MOAD
export const initializeMOADSystem = (environment: 'test' | 'prod' = 'test') => {
  const config = getEnvironmentConfig(environment)
  
  console.log(`
🚀 SISTEMA MOAD INICIALIZADO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 INFORMACIÓN DEL SISTEMA:
• Versión: ${config.system.version}
• Nombre: ${config.system.name}
• Entorno: ${environment.toUpperCase()}
• Estrategias: ${ARBITRAGE_STRATEGIES.length} implementadas

🎯 OBJETIVOS FINANCIEROS:
• Ganancia Diaria: $${config.targets.dailyProfitUSD.toLocaleString()}+
• ROI Mensual: ${config.targets.monthlyROIPercent}%
• Tasa de Éxito: ${(config.targets.minSuccessRate * 100)}%+
• Latencia Máxima: ${config.targets.maxLatencyMicroseconds}μs

🔧 CARACTERÍSTICAS TÉCNICAS:
• Blockchains: ${Object.keys(config.blockchains).length} soportadas
• DEXs: ${Object.keys(config.dexs).length} integrados
• Protección MEV: ${config.mevProtection.flashbots.enabled ? 'Activa' : 'Inactiva'}
• IA/LLM: ${config.ai.llm.provider.toUpperCase()} ${config.ai.llm.model}

🌐 BLOCKCHAINS SOPORTADAS:
${Object.entries(config.blockchains).map(([key, blockchain]) => 
  `• ${blockchain.name} (Prioridad: ${blockchain.priorityScore})`
).join('\n')}

⚡ ESTRATEGIAS POR CATEGORÍA:
• Flash Loans: ${getStrategiesByCategory('flash-loan').length}
• Cross-DEX: ${getStrategiesByCategory('cross-dex').length}
• Triangular: ${getStrategiesByCategory('triangular').length}
• Cross-DEX: ${getStrategiesByCategory('cross-dex').length}
• Intra-DEX: ${getStrategiesByCategory('intra-dex').length}
• Multi-Hop: ${getStrategiesByCategory('multi-hop').length}

🔒 SEGURIDAD:
• Posición Máxima: ${(config.security.maxPositionSize * 100)}% del capital
• Operaciones Diarias Máx: ${config.security.maxDailyOperations}
• Stop-Loss Emergencia: ${(config.security.emergencyStopLoss * 100)}%
• MFA Requerido: ${config.security.requireMFAForProduction ? 'Sí' : 'No'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Sistema listo para operaciones de arbitraje DeFi
`)

  // Mostrar notificación de bienvenida
  moadNotifier.setEnvironment(environment)
  moadNotifier.showSystemStarted()

  return {
    config,
    strategies: ARBITRAGE_STRATEGIES,
    environment,
    isInitialized: true
  }
}

// Función para mostrar estadísticas rápidas
export const showMOADStats = () => {
  const stats = getStrategyStats()
  
  console.log(`
📊 ESTADÍSTICAS RÁPIDAS MOAD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📈 ESTRATEGIAS:
• Total: ${stats.total}
• Flash Loans: ${stats.flashLoanCount}
• Cross-Chain: ${stats.crossChainCount}
• MEV Protected: ${stats.mevProtectedCount}

🎯 POR COMPLEJIDAD:
• Básicas: ${stats.byComplexity.basic}
• Intermedias: ${stats.byComplexity.intermediate}
• Avanzadas: ${stats.byComplexity.advanced}
• Expertas: ${stats.byComplexity.expert}

⚖️ POR NIVEL DE RIESGO:
• Bajo: ${stats.byRisk.low}
• Medio: ${stats.byRisk.medium}
• Alto: ${stats.byRisk.high}
• Extremo: ${stats.byRisk.extreme}

💡 TOP 3 ESTRATEGIAS (ROI):
${ARBITRAGE_STRATEGIES.slice(0, 3).map((strategy, index) => 
  `${index + 1}. ${strategy.label} (${strategy.roiExpected})`
).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
}