/**
 * ArbitrageX Pro 2 - MOAD Executive Summary
 * Resumen ejecutivo del sistema de arbitraje para stakeholders
 */

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Badge } from '../../ui/badge'
import { Progress } from '../../ui/progress'
import { 
  TrendUp, 
  Target, 
  Activity, 
  Clock,
  CurrencyDollar,
  Lightning,
  Shield,
  WarningCircle,
  CheckCircle
} from 'lucide-react'
import { useMOADStats, useNetworkDesktoping } from './hooks'
import { getStrategyStats } from './strategies'
import { cn } from '../../../lib/utils'

interface MOADExecutiveSummaryProps {
  environment: 'test' | 'prod'
}

export const MOADExecutiveSummary: React.FC<MOADExecutiveSummaryProps> = ({
  environment
}) => {
  const { data: stats } = useMOADStats(environment)
  const { data: networkStatus } = useNetworkDesktoping()
  const strategyStats = getStrategyStats()

  const getPerformanceStatus = () => {
    if (!stats) return { label: 'Cargando...', color: 'bg-gray-400' }
    
    if (stats.successRate >= 98) return { label: 'Excelente', color: 'bg-green-500' }
    if (stats.successRate >= 95) return { label: 'Muy Bueno', color: 'bg-blue-500' }
    if (stats.successRate >= 90) return { label: 'Bueno', color: 'bg-yellow-500' }
    return { label: 'Necesita Atención', color: 'bg-red-500' }
  }

  const getNetworkHealthScore = () => {
    if (!networkStatus) return 0
    
    const networks = Object.values(networkStatus)
    const optimalCount = networks.filter(n => n.status === 'optimal').length
    const normalCount = networks.filter(n => n.status === 'normal').length
    
    return ((optimalCount * 100) + (normalCount * 75)) / networks.length
  }

  const performanceStatus = getPerformanceStatus()
  const networkHealth = getNetworkHealthScore()

  return (
    <div className="space-y-6">
      {/* Header ejecutivo */}
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2">MOAD - Resumen Ejecutivo</h2>
        <p className="text-muted-foreground">
          Sistema de Oportunidades de Arbitraje DeFi • Modo {environment.toUpperCase()}
        </p>
        <div className="flex items-center justify-center gap-2 mt-2">
          <div className={cn("w-3 h-3 rounded-full", performanceStatus.color)} />
          <span className="text-sm font-medium">{performanceStatus.label}</span>
        </div>
      </div>

      {/* KPIs principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <CurrencyDollar className="w-8 h-8 text-green-600" />
              <Badge className="bg-green-100 text-green-800">HOY</Badge>
            </div>
            <p className="text-sm text-green-600 mb-1">Ganancia Diaria</p>
            <p className="text-2xl font-bold text-green-700">
              ${(stats?.dailyProfit || 0).toLocaleString()}
            </p>
            <p className="text-xs text-green-600">
              Objetivo: $100,000+ USD
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-sky-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <TrendUp className="w-8 h-8 text-blue-600" />
              <Badge className="bg-blue-100 text-blue-800">MENSUAL</Badge>
            </div>
            <p className="text-sm text-blue-600 mb-1">ROI Mensual</p>
            <p className="text-2xl font-bold text-blue-700">
              {(stats?.monthlyROI || 0).toFixed(1)}%
            </p>
            <p className="text-xs text-blue-600">
              Objetivo: 50-75%
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-violet-50 border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Target className="w-8 h-8 text-purple-600" />
              <Badge className="bg-purple-100 text-purple-800">PRECISIÓN</Badge>
            </div>
            <p className="text-sm text-purple-600 mb-1">Tasa de Éxito</p>
            <p className="text-2xl font-bold text-purple-700">
              {(stats?.successRate || 0).toFixed(1)}%
            </p>
            <p className="text-xs text-purple-600">
              Objetivo: &gt;95%
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Lightning className="w-8 h-8 text-orange-600" />
              <Badge className="bg-orange-100 text-orange-800">VELOCIDAD</Badge>
            </div>
            <p className="text-sm text-orange-600 mb-1">Latencia Promedio</p>
            <p className="text-2xl font-bold text-orange-700">
              {(stats?.avgLatency || 0).toFixed(1)}μs
            </p>
            <p className="text-xs text-orange-600">
              Objetivo: &lt;100μs
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Métricas operacionales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Operaciones del Día
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Oportunidades Detectadas</p>
                <p className="text-xl font-bold">{stats?.opportunitiesDetected || 0}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Oportunidades Ejecutadas</p>
                <p className="text-xl font-bold text-profit">{stats?.opportunitiesExecuted || 0}</p>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Tasa de Ejecución</span>
                <span>{stats ? ((stats.opportunitiesExecuted / stats.opportunitiesDetected) * 100).toFixed(1) : 0}%</span>
              </div>
              <Progress 
                value={stats ? (stats.opportunitiesExecuted / stats.opportunitiesDetected) * 100 : 0} 
                className="h-2" 
              />
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-profit" />
                <span>Protección MEV: {(stats?.mevProtectionRate || 0).toFixed(1)}%</span>
              </div>
              <div className="flex items-center gap-2">
                <Lightning className="w-4 h-4 text-warning" />
                <span>Flash Loans: {stats?.flashLoanOperations || 0}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5" />
              Estado de Estrategias
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Estrategias Totales</p>
                <p className="text-xl font-bold">{strategyStats.total}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Estrategias Activas</p>
                <p className="text-xl font-bold text-profit">{stats?.activeStrategies || 0}</p>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Activación</span>
                <span>{stats ? ((stats.activeStrategies / strategyStats.total) * 100).toFixed(0) : 0}%</span>
              </div>
              <Progress 
                value={stats ? (stats.activeStrategies / strategyStats.total) * 100 : 0} 
                className="h-2" 
              />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>Flash Loans: {strategyStats.flashLoanCount}</div>
              <div>Cross-Chain: {strategyStats.crossChainCount}</div>
              <div>MEV Protected: {strategyStats.mevProtectedCount}</div>
              <div>Cross-Chain Ops: {stats?.crossChainOperations || 0}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Estado de la red */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Estado de Redes Blockchain
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {networkStatus && Object.entries(networkStatus).map(([network, status]) => (
              <div key={network} className="text-center p-3 bg-accent/5 rounded-lg">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <div className={cn(
                    "w-3 h-3 rounded-full",
                    status.status === 'optimal' ? 'bg-green-500' :
                    status.status === 'normal' ? 'bg-yellow-500' : 'bg-red-500'
                  )} />
                  <span className="text-sm font-medium capitalize">{network}</span>
                </div>
                <div className="space-y-1 text-xs">
                  <div>Gas: {status.gasPrice} gwei</div>
                  <div>Block: {status.blockTime.toFixed(1)}s</div>
                  <div>TPS: {status.tps}</div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Salud General de Red</span>
              <span>{networkHealth.toFixed(0)}%</span>
            </div>
            <Progress value={networkHealth} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Alertas y recomendaciones */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <WarningCircle className="w-5 h-5" />
            Alertas y Recomendaciones
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {stats && stats.successRate < 95 && (
              <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <WarningCircle className="w-4 h-4 text-yellow-600" />
                <span className="text-sm text-yellow-800">
                  Tasa de éxito por debajo del objetivo. Revisar configuración de riesgo.
                </span>
              </div>
            )}
            
            {stats && stats.avgLatency > 75 && (
              <div className="flex items-center gap-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                <Clock className="w-4 h-4 text-orange-600" />
                <span className="text-sm text-orange-800">
                  Latencia alta detectada. Considerar optimización de infraestructura.
                </span>
              </div>
            )}
            
            {networkHealth < 80 && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <Activity className="w-4 h-4 text-red-600" />
                <span className="text-sm text-red-800">
                  Problemas de conectividad en algunas redes. Verificar proveedores RPC.
                </span>
              </div>
            )}
            
            {(!stats || (stats.successRate >= 95 && stats.avgLatency <= 75 && networkHealth >= 80)) && (
              <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm text-green-800">
                  Todos los sistemas operando óptimamente. MOAD funcionando según especificaciones.
                </span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Footer con timestamp */}
      <div className="text-center text-xs text-muted-foreground">
        Última actualización: {new Date().toLocaleString()} • 
        Modo {environment === 'test' ? 'Testnet' : 'Producción'} • 
        Certificado para operaciones de alto volumen
      </div>
    </div>
  )
}