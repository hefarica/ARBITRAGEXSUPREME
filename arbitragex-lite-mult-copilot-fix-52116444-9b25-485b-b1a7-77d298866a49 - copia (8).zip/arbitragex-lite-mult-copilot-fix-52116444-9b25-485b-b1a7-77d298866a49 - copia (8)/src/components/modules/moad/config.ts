/**
 * ArbitrageX Pro 2 - MOAD Configuration
 * Configuración centralizada del sistema MOAD
 */

export const MOAD_CONFIG = {
  // Configuración general del sistema
  system: {
    version: '6.0.1',
    name: 'MOAD - Módulo de Oportunidades de Arbitraje DeFi',
    description: 'Sistema avanzado de arbitraje multi-blockchain con IA integrada',
    maxConcurrentOperations: 50,
    healthCheckInterval: 5000, // 5 segundos
    defaultEnvironment: 'test' as 'test' | 'prod'
  },

  // Objetivos financieros
  targets: {
    dailyProfitUSD: 100000,
    monthlyROIPercent: 62.5, // 50-75% range
    maxDailyLossUSD: 5000,
    minSuccessRate: 0.95, // 95%
    maxLatencyMicroseconds: 100
  },

  // Configuración de estrategias
  strategies: {
    // Límites de capital por estrategia
    capitalLimits: {
      'cross-chain-multi-hop-flash-loan': { min: 50000, max: 500000 },
      'cross-chain-cross-dex': { min: 25000, max: 200000 },
      'flash-loan-triangular-cross-dex': { min: 20000, max: 300000 },
      'multi-hop-cross-dex': { min: 15000, max: 150000 },
      'flash-loan-cross-dex': { min: 10000, max: 250000 },
      'triangular-inter-dex': { min: 8000, max: 100000 },
      'triangular-intra-dex': { min: 5000, max: 75000 },
      'atomic-swap-cross-dex': { min: 12000, max: 120000 },
      'atomic-swap-intra-dex': { min: 3000, max: 50000 }, // Mantener ID pero categoría cambiada a intra-dex
      'basic-cross-dex': { min: 2000, max: 40000 },
      'basic-flash-loan': { min: 1000, max: 30000 }
    },

    // Configuración de riesgo por estrategia
    riskConfig: {
      'cross-chain-multi-hop-flash-loan': { maxSlippage: 0.02, timeoutSeconds: 90 },
      'cross-chain-cross-dex': { maxSlippage: 0.015, timeoutSeconds: 60 },
      'flash-loan-triangular-cross-dex': { maxSlippage: 0.012, timeoutSeconds: 45 },
      'multi-hop-cross-dex': { maxSlippage: 0.01, timeoutSeconds: 40 },
      'flash-loan-cross-dex': { maxSlippage: 0.008, timeoutSeconds: 30 },
      'triangular-inter-dex': { maxSlippage: 0.006, timeoutSeconds: 25 },
      'triangular-intra-dex': { maxSlippage: 0.005, timeoutSeconds: 20 },
      'atomic-swap-cross-dex': { maxSlippage: 0.01, timeoutSeconds: 120 },
      'atomic-swap-intra-dex': { maxSlippage: 0.005, timeoutSeconds: 15 },
      'basic-cross-dex': { maxSlippage: 0.008, timeoutSeconds: 12 },
      'basic-flash-loan': { maxSlippage: 0.005, timeoutSeconds: 10 }
    }
  },

  // Configuración de blockchains
  blockchains: {
    ethereum: {
      name: 'Ethereum',
      chainId: { mainnet: 1, testnet: 11155111 }, // Sepolia
      gasLimits: { min: 21000, max: 500000 },
      maxGasPriceGwei: 100,
      priorityScore: 10
    },
    polygon: {
      name: 'Polygon',
      chainId: { mainnet: 137, testnet: 80001 }, // Mumbai
      gasLimits: { min: 21000, max: 500000 },
      maxGasPriceGwei: 200,
      priorityScore: 9
    },
    bsc: {
      name: 'BSC',
      chainId: { mainnet: 56, testnet: 97 },
      gasLimits: { min: 21000, max: 500000 },
      maxGasPriceGwei: 50,
      priorityScore: 8
    },
    arbitrum: {
      name: 'Arbitrum',
      chainId: { mainnet: 42161, testnet: 421613 },
      gasLimits: { min: 21000, max: 1000000 },
      maxGasPriceGwei: 10,
      priorityScore: 9
    },
    optimism: {
      name: 'Optimism',
      chainId: { mainnet: 10, testnet: 420 },
      gasLimits: { min: 21000, max: 1000000 },
      maxGasPriceGwei: 15,
      priorityScore: 8
    },
    avalanche: {
      name: 'Avalanche',
      chainId: { mainnet: 43114, testnet: 43113 },
      gasLimits: { min: 21000, max: 500000 },
      maxGasPriceGwei: 100,
      priorityScore: 7
    }
  },

  // Configuración de DEXs
  dexs: {
    uniswapV3: {
      name: 'Uniswap V3',
      blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism'],
      feeStructure: [0.01, 0.05, 0.3, 1.0], // %
      liquidityThreshold: 100000 // USD
    },
    sushiSwap: {
      name: 'SushiSwap',
      blockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum'],
      feeStructure: [0.25, 0.3], // %
      liquidityThreshold: 50000
    },
    pancakeSwap: {
      name: 'PancakeSwap',
      blockchains: ['bsc'],
      feeStructure: [0.25], // %
      liquidityThreshold: 30000
    },
    quickSwap: {
      name: 'QuickSwap',
      blockchains: ['polygon'],
      feeStructure: [0.3], // %
      liquidityThreshold: 25000
    },
    traderJoe: {
      name: 'Trader Joe',
      blockchains: ['avalanche'],
      feeStructure: [0.3], // %
      liquidityThreshold: 20000
    }
  },

  // Configuración de protección MEV
  mevProtection: {
    flashbots: {
      enabled: true,
      relayURL: 'https://relay.flashbots.net',
      bundleTimeout: 25, // segundos
      maxBlockNumber: 5 // bloques en el futuro
    },
    commitReveal: {
      enabled: true,
      commitPhaseDuration: 30, // segundos
      revealPhaseDuration: 60, // segundos
      penaltyAmount: 0.01 // ETH
    },
    orderSplitting: {
      enabled: true,
      maxSplits: 10,
      timeDelayMs: 100,
      randomization: true
    },
    temporalRandomization: {
      enabled: true,
      minDelayMs: 50,
      maxDelayMs: 2000
    }
  },

  // Configuración de IA/LLM
  ai: {
    llm: {
      provider: 'openai', // 'openai' | 'anthropic' | 'google'
      model: 'gpt-4-turbo',
      maxTokens: 4000,
      temperature: 0.7,
      updateInterval: 60000 // 1 minuto
    },
    decisionThresholds: {
      minConfidence: 0.8,
      maxRiskTolerance: 0.7,
      profitabilityThreshold: 0.02 // 2%
    },
    learningConfig: {
      enabled: true,
      batchSize: 100,
      retrainingInterval: 86400000, // 24 horas
      performanceWindow: 7 // días
    }
  },

  // Configuración de monitoreo
  monitoring: {
    metricsUpdateInterval: 1000, // 1 segundo
    alertThresholds: {
      latencyMs: 100,
      successRate: 0.95,
      dailyLoss: 5000,
      gasPrice: 150 // gwei
    },
    notifications: {
      telegram: {
        enabled: true,
        urgentOnly: false
      },
      discord: {
        enabled: true,
        urgentOnly: true
      },
      email: {
        enabled: true,
        urgentOnly: true
      }
    }
  },

  // Configuración de UI
  ui: {
    refreshIntervals: {
      dashboard: 5000, // 5 segundos
      opportunities: 3000, // 3 segundos
      metrics: 1000, // 1 segundo
      charts: 10000 // 10 segundos
    },
    defaultFunnels: {
      minProfitUSD: 500,
      maxRiskScore: 0.6,
      minConfidence: 0.7,
      showMEVProtectedOnly: false,
      showCrossChainOnly: false
    },
    chartGear: {
      maxDataPoints: 100,
      animationDuration: 300,
      showTooltips: true,
      autoScale: true
    }
  },

  // Configuración de testing
  testing: {
    simulationMode: {
      enabled: true,
      virtualBalance: 1000000, // USD
      slippageSimulation: true,
      gasSimulation: true
    },
    backtesting: {
      defaultPeriodDays: 30,
      maxPeriodDays: 365,
      sampleSize: 1000
    },
    performanceTesting: {
      concurrentOperations: 10,
      testDurationMinutes: 5,
      expectedThroughput: 1000 // operaciones/minuto
    }
  },

  // Límites de seguridad
  security: {
    maxPositionSize: 0.2, // 20% del capital total
    maxDailyOperations: 500,
    emergencyStopLoss: 0.05, // 5% pérdida diaria
    maxConcurrentTransactions: 10,
    requireMFAForProduction: true,
    sessionTimeoutMinutes: 30
  }
}

// Funciones de utilidad para la configuración
export const getMOADConfig = () => MOAD_CONFIG

export const getStrategyConfig = (strategyId: string) => ({
  capitalLimits: MOAD_CONFIG.strategies.capitalLimits[strategyId],
  riskConfig: MOAD_CONFIG.strategies.riskConfig[strategyId]
})

export const getBlockchainConfig = (blockchain: string) => 
  MOAD_CONFIG.blockchains[blockchain as keyof typeof MOAD_CONFIG.blockchains]

export const getDEXConfig = (dex: string) =>
  MOAD_CONFIG.dexs[dex as keyof typeof MOAD_CONFIG.dexs]

export const isFeatureEnabled = (feature: string): boolean => {
  const features = {
    'mev-protection': MOAD_CONFIG.mevProtection.flashbots.enabled,
    'ai-decisions': MOAD_CONFIG.ai.learningConfig.enabled,
    'cross-chain': true,
    'flash-loans': true,
    'testing-mode': MOAD_CONFIG.testing.simulationMode.enabled
  }
  
  return features[feature as keyof typeof features] ?? false
}

export const getEnvironmentConfig = (environment: 'test' | 'prod') => ({
  ...MOAD_CONFIG,
  isDevelopment: environment === 'test',
  isProduction: environment === 'prod',
  requiresConfirmation: environment === 'prod',
  allowedCapital: environment === 'test' ? 10000 : 1000000 // USD
})