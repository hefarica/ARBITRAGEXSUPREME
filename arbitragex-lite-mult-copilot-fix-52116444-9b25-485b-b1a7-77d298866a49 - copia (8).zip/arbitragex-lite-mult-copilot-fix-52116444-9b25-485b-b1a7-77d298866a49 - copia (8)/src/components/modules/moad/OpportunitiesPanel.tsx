/**
 * ArbitrageX Pro 2 - Opportunities Panel
 * Panel de oportunidades de arbitraje en tiempo real
 */

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { Input } from '../../ui/input'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../ui/select'
import { 
  Activity, 
  TrendUp, 
  Clock, 
  Shield, 
  Lightning,
  PlayCircle,
  Funnel,
  Repeat,
  WarningCircle,
  Target,
  CurrencyDollar
} from 'lucide-react'
import { OpportunityRow } from './OpportunityRow'
import { ARBITRAGE_STRATEGIES } from './strategies'
import type { Opportunity, OpportunityFunnel } from './types'
import { cn } from '../../../lib/utils'

interface OpportunitiesPanelProps {
  opportunities: Opportunity[]
  selectedStrategy: string
  onStrategyChange: (strategy: string) => void
  environment: 'test' | 'prod'
  systemActive: boolean
}

export const OpportunitiesPanel: React.FC<OpportunitiesPanelProps> = ({
  opportunities,
  selectedStrategy,
  onStrategyChange,
  environment,
  systemActive
}) => {
  const [filter, setFunnel] = useState<OpportunityFunnel>({})
  const [sortBy, setSortBy] = useState<'profit' | 'risk' | 'time' | 'confidence'>('profit')
  const [isArrowClockwiseing, setIsArrowClockwiseing] = useState(false)

  // Filtrar y ordenar oportunidades
  const filteredOpportunities = opportunities
    .filter(opp => {
      if (filter.strategy && opp.strategyId !== filter.strategy) return false
      if (filter.minProfit && opp.profitEstimated < filter.minProfit) return false
      if (filter.maxRisk && opp.riskScore > filter.maxRisk) return false
      if (filter.flashLoanOnly && !opp.flashLoanAmount) return false
      if (filter.crossChainOnly && !opp.crossChain) return false
      if (filter.mevProtected && !opp.mevProtection) return false
      if (filter.minConfidence && opp.confidence < filter.minConfidence) return false
      return true
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'profit':
          return b.profitUSD - a.profitUSD
        case 'risk':
          return a.riskScore - b.riskScore
        case 'time':
          return a.executionTime - b.executionTime
        case 'confidence':
          return b.confidence - a.confidence
        default:
          return 0
      }
    })

  const handleArrowClockwise = async () => {
    setIsArrowClockwiseing(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    setIsArrowClockwiseing(false)
  }

  const getOpportunityStats = () => {
    const totalValue = filteredOpportunities.reduce((sum, opp) => sum + opp.profitUSD, 0)
    const avgRisk = filteredOpportunities.reduce((sum, opp) => sum + opp.riskScore, 0) / filteredOpportunities.length || 0
    const flashLoanCount = filteredOpportunities.filter(opp => opp.flashLoanAmount).length
    const crossChainCount = filteredOpportunities.filter(opp => opp.crossChain).length
    
    return { totalValue, avgRisk, flashLoanCount, crossChainCount }
  }

  const stats = getOpportunityStats()

  return (
    <div className="space-y-6">
      {/* Header con estadísticas */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Activity className="w-6 h-6 text-primary" />
            Oportunidades en Tiempo Real
          </h2>
          <p className="text-muted-foreground">
            {filteredOpportunities.length} oportunidades activas • 
            Valor total: ${stats.totalValue.toLocaleString()}
          </p>
        </div>
        
        <Button 
          variant="outline" 
          onClick={handleArrowClockwise}
          disabled={isArrowClockwiseing}
          className="flex items-center gap-2"
        >
          <Repeat className={cn("w-4 h-4", isArrowClockwiseing && "animate-spin")} />
          Actualizar
        </Button>
      </div>

      {/* Estadísticas rápidas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Valor Total</p>
                <p className="text-lg font-bold text-profit">
                  ${stats.totalValue.toLocaleString()}
                </p>
              </div>
              <CurrencyDollar className="w-6 h-6 text-profit" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Riesgo Promedio</p>
                <p className="text-lg font-bold">
                  {(stats.avgRisk * 100).toFixed(1)}%
                </p>
              </div>
              <WarningCircle className="w-6 h-6 text-warning" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Flash Loans</p>
                <p className="text-lg font-bold">
                  {stats.flashLoanCount}
                </p>
              </div>
              <Lightning className="w-6 h-6 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Cross-Chain</p>
                <p className="text-lg font-bold">
                  {stats.crossChainCount}
                </p>
              </div>
              <Target className="w-6 h-6 text-secondary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Funnel className="w-5 h-5" />
            Filtros y Configuración
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {/* Estrategia */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Estrategia</label>
              <Select value={filter.strategy || ''} onValueChange={(value) => setFunnel({...filter, strategy: value || undefined})}>
                <SelectTrigger>
                  <SelectValue placeholder="Todas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todas las estrategias</SelectItem>
                  {ARBITRAGE_STRATEGIES.map(strategy => (
                    <SelectItem key={strategy.id} value={strategy.id}>
                      {strategy.icon} {strategy.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Ganancia mínima */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Ganancia Mín.</label>
              <Input
                type="number"
                placeholder="0.02"
                step="0.01"
                min="0"
                max="1"
                value={filter.minProfit || ''}
                onChange={(e) => setFunnel({...filter, minProfit: parseFloat(e.target.value) || undefined})}
              />
            </div>

            {/* Riesgo máximo */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Riesgo Máx.</label>
              <Input
                type="number"
                placeholder="0.5"
                step="0.01"
                min="0"
                max="1"
                value={filter.maxRisk || ''}
                onChange={(e) => setFunnel({...filter, maxRisk: parseFloat(e.target.value) || undefined})}
              />
            </div>

            {/* Confianza mínima */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Confianza Mín.</label>
              <Input
                type="number"
                placeholder="0.8"
                step="0.01"
                min="0"
                max="1"
                value={filter.minConfidence || ''}
                onChange={(e) => setFunnel({...filter, minConfidence: parseFloat(e.target.value) || undefined})}
              />
            </div>

            {/* Ordenar por */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Ordenar por</label>
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="profit">Ganancia</SelectItem>
                  <SelectItem value="risk">Riesgo</SelectItem>
                  <SelectItem value="time">Tiempo</SelectItem>
                  <SelectItem value="confidence">Confianza</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Filtros especiales */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Filtros Especiales</label>
              <div className="space-y-1">
                <label className="flex items-center gap-2 text-xs">
                  <input
                    type="checkbox"
                    checked={filter.flashLoanOnly || false}
                    onChange={(e) => setFunnel({...filter, flashLoanOnly: e.target.checked || undefined})}
                  />
                  Solo Flash Loans
                </label>
                <label className="flex items-center gap-2 text-xs">
                  <input
                    type="checkbox"
                    checked={filter.crossChainOnly || false}
                    onChange={(e) => setFunnel({...filter, crossChainOnly: e.target.checked || undefined})}
                  />
                  Solo Cross-Chain
                </label>
                <label className="flex items-center gap-2 text-xs">
                  <input
                    type="checkbox"
                    checked={filter.mevProtected || false}
                    onChange={(e) => setFunnel({...filter, mevProtected: e.target.checked || undefined})}
                  />
                  Con Protección MEV
                </label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de oportunidades */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <TrendUp className="w-5 h-5" />
              Oportunidades Detectadas ({filteredOpportunities.length})
            </CardTitle>
            
            {!systemActive && (
              <Badge variant="secondary">
                Sistema Pausado
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {filteredOpportunities.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No hay oportunidades que coincidan con los filtros actuales</p>
              <p className="text-sm">Ajusta los filtros o espera a que se detecten nuevas oportunidades</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredOpportunities.map((opportunity) => (
                <OpportunityRow
                  key={opportunity.id}
                  opportunity={opportunity}
                  environment={environment}
                  systemActive={systemActive}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}