/**
 * ArbitrageX Pro 2 - Revenue Dashboard
 * Panel principal para controlar los motores de arbitraje y HFT
 */

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Switch } from '../../ui/switch'
import { Badge } from '../../ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../ui/tabs'
import { ArbitrageEngineCard } from './ArbitrageEngineCard'
import { HFTEngineCard } from './HFTEngineCard'
import { OpportunitiesPanel } from './OpportunitiesPanel'
import { StrategySelector } from './StrategySelector'
import { useQuery, useMutation } from '@tanstack/react-query'
import { useKV } from '@/hooks/useKV'
import { ARBITRAGE_STRATEGIES, getStrategyStats } from './strategies'
import { Activity, TrendUp, Lightning, Target, WarningCircle } from 'lucide-react'
import type { ArbitrageEngineStatus, HFTEngineStatus, Opportunity } from './types'

interface RevenueDashboardProps {
  environment: 'test' | 'prod'
}

export const RevenueDashboard: React.FC<RevenueDashboardProps> = ({ environment }) => {
  const [selectedStrategy, setSelectedStrategy] = useKV<string>('moad-selected-strategy', 'cross-chain-multi-hop-flash-loan')
  const [autoRunArbitrage, setAutoRunArbitrage] = useKV<boolean>('moad-auto-run-arbitrage', false)
  const [autoRunHFT, setAutoRunHFT] = useKV<boolean>('moad-auto-run-hft', false)
  const [systemActive, setSystemActive] = useState(false)

  // Simulación de datos del motor de arbitraje
  const { data: arbStatus, refetch: refetchArbStatus } = useQuery<ArbitrageEngineStatus>({
    queryKey: ['arbitrage-status', environment],
    queryFn: async () => ({
      isActive: systemActive,
      mode: autoRunArbitrage ? 'auto' : 'manual',
      opportunitiesDetected: Math.floor(Math.random() * 50) + 20,
      opportunitiesExecuted: Math.floor(Math.random() * 15) + 5,
      totalProfit: 156750.25,
      dailyProfit: Math.floor(Math.random() * 50000) + 80000,
      successRate: 0.95,
      avgExecutionTime: 15.3,
      lastExecution: new Date(),
      currentStrategy: selectedStrategy,
      autoRunEnabled: autoRunArbitrage
    }),
    refetchInterval: 5000
  })

  // Simulación de datos del motor HFT
  const { data: hftStatus, refetch: refetchHFTStatus } = useQuery<HFTEngineStatus>({
    queryKey: ['hft-status', environment],
    queryFn: async () => ({
      isActive: systemActive,
      currentLatency: Math.random() * 50 + 25,
      executionsPerSecond: Math.floor(Math.random() * 100) + 200,
      avgLatency: 35.7,
      totalExecutions: 127834,
      successRate: 0.98,
      profitToday: Math.floor(Math.random() * 30000) + 45000,
      lastExecution: new Date(),
      networkStatus: 'optimal'
    }),
    refetchInterval: 1000
  })

  // Simulación de oportunidades en tiempo real
  const { data: opportunities, refetch: refetchOpportunities } = useQuery<Opportunity[]>({
    queryKey: ['opportunities', environment, selectedStrategy],
    queryFn: async () => {
      // Generar oportunidades simuladas basadas en la estrategia seleccionada
      const strategy = ARBITRAGE_STRATEGIES.find(s => s.id === selectedStrategy)
      if (!strategy) return []

      const numOpportunities = Math.floor(Math.random() * 8) + 3
      return Array.from({ length: numOpportunities }, (_, i) => ({
        id: `opp-${Date.now()}-${i}`,
        strategyId: strategy.id,
        strategyLabel: strategy.label,
        icon: strategy.icon,
        tokens: {
          input: ['WETH', 'USDC', 'USDT', 'WBTC'][Math.floor(Math.random() * 4)],
          output: ['USDC', 'USDT', 'DAI', 'WETH'][Math.floor(Math.random() * 4)],
          intermediate: strategy.id.includes('triangular') ? ['DAI'] : undefined
        },
        path: {
          dexs: strategy.dexs.slice(0, Math.floor(Math.random() * 3) + 1),
          blockchains: strategy.blockchains.slice(0, Math.floor(Math.random() * 2) + 1),
          pools: [`Pool-${i}-A`, `Pool-${i}-B`]
        },
        profitEstimated: Math.random() * 0.15 + 0.02, // 2-17%
        profitUSD: Math.floor(Math.random() * 5000) + 500,
        riskScore: Math.random() * 0.8 + 0.1, // 0.1-0.9
        executionTime: Math.floor(Math.random() * 60) + 10,
        gasEstimated: Math.floor(Math.random() * 100000) + 50000,
        slippage: Math.random() * 0.02 + 0.001, // 0.1-2.1%
        liquidityRequired: Math.floor(Math.random() * 500000) + 50000,
        confidence: Math.random() * 0.3 + 0.7, // 70-100%
        lastUpdated: new Date(),
        status: 'active' as const,
        mevProtection: strategy.mevProtection,
        flashLoanAmount: strategy.flashLoanRequired ? Math.floor(Math.random() * 100000) + 10000 : undefined,
        crossChain: strategy.crossChain,
        priority: ['low', 'medium', 'high', 'critical'][Math.floor(Math.random() * 4)] as any
      }))
    },
    refetchInterval: 3000
  })

  // Mutaciones para ejecutar motores
  const runArbitrageMutation = useMutation({
    mutationFn: async () => {
      await new Promise(resolve => setTimeout(resolve, 2000))
      return { success: true, profit: Math.floor(Math.random() * 5000) + 1000 }
    },
    onSuccess: () => {
      refetchArbStatus()
    }
  })

  const runHFTMutation = useMutation({
    mutationFn: async () => {
      await new Promise(resolve => setTimeout(resolve, 1000))
      return { success: true, executions: Math.floor(Math.random() * 50) + 20 }
    },
    onSuccess: () => {
      refetchHFTStatus()
    }
  })

  // Efecto para auto-run
  useEffect(() => {
    let intervalId: NodeJS.Timeout | null = null

    if (autoRunArbitrage && systemActive) {
      intervalId = setInterval(() => {
        if (Math.random() > 0.7) { // 30% de probabilidad de ejecutar
          runArbitrageMutation.mutate()
        }
      }, 10000) // Cada 10 segundos
    }

    return () => {
      if (intervalId) clearInterval(intervalId)
    }
  }, [autoRunArbitrage, systemActive])

  const strategyStats = getStrategyStats()

  return (
    <div className="space-y-6">
      {/* Header con controles principales */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Target className="w-8 h-8 text-primary" />
            MOAD - Sistema de Arbitraje DeFi
          </h1>
          <p className="text-muted-foreground">
            {environment === 'test' ? '🧪 Modo Testnet' : '🔴 Modo Producción'} • 
            {ARBITRAGE_STRATEGIES.length} estrategias disponibles
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Switch
              checked={systemActive}
              onCheckedChange={setSystemActive}
              id="system-active"
            />
            <label htmlFor="system-active" className="text-sm font-medium">
              Sistema Activo
            </label>
          </div>
          
          <Badge variant={systemActive ? "default" : "secondary"}>
            {systemActive ? (
              <>
                <Activity className="w-3 h-3 mr-1" />
                Operativo
              </>
            ) : (
              'Detenido'
            )}
          </Badge>
        </div>
      </div>

      {/* Estadísticas rápidas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Ganancia Diaria</p>
                <p className="text-2xl font-bold text-profit">
                  ${(arbStatus?.dailyProfit || 0).toLocaleString()}
                </p>
              </div>
              <TrendUp className="w-8 h-8 text-profit" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Oportunidades</p>
                <p className="text-2xl font-bold">
                  {arbStatus?.opportunitiesDetected || 0}
                </p>
              </div>
              <Target className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Latencia HFT</p>
                <p className="text-2xl font-bold">
                  {(hftStatus?.currentLatency || 0).toFixed(1)}μs
                </p>
              </div>
              <Lightning className="w-8 h-8 text-warning" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Éxito Rate</p>
                <p className="text-2xl font-bold">
                  {((arbStatus?.successRate || 0) * 100).toFixed(1)}%
                </p>
              </div>
              <WarningCircle className="w-8 h-8 text-profit" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contenido principal en tabs */}
      <Tabs defaultValue="engines" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="engines">Motores de Ejecución</TabsTrigger>
          <TabsTrigger value="opportunities">Oportunidades en Tiempo Real</TabsTrigger>
          <TabsTrigger value="strategies">Gestión de Estrategias</TabsTrigger>
        </TabsList>

        <TabsContent value="engines" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <ArbitrageEngineCard
              status={arbStatus}
              isLoading={runArbitrageMutation.isPending}
              onRunNow={() => runArbitrageMutation.mutate()}
              autoRun={autoRunArbitrage}
              onAutoRunChange={setAutoRunArbitrage}
              environment={environment}
              systemActive={systemActive}
            />

            <HFTEngineCard
              status={hftStatus}
              isLoading={runHFTMutation.isPending}
              onRunNow={() => runHFTMutation.mutate()}
              autoRun={autoRunHFT}
              onAutoRunChange={setAutoRunHFT}
              environment={environment}
              systemActive={systemActive}
            />
          </div>
        </TabsContent>

        <TabsContent value="opportunities" className="space-y-6">
          <OpportunitiesPanel
            opportunities={opportunities || []}
            selectedStrategy={selectedStrategy}
            onStrategyChange={setSelectedStrategy}
            environment={environment}
            systemActive={systemActive}
          />
        </TabsContent>

        <TabsContent value="strategies" className="space-y-6">
          <StrategySelector
            selectedStrategy={selectedStrategy}
            onStrategyChange={setSelectedStrategy}
            environment={environment}
            strategyStats={strategyStats}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}