/**
 * ArbitrageX Pro 2 - Arbitrage Engine Card
 * Tarjeta de control para el motor de arbitraje multi-estrategia
 */

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Switch } from '../../ui/switch'
import { Badge } from '../../ui/badge'
import { Progress } from '../../ui/progress'
import { 
  Activity, 
  TrendUp, 
  Clock, 
  Target, 
  Lightning,
  PlayCircle,
  PauseCircle,
  WarningCircle
} from 'lucide-react'
import type { ArbitrageEngineStatus } from './types'
import { cn } from '../../../lib/utils'

interface ArbitrageEngineCardProps {
  status?: ArbitrageEngineStatus
  isLoading: boolean
  onRunNow: () => void
  autoRun: boolean
  onAutoRunChange: (enabled: boolean) => void
  environment: 'test' | 'prod'
  systemActive: boolean
}

export const ArbitrageEngineCard: React.FC<ArbitrageEngineCardProps> = ({
  status,
  isLoading,
  onRunNow,
  autoRun,
  onAutoRunChange,
  environment,
  systemActive
}) => {
  const getStatusLED = () => {
    if (!systemActive) return { color: 'bg-gray-400', label: 'Detenido' }
    if (isLoading) return { color: 'bg-yellow-400 animate-pulse', label: 'Ejecutando' }
    if (status?.isActive) return { color: 'bg-green-400 animate-pulse', label: 'Activo' }
    return { color: 'bg-red-400', label: 'Error' }
  }

  const led = getStatusLED()

  return (
    <Card className="hover-lift">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Motor de Arbitraje Multi-Estrategia
          </CardTitle>
          
          <div className="flex items-center gap-2">
            <div className={cn("w-3 h-3 rounded-full", led.color)} />
            <span className="text-xs text-muted-foreground">{led.label}</span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Métricas principales */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Ganancia Diaria</p>
            <p className="text-xl font-bold text-profit">
              ${(status?.dailyProfit || 0).toLocaleString()}
            </p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Ganancia Total</p>
            <p className="text-xl font-bold">
              ${(status?.totalProfit || 0).toLocaleString()}
            </p>
          </div>
        </div>

        {/* Métricas de performance */}
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center p-2 bg-accent/10 rounded-lg">
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-1">
              <Activity className="w-3 h-3" />
              Oportunidades
            </div>
            <p className="font-semibold">{status?.opportunitiesDetected || 0}</p>
          </div>
          
          <div className="text-center p-2 bg-accent/10 rounded-lg">
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-1">
              <TrendUp className="w-3 h-3" />
              Ejecutadas
            </div>
            <p className="font-semibold">{status?.opportunitiesExecuted || 0}</p>
          </div>
          
          <div className="text-center p-2 bg-accent/10 rounded-lg">
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-1">
              <Clock className="w-3 h-3" />
              Tiempo Avg
            </div>
            <p className="font-semibold">{(status?.avgExecutionTime || 0).toFixed(1)}s</p>
          </div>
        </div>

        {/* Tasa de éxito */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Tasa de Éxito</span>
            <span className="font-medium">{((status?.successRate || 0) * 100).toFixed(1)}%</span>
          </div>
          <Progress value={(status?.successRate || 0) * 100} className="h-2" />
        </div>

        {/* Estrategia actual */}
        {status?.currentStrategy && (
          <div className="flex items-center gap-2 p-2 bg-primary/10 rounded-lg">
            <Lightning className="w-4 h-4 text-primary" />
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Estrategia Activa</p>
              <p className="text-sm font-medium truncate">
                {status.currentStrategy.replace(/-/g, ' ').toUpperCase()}
              </p>
            </div>
          </div>
        )}

        {/* Controles */}
        <div className="space-y-3 pt-2 border-t border-border">
          {/* Botón Run Now */}
          <Button
            onClick={onRunNow}
            disabled={!systemActive || isLoading}
            className="w-full"
            size="lg"
          >
            {isLoading ? (
              <>
                <PauseCircle className="w-4 h-4 mr-2 animate-spin" />
                Ejecutando...
              </>
            ) : (
              <>
                <PlayCircle className="w-4 h-4 mr-2" />
                Ejecutar Ahora
              </>
            )}
          </Button>

          {/* Toggle Auto-Run */}
          <div className="flex items-center justify-between p-3 bg-accent/5 rounded-lg">
            <div className="flex items-center gap-2">
              <Switch
                checked={autoRun}
                onCheckedChange={onAutoRunChange}
                disabled={!systemActive}
                id="auto-run-arbitrage"
              />
              <label htmlFor="auto-run-arbitrage" className="text-sm font-medium">
                Auto-Ejecución
              </label>
            </div>
            
            <Badge variant={autoRun && systemActive ? "default" : "secondary"}>
              {autoRun && systemActive ? 'ACTIVO' : 'MANUAL'}
            </Badge>
          </div>
        </div>

        {/* Información de modo */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {environment === 'test' ? (
            <>
              <WarningCircle className="w-3 h-3" />
              Operando en Testnet
            </>
          ) : (
            <>
              <WarningCircle className="w-3 h-3 text-red-500" />
              <span className="text-red-500">Operando en Mainnet</span>
            </>
          )}
        </div>

        {/* Última ejecución */}
        {status?.lastExecution && (
          <div className="text-xs text-muted-foreground">
            Última ejecución: {status.lastExecution.toLocaleTimeString()}
          </div>
        )}
      </CardContent>
    </Card>
  )
}