/**
 * ArbitrageX Pro 2 - MOAD Complete System
 * Sistema completo de arbitraje DeFi con todas las funcionalidades
 */

import React, { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../ui/tabs'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Badge } from '../../ui/badge'
import { Button } from '../../ui/button'
import { 
  Target, 
  Activity, 
  Gear, 
  TestTube,
  ChartBar3,
  Lightning,
  Shield,
  Brain,
  TrendUp
} from 'lucide-react'
import { RevenueDashboard } from './RevenueDashboard'
import { MOADExecutiveSummary } from './MOADExecutiveSummary'
import { MOADStrategyTesting } from './MOADStrategyTesting'
import { useMOADStats } from './hooks'
import { getStrategyStats } from './strategies'

interface MOADCompleteSystemProps {
  environment: 'test' | 'prod'
}

export const MOADCompleteSystem: React.FC<MOADCompleteSystemProps> = ({
  environment
}) => {
  const [activeTab, setActiveTab] = useState('dashboard')
  const { data: moadStats } = useMOADStats(environment)
  const strategyStats = getStrategyStats()

  const getEnvironmentBadge = () => {
    if (environment === 'test') {
      return (
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
          🧪 Modo Testnet
        </Badge>
      )
    }
    return (
      <Badge variant="destructive" className="bg-red-50 text-red-700 border-red-200">
        🔴 Modo Producción
      </Badge>
    )
  }

  const getSystemStatusIndicator = () => {
    const successRate = moadStats?.successRate || 0
    
    if (successRate >= 98) {
      return {
        color: 'bg-green-500',
        label: 'Óptimo',
        pulse: 'animate-pulse'
      }
    } else if (successRate >= 95) {
      return {
        color: 'bg-yellow-500',
        label: 'Normal',
        pulse: 'animate-pulse'
      }
    } else {
      return {
        color: 'bg-red-500',
        label: 'Requiere Atención',
        pulse: 'animate-pulse'
      }
    }
  }

  const systemStatus = getSystemStatusIndicator()

  return (
    <div className="min-h-screen bg-background">
      {/* Header principal del sistema MOAD */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Target className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">
                    MOAD - Sistema de Arbitraje DeFi
                  </h1>
                  <p className="text-sm text-muted-foreground">
                    Módulo de Oportunidades de Arbitraje DeFi • v6.0.1
                  </p>
                </div>
              </div>
              
              {getEnvironmentBadge()}
            </div>
            
            <div className="flex items-center gap-4">
              {/* Indicador de estado del sistema */}
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${systemStatus.color} ${systemStatus.pulse}`} />
                <span className="text-sm font-medium">{systemStatus.label}</span>
              </div>
              
              {/* Métricas rápidas */}
              <div className="hidden md:flex items-center gap-6 text-sm">
                <div className="text-center">
                  <div className="font-bold text-profit">
                    ${(moadStats?.dailyProfit || 0).toLocaleString()}
                  </div>
                  <div className="text-muted-foreground">Hoy</div>
                </div>
                
                <div className="text-center">
                  <div className="font-bold">
                    {(moadStats?.successRate || 0).toFixed(1)}%
                  </div>
                  <div className="text-muted-foreground">Éxito</div>
                </div>
                
                <div className="text-center">
                  <div className="font-bold">
                    {strategyStats.total}
                  </div>
                  <div className="text-muted-foreground">Estrategias</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="container mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-6">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Dashboard Principal
            </TabsTrigger>
            <TabsTrigger value="executive" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Resumen Ejecutivo
            </TabsTrigger>
            <TabsTrigger value="testing" className="flex items-center gap-2">
              <TestTube className="w-4 h-4" />
              Testing Estrategias
            </TabsTrigger>
            <TabsTrigger value="config" className="flex items-center gap-2">
              <Gear className="w-4 h-4" />
              Configuración
            </TabsTrigger>
            <TabsTrigger value="docs" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Documentación
            </TabsTrigger>
          </TabsList>

          {/* Tab: Dashboard Principal */}
          <TabsContent value="dashboard" className="space-y-6">
            <RevenueDashboard environment={environment} />
          </TabsContent>

          {/* Tab: Resumen Ejecutivo */}
          <TabsContent value="executive" className="space-y-6">
            <MOADExecutiveSummary environment={environment} />
          </TabsContent>

          {/* Tab: Testing de Estrategias */}
          <TabsContent value="testing" className="space-y-6">
            <MOADStrategyTesting environment={environment} />
          </TabsContent>

          {/* Tab: Configuración */}
          <TabsContent value="config" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gear className="w-5 h-5" />
                  Configuración del Sistema MOAD
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Lightning className="w-4 h-4" />
                        Motor de Arbitraje
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-sm text-muted-foreground">
                        Configuración del motor principal de detección y ejecución de arbitrajes.
                      </div>
                      <Button variant="outline" className="w-full">
                        Configurar Motor
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Shield className="w-4 h-4" />
                        Protección MEV
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-sm text-muted-foreground">
                        Configuración de protección contra ataques MEV y sandwiching.
                      </div>
                      <Button variant="outline" className="w-full">
                        Configurar MEV
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Brain className="w-4 h-4" />
                        IA y LLM
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-sm text-muted-foreground">
                        Configuración del asistente IA para toma de decisiones automatizada.
                      </div>
                      <Button variant="outline" className="w-full">
                        Configurar IA
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Documentación */}
          <TabsContent value="docs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  Documentación del Sistema MOAD
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Información del PRD */}
                <div>
                  <h3 className="text-lg font-semibold mb-3">
                    PRD - Módulo de Oportunidades de Arbitraje DeFi
                  </h3>
                  <div className="bg-accent/10 p-4 rounded-lg space-y-2">
                    <p className="text-sm">
                      <strong>Documento:</strong> PRD-MOAD-001
                    </p>
                    <p className="text-sm">
                      <strong>Versión:</strong> 1.0
                    </p>
                    <p className="text-sm">
                      <strong>Fecha:</strong> Enero 2025
                    </p>
                    <p className="text-sm">
                      <strong>Objetivo:</strong> Generar $100,000+ USD diarios con ROI 50-75% mensual
                    </p>
                  </div>
                </div>

                {/* Estrategias implementadas */}
                <div>
                  <h3 className="text-lg font-semibold mb-3">
                    Estrategias de Arbitraje Implementadas
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="font-medium">Estrategias Avanzadas (ROI Alto)</h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• Cross-Chain Multi-Hop Flash-Loan (15-25%)</li>
                        <li>• Cross-Chain Cross-DEX (12-20%)</li>
                        <li>• Flash-Loan Triangular Cross-DEX (10-18%)</li>
                        <li>• Multi-Hop Cross-DEX (8-15%)</li>
                        <li>• Flash-Loan Cross-DEX (7-14%)</li>
                      </ul>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="font-medium">Estrategias Básicas (ROI Medio)</h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• Triangular Inter-DEX (6-12%)</li>
                        <li>• Triangular Intra-DEX (5-10%)</li>
                        <li>• Atomic Swap Cross-DEX (4-9%)</li>
                        <li>• Atomic Swap Intra-DEX (3-7%)</li>
                        <li>• Basic Cross-DEX (2-6%)</li>
                        <li>• Basic Flash-Loan (1-5%)</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Características técnicas */}
                <div>
                  <h3 className="text-lg font-semibold mb-3">
                    Características Técnicas
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-2">Performance</h4>
                        <ul className="text-sm space-y-1 text-muted-foreground">
                          <li>• Latencia &lt;100μs</li>
                          <li>• Accuracy &gt;99.5%</li>
                          <li>• Uptime &gt;99.9%</li>
                          <li>• 1000+ oportunidades/min</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-2">Blockchains</h4>
                        <ul className="text-sm space-y-1 text-muted-foreground">
                          <li>• Ethereum</li>
                          <li>• Polygon</li>
                          <li>• BSC</li>
                          <li>• Arbitrum</li>
                          <li>• Optimism</li>
                          <li>• Avalanche</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-2">Seguridad</h4>
                        <ul className="text-sm space-y-1 text-muted-foreground">
                          <li>• Protección MEV</li>
                          <li>• Private mempool</li>
                          <li>• Commit-reveal</li>
                          <li>• Rate limiting</li>
                          <li>• Circuit breakers</li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Instrucciones de uso */}
                <div>
                  <h3 className="text-lg font-semibold mb-3">
                    Instrucciones de Uso
                  </h3>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <ol className="text-sm space-y-2">
                      <li><strong>1.</strong> Verificar que el sistema esté en modo {environment.toUpperCase()}</li>
                      <li><strong>2.</strong> Revisar el estado de las conexiones blockchain</li>
                      <li><strong>3.</strong> Seleccionar las estrategias a activar</li>
                      <li><strong>4.</strong> Configurar límites de riesgo y capital</li>
                      <li><strong>5.</strong> Elegir modo de operación (Manual/Semi/Auto)</li>
                      <li><strong>6.</strong> Desktopear performance en tiempo real</li>
                    </ol>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer del sistema */}
      <div className="border-t border-border bg-card/30 backdrop-blur-sm mt-12">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div>
              ArbitrageX Pro 2 MOAD v6.0.1 • 
              {strategyStats.total} estrategias implementadas • 
              Certificado para operaciones de alto volumen
            </div>
            <div>
              Última actualización: {new Date().toLocaleString()}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}