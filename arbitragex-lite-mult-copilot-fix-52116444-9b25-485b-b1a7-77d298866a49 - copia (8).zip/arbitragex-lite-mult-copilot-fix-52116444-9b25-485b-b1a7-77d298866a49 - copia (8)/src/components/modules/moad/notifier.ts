/**
 * ArbitrageX Pro 2 - MOAD System Notifier
 * Notificaciones y alertas del sistema MOAD
 */

import { toast } from 'sonner'
import { MOAD_CONFIG } from './config'
import { ARBITRAGE_STRATEGIES } from './strategies'

export class MOADNotifier {
  private static instance: MOADNotifier
  private environment: 'test' | 'prod' = 'test'

  private constructor() {}

  static getInstance(): MOADNotifier {
    if (!MOADNotifier.instance) {
      MOADNotifier.instance = new MOADNotifier()
    }
    return MOADNotifier.instance
  }

  setEnvironment(env: 'test' | 'prod') {
    this.environment = env
  }

  // Notificación de bienvenida al sistema
  showWelcomeMessage() {
    toast.success('🚀 Sistema MOAD Inicializado', {
      description: `${ARBITRAGE_STRATEGIES.length} estrategias de arbitraje activadas • Modo ${this.environment.toUpperCase()}`,
      duration: 5000,
      action: {
        label: 'Ver Estrategias',
        onClick: () => this.showStrategiesOverview()
      }
    })
  }

  // Notificación de cambio de entorno
  showEnvironmentChange(newEnv: 'test' | 'prod') {
    const isProduction = newEnv === 'prod'
    
    if (isProduction) {
      toast.warning('⚠️ Cambiando a Modo Producción', {
        description: 'Las operaciones usarán fondos reales. Proceder con precaución.',
        duration: 8000
      })
    } else {
      toast.info('🧪 Cambiando a Modo Testnet', {
        description: 'Las operaciones usarán fondos de prueba.',
        duration: 4000
      })
    }
    
    this.environment = newEnv
  }

  // Notificación de oportunidad detectada
  showOpportunityDetected(opportunity: {
    strategy: string
    profitUSD: number
    riskScore: number
    tokens: string
  }) {
    const riskLevel = opportunity.riskScore > 0.7 ? 'Alta' : 
                     opportunity.riskScore > 0.4 ? 'Media' : 'Baja'
    
    toast.info('🎯 Nueva Oportunidad Detectada', {
      description: `${opportunity.strategy} • +$${opportunity.profitUSD.toLocaleString()} • Riesgo: ${riskLevel}`,
      duration: 6000,
      action: {
        label: 'Ver Detalles',
        onClick: () => console.log('Ver oportunidad:', opportunity)
      }
    })
  }

  // Notificación de arbitraje ejecutado exitosamente
  showArbitrageSuccess(result: {
    strategy: string
    profitRealized: number
    executionTime: number
    txHash?: string
  }) {
    toast.success('✅ Arbitraje Ejecutado', {
      description: `${result.strategy} • +$${result.profitRealized.toLocaleString()} en ${result.executionTime}s`,
      duration: 7000,
      action: result.txHash ? {
        label: 'Ver TX',
        onClick: () => window.open(`https://etherscan.io/tx/${result.txHash}`, '_blank')
      } : undefined
    })
  }

  // Notificación de error en arbitraje
  showArbitrageError(error: {
    strategy: string
    message: string
    severity: 'low' | 'medium' | 'high'
  }) {
    const icon = error.severity === 'high' ? '🚨' : 
                 error.severity === 'medium' ? '⚠️' : '⚡'
    
    toast.error(`${icon} Error en Arbitraje`, {
      description: `${error.strategy}: ${error.message}`,
      duration: error.severity === 'high' ? 10000 : 5000
    })
  }

  // Notificación de métricas de performance
  showPerformanceUpdate(metrics: {
    dailyProfit: number
    successRate: number
    opportunitiesExecuted: number
    avgLatency: number
  }) {
    const isGoodPerformance = metrics.successRate > 0.95 && metrics.dailyProfit > 100000
    
    if (isGoodPerformance) {
      toast.success('📊 Performance Excelente', {
        description: `+$${metrics.dailyProfit.toLocaleString()} hoy • ${(metrics.successRate * 100).toFixed(1)}% éxito • ${metrics.avgLatency.toFixed(1)}μs latencia`,
        duration: 4000
      })
    }
  }

  // Notificación de alerta de riesgo
  showRiskAlert(alert: {
    type: 'daily_loss' | 'high_latency' | 'low_success_rate' | 'network_congestion'
    value: number
    threshold: number
    severity: 'warning' | 'critical'
  }) {
    const messages = {
      daily_loss: `Pérdida diaria: $${alert.value.toLocaleString()} (límite: $${alert.threshold.toLocaleString()})`,
      high_latency: `Latencia alta: ${alert.value.toFixed(1)}μs (límite: ${alert.threshold}μs)`,
      low_success_rate: `Tasa de éxito baja: ${(alert.value * 100).toFixed(1)}% (mínimo: ${(alert.threshold * 100).toFixed(1)}%)`,
      network_congestion: `Congestión de red detectada: ${alert.value.toFixed(0)} gwei`
    }

    const icon = alert.severity === 'critical' ? '🚨' : '⚠️'
    
    toast.error(`${icon} Alerta de Riesgo`, {
      description: messages[alert.type],
      duration: alert.severity === 'critical' ? 15000 : 8000,
      action: {
        label: 'Ajustar Config',
        onClick: () => console.log('Abrir configuración de riesgo')
      }
    })
  }

  // Notificación de estado de la red
  showNetworkStatus(status: {
    blockchain: string
    status: 'optimal' | 'normal' | 'degraded' | 'critical'
    gasPrice: number
    blockTime: number
  }) {
    if (status.status === 'degraded' || status.status === 'critical') {
      toast.warning(`🌐 Red ${status.blockchain}`, {
        description: `Estado: ${status.status.toUpperCase()} • Gas: ${status.gasPrice} gwei • Bloque: ${status.blockTime.toFixed(1)}s`,
        duration: 6000
      })
    }
  }

  // Notificación de actualización de estrategia
  showStrategyUpdate(update: {
    strategyId: string
    action: 'activated' | 'deactivated' | 'optimized'
    details?: string
  }) {
    const strategy = ARBITRAGE_STRATEGIES.find(s => s.id === update.strategyId)
    const actionText = {
      activated: 'Activada',
      deactivated: 'Desactivada', 
      optimized: 'Optimizada'
    }

    toast.info(`🎯 Estrategia ${actionText[update.action]}`, {
      description: `${strategy?.label}${update.details ? ` • ${update.details}` : ''}`,
      duration: 4000
    })
  }

  // Notificación de resumen diario
  showDailySummary(summary: {
    totalProfit: number
    operationsExecuted: number
    successRate: number
    topStrategy: string
  }) {
    toast.success('📊 Resumen del Día', {
      description: `+$${summary.totalProfit.toLocaleString()} • ${summary.operationsExecuted} ops • ${(summary.successRate * 100).toFixed(1)}% éxito`,
      duration: 10000,
      action: {
        label: 'Ver Reporte',
        onClick: () => console.log('Abrir reporte diario')
      }
    })
  }

  // Notificación de sistema iniciado
  showSystemStarted() {
    const targetProfit = MOAD_CONFIG.targets.dailyProfitUSD
    
    toast.success('🚀 Sistema MOAD Operativo', {
      description: `Objetivo: $${targetProfit.toLocaleString()}/día • ${ARBITRAGE_STRATEGIES.length} estrategias • Modo ${this.environment.toUpperCase()}`,
      duration: 6000,
      action: {
        label: 'Ver Dashboard',
        onClick: () => console.log('Navegar al dashboard')
      }
    })
  }

  // Resumen de estrategias disponibles
  private showStrategiesOverview() {
    const expertStrategies = ARBITRAGE_STRATEGIES.filter(s => s.complexity === 'expert').length
    const advancedStrategies = ARBITRAGE_STRATEGIES.filter(s => s.complexity === 'advanced').length
    const basicStrategies = ARBITRAGE_STRATEGIES.filter(s => s.complexity === 'basic' || s.complexity === 'intermediate').length
    
    toast.info('📋 Estrategias Disponibles', {
      description: `${expertStrategies} experto • ${advancedStrategies} avanzadas • ${basicStrategies} básicas/intermedias`,
      duration: 5000
    })
  }

  // Método para mostrar el estado completo del sistema
  showSystemStatus(status: {
    isActive: boolean
    environment: 'test' | 'prod'
    strategiesActive: number
    totalCapital: number
    dailyProfit: number
    systemHealth: 'excellent' | 'good' | 'warning' | 'critical'
  }) {
    const healthMessages = {
      excellent: '🟢 Excelente',
      good: '🟡 Bueno', 
      warning: '🟠 Advertencia',
      critical: '🔴 Crítico'
    }

    toast.info('📊 Estado del Sistema', {
      description: `${healthMessages[status.systemHealth]} • $${status.dailyProfit.toLocaleString()} hoy • ${status.strategiesActive} estrategias activas`,
      duration: 6000
    })
  }
}

// Instancia singleton para uso global
export const moadNotifier = MOADNotifier.getInstance()

// Hook personalizado para usar el notificador en React
export const useMOADNotifier = () => {
  return moadNotifier
}