/**
 * ArbitrageX Pro 2 - Strategy Selector
 * Selector y configurador de estrategias de arbitraje
 */

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { Input } from '../../ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../ui/tabs'
import { 
  Target, 
  TrendUp, 
  Clock, 
  CurrencyDollar,
  WarningCircle,
  Lightning,
  Link,
  Shield,
  Info,
  Gear,
  ChartBar3,
  Funnel
} from 'lucide-react'
import { ARBITRAGE_STRATEGIES, getStrategiesByCategory, getStrategyStats } from './strategies'
import type { StrategyInfo } from './strategies'
import { cn } from '../../../lib/utils'

interface StrategySelectorProps {
  selectedStrategy: string
  onStrategyChange: (strategy: string) => void
  environment: 'test' | 'prod'
  strategyStats: ReturnType<typeof getStrategyStats>
}

export const StrategySelector: React.FC<StrategySelectorProps> = ({
  selectedStrategy,
  onStrategyChange,
  environment,
  strategyStats
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [searchTerm, setMagnifyingGlassTerm] = useState('')
  const [complexityFunnel, setComplexityFunnel] = useState<string>('all')

  // Filtrar estrategias
  const filteredStrategies = ARBITRAGE_STRATEGIES.filter(strategy => {
    const matchesCategory = selectedCategory === 'all' || strategy.category === selectedCategory
    const matchesMagnifyingGlass = strategy.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         strategy.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesComplexity = complexityFunnel === 'all' || strategy.complexity === complexityFunnel
    
    return matchesCategory && matchesMagnifyingGlass && matchesComplexity
  })

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case 'basic': return 'bg-green-100 text-green-800'
      case 'intermediate': return 'bg-blue-100 text-blue-800'
      case 'advanced': return 'bg-orange-100 text-orange-800'
      case 'expert': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-500'
      case 'medium': return 'text-yellow-500'
      case 'high': return 'text-orange-500'
      case 'extreme': return 'text-red-500'
      default: return 'text-gray-500'
    }
  }

  const categories = [
    { id: 'all', label: 'Todas', count: ARBITRAGE_STRATEGIES.length },
    { id: 'flash-loan', label: 'Flash Loans', count: getStrategiesByCategory('flash-loan').length },
    { id: 'cross-dex', label: 'Cross-DEX', count: getStrategiesByCategory('cross-dex').length },
    { id: 'triangular', label: 'Triangular', count: getStrategiesByCategory('triangular').length },
    { id: 'intra-dex', label: 'Intra-DEX', count: getStrategiesByCategory('intra-dex').length },
    { id: 'multi-hop', label: 'Multi-Hop', count: getStrategiesByCategory('multi-hop').length },
  ]

  const selectedStrategyInfo = ARBITRAGE_STRATEGIES.find(s => s.id === selectedStrategy)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Target className="w-6 h-6 text-primary" />
            Gestión de Estrategias
          </h2>
          <p className="text-muted-foreground">
            Configuración y selección de las 11 estrategias de arbitraje DeFi
          </p>
        </div>
      </div>

      {/* Estadísticas generales */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Estrategias Totales</p>
                <p className="text-2xl font-bold">{strategyStats.total}</p>
              </div>
              <Target className="w-6 h-6 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Flash Loans</p>
                <p className="text-2xl font-bold">{strategyStats.flashLoanCount}</p>
              </div>
              <Lightning className="w-6 h-6 text-warning" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Cross-Chain</p>
                <p className="text-2xl font-bold">{strategyStats.crossChainCount}</p>
              </div>
              <Link className="w-6 h-6 text-secondary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Con Protección MEV</p>
                <p className="text-2xl font-bold">{strategyStats.mevProtectedCount}</p>
              </div>
              <Shield className="w-6 h-6 text-profit" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="selection" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="selection">Selección de Estrategia</TabsTrigger>
          <TabsTrigger value="details">Detalles y Configuración</TabsTrigger>
          <TabsTrigger value="analytics">Analytics y Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="selection" className="space-y-6">
          {/* Filtros */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Funnel className="w-5 h-5" />
                Filtros
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Búsqueda</label>
                  <Input
                    placeholder="Buscar estrategias..."
                    value={searchTerm}
                    onChange={(e) => setMagnifyingGlassTerm(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Complejidad</label>
                  <select
                    className="w-full p-2 border rounded-md"
                    value={complexityFunnel}
                    onChange={(e) => setComplexityFunnel(e.target.value)}
                  >
                    <option value="all">Todas</option>
                    <option value="basic">Básica</option>
                    <option value="intermediate">Intermedia</option>
                    <option value="advanced">Avanzada</option>
                    <option value="expert">Experto</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Categorías</label>
                  <div className="flex flex-wrap gap-2">
                    {categories.map(category => (
                      <button
                        key={category.id}
                        onClick={() => setSelectedCategory(category.id)}
                        className={cn(
                          "px-3 py-1 rounded-full text-xs font-medium transition-colors",
                          selectedCategory === category.id
                            ? "bg-primary text-primary-foreground"
                            : "bg-accent text-accent-foreground hover:bg-accent/80"
                        )}
                      >
                        {category.label} ({category.count})
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Lista de estrategias */}
          <div className="grid gap-4">
            {filteredStrategies.map((strategy) => (
              <Card
                key={strategy.id}
                className={cn(
                  "cursor-pointer transition-all duration-200 hover-lift",
                  selectedStrategy === strategy.id
                    ? "ring-2 ring-primary border-primary/50 bg-primary/5"
                    : "hover:border-primary/30"
                )}
                onClick={() => onStrategyChange(strategy.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    {/* Ícono y prioridad */}
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-3xl">{strategy.icon}</span>
                      <Badge className="text-xs">
                        #{strategy.roi2025Score}
                      </Badge>
                    </div>

                    {/* Información principal */}
                    <div className="flex-1 space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold text-lg">{strategy.label}</h3>
                          <p className="text-sm text-muted-foreground">{strategy.description}</p>
                        </div>
                        
                        <div className="text-right">
                          <p className="text-lg font-bold text-profit">{strategy.roiExpected}</p>
                          <p className="text-xs text-muted-foreground">ROI Esperado</p>
                        </div>
                      </div>

                      {/* Badges y características */}
                      <div className="flex flex-wrap gap-2">
                        <Badge className={getComplexityColor(strategy.complexity)}>
                          {strategy.complexity.charAt(0).toUpperCase() + strategy.complexity.slice(1)}
                        </Badge>
                        
                        <Badge variant="outline" className={getRiskColor(strategy.riskLevel)}>
                          Riesgo: {strategy.riskLevel.toUpperCase()}
                        </Badge>

                        {strategy.flashLoanRequired && (
                          <Badge variant="secondary">
                            <Lightning className="w-3 h-3 mr-1" />
                            Flash Loan
                          </Badge>
                        )}

                        {strategy.crossChain && (
                          <Badge variant="outline">
                            <Link className="w-3 h-3 mr-1" />
                            Cross-Chain
                          </Badge>
                        )}

                        {strategy.mevProtection && (
                          <Badge variant="default">
                            <Shield className="w-3 h-3 mr-1" />
                            MEV Protected
                          </Badge>
                        )}
                      </div>

                      {/* Métricas */}
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-muted-foreground" />
                          <span className="text-muted-foreground">Tiempo:</span>
                          <span>{strategy.timeExecution}</span>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <CurrencyDollar className="w-3 h-3 text-muted-foreground" />
                          <span className="text-muted-foreground">Capital:</span>
                          <span>{strategy.minimumCapital}</span>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <Target className="w-3 h-3 text-muted-foreground" />
                          <span className="text-muted-foreground">Blockchains:</span>
                          <span>{strategy.blockchains.length}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="details" className="space-y-6">
          {selectedStrategyInfo ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">{selectedStrategyInfo.icon}</span>
                  {selectedStrategyInfo.label}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Descripción detallada */}
                <div>
                  <h4 className="font-medium mb-2">Descripción</h4>
                  <p className="text-muted-foreground">{selectedStrategyInfo.description}</p>
                </div>

                {/* Especificaciones técnicas */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">Especificaciones</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ROI Esperado:</span>
                        <span className="font-medium text-profit">{selectedStrategyInfo.roiExpected}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Complejidad:</span>
                        <Badge className={getComplexityColor(selectedStrategyInfo.complexity)}>
                          {selectedStrategyInfo.complexity}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Nivel de Riesgo:</span>
                        <span className={getRiskColor(selectedStrategyInfo.riskLevel)}>
                          {selectedStrategyInfo.riskLevel.toUpperCase()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Tiempo de Ejecución:</span>
                        <span>{selectedStrategyInfo.timeExecution}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Capital Mínimo:</span>
                        <span>{selectedStrategyInfo.minimumCapital}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Infraestructura</h4>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Blockchains Soportadas:</p>
                        <div className="flex flex-wrap gap-1">
                          {selectedStrategyInfo.blockchains.map(blockchain => (
                            <Badge key={blockchain} variant="outline" className="text-xs">
                              {blockchain}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">DEXs Compatibles:</p>
                        <div className="flex flex-wrap gap-1">
                          {selectedStrategyInfo.dexs.slice(0, 3).map(dex => (
                            <Badge key={dex} variant="secondary" className="text-xs">
                              {dex}
                            </Badge>
                          ))}
                          {selectedStrategyInfo.dexs.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{selectedStrategyInfo.dexs.length - 3} más
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Características especiales */}
                <div>
                  <h4 className="font-medium mb-3">Características Especiales</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className={cn(
                      "p-3 rounded-lg border",
                      selectedStrategyInfo.flashLoanRequired 
                        ? "bg-warning/10 border-warning/30" 
                        : "bg-muted/10"
                    )}>
                      <div className="flex items-center gap-2 mb-1">
                        <Lightning className="w-4 h-4" />
                        <span className="text-sm font-medium">Flash Loans</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {selectedStrategyInfo.flashLoanRequired ? 'Requerido' : 'No requerido'}
                      </p>
                    </div>

                    <div className={cn(
                      "p-3 rounded-lg border",
                      selectedStrategyInfo.crossChain 
                        ? "bg-secondary/10 border-secondary/30" 
                        : "bg-muted/10"
                    )}>
                      <div className="flex items-center gap-2 mb-1">
                        <Link className="w-4 h-4" />
                        <span className="text-sm font-medium">Cross-Chain</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {selectedStrategyInfo.crossChain ? 'Habilitado' : 'Single chain'}
                      </p>
                    </div>

                    <div className={cn(
                      "p-3 rounded-lg border",
                      selectedStrategyInfo.mevProtection 
                        ? "bg-profit/10 border-profit/30" 
                        : "bg-muted/10"
                    )}>
                      <div className="flex items-center gap-2 mb-1">
                        <Shield className="w-4 h-4" />
                        <span className="text-sm font-medium">Protección MEV</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {selectedStrategyInfo.mevProtection ? 'Protegido' : 'No protegido'}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <Info className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Selecciona una estrategia para ver los detalles</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Analytics de Estrategias
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-accent/5 rounded-lg">
                  <p className="text-sm text-muted-foreground">Por Complejidad</p>
                  <div className="space-y-1 mt-2">
                    <div className="text-xs">Básica: {strategyStats.byComplexity.basic}</div>
                    <div className="text-xs">Intermedia: {strategyStats.byComplexity.intermediate}</div>
                    <div className="text-xs">Avanzada: {strategyStats.byComplexity.advanced}</div>
                    <div className="text-xs">Experto: {strategyStats.byComplexity.expert}</div>
                  </div>
                </div>

                <div className="text-center p-4 bg-accent/5 rounded-lg">
                  <p className="text-sm text-muted-foreground">Por Nivel de Riesgo</p>
                  <div className="space-y-1 mt-2">
                    <div className="text-xs text-green-600">Bajo: {strategyStats.byRisk.low}</div>
                    <div className="text-xs text-yellow-600">Medio: {strategyStats.byRisk.medium}</div>
                    <div className="text-xs text-orange-600">Alto: {strategyStats.byRisk.high}</div>
                    <div className="text-xs text-red-600">Extremo: {strategyStats.byRisk.extreme}</div>
                  </div>
                </div>

                <div className="text-center p-4 bg-accent/5 rounded-lg">
                  <p className="text-sm text-muted-foreground">Características</p>
                  <div className="space-y-1 mt-2">
                    <div className="text-xs">Flash Loans: {strategyStats.flashLoanCount}</div>
                    <div className="text-xs">Cross-Chain: {strategyStats.crossChainCount}</div>
                    <div className="text-xs">MEV Protected: {strategyStats.mevProtectedCount}</div>
                  </div>
                </div>

                <div className="text-center p-4 bg-accent/5 rounded-lg">
                  <p className="text-sm text-muted-foreground">Distribución ROI</p>
                  <div className="space-y-1 mt-2">
                    <div className="text-xs">Alta (&gt;10%): {ARBITRAGE_STRATEGIES.filter(s => parseFloat(s.roiExpected.split('-')[1]) > 10).length}</div>
                    <div className="text-xs">Media (5-10%): {ARBITRAGE_STRATEGIES.filter(s => {
                      const max = parseFloat(s.roiExpected.split('-')[1])
                      return max >= 5 && max <= 10
                    }).length}</div>
                    <div className="text-xs">Baja (&lt;5%): {ARBITRAGE_STRATEGIES.filter(s => parseFloat(s.roiExpected.split('-')[1]) < 5).length}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}