/**
 * ArbitrageX Pro 2 - Opportunity Row
 * Componente para mostrar una fila de oportunidad de arbitraje
 */

import React, { useState } from 'react'
import { Button } from '../../ui/button'
import { Badge } from '../../ui/badge'
import { Progress } from '../../ui/progress'
import { 
  PlayCircle, 
  Clock, 
  TrendUp, 
  WarningCircle, 
  Shield,
  Lightning,
  ArrowRight,
  Link,
  Target,
  CurrencyDollar
} from 'lucide-react'
import { useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'
import type { Opportunity } from './types'
import { cn } from '../../../lib/utils'

interface OpportunityRowProps {
  opportunity: Opportunity
  environment: 'test' | 'prod'
  systemActive: boolean
}

export const OpportunityRow: React.FC<OpportunityRowProps> = ({
  opportunity,
  environment,
  systemActive
}) => {
  const [isExpanded, setIsExpanded] = useState(false)

  // Mutación para ejecutar oportunidad
  const executeMutation = useMutation({
    mutationFn: async () => {
      // Simular ejecución de arbitraje
      await new Promise(resolve => setTimeout(resolve, opportunity.executionTime * 100))
      
      // Simular resultado (90% de éxito)
      const success = Math.random() > 0.1
      if (!success) {
        throw new Error('Ejecución fallida por condiciones de mercado')
      }
      
      return {
        success: true,
        profitRealized: opportunity.profitUSD * (0.8 + Math.random() * 0.4), // 80-120% del esperado
        txHash: `0x${Math.random().toString(16).substr(2, 40)}`,
        gasUsed: opportunity.gasEstimated * (0.9 + Math.random() * 0.2)
      }
    },
    onSuccess: (result) => {
      toast.success(
        `Arbitraje ejecutado exitosamente: +$${result.profitRealized.toFixed(2)}`,
        {
          description: `TX: ${result.txHash}`,
          duration: 5000
        }
      )
    },
    onError: (error) => {
      toast.error('Error en ejecución de arbitraje', {
        description: error.message,
        duration: 5000
      })
    }
  })

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500'
      case 'high': return 'bg-orange-500'
      case 'medium': return 'bg-yellow-500'
      case 'low': return 'bg-green-500'
      default: return 'bg-gray-500'
    }
  }

  const getRiskColor = (risk: number) => {
    if (risk <= 0.3) return 'text-green-500'
    if (risk <= 0.6) return 'text-yellow-500'
    return 'text-red-500'
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-500'
    if (confidence >= 0.7) return 'text-yellow-500'
    return 'text-red-500'
  }

  return (
    <div className={cn(
      "border rounded-lg p-4 transition-all duration-200",
      isExpanded ? "bg-accent/5 border-primary/30" : "hover:bg-accent/5",
      opportunity.priority === 'critical' && "border-l-4 border-l-red-500",
      opportunity.priority === 'high' && "border-l-4 border-l-orange-500"
    )}>
      {/* Fila principal */}
      <div className="flex items-center gap-4">
        {/* Indicador de prioridad */}
        <div className="flex flex-col items-center gap-1">
          <div className={cn("w-3 h-3 rounded-full", getPriorityColor(opportunity.priority))} />
          <span className="text-xs text-muted-foreground">{opportunity.priority.toUpperCase()}</span>
        </div>

        {/* Estrategia e ícono */}
        <div className="flex items-center gap-2 min-w-[200px]">
          <span className="text-2xl">{opportunity.icon}</span>
          <div>
            <p className="font-medium text-sm">{opportunity.strategyLabel}</p>
            <p className="text-xs text-muted-foreground">
              {opportunity.tokens.input} → {opportunity.tokens.output}
              {opportunity.tokens.intermediate && ` → ${opportunity.tokens.intermediate.join(' → ')}`}
            </p>
          </div>
        </div>

        {/* Profit */}
        <div className="text-center min-w-[100px]">
          <p className="text-lg font-bold text-profit">
            ${opportunity.profitUSD.toLocaleString()}
          </p>
          <p className="text-xs text-muted-foreground">
            {(opportunity.profitEstimated * 100).toFixed(2)}%
          </p>
        </div>

        {/* Risk Score */}
        <div className="text-center min-w-[80px]">
          <p className={cn("text-lg font-bold", getRiskColor(opportunity.riskScore))}>
            {(opportunity.riskScore * 100).toFixed(1)}%
          </p>
          <p className="text-xs text-muted-foreground">Risk</p>
        </div>

        {/* Tiempo de ejecución */}
        <div className="text-center min-w-[80px]">
          <p className="text-sm font-medium flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {opportunity.executionTime}s
          </p>
          <p className="text-xs text-muted-foreground">Tiempo</p>
        </div>

        {/* Confianza */}
        <div className="text-center min-w-[80px]">
          <p className={cn("text-sm font-medium", getConfidenceColor(opportunity.confidence))}>
            {(opportunity.confidence * 100).toFixed(1)}%
          </p>
          <p className="text-xs text-muted-foreground">Confianza</p>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-1 min-w-[120px]">
          {opportunity.flashLoanAmount && (
            <Badge variant="secondary" className="text-xs">
              <Lightning className="w-3 h-3 mr-1" />
              Flash
            </Badge>
          )}
          {opportunity.crossChain && (
            <Badge variant="outline" className="text-xs">
              <Link className="w-3 h-3 mr-1" />
              Cross
            </Badge>
          )}
          {opportunity.mevProtection && (
            <Badge variant="default" className="text-xs">
              <Shield className="w-3 h-3 mr-1" />
              MEV
            </Badge>
          )}
        </div>

        {/* Botones de acción */}
        <div className="flex items-center gap-2 ml-auto">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? 'Ocultar' : 'Detalles'}
          </Button>
          
          <Button
            onClick={() => executeMutation.mutate()}
            disabled={!systemActive || executeMutation.isPending || opportunity.status !== 'active'}
            className="min-w-[100px]"
          >
            {executeMutation.isPending ? (
              'Ejecutando...'
            ) : (
              <>
                <PlayCircle className="w-4 h-4 mr-1" />
                Ejecutar
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Detalles expandidos */}
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-border space-y-3">
          {/* Path de ejecución */}
          <div>
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
              <Target className="w-4 h-4" />
              Ruta de Ejecución
            </h4>
            <div className="flex items-center gap-2 text-sm">
              {opportunity.path.dexs.map((dex, index) => (
                <React.Fragment key={dex}>
                  <Badge variant="outline">{dex}</Badge>
                  {index < opportunity.path.dexs.length - 1 && (
                    <ArrowRight className="w-3 h-3 text-muted-foreground" />
                  )}
                </React.Fragment>
              ))}
            </div>
            <div className="flex items-center gap-2 text-sm mt-1">
              <span className="text-muted-foreground">Blockchains:</span>
              {opportunity.path.blockchains.map((blockchain, index) => (
                <React.Fragment key={blockchain}>
                  <Badge variant="secondary" className="text-xs">{blockchain}</Badge>
                  {index < opportunity.path.blockchains.length - 1 && (
                    <ArrowRight className="w-3 h-3 text-muted-foreground" />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Métricas detalladas */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-xs text-muted-foreground">Gas Estimado</p>
              <p className="text-sm font-medium">{opportunity.gasEstimated.toLocaleString()}</p>
            </div>
            
            <div>
              <p className="text-xs text-muted-foreground">Slippage</p>
              <p className="text-sm font-medium">{(opportunity.slippage * 100).toFixed(3)}%</p>
            </div>
            
            <div>
              <p className="text-xs text-muted-foreground">Liquidez Requerida</p>
              <p className="text-sm font-medium">${opportunity.liquidityRequired.toLocaleString()}</p>
            </div>
            
            {opportunity.flashLoanAmount && (
              <div>
                <p className="text-xs text-muted-foreground">Flash Loan</p>
                <p className="text-sm font-medium">${opportunity.flashLoanAmount.toLocaleString()}</p>
              </div>
            )}
          </div>

          {/* Progress bars */}
          <div className="space-y-2">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>Confianza</span>
                <span>{(opportunity.confidence * 100).toFixed(1)}%</span>
              </div>
              <Progress value={opportunity.confidence * 100} className="h-2" />
            </div>
            
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>Riesgo</span>
                <span>{(opportunity.riskScore * 100).toFixed(1)}%</span>
              </div>
              <Progress value={opportunity.riskScore * 100} className="h-2" />
            </div>
          </div>

          {/* Advertencias */}
          {opportunity.riskScore > 0.7 && (
            <div className="flex items-center gap-2 p-2 bg-destructive/10 rounded text-destructive text-sm">
              <WarningCircle className="w-4 h-4" />
              Alto riesgo detectado. Revisar condiciones de mercado antes de ejecutar.
            </div>
          )}

          {environment === 'prod' && opportunity.profitUSD > 10000 && (
            <div className="flex items-center gap-2 p-2 bg-warning/10 rounded text-warning text-sm">
              <WarningCircle className="w-4 h-4" />
              Oportunidad de alto valor en producción. Verificar configuración de límites.
            </div>
          )}

          {/* Información de última actualización */}
          <div className="text-xs text-muted-foreground">
            Última actualización: {opportunity.lastUpdated.toLocaleTimeString()}
          </div>
        </div>
      )}
    </div>
  )
}