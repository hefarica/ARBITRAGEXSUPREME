import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ShieldCheck } from '@phosphor-icons/react'

interface AdvancedSecurityCenterProps {
  environment: 'test' | 'prod'
}

export default function AdvancedSecurityCenter({ environment }: AdvancedSecurityCenterProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck size={24} className="text-primary" />
            Advanced Security Center
          </CardTitle>
          <CardDescription>
            Authentication, sessions, RBAC, and quantum security protocols
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-muted-foreground">
            <ShieldCheck size={64} className="mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">Quantum Security Hub</h3>
            <p>ZK-proofs, WebAuthn, biometric authentication, and security events</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}