import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Robot, Lightning, Target, TrendUp, Play, Pause, Eye, Brain, CheckCircle } from '@phosphor-icons/react'
import { useKV } from '@/hooks/useKV'

interface SmartArbitrageEngineProps {
  environment: 'test' | 'prod'
}

interface ArbitrageOpportunity {
  id: string
  pair: string
  exchange1: string
  exchange2: string
  priceDiff: number
  profit: number
  confidence: number
  timestamp: Date
  status: 'detected' | 'executing' | 'completed' | 'failed'
}

interface Strategy {
  id: string
  name: string
  type: 'triangular' | 'cross-exchange' | 'statistical' | 'mev-sandwich'
  enabled: boolean
  roi: number
  successRate: number
  risk: 'low' | 'medium' | 'high'
}

const generateOpportunity = (): ArbitrageOpportunity => ({
  id: Math.random().toString(36).substr(2, 9),
  pair: ['ETH/USDT', 'BTC/USDT', 'SOL/USDT', 'MATIC/USDT'][Math.floor(Math.random() * 4)],
  exchange1: ['Binance', 'Coinbase', 'Kraken', 'Uniswap'][Math.floor(Math.random() * 4)],
  exchange2: ['Binance', 'Coinbase', 'Kraken', 'Uniswap'][Math.floor(Math.random() * 4)],
  priceDiff: Math.random() * 5 + 0.1,
  profit: Math.random() * 1000 + 50,
  confidence: Math.random() * 30 + 70,
  timestamp: new Date(),
  status: ['detected', 'executing', 'completed'][Math.floor(Math.random() * 3)] as any
})

const defaultStrategies: Strategy[] = [
  {
    id: '1',
    name: 'Cross-Exchange Arbitrage',
    type: 'cross-exchange',
    enabled: true,
    roi: 12.5,
    successRate: 87.3,
    risk: 'low'
  },
  {
    id: '2', 
    name: 'Triangular Arbitrage',
    type: 'triangular',
    enabled: true,
    roi: 8.2,
    successRate: 92.1,
    risk: 'low'
  },
  {
    id: '3',
    name: 'Statistical Arbitrage',
    type: 'statistical',
    enabled: false,
    roi: 15.7,
    successRate: 73.4,
    risk: 'medium'
  },
  {
    id: '4',
    name: 'MEV Sandwich Detection',
    type: 'mev-sandwich',
    enabled: true,
    roi: 22.1,
    successRate: 68.9,
    risk: 'high'
  }
]

export default function SmartArbitrageEngine({ environment }: SmartArbitrageEngineProps) {
  const [isEngineRunning, setIsEngineRunning] = useKV('arbitrage-engine-running', false)
  const [strategies, setStrategies] = useKV('arbitrage-strategies', defaultStrategies)
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([])
  const [detectionMode, setDetectionMode] = useKV('detection-mode', 'automatic')
  
  // Simulate real-time opportunity detection
  useEffect(() => {
    if (!isEngineRunning) return

    const interval = setInterval(() => {
      // Add new opportunity occasionally
      if (Math.random() < 0.3) {
        setOpportunities(prev => [generateOpportunity(), ...prev.slice(0, 9)])
      }
      
      // Update existing opportunities
      setOpportunities(prev => prev.map(opp => {
        if (opp.status === 'executing' && Math.random() < 0.4) {
          return { ...opp, status: Math.random() < 0.9 ? 'completed' : 'failed' }
        }
        return opp
      }))
    }, 2000)

    return () => clearInterval(interval)
  }, [isEngineRunning])

  const handleStrategyToggle = (strategyId: string) => {
    setStrategies(strategies.map(s => 
      s.id === strategyId ? { ...s, enabled: !s.enabled } : s
    ))
  }

  const handleExecuteOpportunity = (oppId: string) => {
    setOpportunities(opportunities.map(opp =>
      opp.id === oppId ? { ...opp, status: 'executing' } : opp
    ))
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'detected': return <Eye size={16} className="text-blue-500" />
      case 'executing': return <Lightning size={16} className="text-yellow-500 animate-pulse" />
      case 'completed': return <CheckCircle size={16} className="text-profit" />
      case 'failed': return <Target size={16} className="text-destructive" />
      default: return null
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-profit'
      case 'medium': return 'text-warning'
      case 'high': return 'text-destructive'
      default: return 'text-muted-foreground'
    }
  }

  const totalProfit = opportunities
    .filter(opp => opp.status === 'completed')
    .reduce((sum, opp) => sum + opp.profit, 0)

  const successRate = opportunities.length > 0 
    ? (opportunities.filter(opp => opp.status === 'completed').length / opportunities.length) * 100
    : 0

  return (
    <div className="space-y-6">
      {/* Engine Control */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Robot size={24} className="text-primary" />
                AI-Enhanced Arbitrage Engine
              </CardTitle>
              <CardDescription>
                Intelligent opportunity detection with machine learning optimization
              </CardDescription>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Status</div>
                <Badge variant={isEngineRunning ? 'default' : 'secondary'}>
                  {isEngineRunning ? 'Active' : 'Stopped'}
                </Badge>
              </div>
              <Button
                onClick={() => setIsEngineRunning(!isEngineRunning)}
                variant={isEngineRunning ? 'destructive' : 'default'}
                className="gap-2"
              >
                {isEngineRunning ? <Pause size={16} /> : <Play size={16} />}
                {isEngineRunning ? 'Stop Engine' : 'Start Engine'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Total Profit</span>
                <span className="font-semibold profit">${totalProfit.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Success Rate</span>
                <span className="font-semibold">{successRate.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Opportunities Detected</span>
                <span className="font-semibold">{opportunities.length}</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Detection Mode</span>
                <Badge variant="outline">{detectionMode}</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Active Strategies</span>
                <span className="font-semibold">{strategies.filter(s => s.enabled).length}/{strategies.length}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Environment</span>
                <Badge variant={environment === 'prod' ? 'destructive' : 'secondary'}>
                  {environment}
                </Badge>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>AI Confidence</span>
                <span className="font-semibold">87.3%</span>
              </div>
              <Progress value={87.3} className="h-2" />
              <div className="text-xs text-muted-foreground">
                ML model accuracy improving
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Strategy Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain size={20} />
            Active Strategies
          </CardTitle>
          <CardDescription>
            Configure and monitor AI-powered arbitrage strategies
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {strategies.map((strategy) => (
              <div key={strategy.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <Switch
                    checked={strategy.enabled}
                    onCheckedChange={() => handleStrategyToggle(strategy.id)}
                  />
                  <div>
                    <div className="font-medium">{strategy.name}</div>
                    <div className="text-sm text-muted-foreground">{strategy.type}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <div className="text-sm font-medium profit">+{strategy.roi}% ROI</div>
                    <div className="text-xs text-muted-foreground">{strategy.successRate}% success</div>
                  </div>
                  <Badge variant="outline" className={getRiskColor(strategy.risk)}>
                    {strategy.risk} risk
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Live Opportunities */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightning size={20} />
            Live Opportunities
          </CardTitle>
          <CardDescription>
            Real-time arbitrage opportunities detected by AI
          </CardDescription>
        </CardHeader>
        <CardContent>
          {opportunities.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {isEngineRunning ? 'Scanning for opportunities...' : 'Start the engine to detect opportunities'}
            </div>
          ) : (
            <div className="space-y-3">
              {opportunities.slice(0, 5).map((opp) => (
                <div key={opp.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    {getStatusIcon(opp.status)}
                    <div>
                      <div className="font-medium">{opp.pair}</div>
                      <div className="text-sm text-muted-foreground">
                        {opp.exchange1} → {opp.exchange2}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-sm font-medium profit">+{opp.priceDiff.toFixed(2)}%</div>
                      <div className="text-xs text-muted-foreground">${opp.profit.toFixed(2)} profit</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm">Confidence</div>
                      <div className="text-xs text-muted-foreground">{opp.confidence.toFixed(1)}%</div>
                    </div>
                    {opp.status === 'detected' && (
                      <Button
                        size="sm"
                        onClick={() => handleExecuteOpportunity(opp.id)}
                        className="gap-2"
                      >
                        <Play size={14} />
                        Execute
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}