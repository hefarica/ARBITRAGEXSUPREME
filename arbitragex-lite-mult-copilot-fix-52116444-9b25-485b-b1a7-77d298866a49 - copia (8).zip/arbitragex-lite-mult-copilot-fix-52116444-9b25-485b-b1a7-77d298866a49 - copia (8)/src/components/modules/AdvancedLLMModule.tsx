import { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Brain, 
  PaperPlane, 
  Sparkle, 
  TrendUp, 
  Code, 
  Target,
  User,
  Robot,
  Lightbulb,
  ChartLine
} from '@phosphor-icons/react'
import { useKV } from '../hooks/useKV'

interface AdvancedLLMModuleProps {
  environment: 'test' | 'prod'
}

interface Message {
  id: string
  type: 'user' | 'assistant'
  content: string
  timestamp: Date
  category?: 'insight' | 'strategy' | 'risk' | 'market'
}

interface Suggestion {
  id: string
  title: string
  description: string
  category: 'strategy' | 'risk' | 'market' | 'optimization'
  priority: 'high' | 'medium' | 'low'
}

const quickPrompts = [
  "Analyze current market conditions for arbitrage opportunities",
  "Generate a new triangular arbitrage strategy",
  "Explain risk management best practices",
  "Optimize my trading parameters for better returns",
  "What are the latest DeFi trends affecting arbitrage?",
  "Help me understand MEV protection strategies"
]

const suggestions: Suggestion[] = [
  {
    id: '1',
    title: 'Optimize Gas Usage',
    description: 'Review your transaction batching to reduce gas costs by up to 25%',
    category: 'optimization',
    priority: 'high'
  },
  {
    id: '2',
    title: 'New Arbitrage Route',
    description: 'ETH/USDC pair showing 0.3% spread across Uniswap and SushiSwap',
    category: 'strategy',
    priority: 'high'
  },
  {
    id: '3',
    title: 'Risk Alert',
    description: 'High volatility detected in your active positions',
    category: 'risk',
    priority: 'medium'
  },
  {
    id: '4',
    title: 'Market Update',
    description: 'New DEX liquidity pools available for your trading pairs',
    category: 'market',
    priority: 'low'
  }
]

export default function AdvancedLLMModule({ environment }: AdvancedLLMModuleProps) {
  const [messages, setMessages] = useKV<Message[]>('llm-chat-history', [])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [messages])

  const handlePaperPlaneMessage = async (content: string) => {
    if (!content.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsLoading(true)

    try {
      // Simulate AI response - in production this would connect to real LLM API
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000))
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: generateAIResponse(content),
        timestamp: new Date(),
        category: determineCategory(content)
      }

      setMessages(prev => [...prev, assistantMessage])
    } catch (error) {
      console.error('Error generating AI response:', error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'I apologize, but I encountered an error while processing your request. Please try again.',
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const generateAIResponse = (userInput: string): string => {
    const input = userInput.toLowerCase()
    
    if (input.includes('arbitrage') || input.includes('strategy')) {
      return `Based on current market analysis, I've identified several arbitrage opportunities:

🎯 **Triangular Arbitrage**: ETH → USDC → DAI → ETH showing 0.12% profit margin
📊 **Cross-DEX**: WBTC price difference of 0.08% between Uniswap and SushiSwap
⚡ **Flash Loan**: Potential 0.15% profit on LINK/ETH using Aave flash loans

**Recommended Action**: Start with the triangular arbitrage as it has the lowest gas cost relative to profit potential.

Would you like me to generate the specific transaction parameters for any of these strategies?`
    }
    
    if (input.includes('risk') || input.includes('manage')) {
      return `Here's your comprehensive risk management framework:

🛡️ **Position Sizing**: Never risk more than 2% of portfolio per trade
⏱️ **Time Limits**: Set 5-minute maximum execution windows
💨 **Gas Protection**: Cancel if gas > 150 gwei unless profit > 0.5%
🔄 **Diversification**: Spread across minimum 5 different token pairs

**Circuit Breakers**:
- Stop trading if daily loss > 5%
- Pause on network congestion > 200 gwei
- Alert on unusual price movements > 2% in 1 minute

Your current risk score: **Medium** (recommended adjustments available)`
    }
    
    if (input.includes('market') || input.includes('condition')) {
      return `Current DeFi Market Analysis:

📈 **Overall Sentiment**: Bullish (fear/greed index: 68)
🌊 **Liquidity**: High across major DEXs (+15% from last week)
⛽ **Gas Prices**: Moderate (avg 45 gwei, optimal for arbitrage)
🔄 **SpeakerHigh**: $2.1B daily DEX volume (-3% from yesterday)

**Key Opportunities**:
1. Increased activity in L2 solutions (Arbitrum/Optimism)
2. New liquidity farming rewards on Balancer
3. Reduced competition in exotic pairs

**Risks to Desktop**:
- Potential Fed announcement impact
- Large whale movements in stablecoin pools
- MEV bot competition increasing`
    }
    
    return `I understand you're asking about "${userInput}". Let me provide you with relevant insights for your DeFi arbitrage strategy:

Based on current market conditions, I recommend focusing on:
- Cross-chain opportunities between Ethereum and Layer 2 solutions
- Stablecoin arbitrage during high volatility periods
- MEV protection strategies for larger trades

Would you like me to elaborate on any specific aspect or provide more detailed analysis for a particular trading pair?`
  }

  const determineCategory = (content: string): Message['category'] => {
    const input = content.toLowerCase()
    if (input.includes('strategy') || input.includes('arbitrage')) return 'strategy'
    if (input.includes('risk') || input.includes('manage')) return 'risk'
    if (input.includes('market') || input.includes('price')) return 'market'
    return 'insight'
  }

  const handleQuickPrompt = (prompt: string) => {
    setInputValue(prompt)
    handlePaperPlaneMessage(prompt)
  }

  const clearHistory = () => {
    setMessages([])
  }

  const getMessageIcon = (type: Message['type']) => {
    return type === 'user' ? <User size={16} /> : <Robot size={16} />
  }

  const getCategoryColor = (category?: Message['category']) => {
    switch (category) {
      case 'strategy': return 'border-green-500 bg-green-50'
      case 'risk': return 'border-red-500 bg-red-50'
      case 'market': return 'border-blue-500 bg-blue-50'
      case 'insight': return 'border-purple-500 bg-purple-50'
      default: return 'border-gray-500 bg-gray-50'
    }
  }

  const getSuggestionColor = (category: Suggestion['category']) => {
    switch (category) {
      case 'strategy': return 'border-green-500 bg-green-50'
      case 'risk': return 'border-red-500 bg-red-50'
      case 'market': return 'border-blue-500 bg-blue-50'
      case 'optimization': return 'border-purple-500 bg-purple-50'
      default: return 'border-gray-500 bg-gray-50'
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
      {/* Chat Interface */}
      <div className="lg:col-span-2 space-y-4">
        <Card className="h-[600px] flex flex-col">
          <CardHeader className="flex-shrink-0">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Brain size={24} className="text-primary" />
                  AI Trading Assistant
                </CardTitle>
                <CardDescription>
                  Advanced AI-powered insights for DeFi arbitrage strategies
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="gap-1">
                  <Sparkle size={12} />
                  AI Powered
                </Badge>
                <Button variant="outline" size="sm" onClick={clearHistory}>
                  Clear
                </Button>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col">
            <ScrollArea className="flex-1 pr-4">
              <div className="space-y-4">
                {messages.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Brain size={48} className="mx-auto mb-4 opacity-50" />
                    <p>Ask me anything about DeFi arbitrage, trading strategies, or market analysis!</p>
                  </div>
                )}
                
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex items-start gap-3 ${
                      message.type === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {message.type === 'assistant' && (
                      <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
                        {getMessageIcon(message.type)}
                      </div>
                    )}
                    
                    <div
                      className={`max-w-[80%] rounded-lg p-4 ${
                        message.type === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : `border-2 ${getCategoryColor(message.category)}`
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        {message.type === 'user' && getMessageIcon(message.type)}
                        <span className="text-xs opacity-70">
                          {message.timestamp.toLocaleTimeString()}
                        </span>
                        {message.category && message.type === 'assistant' && (
                          <Badge variant="outline" className="text-xs">
                            {message.category}
                          </Badge>
                        )}
                      </div>
                      <div className="whitespace-pre-wrap text-sm">
                        {message.content}
                      </div>
                    </div>
                    
                    {message.type === 'user' && (
                      <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                        {getMessageIcon(message.type)}
                      </div>
                    )}
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
                      <Robot size={16} />
                    </div>
                    <div className="border-2 border-gray-200 bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={scrollRef} />
              </div>
            </ScrollArea>
            
            <div className="flex-shrink-0 mt-4">
              <div className="flex gap-2 mb-3 flex-wrap">
                {quickPrompts.slice(0, 3).map((prompt, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickPrompt(prompt)}
                    className="text-xs"
                  >
                    {prompt.slice(0, 30)}...
                  </Button>
                ))}
              </div>
              
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Ask about arbitrage strategies, market analysis, or risk management..."
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault()
                      handlePaperPlaneMessage(inputValue)
                    }
                  }}
                  disabled={isLoading}
                />
                <Button
                  onClick={() => handlePaperPlaneMessage(inputValue)}
                  disabled={isLoading || !inputValue.trim()}
                  size="icon"
                >
                  <PaperPlane size={16} />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* SidebarSimple with suggestions and quick actions */}
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb size={20} />
              AI Suggestions
            </CardTitle>
            <CardDescription>
              Personalized recommendations based on your trading activity
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {suggestions.map((suggestion) => (
              <div
                key={suggestion.id}
                className={`p-3 rounded-lg border-2 cursor-pointer hover:opacity-80 transition-opacity ${getSuggestionColor(suggestion.category)}`}
                onClick={() => handleQuickPrompt(`Tell me more about: ${suggestion.title}`)}
              >
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-medium text-sm">{suggestion.title}</h4>
                  <Badge variant="outline" className="text-xs">
                    {suggestion.priority}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  {suggestion.description}
                </p>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code size={20} />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={() => handleQuickPrompt("Analyze my current portfolio for optimization opportunities")}
            >
              <LineChart size={16} />
              Portfolio Analysis
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={() => handleQuickPrompt("Generate a custom arbitrage strategy for the current market conditions")}
            >
              <Target size={16} />
              Generate Strategy
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={() => handleQuickPrompt("Optimize my existing strategies for better performance")}
            >
              <TrendUp size={16} />
              Optimize Existing
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={() => handleQuickPrompt("Create a risk management framework for my trading")}
            >
              <Target size={16} />
              Risk Framework
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}