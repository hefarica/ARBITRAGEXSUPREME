import { useState } from 'react'
import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { MarketSimulator } from '../simulation/MarketSimulator'
import { PortfolioChart } from '../charts/PortfolioChart'
import { ProfitLossChart } from '../charts/ProfitLossChart'
import { StrategyAllocationChart } from '../charts/StrategyAllocationChart'
import { RiskMetricsChart } from '../charts/RiskMetricsChart'
import { TradingSpeakerHighChart } from '../charts/TradingSpeakerHighChart'
import { 
  TrendUp, 
  TrendDown, 
  Activity, 
  Target, 
  BarChart, 
  PieChart,
  LineChart,
  Download,
  Repeat,
  WarningCircle,
  CalendarBlank,
  CurrencyDollar
} from '@phosphor-icons/react'

type TimeRange = '1D' | '7D' | '30D' | 'ALL'

export function AdvancedAnalyticsDashboard() {
  const { state } = useSimulation()
  const [timeRange, setTimeRange] = useState<TimeRange>('7D')
  const [refreshing, setArrowClockwiseing] = useState(false)

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value.toFixed(2)}%`
  }

  // Calculate comprehensive metrics
  const metrics = {
    totalTrades: state.trades.length,
    successfulTrades: state.trades.filter(t => t.profit > 0).length,
    winRate: state.trades.length > 0 ? (state.trades.filter(t => t.profit > 0).length / state.trades.length) * 100 : 0,
    totalFees: state.trades.reduce((sum, t) => sum + t.fees, 0),
    avgTradeSize: state.trades.length > 0 ? state.trades.reduce((sum, t) => sum + t.amount, 0) / state.trades.length : 0,
    totalReturn: ((state.balance - 10000) / 10000) * 100,
    totalSpeakerHigh: state.trades.reduce((sum, t) => sum + t.amount, 0),
    
    profitFactor: (() => {
      const profits = state.trades.filter(t => t.profit > 0).reduce((sum, t) => sum + t.profit, 0)
      const losses = Math.abs(state.trades.filter(t => t.profit <= 0).reduce((sum, t) => sum + t.profit, 0))
      return losses > 0 ? profits / losses : profits > 0 ? Infinity : 0
    })(),

    sharpeRatio: (() => {
      if (state.trades.length < 2) return 0
      const returns = state.trades.map(t => (t.profit - t.fees) / t.amount)
      const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length
      const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length
      const stdDev = Math.sqrt(variance)
      return stdDev > 0 ? (avgReturn * Math.sqrt(252)) / (stdDev * Math.sqrt(252)) : 0 // Annualized
    })(),

    maxDrawdown: (() => {
      let maxBalance = 10000
      let maxDD = 0
      let runningBalance = 10000
      
      Array.from(state.trades).reverse().forEach(trade => {
        runningBalance += trade.profit - trade.fees
        if (runningBalance > maxBalance) maxBalance = runningBalance
        const drawdown = (maxBalance - runningBalance) / maxBalance
        if (drawdown > maxDD) maxDD = drawdown
      })
      
      return maxDD * 100
    })()
  }

  const handleArrowClockwise = async () => {
    setArrowClockwiseing(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    setArrowClockwiseing(false)
  }

  const handleExportData = () => {
    const exportData = {
      summary: metrics,
      trades: state.trades,
      marketData: state.marketData,
      timestamp: new Date().toISOString()
    }
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `defi-analytics-${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* Header with Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Advanced Analytics</h1>
          <p className="text-muted-foreground">Comprehensive portfolio performance and risk analysis</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Select value={timeRange} onValueChange={(value: TimeRange) => setTimeRange(value)}>
            <SelectTrigger className="w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1D">1D</SelectItem>
              <SelectItem value="7D">7D</SelectItem>
              <SelectItem value="30D">30D</SelectItem>
              <SelectItem value="ALL">All</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleArrowClockwise}
            disabled={refreshing}
            className="gap-2"
          >
            <Repeat size={16} className={refreshing ? 'animate-spin' : ''} />
            ArrowClockwise
          </Button>
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleExportData}
            className="gap-2"
          >
            <Download size={16} />
            Export
          </Button>
        </div>
      </div>

      {/* Performance Alerts */}
      {metrics.maxDrawdown > 15 && (
        <Card className="border-destructive bg-destructive/5">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <WarningCircle size={20} className="text-destructive flex-shrink-0" />
              <div>
                <p className="font-medium text-destructive">High Risk Alert</p>
                <p className="text-sm text-muted-foreground">
                  Portfolio drawdown of {formatPercentage(metrics.maxDrawdown)} exceeds recommended levels. Consider risk management review.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Key Performance Metrics GridFour */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Return</p>
                <p className={`text-2xl font-bold ${metrics.totalReturn >= 0 ? 'profit' : 'loss'}`}>
                  {formatPercentage(metrics.totalReturn)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatCurrency(state.balance - 10000)} absolute
                </p>
              </div>
              <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                metrics.totalReturn >= 0 ? 'bg-profit/10' : 'bg-destructive/10'
              }`}>
                {metrics.totalReturn >= 0 ? 
                  <TrendUp size={24} className="text-profit" /> : 
                  <TrendDown size={24} className="text-destructive" />
                }
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Sharpe Ratio</p>
                <p className="text-2xl font-bold">{metrics.sharpeRatio.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground mt-1">Risk-adjusted return</p>
              </div>
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Target size={24} className="text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Win Rate</p>
                <p className="text-2xl font-bold">{formatPercentage(metrics.winRate)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {metrics.successfulTrades}/{metrics.totalTrades} trades
                </p>
              </div>
              <div className="h-12 w-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <BarChart size={24} className="text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total SpeakerHigh</p>
                <p className="text-2xl font-bold">{formatCurrency(metrics.totalSpeakerHigh)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Avg: {formatCurrency(metrics.avgTradeSize)}
                </p>
              </div>
              <div className="h-12 w-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                <CurrencyDollar size={24} className="text-secondary-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart Tabs */}
      <Tabs defaultValue="portfolio" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="portfolio" className="gap-2">
            <LineChart size={16} />
            Portfolio
          </TabsTrigger>
          <TabsTrigger value="pnl" className="gap-2">
            <BarChart size={16} />
            P&L
          </TabsTrigger>
          <TabsTrigger value="allocation" className="gap-2">
            <PieChart size={16} />
            Allocation
          </TabsTrigger>
          <TabsTrigger value="risk" className="gap-2">
            <WarningCircle size={16} />
            Risk
          </TabsTrigger>
          <TabsTrigger value="volume" className="gap-2">
            <Activity size={16} />
            SpeakerHigh
          </TabsTrigger>
        </TabsList>

        <TabsContent value="portfolio" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LineChart size={20} />
                Portfolio Value Over Time
              </CardTitle>
            </CardHeader>
            <CardContent>
              <PortfolioChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pnl" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart size={20} />
                Daily Profit & Loss
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ProfitLossChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="allocation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart size={20} />
                Strategy Allocation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <StrategyAllocationChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <WarningCircle size={20} />
                Risk Analysis & Drawdown
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RiskMetricsChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="volume" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity size={20} />
                Trading SpeakerHigh Patterns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <TradingSpeakerHighChart />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Additional Metrics Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <MarketSimulator onTradeGenerated={() => {}} />
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Performance Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Profit Factor</span>
              <span className="font-semibold">
                {metrics.profitFactor === Infinity ? '∞' : metrics.profitFactor.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Max Drawdown</span>
              <span className={`font-semibold ${metrics.maxDrawdown > 10 ? 'loss' : 'text-foreground'}`}>
                {formatPercentage(metrics.maxDrawdown)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total Fees</span>
              <span className="font-semibold">{formatCurrency(metrics.totalFees)}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Trading Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total Trades</span>
              <span className="font-semibold">{metrics.totalTrades}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Success Rate</span>
              <span className="font-semibold profit">{formatPercentage(metrics.winRate)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Avg Trade Size</span>
              <span className="font-semibold">{formatCurrency(metrics.avgTradeSize)}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Risk Metrics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Sharpe Ratio</span>
              <span className="font-semibold">{metrics.sharpeRatio.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Risk Level</span>
              <Badge className={metrics.maxDrawdown > 15 ? 'bg-destructive text-destructive-foreground' : 
                              metrics.maxDrawdown > 10 ? 'bg-warning text-warning-foreground' : 
                              'bg-profit text-profit-foreground'}>
                {metrics.maxDrawdown > 15 ? 'High' : metrics.maxDrawdown > 10 ? 'Medium' : 'Low'}
              </Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Portfolio Health</span>
              <Badge className={metrics.totalReturn >= 0 ? 'bg-profit text-profit-foreground' : 'bg-destructive text-destructive-foreground'}>
                {metrics.totalReturn >= 0 ? 'Healthy' : 'Needs Attention'}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}