import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { 
  ChartLine,
  MapPin,
  Clock,
  Brain,
  TrendingUp,
  TrendingDown,
  Target,
  Calendar,
  BarChart3,
  PieChart,
  LineChart,
  Globe,
  Database,
  Cpu,
  Network,
  Wifi,
  WifiOff,
  Lock,
  Unlock,
  Eye,
  EyeSlash,
  Bell,
  BellSlash,
  Timer,
  Calendar as CalendarIcon,
  ClockCounterClockwise,
  Rocket,
  Satellite,
  Broadcast,
  Radio,
  Television,
  Monitor,
  Smartphone,
  Tablet,
  Laptop,
  Desktop,
  Server,
  Cloud,
  HardDrives,
  HardDrive,
  FloppyDisk,
  CompactDisc,
  Usb,
  Bluetooth,
  WifiHigh,
  WifiMedium,
  WifiLow,
  Signal,
  SignalHigh,
  SignalMedium,
  SignalLow,
  Battery,
  BatteryCharging,
  BatteryWarning,
  BatteryEmpty,
  Power,
  PowerOff,
  PowerOn,
  PowerWarning,
  PowerError,
  PowerSuccess,
  PowerInfo,
  PowerQuestion,
  PowerPlus,
  PowerMinus,
  PowerEqual,
  PowerDivide,
  PowerMultiply,
  PowerPercent,
  PowerSquare,
  PowerCube,
  PowerRoot,
  PowerLog,
  PowerLn,
  PowerExp,
  PowerSin,
  PowerCos,
  PowerTan,
  PowerAsin,
  PowerAcos,
  PowerAtan,
  PowerSinh,
  PowerCosh,
  PowerTanh,
  PowerAsinh,
  PowerAcosh,
  PowerAtanh,
  MapTrifold,
  Compass,
  Navigation,
  Location,
  Placeholder,
  PlaceholderSimple,
  PlaceholderBold,
  PlaceholderLight,
  PlaceholderThin,
  PlaceholderFill,
  PlaceholderDuotone,
  PlaceholderGradient,
  PlaceholderLinear,
  PlaceholderRadial,
  PlaceholderConic,
  PlaceholderAngular,
  PlaceholderCubic,
  PlaceholderQuadratic,
  PlaceholderExponential,
  PlaceholderLogarithmic,
  PlaceholderSine,
  PlaceholderCosine,
  PlaceholderTangent,
  PlaceholderArcsin,
  PlaceholderArccos,
  PlaceholderArctan,
  PlaceholderSinh,
  PlaceholderCosh,
  PlaceholderTanh,
  PlaceholderArcsinh,
  PlaceholderArccosh,
  PlaceholderArctanh
} from '@phosphor-icons/react'
import { cn } from '@/lib/utils'

interface Opportunity {
  id: string
  location: string
  coordinates: { lat: number; lng: number }
  type: 'arbitrage' | 'liquidation' | 'mev' | 'flash-loan'
  profit: number
  probability: number
  timeWindow: number
  exchanges: string[]
  tokens: string[]
  aiConfidence: number
  marketConditions: 'bullish' | 'bearish' | 'neutral'
  volatility: 'low' | 'medium' | 'high'
  volume: number
  trend: 'up' | 'down' | 'sideways'
}

interface TimelineEvent {
  id: string
  timestamp: Date
  type: 'trade' | 'opportunity' | 'market-change' | 'system-event'
  title: string
  description: string
  impact: 'positive' | 'negative' | 'neutral'
  profit?: number
  loss?: number
  exchanges: string[]
  tokens: string[]
}

interface Pattern {
  id: string
  name: string
  description: string
  confidence: number
  frequency: number
  profitPotential: number
  risk: 'low' | 'medium' | 'high'
  timeOfDay: string
  dayOfWeek: string
  marketConditions: string[]
  exchanges: string[]
  tokens: string[]
  lastOccurrence: Date
  nextPredicted: Date
}

interface Prediction {
  id: string
  timeframe: '1h' | '4h' | '1d' | '1w' | '1m'
  predictedProfit: number
  confidence: number
  factors: string[]
  riskFactors: string[]
  recommendations: string[]
  timestamp: Date
}

export function PredictiveAnalytics2025() {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([])
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([])
  const [patterns, setPatterns] = useState<Pattern[]>([])
  const [predictions, setPredictions] = useState<Prediction[]>([])
  const [selectedTimeframe, setSelectedTimeframe] = useState<'1h' | '4h' | '1d' | '1w' | '1m'>('1d')

  // Simulación de datos en tiempo real
  useEffect(() => {
    const generateOpportunity = (): Opportunity => {
      const locations = ['Ethereum Mainnet', 'Polygon', 'BSC', 'Arbitrum', 'Optimism', 'Avalanche']
      const types: Array<Opportunity['type']> = ['arbitrage', 'liquidation', 'mev', 'flash-loan']
      const exchanges = ['Uniswap V3', 'SushiSwap', 'PancakeSwap', 'Curve', 'Balancer', '1inch']
      const tokens = ['ETH', 'USDC', 'USDT', 'DAI', 'WETH', 'WBTC', 'UNI', 'LINK']
      
      return {
        id: crypto.randomUUID(),
        location: locations[Math.floor(Math.random() * locations.length)],
        coordinates: {
          lat: Math.random() * 180 - 90,
          lng: Math.random() * 360 - 180
        },
        type: types[Math.floor(Math.random() * types.length)],
        profit: Math.random() * 500 + 50,
        probability: Math.random() * 30 + 70,
        timeWindow: Math.floor(Math.random() * 600) + 60,
        exchanges: exchanges.slice(0, Math.floor(Math.random() * 3) + 2),
        tokens: tokens.slice(0, Math.floor(Math.random() * 2) + 2),
        aiConfidence: Math.random() * 20 + 80,
        marketConditions: Math.random() > 0.6 ? 'bullish' : Math.random() > 0.3 ? 'bearish' : 'neutral',
        volatility: Math.random() > 0.7 ? 'high' : Math.random() > 0.4 ? 'medium' : 'low',
        volume: Math.random() * 1000000 + 100000,
        trend: Math.random() > 0.6 ? 'up' : Math.random() > 0.3 ? 'down' : 'sideways'
      }
    }

    const generateTimelineEvent = (): TimelineEvent => {
      const types: Array<TimelineEvent['type']> = ['trade', 'opportunity', 'market-change', 'system-event']
      const impacts: Array<TimelineEvent['impact']> = ['positive', 'negative', 'neutral']
      
      return {
        id: crypto.randomUUID(),
        timestamp: new Date(Date.now() - Math.random() * 86400000),
        type: types[Math.floor(Math.random() * types.length)],
        title: `Evento ${Math.floor(Math.random() * 1000)}`,
        description: 'Descripción del evento del timeline',
        impact: impacts[Math.floor(Math.random() * impacts.length)],
        profit: Math.random() > 0.5 ? Math.random() * 100 : undefined,
        loss: Math.random() > 0.5 ? Math.random() * 50 : undefined,
        exchanges: ['Uniswap', 'SushiSwap'],
        tokens: ['ETH', 'USDC']
      }
    }

    const generatePattern = (): Pattern => {
      return {
        id: crypto.randomUUID(),
        name: `Patrón ${Math.floor(Math.random() * 100)}`,
        description: 'Descripción del patrón detectado por IA',
        confidence: Math.random() * 30 + 70,
        frequency: Math.floor(Math.random() * 10) + 1,
        profitPotential: Math.random() * 200 + 50,
        risk: Math.random() > 0.7 ? 'high' : Math.random() > 0.4 ? 'medium' : 'low',
        timeOfDay: `${Math.floor(Math.random() * 24)}:00`,
        dayOfWeek: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'][Math.floor(Math.random() * 7)],
        marketConditions: ['bullish', 'bearish'],
        exchanges: ['Uniswap', 'SushiSwap'],
        tokens: ['ETH', 'USDC'],
        lastOccurrence: new Date(Date.now() - Math.random() * 86400000),
        nextPredicted: new Date(Date.now() + Math.random() * 86400000)
      }
    }

    const generatePrediction = (): Prediction => {
      const timeframes: Array<Prediction['timeframe']> = ['1h', '4h', '1d', '1w', '1m']
      
      return {
        id: crypto.randomUUID(),
        timeframe: timeframes[Math.floor(Math.random() * timeframes.length)],
        predictedProfit: Math.random() * 1000 + 100,
        confidence: Math.random() * 30 + 70,
        factors: ['Volatilidad alta', 'Volumen creciente', 'Tendencia alcista'],
        riskFactors: ['Mercado volátil', 'Liquidez baja'],
        recommendations: ['Aumentar posición', 'Reducir riesgo'],
        timestamp: new Date()
      }
    }

    // Generar datos iniciales
    const initialOpportunities = Array.from({ length: 10 }, generateOpportunity)
    const initialTimelineEvents = Array.from({ length: 20 }, generateTimelineEvent)
    const initialPatterns = Array.from({ length: 5 }, generatePattern)
    const initialPredictions = Array.from({ length: 5 }, generatePrediction)

    setOpportunities(initialOpportunities)
    setTimelineEvents(initialTimelineEvents.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()))
    setPatterns(initialPatterns)
    setPredictions(initialPredictions)

    // Actualizar datos en tiempo real
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        setOpportunities(prev => [generateOpportunity(), ...prev.slice(0, 9)])
      }
      if (Math.random() > 0.8) {
        setTimelineEvents(prev => [generateTimelineEvent(), ...prev.slice(0, 19)])
      }
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'positive': return 'text-green-600'
      case 'negative': return 'text-red-600'
      case 'neutral': return 'text-gray-600'
      default: return 'text-gray-600'
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp size={16} className="text-green-600" />
      case 'down': return <TrendingDown size={16} className="text-red-600" />
      case 'sideways': return <Target size={16} className="text-yellow-600" />
      default: return <Target size={16} className="text-gray-600" />
    }
  }

  const totalPredictedProfit = predictions.reduce((sum, p) => sum + p.predictedProfit, 0)
  const averageConfidence = predictions.reduce((sum, p) => sum + p.confidence, 0) / predictions.length

  return (
    <div className="space-y-6">
      {/* Header del Análisis Predictivo */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Brain size={32} />
            <div>
              <h1 className="text-2xl font-bold">Análisis Predictivo con IA</h1>
              <p className="text-purple-100">Predicciones inteligentes basadas en datos históricos y patrones de mercado</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp size={20} />
                <span className="text-xl font-bold">{formatCurrency(totalPredictedProfit)}</span>
              </div>
              <p className="text-sm text-purple-100">Ganancia Predicha</p>
            </div>
            
            <div className="text-right">
              <div className="flex items-center gap-2 mb-1">
                <Brain size={20} />
                <span className="text-xl font-bold">{averageConfidence.toFixed(1)}%</span>
              </div>
              <p className="text-sm text-purple-100">Confianza IA</p>
            </div>
          </div>
        </div>
        
        {/* Métricas Rápidas */}
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold">{opportunities.length}</p>
            <p className="text-sm text-purple-100">Oportunidades Activas</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{patterns.length}</p>
            <p className="text-sm text-purple-100">Patrones Detectados</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{timelineEvents.length}</p>
            <p className="text-sm text-purple-100">Eventos Registrados</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{predictions.length}</p>
            <p className="text-sm text-purple-100">Predicciones Activas</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="map" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="map">Mapa de Oportunidades</TabsTrigger>
          <TabsTrigger value="timeline">Timeline de Eventos</TabsTrigger>
          <TabsTrigger value="patterns">Análisis de Patrones</TabsTrigger>
          <TabsTrigger value="predictions">Proyecciones</TabsTrigger>
        </TabsList>

        <TabsContent value="map" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Mapa Visual */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapTrifold size={20} />
                    Mapa de Oportunidades de Arbitraje
                  </CardTitle>
                  <p className="text-muted-foreground">
                    Visualización geográfica de oportunidades en diferentes blockchains
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6 h-96 relative overflow-hidden">
                    {/* Simulación de mapa */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center text-muted-foreground">
                        <Globe size={64} className="mx-auto mb-4 opacity-50" />
                        <p className="text-lg font-semibold">Mapa Interactivo</p>
                        <p className="text-sm">Visualización de oportunidades en tiempo real</p>
                      </div>
                    </div>
                    
                    {/* Puntos de oportunidades */}
                    {opportunities.map((opp, index) => (
                      <div
                        key={opp.id}
                        className="absolute w-4 h-4 bg-red-500 rounded-full animate-pulse cursor-pointer"
                        style={{
                          left: `${20 + (index * 8) % 60}%`,
                          top: `${30 + (index * 12) % 40}%`
                        }}
                        title={`${opp.location}: ${formatCurrency(opp.profit)}`}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Lista de Oportunidades */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target size={20} />
                    Oportunidades Activas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {opportunities.map((opp) => (
                      <div key={opp.id} className="p-3 border rounded-lg hover:bg-gray-50">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h4 className="font-semibold text-sm">{opp.location}</h4>
                            <p className="text-xs text-muted-foreground">{opp.type}</p>
                          </div>
                          <Badge className={cn(
                            "text-white",
                            opp.marketConditions === 'bullish' ? "bg-green-500" :
                            opp.marketConditions === 'bearish' ? "bg-red-500" : "bg-gray-500"
                          )}>
                            {opp.marketConditions}
                          </Badge>
                        </div>
                        
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between">
                            <span>Ganancia:</span>
                            <span className="font-semibold text-green-600">{formatCurrency(opp.profit)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Confianza IA:</span>
                            <span>{opp.aiConfidence.toFixed(1)}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Ventana:</span>
                            <span>{Math.floor(opp.timeWindow / 60)}m {opp.timeWindow % 60}s</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span>Tendencia:</span>
                            {getTrendIcon(opp.trend)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="timeline" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock size={20} />
                Timeline de Eventos
              </CardTitle>
              <p className="text-muted-foreground">
                Cronología de operaciones, oportunidades y cambios de mercado
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {timelineEvents.map((event, index) => (
                  <div key={event.id} className="flex items-start gap-4">
                    {/* Línea de tiempo */}
                    <div className="flex flex-col items-center">
                      <div className={cn(
                        "w-3 h-3 rounded-full",
                        event.impact === 'positive' ? "bg-green-500" :
                        event.impact === 'negative' ? "bg-red-500" : "bg-gray-500"
                      )} />
                      {index < timelineEvents.length - 1 && (
                        <div className="w-0.5 h-8 bg-gray-300 mt-1" />
                      )}
                    </div>
                    
                    {/* Contenido del evento */}
                    <div className="flex-1 p-3 border rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className={cn("font-semibold", getImpactColor(event.impact))}>
                            {event.title}
                          </h4>
                          <p className="text-sm text-muted-foreground">{event.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">
                            {event.timestamp.toLocaleTimeString()}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {event.timestamp.toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4 text-xs">
                        <span>Exchanges: {event.exchanges.join(', ')}</span>
                        <span>Tokens: {event.tokens.join('/')}</span>
                        {event.profit && (
                          <span className="text-green-600 font-semibold">
                            +{formatCurrency(event.profit)}
                          </span>
                        )}
                        {event.loss && (
                          <span className="text-red-600 font-semibold">
                            -{formatCurrency(event.loss)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lista de Patrones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain size={20} />
                  Patrones Detectados por IA
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {patterns.map((pattern) => (
                    <div key={pattern.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold">{pattern.name}</h4>
                          <p className="text-sm text-muted-foreground">{pattern.description}</p>
                        </div>
                        <Badge className={cn(
                          "text-white",
                          pattern.risk === 'low' ? "bg-green-500" :
                          pattern.risk === 'medium' ? "bg-yellow-500" : "bg-red-500"
                        )}>
                          {pattern.risk} risk
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Confianza:</span>
                          <p className="font-semibold">{pattern.confidence.toFixed(1)}%</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Frecuencia:</span>
                          <p className="font-semibold">{pattern.frequency}/día</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Potencial:</span>
                          <p className="font-semibold text-green-600">{formatCurrency(pattern.profitPotential)}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Próximo:</span>
                          <p className="font-semibold">{pattern.nextPredicted.toLocaleTimeString()}</p>
                        </div>
                      </div>
                      
                      <div className="mt-3 text-xs text-muted-foreground">
                        <p>Mejor momento: {pattern.dayOfWeek} a las {pattern.timeOfDay}</p>
                        <p>Exchanges: {pattern.exchanges.join(', ')}</p>
                        <p>Tokens: {pattern.tokens.join('/')}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Análisis de Patrones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 size={20} />
                  Análisis de Patrones
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Patrones por Hora */}
                  <div>
                    <h4 className="font-semibold mb-3">Patrones por Hora del Día</h4>
                    <div className="space-y-2">
                      {Array.from({ length: 6 }, (_, i) => (
                        <div key={i} className="flex items-center gap-3">
                          <span className="text-sm w-12">{i * 4}:00</span>
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-500 h-2 rounded-full"
                              style={{ width: `${Math.random() * 100}%` }}
                            />
                          </div>
                          <span className="text-sm w-12">{Math.floor(Math.random() * 10)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Patrones por Día */}
                  <div>
                    <h4 className="font-semibold mb-3">Patrones por Día de la Semana</h4>
                    <div className="space-y-2">
                      {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map((day, i) => (
                        <div key={day} className="flex items-center gap-3">
                          <span className="text-sm w-8">{day}</span>
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-green-500 h-2 rounded-full"
                              style={{ width: `${Math.random() * 100}%` }}
                            />
                          </div>
                          <span className="text-sm w-12">{Math.floor(Math.random() * 20)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Efectividad de Patrones */}
                  <div>
                    <h4 className="font-semibold mb-3">Efectividad de Patrones</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span>Patrones de Alta Confianza</span>
                        <span className="font-semibold">87.5%</span>
                      </div>
                      <Progress value={87.5} className="h-2" />
                      
                      <div className="flex justify-between text-sm">
                        <span>Patrones de Media Confianza</span>
                        <span className="font-semibold">72.3%</span>
                      </div>
                      <Progress value={72.3} className="h-2" />
                      
                      <div className="flex justify-between text-sm">
                        <span>Patrones de Baja Confianza</span>
                        <span className="font-semibold">45.8%</span>
                      </div>
                      <Progress value={45.8} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="predictions" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Proyecciones de Ganancias */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp size={20} />
                  Proyecciones de Ganancias
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {predictions.map((prediction) => (
                    <div key={prediction.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold">Predicción {prediction.timeframe}</h4>
                          <p className="text-sm text-muted-foreground">
                            Basada en análisis de {prediction.factors.length} factores
                          </p>
                        </div>
                        <Badge className="bg-blue-100 text-blue-800">
                          {prediction.confidence.toFixed(1)}% confianza
                        </Badge>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Ganancia Predicha:</span>
                          <span className="font-bold text-green-600 text-lg">
                            {formatCurrency(prediction.predictedProfit)}
                          </span>
                        </div>
                        
                        <div>
                          <span className="text-sm text-muted-foreground">Factores Positivos:</span>
                          <ul className="text-xs text-green-600 mt-1">
                            {prediction.factors.map((factor, index) => (
                              <li key={index}>• {factor}</li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <span className="text-sm text-muted-foreground">Factores de Riesgo:</span>
                          <ul className="text-xs text-red-600 mt-1">
                            {prediction.riskFactors.map((factor, index) => (
                              <li key={index}>• {factor}</li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <span className="text-sm text-muted-foreground">Recomendaciones:</span>
                          <ul className="text-xs text-blue-600 mt-1">
                            {prediction.recommendations.map((rec, index) => (
                              <li key={index}>• {rec}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Gráfico de Proyecciones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart size={20} />
                  Tendencias de Proyección
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Selector de Timeframe */}
                  <div className="flex gap-2">
                    {(['1h', '4h', '1d', '1w', '1m'] as const).map((tf) => (
                      <Button
                        key={tf}
                        variant={selectedTimeframe === tf ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedTimeframe(tf)}
                      >
                        {tf}
                      </Button>
                    ))}
                  </div>
                  
                  {/* Gráfico Simulado */}
                  <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6 h-64 flex items-center justify-center">
                    <div className="text-center text-muted-foreground">
                      <LineChart size={48} className="mx-auto mb-4 opacity-50" />
                      <p className="font-semibold">Gráfico de Proyecciones</p>
                      <p className="text-sm">Visualización de tendencias para {selectedTimeframe}</p>
                    </div>
                  </div>
                  
                  {/* Métricas de Proyección */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">
                        {formatCurrency(totalPredictedProfit)}
                      </p>
                      <p className="text-sm text-muted-foreground">Ganancia Total Predicha</p>
                    </div>
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">
                        {averageConfidence.toFixed(1)}%
                      </p>
                      <p className="text-sm text-muted-foreground">Confianza Promedio</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 