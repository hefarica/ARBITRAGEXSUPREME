import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { 
  AlertTriangle, 
  CheckCircle, 
  DollarSign, 
  GasPump, 
  TrendingUp,
  Clock,
  Target,
  Shield,
  Zap
} from 'lucide-react'
import { ArbitrageViabilityCalculator, ViabilityMetrics, ArbitrageOpportunity } from '@/services/ArbitrageViabilityCalculator'

interface ViabilityDashboardProps {
  className?: string
}

export const ArbitrageViabilityDashboard: React.FC<ViabilityDashboardProps> = ({ className }) => {
  const [calculator] = useState(() => new ArbitrageViabilityCalculator())
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([])
  const [viabilityResults, setViabilityResults] = useState<Map<string, ViabilityMetrics>>(new Map())
  const [selectedCapital, setSelectedCapital] = useState(1000)
  const [gasPrices, setGasPrices] = useState<Map<string, number>>(new Map())
  const [isLoading, setIsLoading] = useState(false)

  // Generar oportunidades de ejemplo para demostración
  useEffect(() => {
    generateSampleOpportunities()
    updateGasPrices()
  }, [])

  const generateSampleOpportunities = () => {
    const sampleOpps: ArbitrageOpportunity[] = [
      {
        id: '1',
        type: 'simple',
        tokenPath: ['ETH', 'USDC'],
        dexPath: ['Uniswap V3', 'SushiSwap'],
        chainPath: [1, 1],
        amountInUSD: 1000,
        expectedProfitUSD: 15,
        blockchain: 'ethereum',
        timestamp: Date.now()
      },
      {
        id: '2',
        type: 'triangular',
        tokenPath: ['ETH', 'USDC', 'DAI', 'ETH'],
        dexPath: ['Uniswap V3', 'Curve', 'SushiSwap'],
        chainPath: [1, 1, 1, 1],
        amountInUSD: 5000,
        expectedProfitUSD: 45,
        blockchain: 'arbitrum',
        timestamp: Date.now()
      },
      {
        id: '3',
        type: 'cross-chain',
        tokenPath: ['ETH', 'USDC'],
        dexPath: ['Uniswap V3', 'PancakeSwap'],
        chainPath: [1, 56],
        amountInUSD: 2000,
        expectedProfitUSD: 35,
        blockchain: 'polygon',
        timestamp: Date.now()
      },
      {
        id: '4',
        type: 'nft-floor',
        tokenPath: ['ETH', 'BAYC'],
        dexPath: ['OpenSea', 'X2Y2'],
        chainPath: [1, 1],
        amountInUSD: 500,
        expectedProfitUSD: 25,
        blockchain: 'ethereum',
        timestamp: Date.now()
      },
      {
        id: '5',
        type: 'mev-liquidation',
        tokenPath: ['ETH', 'USDC'],
        dexPath: ['Aave', 'Uniswap V3'],
        chainPath: [1, 1],
        amountInUSD: 10000,
        expectedProfitUSD: 120,
        blockchain: 'arbitrum',
        timestamp: Date.now()
      },
      {
        id: '6',
        type: 'simple',
        tokenPath: ['BNB', 'BUSD'],
        dexPath: ['PancakeSwap', 'BiSwap'],
        chainPath: [56, 56],
        amountInUSD: 100,
        expectedProfitUSD: 2.5,
        blockchain: 'bsc',
        timestamp: Date.now()
      },
      {
        id: '7',
        type: 'triangular',
        tokenPath: ['MATIC', 'USDC', 'USDT', 'MATIC'],
        dexPath: ['QuickSwap', 'Curve', 'SushiSwap'],
        chainPath: [137, 137, 137, 137],
        amountInUSD: 300,
        expectedProfitUSD: 8,
        blockchain: 'polygon',
        timestamp: Date.now()
      },
      {
        id: '8',
        type: 'simple',
        tokenPath: ['AVAX', 'USDC'],
        dexPath: ['TraderJoe', 'Pangolin'],
        chainPath: [43114, 43114],
        amountInUSD: 1500,
        expectedProfitUSD: 18,
        blockchain: 'avalanche',
        timestamp: Date.now()
      }
    ]

    setOpportunities(sampleOpps)
  }

  const updateGasPrices = async () => {
    await calculator.updateGasPrices()
    const prices = new Map()
    for (const [chain] of calculator['blockchainProfiles']) {
      prices.set(chain, calculator['currentGasPrices'].get(chain) || 0)
    }
    setGasPrices(prices)
  }

  const calculateViabilityForAll = async () => {
    setIsLoading(true)
    try {
      const results = new Map<string, ViabilityMetrics>()
      
      for (const opp of opportunities) {
        const viability = await calculator.calculateViability(opp, selectedCapital)
        results.set(opp.id, viability)
      }
      
      setViabilityResults(results)
    } catch (error) {
      console.error('Error calculando viabilidad:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'LOW': return 'bg-green-100 text-green-800'
      case 'MEDIUM': return 'bg-yellow-100 text-yellow-800'
      case 'HIGH': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getBlockchainIcon = (blockchain: string) => {
    const icons: Record<string, string> = {
      'ethereum': '🔵',
      'arbitrum': '🔷',
      'optimism': '🔶',
      'polygon': '🟣',
      'bsc': '🟡',
      'avalanche': '🔴',
      'fantom': '🔵',
      'base': '🟦'
    }
    return icons[blockchain] || '⛓️'
  }

  const getStrategyIcon = (type: string) => {
    const icons: Record<string, React.ReactNode> = {
      'simple': <Target className="w-4 h-4" />,
      'triangular': <TrendingUp className="w-4 h-4" />,
      'cross-chain': <Zap className="w-4 h-4" />,
      'nft-floor': <Shield className="w-4 h-4" />,
      'mev-liquidation': <Clock className="w-4 h-4" />
    }
    return icons[type] || <Target className="w-4 h-4" />
  }

  const viableOpportunities = Array.from(viabilityResults.values()).filter(v => v.isViable)
  const totalPotentialProfit = viableOpportunities.reduce((sum, v) => sum + v.netProfitUSD, 0)
  const totalGasCosts = viableOpportunities.reduce((sum, v) => sum + v.gasCostUSD, 0)

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header con métricas principales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Oportunidades Viable</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{viableOpportunities.length}</div>
            <p className="text-xs text-muted-foreground">
              de {opportunities.length} total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profit Neto Total</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalPotentialProfit.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              Después de gas y fees
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Costos Gas Total</CardTitle>
            <GasPump className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalGasCosts.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              Costos de ejecución
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ROI Promedio</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {viableOpportunities.length > 0 
                ? (viableOpportunities.reduce((sum, v) => sum + v.netProfitPercentage, 0) / viableOpportunities.length).toFixed(2)
                : '0'
              }%
            </div>
            <p className="text-xs text-muted-foreground">
              Retorno sobre capital
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Controles */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GasPump className="w-5 h-5" />
            Calculadora de Viabilidad de Arbitraje
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-4 items-center">
            <div>
              <label className="text-sm font-medium">Capital Disponible (USD)</label>
              <select 
                value={selectedCapital} 
                onChange={(e) => setSelectedCapital(Number(e.target.value))}
                className="ml-2 px-3 py-1 border rounded"
              >
                <option value={100}>$100</option>
                <option value={500}>$500</option>
                <option value={1000}>$1,000</option>
                <option value={5000}>$5,000</option>
                <option value={10000}>$10,000</option>
              </select>
            </div>
            
            <Button 
              onClick={calculateViabilityForAll}
              disabled={isLoading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? 'Calculando...' : 'Calcular Viabilidad'}
            </Button>

            <Button 
              onClick={updateGasPrices}
              variant="outline"
              size="sm"
            >
              Actualizar Gas Prices
            </Button>
          </div>

          {/* Gas Prices en tiempo real */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {Array.from(gasPrices.entries()).map(([chain, price]) => (
              <div key={chain} className="text-center p-2 bg-gray-50 rounded">
                <div className="text-xs font-medium">{chain.toUpperCase()}</div>
                <div className="text-sm">{price.toFixed(1)} gwei</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tabs para diferentes vistas */}
      <Tabs defaultValue="viability" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="viability">Análisis de Viabilidad</TabsTrigger>
          <TabsTrigger value="blockchain">Ranking por Blockchain</TabsTrigger>
          <TabsTrigger value="strategy">Recomendaciones por Estrategia</TabsTrigger>
        </TabsList>

        <TabsContent value="viability" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Oportunidades con Viabilidad Calculada</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Estrategia</TableHead>
                    <TableHead>Blockchain</TableHead>
                    <TableHead>Capital</TableHead>
                    <TableHead>Profit Bruto</TableHead>
                    <TableHead>Gas Cost</TableHead>
                    <TableHead>Profit Neto</TableHead>
                    <TableHead>ROI Neto</TableHead>
                    <TableHead>Margen</TableHead>
                    <TableHead>Riesgo</TableHead>
                    <TableHead>Viable</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {opportunities.map(opp => {
                    const viability = viabilityResults.get(opp.id)
                    if (!viability) return null

                    return (
                      <TableRow key={opp.id}>
                        <TableCell className="flex items-center gap-2">
                          {getStrategyIcon(opp.type)}
                          <span className="capitalize">{opp.type}</span>
                        </TableCell>
                        <TableCell className="flex items-center gap-2">
                          <span>{getBlockchainIcon(opp.blockchain)}</span>
                          <span className="capitalize">{opp.blockchain}</span>
                        </TableCell>
                        <TableCell>${opp.amountInUSD.toLocaleString()}</TableCell>
                        <TableCell className="text-green-600">
                          ${viability.grossProfitUSD.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-red-600">
                          ${viability.gasCostUSD.toFixed(2)}
                        </TableCell>
                        <TableCell className={viability.netProfitUSD > 0 ? 'text-green-600' : 'text-red-600'}>
                          ${viability.netProfitUSD.toFixed(2)}
                        </TableCell>
                        <TableCell>
                          <span className={viability.netProfitPercentage > 0 ? 'text-green-600' : 'text-red-600'}>
                            {viability.netProfitPercentage.toFixed(2)}%
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className={viability.marginFactor >= 1.5 ? 'text-green-600' : 'text-yellow-600'}>
                            {viability.marginFactor.toFixed(1)}x
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge className={getRiskColor(viability.riskLevel)}>
                            {viability.riskLevel}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {viability.isViable ? (
                            <CheckCircle className="w-5 h-5 text-green-600" />
                          ) : (
                            <AlertTriangle className="w-5 h-5 text-red-600" />
                          )}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="blockchain" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Ranking de Blockchains por ROI</CardTitle>
            </CardHeader>
            <CardContent>
              {viabilityResults.size > 0 ? (
                <div className="space-y-4">
                  {Array.from(new Set(Array.from(viabilityResults.values()).map(v => v.recommendedBlockchain)))
                    .map(blockchain => {
                      const chainResults = Array.from(viabilityResults.values())
                        .filter(v => v.recommendedBlockchain === blockchain)
                      
                      if (chainResults.length === 0) return null

                      const avgROI = chainResults.reduce((sum, v) => sum + v.netProfitPercentage, 0) / chainResults.length
                      const avgSuccessRate = chainResults.reduce((sum, v) => sum + v.executionProbability, 0) / chainResults.length
                      const totalGasCost = chainResults.reduce((sum, v) => sum + v.gasCostUSD, 0)

                      return (
                        <div key={blockchain} className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-2xl">{getBlockchainIcon(blockchain)}</span>
                              <span className="font-semibold capitalize">{blockchain}</span>
                            </div>
                            <Badge variant="outline">
                              {chainResults.length} oportunidades
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-4 mb-3">
                            <div>
                              <div className="text-sm text-muted-foreground">ROI Promedio</div>
                              <div className="text-lg font-bold text-green-600">
                                {avgROI.toFixed(2)}%
                              </div>
                            </div>
                            <div>
                              <div className="text-sm text-muted-foreground">Tasa de Éxito</div>
                              <div className="text-lg font-bold text-blue-600">
                                {(avgSuccessRate * 100).toFixed(1)}%
                              </div>
                            </div>
                            <div>
                              <div className="text-sm text-muted-foreground">Gas Total</div>
                              <div className="text-lg font-bold text-red-600">
                                ${totalGasCost.toFixed(2)}
                              </div>
                            </div>
                          </div>

                          <Progress value={avgROI} className="h-2" />
                        </div>
                      )
                    })}
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  Calcula la viabilidad primero para ver el ranking
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="strategy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recomendaciones por Tipo de Estrategia</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {['simple', 'triangular', 'cross-chain', 'nft-floor', 'mev-liquidation'].map(strategyType => {
                  const recommendations = calculator.getStrategyRecommendations(strategyType, selectedCapital)
                  
                  return (
                    <Card key={strategyType} className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        {getStrategyIcon(strategyType)}
                        <h3 className="font-semibold capitalize">{strategyType}</h3>
                      </div>
                      
                      <div className="space-y-2">
                        <div>
                          <div className="text-sm font-medium">Blockchains Recomendadas</div>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {recommendations.recommendedBlockchains.map(chain => (
                              <Badge key={chain} variant="secondary" className="text-xs">
                                {getBlockchainIcon(chain)} {chain}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm font-medium">Profit Mínimo</div>
                          <div className="text-sm text-muted-foreground">
                            {recommendations.minProfitThreshold}% del capital
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm font-medium">Tips de Optimización</div>
                          <ul className="text-xs text-muted-foreground mt-1 space-y-1">
                            {recommendations.gasOptimizationTips.map((tip, index) => (
                              <li key={index}>• {tip}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Resumen ejecutivo */}
      {viabilityResults.size > 0 && (
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Resumen Ejecutivo de Viabilidad
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">📊 Métricas Clave</h4>
                <ul className="space-y-2 text-sm">
                  <li>• <strong>Oportunidades viables:</strong> {viableOpportunities.length} de {opportunities.length}</li>
                  <li>• <strong>Profit neto total:</strong> ${totalPotentialProfit.toFixed(2)}</li>
                  <li>• <strong>Costos de gas totales:</strong> ${totalGasCosts.toFixed(2)}</li>
                  <li>• <strong>ROI promedio:</strong> {viableOpportunities.length > 0 ? (viableOpportunities.reduce((sum, v) => sum + v.netProfitPercentage, 0) / viableOpportunities.length).toFixed(2) : '0'}%</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold mb-3">🎯 Recomendaciones</h4>
                <ul className="space-y-2 text-sm">
                  <li>• <strong>Priorizar L2s:</strong> Arbitrum, Optimism, Base para mejor ROI</li>
                  <li>• <strong>Evitar Ethereum mainnet:</strong> Para capital < $100</li>
                  <li>• <strong>Usar priority fees:</strong> En redes congestionadas</li>
                  <li>• <strong>Margen mínimo:</strong> 1.5x sobre costos de gas</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
