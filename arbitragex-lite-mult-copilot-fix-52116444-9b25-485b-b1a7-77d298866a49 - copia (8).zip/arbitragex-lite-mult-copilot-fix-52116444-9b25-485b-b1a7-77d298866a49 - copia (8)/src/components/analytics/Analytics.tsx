import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { AdvancedAnalyticsDashboard } from './AdvancedAnalyticsDashboard'
import { MarketAnalysisDashboard } from './MarketAnalysisDashboard'
import { PortfolioPerformanceTracker } from '../portfolio/PortfolioPerformanceTracker'
import { RiskManagementSystem } from '../portfolio/RiskManagementSystem'
import { TrendUp, TrendDown, Activity, BarChart, PieChart, Target, LineChart, Eye, Shield } from '@phosphor-icons/react'

export function Analytics() {
  const { state } = useSimulation()

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value.toFixed(2)}%`
  }

  // Calculate analytics
  const successfulTrades = state.trades.filter(t => t.profit > 0)
  const failedTrades = state.trades.filter(t => t.profit <= 0)
  const winRate = state.trades.length > 0 ? (successfulTrades.length / state.trades.length) * 100 : 0
  
  const totalProfit = successfulTrades.reduce((sum, t) => sum + t.profit, 0)
  const totalLoss = Math.abs(failedTrades.reduce((sum, t) => sum + t.profit, 0))
  const totalFees = state.trades.reduce((sum, t) => sum + t.fees, 0)
  
  const avgProfitPerTrade = state.trades.length > 0 ? state.totalPnL / state.trades.length : 0
  const avgFeesPerTrade = state.trades.length > 0 ? totalFees / state.trades.length : 0
  
  const profitFactor = totalLoss > 0 ? totalProfit / totalLoss : totalProfit > 0 ? Infinity : 0

  // Strategy performance breakdown
  const strategyStats = state.trades.reduce((acc, trade) => {
    if (!acc[trade.type]) {
      acc[trade.type] = { count: 0, profit: 0, fees: 0 }
    }
    acc[trade.type].count++
    acc[trade.type].profit += trade.profit
    acc[trade.type].fees += trade.fees
    return acc
  }, {} as Record<string, { count: number, profit: number, fees: number }>)

  // Recent performance (last 10 trades)
  const recentTrades = state.trades.slice(0, 10)
  const recentPerformance = recentTrades.reduce((sum, t) => sum + t.profit - t.fees, 0)

  return (
    <div className="space-y-6">
      {/* Key Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total P&L</p>
                <p className={`text-2xl font-bold ${state.totalPnL >= 0 ? 'profit' : 'loss'}`}>
                  {formatCurrency(state.totalPnL)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatPercentage((state.totalPnL / 10000) * 100)} of starting balance
                </p>
              </div>
              <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                state.totalPnL >= 0 ? 'bg-profit/10' : 'bg-destructive/10'
              }`}>
                {state.totalPnL >= 0 ? 
                  <TrendUp size={24} className="text-profit" /> : 
                  <TrendDown size={24} className="text-destructive" />
                }
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Win Rate</p>
                <p className="text-2xl font-bold">{formatPercentage(winRate)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {successfulTrades.length} wins, {failedTrades.length} losses
                </p>
              </div>
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Target size={24} className="text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Profit/Trade</p>
                <p className={`text-2xl font-bold ${avgProfitPerTrade >= 0 ? 'profit' : 'loss'}`}>
                  {formatCurrency(avgProfitPerTrade)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Fees: {formatCurrency(avgFeesPerTrade)}
                </p>
              </div>
              <div className="h-12 w-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <BarChart size={24} className="text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Profit Factor</p>
                <p className="text-2xl font-bold">
                  {profitFactor === Infinity ? '∞' : profitFactor.toFixed(2)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Total profit / Total loss
                </p>
              </div>
              <div className="h-12 w-12 bg-warning/10 rounded-lg flex items-center justify-center">
                <Activity size={24} className="text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Advanced Charts</TabsTrigger>
          <TabsTrigger value="portfolio">Portfolio Tracker</TabsTrigger>
          <TabsTrigger value="market">Market Analysis</TabsTrigger>
          <TabsTrigger value="risk-mgmt">Risk Management</TabsTrigger>
          <TabsTrigger value="strategies">Strategy Performance</TabsTrigger>
          <TabsTrigger value="trades">Trade History</TabsTrigger>
          <TabsTrigger value="risks">Risk Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Performance Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart size={20} />
                  Performance Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-profit/10 rounded-lg">
                    <p className="text-2xl font-bold text-profit">{formatCurrency(totalProfit)}</p>
                    <p className="text-sm text-muted-foreground">Total Profits</p>
                  </div>
                  <div className="text-center p-4 bg-destructive/10 rounded-lg">
                    <p className="text-2xl font-bold text-destructive">{formatCurrency(totalLoss)}</p>
                    <p className="text-sm text-muted-foreground">Total Losses</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Trades</span>
                    <span className="font-semibold">{state.trades.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Fees Paid</span>
                    <span className="font-semibold">{formatCurrency(totalFees)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Recent Performance</span>
                    <span className={`font-semibold ${recentPerformance >= 0 ? 'profit' : 'loss'}`}>
                      {formatCurrency(recentPerformance)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Market Data */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity size={20} />
                  Market Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {state.marketData.map((market) => (
                  <div key={market.symbol} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div>
                      <p className="font-medium">{market.symbol}</p>
                      <p className="text-sm text-muted-foreground">
                        Vol: {formatCurrency(market.volume24h)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{formatCurrency(market.price)}</p>
                      <p className={`text-sm ${market.change24h >= 0 ? 'profit' : 'loss'}`}>
                        {market.change24h >= 0 ? '+' : ''}{formatPercentage(market.change24h)}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <AdvancedAnalyticsDashboard />
        </TabsContent>

        <TabsContent value="portfolio" className="space-y-6">
          <PortfolioPerformanceTracker />
        </TabsContent>

        <TabsContent value="market" className="space-y-6">
          <MarketAnalysisDashboard />
        </TabsContent>

        <TabsContent value="risk-mgmt" className="space-y-6">
          <RiskManagementSystem />
        </TabsContent>

        <TabsContent value="strategies" className="space-y-6">
          <div className="grid gap-4">
            {Object.entries(strategyStats).length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <PieChart size={48} className="mx-auto mb-4 text-muted-foreground opacity-50" />
                  <h4 className="font-semibold mb-2">No strategy data yet</h4>
                  <p className="text-muted-foreground">Execute some trades to see strategy performance breakdown</p>
                </CardContent>
              </Card>
            ) : (
              Object.entries(strategyStats).map(([strategy, stats]) => (
                <Card key={strategy}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold capitalize mb-2">
                          {strategy.replace('-', ' ')} Strategy
                        </h4>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Trades</p>
                            <p className="font-medium">{stats.count}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Total P&L</p>
                            <p className={`font-medium ${stats.profit >= 0 ? 'profit' : 'loss'}`}>
                              {formatCurrency(stats.profit)}
                            </p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Avg P&L</p>
                            <p className={`font-medium ${stats.profit >= 0 ? 'profit' : 'loss'}`}>
                              {formatCurrency(stats.profit / stats.count)}
                            </p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Total Fees</p>
                            <p className="font-medium">{formatCurrency(stats.fees)}</p>
                          </div>
                        </div>
                      </div>
                      
                      <Badge className={stats.profit >= 0 ? 'bg-profit text-profit-foreground' : 'bg-destructive text-destructive-foreground'}>
                        {stats.profit >= 0 ? 'Profitable' : 'Loss'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="trades" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Complete Trade History</CardTitle>
            </CardHeader>
            <CardContent>
              {state.trades.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Activity size={48} className="mx-auto mb-4 opacity-50" />
                  <p>No trades executed yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {state.trades.map((trade) => (
                    <div key={trade.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <h5 className="font-medium">{trade.type.replace('-', ' ').toUpperCase()}</h5>
                          <Badge variant="outline">{trade.tokens.join('/')}</Badge>
                          <Badge className={trade.profit >= 0 ? 'bg-profit text-profit-foreground' : 'bg-destructive text-destructive-foreground'}>
                            {trade.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {new Date(trade.timestamp).toLocaleString()} • Amount: {formatCurrency(trade.amount)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${trade.profit >= 0 ? 'profit' : 'loss'}`}>
                          {formatCurrency(trade.profit)}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Fees: {formatCurrency(trade.fees)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risks">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Risk Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{formatPercentage((totalFees / (state.balance + Math.abs(state.totalPnL))) * 100)}</p>
                    <p className="text-sm text-muted-foreground">Fee Ratio</p>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{state.trades.length > 0 ? formatCurrency(Math.max(...state.trades.map(t => Math.abs(t.profit)))) : formatCurrency(0)}</p>
                    <p className="text-sm text-muted-foreground">Max Single Loss</p>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{formatPercentage(Math.abs(state.totalPnL) / state.balance * 100)}</p>
                    <p className="text-sm text-muted-foreground">Drawdown</p>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h4 className="font-semibold mb-3">Risk Assessment</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Portfolio Risk Level</span>
                      <Badge className={state.totalPnL >= 0 ? 'bg-profit text-profit-foreground' : 'bg-warning text-warning-foreground'}>
                        {state.totalPnL >= 0 ? 'Low' : 'Medium'}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Diversification</span>
                      <Badge className={Object.keys(strategyStats).length > 1 ? 'bg-profit text-profit-foreground' : 'bg-warning text-warning-foreground'}>
                        {Object.keys(strategyStats).length > 1 ? 'Good' : 'Limited'}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Trade Frequency</span>
                      <Badge className={state.trades.length > 10 ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                        {state.trades.length > 10 ? 'Active' : 'Low'}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}