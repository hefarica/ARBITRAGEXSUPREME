import { useState, useEffect, useMemo } from 'react'
import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from 'recharts'
import { 
  TrendUp, 
  TrendDown, 
  Activity, 
  Lightning,
  Eye,
  Target,
  Timer,
  WarningCircle,
  CheckCircle,
  Clock,
  CurrencyDollar,
  ChartBar3
} from '@phosphor-icons/react'

interface MarketOpportunity {
  id: string
  type: 'arbitrage' | 'triangular' | 'flash-loan'
  pair: string
  expectedProfit: number
  profitMargin: number
  riskLevel: 'Low' | 'Medium' | 'High'
  timeToExpiry: number
  liquidity: number
  slippage: number
  gasEstimate: number
  confidence: number
  exchanges: string[]
}

interface MarketTrend {
  symbol: string
  price: number
  change24h: number
  volume24h: number
  trend: 'bullish' | 'bearish' | 'neutral'
  momentum: number
  support: number
  resistance: number
  volatility: number
}

interface ArbitrageMetrics {
  totalOpportunities: number
  avgProfitMargin: number
  successRate: number
  timeToExecution: number
  competitionIndex: number
  marketEfficiency: number
}

export function MarketAnalysisDashboard() {
  const { state } = useSimulation()
  const [isScanning, setIsScanning] = useState(false)
  const [lastScanTime, setLastScanTime] = useState<Date>(new Date())
  const [selectedOpportunity, setSelectedOpportunity] = useState<string | null>(null)

  // Simulated real-time opportunities
  const [opportunities, setOpportunities] = useState<MarketOpportunity[]>([])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value.toFixed(2)}%`
  }

  // Simulate market opportunities discovery
  useEffect(() => {
    const generateOpportunities = () => {
      const pairs = ['ETH/USDC', 'BTC/USDT', 'UNI/ETH', 'AAVE/USDC', 'LINK/ETH']
      const exchanges = ['Uniswap', 'SushiSwap', 'Balancer', 'Curve', '1inch']
      const types: MarketOpportunity['type'][] = ['arbitrage', 'triangular', 'flash-loan']
      
      const newOpportunities: MarketOpportunity[] = []
      
      // Generate 3-8 opportunities
      const count = 3 + Math.floor(Math.random() * 6)
      
      for (let i = 0; i < count; i++) {
        const type = types[Math.floor(Math.random() * types.length)]
        const pair = pairs[Math.floor(Math.random() * pairs.length)]
        const profitMargin = 0.1 + Math.random() * 2.5 // 0.1% to 2.6%
        const expectedProfit = 50 + Math.random() * 500 // $50 to $550
        
        newOpportunities.push({
          id: `opp-${Date.now()}-${i}`,
          type,
          pair,
          expectedProfit,
          profitMargin,
          riskLevel: profitMargin > 1.5 ? 'High' : profitMargin > 0.8 ? 'Medium' : 'Low',
          timeToExpiry: 30 + Math.random() * 300, // 30-330 seconds
          liquidity: 10000 + Math.random() * 90000, // $10k-$100k
          slippage: 0.1 + Math.random() * 1.4, // 0.1%-1.5%
          gasEstimate: 20 + Math.random() * 80, // $20-$100
          confidence: 65 + Math.random() * 30, // 65%-95%
          exchanges: exchanges.slice(0, 2 + Math.floor(Math.random() * 2))
        })
      }
      
      setOpportunities(newOpportunities)
      setLastScanTime(new Date())
    }

    // Initial generation
    generateOpportunities()

    // Update every 15-30 seconds
    const interval = setInterval(generateOpportunities, 15000 + Math.random() * 15000)
    return () => clearInterval(interval)
  }, [])

  // Market trends simulation
  const marketTrends = useMemo((): MarketTrend[] => {
    return state.marketData.map(market => {
      const momentum = Math.random() * 2 - 1 // -1 to 1
      const volatility = 0.5 + Math.random() * 3 // 0.5% to 3.5%
      
      return {
        symbol: market.symbol,
        price: market.price,
        change24h: market.change24h,
        volume24h: market.volume24h,
        trend: market.change24h > 1 ? 'bullish' : market.change24h < -1 ? 'bearish' : 'neutral',
        momentum,
        support: market.price * (0.95 + Math.random() * 0.03),
        resistance: market.price * (1.02 + Math.random() * 0.03),
        volatility
      }
    })
  }, [state.marketData])

  // Arbitrage metrics
  const arbitrageMetrics = useMemo((): ArbitrageMetrics => {
    const totalOpportunities = opportunities.length
    const avgProfitMargin = opportunities.length > 0 ? 
      opportunities.reduce((sum, opp) => sum + opp.profitMargin, 0) / opportunities.length : 0
    
    // Simulate metrics based on market conditions
    const successRate = 70 + Math.random() * 25 // 70%-95%
    const timeToExecution = 5 + Math.random() * 10 // 5-15 seconds
    const competitionIndex = Math.random() * 100 // 0-100%
    const marketEfficiency = 85 + Math.random() * 10 // 85%-95%
    
    return {
      totalOpportunities,
      avgProfitMargin,
      successRate,
      timeToExecution,
      competitionIndex,
      marketEfficiency
    }
  }, [opportunities])

  const handleScanMarkets = () => {
    setIsScanning(true)
    setTimeout(() => setIsScanning(false), 2000)
  }

  const handleExecuteOpportunity = (opportunityId: string) => {
    // Simulate execution
    const opportunity = opportunities.find(opp => opp.id === opportunityId)
    if (opportunity) {
      // Remove the opportunity from the list
      setOpportunities(prev => prev.filter(opp => opp.id !== opportunityId))
      // In a real app, this would trigger the actual trade execution
    }
  }

  // Price chart data simulation
  const priceChartData = useMemo(() => {
    const data = []
    const now = Date.now()
    for (let i = 24; i >= 0; i--) {
      const basePrice = 2000 + Math.sin(i / 4) * 100
      data.push({
        time: now - (i * 60 * 60 * 1000), // 24 hours ago to now
        price: basePrice + (Math.random() - 0.5) * 50,
        volume: 1000000 + Math.random() * 2000000,
        opportunities: Math.floor(Math.random() * 15)
      })
    }
    return data
  }, [])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Market Analysis & Opportunities</h2>
          <p className="text-muted-foreground">Real-time arbitrage scanning and market insights</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button 
            onClick={handleScanMarkets}
            disabled={isScanning}
            className="gap-2"
            variant={isScanning ? "outline" : "default"}
          >
            <Eye size={16} className={isScanning ? 'animate-pulse' : ''} />
            {isScanning ? 'Scanning...' : 'Scan Markets'}
          </Button>
          
          <div className="text-sm text-muted-foreground">
            Last scan: {lastScanTime.toLocaleTimeString()}
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Opportunities</p>
                <p className="text-2xl font-bold">{arbitrageMetrics.totalOpportunities}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Avg: {formatPercentage(arbitrageMetrics.avgProfitMargin)} profit
                </p>
              </div>
              <div className="h-12 w-12 bg-profit/10 rounded-lg flex items-center justify-center">
                <Target size={24} className="text-profit" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Success Rate</p>
                <p className="text-2xl font-bold">{formatPercentage(arbitrageMetrics.successRate)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Exec time: {arbitrageMetrics.timeToExecution.toFixed(1)}s
                </p>
              </div>
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <CheckCircle size={24} className="text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Market Efficiency</p>
                <p className="text-2xl font-bold">{formatPercentage(arbitrageMetrics.marketEfficiency)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Competition: {formatPercentage(arbitrageMetrics.competitionIndex)}
                </p>
              </div>
              <div className="h-12 w-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <Activity size={24} className="text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Market Status</p>
                <p className="text-2xl font-bold">
                  <Badge className="bg-profit text-profit-foreground">
                    Active
                  </Badge>
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  High volatility
                </p>
              </div>
              <div className="h-12 w-12 bg-warning/10 rounded-lg flex items-center justify-center">
                <Lightning size={24} className="text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="opportunities" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
          <TabsTrigger value="trends">Market Trends</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="opportunities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Live Arbitrage Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              {opportunities.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Target size={48} className="mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium">No opportunities detected</p>
                  <p className="text-sm">Markets are currently efficient</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {opportunities.map((opportunity) => (
                    <div 
                      key={opportunity.id} 
                      className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border hover:bg-muted/70 transition-colors cursor-pointer"
                      onClick={() => setSelectedOpportunity(
                        selectedOpportunity === opportunity.id ? null : opportunity.id
                      )}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h5 className="font-medium">{opportunity.pair}</h5>
                          <Badge variant="outline" className="capitalize">
                            {opportunity.type.replace('-', ' ')}
                          </Badge>
                          <Badge className={
                            opportunity.riskLevel === 'Low' ? 'bg-profit text-profit-foreground' :
                            opportunity.riskLevel === 'Medium' ? 'bg-warning text-warning-foreground' :
                            'bg-destructive text-destructive-foreground'
                          }>
                            {opportunity.riskLevel} Risk
                          </Badge>
                          <Badge variant="outline">
                            {formatPercentage(opportunity.confidence)} confidence
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Expected Profit</p>
                            <p className="font-medium profit">{formatCurrency(opportunity.expectedProfit)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Margin</p>
                            <p className="font-medium">{formatPercentage(opportunity.profitMargin)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Liquidity</p>
                            <p className="font-medium">{formatCurrency(opportunity.liquidity)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Time Left</p>
                            <p className="font-medium">{Math.floor(opportunity.timeToExpiry)}s</p>
                          </div>
                        </div>

                        {selectedOpportunity === opportunity.id && (
                          <div className="mt-4 pt-4 border-t space-y-3">
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                              <div>
                                <p className="text-muted-foreground">Slippage</p>
                                <p className="font-medium">{formatPercentage(opportunity.slippage)}</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Gas Estimate</p>
                                <p className="font-medium">{formatCurrency(opportunity.gasEstimate)}</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Exchanges</p>
                                <p className="font-medium">{opportunity.exchanges.join(', ')}</p>
                              </div>
                            </div>
                            
                            <div className="flex gap-2">
                              <Button 
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  handleExecuteOpportunity(opportunity.id)
                                }}
                                className="gap-2"
                              >
                                <Lightning size={16} />
                                Execute Trade
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={(e) => e.stopPropagation()}
                              >
                                Analyze
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div className="text-right ml-4">
                        <p className="text-lg font-bold profit">
                          +{formatPercentage(opportunity.profitMargin)}
                        </p>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Timer size={12} />
                          {Math.floor(opportunity.timeToExpiry / 60)}:{(opportunity.timeToExpiry % 60).toFixed(0).padStart(2, '0')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Market Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {marketTrends.map((trend) => (
                    <div key={trend.symbol} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <p className="font-medium">{trend.symbol}</p>
                        <div className="flex items-center gap-2 text-sm">
                          <Badge variant="outline" className={
                            trend.trend === 'bullish' ? 'border-profit text-profit' :
                            trend.trend === 'bearish' ? 'border-destructive text-destructive' :
                            'border-muted-foreground text-muted-foreground'
                          }>
                            {trend.trend}
                          </Badge>
                          <span className="text-muted-foreground">Vol: {formatPercentage(trend.volatility)}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{formatCurrency(trend.price)}</p>
                        <p className={`text-sm ${trend.change24h >= 0 ? 'profit' : 'loss'}`}>
                          {trend.change24h >= 0 ? '+' : ''}{formatPercentage(trend.change24h)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Opportunity Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={priceChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                      <XAxis 
                        dataKey="time"
                        tickFormatter={(value) => new Date(value).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        stroke="hsl(var(--muted-foreground))"
                      />
                      <YAxis stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        labelFormatter={(value) => new Date(value).toLocaleString()}
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: 'var(--radius)'
                        }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="opportunities" 
                        stroke="hsl(var(--primary))" 
                        fill="hsl(var(--primary))" 
                        fillOpacity={0.2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Profit Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={opportunities.map(opp => ({
                      type: opp.type,
                      profit: opp.expectedProfit,
                      margin: opp.profitMargin
                    }))}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                      <XAxis dataKey="type" stroke="hsl(var(--muted-foreground))" />
                      <YAxis stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: 'var(--radius)'
                        }}
                      />
                      <Bar dataKey="profit" fill="hsl(var(--primary))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Market Efficiency Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Overall Efficiency</span>
                    <span className="font-semibold">{formatPercentage(arbitrageMetrics.marketEfficiency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Competition Level</span>
                    <span className="font-semibold">{formatPercentage(arbitrageMetrics.competitionIndex)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Avg Execution Time</span>
                    <span className="font-semibold">{arbitrageMetrics.timeToExecution.toFixed(1)}s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Success Rate</span>
                    <span className="font-semibold profit">{formatPercentage(arbitrageMetrics.successRate)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Market Alerts & Notifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-4 bg-profit/10 rounded-lg border border-profit/20">
                <div className="flex items-start gap-3">
                  <CheckCircle size={20} className="text-profit mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-profit">High-Profit Opportunity Detected</p>
                    <p className="text-sm text-muted-foreground">
                      ETH/USDC arbitrage opportunity with 2.3% margin detected on Uniswap vs SushiSwap
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">2 minutes ago</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-warning/10 rounded-lg border border-warning/20">
                <div className="flex items-start gap-3">
                  <WarningCircle size={20} className="text-warning mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-warning">High Gas Prices Alert</p>
                    <p className="text-sm text-muted-foreground">
                      Current gas prices may impact arbitrage profitability. Consider waiting for lower fees.
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">5 minutes ago</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-muted/50 rounded-lg border">
                <div className="flex items-start gap-3">
                  <Clock size={20} className="text-muted-foreground mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Market Analysis Complete</p>
                    <p className="text-sm text-muted-foreground">
                      Scanned 15 DEXs and found {opportunities.length} active opportunities
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">Just now</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}