import React, { useState, useEffect, useCallback } from 'react';
import { apiService } from '../../services/ApiService';

interface SystemConfig {
  // Configuración de arbitraje
  arbitrage: {
    minProfitThreshold: number;
    maxSlippage: number;
    gasLimitBuffer: number;
    executionTimeout: number;
    maxConcurrentExecutions: number;
    autoExecution: boolean;
    profitSharing: number;
  };
  
  // Configuración de MEV
  mev: {
    flashbotsEnabled: boolean;
    stealthMode: boolean;
    decoyTransactions: boolean;
    temporalConfusion: boolean;
    gasPriceNoise: number;
    nonceJitter: number;
  };
  
  // Configuración de blockchains
  blockchains: {
    [chainId: number]: {
      enabled: boolean;
      rpcUrl: string;
      wsUrl: string;
      gasMultiplier: number;
      maxPriorityFee: number;
      blockConfirmations: number;
    };
  };
  
  // Configuración de estrategias
  strategies: {
    [strategyId: string]: {
      enabled: boolean;
      parameters: Record<string, any>;
      riskLevel: 'low' | 'medium' | 'high';
      maxInvestment: number;
      cooldownPeriod: number;
    };
  };
  
  // Configuración de DEXs
  dexes: {
    [dexId: string]: {
      enabled: boolean;
      chainId: number;
      factoryAddress: string;
      routerAddress: string;
      maxSlippage: number;
      gasOptimization: boolean;
    };
  };
  
  // Configuración de monitoreo
  monitoring: {
    logLevel: 'debug' | 'info' | 'warn' | 'error';
    metricsInterval: number;
    alertThresholds: {
      profitDrop: number;
      errorRate: number;
      latencyIncrease: number;
      gasPriceSpike: number;
    };
    notifications: {
      email: boolean;
      telegram: boolean;
      discord: boolean;
      webhook: string;
    };
  };
  
  // Configuración de seguridad
  security: {
    privateKeyEncryption: boolean;
    multiSigEnabled: boolean;
    withdrawalDelay: number;
    maxDailyWithdrawal: number;
    ipWhitelist: string[];
    rateLimiting: {
      enabled: boolean;
      maxRequestsPerMinute: number;
      maxRequestsPerHour: number;
    };
  };
}

export const AdvancedConfiguration: React.FC = () => {
  const [config, setConfig] = useState<SystemConfig>({
    arbitrage: {
      minProfitThreshold: 0.5,
      maxSlippage: 2.0,
      gasLimitBuffer: 1.2,
      executionTimeout: 30000,
      maxConcurrentExecutions: 5,
      autoExecution: false,
      profitSharing: 80
    },
    mev: {
      flashbotsEnabled: true,
      stealthMode: true,
      decoyTransactions: true,
      temporalConfusion: true,
      gasPriceNoise: 0.05,
      nonceJitter: 3
    },
    blockchains: {
      1: { enabled: true, rpcUrl: '', wsUrl: '', gasMultiplier: 1.0, maxPriorityFee: 2, blockConfirmations: 1 },
      56: { enabled: true, rpcUrl: '', wsUrl: '', gasMultiplier: 1.0, maxPriorityFee: 1, blockConfirmations: 1 },
      137: { enabled: true, rpcUrl: '', wsUrl: '', gasMultiplier: 1.0, maxPriorityFee: 30, blockConfirmations: 1 },
      43114: { enabled: true, rpcUrl: '', wsUrl: '', gasMultiplier: 1.0, maxPriorityFee: 25, blockConfirmations: 1 },
      250: { enabled: true, rpcUrl: '', wsUrl: '', gasMultiplier: 1.0, maxPriorityFee: 1, blockConfirmations: 1 },
      42161: { enabled: true, rpcUrl: '', wsUrl: '', gasMultiplier: 1.0, maxPriorityFee: 0.1, blockConfirmations: 1 },
      10: { enabled: true, rpcUrl: '', wsUrl: '', gasMultiplier: 1.0, maxPriorityFee: 0.001, blockConfirmations: 1 },
      8453: { enabled: true, rpcUrl: '', wsUrl: '', gasMultiplier: 1.0, maxPriorityFee: 0.001, blockConfirmations: 1 }
    },
    strategies: {},
    dexes: {},
    monitoring: {
      logLevel: 'info',
      metricsInterval: 5000,
      alertThresholds: {
        profitDrop: 20,
        errorRate: 5,
        latencyIncrease: 50,
        gasPriceSpike: 200
      },
      notifications: {
        email: false,
        telegram: false,
        discord: false,
        webhook: ''
      }
    },
    security: {
      privateKeyEncryption: true,
      multiSigEnabled: false,
      withdrawalDelay: 3600,
      maxDailyWithdrawal: 10000,
      ipWhitelist: [],
      rateLimiting: {
        enabled: true,
        maxRequestsPerMinute: 100,
        maxRequestsPerHour: 1000
      }
    }
  });

  const [activeTab, setActiveTab] = useState('arbitrage');
  const [isLoading, setIsLoading] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');

  // Cargar configuración del sistema
  const loadSystemConfig = useCallback(async () => {
    setIsLoading(true);
    try {
      const systemConfig = await apiService.getSystemConfig();
      if (systemConfig) {
        setConfig(prev => ({ ...prev, ...systemConfig }));
      }
    } catch (error) {
      console.error('❌ Error cargando configuración:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Guardar configuración del sistema
  const saveSystemConfig = useCallback(async () => {
    setSaveStatus('saving');
    try {
      await apiService.updateSystemConfig(config);
      setSaveStatus('success');
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (error) {
      console.error('❌ Error guardando configuración:', error);
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  }, [config]);

  // Cargar configuración inicial
  useEffect(() => {
    loadSystemConfig();
  }, [loadSystemConfig]);

  // Actualizar configuración
  const updateConfig = useCallback((section: keyof SystemConfig, key: string, value: any) => {
    setConfig(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value
      }
    }));
  }, []);

  // Actualizar configuración de blockchain
  const updateBlockchainConfig = useCallback((chainId: number, key: string, value: any) => {
    setConfig(prev => ({
      ...prev,
      blockchains: {
        ...prev.blockchains,
        [chainId]: {
          ...prev.blockchains[chainId],
          [key]: value
        }
      }
    }));
  }, []);

  // Renderizar configuración de arbitraje
  const renderArbitrageConfig = () => (
    <div className="config-section">
      <h3>⚡ Configuración de Arbitraje</h3>
      <div className="config-grid">
        <div className="config-item">
          <label>Umbral Mínimo de Ganancia (%)</label>
          <input
            type="number"
            step="0.1"
            value={config.arbitrage.minProfitThreshold}
            onChange={(e) => updateConfig('arbitrage', 'minProfitThreshold', parseFloat(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Slippage Máximo (%)</label>
          <input
            type="number"
            step="0.1"
            value={config.arbitrage.maxSlippage}
            onChange={(e) => updateConfig('arbitrage', 'maxSlippage', parseFloat(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Buffer de Gas Limit</label>
          <input
            type="number"
            step="0.1"
            value={config.arbitrage.gasLimitBuffer}
            onChange={(e) => updateConfig('arbitrage', 'gasLimitBuffer', parseFloat(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Timeout de Ejecución (ms)</label>
          <input
            type="number"
            value={config.arbitrage.executionTimeout}
            onChange={(e) => updateConfig('arbitrage', 'executionTimeout', parseInt(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Ejecuciones Concurrentes Máx</label>
          <input
            type="number"
            value={config.arbitrage.maxConcurrentExecutions}
            onChange={(e) => updateConfig('arbitrage', 'maxConcurrentExecutions', parseInt(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Ejecución Automática</label>
          <input
            type="checkbox"
            checked={config.arbitrage.autoExecution}
            onChange={(e) => updateConfig('arbitrage', 'autoExecution', e.target.checked)}
          />
        </div>
        <div className="config-item">
          <label>Compartir Ganancias (%)</label>
          <input
            type="number"
            step="1"
            value={config.arbitrage.profitSharing}
            onChange={(e) => updateConfig('arbitrage', 'profitSharing', parseInt(e.target.value))}
          />
        </div>
      </div>
    </div>
  );

  // Renderizar configuración de MEV
  const renderMEVConfig = () => (
    <div className="config-section">
      <h3>🛡️ Configuración de Protección MEV</h3>
      <div className="config-grid">
        <div className="config-item">
          <label>Flashbots Habilitado</label>
          <input
            type="checkbox"
            checked={config.mev.flashbotsEnabled}
            onChange={(e) => updateConfig('mev', 'flashbotsEnabled', e.target.checked)}
          />
        </div>
        <div className="config-item">
          <label>Modo Stealth</label>
          <input
            type="checkbox"
            checked={config.mev.stealthMode}
            onChange={(e) => updateConfig('mev', 'stealthMode', e.target.checked)}
          />
        </div>
        <div className="config-item">
          <label>Transacciones Señuelo</label>
          <input
            type="checkbox"
            checked={config.mev.decoyTransactions}
            onChange={(e) => updateConfig('mev', 'decoyTransactions', e.target.checked)}
          />
        </div>
        <div className="config-item">
          <label>Confusión Temporal</label>
          <input
            type="checkbox"
            checked={config.mev.temporalConfusion}
            onChange={(e) => updateConfig('mev', 'temporalConfusion', e.target.checked)}
          />
        </div>
        <div className="config-item">
          <label>Ruido de Precio de Gas (%)</label>
          <input
            type="number"
            step="0.01"
            value={config.mev.gasPriceNoise}
            onChange={(e) => updateConfig('mev', 'gasPriceNoise', parseFloat(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Jitter de Nonce</label>
          <input
            type="number"
            value={config.mev.nonceJitter}
            onChange={(e) => updateConfig('mev', 'nonceJitter', parseInt(e.target.value))}
          />
        </div>
      </div>
    </div>
  );

  // Renderizar configuración de blockchains
  const renderBlockchainConfig = () => (
    <div className="config-section">
      <h3>⛓️ Configuración de Blockchains</h3>
      <div className="blockchain-grid">
        {Object.entries(config.blockchains).map(([chainId, chainConfig]) => (
          <div key={chainId} className="blockchain-card">
            <div className="blockchain-header">
              <h4>Chain ID: {chainId}</h4>
              <input
                type="checkbox"
                checked={chainConfig.enabled}
                onChange={(e) => updateBlockchainConfig(parseInt(chainId), 'enabled', e.target.checked)}
              />
            </div>
            <div className="blockchain-config">
              <div className="config-item">
                <label>RPC URL</label>
                <input
                  type="text"
                  value={chainConfig.rpcUrl}
                  onChange={(e) => updateBlockchainConfig(parseInt(chainId), 'rpcUrl', e.target.value)}
                  placeholder="https://..."
                />
              </div>
              <div className="config-item">
                <label>WebSocket URL</label>
                <input
                  type="text"
                  value={chainConfig.wsUrl}
                  onChange={(e) => updateBlockchainConfig(parseInt(chainId), 'wsUrl', e.target.value)}
                  placeholder="wss://..."
                />
              </div>
              <div className="config-item">
                <label>Multiplicador de Gas</label>
                <input
                  type="number"
                  step="0.1"
                  value={chainConfig.gasMultiplier}
                  onChange={(e) => updateBlockchainConfig(parseInt(chainId), 'gasMultiplier', parseFloat(e.target.value))}
                />
              </div>
              <div className="config-item">
                <label>Fee de Prioridad Máx (Gwei)</label>
                <input
                  type="number"
                  step="0.1"
                  value={chainConfig.maxPriorityFee}
                  onChange={(e) => updateBlockchainConfig(parseInt(chainId), 'maxPriorityFee', parseFloat(e.target.value))}
                />
              </div>
              <div className="config-item">
                <label>Confirmaciones de Bloque</label>
                <input
                  type="number"
                  value={chainConfig.blockConfirmations}
                  onChange={(e) => updateBlockchainConfig(parseInt(chainId), 'blockConfirmations', parseInt(e.target.value))}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // Renderizar configuración de monitoreo
  const renderMonitoringConfig = () => (
    <div className="config-section">
      <h3>📊 Configuración de Monitoreo</h3>
      <div className="config-grid">
        <div className="config-item">
          <label>Nivel de Log</label>
          <select
            value={config.monitoring.logLevel}
            onChange={(e) => updateConfig('monitoring', 'logLevel', e.target.value)}
          >
            <option value="debug">Debug</option>
            <option value="info">Info</option>
            <option value="warn">Warning</option>
            <option value="error">Error</option>
          </select>
        </div>
        <div className="config-item">
          <label>Intervalo de Métricas (ms)</label>
          <input
            type="number"
            value={config.monitoring.metricsInterval}
            onChange={(e) => updateConfig('monitoring', 'metricsInterval', parseInt(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Umbral de Caída de Ganancia (%)</label>
          <input
            type="number"
            value={config.monitoring.alertThresholds.profitDrop}
            onChange={(e) => updateConfig('monitoring', 'alertThresholds', {
              ...config.monitoring.alertThresholds,
              profitDrop: parseInt(e.target.value)
            })}
          />
        </div>
        <div className="config-item">
          <label>Umbral de Tasa de Error (%)</label>
          <input
            type="number"
            value={config.monitoring.alertThresholds.errorRate}
            onChange={(e) => updateConfig('monitoring', 'alertThresholds', {
              ...config.monitoring.alertThresholds,
              errorRate: parseInt(e.target.value)
            })}
          />
        </div>
      </div>
    </div>
  );

  // Renderizar configuración de seguridad
  const renderSecurityConfig = () => (
    <div className="config-section">
      <h3>🔒 Configuración de Seguridad</h3>
      <div className="config-grid">
        <div className="config-item">
          <label>Encriptación de Clave Privada</label>
          <input
            type="checkbox"
            checked={config.security.privateKeyEncryption}
            onChange={(e) => updateConfig('security', 'privateKeyEncryption', e.target.checked)}
          />
        </div>
        <div className="config-item">
          <label>Multi-Signature Habilitado</label>
          <input
            type="checkbox"
            checked={config.security.multiSigEnabled}
            onChange={(e) => updateConfig('security', 'multiSigEnabled', e.target.checked)}
          />
        </div>
        <div className="config-item">
          <label>Delay de Retiro (segundos)</label>
          <input
            type="number"
            value={config.security.withdrawalDelay}
            onChange={(e) => updateConfig('security', 'withdrawalDelay', parseInt(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Retiro Máximo Diario (USD)</label>
          <input
            type="number"
            value={config.security.maxDailyWithdrawal}
            onChange={(e) => updateConfig('security', 'maxDailyWithdrawal', parseInt(e.target.value))}
          />
        </div>
        <div className="config-item">
          <label>Rate Limiting Habilitado</label>
          <input
            type="checkbox"
            checked={config.security.rateLimiting.enabled}
            onChange={(e) => updateConfig('security', 'rateLimiting', {
              ...config.security.rateLimiting,
              enabled: e.target.checked
            })}
          />
        </div>
      </div>
    </div>
  );

  // Renderizar contenido activo
  const renderActiveTab = () => {
    switch (activeTab) {
      case 'arbitrage':
        return renderArbitrageConfig();
      case 'mev':
        return renderMEVConfig();
      case 'blockchains':
        return renderBlockchainConfig();
      case 'monitoring':
        return renderMonitoringConfig();
      case 'security':
        return renderSecurityConfig();
      default:
        return <div>Sección no encontrada</div>;
    }
  };

  return (
    <div className="advanced-configuration">
      <div className="config-header">
        <h2>⚙️ Configuración Avanzada del Sistema</h2>
        <div className="header-actions">
          <button
            className={`save-btn ${saveStatus}`}
            onClick={saveSystemConfig}
            disabled={saveStatus === 'saving'}
          >
            {saveStatus === 'saving' && '💾 Guardando...'}
            {saveStatus === 'success' && '✅ Guardado'}
            {saveStatus === 'error' && '❌ Error'}
            {saveStatus === 'idle' && '💾 Guardar Configuración'}
          </button>
          <button
            className="reset-btn"
            onClick={loadSystemConfig}
            disabled={isLoading}
          >
            {isLoading ? '🔄 Cargando...' : '🔄 Recargar'}
          </button>
        </div>
      </div>

      {/* Navegación de pestañas */}
      <div className="config-tabs">
        <button
          className={`tab-btn ${activeTab === 'arbitrage' ? 'active' : ''}`}
          onClick={() => setActiveTab('arbitrage')}
        >
          ⚡ Arbitraje
        </button>
        <button
          className={`tab-btn ${activeTab === 'mev' ? 'active' : ''}`}
          onClick={() => setActiveTab('mev')}
        >
          🛡️ MEV
        </button>
        <button
          className={`tab-btn ${activeTab === 'blockchains' ? 'active' : ''}`}
          onClick={() => setActiveTab('blockchains')}
        >
          ⛓️ Blockchains
        </button>
        <button
          className={`tab-btn ${activeTab === 'monitoring' ? 'active' : ''}`}
          onClick={() => setActiveTab('monitoring')}
        >
          📊 Monitoreo
        </button>
        <button
          className={`tab-btn ${activeTab === 'security' ? 'active' : ''}`}
          onClick={() => setActiveTab('security')}
        >
          🔒 Seguridad
        </button>
      </div>

      {/* Contenido de la pestaña activa */}
      <div className="config-content">
        {renderActiveTab()}
      </div>

      {/* Información del sistema */}
      <div className="system-info">
        <h3>ℹ️ Información del Sistema</h3>
        <div className="info-grid">
          <div className="info-item">
            <span>Versión:</span>
            <span>2025.1.0</span>
          </div>
          <div className="info-item">
            <span>Última Actualización:</span>
            <span>{new Date().toLocaleString()}</span>
          </div>
          <div className="info-item">
            <span>Estado:</span>
            <span className="status-active">🟢 Activo</span>
          </div>
        </div>
      </div>
    </div>
  );
};
