import { ServiceDefinition, ServiceInteraction } from './types'

// Comprehensive service definitions for ArbitrageX Pro 2025
export const serviceDefinitions: ServiceDefinition[] = [
  // HOSTING & CLOUD CATEGORY
  {
    id: 'vercel',
    label: 'Vercel Frontend',
    category: 'hosting',
    description: 'Serverless frontend hosting with global CDN',
    required: false,
    cost: 'freemium',
    difficulty: 'easy',
    fields: [
      {
        key: 'VERCEL_TOKEN',
        label: 'Vercel API Token',
        type: 'password',
        required: true,
        placeholder: 'vt_xxxxxxxxxxxxxxxx',
        description: 'Get from Vercel dashboard → Gear → Tokens',
        sensitive: true
      }
    ],
    interactions: {
      railway: {
        type: 'enhancement',
        level: 'warning',
        message: 'Works great with Railway backend hosting',
        recommendation: 'Use together for full-stack deployment'
      }
    }
  },
  {
    id: 'railway',
    label: 'Railway Backend',
    category: 'hosting',
    description: 'Container-based backend hosting with database support',
    required: false,
    cost: 'freemium',
    difficulty: 'easy',
    fields: [
      {
        key: 'RAILWAY_TOKEN',
        label: 'Railway API Token',
        type: 'password',
        required: true,
        placeholder: 'railway_xxxxxxxxxxxxxxxx',
        description: 'Get from Railway dashboard → Account Gear → Tokens',
        sensitive: true
      }
    ],
    interactions: {}
  },
  {
    id: 'aws_cloudfront',
    label: 'AWS CloudFront',
    category: 'hosting',
    description: 'Global content delivery network for ultra-low latency',
    required: false,
    cost: 'paid',
    difficulty: 'advanced',
    fields: [
      {
        key: 'AWS_ACCESS_KEY_ID',
        label: 'AWS Access Key ID',
        type: 'text',
        required: true,
        placeholder: 'AKIAIOSFODNN7EXAMPLE',
        sensitive: true
      },
      {
        key: 'AWS_SECRET_ACCESS_KEY',
        label: 'AWS Secret Access Key',
        type: 'password',
        required: true,
        placeholder: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
        sensitive: true
      },
      {
        key: 'AWS_REGION',
        label: 'AWS Region',
        type: 'select',
        required: true,
        options: [
          { value: 'us-east-1', label: 'US East (N. Virginia)' },
          { value: 'us-west-2', label: 'US West (Oregon)' },
          { value: 'eu-west-1', label: 'Europe (Ireland)' },
          { value: 'ap-southeast-1', label: 'Asia Pacific (Singapore)' }
        ]
      }
    ],
    interactions: {
      hft_engine: {
        type: 'enhancement',
        level: 'warning',
        message: 'Reduces latency for HFT operations when properly configured',
        recommendation: 'Use edge locations near major exchanges'
      }
    }
  },

  // BLOCKCHAIN & RPC CATEGORY
  {
    id: 'ethereum',
    label: 'Ethereum',
    category: 'blockchain',
    description: 'Ethereum mainnet/testnet connectivity',
    required: true,
    cost: 'freemium',
    difficulty: 'medium',
    fields: [
      {
        key: 'rpc_primary',
        label: 'Primary RPC URL',
        type: 'text',
        required: true,
        placeholder: 'https://eth-mainnet.g.alchemy.com/v2/YOUR_API_KEY',
        description: 'Primary Ethereum RPC endpoint'
      },
      {
        key: 'ws_url',
        label: 'WebSocket URL',
        type: 'text',
        required: true,
        placeholder: 'wss://eth-mainnet.g.alchemy.com/v2/YOUR_API_KEY',
        description: 'For real-time transaction monitoring'
      },
      {
        key: 'private_key',
        label: 'Private Key',
        type: 'password',
        required: true,
        placeholder: '0x1234567890abcdef...',
        description: 'Trading wallet private key (keep secure!)',
        sensitive: true
      },
      {
        key: 'chain_id',
        label: 'Chain ID',
        type: 'select',
        required: true,
        options: [
          { value: '1', label: '1 (Mainnet)' },
          { value: '5', label: '5 (Goerli Testnet)' },
          { value: '11155111', label: '11155111 (Sepolia Testnet)' }
        ]
      },
      {
        key: 'max_gas_price_gwei',
        label: 'Max Gas Price (Gwei)',
        type: 'number',
        required: false,
        placeholder: '100',
        validation: { min: 1, max: 1000 }
      }
    ],
    interactions: {
      flashbots: {
        type: 'enhancement',
        level: 'warning',
        message: 'Flashbots protection works best with Ethereum',
        recommendation: 'Enable Flashbots for MEV protection'
      }
    }
  },
  {
    id: 'polygon',
    label: 'Polygon',
    category: 'blockchain',
    description: 'Polygon PoS network for low-cost transactions',
    required: false,
    cost: 'freemium',
    difficulty: 'medium',
    fields: [
      {
        key: 'rpc_primary',
        label: 'Primary RPC URL',
        type: 'text',
        required: true,
        placeholder: 'https://polygon-mainnet.g.alchemy.com/v2/YOUR_API_KEY',
      },
      {
        key: 'ws_url',
        label: 'WebSocket URL',
        type: 'text',
        required: true,
        placeholder: 'wss://polygon-mainnet.g.alchemy.com/v2/YOUR_API_KEY',
      },
      {
        key: 'private_key',
        label: 'Private Key',
        type: 'password',
        required: true,
        placeholder: '0x1234567890abcdef...',
        sensitive: true
      },
      {
        key: 'chain_id',
        label: 'Chain ID',
        type: 'select',
        required: true,
        options: [
          { value: '137', label: '137 (Mainnet)' },
          { value: '80001', label: '80001 (Mumbai Testnet)' }
        ]
      }
    ],
    interactions: {}
  },
  {
    id: 'bsc',
    label: 'Binance Smart Chain',
    category: 'blockchain',
    description: 'BSC network for DeFi trading',
    required: false,
    cost: 'free',
    difficulty: 'medium',
    fields: [
      {
        key: 'rpc_primary',
        label: 'Primary RPC URL',
        type: 'text',
        required: true,
        placeholder: 'https://bsc-dataseed1.binance.org/',
      },
      {
        key: 'private_key',
        label: 'Private Key',
        type: 'password',
        required: true,
        placeholder: '0x1234567890abcdef...',
        sensitive: true
      },
      {
        key: 'chain_id',
        label: 'Chain ID',
        type: 'select',
        required: true,
        options: [
          { value: '56', label: '56 (Mainnet)' },
          { value: '97', label: '97 (Testnet)' }
        ]
      }
    ],
    interactions: {}
  },
  {
    id: 'arbitrum',
    label: 'Arbitrum One',
    category: 'blockchain',
    description: 'Arbitrum L2 for Ethereum scaling',
    required: false,
    cost: 'freemium',
    difficulty: 'medium',
    fields: [
      {
        key: 'rpc_primary',
        label: 'Primary RPC URL',
        type: 'text',
        required: true,
        placeholder: 'https://arb1.arbitrum.io/rpc',
      },
      {
        key: 'private_key',
        label: 'Private Key',
        type: 'password',
        required: true,
        placeholder: '0x1234567890abcdef...',
        sensitive: true
      },
      {
        key: 'chain_id',
        label: 'Chain ID',
        type: 'select',
        required: true,
        options: [
          { value: '42161', label: '42161 (Mainnet)' },
          { value: '421613', label: '421613 (Testnet)' }
        ]
      }
    ],
    interactions: {}
  },
  {
    id: 'optimism',
    label: 'Optimism',
    category: 'blockchain',
    description: 'Optimism L2 for Ethereum',
    required: false,
    cost: 'freemium',
    difficulty: 'medium',
    fields: [
      {
        key: 'rpc_primary',
        label: 'Primary RPC URL',
        type: 'text',
        required: true,
        placeholder: 'https://mainnet.optimism.io',
      },
      {
        key: 'private_key',
        label: 'Private Key',
        type: 'password',
        required: true,
        placeholder: '0x1234567890abcdef...',
        sensitive: true
      },
      {
        key: 'chain_id',
        label: 'Chain ID',
        type: 'select',
        required: true,
        options: [
          { value: '10', label: '10 (Mainnet)' },
          { value: '420', label: '420 (Testnet)' }
        ]
      }
    ],
    interactions: {}
  },
  {
    id: 'avalanche',
    label: 'Avalanche',
    category: 'blockchain',
    description: 'Avalanche C-Chain for DeFi',
    required: false,
    cost: 'free',
    difficulty: 'medium',
    fields: [
      {
        key: 'rpc_primary',
        label: 'Primary RPC URL',
        type: 'text',
        required: true,
        placeholder: 'https://api.avax.network/ext/bc/C/rpc',
      },
      {
        key: 'private_key',
        label: 'Private Key',
        type: 'password',
        required: true,
        placeholder: '0x1234567890abcdef...',
        sensitive: true
      },
      {
        key: 'chain_id',
        label: 'Chain ID',
        type: 'select',
        required: true,
        options: [
          { value: '43114', label: '43114 (Mainnet)' },
          { value: '43113', label: '43113 (Testnet)' }
        ]
      }
    ],
    interactions: {}
  },
  {
    id: 'solana',
    label: 'Solana',
    category: 'blockchain',
    description: 'Solana network for high-speed trading',
    required: false,
    cost: 'free',
    difficulty: 'advanced',
    fields: [
      {
        key: 'rpc_primary',
        label: 'Primary RPC URL',
        type: 'text',
        required: true,
        placeholder: 'https://api.mainnet-beta.solana.com',
      },
      {
        key: 'ws_url',
        label: 'WebSocket URL',
        type: 'text',
        required: false,
        placeholder: 'wss://api.mainnet-beta.solana.com',
      },
      {
        key: 'private_key',
        label: 'Private Key (Base58)',
        type: 'password',
        required: true,
        placeholder: 'Base58 encoded private key',
        sensitive: true
      },
      {
        key: 'commitment',
        label: 'Commitment Level',
        type: 'select',
        required: true,
        options: [
          { value: 'finalized', label: 'Finalized' },
          { value: 'confirmed', label: 'Confirmed' },
          { value: 'processed', label: 'Processed' }
        ]
      },
      {
        key: 'cluster',
        label: 'Cluster',
        type: 'select',
        required: true,
        options: [
          { value: 'mainnet-beta', label: 'Mainnet Beta' },
          { value: 'testnet', label: 'Testnet' },
          { value: 'devnet', label: 'Devnet' }
        ]
      }
    ],
    interactions: {}
  },

  // AI & LLM SERVICES CATEGORY
  {
    id: 'openai',
    label: 'OpenAI GPT-4 Turbo',
    category: 'ai',
    description: 'Most advanced AI for trading insights and automation',
    required: false,
    cost: 'paid',
    difficulty: 'easy',
    fields: [
      {
        key: 'api_key',
        label: 'OpenAI API Key',
        type: 'password',
        required: true,
        placeholder: 'sk-proj-xxxxxxxxxxxxxxxx',
        description: 'Get from OpenAI dashboard → API keys',
        sensitive: true
      },
      {
        key: 'model',
        label: 'Model',
        type: 'select',
        required: true,
        options: [
          { value: 'gpt-4-turbo', label: 'GPT-4 Turbo (Recommended)' },
          { value: 'gpt-4o', label: 'GPT-4o (Latest)' },
          { value: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo (Cost-effective)' }
        ]
      },
      {
        key: 'max_tokens',
        label: 'Max Tokens',
        type: 'number',
        required: false,
        placeholder: '4000',
        validation: { min: 100, max: 8000 }
      },
      {
        key: 'temperature',
        label: 'Temperature',
        type: 'number',
        required: false,
        placeholder: '0.7',
        validation: { min: 0, max: 2 }
      }
    ],
    interactions: {
      claude: {
        type: 'conflict',
        level: 'performance',
        message: 'Using multiple LLM providers may increase costs',
        recommendation: 'Choose one primary LLM provider'
      }
    }
  },
  {
    id: 'claude',
    label: 'Anthropic Claude 3.5 Sonnet',
    category: 'ai',
    description: 'Advanced AI with superior reasoning for complex trading strategies',
    required: false,
    cost: 'paid',
    difficulty: 'easy',
    fields: [
      {
        key: 'api_key',
        label: 'Anthropic API Key',
        type: 'password',
        required: true,
        placeholder: 'sk-ant-xxxxxxxxxxxxxxxx',
        description: 'Get from Anthropic Console → API Keys',
        sensitive: true
      },
      {
        key: 'model',
        label: 'Model',
        type: 'select',
        required: true,
        options: [
          { value: 'claude-3-5-sonnet-20241022', label: 'Claude 3.5 Sonnet (Latest)' },
          { value: 'claude-3-opus-20240229', label: 'Claude 3 Opus (Most Capable)' },
          { value: 'claude-3-haiku-20240307', label: 'Claude 3 Haiku (Fastest)' }
        ]
      },
      {
        key: 'max_tokens',
        label: 'Max Tokens',
        type: 'number',
        required: true,
        placeholder: '4096',
        validation: { min: 100, max: 8192 }
      }
    ],
    interactions: {}
  },
  {
    id: 'gemini',
    label: 'Google Gemini Pro',
    category: 'ai',
    description: 'Google\'s multimodal AI with strong analytical capabilities',
    required: false,
    cost: 'freemium',
    difficulty: 'easy',
    fields: [
      {
        key: 'api_key',
        label: 'Google AI API Key',
        type: 'password',
        required: true,
        placeholder: 'AIzaSyxxxxxxxxxxxxxxxx',
        description: 'Get from Google AI Studio',
        sensitive: true
      },
      {
        key: 'model',
        label: 'Model',
        type: 'select',
        required: true,
        options: [
          { value: 'gemini-pro', label: 'Gemini Pro' },
          { value: 'gemini-pro-vision', label: 'Gemini Pro Vision' }
        ]
      }
    ],
    interactions: {}
  },
  {
    id: 'ollama',
    label: 'Ollama Local',
    category: 'ai',
    description: 'Self-hosted AI models for privacy and cost control',
    required: false,
    cost: 'free',
    difficulty: 'advanced',
    fields: [
      {
        key: 'base_url',
        label: 'Ollama Base URL',
        type: 'text',
        required: true,
        placeholder: 'http://localhost:11434',
        description: 'Local Ollama server endpoint'
      },
      {
        key: 'model',
        label: 'Model',
        type: 'select',
        required: true,
        options: [
          { value: 'llama2', label: 'Llama 2 (7B/13B/70B)' },
          { value: 'codellama', label: 'Code Llama' },
          { value: 'mistral', label: 'Mistral 7B' },
          { value: 'mixtral', label: 'Mixtral 8x7B' }
        ]
      }
    ],
    interactions: {
      openai: {
        type: 'enhancement',
        level: 'warning',
        message: 'Use Ollama for sensitive data, OpenAI for complex reasoning',
        recommendation: 'Hybrid approach: Ollama for local, OpenAI for cloud'
      }
    }
  },
  {
    id: 'groq',
    label: 'Groq (Llama)',
    category: 'ai',
    description: 'Ultra-fast AI inference for real-time trading decisions',
    required: false,
    cost: 'freemium',
    difficulty: 'easy',
    fields: [
      {
        key: 'api_key',
        label: 'Groq API Key',
        type: 'password',
        required: true,
        placeholder: 'gsk_xxxxxxxxxxxxxxxx',
        description: 'Get from Groq Console',
        sensitive: true
      },
      {
        key: 'model',
        label: 'Model',
        type: 'select',
        required: true,
        options: [
          { value: 'llama2-70b-4096', label: 'Llama 2 70B' },
          { value: 'mixtral-8x7b-32768', label: 'Mixtral 8x7B' },
          { value: 'llama3-8b-8192', label: 'Llama 3 8B' }
        ]
      }
    ],
    interactions: {
      hft_engine: {
        type: 'enhancement',
        level: 'warning',
        message: 'Groq\'s speed makes it ideal for HFT AI decisions',
        recommendation: 'Use Groq for time-critical AI tasks'
      }
    }
  },

  // DATABASE SERVICES CATEGORY
  {
    id: 'mongodb',
    label: 'MongoDB Atlas',
    category: 'database',
    description: 'NoSQL database for flexible data storage',
    required: false,
    cost: 'freemium',
    difficulty: 'medium',
    fields: [
      {
        key: 'connection_string',
        label: 'MongoDB Connection String',
        type: 'password',
        required: true,
        placeholder: 'mongodb+srv://user:pass@cluster.mongodb.net/db',
        description: 'Full MongoDB Atlas connection string',
        sensitive: true
      },
      {
        key: 'database',
        label: 'Database Name',
        type: 'text',
        required: true,
        placeholder: 'arbitragex_pro'
      }
    ],
    interactions: {}
  },
  {
    id: 'supabase',
    label: 'Supabase PostgreSQL',
    category: 'database',
    description: 'Open-source Firebase alternative with real-time features',
    required: false,
    cost: 'freemium',
    difficulty: 'easy',
    fields: [
      {
        key: 'url',
        label: 'Supabase URL',
        type: 'text',
        required: true,
        placeholder: 'https://xyz.supabase.co'
      },
      {
        key: 'anon_key',
        label: 'Anon Key',
        type: 'password',
        required: true,
        placeholder: 'eyJhbGciOi...',
        sensitive: true
      },
      {
        key: 'service_key',
        label: 'Service Role Key',
        type: 'password',
        required: false,
        placeholder: 'eyJhbGciOi...',
        description: 'For server-side operations',
        sensitive: true
      }
    ],
    interactions: {}
  },
  {
    id: 'redis',
    label: 'Redis Cache',
    category: 'database',
    description: 'In-memory cache for high-speed data access',
    required: false,
    cost: 'freemium',
    difficulty: 'medium',
    fields: [
      {
        key: 'redis_url',
        label: 'Redis URL',
        type: 'password',
        required: true,
        placeholder: 'redis://username:password@host:port',
        sensitive: true
      },
      {
        key: 'max_connections',
        label: 'Max Connections',
        type: 'number',
        required: false,
        placeholder: '50',
        validation: { min: 1, max: 200 }
      }
    ],
    interactions: {
      hft_engine: {
        type: 'enhancement',
        level: 'warning',
        message: 'Redis cache significantly improves HFT performance',
        recommendation: 'Essential for sub-millisecond data access'
      }
    }
  },
  {
    id: 'upstash_redis',
    label: 'Upstash Redis',
    category: 'database',
    description: 'Serverless Redis with global distribution',
    required: false,
    cost: 'freemium',
    difficulty: 'easy',
    fields: [
      {
        key: 'redis_url',
        label: 'Upstash Redis URL',
        type: 'text',
        required: true,
        placeholder: 'https://us1-app-xxx.upstash.io'
      },
      {
        key: 'redis_token',
        label: 'Redis Token',
        type: 'password',
        required: true,
        placeholder: 'token-xxx',
        sensitive: true
      }
    ],
    interactions: {
      redis: {
        type: 'conflict',
        level: 'blocking',
        message: 'Cannot use both Redis providers simultaneously',
        recommendation: 'Choose either Upstash or traditional Redis'
      }
    }
  },

  // MEV PROTECTION & HFT CATEGORY
  {
    id: 'flashbots',
    label: 'Flashbots Protect',
    category: 'mev',
    description: 'MEV protection through private mempool (100% FREE)',
    required: false,
    cost: 'free',
    difficulty: 'medium',
    fields: [
      {
        key: 'flashbots_private_key',
        label: 'Reputation Private Key',
        type: 'password',
        required: true,
        placeholder: '0x1234567890abcdef...',
        description: 'Separate key for Flashbots reputation (not your trading key!)',
        sensitive: true
      },
      {
        key: 'flashbots_relay_url',
        label: 'Relay URL',
        type: 'text',
        required: false,
        placeholder: 'https://relay.flashbots.net',
        description: 'Default Flashbots relay endpoint'
      },
      {
        key: 'bundle_timeout_seconds',
        label: 'Bundle Timeout (seconds)',
        type: 'number',
        required: false,
        placeholder: '25',
        validation: { min: 10, max: 60 }
      }
    ],
    interactions: {
      ethereum: {
        type: 'dependency',
        level: 'warning',
        message: 'Flashbots only works with Ethereum mainnet',
        recommendation: 'Ensure Ethereum is configured for Flashbots'
      },
      hft_engine: {
        type: 'enhancement',
        level: 'warning',
        message: 'Flashbots protection enhances HFT security',
        recommendation: 'Essential for MEV-protected high-frequency trading'
      }
    }
  },
  {
    id: 'hummingbot',
    label: 'Hummingbot HFT',
    category: 'mev',
    description: 'Open-source HFT framework (100% FREE)',
    required: false,
    cost: 'free',
    difficulty: 'advanced',
    fields: [
      {
        key: 'hummingbot_config_path',
        label: 'Config Directory',
        type: 'text',
        required: true,
        placeholder: './hummingbot/conf',
        description: 'Path to Hummingbot configuration files'
      },
      {
        key: 'strategy_name',
        label: 'Default Strategy',
        type: 'select',
        required: true,
        options: [
          { value: 'arbitrage', label: 'Cross-Exchange Arbitrage' },
          { value: 'pure_market_making', label: 'Pure Market Making' },
          { value: 'liquidity_mining', label: 'Liquidity Mining' },
          { value: 'perpetual_market_making', label: 'Perpetual Market Making' }
        ]
      }
    ],
    interactions: {
      flashbots: {
        type: 'enhancement',
        level: 'warning',
        message: 'Combine with Flashbots for MEV-protected HFT',
        recommendation: 'Use both for maximum trading security'
      }
    }
  },
  {
    id: 'private_rpc',
    label: 'Private RPC (Self-hosted)',
    category: 'mev',
    description: 'Self-hosted blockchain node for maximum speed (100% FREE)',
    required: false,
    cost: 'free',
    difficulty: 'advanced',
    fields: [
      {
        key: 'rpc_endpoint',
        label: 'Private RPC Endpoint',
        type: 'text',
        required: true,
        placeholder: 'http://localhost:8545',
        description: 'Your self-hosted node endpoint'
      },
      {
        key: 'ws_endpoint',
        label: 'WebSocket Endpoint',
        type: 'text',
        required: false,
        placeholder: 'ws://localhost:8546',
        description: 'WebSocket endpoint for real-time data'
      },
      {
        key: 'cpu_affinity',
        label: 'CPU Affinity',
        type: 'text',
        required: false,
        placeholder: '0,1,2,3',
        description: 'CPU cores to bind for performance'
      }
    ],
    interactions: {
      hft_engine: {
        type: 'enhancement',
        level: 'warning',
        message: 'Private RPC provides lowest possible latency',
        recommendation: 'Essential for ultra-low latency HFT operations'
      }
    }
  },

  // NOTIFICATION SERVICES CATEGORY
  {
    id: 'telegram',
    label: 'Telegram Bot',
    category: 'notifications',
    description: 'Real-time trading alerts via Telegram (100% FREE)',
    required: false,
    cost: 'free',
    difficulty: 'easy',
    fields: [
      {
        key: 'telegram_bot_token',
        label: 'Bot Token',
        type: 'password',
        required: true,
        placeholder: '1234567890:ABCDEFGhijklmnoPQRSTUVWxyz',
        description: 'Get from @BotFather on Telegram',
        sensitive: true
      },
      {
        key: 'telegram_chat_id',
        label: 'Chat ID',
        type: 'text',
        required: true,
        placeholder: '-1001234567890',
        description: 'Your chat ID or group ID'
      }
    ],
    interactions: {}
  },
  {
    id: 'discord',
    label: 'Discord Webhook',
    category: 'notifications',
    description: 'Trading alerts to Discord channel (100% FREE)',
    required: false,
    cost: 'free',
    difficulty: 'easy',
    fields: [
      {
        key: 'discord_webhook_url',
        label: 'Webhook URL',
        type: 'password',
        required: true,
        placeholder: 'https://discord.com/api/webhooks/123/abc',
        description: 'Discord channel webhook URL',
        sensitive: true
      }
    ],
    interactions: {}
  },
  {
    id: 'email_smtp',
    label: 'Email (SMTP)',
    category: 'notifications',
    description: 'Email notifications for important events',
    required: false,
    cost: 'freemium',
    difficulty: 'medium',
    fields: [
      {
        key: 'smtp_host',
        label: 'SMTP Host',
        type: 'text',
        required: true,
        placeholder: 'smtp.gmail.com'
      },
      {
        key: 'smtp_port',
        label: 'SMTP Port',
        type: 'number',
        required: true,
        placeholder: '587',
        validation: { min: 1, max: 65535 }
      },
      {
        key: 'smtp_user',
        label: 'Username',
        type: 'text',
        required: true,
        placeholder: 'your-email@gmail.com'
      },
      {
        key: 'smtp_password',
        label: 'Password/App Password',
        type: 'password',
        required: true,
        placeholder: 'your-app-password',
        sensitive: true
      }
    ],
    interactions: {}
  },

  // DATA & ORACLE SERVICES CATEGORY
  {
    id: 'dexscreener',
    label: 'DexScreener Pro',
    category: 'data',
    description: 'Real-time DEX data and price feeds',
    required: false,
    cost: 'freemium',
    difficulty: 'easy',
    fields: [
      {
        key: 'api_key',
        label: 'DexScreener API Key',
        type: 'password',
        required: true,
        placeholder: 'ds_1234567890abcdef',
        sensitive: true
      }
    ],
    interactions: {}
  },
  {
    id: 'coingecko',
    label: 'CoinGecko Pro',
    category: 'data',
    description: 'Comprehensive crypto market data',
    required: false,
    cost: 'freemium',
    difficulty: 'easy',
    fields: [
      {
        key: 'api_key',
        label: 'CoinGecko API Key',
        type: 'password',
        required: true,
        placeholder: 'CG-abcd1234567890',
        sensitive: true
      }
    ],
    interactions: {}
  },
  {
    id: 'moralis',
    label: 'Moralis Web3 Data',
    category: 'data',
    description: 'Comprehensive Web3 and DeFi data API',
    required: false,
    cost: 'freemium',
    difficulty: 'medium',
    fields: [
      {
        key: 'api_key',
        label: 'Moralis API Key',
        type: 'password',
        required: true,
        placeholder: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
        sensitive: true
      }
    ],
    interactions: {}
  }
]

// Service interaction logic
export const checkServiceInteractions = (enabledServices: string[]): ServiceInteraction[] => {
  const interactions: ServiceInteraction[] = []
  
  for (const serviceId of enabledServices) {
    const service = serviceDefinitions.find(s => s.id === serviceId)
    if (!service) continue
    
    for (const [targetServiceId, interaction] of Object.entries(service.interactions)) {
      if (enabledServices.includes(targetServiceId)) {
        interactions.push({
          ...interaction,
          message: `${service.label} → ${serviceDefinitions.find(s => s.id === targetServiceId)?.label}: ${interaction.message}`
        })
      }
    }
  }
  
  return interactions
}

// Get services by category
export const getServicesByCategory = (category: string): ServiceDefinition[] => {
  return serviceDefinitions.filter(service => service.category === category)
}

// Category definitions
export const categoryDefinitions = [
  {
    id: 'hosting',
    label: 'Hosting & Cloud',
    icon: 'Cloud',
    description: 'Frontend and backend hosting solutions',
    services: getServicesByCategory('hosting')
  },
  {
    id: 'blockchain',
    label: 'Blockchains & RPCs',
    icon: 'Globe',
    description: 'Blockchain network connectivity',
    services: getServicesByCategory('blockchain')
  },
  {
    id: 'ai',
    label: 'AI & LLM Services',
    icon: 'Brain',
    description: 'Artificial intelligence and language models',
    services: getServicesByCategory('ai')
  },
  {
    id: 'database',
    label: 'Databases & Storage',
    icon: 'Database',
    description: 'Data storage and caching solutions',
    services: getServicesByCategory('database')
  },
  {
    id: 'mev',
    label: 'MEV & HFT (FREE)',
    icon: 'Shield',
    description: 'MEV protection and high-frequency trading (All FREE options)',
    services: getServicesByCategory('mev')
  },
  {
    id: 'notifications',
    label: 'Notifications',
    icon: 'Bell',
    description: 'Real-time alerts and notifications',
    services: getServicesByCategory('notifications')
  },
  {
    id: 'data',
    label: 'Data & Oracles',
    icon: 'Activity',
    description: 'Market data and price feeds',
    services: getServicesByCategory('data')
  }
]