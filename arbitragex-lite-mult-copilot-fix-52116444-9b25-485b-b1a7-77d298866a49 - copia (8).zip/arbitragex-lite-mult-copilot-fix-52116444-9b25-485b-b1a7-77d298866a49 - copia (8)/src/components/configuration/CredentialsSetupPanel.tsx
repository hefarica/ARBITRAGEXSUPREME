import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CheckCircle, AlertCircle, ExternalLink, Shield, Database, Zap, Globe } from 'lucide-react'

interface CredentialConfig {
  id: string
  name: string
  description: string
  category: 'blockchain' | 'exchange' | 'data' | 'defi' | 'security'
  required: boolean
  placeholder: string
  validation: {
    pattern: RegExp
    message: string
  }
  helpUrl: string
  status: 'pending' | 'configured' | 'validated' | 'error'
  value: string
  error?: string
}

interface SetupStep {
  id: string
  title: string
  description: string
  credentials: string[]
  completed: boolean
  required: boolean
}

export const CredentialsSetupPanel: React.FC = () => {
  const [credentials, setCredentials] = useState<CredentialConfig[]>([])
  const [setupSteps, setSetupSteps] = useState<SetupStep[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [overallProgress, setOverallProgress] = useState(0)
  const [isValidating, setIsValidating] = useState(false)

  useEffect(() => {
    initializeCredentials()
    initializeSetupSteps()
  }, [])

  useEffect(() => {
    calculateProgress()
  }, [credentials])

  const initializeCredentials = () => {
    const initialCredentials: CredentialConfig[] = [
      // Blockchain RPCs
      {
        id: 'ethereum_rpc',
        name: 'Ethereum RPC URL',
        description: 'Conexión a Ethereum mainnet (Alchemy, Infura, etc.)',
        category: 'blockchain',
        required: true,
        placeholder: 'https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY',
        validation: {
          pattern: /^https:\/\/.*\.alchemy\.com\/v2\/[a-zA-Z0-9]+$/,
          message: 'Debe ser una URL válida de Alchemy, Infura o similar'
        },
        helpUrl: 'https://docs.alchemy.com/reference/ethereum-api-quickstart',
        status: 'pending',
        value: ''
      },
      {
        id: 'polygon_rpc',
        name: 'Polygon RPC URL',
        description: 'Conexión a Polygon mainnet',
        category: 'blockchain',
        required: true,
        placeholder: 'https://polygon-mainnet.g.alchemy.com/v2/YOUR_KEY',
        validation: {
          pattern: /^https:\/\/.*\.alchemy\.com\/v2\/[a-zA-Z0-9]+$/,
          message: 'Debe ser una URL válida de Alchemy o Infura'
        },
        helpUrl: 'https://docs.alchemy.com/reference/polygon-api-quickstart',
        status: 'pending',
        value: ''
      },
      {
        id: 'bsc_rpc',
        name: 'BSC RPC URL',
        description: 'Conexión a Binance Smart Chain',
        category: 'blockchain',
        required: true,
        placeholder: 'https://bsc-dataseed.binance.org/',
        validation: {
          pattern: /^https:\/\/.*\.binance\.org\/$/,
          message: 'Debe ser una URL válida de BSC'
        },
        helpUrl: 'https://docs.binance.org/smart-chain/developer/rpc.html',
        status: 'pending',
        value: ''
      },
      {
        id: 'arbitrum_rpc',
        name: 'Arbitrum RPC URL',
        description: 'Conexión a Arbitrum One',
        category: 'blockchain',
        required: false,
        placeholder: 'https://arb-mainnet.g.alchemy.com/v2/YOUR_KEY',
        validation: {
          pattern: /^https:\/\/.*\.alchemy\.com\/v2\/[a-zA-Z0-9]+$/,
          message: 'Debe ser una URL válida de Alchemy'
        },
        helpUrl: 'https://docs.alchemy.com/reference/arbitrum-api-quickstart',
        status: 'pending',
        value: ''
      },
      {
        id: 'optimism_rpc',
        name: 'Optimism RPC URL',
        description: 'Conexión a Optimism',
        category: 'blockchain',
        required: false,
        placeholder: 'https://opt-mainnet.g.alchemy.com/v2/YOUR_KEY',
        validation: {
          pattern: /^https:\/\/.*\.alchemy\.com\/v2\/[a-zA-Z0-9]+$/,
          message: 'Debe ser una URL válida de Alchemy'
        },
        helpUrl: 'https://docs.alchemy.com/reference/optimism-api-quickstart',
        status: 'pending',
        value: ''
      },

      // Exchange APIs
      {
        id: 'binance_api_key',
        name: 'Binance API Key',
        description: 'API Key para Binance (para datos de precios)',
        category: 'exchange',
        required: true,
        placeholder: 'tu_api_key_de_binance',
        validation: {
          pattern: /^[a-zA-Z0-9]{64}$/,
          message: 'Debe ser una API key válida de Binance (64 caracteres)'
        },
        helpUrl: 'https://www.binance.com/en/my/settings/api-management',
        status: 'pending',
        value: ''
      },
      {
        id: 'binance_secret_key',
        name: 'Binance Secret Key',
        description: 'Secret Key para Binance',
        category: 'exchange',
        required: true,
        placeholder: 'tu_secret_key_de_binance',
        validation: {
          pattern: /^[a-zA-Z0-9]{64}$/,
          message: 'Debe ser una secret key válida de Binance (64 caracteres)'
        },
        helpUrl: 'https://www.binance.com/en/my/settings/api-management',
        status: 'pending',
        value: ''
      },

      // Data Providers
      {
        id: 'coingecko_api_key',
        name: 'CoinGecko API Key',
        description: 'API Key para CoinGecko Pro (datos de precios)',
        category: 'data',
        required: true,
        placeholder: 'CG-xxxxxxxxxxxxxxxxxxxxxxxx',
        validation: {
          pattern: /^CG-[a-zA-Z0-9]{32}$/,
          message: 'Debe ser una API key válida de CoinGecko Pro'
        },
        helpUrl: 'https://www.coingecko.com/en/api/pricing',
        status: 'pending',
        value: ''
      },
      {
        id: 'the_graph_api_key',
        name: 'The Graph API Key',
        description: 'API Key para The Graph (datos DeFi)',
        category: 'data',
        required: true,
        placeholder: 'tu_api_key_de_the_graph',
        validation: {
          pattern: /^[a-zA-Z0-9]{32,}$/,
          message: 'Debe ser una API key válida de The Graph'
        },
        helpUrl: 'https://thegraph.com/hosted-service/',
        status: 'pending',
        value: ''
      },

      // DeFi Protocols
      {
        id: 'flashbots_private_key',
        name: 'Flashbots Private Key',
        description: 'Clave privada para protección MEV (opcional)',
        category: 'defi',
        required: false,
        placeholder: '0x...',
        validation: {
          pattern: /^0x[a-fA-F0-9]{64}$/,
          message: 'Debe ser una clave privada válida (0x + 64 caracteres hex)'
        },
        helpUrl: 'https://docs.flashbots.net/flashbots-protect/overview',
        status: 'pending',
        value: ''
      },

      // Security
      {
        id: 'jwt_secret',
        name: 'JWT Secret',
        description: 'Clave secreta para JWT (autenticación)',
        category: 'security',
        required: true,
        placeholder: 'tu_jwt_secret_super_seguro',
        validation: {
          pattern: /^[a-zA-Z0-9]{32,}$/,
          message: 'Debe ser una clave secreta de al menos 32 caracteres'
        },
        helpUrl: 'https://jwt.io/introduction',
        status: 'pending',
        value: ''
      }
    ]

    setCredentials(initialCredentials)
  }

  const initializeSetupSteps = () => {
    const steps: SetupStep[] = [
      {
        id: 'blockchain',
        title: 'Configurar Blockchains',
        description: 'Conectar con las redes blockchain principales',
        credentials: ['ethereum_rpc', 'polygon_rpc', 'bsc_rpc'],
        completed: false,
        required: true
      },
      {
        id: 'exchanges',
        title: 'Configurar Exchanges',
        description: 'Conectar con exchanges para datos de precios',
        credentials: ['binance_api_key', 'binance_secret_key'],
        completed: false,
        required: true
      },
      {
        id: 'data_providers',
        title: 'Configurar Proveedores de Datos',
        description: 'Conectar con APIs de datos DeFi',
        credentials: ['coingecko_api_key', 'the_graph_api_key'],
        completed: false,
        required: true
      },
      {
        id: 'security',
        title: 'Configurar Seguridad',
        description: 'Configurar autenticación y protección',
        credentials: ['jwt_secret'],
        completed: false,
        required: true
      },
      {
        id: 'advanced',
        title: 'Configuración Avanzada',
        description: 'Configuraciones opcionales para funcionalidad avanzada',
        credentials: ['arbitrum_rpc', 'optimism_rpc', 'flashbots_private_key'],
        completed: false,
        required: false
      }
    ]

    setSetupSteps(steps)
  }

  const calculateProgress = () => {
    const configuredCount = credentials.filter(c => c.status === 'configured' || c.status === 'validated').length
    const totalRequired = credentials.filter(c => c.required).length
    const progress = (configuredCount / totalRequired) * 100
    setOverallProgress(Math.min(progress, 100))
  }

  const handleCredentialChange = (id: string, value: string) => {
    setCredentials(prev => prev.map(cred => {
      if (cred.id === id) {
        const isValid = cred.validation.pattern.test(value)
        return {
          ...cred,
          value,
          status: value ? (isValid ? 'configured' : 'error') : 'pending',
          error: value && !isValid ? cred.validation.message : undefined
        }
      }
      return cred
    }))
  }

  const validateCredential = async (credential: CredentialConfig) => {
    setIsValidating(true)
    
    try {
      // Simular validación de API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setCredentials(prev => prev.map(cred => {
        if (cred.id === credential.id) {
          return {
            ...cred,
            status: 'validated'
          }
        }
        return cred
      }))
    } catch (error) {
      setCredentials(prev => prev.map(cred => {
        if (cred.id === credential.id) {
          return {
            ...cred,
            status: 'error',
            error: 'Error al validar la credencial'
          }
        }
        return cred
      }))
    } finally {
      setIsValidating(false)
    }
  }

  const saveCredentials = async () => {
    const configuredCredentials = credentials.filter(c => c.status === 'configured' || c.status === 'validated')
    
    // Aquí se guardarían las credenciales de forma segura
    console.log('Guardando credenciales:', configuredCredentials)
    
    // Simular guardado
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    alert('✅ Credenciales guardadas exitosamente')
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'blockchain': return <Globe className="h-4 w-4" />
      case 'exchange': return <Zap className="h-4 w-4" />
      case 'data': return <Database className="h-4 w-4" />
      case 'defi': return <Shield className="h-4 w-4" />
      case 'security': return <Shield className="h-4 w-4" />
      default: return <Globe className="h-4 w-4" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'validated':
        return <Badge variant="default" className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Validado</Badge>
      case 'configured':
        return <Badge variant="secondary"><CheckCircle className="h-3 w-3 mr-1" />Configurado</Badge>
      case 'error':
        return <Badge variant="destructive"><AlertCircle className="h-3 w-3 mr-1" />Error</Badge>
      default:
        return <Badge variant="outline">Pendiente</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Configuración de Credenciales
          </CardTitle>
          <CardDescription>
            Configura las credenciales necesarias para conectar con servicios reales de DeFi
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">Progreso General</h3>
                <p className="text-sm text-muted-foreground">
                  {credentials.filter(c => c.status === 'configured' || c.status === 'validated').length} de {credentials.filter(c => c.required).length} credenciales requeridas configuradas
                </p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">{Math.round(overallProgress)}%</div>
                <div className="text-sm text-muted-foreground">Completado</div>
              </div>
            </div>
            <Progress value={overallProgress} className="h-2" />
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="blockchain" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="blockchain">Blockchains</TabsTrigger>
          <TabsTrigger value="exchanges">Exchanges</TabsTrigger>
          <TabsTrigger value="data">Datos</TabsTrigger>
          <TabsTrigger value="security">Seguridad</TabsTrigger>
          <TabsTrigger value="advanced">Avanzado</TabsTrigger>
        </TabsList>

        {setupSteps.map(step => (
          <TabsContent key={step.id} value={step.id} className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {getCategoryIcon(step.id)}
                  {step.title}
                </CardTitle>
                <CardDescription>{step.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {credentials
                  .filter(cred => step.credentials.includes(cred.id))
                  .map(credential => (
                    <div key={credential.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor={credential.id} className="text-sm font-medium">
                          {credential.name}
                          {credential.required && <span className="text-red-500 ml-1">*</span>}
                        </Label>
                        {getStatusBadge(credential.status)}
                      </div>
                      <div className="flex gap-2">
                        <Input
                          id={credential.id}
                          type="password"
                          placeholder={credential.placeholder}
                          value={credential.value}
                          onChange={(e) => handleCredentialChange(credential.id, e.target.value)}
                          className="flex-1"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(credential.helpUrl, '_blank')}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                        {credential.status === 'configured' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => validateCredential(credential)}
                            disabled={isValidating}
                          >
                            Validar
                          </Button>
                        )}
                      </div>
                      {credential.error && (
                        <Alert variant="destructive">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription>{credential.error}</AlertDescription>
                        </Alert>
                      )}
                      <p className="text-xs text-muted-foreground">{credential.description}</p>
                    </div>
                  ))}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold">Guardar Configuración</h3>
              <p className="text-sm text-muted-foreground">
                Las credenciales se guardarán de forma segura en el sistema
              </p>
            </div>
            <Button 
              onClick={saveCredentials}
              disabled={overallProgress < 100}
              className="min-w-[120px]"
            >
              {overallProgress < 100 ? 'Configurar Todo' : 'Guardar Credenciales'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 