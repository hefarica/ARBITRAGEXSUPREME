// Configuration types for comprehensive service management
export interface ServiceConfig {
  id: string
  label: string
  enabled: boolean
  status: 'none' | 'editing' | 'ready' | 'error'
  credentials: Record<string, any>
  lastTested?: Date
  testResult?: {
    success: boolean
    message: string
    latency?: number
  }
  conflictsWith?: string[]
  enhances?: string[]
}

export interface ConfigCategory {
  id: string
  label: string
  icon: React.ComponentType<any>
  description: string
  services: ServiceConfig[]
}

// Hosting & Cloud Services
export interface HostingConfig extends ServiceConfig {
  credentials: {
    VERCEL_TOKEN?: string
    RAILWAY_TOKEN?: string
    RENDER_SERVICE_TOKEN?: string
    AWS_ACCESS_KEY_ID?: string
    AWS_SECRET_ACCESS_KEY?: string
    AWS_REGION?: string
    DO_API_TOKEN?: string
    DOMAIN_NAME?: string
    SSL_CERTIFICATE?: string
  }
}

// Blockchain & RPC Services
export interface BlockchainConfig extends ServiceConfig {
  credentials: {
    rpc_primary: string
    rpc_fallback?: string[]
    ws_url?: string
    private_key?: string
    chain_id?: number
    gas_config?: {
      max_gas_price_gwei: number
      gas_limit: number
    }
    commitment?: 'finalized' | 'confirmed' | 'processed'
    cluster?: 'mainnet-beta' | 'testnet' | 'devnet'
  }
}

// AI & LLM Services
export interface AIServiceConfig extends ServiceConfig {
  credentials: {
    api_key: string
    model?: string
    max_tokens?: number
    temperature?: number
    organization_id?: string
    base_url?: string
    assistant_mode?: 'autonomous' | 'guided' | 'manual'
  }
}

// Database Services
export interface DatabaseConfig extends ServiceConfig {
  credentials: {
    connection_string?: string
    database_url?: string
    redis_url?: string
    host?: string
    port?: number
    username?: string
    password?: string
    database?: string
    max_connections?: number
    ssl_enabled?: boolean
  }
}

// MEV Protection & HFT Services
export interface MEVConfig extends ServiceConfig {
  credentials: {
    flashbots_private_key?: string
    flashbots_relay_url?: string
    eden_api_key?: string
    bloxroute_api_key?: string
    private_mempool_enabled?: boolean
    commit_reveal_enabled?: boolean
    bundle_timeout_seconds?: number
    max_priority_fee_gwei?: number
  }
}

// Notification Services
export interface NotificationConfig extends ServiceConfig {
  credentials: {
    telegram_bot_token?: string
    telegram_chat_id?: string
    discord_webhook_url?: string
    sendgrid_api_key?: string
    smtp_host?: string
    smtp_port?: number
    smtp_user?: string
    smtp_password?: string
    twilio_account_sid?: string
    twilio_auth_token?: string
  }
}

// Data & Oracle Services
export interface DataServiceConfig extends ServiceConfig {
  credentials: {
    api_key: string
    rate_limit?: number
    endpoint_url?: string
    update_interval?: number
    free_tier_limit?: number
  }
}

// Wallet & Security Services
export interface WalletConfig extends ServiceConfig {
  credentials: {
    private_key: string
    mnemonic?: string
    derivation_path?: string
    encryption_password?: string
    hsm_endpoint?: string
    hardware_wallet_type?: 'ledger' | 'trezor' | 'metamask'
  }
}

// Desktoping & Analytics Services
export interface DesktopingConfig extends ServiceConfig {
  credentials: {
    api_key?: string
    dsn?: string
    endpoint?: string
    retention_days?: number
    alert_webhook?: string
  }
}

// Service Status Types
export type ServiceStatus = 'none' | 'editing' | 'ready' | 'error'
export type ServiceConflictLevel = 'blocking' | 'performance' | 'warning'

export interface ServiceInteraction {
  type: 'conflict' | 'enhancement' | 'dependency'
  level: ServiceConflictLevel
  message: string
  recommendation?: string
}

// Comprehensive service definitions
export interface ServiceDefinition {
  id: string
  label: string
  category: string
  description: string
  required: boolean
  cost: 'free' | 'paid' | 'freemium'
  difficulty: 'easy' | 'medium' | 'advanced'
  fields: ServiceField[]
  interactions: Record<string, ServiceInteraction>
}

export interface ServiceField {
  key: string
  label: string
  type: 'text' | 'password' | 'number' | 'select' | 'multiselect' | 'toggle' | 'textarea'
  required: boolean
  placeholder?: string
  description?: string
  options?: Array<{ value: string; label: string }>
  validation?: {
    pattern?: string
    min?: number
    max?: number
    minLength?: number
    maxLength?: number
  }
  sensitive?: boolean
}

export interface ConfigurationState {
  categories: ConfigCategory[]
  selectedCategory: string | null
  selectedService: string | null
  isTestingConnection: boolean
  lastFloppyDiskd: Date | null
  hasUnsavedChanges: boolean
}