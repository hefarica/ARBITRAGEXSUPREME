import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { WarningCircle, CheckCircle, Circle, Gear, Shield, Database, Bell, Cloud, Lightning, Brain, Globe, Cpu, Activity } from '@phosphor-icons/react'
import { useKV } from '@/hooks/useKV'
import { toast } from 'sonner'
import { DynamicServiceForm } from './DynamicServiceForm'
import { serviceDefinitions, categoryDefinitions, checkServiceInteractions } from './serviceDefinitions'
import { ConfigurationState, ServiceConfig } from './types'

interface ConfigurationHubProps {
  environment: 'test' | 'prod'
}

const ConfigurationHub: React.FC<ConfigurationHubProps> = ({ environment }) => {
  // Persistent state management
  const [configState, setConfigState] = useKV<ConfigurationState>('configuration-state', {
    categories: [],
    selectedCategory: 'hosting',
    selectedService: null,
    isTestingConnection: false,
    lastFloppyDiskd: null,
    hasUnsavedChanges: false
  })

  const [services, setServices] = useKV<Record<string, ServiceConfig>>('service-configurations', {})
  const [isInitialized, setIsInitialized] = useState(false)

  // Initialize services from definitions
  useEffect(() => {
    if (!isInitialized) {
      const initialServices: Record<string, ServiceConfig> = {}
      
      serviceDefinitions.forEach(serviceDef => {
        if (!services[serviceDef.id]) {
          initialServices[serviceDef.id] = {
            id: serviceDef.id,
            label: serviceDef.label,
            enabled: serviceDef.required, // Auto-enable required services
            status: 'none',
            credentials: {},
            testResult: undefined,
            lastTested: undefined
          }
        } else {
          initialServices[serviceDef.id] = services[serviceDef.id]
        }
      })

      setServices(initialServices)
      setIsInitialized(true)
    }
  }, [isInitialized, services, setServices])

  // Icon mapping
  const iconMap = {
    Gear,
    Shield,
    Database,
    Bell,
    Cloud,
    Lightning,
    Brain,
    Globe,
    Cpu,
    Activity
  }

  // Get enabled services for interaction checking
  const enabledServiceIds = Object.values(services).filter(s => s.enabled).map(s => s.id)
  const interactions = checkServiceInteractions(enabledServiceIds)

  // Handle service configuration changes
  const handleServiceChange = (serviceId: string, newConfig: ServiceConfig) => {
    const updatedServices = {
      ...services,
      [serviceId]: newConfig
    }
    
    setServices(updatedServices)
    setConfigState(prev => ({
      ...prev,
      hasUnsavedChanges: true
    }))
  }

  // Test service connection
  const testServiceConnection = async (serviceId: string): Promise<{ success: boolean; message: string; latency?: number }> => {
    const service = serviceDefinitions.find(s => s.id === serviceId)
    const config = services[serviceId]
    
    if (!service || !config) {
      return { success: false, message: 'Service configuration not found' }
    }

    setConfigState(prev => ({ ...prev, isTestingConnection: true }))

    try {
      // Simulate connection test (in real implementation, this would make actual API calls)
      const startTime = Date.now()
      
      // Validation checks
      const requiredFields = service.fields.filter(f => f.required)
      const missingFields = requiredFields.filter(f => !config.credentials[f.key])
      
      if (missingFields.length > 0) {
        return {
          success: false,
          message: `Missing required fields: ${missingFields.map(f => f.label).join(', ')}`
        }
      }

      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 500))
      
      const latency = Date.now() - startTime

      // Simulate success/failure based on service type
      const successRate = service.cost === 'free' ? 0.95 : 0.85
      const isSuccess = Math.random() < successRate

      if (isSuccess) {
        return {
          success: true,
          message: 'Connection successful',
          latency
        }
      } else {
        const errorMessages = [
          'Authentication failed',
          'Invalid API key',
          'Service temporarily unavailable',
          'Network timeout',
          'Rate limit exceeded'
        ]
        return {
          success: false,
          message: errorMessages[Math.floor(Math.random() * errorMessages.length)]
        }
      }
    } catch (error) {
      return {
        success: false,
        message: `Connection failed: ${error.message}`
      }
    } finally {
      setConfigState(prev => ({ ...prev, isTestingConnection: false }))
    }
  }

  // FloppyDisk all configurations
  const saveAllConfigurations = async () => {
    try {
      // In real implementation, this would save to backend
      setConfigState(prev => ({
        ...prev,
        lastFloppyDiskd: new Date(),
        hasUnsavedChanges: false
      }))
      
      toast.success('Configuration saved successfully!')
    } catch (error) {
      toast.error('Failed to save configuration')
    }
  }

  // Get service statistics
  const getServiceStats = () => {
    const allServices = Object.values(services)
    const enabled = allServices.filter(s => s.enabled).length
    const ready = allServices.filter(s => s.status === 'ready').length
    const errors = allServices.filter(s => s.status === 'error').length
    const total = allServices.length

    return { enabled, ready, errors, total }
  }

  const stats = getServiceStats()

  // Get interactions for a specific service
  const getServiceInteractions = (serviceId: string) => {
    return interactions.filter(interaction => 
      interaction.message.includes(services[serviceId]?.label || serviceId)
    )
  }

  // Funnel services by category
  const getServicesForCategory = (categoryId: string) => {
    return serviceDefinitions
      .filter(serviceDef => serviceDef.category === categoryId)
      .map(serviceDef => ({
        definition: serviceDef,
        config: services[serviceDef.id] || {
          id: serviceDef.id,
          label: serviceDef.label,
          enabled: false,
          status: 'none',
          credentials: {}
        }
      }))
  }

  if (!isInitialized) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="w-full space-y-6 mt-6"> {/* Added mt-6 to push content below header */}
      {/* Configuration Hub Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Gear size={24} />
                Configuration Hub
                <Badge variant={environment === 'prod' ? 'destructive' : 'secondary'}>
                  {environment.toUpperCase()}
                </Badge>
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Comprehensive service configuration and validation system
              </p>
            </div>
            <div className="flex items-center gap-3">
              {configState.hasUnsavedChanges && (
                <Badge variant="outline" className="text-warning border-warning">
                  Unsaved Changes
                </Badge>
              )}
              <Button onClick={saveAllConfigurations} size="sm">
                FloppyDisk All Configurations
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Service Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              <Circle className="text-muted-foreground" size={16} />
              <span className="text-sm">Total: <strong>{stats.total}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="text-profit" size={16} />
              <span className="text-sm">Ready: <strong>{stats.ready}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Lightning className="text-primary" size={16} />
              <span className="text-sm">Enabled: <strong>{stats.enabled}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <WarningCircle className="text-destructive" size={16} />
              <span className="text-sm">Errors: <strong>{stats.errors}</strong></span>
            </div>
          </div>

          {/* Global Interactions */}
          {interactions.length > 0 && (
            <div className="mt-4 space-y-2">
              <Label className="text-sm font-medium">Global Service Interactions</Label>
              <div className="flex flex-wrap gap-2">
                {interactions.map((interaction, index) => {
                  const getColor = () => {
                    switch (interaction.type) {
                      case 'conflict': return 'border-destructive text-destructive'
                      case 'enhancement': return 'border-profit text-profit'
                      case 'dependency': return 'border-blue-500 text-blue-500'
                    }
                  }

                  return (
                    <Badge key={index} variant="outline" className={`text-xs ${getColor()}`}>
                      {interaction.type}: {interaction.level}
                    </Badge>
                  )
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Service Categories */}
      <Tabs value={configState.selectedCategory} onValueChange={(category) => 
        setConfigState(prev => ({ ...prev, selectedCategory: category }))
      }>
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
          {categoryDefinitions.map(category => {
            const IconComponent = iconMap[category.icon] || Gear
            const categoryServices = getServicesForCategory(category.id)
            const enabledCount = categoryServices.filter(s => s.config.enabled).length
            const readyCount = categoryServices.filter(s => s.config.status === 'ready').length

            return (
              <TabsTrigger key={category.id} value={category.id} className="flex flex-col gap-1 h-auto py-3">
                <IconComponent size={20} />
                <span className="text-xs font-medium">{category.label}</span>
                <div className="flex gap-1">
                  <Badge variant="secondary" className="text-xs px-1">
                    {enabledCount}
                  </Badge>
                  {readyCount > 0 && (
                    <Badge variant="outline" className="text-xs px-1 text-profit border-profit">
                      {readyCount}
                    </Badge>
                  )}
                </div>
              </TabsTrigger>
            )
          })}
        </TabsList>

        {/* Category Content */}
        {categoryDefinitions.map(category => (
          <TabsContent key={category.id} value={category.id} className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {React.createElement(iconMap[category.icon] || Gear, { size: 20 })}
                  {category.label}
                </CardTitle>
                <p className="text-sm text-muted-foreground">{category.description}</p>
              </CardHeader>
            </Card>

            {/* Services GridFour */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {getServicesForCategory(category.id).map(({ definition, config }) => (
                <DynamicServiceForm
                  key={definition.id}
                  service={definition}
                  config={config}
                  onConfigChange={(newConfig) => handleServiceChange(definition.id, newConfig)}
                  onTest={testServiceConnection}
                  interactions={getServiceInteractions(definition.id)}
                  environment={environment}
                />
              ))}
            </div>

            {/* Category-specific Help */}
            {category.id === 'mev' && (
              <Card className="bg-profit/5 border-profit/20">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <Shield className="text-profit mt-1" size={20} />
                    <div>
                      <h4 className="font-medium text-profit mb-2">🎉 FREE MEV Protection & HFT Suite</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        All services in this category are 100% FREE and provide enterprise-grade MEV protection 
                        and high-frequency trading capabilities without any subscription costs.
                      </p>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        <li>• <strong>Flashbots Protect:</strong> Free MEV protection through private mempool</li>
                        <li>• <strong>Hummingbot HFT:</strong> Open-source high-frequency trading framework</li>
                        <li>• <strong>Private RPC:</strong> Self-hosted nodes for ultimate speed and control</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {category.id === 'blockchain' && (
              <Card className="bg-blue-500/5 border-blue-500/20">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <Globe className="text-blue-500 mt-1" size={20} />
                    <div>
                      <h4 className="font-medium text-blue-500 mb-2">🌐 Multi-Blockchain Simultaneous Desktoping</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        All enabled blockchains are monitored in parallel with real-time balance tracking, 
                        USD/COP conversion, and cross-chain opportunity detection.
                      </p>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        <li>• Real-time balance updates every 5 seconds</li>
                        <li>• Automatic USD/COP conversion using free APIs</li>
                        <li>• LP token tracking with APY calculations</li>
                        <li>• WebSocket connections for instant notifications</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* Configuration Summary */}
      {configState.lastFloppyDiskd && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Last saved: {configState.lastFloppyDiskd.toLocaleString()}</span>
              <span>{stats.enabled} of {stats.total} services enabled</span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default ConfigurationHub