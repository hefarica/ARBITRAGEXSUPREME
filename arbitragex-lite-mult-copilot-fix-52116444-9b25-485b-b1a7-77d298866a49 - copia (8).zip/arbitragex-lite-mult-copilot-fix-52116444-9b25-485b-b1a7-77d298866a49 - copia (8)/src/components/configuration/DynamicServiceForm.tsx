import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { WarningCircle, CheckCircle, Circle, Eye, EyeSlash, TestTube, Lightning } from '@phosphor-icons/react'
import { ServiceDefinition, ServiceConfig, ServiceField, ServiceInteraction } from './types'
import { toast } from 'sonner'

interface DynamicServiceFormProps {
  service: ServiceDefinition
  config: ServiceConfig
  onConfigChange: (config: ServiceConfig) => void
  onTest: (serviceId: string) => Promise<{ success: boolean; message: string; latency?: number }>
  interactions: ServiceInteraction[]
  environment: 'test' | 'prod'
}

export const DynamicServiceForm: React.FC<DynamicServiceFormProps> = ({
  service,
  config,
  onConfigChange,
  onTest,
  interactions,
  environment
}) => {
  const [showSensitive, setShowSensitive] = useState<Record<string, boolean>>({})
  const [isTesting, setIsTesting] = useState(false)
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({})

  const toggleSensitiveField = (fieldKey: string) => {
    setShowSensitive(prev => ({
      ...prev,
      [fieldKey]: !prev[fieldKey]
    }))
  }

  const validateField = (field: ServiceField, value: any): string | null => {
    if (field.required && (!value || value === '')) {
      return `${field.label} is required`
    }

    if (field.validation && value) {
      const { pattern, min, max, minLength, maxLength } = field.validation

      if (pattern && typeof value === 'string') {
        const regex = new RegExp(pattern)
        if (!regex.test(value)) {
          return `${field.label} format is invalid`
        }
      }

      if (typeof value === 'number') {
        if (min !== undefined && value < min) {
          return `${field.label} must be at least ${min}`
        }
        if (max !== undefined && value > max) {
          return `${field.label} must be at most ${max}`
        }
      }

      if (typeof value === 'string') {
        if (minLength !== undefined && value.length < minLength) {
          return `${field.label} must be at least ${minLength} characters`
        }
        if (maxLength !== undefined && value.length > maxLength) {
          return `${field.label} must be at most ${maxLength} characters`
        }
      }
    }

    return null
  }

  const handleFieldChange = (field: ServiceField, value: any) => {
    const error = validateField(field, value)
    
    setValidationErrors(prev => ({
      ...prev,
      [field.key]: error || ''
    }))

    const newCredentials = {
      ...config.credentials,
      [field.key]: value
    }

    // Auto-detect status based on required fields
    const allRequiredFieldsFilled = service.fields
      .filter(f => f.required)
      .every(f => newCredentials[f.key] && newCredentials[f.key] !== '')

    const newStatus = allRequiredFieldsFilled ? 'editing' : 'none'

    onConfigChange({
      ...config,
      credentials: newCredentials,
      status: newStatus
    })
  }

  const handleTest = async () => {
    setIsTesting(true)
    try {
      const result = await onTest(service.id)
      
      const newConfig = {
        ...config,
        status: result.success ? 'ready' : 'error',
        lastTested: new Date(),
        testResult: result
      }
      
      onConfigChange(newConfig)
      
      if (result.success) {
        toast.success(`${service.label} connection successful!`, {
          description: result.latency ? `Latency: ${result.latency}ms` : undefined
        })
      } else {
        toast.error(`${service.label} connection failed`, {
          description: result.message
        })
      }
    } catch (error) {
      toast.error(`Test failed: ${error.message}`)
    } finally {
      setIsTesting(false)
    }
  }

  const renderField = (field: ServiceField) => {
    const value = config.credentials[field.key] || ''
    const error = validationErrors[field.key]
    const isRequired = field.required
    const isSensitive = field.sensitive

    switch (field.type) {
      case 'text':
      case 'password':
        return (
          <div key={field.key} className="space-y-2">
            <Label htmlFor={field.key} className="flex items-center gap-2">
              {field.label}
              {isRequired && <span className="text-destructive">*</span>}
              {isSensitive && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleSensitiveField(field.key)}
                  className="h-4 w-4 p-0"
                >
                  {showSensitive[field.key] ? <EyeSlash size={12} /> : <Eye size={12} />}
                </Button>
              )}
            </Label>
            <Input
              id={field.key}
              type={isSensitive && !showSensitive[field.key] ? 'password' : 'text'}
              value={value}
              onChange={(e) => handleFieldChange(field, e.target.value)}
              placeholder={field.placeholder}
              className={error ? 'border-destructive' : ''}
            />
            {field.description && (
              <p className="text-xs text-muted-foreground">{field.description}</p>
            )}
            {error && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <WarningCircle size={12} />
                {error}
              </p>
            )}
          </div>
        )

      case 'number':
        return (
          <div key={field.key} className="space-y-2">
            <Label htmlFor={field.key} className="flex items-center gap-2">
              {field.label}
              {isRequired && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={field.key}
              type="number"
              value={value}
              onChange={(e) => handleFieldChange(field, Number(e.target.value))}
              placeholder={field.placeholder}
              min={field.validation?.min}
              max={field.validation?.max}
              className={error ? 'border-destructive' : ''}
            />
            {field.description && (
              <p className="text-xs text-muted-foreground">{field.description}</p>
            )}
            {error && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <WarningCircle size={12} />
                {error}
              </p>
            )}
          </div>
        )

      case 'select':
        return (
          <div key={field.key} className="space-y-2">
            <Label htmlFor={field.key} className="flex items-center gap-2">
              {field.label}
              {isRequired && <span className="text-destructive">*</span>}
            </Label>
            <Select value={value} onValueChange={(newValue) => handleFieldChange(field, newValue)}>
              <SelectTrigger className={error ? 'border-destructive' : ''}>
                <SelectValue placeholder={field.placeholder} />
              </SelectTrigger>
              <SelectContent>
                {field.options?.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {field.description && (
              <p className="text-xs text-muted-foreground">{field.description}</p>
            )}
            {error && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <WarningCircle size={12} />
                {error}
              </p>
            )}
          </div>
        )

      case 'textarea':
        return (
          <div key={field.key} className="space-y-2">
            <Label htmlFor={field.key} className="flex items-center gap-2">
              {field.label}
              {isRequired && <span className="text-destructive">*</span>}
            </Label>
            <Textarea
              id={field.key}
              value={value}
              onChange={(e) => handleFieldChange(field, e.target.value)}
              placeholder={field.placeholder}
              className={error ? 'border-destructive' : ''}
              rows={3}
            />
            {field.description && (
              <p className="text-xs text-muted-foreground">{field.description}</p>
            )}
            {error && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <WarningCircle size={12} />
                {error}
              </p>
            )}
          </div>
        )

      case 'toggle':
        return (
          <div key={field.key} className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor={field.key} className="flex items-center gap-2">
                {field.label}
                {isRequired && <span className="text-destructive">*</span>}
              </Label>
              <Switch
                id={field.key}
                checked={Boolean(value)}
                onCheckedChange={(checked) => handleFieldChange(field, checked)}
              />
            </div>
            {field.description && (
              <p className="text-xs text-muted-foreground">{field.description}</p>
            )}
          </div>
        )

      default:
        return null
    }
  }

  const getStatusIcon = () => {
    switch (config.status) {
      case 'ready':
        return <CheckCircle className="text-profit" size={16} />
      case 'error':
        return <WarningCircle className="text-destructive" size={16} />
      case 'editing':
        return <Circle className="text-warning" size={16} />
      default:
        return <Circle className="text-muted-foreground" size={16} />
    }
  }

  const getStatusColor = () => {
    switch (config.status) {
      case 'ready': return 'text-profit'
      case 'error': return 'text-destructive'
      case 'editing': return 'text-warning'
      default: return 'text-muted-foreground'
    }
  }

  const canTest = config.status === 'editing' || config.status === 'ready' || config.status === 'error'
  const hasErrors = Object.values(validationErrors).some(error => error !== '')

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {getStatusIcon()}
            <div>
              <CardTitle className="flex items-center gap-2">
                {service.label}
                {service.cost === 'free' && (
                  <Badge variant="secondary" className="bg-profit/10 text-profit border-profit/20">
                    FREE
                  </Badge>
                )}
                {service.cost === 'freemium' && (
                  <Badge variant="secondary" className="bg-blue-500/10 text-blue-500 border-blue-500/20">
                    FREEMIUM
                  </Badge>
                )}
                {service.required && (
                  <Badge variant="destructive" className="text-xs">
                    REQUIRED
                  </Badge>
                )}
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">{service.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={`${getStatusColor()}`}>
              {config.status.toUpperCase()}
            </Badge>
            <Switch
              checked={config.enabled}
              onCheckedChange={(enabled) => onConfigChange({ ...config, enabled })}
            />
          </div>
        </div>
      </CardHeader>

      {config.enabled && (
        <CardContent className="space-y-4">
          {/* Service Info */}
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span>Difficulty: <strong className="capitalize">{service.difficulty}</strong></span>
            <span>•</span>
            <span>Cost: <strong className="capitalize">{service.cost}</strong></span>
            {service.required && (
              <>
                <span>•</span>
                <span className="text-destructive">Required Service</span>
              </>
            )}
          </div>

          <Separator />

          {/* Configuration Fields */}
          <div className="space-y-4">
            {service.fields.map(renderField)}
          </div>

          {/* Service Interactions */}
          {interactions.length > 0 && (
            <>
              <Separator />
              <div className="space-y-2">
                <Label className="text-sm font-medium">Service Interactions</Label>
                <div className="space-y-2">
                  {interactions.map((interaction, index) => {
                    const getInteractionIcon = () => {
                      switch (interaction.type) {
                        case 'conflict': return <WarningCircle className="text-destructive" size={14} />
                        case 'enhancement': return <Lightning className="text-profit" size={14} />
                        case 'dependency': return <Circle className="text-blue-500" size={14} />
                      }
                    }

                    const getInteractionColor = () => {
                      switch (interaction.level) {
                        case 'blocking': return 'border-destructive bg-destructive/5'
                        case 'performance': return 'border-warning bg-warning/5'
                        case 'warning': return 'border-blue-500 bg-blue-500/5'
                      }
                    }

                    return (
                      <div key={index} className={`p-3 rounded-lg border ${getInteractionColor()}`}>
                        <div className="flex items-start gap-2">
                          {getInteractionIcon()}
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium capitalize">{interaction.type}</p>
                            <p className="text-xs text-muted-foreground">{interaction.message}</p>
                            {interaction.recommendation && (
                              <p className="text-xs text-blue-600 mt-1 font-medium">
                                💡 {interaction.recommendation}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </>
          )}

          {/* Test Connection */}
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-sm">Connection Test</Label>
              {config.lastTested && (
                <p className="text-xs text-muted-foreground">
                  Last tested: {config.lastTested.toLocaleString()}
                </p>
              )}
              {config.testResult && (
                <p className={`text-xs ${config.testResult.success ? 'text-profit' : 'text-destructive'}`}>
                  {config.testResult.message}
                  {config.testResult.latency && ` (${config.testResult.latency}ms)`}
                </p>
              )}
            </div>
            <Button
              onClick={handleTest}
              disabled={!canTest || hasErrors || isTesting}
              size="sm"
              variant="outline"
              className="flex items-center gap-2"
            >
              <TestTube size={14} />
              {isTesting ? 'Testing...' : 'Test Connection'}
            </Button>
          </div>

          {/* Environment Warning */}
          {environment === 'prod' && service.id.includes('test') && (
            <div className="p-3 rounded-lg border border-warning bg-warning/5">
              <div className="flex items-center gap-2">
                <WarningCircle className="text-warning" size={14} />
                <p className="text-xs text-warning">
                  Warning: You're in PRODUCTION mode but this service appears to be for testing.
                </p>
              </div>
            </div>
          )}
        </CardContent>
      )}
    </Card>
  )
}