import React, { useState, useEffect, useCallback } from 'react';
import { PerformanceMonitor } from '../../core/PerformanceMonitor';
import { RealTimeDataIngestion } from '../../core/RealTimeDataIngestion';
import { ArbitrageDetectionEngine } from '../../core/ArbitrageDetectionEngine';
import { MEVProtectedExecutor } from '../../core/MEVProtectedExecutor';

interface PerformanceMetrics {
  latency: {
    rpc: { [chainId: number]: number };
    websocket: { [chainId: number]: number };
    multicall: { [chainId: number]: number };
    arbitrage: number;
    execution: number;
  };
  throughput: {
    poolsPerSecond: number;
    opportunitiesPerSecond: number;
    transactionsPerSecond: number;
    dataPointsPerSecond: number;
  };
  efficiency: {
    cpuUsage: number;
    memoryUsage: number;
    networkUsage: number;
    cacheHitRate: number;
  };
  reliability: {
    uptime: number;
    errorRate: number;
    successRate: number;
    reconnectionAttempts: number;
  };
}

interface TestResult {
  name: string;
  success: boolean;
  duration: number;
  metrics: any;
  error?: string;
}

export const PerformanceMonitorComponent: React.FC = () => {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    latency: { rpc: {}, websocket: {}, multicall: {}, arbitrage: 0, execution: 0 },
    throughput: { poolsPerSecond: 0, opportunitiesPerSecond: 0, transactionsPerSecond: 0, dataPointsPerSecond: 0 },
    efficiency: { cpuUsage: 0, memoryUsage: 0, networkUsage: 0, cacheHitRate: 0 },
    reliability: { uptime: 0, errorRate: 0, successRate: 0, reconnectionAttempts: 0 }
  });

  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  // Inicializar servicios del core
  const [dataIngestion] = useState(() => {
    const rpcConfigs = [
      { chainId: 1, wsUrl: 'wss://mainnet.infura.io/ws/v3/YOUR_INFURA_KEY' },
      { chainId: 56, wsUrl: 'wss://bsc-dataseed.binance.org' },
      { chainId: 137, wsUrl: 'wss://polygon-rpc.com' },
      { chainId: 43114, wsUrl: 'wss://api.avax.network/ext/bc/C/ws' },
      { chainId: 250, wsUrl: 'wss://rpc.ftm.tools' },
      { chainId: 42161, wsUrl: 'wss://arb1.arbitrum.io/ws' },
      { chainId: 10, wsUrl: 'wss://mainnet.optimism.io' },
      { chainId: 8453, wsUrl: 'wss://mainnet.base.org' }
    ];
    return new RealTimeDataIngestion(rpcConfigs);
  });

  const [arbitrageEngine] = useState(() => new ArbitrageDetectionEngine(dataIngestion));
  const [mevExecutor] = useState(() => new MEVProtectedExecutor(dataIngestion, arbitrageEngine));
  const [performanceMonitor] = useState(() => new PerformanceMonitor(dataIngestion, arbitrageEngine, mevExecutor));

  // Ejecutar pruebas de rendimiento
  const runPerformanceTests = useCallback(async () => {
    setIsRunning(true);
    setTestResults([]);

    try {
      console.log('🚀 Iniciando pruebas de rendimiento...');
      const results = await performanceMonitor.runAllTests();
      
      setTestResults(results.map(result => ({
        name: result.name,
        success: result.success,
        duration: result.duration,
        metrics: result.metrics,
        error: result.error
      })));

      // Actualizar métricas con los resultados
      updateMetricsFromResults(results);
      
      console.log('✅ Pruebas de rendimiento completadas');
    } catch (error) {
      console.error('❌ Error ejecutando pruebas:', error);
    } finally {
      setIsRunning(false);
      setLastUpdate(new Date());
    }
  }, [performanceMonitor]);

  // Actualizar métricas desde los resultados de las pruebas
  const updateMetricsFromResults = useCallback((results: TestResult[]) => {
    const newMetrics = { ...metrics };
    
    results.forEach(result => {
      if (result.success && result.metrics) {
        // Actualizar métricas de latencia
        if (result.metrics.latency) {
          newMetrics.latency = { ...newMetrics.latency, ...result.metrics.latency };
        }
        
        // Actualizar métricas de throughput
        if (result.metrics.throughput) {
          newMetrics.throughput = { ...newMetrics.throughput, ...result.metrics.throughput };
        }
        
        // Actualizar métricas de eficiencia
        if (result.metrics.efficiency) {
          newMetrics.efficiency = { ...newMetrics.efficiency, ...result.metrics.efficiency };
        }
        
        // Actualizar métricas de confiabilidad
        if (result.metrics.reliability) {
          newMetrics.reliability = { ...newMetrics.reliability, ...result.metrics.reliability };
        }
      }
    });

    setMetrics(newMetrics);
  }, [metrics]);

  // Monitoreo continuo de métricas
  useEffect(() => {
    const updateMetrics = () => {
      // Simular actualización de métricas en tiempo real
      setMetrics(prev => ({
        ...prev,
        efficiency: {
          ...prev.efficiency,
          cpuUsage: Math.random() * 100,
          memoryUsage: Math.random() * 100,
          networkUsage: Math.random() * 1000,
          cacheHitRate: 70 + Math.random() * 30
        },
        reliability: {
          ...prev.reliability,
          uptime: 95 + Math.random() * 5,
          errorRate: Math.random() * 5,
          successRate: 90 + Math.random() * 10,
          reconnectionAttempts: Math.floor(Math.random() * 10)
        }
      }));
    };

    const interval = setInterval(updateMetrics, 10000); // Actualizar cada 10 segundos
    return () => clearInterval(interval);
  }, []);

  // Formatear tiempo
  const formatDuration = (ms: number) => {
    if (ms < 1000) return `${ms.toFixed(2)}ms`;
    if (ms < 60000) return `${(ms / 1000).toFixed(2)}s`;
    return `${(ms / 60000).toFixed(2)}m`;
  };

  // Obtener color de estado
  const getStatusColor = (success: boolean) => {
    return success ? 'text-green-500' : 'text-red-500';
  };

  return (
    <div className="performance-monitor">
      <div className="monitor-header">
        <h2>📊 Monitor de Rendimiento</h2>
        <div className="header-actions">
          <button
            className={`run-tests-btn ${isRunning ? 'running' : ''}`}
            onClick={runPerformanceTests}
            disabled={isRunning}
          >
            {isRunning ? '🔄 Ejecutando...' : '🚀 Ejecutar Pruebas'}
          </button>
          <span className="last-update">
            Última actualización: {lastUpdate.toLocaleTimeString()}
          </span>
        </div>
      </div>

      {/* Métricas en tiempo real */}
      <div className="metrics-grid">
        <div className="metric-card">
          <h3>⚡ Latencia</h3>
          <div className="metric-content">
            <div className="metric-item">
              <span>RPC Promedio:</span>
              <span>{Object.values(metrics.latency.rpc).length > 0 
                ? `${(Object.values(metrics.latency.rpc).reduce((a, b) => a + b, 0) / Object.values(metrics.latency.rpc).length).toFixed(2)}ms`
                : 'N/A'
              }</span>
            </div>
            <div className="metric-item">
              <span>WebSocket:</span>
              <span>{Object.values(metrics.latency.websocket).length > 0 
                ? `${(Object.values(metrics.latency.websocket).reduce((a, b) => a + b, 0) / Object.values(metrics.latency.websocket).length).toFixed(2)}ms`
                : 'N/A'
              }</span>
            </div>
            <div className="metric-item">
              <span>Arbitraje:</span>
              <span>{metrics.latency.arbitrage > 0 ? `${metrics.latency.arbitrage.toFixed(2)}ms` : 'N/A'}</span>
            </div>
            <div className="metric-item">
              <span>Ejecución:</span>
              <span>{metrics.latency.execution > 0 ? `${metrics.latency.execution.toFixed(2)}ms` : 'N/A'}</span>
            </div>
          </div>
        </div>

        <div className="metric-card">
          <h3>📈 Throughput</h3>
          <div className="metric-content">
            <div className="metric-item">
              <span>Pools/seg:</span>
              <span>{metrics.throughput.poolsPerSecond.toFixed(2)}</span>
            </div>
            <div className="metric-item">
              <span>Oportunidades/seg:</span>
              <span>{metrics.throughput.opportunitiesPerSecond.toFixed(2)}</span>
            </div>
            <div className="metric-item">
              <span>Transacciones/seg:</span>
              <span>{metrics.throughput.transactionsPerSecond.toFixed(2)}</span>
            </div>
            <div className="metric-item">
              <span>Datos/seg:</span>
              <span>{metrics.throughput.dataPointsPerSecond.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="metric-card">
          <h3>🔧 Eficiencia</h3>
          <div className="metric-content">
            <div className="metric-item">
              <span>CPU:</span>
              <span>{metrics.efficiency.cpuUsage.toFixed(1)}%</span>
            </div>
            <div className="metric-item">
              <span>Memoria:</span>
              <span>{metrics.efficiency.memoryUsage.toFixed(1)}%</span>
            </div>
            <div className="metric-item">
              <span>Red:</span>
              <span>{metrics.efficiency.networkUsage.toFixed(0)} KB/s</span>
            </div>
            <div className="metric-item">
              <span>Cache Hit:</span>
              <span>{metrics.efficiency.cacheHitRate.toFixed(1)}%</span>
            </div>
          </div>
        </div>

        <div className="metric-card">
          <h3>🛡️ Confiabilidad</h3>
          <div className="metric-content">
            <div className="metric-item">
              <span>Uptime:</span>
              <span>{metrics.reliability.uptime.toFixed(2)}%</span>
            </div>
            <div className="metric-item">
              <span>Error Rate:</span>
              <span>{metrics.reliability.errorRate.toFixed(2)}%</span>
            </div>
            <div className="metric-item">
              <span>Success Rate:</span>
              <span>{metrics.reliability.successRate.toFixed(2)}%</span>
            </div>
            <div className="metric-item">
              <span>Reconexiones:</span>
              <span>{metrics.reliability.reconnectionAttempts}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Resultados de las pruebas */}
      {testResults.length > 0 && (
        <div className="test-results">
          <h3>🧪 Resultados de las Pruebas</h3>
          <div className="results-grid">
            {testResults.map((result, index) => (
              <div key={index} className={`result-card ${result.success ? 'success' : 'error'}`}>
                <div className="result-header">
                  <h4>{result.name}</h4>
                  <span className={`status ${getStatusColor(result.success)}`}>
                    {result.success ? '✅' : '❌'}
                  </span>
                </div>
                <div className="result-details">
                  <div className="detail-item">
                    <span>Duración:</span>
                    <span>{formatDuration(result.duration)}</span>
                  </div>
                  {result.error && (
                    <div className="detail-item error">
                      <span>Error:</span>
                      <span>{result.error}</span>
                    </div>
                  )}
                  {result.success && result.metrics && (
                    <div className="detail-item">
                      <span>Métricas:</span>
                      <span>{JSON.stringify(result.metrics).substring(0, 50)}...</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Gráficos de rendimiento */}
      <div className="performance-charts">
        <h3>📊 Gráficos de Rendimiento</h3>
        <div className="charts-grid">
          <div className="chart-container">
            <h4>Latencia por Blockchain</h4>
            <div className="chart-placeholder">
              Gráfico de latencia RPC por blockchain
            </div>
          </div>
          <div className="chart-container">
            <h4>Throughput en Tiempo Real</h4>
            <div className="chart-placeholder">
              Gráfico de throughput por segundo
            </div>
          </div>
          <div className="chart-container">
            <h4>Uso de Recursos</h4>
            <div className="chart-placeholder">
              Gráfico de CPU y memoria
            </div>
          </div>
          <div className="chart-container">
            <h4>Estado de Conexiones</h4>
            <div className="chart-placeholder">
              Gráfico de estado de conexiones
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
