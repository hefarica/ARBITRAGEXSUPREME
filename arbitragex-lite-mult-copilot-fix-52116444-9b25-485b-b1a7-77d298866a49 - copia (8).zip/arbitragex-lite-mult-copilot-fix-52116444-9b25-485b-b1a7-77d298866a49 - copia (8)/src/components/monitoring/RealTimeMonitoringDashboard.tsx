/**
 * RealTimeMonitoringDashboard.tsx
 * Dashboard de monitoreo en tiempo real para ArbitrageX Pro 2025
 * RESUELVE: Problema #21 - Dashboard de monitoreo completo
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  DollarSign,
  Cpu,
  MemoryStick,
  Network,
  HardDrive,
  Clock,
  Zap
} from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: number | string;
  unit?: string;
  threshold?: number;
  icon?: React.ReactNode;
  critical?: boolean;
  trend?: 'up' | 'down' | 'stable';
  description?: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ 
  title, 
  value, 
  unit = '', 
  threshold, 
  icon, 
  critical, 
  trend,
  description 
}) => {
  const isNumeric = typeof value === 'number';
  const isOverThreshold = threshold && isNumeric && value > threshold;
  const isWarning = isOverThreshold || critical;

  const getTrendIcon = () => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'down': return <TrendingDown className="h-4 w-4 text-red-500" />;
      default: return null;
    }
  };

  return (
    <Card className={`${isWarning ? 'border-red-500 bg-red-50' : 'border-gray-200'}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between space-y-0 pb-2">
          <div className="flex items-center space-x-2">
            {icon}
            <h3 className="text-sm font-medium text-gray-600">{title}</h3>
          </div>
          {getTrendIcon()}
        </div>
        <div className="flex items-baseline space-x-2">
          <div className={`text-2xl font-bold ${isWarning ? 'text-red-600' : 'text-gray-900'}`}>
            {isNumeric ? value.toFixed(1) : value}
          </div>
          <span className="text-sm text-gray-500">{unit}</span>
        </div>
        {description && (
          <p className="text-xs text-gray-500 mt-1">{description}</p>
        )}
        {threshold && isOverThreshold && (
          <div className="mt-2">
            <Badge variant="destructive" className="text-xs">
              Umbral: {threshold}{unit}
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

interface AlertsPanelProps {
  alerts: any[];
  onResolveAlert: (alertId: string) => void;
}

const AlertsPanel: React.FC<AlertsPanelProps> = ({ alerts, onResolveAlert }) => {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-100 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-100 border-blue-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  if (alerts.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Sin Alertas Activas
          </h3>
          <p className="text-gray-500">
            Todos los sistemas funcionan normalmente
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {alerts.map((alert) => (
        <Card key={alert.id} className={`border-l-4 ${getSeverityColor(alert.severity)}`}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <AlertTriangle className="h-5 w-5" />
                  <Badge className={getSeverityColor(alert.severity)}>
                    {alert.severity.toUpperCase()}
                  </Badge>
                  <span className="text-sm text-gray-500">
                    {new Date(alert.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <h4 className="text-sm font-medium text-gray-900 mb-1">
                  {alert.message}
                </h4>
                {alert.actions && alert.actions.length > 0 && (
                  <p className="text-xs text-gray-600">
                    Acciones: {alert.actions.join(', ')}
                  </p>
                )}
              </div>
              {!alert.resolved && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onResolveAlert(alert.id)}
                  className="ml-4"
                >
                  Resolver
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

const PerformanceChart: React.FC<{ data: any[] }> = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
        <p className="text-gray-500">No hay datos de performance disponibles</p>
      </div>
    );
  }

  // Gráfico simple con SVG
  const maxValue = Math.max(...data.map(d => d.value));
  const width = 800;
  const height = 200;
  const padding = 40;

  const xScale = (width - 2 * padding) / (data.length - 1);
  const yScale = (height - 2 * padding) / maxValue;

  const pathData = data
    .map((d, i) => `${i === 0 ? 'M' : 'L'} ${padding + i * xScale} ${height - padding - d.value * yScale}`)
    .join(' ');

  return (
    <div className="bg-white p-4 rounded-lg border">
      <h3 className="text-lg font-medium mb-4">Performance en Tiempo Real</h3>
      <svg width={width} height={height} className="w-full">
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
          </linearGradient>
        </defs>
        
        {/* Grid lines */}
        {[...Array(5)].map((_, i) => (
          <line
            key={i}
            x1={padding}
            y1={padding + i * (height - 2 * padding) / 4}
            x2={width - padding}
            y2={padding + i * (height - 2 * padding) / 4}
            stroke="#e5e7eb"
            strokeWidth="1"
          />
        ))}
        
        {/* Area fill */}
        <path
          d={`${pathData} L ${width - padding} ${height - padding} L ${padding} ${height - padding} Z`}
          fill="url(#gradient)"
        />
        
        {/* Line */}
        <path
          d={pathData}
          fill="none"
          stroke="#3b82f6"
          strokeWidth="2"
        />
        
        {/* Data points */}
        {data.map((d, i) => (
          <circle
            key={i}
            cx={padding + i * xScale}
            cy={height - padding - d.value * yScale}
            r="4"
            fill="#3b82f6"
          />
        ))}
      </svg>
    </div>
  );
};

export const RealTimeMonitoringDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<any>(null);
  const [financialMetrics, setFinancialMetrics] = useState<any>(null);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [performanceHistory, setPerformanceHistory] = useState<any[]>([]);
  const [isEmergencyStop, setIsEmergencyStop] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  // Simular datos de métricas (en producción vendrían de la API)
  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        // Métricas de performance
        const performanceResponse = await fetch('/api/metrics/performance');
        const performanceData = await performanceResponse.json();
        setMetrics(performanceData);

        // Métricas financieras
        const financialResponse = await fetch('/api/metrics/financial');
        const financialData = await financialResponse.json();
        setFinancialMetrics(financialData);

        // Alertas
        const alertsResponse = await fetch('/api/alerts');
        const alertsData = await alertsResponse.json();
        setAlerts(alertsData);

        // Actualizar histórico de performance
        setPerformanceHistory(prev => {
          const newData = [...prev, {
            timestamp: Date.now(),
            value: performanceData.performance?.cpuUsage || 0
          }].slice(-50); // Mantener últimos 50 puntos
          return newData;
        });

        setLastUpdate(new Date());
      } catch (error) {
        console.error('Error fetching metrics:', error);
      }
    };

    // Fetch inicial
    fetchMetrics();

    // Actualizar cada 5 segundos
    const interval = setInterval(fetchMetrics, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleEmergencyStop = () => {
    setIsEmergencyStop(!isEmergencyStop);
    // TODO: Integrar con sistema real de emergency stop
    console.log(isEmergencyStop ? 'Emergency stop desactivado' : 'Emergency stop activado');
  };

  const handleResolveAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
    // TODO: Marcar alerta como resuelta en el backend
  };

  const getSystemStatus = () => {
    if (isEmergencyStop) return { status: 'stopped', color: 'red', text: 'Sistema Detenido' };
    if (alerts.some(a => a.severity === 'critical')) return { status: 'critical', color: 'red', text: 'Estado Crítico' };
    if (alerts.some(a => a.severity === 'high')) return { status: 'warning', color: 'orange', text: 'Advertencias' };
    return { status: 'healthy', color: 'green', text: 'Sistema Saludable' };
  };

  const systemStatus = getSystemStatus();

  if (!metrics) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Activity className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-500" />
          <p className="text-gray-600">Cargando métricas del sistema...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Monitoreo en Tiempo Real
          </h1>
          <p className="text-gray-600">
            Última actualización: {lastUpdate.toLocaleTimeString()}
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <Badge className={`bg-${systemStatus.color}-100 text-${systemStatus.color}-800`}>
            {systemStatus.text}
          </Badge>
          
          <Button
            variant={isEmergencyStop ? "default" : "destructive"}
            onClick={handleEmergencyStop}
            className="flex items-center space-x-2"
          >
            {isEmergencyStop ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
            <span>{isEmergencyStop ? 'Reanudar Sistema' : 'Parada de Emergencia'}</span>
          </Button>
        </div>
      </div>

      {/* Tabs principales */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Vista General</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="financial">Financiero</TabsTrigger>
          <TabsTrigger value="alerts">Alertas</TabsTrigger>
        </TabsList>

        {/* Vista General */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard
              title="CPU Usage"
              value={metrics.performance?.cpuUsage || 0}
              unit="%"
              threshold={80}
              icon={<Cpu className="h-4 w-4 text-blue-500" />}
              trend="stable"
              description="Uso de procesador"
            />
            
            <MetricCard
              title="Memory Usage"
              value={metrics.performance?.memoryUsage?.percentage || 0}
              unit="%"
              threshold={85}
              icon={<MemoryStick className="h-4 w-4 text-green-500" />}
              trend="up"
              description="Uso de memoria RAM"
            />
            
            <MetricCard
              title="Response Time"
              value={metrics.performance?.avgResponseTime || 0}
              unit="ms"
              threshold={2000}
              icon={<Clock className="h-4 w-4 text-purple-500" />}
              trend="down"
              description="Tiempo promedio de respuesta"
            />
            
            <MetricCard
              title="Error Rate"
              value={metrics.performance?.errorRate || 0}
              unit="%"
              threshold={10}
              icon={<AlertTriangle className="h-4 w-4 text-red-500" />}
              critical={metrics.performance?.errorRate > 10}
              trend="stable"
              description="Tasa de errores"
            />
          </div>

          {/* Métricas Financieras Rápidas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MetricCard
              title="Daily Profit"
              value={financialMetrics?.dailyProfit || 0}
              unit="USD"
              icon={<DollarSign className="h-4 w-4 text-green-500" />}
              critical={financialMetrics?.dailyProfit < -500}
              trend={financialMetrics?.dailyProfit > 0 ? 'up' : 'down'}
              description="Ganancia del día"
            />
            
            <MetricCard
              title="Success Rate"
              value={financialMetrics?.successRate || 0}
              unit="%"
              threshold={90}
              icon={<TrendingUp className="h-4 w-4 text-blue-500" />}
              description="Tasa de éxito de trades"
            />
            
            <MetricCard
              title="Active Trades"
              value={financialMetrics?.totalTrades || 0}
              icon={<Activity className="h-4 w-4 text-purple-500" />}
              description="Trades ejecutados hoy"
            />
          </div>

          {/* Conectividad */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Network className="h-5 w-5" />
                <span>Estado de Conectividad</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {metrics.health?.rpcConnections?.map((conn: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{conn.name}</p>
                      <p className="text-xs text-gray-500">{conn.latency}ms</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${
                        conn.status === 'healthy' ? 'bg-green-500' :
                        conn.status === 'degraded' ? 'bg-yellow-500' : 'bg-red-500'
                      }`} />
                      <span className="text-xs capitalize">{conn.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance */}
        <TabsContent value="performance" className="space-y-6">
          <PerformanceChart data={performanceHistory} />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Recursos del Sistema</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">CPU Usage</span>
                  <span className="text-sm font-medium">
                    {metrics.performance?.cpuUsage?.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${metrics.performance?.cpuUsage || 0}%` }}
                  />
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm">Memory Usage</span>
                  <span className="text-sm font-medium">
                    {metrics.performance?.memoryUsage?.percentage?.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${metrics.performance?.memoryUsage?.percentage || 0}%` }}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Throughput</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-2">
                  <div className="text-3xl font-bold text-blue-600">
                    {metrics.performance?.throughput?.toFixed(1) || 0}
                  </div>
                  <div className="text-sm text-gray-500">req/s</div>
                  <div className="text-xs text-gray-400">
                    Uptime: {Math.floor(metrics.uptime / 3600)}h {Math.floor((metrics.uptime % 3600) / 60)}m
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Financiero */}
        <TabsContent value="financial" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MetricCard
              title="Portfolio Value"
              value={financialMetrics?.portfolioValue || 0}
              unit="USD"
              icon={<DollarSign className="h-4 w-4 text-green-500" />}
              description="Valor total del portfolio"
            />
            
            <MetricCard
              title="Total ROI"
              value={financialMetrics?.totalROI || 0}
              unit="%"
              icon={<TrendingUp className="h-4 w-4 text-blue-500" />}
              description="Retorno total de inversión"
            />
            
            <MetricCard
              title="Average Profit"
              value={financialMetrics?.averageProfit || 0}
              unit="USD"
              icon={<Zap className="h-4 w-4 text-purple-500" />}
              description="Ganancia promedio por trade"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Resumen de Trading</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">
                    {financialMetrics?.totalTrades || 0}
                  </div>
                  <div className="text-sm text-gray-500">Total Trades</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-600">
                    {financialMetrics?.successRate?.toFixed(1) || 0}%
                  </div>
                  <div className="text-sm text-gray-500">Success Rate</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">
                    ${financialMetrics?.dailyProfit?.toFixed(2) || 0}
                  </div>
                  <div className="text-sm text-gray-500">Daily P&L</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-orange-600">
                    {financialMetrics?.totalROI?.toFixed(1) || 0}%
                  </div>
                  <div className="text-sm text-gray-500">Total ROI</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Alertas */}
        <TabsContent value="alerts" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Alertas del Sistema</h2>
            <Badge variant="outline">
              {alerts.length} alertas activas
            </Badge>
          </div>
          
          <AlertsPanel alerts={alerts} onResolveAlert={handleResolveAlert} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RealTimeMonitoringDashboard;
