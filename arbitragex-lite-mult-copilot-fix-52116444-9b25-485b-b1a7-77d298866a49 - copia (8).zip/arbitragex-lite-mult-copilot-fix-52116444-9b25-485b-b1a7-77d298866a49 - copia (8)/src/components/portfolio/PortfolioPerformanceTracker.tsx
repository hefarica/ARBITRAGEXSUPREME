import { useState, useMemo } from 'react'
import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  TrendUp, 
  TrendDown, 
  Target, 
  Shield, 
  Activity,
  CalendarBlank,
  ChartBar3,
  PieChart,
  LineChart,
  WarningCircle,
  Medal,
  Lightning
} from '@phosphor-icons/react'

type PerformancePeriod = '1D' | '7D' | '30D' | '90D' | 'ALL'

interface PerformanceMetrics {
  totalReturn: number
  annualizedReturn: number
  volatility: number
  sharpeRatio: number
  sortinoRatio: number
  maxDrawdown: number
  calmarRatio: number
  winRate: number
  profitFactor: number
  avgWinSize: number
  avgLossSize: number
  consecutiveWins: number
  consecutiveLosses: number
  largestWin: number
  largestLoss: number
  recoveryFactor: number
  kellyPercentage: number
  valueAtRisk: number
  expectedShortfall: number
  beta: number
  alpha: number
  informationRatio: number
  trackingError: number
}

interface RiskMetrics {
  portfolioRisk: 'Low' | 'Medium' | 'High' | 'Critical'
  diversificationScore: number
  concentrationRisk: number
  liquidityRisk: number
  marketRisk: number
  correlationRisk: number
  overallRiskScore: number
}

export function PortfolioPerformanceTracker() {
  const { state } = useSimulation()
  const [selectedPeriod, setSelectedPeriod] = useState<PerformancePeriod>('30D')
  const [activeView, setActiveView] = useState<'overview' | 'metrics' | 'risk' | 'attribution'>('overview')

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value)
  }

  const formatPercentage = (value: number, decimals = 2) => {
    return `${value.toFixed(decimals)}%`
  }

  // Enhanced performance calculations
  const performanceMetrics = useMemo((): PerformanceMetrics => {
    if (state.trades.length === 0) {
      return {
        totalReturn: 0, annualizedReturn: 0, volatility: 0, sharpeRatio: 0, sortinoRatio: 0,
        maxDrawdown: 0, calmarRatio: 0, winRate: 0, profitFactor: 0, avgWinSize: 0,
        avgLossSize: 0, consecutiveWins: 0, consecutiveLosses: 0, largestWin: 0,
        largestLoss: 0, recoveryFactor: 0, kellyPercentage: 0, valueAtRisk: 0,
        expectedShortfall: 0, beta: 0, alpha: 0, informationRatio: 0, trackingError: 0
      }
    }

    const sortedTrades = Array.from(state.trades).reverse()
    const returns = sortedTrades.map(trade => (trade.profit - trade.fees) / trade.amount)
    const winningTrades = sortedTrades.filter(t => t.profit > 0)
    const losingTrades = sortedTrades.filter(t => t.profit <= 0)
    
    // Basic metrics
    const totalReturn = ((state.balance - 10000) / 10000) * 100
    const tradingDays = Math.max(1, (Date.now() - sortedTrades[0].timestamp) / (1000 * 60 * 60 * 24))
    const annualizedReturn = totalReturn * (365 / tradingDays)
    
    // Volatility calculations
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length
    const volatility = Math.sqrt(variance) * Math.sqrt(252) * 100 // Annualized
    
    // Risk-adjusted returns
    const sharpeRatio = volatility > 0 ? (annualizedReturn - 2) / volatility : 0 // Assuming 2% risk-free rate
    
    const downReturns = returns.filter(r => r < 0)
    const downVariance = downReturns.length > 0 ? 
      downReturns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / downReturns.length : 0
    const downVolatility = Math.sqrt(downVariance) * Math.sqrt(252) * 100
    const sortinoRatio = downVolatility > 0 ? (annualizedReturn - 2) / downVolatility : 0
    
    // Drawdown analysis
    let runningBalance = 10000
    let maxBalance = 10000
    let maxDrawdown = 0
    let currentDrawdown = 0
    
    sortedTrades.forEach(trade => {
      runningBalance += trade.profit - trade.fees
      if (runningBalance > maxBalance) {
        maxBalance = runningBalance
        currentDrawdown = 0
      } else {
        currentDrawdown = (maxBalance - runningBalance) / maxBalance
        maxDrawdown = Math.max(maxDrawdown, currentDrawdown)
      }
    })
    
    const calmarRatio = maxDrawdown > 0 ? Math.abs(annualizedReturn) / (maxDrawdown * 100) : 0
    
    // Trading performance
    const winRate = (winningTrades.length / sortedTrades.length) * 100
    const totalWins = winningTrades.reduce((sum, t) => sum + t.profit, 0)
    const totalLosses = Math.abs(losingTrades.reduce((sum, t) => sum + t.profit, 0))
    const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0
    
    const avgWinSize = winningTrades.length > 0 ? totalWins / winningTrades.length : 0
    const avgLossSize = losingTrades.length > 0 ? totalLosses / losingTrades.length : 0
    
    // Consecutive analysis
    let consecutiveWins = 0
    let consecutiveLosses = 0
    let currentWinStreak = 0
    let currentLossStreak = 0
    
    sortedTrades.forEach(trade => {
      if (trade.profit > 0) {
        currentWinStreak++
        currentLossStreak = 0
        consecutiveWins = Math.max(consecutiveWins, currentWinStreak)
      } else {
        currentLossStreak++
        currentWinStreak = 0
        consecutiveLosses = Math.max(consecutiveLosses, currentLossStreak)
      }
    })
    
    const largestWin = winningTrades.length > 0 ? Math.max(...winningTrades.map(t => t.profit)) : 0
    const largestLoss = losingTrades.length > 0 ? Math.abs(Math.min(...losingTrades.map(t => t.profit))) : 0
    
    // Advanced metrics
    const recoveryFactor = maxDrawdown > 0 ? Math.abs(totalReturn) / (maxDrawdown * 100) : 0
    
    // Kelly Criterion
    const kellyPercentage = winRate > 0 && avgLossSize > 0 ? 
      ((winRate / 100) - ((100 - winRate) / 100) / (avgWinSize / avgLossSize)) * 100 : 0
    
    // Value at Risk (95% confidence)
    const sortedReturns = [...returns].sort((a, b) => a - b)
    const varIndex = Math.floor(returns.length * 0.05)
    const valueAtRisk = sortedReturns[varIndex] ? Math.abs(sortedReturns[varIndex] * 100) : 0
    
    // Expected Shortfall (Conditional VaR)
    const worstReturns = sortedReturns.slice(0, varIndex + 1)
    const expectedShortfall = worstReturns.length > 0 ? 
      Math.abs(worstReturns.reduce((sum, r) => sum + r, 0) / worstReturns.length * 100) : 0
    
    // Market correlation metrics (simplified for simulation)
    const beta = 0.8 + Math.random() * 0.4 // Simulated beta between 0.8-1.2
    const alpha = annualizedReturn - (2 + beta * 6) // Assuming market return of 8%
    const trackingError = volatility * 0.3 // Simplified tracking error
    const informationRatio = trackingError > 0 ? alpha / trackingError : 0

    return {
      totalReturn,
      annualizedReturn,
      volatility,
      sharpeRatio,
      sortinoRatio,
      maxDrawdown: maxDrawdown * 100,
      calmarRatio,
      winRate,
      profitFactor,
      avgWinSize,
      avgLossSize,
      consecutiveWins,
      consecutiveLosses,
      largestWin,
      largestLoss,
      recoveryFactor,
      kellyPercentage,
      valueAtRisk,
      expectedShortfall,
      beta,
      alpha,
      informationRatio,
      trackingError
    }
  }, [state.trades, state.balance])

  // Risk assessment
  const riskMetrics = useMemo((): RiskMetrics => {
    const { volatility, maxDrawdown, sharpeRatio } = performanceMetrics
    
    // Strategy diversification
    const strategyTypes = new Set(state.trades.map(t => t.type))
    const diversificationScore = Math.min(100, (strategyTypes.size / 5) * 100) // Max 5 strategy types
    
    // Concentration risk
    const totalSpeakerHigh = state.trades.reduce((sum, t) => sum + t.amount, 0)
    const largestTrade = totalSpeakerHigh > 0 ? Math.max(...state.trades.map(t => t.amount)) / totalSpeakerHigh * 100 : 0
    const concentrationRisk = largestTrade
    
    // Overall risk scoring
    let riskScore = 0
    riskScore += Math.min(25, volatility / 2) // Volatility component (max 25 points)
    riskScore += Math.min(25, maxDrawdown) // Drawdown component (max 25 points)
    riskScore += Math.min(25, concentrationRisk) // Concentration component (max 25 points)
    riskScore += Math.min(25, 100 - diversificationScore) // Diversification component (max 25 points)
    
    const portfolioRisk: RiskMetrics['portfolioRisk'] = 
      riskScore < 25 ? 'Low' :
      riskScore < 50 ? 'Medium' :
      riskScore < 75 ? 'High' : 'Critical'
    
    return {
      portfolioRisk,
      diversificationScore,
      concentrationRisk,
      liquidityRisk: Math.random() * 30, // Simulated
      marketRisk: Math.abs(performanceMetrics.beta - 1) * 50,
      correlationRisk: Math.random() * 40, // Simulated
      overallRiskScore: riskScore
    }
  }, [performanceMetrics, state.trades])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Portfolio Performance Tracker</h2>
          <p className="text-muted-foreground">Advanced analytics and risk assessment</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Select value={selectedPeriod} onValueChange={(value: PerformancePeriod) => setSelectedPeriod(value)}>
            <SelectTrigger className="w-20">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1D">1D</SelectItem>
              <SelectItem value="7D">7D</SelectItem>
              <SelectItem value="30D">30D</SelectItem>
              <SelectItem value="90D">90D</SelectItem>
              <SelectItem value="ALL">All</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            size="sm"
            className="gap-2"
          >
            <CalendarBlank size={16} />
            Export Report
          </Button>
        </div>
      </div>

      {/* Risk Alert */}
      {riskMetrics.portfolioRisk === 'High' || riskMetrics.portfolioRisk === 'Critical' && (
        <Card className="border-destructive bg-destructive/5">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <WarningCircle size={20} className="text-destructive flex-shrink-0" />
              <div>
                <p className="font-medium text-destructive">
                  {riskMetrics.portfolioRisk} Risk Portfolio Detected
                </p>
                <p className="text-sm text-muted-foreground">
                  Risk Score: {riskMetrics.overallRiskScore.toFixed(1)}/100. Consider risk management review.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Performance Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Return</p>
                <p className={`text-2xl font-bold ${performanceMetrics.totalReturn >= 0 ? 'profit' : 'loss'}`}>
                  {formatPercentage(performanceMetrics.totalReturn)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Annualized: {formatPercentage(performanceMetrics.annualizedReturn)}
                </p>
              </div>
              <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                performanceMetrics.totalReturn >= 0 ? 'bg-profit/10' : 'bg-destructive/10'
              }`}>
                {performanceMetrics.totalReturn >= 0 ? 
                  <TrendUp size={24} className="text-profit" /> : 
                  <TrendDown size={24} className="text-destructive" />
                }
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Sharpe Ratio</p>
                <p className="text-2xl font-bold">{performanceMetrics.sharpeRatio.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Risk-adj. return
                </p>
              </div>
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Target size={24} className="text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Max Drawdown</p>
                <p className={`text-2xl font-bold ${performanceMetrics.maxDrawdown > 15 ? 'loss' : 'text-foreground'}`}>
                  {formatPercentage(performanceMetrics.maxDrawdown)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Recovery: {performanceMetrics.recoveryFactor.toFixed(2)}x
                </p>
              </div>
              <div className="h-12 w-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                <Shield size={24} className="text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Win Rate</p>
                <p className="text-2xl font-bold">{formatPercentage(performanceMetrics.winRate)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Profit Factor: {performanceMetrics.profitFactor === Infinity ? '∞' : performanceMetrics.profitFactor.toFixed(2)}
                </p>
              </div>
              <div className="h-12 w-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <Medal size={24} className="text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analysis Tabs */}
      <Tabs value={activeView} onValueChange={(value: any) => setActiveView(value)} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="gap-2">
            <BarChart3 size={16} />
            Overview
          </TabsTrigger>
          <TabsTrigger value="metrics" className="gap-2">
            <LineChart size={16} />
            Metrics
          </TabsTrigger>
          <TabsTrigger value="risk" className="gap-2">
            <Shield size={16} />
            Risk
          </TabsTrigger>
          <TabsTrigger value="attribution" className="gap-2">
            <PieChart size={16} />
            Attribution
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Highlights</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-profit/10 rounded-lg">
                    <p className="text-xl font-bold text-profit">{formatCurrency(performanceMetrics.avgWinSize)}</p>
                    <p className="text-sm text-muted-foreground">Avg Win</p>
                  </div>
                  <div className="text-center p-4 bg-destructive/10 rounded-lg">
                    <p className="text-xl font-bold text-destructive">{formatCurrency(performanceMetrics.avgLossSize)}</p>
                    <p className="text-sm text-muted-foreground">Avg Loss</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Largest Win</span>
                    <span className="font-semibold profit">{formatCurrency(performanceMetrics.largestWin)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Largest Loss</span>
                    <span className="font-semibold loss">{formatCurrency(performanceMetrics.largestLoss)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Best Win Streak</span>
                    <span className="font-semibold">{performanceMetrics.consecutiveWins}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Worst Loss Streak</span>
                    <span className="font-semibold">{performanceMetrics.consecutiveLosses}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Risk Overview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Portfolio Risk</span>
                  <Badge className={
                    riskMetrics.portfolioRisk === 'Low' ? 'bg-profit text-profit-foreground' :
                    riskMetrics.portfolioRisk === 'Medium' ? 'bg-warning text-warning-foreground' :
                    'bg-destructive text-destructive-foreground'
                  }>
                    {riskMetrics.portfolioRisk}
                  </Badge>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Diversification</span>
                    <span className="font-semibold">{formatPercentage(riskMetrics.diversificationScore, 0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Volatility</span>
                    <span className="font-semibold">{formatPercentage(performanceMetrics.volatility)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Value at Risk (95%)</span>
                    <span className="font-semibold loss">{formatPercentage(performanceMetrics.valueAtRisk)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Kelly %</span>
                    <span className="font-semibold">{formatPercentage(performanceMetrics.kellyPercentage)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Return Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Return</span>
                  <span className="font-semibold">{formatPercentage(performanceMetrics.totalReturn)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Annualized Return</span>
                  <span className="font-semibold">{formatPercentage(performanceMetrics.annualizedReturn)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Alpha</span>
                  <span className="font-semibold">{formatPercentage(performanceMetrics.alpha)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Beta</span>
                  <span className="font-semibold">{performanceMetrics.beta.toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Risk-Adjusted Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Sharpe Ratio</span>
                  <span className="font-semibold">{performanceMetrics.sharpeRatio.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Sortino Ratio</span>
                  <span className="font-semibold">{performanceMetrics.sortinoRatio.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Calmar Ratio</span>
                  <span className="font-semibold">{performanceMetrics.calmarRatio.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Information Ratio</span>
                  <span className="font-semibold">{performanceMetrics.informationRatio.toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Risk Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Volatility</span>
                  <span className="font-semibold">{formatPercentage(performanceMetrics.volatility)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Max Drawdown</span>
                  <span className="font-semibold">{formatPercentage(performanceMetrics.maxDrawdown)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">VaR (95%)</span>
                  <span className="font-semibold">{formatPercentage(performanceMetrics.valueAtRisk)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Expected Shortfall</span>
                  <span className="font-semibold">{formatPercentage(performanceMetrics.expectedShortfall)}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Risk Assessment</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Overall Risk</span>
                    <Badge className={
                      riskMetrics.portfolioRisk === 'Low' ? 'bg-profit text-profit-foreground' :
                      riskMetrics.portfolioRisk === 'Medium' ? 'bg-warning text-warning-foreground' :
                      'bg-destructive text-destructive-foreground'
                    }>
                      {riskMetrics.portfolioRisk}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Risk Score</span>
                    <span className="font-semibold">{riskMetrics.overallRiskScore.toFixed(1)}/100</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Diversification</span>
                    <span className="font-semibold profit">{formatPercentage(riskMetrics.diversificationScore, 0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Concentration Risk</span>
                    <span className="font-semibold warning">{formatPercentage(riskMetrics.concentrationRisk)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Market Risk</span>
                    <span className="font-semibold">{formatPercentage(riskMetrics.marketRisk)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Risk Recommendations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {riskMetrics.diversificationScore < 60 && (
                  <div className="p-3 bg-warning/10 rounded-lg border border-warning/20">
                    <div className="flex items-start gap-2">
                      <Lightning size={16} className="text-warning mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-warning">Improve Diversification</p>
                        <p className="text-sm text-muted-foreground">Consider adding more strategy types to reduce concentration risk.</p>
                      </div>
                    </div>
                  </div>
                )}
                
                {performanceMetrics.maxDrawdown > 15 && (
                  <div className="p-3 bg-destructive/10 rounded-lg border border-destructive/20">
                    <div className="flex items-start gap-2">
                      <WarningCircle size={16} className="text-destructive mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-destructive">High Drawdown Risk</p>
                        <p className="text-sm text-muted-foreground">Implement stricter stop-loss rules to limit downside exposure.</p>
                      </div>
                    </div>
                  </div>
                )}
                
                {performanceMetrics.kellyPercentage > 25 && (
                  <div className="p-3 bg-warning/10 rounded-lg border border-warning/20">
                    <div className="flex items-start gap-2">
                      <Target size={16} className="text-warning mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-warning">Position Sizing</p>
                        <p className="text-sm text-muted-foreground">Kelly criterion suggests reducing position sizes for optimal growth.</p>
                      </div>
                    </div>
                  </div>
                )}
                
                {riskMetrics.portfolioRisk === 'Low' && performanceMetrics.totalReturn > 0 && (
                  <div className="p-3 bg-profit/10 rounded-lg border border-profit/20">
                    <div className="flex items-start gap-2">
                      <Medal size={16} className="text-profit mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-profit">Well-Managed Risk</p>
                        <p className="text-sm text-muted-foreground">Portfolio shows good risk management with positive returns.</p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="attribution" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance Attribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <PieChart size={48} className="mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">Strategy Attribution Analysis</p>
                <p className="text-sm">Detailed breakdown of strategy performance contribution coming soon</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}