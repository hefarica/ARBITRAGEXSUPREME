import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Wallet,
  TrendUp,
  TrendDown,
  Repeat,
  Eye,
  EyeSlash,
  Circle,
  CheckCircle,
  WarningCircle,
  CurrencyDollar,
  Coins,
  Globe,
  ArrowUpDown,
  Lightning,
  Clock,
  WifiHigh,
  WifiSlash
} from '@phosphor-icons/react'
import { useKV } from '@/hooks/useKV'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar } from 'recharts'
import { toast } from 'sonner'

interface PortfolioBalanceTrackerProps {
  environment: 'test' | 'prod'
}

// Token Balance Interface
interface TokenBalance {
  contract_address: string
  symbol: string
  name: string
  decimals: number
  balance: string
  balance_formatted: string
  price_usd: number
  price_cop: number
  total_value_usd: number
  total_value_cop: number
  last_updated: Date
  price_source: string
  change_24h?: number
}

// LP Token Balance Interface
interface LPTokenBalance {
  lp_address: string
  dex_name: string
  pair_symbol: string
  token0: {
    address: string
    symbol: string
    balance: string
    value_usd: number
    value_cop: number
  }
  token1: {
    address: string
    symbol: string
    balance: string
    value_usd: number
    value_cop: number
  }
  lp_balance: string
  total_value_usd: number
  total_value_cop: number
  apy_percent?: number
  last_updated: Date
}

// Blockchain Balance Interface
interface BlockchainBalance {
  blockchain_name: string
  network_status: 'connected' | 'disconnected' | 'syncing' | 'error'
  last_sync: Date
  native_token: {
    symbol: string
    balance: string
    balance_formatted: string
    usd_value: number
    cop_value: number
    last_updated: Date
    change_24h?: number
  }
  tokens: TokenBalance[]
  lp_tokens: LPTokenBalance[]
  totals: {
    total_usd: number
    total_cop: number
    token_count: number
    lp_token_count: number
  }
}

// Mock data for demonstration - replace with real API calls
const generateMockBlockchainBalance = (blockchain: string, environment: 'test' | 'prod'): BlockchainBalance => {
  const isTestnet = environment === 'test'
  
  const nativeTokens = {
    ethereum: { symbol: 'ETH', price: 2300 },
    polygon: { symbol: 'MATIC', price: 0.8 },
    bsc: { symbol: 'BNB', price: 310 },
    arbitrum: { symbol: 'ETH', price: 2300 },
    optimism: { symbol: 'ETH', price: 2300 },
    avalanche: { symbol: 'AVAX', price: 27 },
    solana: { symbol: 'SOL', price: 98 }
  }
  
  const token = nativeTokens[blockchain as keyof typeof nativeTokens] || { symbol: 'TOKEN', price: 1 }
  const balance = isTestnet ? Math.random() * 0.1 : Math.random() * 2
  const balanceFormatted = balance.toFixed(6)
  const usdValue = balance * token.price
  const copValue = usdValue * 4000 // Mock COP rate
  
  const mockTokens: TokenBalance[] = isTestnet ? [] : [
    {
      contract_address: '0xa0b86a33e6ba7e7bb00c5e6eebc55b0e4b4b8c2a',
      symbol: 'USDC',
      name: 'USD Coin',
      decimals: 6,
      balance: '1000000000',
      balance_formatted: '1,000.00',
      price_usd: 1.00,
      price_cop: 4000,
      total_value_usd: 1000,
      total_value_cop: 4000000,
      last_updated: new Date(),
      price_source: 'coingecko',
      change_24h: 0.1
    },
    {
      contract_address: '0xa0b86a33e6ba7e7bb00c5e6eebc55b0e4b4b8c2b',
      symbol: 'USDT',
      name: 'Tether USD',
      decimals: 6,
      balance: '500000000',
      balance_formatted: '500.00',
      price_usd: 1.00,
      price_cop: 4000,
      total_value_usd: 500,
      total_value_cop: 2000000,
      last_updated: new Date(),
      price_source: 'dexscreener',
      change_24h: -0.05
    }
  ]
  
  const mockLPTokens: LPTokenBalance[] = isTestnet ? [] : [
    {
      lp_address: '0xa0b86a33e6ba7e7bb00c5e6eebc55b0e4b4b8c3a',
      dex_name: 'Uniswap V3',
      pair_symbol: 'ETH/USDC',
      token0: {
        address: '0x...',
        symbol: 'ETH',
        balance: '0.5',
        value_usd: 1150,
        value_cop: 4600000
      },
      token1: {
        address: '0x...',
        symbol: 'USDC',
        balance: '1150',
        value_usd: 1150,
        value_cop: 4600000
      },
      lp_balance: '1000000000000000000',
      total_value_usd: 2300,
      total_value_cop: 9200000,
      apy_percent: 15.5,
      last_updated: new Date()
    }
  ]
  
  const totalUSD = usdValue + mockTokens.reduce((sum, t) => sum + t.total_value_usd, 0) + mockLPTokens.reduce((sum, lp) => sum + lp.total_value_usd, 0)
  const totalCOP = totalUSD * 4000
  
  return {
    blockchain_name: blockchain,
    network_status: Math.random() > 0.1 ? 'connected' : 'syncing',
    last_sync: new Date(),
    native_token: {
      symbol: token.symbol,
      balance: (balance * Math.pow(10, 18)).toString(),
      balance_formatted: balanceFormatted,
      usd_value: usdValue,
      cop_value: copValue,
      last_updated: new Date(),
      change_24h: (Math.random() - 0.5) * 10
    },
    tokens: mockTokens,
    lp_tokens: mockLPTokens,
    totals: {
      total_usd: totalUSD,
      total_cop: totalCOP,
      token_count: mockTokens.length,
      lp_token_count: mockLPTokens.length
    }
  }
}

// Exchange rate mock - replace with real API
const getUSDToCOPRate = async (): Promise<number> => {
  // Mock implementation - replace with real exchange rate API
  return new Promise(resolve => {
    setTimeout(() => {
      const baseRate = 4000
      const variation = (Math.random() - 0.5) * 100 // ±50 variation
      resolve(baseRate + variation)
    }, 100)
  })
}

const PortfolioBalanceTracker = ({ environment }: PortfolioBalanceTrackerProps) => {
  // State management
  const [balances, setBalances] = useState<Record<string, BlockchainBalance>>({})
  const [isLoading, setIsLoading] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())
  const [autoArrowClockwise, setAutoArrowClockwise] = useKV('portfolio-auto-refresh', true)
  const [refreshInterval, setArrowClockwiseInterval] = useKV('portfolio-refresh-interval', 5)
  const [showCOP, setShowCOP] = useKV('portfolio-show-cop', true)
  const [showUSD, setShowUSD] = useKV('portfolio-show-usd', true)
  const [hideBalances, setHideBalances] = useKV('portfolio-hide-balances', false)
  const [usdToCopRate, setUsdToCopRate] = useState(4000)
  const [activeView, setActiveView] = useState('overview')
  
  // Supported blockchains
  const supportedBlockchains = [
    'ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism', 'avalanche', 'solana'
  ]
  
  // Network status component
  const NetworkStatus = ({ status }: { status: string }) => {
    const statusConfig = {
      connected: { color: 'bg-green-500', icon: CheckCircle, text: 'Connected' },
      disconnected: { color: 'bg-red-500', icon: WifiSlash, text: 'Disconnected' },
      syncing: { color: 'bg-yellow-500', icon: Repeat, text: 'Syncing' },
      error: { color: 'bg-red-600', icon: WarningCircle, text: 'Error' }
    }
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.disconnected
    const Icon = config.icon
    
    return (
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${config.color} animate-pulse`} />
        <Icon size={12} />
        <span className="text-xs">{config.text}</span>
      </div>
    )
  }
  
  // Fetch balances for all blockchains simultaneously
  const fetchAllBalances = async () => {
    setIsLoading(true)
    try {
      // Update exchange rate
      const rate = await getUSDToCOPRate()
      setUsdToCopRate(rate)
      
      // Fetch balances for all blockchains in parallel
      const promises = supportedBlockchains.map(async (blockchain) => {
        try {
          // Replace with real API calls
          const balance = generateMockBlockchainBalance(blockchain, environment)
          return [blockchain, balance]
        } catch (error) {
          console.error(`Error fetching ${blockchain} balance:`, error)
          return [blockchain, null]
        }
      })
      
      const results = await Promise.all(promises)
      const newBalances: Record<string, BlockchainBalance> = {}
      
      results.forEach(([blockchain, balance]) => {
        if (balance) {
          newBalances[blockchain as string] = balance as BlockchainBalance
        }
      })
      
      setBalances(newBalances)
      setLastUpdate(new Date())
      toast.success('Portfolio balances updated successfully')
      
    } catch (error) {
      toast.error('Failed to update portfolio balances')
      console.error('Error fetching balances:', error)
    } finally {
      setIsLoading(false)
    }
  }
  
  // Auto-refresh effect
  useEffect(() => {
    if (autoArrowClockwise) {
      const interval = setInterval(fetchAllBalances, refreshInterval * 1000)
      return () => clearInterval(interval)
    }
  }, [autoArrowClockwise, refreshInterval])
  
  // Initial fetch
  useEffect(() => {
    fetchAllBalances()
  }, [environment])
  
  // Calculate consolidated totals
  const consolidatedTotals = Object.values(balances).reduce(
    (totals, blockchain) => ({
      total_usd: totals.total_usd + blockchain.totals.total_usd,
      total_cop: totals.total_cop + blockchain.totals.total_cop,
      native_tokens_usd: totals.native_tokens_usd + blockchain.native_token.usd_value,
      erc20_tokens_usd: totals.erc20_tokens_usd + blockchain.tokens.reduce((sum, t) => sum + t.total_value_usd, 0),
      lp_tokens_usd: totals.lp_tokens_usd + blockchain.lp_tokens.reduce((sum, lp) => sum + lp.total_value_usd, 0),
      total_tokens: totals.total_tokens + blockchain.totals.token_count,
      total_lp_tokens: totals.total_lp_tokens + blockchain.totals.lp_token_count
    }),
    {
      total_usd: 0,
      total_cop: 0,
      native_tokens_usd: 0,
      erc20_tokens_usd: 0,
      lp_tokens_usd: 0,
      total_tokens: 0,
      total_lp_tokens: 0
    }
  )
  
  // Blockchain breakdown for charts
  const blockchainBreakdown = Object.entries(balances).map(([blockchain, balance]) => ({
    blockchain: blockchain.charAt(0).toUpperCase() + blockchain.slice(1),
    usd_value: balance.totals.total_usd,
    cop_value: balance.totals.total_cop,
    percentage: ((balance.totals.total_usd / consolidatedTotals.total_usd) * 100).toFixed(1),
    status: balance.network_status
  }))
  
  // Asset type breakdown
  const assetTypeBreakdown = [
    {
      name: 'Native Tokens',
      value: consolidatedTotals.native_tokens_usd,
      percentage: ((consolidatedTotals.native_tokens_usd / consolidatedTotals.total_usd) * 100).toFixed(1),
      color: '#8884d8'
    },
    {
      name: 'ERC-20 Tokens',
      value: consolidatedTotals.erc20_tokens_usd,
      percentage: ((consolidatedTotals.erc20_tokens_usd / consolidatedTotals.total_usd) * 100).toFixed(1),
      color: '#82ca9d'
    },
    {
      name: 'LP Tokens',
      value: consolidatedTotals.lp_tokens_usd,
      percentage: ((consolidatedTotals.lp_tokens_usd / consolidatedTotals.total_usd) * 100).toFixed(1),
      color: '#ffc658'
    }
  ]
  
  // Format currency values
  const formatCurrency = (value: number, currency: 'USD' | 'COP') => {
    if (hideBalances) return '••••••'
    
    if (currency === 'USD') {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(value)
    } else {
      return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(value)
    }
  }
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Wallet size={24} className="text-primary" />
            Portfolio Balance Tracker
          </h2>
          <p className="text-muted-foreground">
            Multi-blockchain • Real-time • USD/COP conversion
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Badge variant={environment === 'test' ? 'secondary' : 'destructive'}>
            {environment === 'test' ? 'Testnet' : 'Mainnet'}
          </Badge>
          
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={fetchAllBalances}
              disabled={isLoading}
              className="flex items-center gap-2"
            >
              <Repeat size={14} className={isLoading ? 'animate-spin' : ''} />
              ArrowClockwise
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setHideBalances(!hideBalances)}
              className="flex items-center gap-2"
            >
              {hideBalances ? <EyeSlash size={14} /> : <Eye size={14} />}
              {hideBalances ? 'Show' : 'Hide'}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Gear Row */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="auto-refresh"
                checked={autoArrowClockwise}
                onCheckedChange={setAutoArrowClockwise}
              />
              <Label htmlFor="auto-refresh" className="text-sm">Auto ArrowClockwise</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Label htmlFor="refresh-interval" className="text-sm">Interval:</Label>
              <Select value={refreshInterval.toString()} onValueChange={(value) => setArrowClockwiseInterval(parseInt(value))}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1s</SelectItem>
                  <SelectItem value="5">5s</SelectItem>
                  <SelectItem value="10">10s</SelectItem>
                  <SelectItem value="30">30s</SelectItem>
                  <SelectItem value="60">1m</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="show-usd"
                checked={showUSD}
                onCheckedChange={setShowUSD}
              />
              <Label htmlFor="show-usd" className="text-sm">Show USD</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="show-cop"
                checked={showCOP}
                onCheckedChange={setShowCOP}
              />
              <Label htmlFor="show-cop" className="text-sm">Show COP</Label>
            </div>
          </div>
          
          <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
            <span>Last updated: {lastUpdate.toLocaleTimeString()}</span>
            <span>USD/COP: {usdToCopRate.toFixed(2)}</span>
            <span>Next refresh: {autoArrowClockwise ? `${refreshInterval}s` : 'Manual'}</span>
          </div>
        </CardContent>
      </Card>
      
      {/* Consolidated Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Portfolio</p>
                {showUSD && (
                  <p className="text-2xl font-bold">{formatCurrency(consolidatedTotals.total_usd, 'USD')}</p>
                )}
                {showCOP && (
                  <p className="text-lg text-muted-foreground">{formatCurrency(consolidatedTotals.total_cop, 'COP')}</p>
                )}
              </div>
              <CurrencyDollar size={24} className="text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Blockchains</p>
                <p className="text-2xl font-bold">{Object.keys(balances).length}</p>
                <p className="text-sm text-muted-foreground">
                  {Object.values(balances).filter(b => b.network_status === 'connected').length} connected
                </p>
              </div>
              <Globe size={24} className="text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Assets</p>
                <p className="text-2xl font-bold">
                  {consolidatedTotals.total_tokens + consolidatedTotals.total_lp_tokens + Object.keys(balances).length}
                </p>
                <p className="text-sm text-muted-foreground">
                  {consolidatedTotals.total_tokens} tokens, {consolidatedTotals.total_lp_tokens} LP
                </p>
              </div>
              <Coins size={24} className="text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Main Content Tabs */}
      <Tabs value={activeView} onValueChange={setActiveView}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="blockchains">By Blockchain</TabsTrigger>
          <TabsTrigger value="assets">Asset Types</TabsTrigger>
          <TabsTrigger value="details">Detailed View</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Blockchain Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Portfolio Distribution by Blockchain</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={blockchainBreakdown}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="usd_value"
                      label={({ blockchain, percentage }) => `${blockchain} (${percentage}%)`}
                    >
                      {blockchainBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={`hsl(${index * 50}, 70%, 60%)`} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [formatCurrency(value as number, 'USD'), 'Value']} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            {/* Asset Type Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Portfolio Distribution by Asset Type</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={assetTypeBreakdown}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [formatCurrency(value as number, 'USD'), 'Value']} />
                    <Bar dataKey="value" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          {/* Blockchain Status GridFour */}
          <Card>
            <CardHeader>
              <CardTitle>Blockchain Network Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Object.entries(balances).map(([blockchain, balance]) => (
                  <div key={blockchain} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium capitalize">{blockchain}</span>
                      <NetworkStatus status={balance.network_status} />
                    </div>
                    {showUSD && (
                      <p className="text-lg font-bold">{formatCurrency(balance.totals.total_usd, 'USD')}</p>
                    )}
                    {showCOP && (
                      <p className="text-sm text-muted-foreground">{formatCurrency(balance.totals.total_cop, 'COP')}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      {balance.totals.token_count + 1} assets
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* By Blockchain Tab */}
        <TabsContent value="blockchains" className="space-y-6">
          {Object.entries(balances).map(([blockchain, balance]) => (
            <Card key={blockchain}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="capitalize flex items-center gap-2">
                    {blockchain}
                    <NetworkStatus status={balance.network_status} />
                  </CardTitle>
                  <div className="text-right">
                    {showUSD && (
                      <p className="text-lg font-bold">{formatCurrency(balance.totals.total_usd, 'USD')}</p>
                    )}
                    {showCOP && (
                      <p className="text-sm text-muted-foreground">{formatCurrency(balance.totals.total_cop, 'COP')}</p>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Native Token */}
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold text-primary-foreground">
                          {balance.native_token.symbol.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium">{balance.native_token.symbol}</p>
                        <p className="text-sm text-muted-foreground">Native Token</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{balance.native_token.balance_formatted}</p>
                      {showUSD && (
                        <p className="text-sm">{formatCurrency(balance.native_token.usd_value, 'USD')}</p>
                      )}
                      {showCOP && (
                        <p className="text-xs text-muted-foreground">{formatCurrency(balance.native_token.cop_value, 'COP')}</p>
                      )}
                    </div>
                  </div>
                  
                  {/* ERC-20 Tokens */}
                  {balance.tokens.map((token) => (
                    <div key={token.contract_address} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                          <span className="text-xs font-bold">{token.symbol.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="font-medium">{token.symbol}</p>
                          <p className="text-sm text-muted-foreground">{token.name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{token.balance_formatted}</p>
                        {showUSD && (
                          <p className="text-sm">{formatCurrency(token.total_value_usd, 'USD')}</p>
                        )}
                        {showCOP && (
                          <p className="text-xs text-muted-foreground">{formatCurrency(token.total_value_cop, 'COP')}</p>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  {/* LP Tokens */}
                  {balance.lp_tokens.map((lp) => (
                    <div key={lp.lp_address} className="flex items-center justify-between p-3 border rounded-lg bg-green-50 dark:bg-green-900/20">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                          <Lightning size={16} className="text-white" />
                        </div>
                        <div>
                          <p className="font-medium">{lp.pair_symbol}</p>
                          <p className="text-sm text-muted-foreground">{lp.dex_name}</p>
                          {lp.apy_percent && (
                            <p className="text-xs text-green-600 font-medium">APY: {lp.apy_percent.toFixed(2)}%</p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        {showUSD && (
                          <p className="text-sm font-medium">{formatCurrency(lp.total_value_usd, 'USD')}</p>
                        )}
                        {showCOP && (
                          <p className="text-xs text-muted-foreground">{formatCurrency(lp.total_value_cop, 'COP')}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        
        {/* Asset Types Tab */}
        <TabsContent value="assets" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {assetTypeBreakdown.map((assetType) => (
              <Card key={assetType.name}>
                <CardHeader>
                  <CardTitle className="text-lg">{assetType.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-2xl font-bold">
                      {formatCurrency(assetType.value, 'USD')}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {assetType.percentage}% of portfolio
                    </div>
                    <Progress value={parseFloat(assetType.percentage)} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Detailed Asset Type Analysis */}
          <Card>
            <CardHeader>
              <CardTitle>Asset Type Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={assetTypeBreakdown}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis 
                    tickFormatter={(value) => formatCurrency(value, 'USD')}
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <Tooltip 
                    formatter={(value, name) => [
                      name === 'value' ? formatCurrency(value as number, 'USD') : `${value}%`,
                      name === 'value' ? 'Value' : 'Percentage'
                    ]}
                  />
                  <Bar 
                    dataKey="value" 
                    fill="hsl(var(--primary))" 
                    name="value"
                    radius={[2, 2, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Detailed View Tab */}
        <TabsContent value="details" className="space-y-6">
          <ScrollArea className="h-[600px]">
            {Object.entries(balances).map(([blockchain, balance]) => (
              <Card key={blockchain} className="mb-4">
                <CardHeader>
                  <CardTitle className="capitalize flex items-center justify-between">
                    <span>{blockchain} - Detailed View</span>
                    <NetworkStatus status={balance.network_status} />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* Native Token Details */}
                    <div>
                      <h4 className="font-medium mb-3">Native Token</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Symbol</p>
                          <p className="font-medium">{balance.native_token.symbol}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Balance</p>
                          <p className="font-medium">{balance.native_token.balance_formatted}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">USD Value</p>
                          <p className="font-medium">{formatCurrency(balance.native_token.usd_value, 'USD')}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">COP Value</p>
                          <p className="font-medium">{formatCurrency(balance.native_token.cop_value, 'COP')}</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* ERC-20 Tokens Details */}
                    {balance.tokens.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">ERC-20 Tokens ({balance.tokens.length})</h4>
                        <div className="space-y-3">
                          {balance.tokens.map((token) => (
                            <div key={token.contract_address} className="p-3 border rounded-lg">
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 text-sm">
                                <div>
                                  <p className="text-muted-foreground">Token</p>
                                  <p className="font-medium">{token.symbol}</p>
                                  <p className="text-xs text-muted-foreground">{token.name}</p>
                                </div>
                                <div>
                                  <p className="text-muted-foreground">Balance</p>
                                  <p className="font-medium">{token.balance_formatted}</p>
                                </div>
                                <div>
                                  <p className="text-muted-foreground">Price USD</p>
                                  <p className="font-medium">${token.price_usd.toFixed(6)}</p>
                                </div>
                                <div>
                                  <p className="text-muted-foreground">Total USD</p>
                                  <p className="font-medium">{formatCurrency(token.total_value_usd, 'USD')}</p>
                                </div>
                                <div>
                                  <p className="text-muted-foreground">Source</p>
                                  <p className="font-medium capitalize">{token.price_source}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* LP Tokens Details */}
                    {balance.lp_tokens.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-3">LP Tokens ({balance.lp_tokens.length})</h4>
                        <div className="space-y-3">
                          {balance.lp_tokens.map((lp) => (
                            <div key={lp.lp_address} className="p-3 border rounded-lg bg-green-50 dark:bg-green-900/20">
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                                <div>
                                  <p className="text-muted-foreground">Pair</p>
                                  <p className="font-medium">{lp.pair_symbol}</p>
                                  <p className="text-xs text-muted-foreground">{lp.dex_name}</p>
                                </div>
                                <div>
                                  <p className="text-muted-foreground">Token0</p>
                                  <p className="font-medium">{lp.token0.symbol}: {lp.token0.balance}</p>
                                  <p className="text-xs">{formatCurrency(lp.token0.value_usd, 'USD')}</p>
                                </div>
                                <div>
                                  <p className="text-muted-foreground">Token1</p>
                                  <p className="font-medium">{lp.token1.symbol}: {lp.token1.balance}</p>
                                  <p className="text-xs">{formatCurrency(lp.token1.value_usd, 'USD')}</p>
                                </div>
                                <div>
                                  <p className="text-muted-foreground">Total Value</p>
                                  <p className="font-medium">{formatCurrency(lp.total_value_usd, 'USD')}</p>
                                  {lp.apy_percent && (
                                    <p className="text-xs text-green-600">APY: {lp.apy_percent.toFixed(2)}%</p>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export { PortfolioBalanceTracker }