import { useState, useMemo } from 'react'
import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { useKV } from '@/hooks/useKV'
import { 
  Shield, 
  WarningCircle, 
  Target, 
  TrendDown,
  Gear,
  Lock,
  Lightning,
  Activity,
  Eye,
  CheckCircle,
  XCircle
} from '@phosphor-icons/react'

interface RiskGear {
  maxDrawdown: number
  stopLossPercent: number
  takeProfitPercent: number
  maxPositionSize: number
  maxDailyLoss: number
  riskPerTrade: number
  enableStopLoss: boolean
  enableTakeProfit: boolean
  enablePositionLimits: boolean
  enableDailyLimits: boolean
}

interface RiskAlert {
  id: string
  type: 'warning' | 'danger' | 'info'
  title: string
  message: string
  timestamp: Date
  isActive: boolean
  metric: string
  currentValue: number
  threshold: number
}

export function RiskManagementSystem() {
  const { state } = useSimulation()
  const [riskGear, setRiskGear] = useKV<RiskGear>('risk-settings', {
    maxDrawdown: 15,
    stopLossPercent: 5,
    takeProfitPercent: 10,
    maxPositionSize: 2000,
    maxDailyLoss: 500,
    riskPerTrade: 2,
    enableStopLoss: true,
    enableTakeProfit: false,
    enablePositionLimits: true,
    enableDailyLimits: true
  })

  const [showGear, setShowGear] = useState(false)

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value.toFixed(2)}%`
  }

  // Calculate current risk metrics
  const riskMetrics = useMemo(() => {
    if (state.trades.length === 0) {
      return {
        currentDrawdown: 0,
        dailyPnL: 0,
        maxPositionUsed: 0,
        riskScore: 0,
        volatility: 0,
        valueAtRisk: 0,
        sharpeRatio: 0,
        isHighRisk: false
      }
    }

    // Calculate current drawdown
    let runningBalance = 10000
    let maxBalance = 10000
    let currentDrawdown = 0

    // Get trades from oldest to newest
    const sortedTrades = Array.from(state.trades).reverse()
    
    sortedTrades.forEach(trade => {
      runningBalance += trade.profit - trade.fees
      if (runningBalance > maxBalance) {
        maxBalance = runningBalance
      }
      currentDrawdown = Math.max(currentDrawdown, (maxBalance - runningBalance) / maxBalance * 100)
    })

    // Calculate daily P&L (last 24 hours)
    const oneDayAgo = Date.now() - 24 * 60 * 60 * 1000
    const recentTrades = state.trades.filter(t => t.timestamp > oneDayAgo)
    const dailyPnL = recentTrades.reduce((sum, t) => sum + t.profit - t.fees, 0)

    // Calculate max position used
    const maxPositionUsed = state.trades.length > 0 ? Math.max(...state.trades.map(t => t.amount)) : 0

    // Calculate volatility
    const returns = sortedTrades.map(t => (t.profit - t.fees) / t.amount)
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length
    const volatility = Math.sqrt(variance) * Math.sqrt(252) * 100 // Annualized

    // Calculate Value at Risk (95% confidence)
    const sortedReturns = [...returns].sort((a, b) => a - b)
    const varIndex = Math.floor(returns.length * 0.05)
    const valueAtRisk = sortedReturns[varIndex] ? Math.abs(sortedReturns[varIndex] * 100) : 0

    // Calculate Sharpe ratio
    const sharpeRatio = volatility > 0 ? (avgReturn * Math.sqrt(252) - 0.02) / (volatility / 100) : 0

    // Risk score calculation
    let riskScore = 0
    riskScore += Math.min(25, currentDrawdown / riskGear.maxDrawdown * 25)
    riskScore += Math.min(25, volatility / 50 * 25)
    riskScore += Math.min(25, maxPositionUsed / riskGear.maxPositionSize * 25)
    riskScore += Math.min(25, Math.abs(dailyPnL) / riskGear.maxDailyLoss * 25)

    const isHighRisk = riskScore > 60

    return {
      currentDrawdown,
      dailyPnL,
      maxPositionUsed,
      riskScore,
      volatility,
      valueAtRisk,
      sharpeRatio,
      isHighRisk
    }
  }, [state.trades, riskGear])

  // Generate risk alerts
  const riskAlerts = useMemo((): RiskAlert[] => {
    const alerts: RiskAlert[] = []

    // Drawdown alert
    if (riskMetrics.currentDrawdown > riskGear.maxDrawdown * 0.8) {
      alerts.push({
        id: 'drawdown-warning',
        type: riskMetrics.currentDrawdown > riskGear.maxDrawdown ? 'danger' : 'warning',
        title: 'Drawdown Risk',
        message: `Current drawdown of ${formatPercentage(riskMetrics.currentDrawdown)} approaching limit of ${formatPercentage(riskGear.maxDrawdown)}`,
        timestamp: new Date(),
        isActive: true,
        metric: 'drawdown',
        currentValue: riskMetrics.currentDrawdown,
        threshold: riskGear.maxDrawdown
      })
    }

    // Daily loss alert
    if (Math.abs(riskMetrics.dailyPnL) > riskGear.maxDailyLoss * 0.8 && riskMetrics.dailyPnL < 0) {
      alerts.push({
        id: 'daily-loss-warning',
        type: Math.abs(riskMetrics.dailyPnL) > riskGear.maxDailyLoss ? 'danger' : 'warning',
        title: 'Daily Loss Limit',
        message: `Daily loss of ${formatCurrency(Math.abs(riskMetrics.dailyPnL))} approaching limit of ${formatCurrency(riskGear.maxDailyLoss)}`,
        timestamp: new Date(),
        isActive: true,
        metric: 'dailyLoss',
        currentValue: Math.abs(riskMetrics.dailyPnL),
        threshold: riskGear.maxDailyLoss
      })
    }

    // High volatility alert
    if (riskMetrics.volatility > 40) {
      alerts.push({
        id: 'volatility-warning',
        type: riskMetrics.volatility > 60 ? 'danger' : 'warning',
        title: 'High Volatility',
        message: `Portfolio volatility of ${formatPercentage(riskMetrics.volatility)} indicates increased risk`,
        timestamp: new Date(),
        isActive: true,
        metric: 'volatility',
        currentValue: riskMetrics.volatility,
        threshold: 40
      })
    }

    // Position size alert
    if (riskMetrics.maxPositionUsed > riskGear.maxPositionSize * 0.9) {
      alerts.push({
        id: 'position-size-warning',
        type: riskMetrics.maxPositionUsed > riskGear.maxPositionSize ? 'danger' : 'warning',
        title: 'Position Size Risk',
        message: `Maximum position of ${formatCurrency(riskMetrics.maxPositionUsed)} near limit of ${formatCurrency(riskGear.maxPositionSize)}`,
        timestamp: new Date(),
        isActive: true,
        metric: 'positionSize',
        currentValue: riskMetrics.maxPositionUsed,
        threshold: riskGear.maxPositionSize
      })
    }

    return alerts
  }, [riskMetrics, riskGear])

  const updateRiskSetting = (key: keyof RiskGear, value: any) => {
    setRiskGear(prev => ({
      ...prev,
      [key]: value
    }))
  }

  const getRiskColor = (score: number) => {
    if (score < 25) return 'text-profit'
    if (score < 50) return 'text-warning'
    if (score < 75) return 'text-destructive'
    return 'text-destructive'
  }

  const getRiskLabel = (score: number) => {
    if (score < 25) return 'Low Risk'
    if (score < 50) return 'Medium Risk'
    if (score < 75) return 'High Risk'
    return 'Critical Risk'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Risk Management System</h2>
          <p className="text-muted-foreground">Desktop and control portfolio risk in real-time</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowGear(!showGear)}
            className="gap-2"
          >
            <Gear size={16} />
            Gear
          </Button>
          
          <Badge className={`${riskMetrics.isHighRisk ? 'bg-destructive text-destructive-foreground' : 'bg-profit text-profit-foreground'}`}>
            {getRiskLabel(riskMetrics.riskScore)}
          </Badge>
        </div>
      </div>

      {/* Risk Score Card */}
      <Card className={riskMetrics.isHighRisk ? 'border-destructive' : ''}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold">Overall Risk Score</h3>
              <p className="text-muted-foreground">Real-time portfolio risk assessment</p>
            </div>
            <div className="text-right">
              <p className={`text-3xl font-bold ${getRiskColor(riskMetrics.riskScore)}`}>
                {riskMetrics.riskScore.toFixed(0)}/100
              </p>
              <p className="text-sm text-muted-foreground">{getRiskLabel(riskMetrics.riskScore)}</p>
            </div>
          </div>
          
          <Progress 
            value={riskMetrics.riskScore} 
            className={`h-3 ${riskMetrics.riskScore > 75 ? '[&>div]:bg-destructive' : 
                              riskMetrics.riskScore > 50 ? '[&>div]:bg-warning' : 
                              '[&>div]:bg-profit'}`}
          />
        </CardContent>
      </Card>

      {/* Active Alerts */}
      {riskAlerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <WarningCircle size={20} />
              Active Risk Alerts ({riskAlerts.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {riskAlerts.map(alert => (
              <div 
                key={alert.id}
                className={`p-4 rounded-lg border ${
                  alert.type === 'danger' ? 'bg-destructive/10 border-destructive/20' :
                  alert.type === 'warning' ? 'bg-warning/10 border-warning/20' :
                  'bg-primary/10 border-primary/20'
                }`}
              >
                <div className="flex items-start gap-3">
                  {alert.type === 'danger' ? (
                    <XCircle size={20} className="text-destructive mt-0.5 flex-shrink-0" />
                  ) : alert.type === 'warning' ? (
                    <WarningCircle size={20} className="text-warning mt-0.5 flex-shrink-0" />
                  ) : (
                    <CheckCircle size={20} className="text-primary mt-0.5 flex-shrink-0" />
                  )}
                  <div className="flex-1">
                    <p className={`font-medium ${
                      alert.type === 'danger' ? 'text-destructive' :
                      alert.type === 'warning' ? 'text-warning' :
                      'text-primary'
                    }`}>
                      {alert.title}
                    </p>
                    <p className="text-sm text-muted-foreground">{alert.message}</p>
                    <div className="mt-2">
                      <Progress 
                        value={(alert.currentValue / alert.threshold) * 100}
                        className="h-2"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="limits">Risk Limits</TabsTrigger>
          <TabsTrigger value="metrics">Risk Metrics</TabsTrigger>
          <TabsTrigger value="controls">Controls</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Current Drawdown</p>
                    <p className={`text-2xl font-bold ${riskMetrics.currentDrawdown > riskGear.maxDrawdown ? 'loss' : 'text-foreground'}`}>
                      {formatPercentage(riskMetrics.currentDrawdown)}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Limit: {formatPercentage(riskGear.maxDrawdown)}
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                    <TrendDown size={24} className="text-destructive" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Daily P&L</p>
                    <p className={`text-2xl font-bold ${riskMetrics.dailyPnL >= 0 ? 'profit' : 'loss'}`}>
                      {formatCurrency(riskMetrics.dailyPnL)}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Loss limit: {formatCurrency(riskGear.maxDailyLoss)}
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Activity size={24} className="text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Max Position</p>
                    <p className="text-2xl font-bold">{formatCurrency(riskMetrics.maxPositionUsed)}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Limit: {formatCurrency(riskGear.maxPositionSize)}
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-warning/10 rounded-lg flex items-center justify-center">
                    <Target size={24} className="text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Volatility</p>
                    <p className="text-2xl font-bold">{formatPercentage(riskMetrics.volatility)}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Sharpe: {riskMetrics.sharpeRatio.toFixed(2)}
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <Activity size={24} className="text-accent" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="limits" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Drawdown Control</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="maxDrawdown">Maximum Drawdown (%)</Label>
                  <Slider
                    id="maxDrawdown"
                    min={5}
                    max={30}
                    step={1}
                    value={[riskGear.maxDrawdown]}
                    onValueChange={([value]) => updateRiskSetting('maxDrawdown', value)}
                    className="mt-2"
                  />
                  <p className="text-sm text-muted-foreground mt-1">
                    Current: {formatPercentage(riskGear.maxDrawdown)}
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="enableStopLoss"
                    checked={riskGear.enableStopLoss}
                    onCheckedChange={(checked) => updateRiskSetting('enableStopLoss', checked)}
                  />
                  <Label htmlFor="enableStopLoss">Enable Stop Loss</Label>
                </div>

                {riskGear.enableStopLoss && (
                  <div>
                    <Label htmlFor="stopLoss">Stop Loss (%)</Label>
                    <Slider
                      id="stopLoss"
                      min={1}
                      max={10}
                      step={0.5}
                      value={[riskGear.stopLossPercent]}
                      onValueChange={([value]) => updateRiskSetting('stopLossPercent', value)}
                      className="mt-2"
                    />
                    <p className="text-sm text-muted-foreground mt-1">
                      Current: {formatPercentage(riskGear.stopLossPercent)}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Position & Daily Limits</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="enablePositionLimits"
                    checked={riskGear.enablePositionLimits}
                    onCheckedChange={(checked) => updateRiskSetting('enablePositionLimits', checked)}
                  />
                  <Label htmlFor="enablePositionLimits">Enable Position Limits</Label>
                </div>

                {riskGear.enablePositionLimits && (
                  <div>
                    <Label htmlFor="maxPosition">Max Position Size ($)</Label>
                    <Input
                      id="maxPosition"
                      type="number"
                      value={riskGear.maxPositionSize}
                      onChange={(e) => updateRiskSetting('maxPositionSize', Number(e.target.value))}
                      className="mt-2"
                    />
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  <Switch
                    id="enableDailyLimits"
                    checked={riskGear.enableDailyLimits}
                    onCheckedChange={(checked) => updateRiskSetting('enableDailyLimits', checked)}
                  />
                  <Label htmlFor="enableDailyLimits">Enable Daily Loss Limit</Label>
                </div>

                {riskGear.enableDailyLimits && (
                  <div>
                    <Label htmlFor="maxDailyLoss">Max Daily Loss ($)</Label>
                    <Input
                      id="maxDailyLoss"
                      type="number"
                      value={riskGear.maxDailyLoss}
                      onChange={(e) => updateRiskSetting('maxDailyLoss', Number(e.target.value))}
                      className="mt-2"
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Risk Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Value at Risk (95%)</span>
                  <span className="font-semibold">{formatPercentage(riskMetrics.valueAtRisk)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Volatility (Annualized)</span>
                  <span className="font-semibold">{formatPercentage(riskMetrics.volatility)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Sharpe Ratio</span>
                  <span className="font-semibold">{riskMetrics.sharpeRatio.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Max Drawdown</span>
                  <span className="font-semibold loss">{formatPercentage(riskMetrics.currentDrawdown)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Position Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Largest Position</span>
                  <span className="font-semibold">{formatCurrency(riskMetrics.maxPositionUsed)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Position Utilization</span>
                  <span className="font-semibold">
                    {formatPercentage((riskMetrics.maxPositionUsed / riskGear.maxPositionSize) * 100)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Daily P&L</span>
                  <span className={`font-semibold ${riskMetrics.dailyPnL >= 0 ? 'profit' : 'loss'}`}>
                    {formatCurrency(riskMetrics.dailyPnL)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Risk per Trade</span>
                  <span className="font-semibold">{formatPercentage(riskGear.riskPerTrade)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Risk Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Stop Loss</span>
                  <Badge className={riskGear.enableStopLoss ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                    {riskGear.enableStopLoss ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Take Profit</span>
                  <Badge className={riskGear.enableTakeProfit ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                    {riskGear.enableTakeProfit ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Position Limits</span>
                  <Badge className={riskGear.enablePositionLimits ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                    {riskGear.enablePositionLimits ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Daily Limits</span>
                  <Badge className={riskGear.enableDailyLimits ? 'bg-profit text-profit-foreground' : 'bg-muted text-muted-foreground'}>
                    {riskGear.enableDailyLimits ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="controls" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Emergency Controls</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Button variant="destructive" className="gap-2">
                  <Lock size={16} />
                  Stop All Trading
                </Button>
                <Button variant="outline" className="gap-2">
                  <Shield size={16} />
                  Enable Safe Mode
                </Button>
                <Button variant="outline" className="gap-2">
                  <Eye size={16} />
                  Close All Positions
                </Button>
                <Button variant="outline" className="gap-2">
                  <Lightning size={16} />
                  Reset Limits
                </Button>
              </div>
              
              <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                <h4 className="font-semibold mb-2">Risk Management Guidelines</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Never risk more than 2% of your portfolio on a single trade</li>
                  <li>• Set stop losses to limit maximum loss per position</li>
                  <li>• Desktop drawdown and take breaks if losses exceed 10%</li>
                  <li>• Diversify across different arbitrage strategies</li>
                  <li>• Review and adjust risk parameters regularly</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}