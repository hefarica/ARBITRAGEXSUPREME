import { useState } from 'react'
import { useSimulation } from '../simulation/SimulationProvider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { PortfolioChart } from '../charts/PortfolioChart'
import { ProfitLossChart } from '../charts/ProfitLossChart'
import { StrategyAllocationChart } from '../charts/StrategyAllocationChart'
import { RiskMetricsChart } from '../charts/RiskMetricsChart'
import { TradingSpeakerHighChart } from '../charts/TradingSpeakerHighChart'
import { 
  TrendUp, 
  TrendDown, 
  Activity, 
  Target, 
  BarChart, 
  PieChart,
  LineChart,
  Download,
  Repeat,
  WarningCircle
} from '@phosphor-icons/react'

export function PortfolioPerformanceDashboard() {
  const { state } = useSimulation()
  const [refreshing, setArrowClockwiseing] = useState(false)

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const formatPercentage = (value: number) => {
    return `${value.toFixed(2)}%`
  }

  // Calculate key performance metrics
  const totalTrades = state.trades.length
  const successfulTrades = state.trades.filter(t => t.profit > 0).length
  const winRate = totalTrades > 0 ? (successfulTrades / totalTrades) * 100 : 0
  const totalFees = state.trades.reduce((sum, t) => sum + t.fees, 0)
  const avgTradeSize = totalTrades > 0 ? state.trades.reduce((sum, t) => sum + t.amount, 0) / totalTrades : 0
  
  // Calculate return metrics
  const totalReturn = ((state.balance - 10000) / 10000) * 100
  const profitFactor = (() => {
    const profits = state.trades.filter(t => t.profit > 0).reduce((sum, t) => sum + t.profit, 0)
    const losses = Math.abs(state.trades.filter(t => t.profit <= 0).reduce((sum, t) => sum + t.profit, 0))
    return losses > 0 ? profits / losses : profits > 0 ? Infinity : 0
  })()

  // Calculate risk metrics
  const maxDrawdown = (() => {
    let maxBalance = 10000
    let maxDD = 0
    let runningBalance = 10000
    
    Array.from(state.trades).reverse().forEach(trade => {
      runningBalance += trade.profit - trade.fees
      if (runningBalance > maxBalance) maxBalance = runningBalance
      const drawdown = (maxBalance - runningBalance) / maxBalance
      if (drawdown > maxDD) maxDD = drawdown
    })
    
    return maxDD * 100
  })()

  const handleArrowClockwise = async () => {
    setArrowClockwiseing(true)
    // Simulate data refresh
    await new Promise(resolve => setTimeout(resolve, 1000))
    setArrowClockwiseing(false)
  }

  const handleExportData = () => {
    const exportData = {
      summary: {
        totalReturn,
        winRate,
        profitFactor,
        maxDrawdown,
        totalTrades,
        totalFees: formatCurrency(totalFees)
      },
      trades: state.trades,
      timestamp: new Date().toISOString()
    }
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `portfolio-performance-${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* Header with Controls */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Portfolio Performance</h1>
          <p className="text-muted-foreground">Advanced analytics and performance tracking</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={handleArrowClockwise}
            disabled={refreshing}
            className="gap-2"
          >
            <Repeat size={16} className={refreshing ? 'animate-spin' : ''} />
            ArrowClockwise
          </Button>
          <Button 
            variant="outline" 
            onClick={handleExportData}
            className="gap-2"
          >
            <Download size={16} />
            Export Data
          </Button>
        </div>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Return</p>
                <p className={`text-2xl font-bold ${totalReturn >= 0 ? 'profit' : 'loss'}`}>
                  {formatPercentage(totalReturn)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatCurrency(state.balance - 10000)} absolute
                </p>
              </div>
              <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                totalReturn >= 0 ? 'bg-profit/10' : 'bg-destructive/10'
              }`}>
                {totalReturn >= 0 ? 
                  <TrendUp size={24} className="text-profit" /> : 
                  <TrendDown size={24} className="text-destructive" />
                }
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Win Rate</p>
                <p className="text-2xl font-bold">{formatPercentage(winRate)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {successfulTrades}/{totalTrades} trades
                </p>
              </div>
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Target size={24} className="text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Profit Factor</p>
                <p className="text-2xl font-bold">
                  {profitFactor === Infinity ? '∞' : profitFactor.toFixed(2)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Gross profit/loss ratio
                </p>
              </div>
              <div className="h-12 w-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <BarChart size={24} className="text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Max Drawdown</p>
                <p className={`text-2xl font-bold ${maxDrawdown > 10 ? 'loss' : 'text-foreground'}`}>
                  {formatPercentage(maxDrawdown)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Peak to trough decline
                </p>
              </div>
              <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                maxDrawdown > 10 ? 'bg-destructive/10' : 'bg-warning/10'
              }`}>
                <WarningCircle size={24} className={maxDrawdown > 10 ? 'text-destructive' : 'text-warning'} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Alert */}
      {maxDrawdown > 15 && (
        <Card className="border-destructive">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <WarningCircle size={20} className="text-destructive" />
              <div>
                <p className="font-medium text-destructive">High Risk Alert</p>
                <p className="text-sm text-muted-foreground">
                  Your portfolio has experienced a significant drawdown. Consider reviewing your risk management strategy.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Detailed Analytics Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="allocation">Allocation</TabsTrigger>
          <TabsTrigger value="risk">Risk Analysis</TabsTrigger>
          <TabsTrigger value="volume">SpeakerHigh</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart size={20} />
                  Portfolio Value Over Time
                </CardTitle>
              </CardHeader>
              <CardContent>
                <PortfolioChart />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity size={20} />
                  Key Metrics Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{totalTrades}</p>
                    <p className="text-sm text-muted-foreground">Total Trades</p>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{formatCurrency(avgTradeSize)}</p>
                    <p className="text-sm text-muted-foreground">Avg Trade Size</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Current Balance</span>
                    <span className="font-semibold">{formatCurrency(state.balance)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Fees Paid</span>
                    <span className="font-semibold">{formatCurrency(totalFees)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Net P&L</span>
                    <span className={`font-semibold ${state.totalPnL >= 0 ? 'profit' : 'loss'}`}>
                      {formatCurrency(state.totalPnL)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart size={20} />
                Daily Profit & Loss Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ProfitLossChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="allocation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart size={20} />
                Strategy Allocation Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent>
              <StrategyAllocationChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <WarningCircle size={20} />
                Risk Metrics & Drawdown Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RiskMetricsChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="volume" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity size={20} />
                Trading SpeakerHigh Patterns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <TradingSpeakerHighChart />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}