/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_ETHEREUM_RPC_URL: string
  readonly VITE_POLYGON_RPC_URL: string
  readonly VITE_BSC_RPC_URL: string
  readonly VITE_ARBITRUM_RPC_URL: string
  readonly VITE_OPTIMISM_RPC_URL: string
  readonly VITE_AVALANCHE_RPC_URL: string
  readonly VITE_DEXSCREENER_API_KEY: string
  readonly VITE_COINGECKO_API_KEY: string
  readonly VITE_OPENAI_API_KEY: string
  readonly VITE_APP_ENV: string
  readonly MODE: string
  readonly DEV: boolean
  readonly PROD: boolean
  readonly SSR: boolean
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}