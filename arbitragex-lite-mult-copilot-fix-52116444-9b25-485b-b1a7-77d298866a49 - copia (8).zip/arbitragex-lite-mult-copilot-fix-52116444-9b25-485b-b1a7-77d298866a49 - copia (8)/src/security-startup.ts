/**
 * 🔐 SECURITY STARTUP - ArbitrageX Pro 2025
 * Inicialización automática de todos los sistemas de seguridad
 * 
 * Importar en tu archivo principal:
 * import './src/security-startup';
 */

import { initializeAllSecuritySystems } from './security';

// Auto-ejecutar inicialización de seguridad
(async () => {
  try {
    console.log('🔐 Iniciando configuración automática de seguridad...');
    await initializeAllSecuritySystems();
    console.log('✅ Configuración de seguridad completada exitosamente');
  } catch (error) {
    console.error('❌ Error en configuración de seguridad:', error);
    process.exit(1);
  }
})();

export default initializeAllSecuritySystems;
