import { Router } from 'express';
import { FigmaMCPController } from '../controllers/FigmaMCPController';

const router = Router();
const figmaController = new FigmaMCPController(process.env.FIGMA_ACCESS_TOKEN || '');

/**
 * GET /api/figma/file/:fileId
 * Obtiene información de un archivo de Figma
 */
router.get('/file/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;
    const fileInfo = await figmaController.getFileInfo(fileId);
    res.json({ success: true, data: fileInfo });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: `Error obteniendo información del archivo: ${error}` 
    });
  }
});

/**
 * GET /api/figma/components/:fileId
 * Lista todos los componentes de un archivo
 */
router.get('/components/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;
    const components = await figmaController.listComponents(fileId);
    res.json({ success: true, data: components });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: `Error listando componentes: ${error}` 
    });
  }
});

/**
 * POST /api/figma/assets
 * Obtiene assets específicos de un archivo
 */
router.post('/assets', async (req, res) => {
  try {
    const { fileId, nodeIds, format, scale } = req.body;
    
    if (!fileId || !nodeIds || !Array.isArray(nodeIds)) {
      return res.status(400).json({
        success: false,
        error: 'fileId y nodeIds son requeridos'
      });
    }
    
    const assets = await figmaController.getAssets(
      fileId, 
      nodeIds, 
      format || 'png', 
      scale || 1
    );
    
    res.json({ success: true, data: assets });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: `Error obteniendo assets: ${error}` 
    });
  }
});

/**
 * POST /api/figma/sync
 * Sincroniza assets completos desde Figma
 */
router.post('/sync', async (req, res) => {
  try {
    const { fileId, outputDir } = req.body;
    
    if (!fileId || !outputDir) {
      return res.status(400).json({
        success: false,
        error: 'fileId y outputDir son requeridos'
      });
    }
    
    const result = await figmaController.syncAssets(fileId, outputDir);
    res.json(result);
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: `Error en sincronización: ${error}` 
    });
  }
});

/**
 * GET /api/figma/search/:fileId
 * Busca componentes por nombre
 */
router.get('/search/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;
    const { q: searchTerm } = req.query;
    
    if (!searchTerm || typeof searchTerm !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Parámetro de búsqueda "q" es requerido'
      });
    }
    
    const components = await figmaController.searchComponents(fileId, searchTerm);
    res.json({ success: true, data: components });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: `Error en búsqueda: ${error}` 
    });
  }
});

/**
 * GET /api/figma/stats/:fileId
 * Obtiene estadísticas del archivo
 */
router.get('/stats/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;
    const stats = await figmaController.getFileStats(fileId);
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: `Error obteniendo estadísticas: ${error}` 
    });
  }
});

export default router;
