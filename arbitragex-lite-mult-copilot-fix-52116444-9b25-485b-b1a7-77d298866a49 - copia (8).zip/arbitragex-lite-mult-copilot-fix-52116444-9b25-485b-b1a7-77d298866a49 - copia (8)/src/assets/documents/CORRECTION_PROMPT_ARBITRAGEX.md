
# ===============================================================================
# 🚨 PROMPT DE CORRECCIÓN ANTI-MOCK - ARBITRAGEX LITE
# ===============================================================================

VIOLACIONES CRÍTICAS DETECTADAS: 805 TOTAL
- MOCK_CODE: 642 violaciones
- PLACEHOLDER_VALUE: 148 violaciones  
- TODO_DATA: 15 violaciones

# ===============================================================================
# 🔥 CORRECCIONES OBLIGATORIAS INMEDIATAS
# ===============================================================================

## 1. ELIMINAR SCRIPTS MOCK DEL PACKAGE.JSON

❌ REMOVER ESTAS LÍNEAS INMEDIATAMENTE:
```json
"audit:mock": "node scripts/mock-data-auditor.js",
"audit:mock:watch": "node scripts/mock-data-auditor.js --watch", 
"audit:mock:json": "node scripts/mock-data-auditor.js --json audit-reports/mock-data-report.json",
"prebuild": "npm run audit:mock"
```

✅ REEMPLAZAR CON:
```json
"audit:real": "python scripts/realtime_truth_guard.py . --json audit-reports/real-data-report.json",
"audit:real:watch": "python scripts/realtime_truth_guard.py . --json audit-reports/real-data-report.json --verbose",
"prebuild": "npm run audit:real"
```

## 2. CORREGIR MFASecurityModule.ts - LÍNEA 561

❌ CÓDIGO PROHIBIDO:
```typescript
return Math.random() > 0.1 // 90% success rate para demo
```

✅ CORRECCIÓN OBLIGATORIA:
```typescript
// Integrar con servicio MFA real
const mfaResponse = await this.realMFAService.validateToken(token);
return mfaResponse.isValid;
```

## 3. CONFIGURAR SERVICIOS REALES REQUERIDOS

### 3.1 Variables de Entorno (.env)
```bash
# PRICE FEEDS - OBLIGATORIO
COINGECKO_API_KEY=tu_api_key_real
BINANCE_API_KEY=tu_api_key_real
BINANCE_SECRET_KEY=tu_secret_key_real

# BLOCKCHAIN RPC - OBLIGATORIO  
INFURA_PROJECT_ID=tu_project_id_real
ALCHEMY_API_KEY=tu_api_key_real
QUICKNODE_ENDPOINT=tu_endpoint_real

# ORACLES - OBLIGATORIO
CHAINLINK_PRICE_FEED_ETH_USD=0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419
CHAINLINK_PRICE_FEED_BTC_USD=0xF4030086522a5bEEa4988F8cA5B36dbC97BeE88c

# BLOCK EXPLORERS - OBLIGATORIO
ETHERSCAN_API_KEY=tu_api_key_real
BSCSCAN_API_KEY=tu_api_key_real

# GAS ORACLES - OBLIGATORIO
GAS_STATION_API_KEY=tu_api_key_real
```

### 3.2 Servicios de Precio Reales
```typescript
// src/services/PriceService.ts
export class RealPriceService {
  private coingeckoAPI: string;
  private binanceAPI: string;

  constructor() {
    this.coingeckoAPI = process.env.COINGECKO_API_KEY!;
    this.binanceAPI = process.env.BINANCE_API_KEY!;

    if (!this.coingeckoAPI || !this.binanceAPI) {
      throw new Error('🚫 PRICE SERVICE APIs NOT CONFIGURED');
    }
  }

  async getRealTimePrice(symbol: string): Promise<number> {
    // Implementar llamada real a CoinGecko/Binance
    const response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${symbol}&vs_currencies=usd`, {
      headers: { 'X-CG-Demo-API-Key': this.coingeckoAPI }
    });

    if (!response.ok) {
      throw new Error('🚫 FAILED TO FETCH REAL PRICE DATA');
    }

    const data = await response.json();
    return data[symbol].usd;
  }
}
```

### 3.3 Blockchain RPC Real
```typescript
// src/services/BlockchainService.ts
import { ethers } from 'ethers';

export class RealBlockchainService {
  private provider: ethers.Provider;

  constructor() {
    const infuraKey = process.env.INFURA_PROJECT_ID;
    const alchemyKey = process.env.ALCHEMY_API_KEY;

    if (!infuraKey && !alchemyKey) {
      throw new Error('🚫 BLOCKCHAIN RPC NOT CONFIGURED');
    }

    // Usar Infura o Alchemy como provider real
    this.provider = infuraKey 
      ? new ethers.InfuraProvider('mainnet', infuraKey)
      : new ethers.AlchemyProvider('mainnet', alchemyKey);
  }

  async getRealGasPrice(): Promise<bigint> {
    return await this.provider.getFeeData().then(fee => fee.gasPrice!);
  }

  async getRealBlockNumber(): Promise<number> {
    return await this.provider.getBlockNumber();
  }
}
```

## 4. ELIMINAR ARCHIVOS MOCK COMPLETAMENTE

❌ BORRAR ESTOS ARCHIVOS:
- scripts/mock-data-auditor.js
- Cualquier archivo que contenga "mock" en el nombre
- Archivos de test que usen datos simulados

## 5. CORREGIR useCacheWithFallback.ts

❌ LÍNEA 148 PROHIBIDA:
```typescript
successRate: 0,
```

✅ CORRECCIÓN:
```typescript
successRate: await this.calculateRealSuccessRate(),
```

## 6. IMPLEMENTAR VALIDACIÓN REAL EN HOOKS

```typescript
// src/hooks/useRealTimeData.ts
export const useRealTimeData = (endpoint: string) => {
  // Verificar que endpoint no sea localhost o mock
  if (endpoint.includes('localhost') || endpoint.includes('mock') || endpoint.includes('test')) {
    throw new Error('🚫 MOCK ENDPOINTS PROHIBITED');
  }

  // Solo permitir endpoints de servicios reales
  const allowedDomains = [
    'api.coingecko.com',
    'api.binance.com', 
    'mainnet.infura.io',
    'eth-mainnet.alchemyapi.io'
  ];

  const isValidEndpoint = allowedDomains.some(domain => endpoint.includes(domain));
  if (!isValidEndpoint) {
    throw new Error('🚫 ONLY REAL SERVICE ENDPOINTS ALLOWED');
  }

  // Continuar con lógica real...
};
```

# ===============================================================================
# 🛡️ VERIFICACIÓN POST-CORRECCIÓN
# ===============================================================================

Después de aplicar las correcciones, ejecutar:

```bash
# 1. Verificar que no queden mocks
python scripts/realtime_truth_guard.py . --json final-audit.json

# 2. El script debe retornar exit code 0 (sin violaciones)
echo $?  # Debe ser 0

# 3. Verificar build sin mocks
npm run build

# 4. Verificar que todas las APIs estén configuradas
npm run audit:real
```

# ===============================================================================
# ⚠️ ADVERTENCIAS CRÍTICAS
# ===============================================================================

🚫 NO IGNORAR ESTAS CORRECCIONES
🚫 NO USAR DATOS SIMULADOS EN PRODUCCIÓN  
🚫 NO HACER BYPASS DEL TRUTH GUARD
🚫 NO USAR Math.random() PARA PRECIOS
🚫 NO USAR LOCALHOST EN ENDPOINTS DE PRODUCCIÓN

✅ SOLO CONTINUAR SI TODAS LAS CORRECCIONES ESTÁN APLICADAS
✅ SOLO USAR SERVICIOS REALES CONFIGURADOS
✅ SOLO DEPLOYAR SI AUDIT RETORNA 0 VIOLACIONES

# ===============================================================================
# 📋 CHECKLIST DE CORRECCIÓN
# ===============================================================================

□ Scripts mock eliminados del package.json
□ Math.random() reemplazado con servicios reales
□ Variables de entorno configuradas con APIs reales
□ Archivos mock eliminados completamente
□ Endpoints localhost reemplazados con URLs reales
□ Placeholders reemplazados con valores reales
□ Truth Guard ejecutado sin violaciones (exit 0)
□ Build exitoso sin warnings de mock data
□ Todas las APIs de precio funcionando
□ Todos los RPCs blockchain conectados

SOLO MARCAR COMO COMPLETO CUANDO TODAS LAS CASILLAS ESTÉN ✅
