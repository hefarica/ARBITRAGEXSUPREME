/**
 * 🔄 Servicio de Reconexión Automática para Blockchains
 * Maneja la reconexión automática de todas las blockchains desconectadas
 * con estrategias inteligentes de retry y fallback
 */

import { EventEmitter } from 'events'
import { ethers } from 'ethers'

export interface BlockchainConnection {
  name: string
  chainId: number
  rpcUrl: string
  wsUrl?: string
  provider: ethers.JsonRpcProvider
  isConnected: boolean
  lastConnected: number
  lastDisconnected: number
  connectionAttempts: number
  maxRetries: number
  healthCheckInterval: number
  status: 'connected' | 'disconnected' | 'connecting' | 'error'
  error?: string
  latency: number
  blockHeight: number
  gasPrice: string
}

export interface ReconnectionConfig {
  enabled: boolean
  maxRetries: number
  baseDelay: number
  maxDelay: number
  exponentialBackoff: boolean
  healthCheckInterval: number
  autoReconnectOnError: boolean
  fallbackRPCs: boolean
}

export class AutoReconnectionService extends EventEmitter {
  private static instance: AutoReconnectionService
  private connections: Map<string, BlockchainConnection> = new Map()
  private reconnectionTimers: Map<string, NodeJS.Timeout> = new Map()
  private healthCheckTimers: Map<string, NodeJS.Timeout> = new Map()
  private isRunning = false

  // Configuración por defecto
  private config: ReconnectionConfig = {
    enabled: true,
    maxRetries: 10,
    baseDelay: 1000, // 1 segundo
    maxDelay: 30000, // 30 segundos
    exponentialBackoff: true,
    healthCheckInterval: 15000, // 15 segundos
    autoReconnectOnError: true,
    fallbackRPCs: true
  }

  // RPCs de fallback para cada blockchain
  private fallbackRPCs: Record<string, string[]> = {
    ethereum: [
      'https://eth-mainnet.g.alchemy.com/v2/demo',
      'https://mainnet.infura.io/v3/demo',
      'https://rpc.ankr.com/eth',
      'https://cloudflare-eth.com'
    ],
    polygon: [
      'https://polygon-rpc.com',
      'https://rpc-mainnet.matic.network',
      'https://rpc-mainnet.maticvigil.com',
      'https://polygon.llamarpc.com'
    ],
    bsc: [
      'https://bsc-dataseed.binance.org',
      'https://bsc-dataseed1.defibit.io',
      'https://bsc-dataseed1.ninicoin.io',
      'https://bsc.nodereal.io'
    ],
    arbitrum: [
      'https://arb1.arbitrum.io/rpc',
      'https://arbitrum-one.publicnode.com',
      'https://arbitrum.llamarpc.com'
    ],
    optimism: [
      'https://mainnet.optimism.io',
      'https://optimism.publicnode.com',
      'https://optimism.llamarpc.com'
    ],
    fantom: [
      'https://rpc.ftm.tools',
      'https://rpc.fantom.network',
      'https://fantom.publicnode.com'
    ],
    avalanche: [
      'https://api.avax.network/ext/bc/C/rpc',
      'https://rpc.ankr.com/avalanche',
      'https://avalanche.public-rpc.com'
    ],
    cronos: [
      'https://evm.cronos.org',
      'https://cronos.crypto.org',
      'https://rpc.vvs.finance'
    ]
  }

  private constructor() {
    super()
    this.setupEventHandlers()
  }

  static getInstance(): AutoReconnectionService {
    if (!AutoReconnectionService.instance) {
      AutoReconnectionService.instance = new AutoReconnectionService()
    }
    return AutoReconnectionService.instance
  }

  /**
   * Configurar el servicio de reconexión
   */
  configure(config: Partial<ReconnectionConfig>): void {
    this.config = { ...this.config, ...config }
    console.log('⚙️ Configuración de reconexión actualizada:', this.config)
  }

  /**
   * Iniciar el servicio de reconexión automática
   */
  async start(): Promise<void> {
    if (this.isRunning) {
      console.log('🔄 Servicio de reconexión ya está ejecutándose')
      return
    }

    this.isRunning = true
    console.log('🚀 Iniciando servicio de reconexión automática...')

    // Iniciar health checks para todas las conexiones
    this.startHealthChecks()

    // Intentar reconectar conexiones desconectadas
    await this.reconnectAllDisconnected()

    this.emit('service_started')
    console.log('✅ Servicio de reconexión automática iniciado')
  }

  /**
   * Detener el servicio de reconexión
   */
  stop(): void {
    if (!this.isRunning) return

    this.isRunning = false
    console.log('🛑 Deteniendo servicio de reconexión automática...')

    // Limpiar todos los timers
    this.clearAllTimers()

    this.emit('service_stopped')
    console.log('✅ Servicio de reconexión automática detenido')
  }

  /**
   * Agregar una nueva conexión blockchain al servicio
   */
  addConnection(connection: Omit<BlockchainConnection, 'connectionAttempts' | 'maxRetries' | 'healthCheckInterval'>): void {
    const fullConnection: BlockchainConnection = {
      ...connection,
      connectionAttempts: 0,
      maxRetries: this.config.maxRetries,
      healthCheckInterval: this.config.healthCheckInterval
    }

    this.connections.set(connection.name, fullConnection)
    console.log(`🔗 Conexión agregada: ${connection.name} (Chain ID: ${connection.chainId})`)

    // Iniciar health check para esta conexión
    this.startHealthCheck(connection.name)

    // Si está desconectada, programar reconexión
    if (!connection.isConnected) {
      this.scheduleReconnection(connection.name)
    }
  }

  /**
   * Actualizar el estado de una conexión
   */
  updateConnectionStatus(name: string, status: BlockchainConnection['status'], error?: string): void {
    const connection = this.connections.get(name)
    if (!connection) return

    const previousStatus = connection.status
    connection.status = status
    connection.error = error

    if (status === 'connected') {
      connection.isConnected = true
      connection.lastConnected = Date.now()
      connection.connectionAttempts = 0
      connection.error = undefined
      
      // Limpiar timer de reconexión si existe
      this.clearReconnectionTimer(name)
      
      console.log(`✅ ${name}: Reconectado exitosamente`)
      this.emit('blockchain_reconnected', { name, chainId: connection.chainId })
      
    } else if (status === 'disconnected' || status === 'error') {
      connection.isConnected = false
      connection.lastDisconnected = Date.now()
      
      if (this.config.autoReconnectOnError) {
        this.scheduleReconnection(name)
      }
      
      console.log(`❌ ${name}: Desconectado - ${error || 'Sin especificar'}`)
      this.emit('blockchain_disconnected', { name, chainId: connection.chainId, error })
    }

    // Emitir evento de cambio de estado
    if (previousStatus !== status) {
      this.emit('connection_status_changed', { name, previousStatus, newStatus: status })
    }
  }

  /**
   * Reconectar todas las blockchains desconectadas
   */
  async reconnectAllDisconnected(): Promise<void> {
    console.log('🔄 Iniciando reconexión masiva de blockchains desconectadas...')
    
    const disconnectedConnections = Array.from(this.connections.values())
      .filter(conn => !conn.isConnected && conn.status !== 'connecting')

    if (disconnectedConnections.length === 0) {
      console.log('✅ Todas las blockchains están conectadas')
      return
    }

    console.log(`📡 Reconectando ${disconnectedConnections.length} blockchains...`)

    // Reconectar en paralelo con límite de concurrencia
    const batchSize = 3
    for (let i = 0; i < disconnectedConnections.length; i += batchSize) {
      const batch = disconnectedConnections.slice(i, i + batchSize)
      
      await Promise.allSettled(
        batch.map(conn => this.reconnectBlockchain(conn.name))
      )

      // Pequeña pausa entre lotes para evitar sobrecarga
      if (i + batchSize < disconnectedConnections.length) {
        await new Promise(resolve => setTimeout(resolve, 1000))
      }
    }

    console.log('✅ Proceso de reconexión masiva completado')
  }

  /**
   * Reconectar una blockchain específica
   */
  async reconnectBlockchain(name: string): Promise<boolean> {
    const connection = this.connections.get(name)
    if (!connection) {
      console.error(`❌ Conexión no encontrada: ${name}`)
      return false
    }

    if (connection.status === 'connecting') {
      console.log(`⏳ ${name}: Ya está en proceso de reconexión`)
      return false
    }

    if (connection.connectionAttempts >= connection.maxRetries) {
      console.error(`❌ ${name}: Máximo de intentos de reconexión alcanzado`)
      this.emit('max_reconnection_attempts_reached', { name, chainId: connection.chainId })
      return false
    }

    console.log(`🔄 Reconectando ${name} (intento ${connection.connectionAttempts + 1}/${connection.maxRetries})`)
    
    connection.status = 'connecting'
    connection.connectionAttempts++
    
    this.emit('reconnecting', { name, chainId: connection.chainId, attempt: connection.connectionAttempts })

    try {
      // Intentar conectar usando el RPC principal
      const success = await this.attemptConnection(name, connection.rpcUrl)
      
      if (success) {
        this.updateConnectionStatus(name, 'connected')
        return true
      }

      // Si falla, intentar con RPCs de fallback
      if (this.config.fallbackRPCs && this.fallbackRPCs[name]) {
        console.log(`🔄 ${name}: Intentando con RPCs de fallback...`)
        
        for (const fallbackRPC of this.fallbackRPCs[name]) {
          const fallbackSuccess = await this.attemptConnection(name, fallbackRPC)
          if (fallbackSuccess) {
            // Actualizar la URL del RPC al fallback exitoso
            connection.rpcUrl = fallbackRPC
            this.updateConnectionStatus(name, 'connected')
            console.log(`✅ ${name}: Reconectado usando RPC de fallback: ${fallbackRPC}`)
            return true
          }
        }
      }

      // Si todos los intentos fallan
      this.updateConnectionStatus(name, 'error', 'Todos los RPCs fallaron')
      return false

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Error desconocido'
      this.updateConnectionStatus(name, 'error', errorMessage)
      return false
    }
  }

  /**
   * Intentar conectar a un RPC específico
   */
  private async attemptConnection(name: string, rpcUrl: string): Promise<boolean> {
    try {
      const provider = new ethers.JsonRpcProvider(rpcUrl)
      
      // Verificar conectividad con timeout
      const networkPromise = provider.getNetwork()
      const blockNumberPromise = provider.getBlockNumber()
      
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout')), 10000)
      )

      const [network, blockNumber] = await Promise.race([
        Promise.all([networkPromise, blockNumberPromise]),
        timeoutPromise
      ]) as [ethers.Network, bigint]

      // Verificar que la chain ID coincida
      const connection = this.connections.get(name)
      if (connection && Number(network.chainId) !== connection.chainId) {
        console.warn(`⚠️ ${name}: Chain ID no coincide (esperado: ${connection.chainId}, recibido: ${network.chainId})`)
        return false
      }

      // Medir latencia
      const startTime = Date.now()
      await provider.getBlockNumber()
      const latency = Date.now() - startTime

      // Obtener gas price
      const feeData = await provider.getFeeData()
      const gasPrice = ethers.formatUnits(feeData.gasPrice || feeData.maxFeePerGas || 0n, 'gwei')

      // Actualizar la conexión
      if (connection) {
        connection.provider = provider
        connection.latency = latency
        connection.blockHeight = Number(blockNumber)
        connection.gasPrice = gasPrice
      }

      console.log(`✅ ${name}: Conectado exitosamente (Block: ${blockNumber}, Gas: ${gasPrice} Gwei, Latencia: ${latency}ms)`)
      return true

    } catch (error) {
      console.warn(`⚠️ ${name}: Fallo de conexión con ${rpcUrl}: ${error}`)
      return false
    }
  }

  /**
   * Programar reconexión para una blockchain
   */
  private scheduleReconnection(name: string): void {
    const connection = this.connections.get(name)
    if (!connection) return

    // Limpiar timer existente
    this.clearReconnectionTimer(name)

    // Calcular delay con backoff exponencial
    let delay = this.config.baseDelay
    if (this.config.exponentialBackoff) {
      delay = Math.min(
        this.config.baseDelay * Math.pow(2, connection.connectionAttempts),
        this.config.maxDelay
      )
    }

    console.log(`⏰ ${name}: Programando reconexión en ${delay}ms`)

    const timer = setTimeout(() => {
      this.reconnectBlockchain(name)
    }, delay)

    this.reconnectionTimers.set(name, timer)
  }

  /**
   * Iniciar health checks para todas las conexiones
   */
  private startHealthChecks(): void {
    this.connections.forEach((_, name) => {
      this.startHealthCheck(name)
    })
  }

  /**
   * Iniciar health check para una conexión específica
   */
  private startHealthCheck(name: string): void {
    const connection = this.connections.get(name)
    if (!connection) return

    // Limpiar timer existente
    this.clearHealthCheckTimer(name)

    const timer = setInterval(async () => {
      if (!this.isRunning) return

      try {
        await this.performHealthCheck(name)
      } catch (error) {
        console.error(`❌ Error en health check de ${name}:`, error)
      }
    }, connection.healthCheckInterval)

    this.healthCheckTimers.set(name, timer)
  }

  /**
   * Realizar health check de una conexión
   */
  private async performHealthCheck(name: string): Promise<void> {
    const connection = this.connections.get(name)
    if (!connection || !connection.isConnected) return

    try {
      const startTime = Date.now()
      const blockNumber = await connection.provider.getBlockNumber()
      const latency = Date.now() - startTime

      // Actualizar métricas
      connection.latency = latency
      connection.blockHeight = Number(blockNumber)

      // Verificar que la latencia no sea excesiva
      if (latency > 10000) { // Más de 10 segundos
        console.warn(`⚠️ ${name}: Latencia alta detectada (${latency}ms)`)
        this.emit('high_latency_detected', { name, latency })
      }

      // Emitir evento de health check exitoso
      this.emit('health_check_success', { name, latency, blockHeight: blockNumber })

    } catch (error) {
      console.warn(`⚠️ ${name}: Health check falló - ${error}`)
      
      // Marcar como desconectada si el health check falla
      this.updateConnectionStatus(name, 'error', 'Health check falló')
      
      // Programar reconexión automática
      if (this.config.autoReconnectOnError) {
        this.scheduleReconnection(name)
      }
    }
  }

  /**
   * Limpiar timer de reconexión
   */
  private clearReconnectionTimer(name: string): void {
    const timer = this.reconnectionTimers.get(name)
    if (timer) {
      clearTimeout(timer)
      this.reconnectionTimers.delete(name)
    }
  }

  /**
   * Limpiar timer de health check
   */
  private clearHealthCheckTimer(name: string): void {
    const timer = this.healthCheckTimers.get(name)
    if (timer) {
      clearInterval(timer)
      this.healthCheckTimers.delete(name)
    }
  }

  /**
   * Limpiar todos los timers
   */
  private clearAllTimers(): void {
    this.reconnectionTimers.forEach(timer => clearTimeout(timer))
    this.reconnectionTimers.clear()
    
    this.healthCheckTimers.forEach(timer => clearInterval(timer))
    this.healthCheckTimers.clear()
  }

  /**
   * Configurar manejadores de eventos
   */
  private setupEventHandlers(): void {
    this.on('blockchain_reconnected', ({ name, chainId }) => {
      console.log(`🎉 Blockchain ${name} (${chainId}) reconectada exitosamente`)
    })

    this.on('blockchain_disconnected', ({ name, chainId, error }) => {
      console.log(`💔 Blockchain ${name} (${chainId}) desconectada: ${error}`)
    })

    this.on('reconnecting', ({ name, chainId, attempt }) => {
      console.log(`🔄 Reconectando ${name} (${chainId}) - Intento ${attempt}`)
    })

    this.on('max_reconnection_attempts_reached', ({ name, chainId }) => {
      console.error(`💥 Máximo de intentos de reconexión alcanzado para ${name} (${chainId})`)
    })
  }

  /**
   * Obtener estado de todas las conexiones
   */
  getConnectionStatus(): Map<string, BlockchainConnection> {
    return new Map(this.connections)
  }

  /**
   * Obtener estadísticas de reconexión
   */
  getReconnectionStats(): {
    totalConnections: number
    connectedConnections: number
    disconnectedConnections: number
    reconnectingConnections: number
    errorConnections: number
  } {
    const connections = Array.from(this.connections.values())
    
    return {
      totalConnections: connections.length,
      connectedConnections: connections.filter(c => c.isConnected).length,
      disconnectedConnections: connections.filter(c => !c.isConnected && c.status === 'disconnected').length,
      reconnectingConnections: connections.filter(c => c.status === 'connecting').length,
      errorConnections: connections.filter(c => c.status === 'error').length
    }
  }

  /**
   * Verificar si el servicio está ejecutándose
   */
  isServiceRunning(): boolean {
    return this.isRunning
  }

  /**
   * Obtener configuración actual
   */
  getConfig(): ReconnectionConfig {
    return { ...this.config }
  }
}

// Exportar instancia singleton
export const autoReconnectionService = AutoReconnectionService.getInstance()
