import { ethers } from 'ethers'

export interface BlockchainConfig {
  name: string
  rpcUrl: string
  wsUrl?: string
  chainId: number
  explorer: string
  isConnected: boolean
  latency: number
}

export interface ExchangeConfig {
  name: string
  apiKey: string
  secretKey: string
  isConnected: boolean
  rateLimit: number
}

export interface ValidationResult {
  isValid: boolean
  errors: string[]
  warnings: string[]
  blockchains: BlockchainConfig[]
  exchanges: ExchangeConfig[]
  dataProviders: any[]
  security: any[]
}

export class ConfigurationValidator {
  private static instance: ConfigurationValidator
  private validationResults: ValidationResult

  private constructor() {
    this.validationResults = {
      isValid: false,
      errors: [],
      warnings: [],
      blockchains: [],
      exchanges: [],
      dataProviders: [],
      security: []
    }
  }

  public static getInstance(): ConfigurationValidator {
    if (!ConfigurationValidator.instance) {
      ConfigurationValidator.instance = new ConfigurationValidator()
    }
    return ConfigurationValidator.instance
  }

  /**
   * Valida todas las configuraciones de producción
   */
  public async validateAllConfigurations(): Promise<ValidationResult> {
    console.log('🔍 Iniciando validación completa de configuraciones...')
    
    this.validationResults = {
      isValid: true,
      errors: [],
      warnings: [],
      blockchains: [],
      exchanges: [],
      dataProviders: [],
      security: []
    }

    // 1. Validar Blockchains
    await this.validateBlockchains()
    
    // 2. Validar Exchanges
    await this.validateExchanges()
    
    // 3. Validar Data Providers
    await this.validateDataProviders()
    
    // 4. Validar Security
    await this.validateSecurity()
    
    // 5. Validar Wallets
    await this.validateWallets()
    
    // 6. Validar MEV Protection
    await this.validateMEVProtection()

    console.log('✅ Validación completada')
    return this.validationResults
  }

  /**
   * Valida conectividad con las 8 principales blockchains
   */
  private async validateBlockchains(): Promise<void> {
    console.log('🔗 Validando conectividad con blockchains...')
    
    const blockchains = [
      {
        name: 'Ethereum',
        rpcUrl: import.meta.env.VITE_ETHEREUM_RPC_URL,
        wsUrl: import.meta.env.VITE_ETHEREUM_WS_URL,
        chainId: 1,
        explorer: 'https://etherscan.io'
      },
      {
        name: 'Binance Smart Chain',
        rpcUrl: import.meta.env.VITE_BSC_RPC_URL,
        wsUrl: import.meta.env.VITE_BSC_WS_URL,
        chainId: 56,
        explorer: 'https://bscscan.com'
      },
      {
        name: 'Polygon',
        rpcUrl: import.meta.env.VITE_POLYGON_RPC_URL,
        wsUrl: import.meta.env.VITE_POLYGON_WS_URL,
        chainId: 137,
        explorer: 'https://polygonscan.com'
      },
      {
        name: 'Arbitrum',
        rpcUrl: import.meta.env.VITE_ARBITRUM_RPC_URL,
        wsUrl: import.meta.env.VITE_ARBITRUM_WS_URL,
        chainId: 42161,
        explorer: 'https://arbiscan.io'
      },
      {
        name: 'Optimism',
        rpcUrl: import.meta.env.VITE_OPTIMISM_RPC_URL,
        wsUrl: import.meta.env.VITE_OPTIMISM_WS_URL,
        chainId: 10,
        explorer: 'https://optimistic.etherscan.io'
      },
      {
        name: 'Avalanche',
        rpcUrl: import.meta.env.VITE_AVALANCHE_RPC_URL,
        wsUrl: import.meta.env.VITE_AVALANCHE_WS_URL,
        chainId: 43114,
        explorer: 'https://snowtrace.io'
      },
      {
        name: 'Fantom',
        rpcUrl: import.meta.env.VITE_FANTOM_RPC_URL,
        wsUrl: import.meta.env.VITE_FANTOM_WS_URL,
        chainId: 250,
        explorer: 'https://ftmscan.com'
      },
      {
        name: 'Cronos',
        rpcUrl: import.meta.env.VITE_CRONOS_RPC_URL,
        wsUrl: import.meta.env.VITE_CRONOS_WS_URL,
        chainId: 25,
        explorer: 'https://cronoscan.com'
      }
    ]

    for (const blockchain of blockchains) {
      const startTime = Date.now()
      let isConnected = false
      let latency = 0

      try {
        if (!blockchain.rpcUrl || blockchain.rpcUrl.includes('TU_ALCHEMY_KEY_AQUI')) {
          this.validationResults.errors.push(`❌ ${blockchain.name}: RPC URL no configurada`)
          continue
        }

        const provider = new ethers.JsonRpcProvider(blockchain.rpcUrl)
        const blockNumber = await provider.getBlockNumber()
        latency = Date.now() - startTime
        isConnected = true

        console.log(`✅ ${blockchain.name}: Conectado (Block #${blockNumber}, ${latency}ms)`)
        
        this.validationResults.blockchains.push({
          name: blockchain.name,
          rpcUrl: blockchain.rpcUrl,
          wsUrl: blockchain.wsUrl,
          chainId: blockchain.chainId,
          explorer: blockchain.explorer,
          isConnected,
          latency
        })

      } catch (error) {
        latency = Date.now() - startTime
        console.error(`❌ ${blockchain.name}: Error de conexión - ${error}`)
        this.validationResults.errors.push(`❌ ${blockchain.name}: Error de conexión - ${error}`)
        this.validationResults.isValid = false
      }
    }
  }

  /**
   * Valida configuraciones de exchanges
   */
  private async validateExchanges(): Promise<void> {
    console.log('🏦 Validando configuraciones de exchanges...')
    
    const exchanges = [
      {
        name: 'Binance',
        apiKey: import.meta.env.VITE_BINANCE_API_KEY,
        secretKey: import.meta.env.VITE_BINANCE_SECRET_KEY
      },
      {
        name: 'Coinbase',
        apiKey: import.meta.env.VITE_COINBASE_API_KEY,
        secretKey: import.meta.env.VITE_COINBASE_SECRET
      },
      {
        name: 'Kraken',
        apiKey: import.meta.env.VITE_KRAKEN_API_KEY,
        secretKey: import.meta.env.VITE_KRAKEN_SECRET
      }
    ]

    for (const exchange of exchanges) {
      if (!exchange.apiKey || exchange.apiKey.includes('tu_')) {
        this.validationResults.warnings.push(`⚠️ ${exchange.name}: API Key no configurada`)
        continue
      }

      if (!exchange.secretKey || exchange.secretKey.includes('tu_')) {
        this.validationResults.warnings.push(`⚠️ ${exchange.name}: Secret Key no configurada`)
        continue
      }

      // Aquí se haría una validación real de la API
      this.validationResults.exchanges.push({
        name: exchange.name,
        apiKey: exchange.apiKey,
        secretKey: exchange.secretKey,
        isConnected: true,
        rateLimit: 100
      })

      console.log(`✅ ${exchange.name}: Configurado`)
    }
  }

  /**
   * Valida data providers
   */
  private async validateDataProviders(): Promise<void> {
    console.log('📊 Validando data providers...')
    
    const providers = [
      {
        name: 'CoinGecko',
        apiKey: import.meta.env.VITE_COINGECKO_API_KEY
      },
      {
        name: 'The Graph',
        apiKey: import.meta.env.VITE_THE_GRAPH_API_KEY
      },
      {
        name: 'DexScreener',
        apiKey: import.meta.env.VITE_DEXSCREENER_API_KEY
      }
    ]

    for (const provider of providers) {
      if (!provider.apiKey || provider.apiKey.includes('tu_')) {
        this.validationResults.warnings.push(`⚠️ ${provider.name}: API Key no configurada`)
        continue
      }

      this.validationResults.dataProviders.push({
        name: provider.name,
        apiKey: provider.apiKey,
        isConnected: true
      })

      console.log(`✅ ${provider.name}: Configurado`)
    }
  }

  /**
   * Valida configuraciones de seguridad
   */
  private async validateSecurity(): Promise<void> {
    console.log('🔒 Validando configuraciones de seguridad...')
    
    const securityChecks = [
      {
        name: 'JWT Secret',
        value: import.meta.env.VITE_JWT_SECRET,
        minLength: 32
      },
      {
        name: 'Encryption Key',
        value: import.meta.env.VITE_ENCRYPTION_KEY,
        minLength: 64 // 32 bytes en hex
      }
    ]

    for (const check of securityChecks) {
      if (!check.value || check.value.includes('tu_')) {
        this.validationResults.errors.push(`❌ ${check.name}: No configurado`)
        this.validationResults.isValid = false
        continue
      }

      if (check.value.length < check.minLength) {
        this.validationResults.errors.push(`❌ ${check.name}: Muy corto (mínimo ${check.minLength} caracteres)`)
        this.validationResults.isValid = false
        continue
      }

      this.validationResults.security.push({
        name: check.name,
        isConfigured: true,
        length: check.value.length
      })

      console.log(`✅ ${check.name}: Configurado (${check.value.length} caracteres)`)
    }
  }

  /**
   * Valida configuraciones de wallets
   */
  private async validateWallets(): Promise<void> {
    console.log('💰 Validando configuraciones de wallets...')
    
    const wallets = [
      {
        name: 'Trading Wallet',
        privateKey: import.meta.env.VITE_TRADING_WALLET_PRIVATE_KEY,
        address: import.meta.env.VITE_TRADING_WALLET_ADDRESS
      },
      {
        name: 'Backup Wallet',
        privateKey: import.meta.env.VITE_BACKUP_WALLET_PRIVATE_KEY,
        address: import.meta.env.VITE_BACKUP_WALLET_ADDRESS
      }
    ]

    for (const wallet of wallets) {
      if (!wallet.privateKey || wallet.privateKey.includes('tu_')) {
        this.validationResults.warnings.push(`⚠️ ${wallet.name}: Private Key no configurada`)
        continue
      }

      if (!wallet.address || wallet.address.includes('tu_')) {
        this.validationResults.warnings.push(`⚠️ ${wallet.name}: Address no configurada`)
        continue
      }

      try {
        // Validar formato de private key
        if (!wallet.privateKey.startsWith('0x') || wallet.privateKey.length !== 66) {
          this.validationResults.errors.push(`❌ ${wallet.name}: Private Key formato inválido`)
          this.validationResults.isValid = false
          continue
        }

        // Validar formato de address
        if (!ethers.isAddress(wallet.address)) {
          this.validationResults.errors.push(`❌ ${wallet.name}: Address formato inválido`)
          this.validationResults.isValid = false
          continue
        }

        console.log(`✅ ${wallet.name}: Configurado (${wallet.address})`)
      } catch (error) {
        this.validationResults.errors.push(`❌ ${wallet.name}: Error de validación - ${error}`)
        this.validationResults.isValid = false
      }
    }
  }

  /**
   * Valida configuraciones de MEV Protection
   */
  private async validateMEVProtection(): Promise<void> {
    console.log('🛡️ Validando configuraciones de MEV Protection...')
    
    const mevConfigs = [
      {
        name: 'Flashbots',
        relayUrl: import.meta.env.VITE_FLASHBOTS_RELAY_URL,
        signingKey: import.meta.env.VITE_FLASHBOTS_SIGNING_KEY
      },
      {
        name: 'MEV-Share',
        apiUrl: import.meta.env.VITE_MEVSHARE_API_URL,
        apiKey: import.meta.env.VITE_MEVSHARE_API_KEY
      }
    ]

    for (const config of mevConfigs) {
      if (!config.relayUrl && !config.apiUrl) {
        this.validationResults.warnings.push(`⚠️ ${config.name}: URL no configurada`)
        continue
      }

      if (!config.signingKey && !config.apiKey) {
        this.validationResults.warnings.push(`⚠️ ${config.name}: Key no configurada`)
        continue
      }

      console.log(`✅ ${config.name}: Configurado`)
    }
  }

  /**
   * Genera reporte de validación
   */
  public generateValidationReport(): string {
    const { isValid, errors, warnings, blockchains } = this.validationResults
    
    let report = `# 🔍 REPORTE DE VALIDACIÓN DE CONFIGURACIÓN\n\n`
    report += `**Estado General:** ${isValid ? '✅ VÁLIDO' : '❌ INVÁLIDO'}\n\n`
    
    report += `## 🔗 BLOCKCHAINS (${blockchains.filter(b => b.isConnected).length}/8)\n\n`
    for (const blockchain of blockchains) {
      const status = blockchain.isConnected ? '✅' : '❌'
      report += `${status} **${blockchain.name}**: ${blockchain.isConnected ? `${blockchain.latency}ms` : 'No conectado'}\n`
    }
    
    if (errors.length > 0) {
      report += `\n## ❌ ERRORES CRÍTICOS\n\n`
      errors.forEach(error => report += `- ${error}\n`)
    }
    
    if (warnings.length > 0) {
      report += `\n## ⚠️ ADVERTENCIAS\n\n`
      warnings.forEach(warning => report += `- ${warning}\n`)
    }
    
    return report
  }

  /**
   * Verifica si la configuración está lista para producción
   */
  public isReadyForProduction(): boolean {
    const { isValid, blockchains } = this.validationResults
    
    // Mínimo 3 blockchains conectadas para producción
    const connectedBlockchains = blockchains.filter(b => b.isConnected).length
    
    return isValid && connectedBlockchains >= 3
  }
}

// Exportar instancia singleton
export const configurationValidator = ConfigurationValidator.getInstance() 