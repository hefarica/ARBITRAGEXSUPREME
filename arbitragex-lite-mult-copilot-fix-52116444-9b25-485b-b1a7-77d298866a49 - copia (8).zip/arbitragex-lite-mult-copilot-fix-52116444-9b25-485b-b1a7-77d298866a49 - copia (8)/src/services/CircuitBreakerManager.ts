/**
 * ⚡ CIRCUIT BREAKER MANAGER - ArbitrageX Pro 2025
 * Sistema avanzado de circuit breakers para APIs externas
 */

export interface CircuitBreakerConfig {
  name: string;
  failureThreshold: number; // Número de fallos para abrir
  resetTimeout: number; // Tiempo en ms para reset
  monitoringWindow: number; // Ventana de monitoreo en ms
  halfOpenMaxCalls: number; // Máximo calls en estado half-open
  healthCheckInterval: number; // Intervalo de health check en ms
  timeoutDuration: number; // Timeout por call en ms
}

export interface CircuitBreakerState {
  name: string;
  state: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
  failureCount: number;
  lastFailureTime: number;
  lastSuccessTime: number;
  callsInWindow: number;
  successfulCalls: number;
  failedCalls: number;
  averageResponseTime: number;
  isHealthy: boolean;
}

export interface CallResult<T> {
  success: boolean;
  data?: T;
  error?: Error;
  responseTime: number;
  timestamp: number;
}

export interface HealthCheckResult {
  isHealthy: boolean;
  responseTime: number;
  error?: string;
  timestamp: number;
}

export class CircuitBreaker<T = any> {
  private config: CircuitBreakerConfig;
  private state: CircuitBreakerState;
  private callHistory: { timestamp: number; success: boolean; responseTime: number }[] = [];
  private healthCheckTimer?: NodeJS.Timeout;
  private halfOpenCalls: number = 0;

  constructor(config: CircuitBreakerConfig) {
    this.config = config;
    this.state = {
      name: config.name,
      state: 'CLOSED',
      failureCount: 0,
      lastFailureTime: 0,
      lastSuccessTime: Date.now(),
      callsInWindow: 0,
      successfulCalls: 0,
      failedCalls: 0,
      averageResponseTime: 0,
      isHealthy: true
    };

    this.startHealthCheck();
  }

  /**
   * Ejecutar función con circuit breaker
   */
  async execute<TResult = T>(
    operation: () => Promise<TResult>,
    fallback?: () => Promise<TResult>
  ): Promise<CallResult<TResult>> {
    const startTime = Date.now();

    // Verificar estado del circuit breaker
    if (this.state.state === 'OPEN') {
      return this.handleOpenState(fallback);
    }

    if (this.state.state === 'HALF_OPEN' && this.halfOpenCalls >= this.config.halfOpenMaxCalls) {
      return this.handleOpenState(fallback);
    }

    try {
      // Ejecutar con timeout
      const data = await this.executeWithTimeout(operation);
      const responseTime = Date.now() - startTime;

      // Registrar éxito
      this.recordSuccess(responseTime);

      return {
        success: true,
        data,
        responseTime,
        timestamp: Date.now()
      };

    } catch (error) {
      const responseTime = Date.now() - startTime;

      // Registrar fallo
      this.recordFailure(error as Error, responseTime);

      // Intentar fallback si está disponible
      if (fallback) {
        try {
          const fallbackData = await fallback();
          return {
            success: true,
            data: fallbackData,
            responseTime: Date.now() - startTime,
            timestamp: Date.now()
          };
        } catch (fallbackError) {
          return {
            success: false,
            error: fallbackError as Error,
            responseTime,
            timestamp: Date.now()
          };
        }
      }

      return {
        success: false,
        error: error as Error,
        responseTime,
        timestamp: Date.now()
      };
    }
  }

  /**
   * Ejecutar operación con timeout
   */
  private async executeWithTimeout<TResult>(
    operation: () => Promise<TResult>
  ): Promise<TResult> {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error(`Timeout after ${this.config.timeoutDuration}ms`));
      }, this.config.timeoutDuration);

      operation()
        .then(result => {
          clearTimeout(timeout);
          resolve(result);
        })
        .catch(error => {
          clearTimeout(timeout);
          reject(error);
        });
    });
  }

  /**
   * Manejar estado OPEN
   */
  private async handleOpenState<TResult>(
    fallback?: () => Promise<TResult>
  ): Promise<CallResult<TResult>> {
    // Verificar si es tiempo de intentar reset
    const timeSinceLastFailure = Date.now() - this.state.lastFailureTime;
    if (timeSinceLastFailure >= this.config.resetTimeout) {
      this.state.state = 'HALF_OPEN';
      this.halfOpenCalls = 0;
      console.log(`🔄 Circuit breaker ${this.config.name} pasó a HALF_OPEN`);
    }

    // Intentar fallback
    if (fallback) {
      try {
        const data = await fallback();
        return {
          success: true,
          data,
          responseTime: 0,
          timestamp: Date.now()
        };
      } catch (error) {
        return {
          success: false,
          error: error as Error,
          responseTime: 0,
          timestamp: Date.now()
        };
      }
    }

    return {
      success: false,
      error: new Error(`Circuit breaker ${this.config.name} is OPEN`),
      responseTime: 0,
      timestamp: Date.now()
    };
  }

  /**
   * Registrar éxito
   */
  private recordSuccess(responseTime: number): void {
    this.state.successfulCalls++;
    this.state.lastSuccessTime = Date.now();
    this.state.failureCount = 0;

    if (this.state.state === 'HALF_OPEN') {
      this.halfOpenCalls++;
      
      // Si suficientes calls exitosos en half-open, cerrar el circuit
      if (this.halfOpenCalls >= this.config.halfOpenMaxCalls) {
        this.state.state = 'CLOSED';
        this.halfOpenCalls = 0;
        console.log(`✅ Circuit breaker ${this.config.name} cerrado después de recovery`);
      }
    }

    this.addToHistory(true, responseTime);
    this.updateMetrics();
  }

  /**
   * Registrar fallo
   */
  private recordFailure(error: Error, responseTime: number): void {
    this.state.failedCalls++;
    this.state.failureCount++;
    this.state.lastFailureTime = Date.now();

    if (this.state.state === 'HALF_OPEN') {
      // Volver a OPEN si falla en half-open
      this.state.state = 'OPEN';
      this.halfOpenCalls = 0;
      console.log(`❌ Circuit breaker ${this.config.name} volvió a OPEN desde HALF_OPEN`);
    } else if (this.state.failureCount >= this.config.failureThreshold) {
      // Abrir circuit si excede threshold
      this.state.state = 'OPEN';
      console.log(`🚨 Circuit breaker ${this.config.name} ABIERTO - ${this.state.failureCount} fallos`);
    }

    this.addToHistory(false, responseTime);
    this.updateMetrics();
  }

  /**
   * Agregar a historial
   */
  private addToHistory(success: boolean, responseTime: number): void {
    const now = Date.now();
    this.callHistory.push({ timestamp: now, success, responseTime });

    // Limpiar historial fuera de la ventana de monitoreo
    const windowStart = now - this.config.monitoringWindow;
    this.callHistory = this.callHistory.filter(call => call.timestamp >= windowStart);
  }

  /**
   * Actualizar métricas
   */
  private updateMetrics(): void {
    this.state.callsInWindow = this.callHistory.length;
    
    if (this.callHistory.length > 0) {
      const totalResponseTime = this.callHistory.reduce((sum, call) => sum + call.responseTime, 0);
      this.state.averageResponseTime = totalResponseTime / this.callHistory.length;
    }

    // Determinar salud basada en tasa de éxito reciente
    const recentSuccesses = this.callHistory.filter(call => call.success).length;
    const successRate = this.callHistory.length > 0 ? recentSuccesses / this.callHistory.length : 1;
    this.state.isHealthy = successRate >= 0.8; // 80% mínimo
  }

  /**
   * Health check periódico
   */
  private startHealthCheck(): void {
    this.healthCheckTimer = setInterval(async () => {
      await this.performHealthCheck();
    }, this.config.healthCheckInterval);
  }

  /**
   * Realizar health check
   */
  private async performHealthCheck(): Promise<HealthCheckResult> {
    // Implementar lógica específica de health check por servicio
    // Por ahora, basado en métricas internas
    const isHealthy = this.state.isHealthy && this.state.state !== 'OPEN';
    
    return {
      isHealthy,
      responseTime: this.state.averageResponseTime,
      timestamp: Date.now()
    };
  }

  /**
   * Obtener estado actual
   */
  getState(): CircuitBreakerState {
    return { ...this.state };
  }

  /**
   * Resetear circuit breaker manualmente
   */
  reset(): void {
    this.state.state = 'CLOSED';
    this.state.failureCount = 0;
    this.halfOpenCalls = 0;
    this.callHistory = [];
    console.log(`🔄 Circuit breaker ${this.config.name} reseteado manualmente`);
  }

  /**
   * Forzar apertura del circuit
   */
  forceOpen(): void {
    this.state.state = 'OPEN';
    this.state.lastFailureTime = Date.now();
    console.log(`🔒 Circuit breaker ${this.config.name} forzado a OPEN`);
  }

  /**
   * Destruir circuit breaker
   */
  destroy(): void {
    if (this.healthCheckTimer) {
      clearInterval(this.healthCheckTimer);
    }
  }
}

/**
 * Manager para múltiples circuit breakers
 */
export class CircuitBreakerManager {
  private static instance: CircuitBreakerManager;
  private breakers: Map<string, CircuitBreaker> = new Map();

  private constructor() {}

  public static getInstance(): CircuitBreakerManager {
    if (!CircuitBreakerManager.instance) {
      CircuitBreakerManager.instance = new CircuitBreakerManager();
    }
    return CircuitBreakerManager.instance;
  }

  /**
   * Crear circuit breaker para servicio
   */
  createBreaker(config: CircuitBreakerConfig): CircuitBreaker {
    const breaker = new CircuitBreaker(config);
    this.breakers.set(config.name, breaker);
    console.log(`⚡ Circuit breaker creado: ${config.name}`);
    return breaker;
  }

  /**
   * Obtener circuit breaker
   */
  getBreaker(name: string): CircuitBreaker | undefined {
    return this.breakers.get(name);
  }

  /**
   * Crear circuit breakers para servicios comunes
   */
  initializeCommonBreakers(): void {
    // CoinGecko API
    this.createBreaker({
      name: 'coingecko',
      failureThreshold: 5,
      resetTimeout: 30000, // 30s
      monitoringWindow: 60000, // 1 min
      halfOpenMaxCalls: 3,
      healthCheckInterval: 15000, // 15s
      timeoutDuration: 5000 // 5s
    });

    // Binance API
    this.createBreaker({
      name: 'binance',
      failureThreshold: 3,
      resetTimeout: 20000, // 20s
      monitoringWindow: 60000,
      halfOpenMaxCalls: 2,
      healthCheckInterval: 10000, // 10s
      timeoutDuration: 3000 // 3s
    });

    // Ethereum RPC
    this.createBreaker({
      name: 'ethereum-rpc',
      failureThreshold: 5,
      resetTimeout: 15000, // 15s
      monitoringWindow: 120000, // 2 min
      halfOpenMaxCalls: 3,
      healthCheckInterval: 5000, // 5s
      timeoutDuration: 10000 // 10s
    });

    // Polygon RPC
    this.createBreaker({
      name: 'polygon-rpc',
      failureThreshold: 5,
      resetTimeout: 15000,
      monitoringWindow: 120000,
      halfOpenMaxCalls: 3,
      healthCheckInterval: 5000,
      timeoutDuration: 8000 // 8s
    });

    // BSC RPC
    this.createBreaker({
      name: 'bsc-rpc',
      failureThreshold: 5,
      resetTimeout: 15000,
      monitoringWindow: 120000,
      halfOpenMaxCalls: 3,
      healthCheckInterval: 5000,
      timeoutDuration: 8000
    });

    // The Graph
    this.createBreaker({
      name: 'thegraph',
      failureThreshold: 4,
      resetTimeout: 25000, // 25s
      monitoringWindow: 90000, // 1.5 min
      halfOpenMaxCalls: 2,
      healthCheckInterval: 12000, // 12s
      timeoutDuration: 7000 // 7s
    });

    // DexScreener
    this.createBreaker({
      name: 'dexscreener',
      failureThreshold: 4,
      resetTimeout: 30000,
      monitoringWindow: 60000,
      halfOpenMaxCalls: 2,
      healthCheckInterval: 15000,
      timeoutDuration: 6000 // 6s
    });

    // Flashbots
    this.createBreaker({
      name: 'flashbots',
      failureThreshold: 3,
      resetTimeout: 10000, // 10s - más agresivo para MEV
      monitoringWindow: 60000,
      halfOpenMaxCalls: 2,
      healthCheckInterval: 5000,
      timeoutDuration: 5000 // 5s
    });

    console.log('⚡ Circuit breakers inicializados para todos los servicios');
  }

  /**
   * Obtener estado de todos los breakers
   */
  getAllStates(): Record<string, CircuitBreakerState> {
    const states: Record<string, CircuitBreakerState> = {};
    
    for (const [name, breaker] of this.breakers) {
      states[name] = breaker.getState();
    }

    return states;
  }

  /**
   * Resetear todos los circuit breakers
   */
  resetAll(): void {
    for (const [name, breaker] of this.breakers) {
      breaker.reset();
    }
    console.log('🔄 Todos los circuit breakers reseteados');
  }

  /**
   * Obtener resumen de salud
   */
  getHealthSummary(): {
    totalBreakers: number;
    healthyBreakers: number;
    openBreakers: number;
    halfOpenBreakers: number;
    overallHealth: number;
  } {
    const states = this.getAllStates();
    const total = Object.keys(states).length;
    
    const healthy = Object.values(states).filter(s => s.isHealthy).length;
    const open = Object.values(states).filter(s => s.state === 'OPEN').length;
    const halfOpen = Object.values(states).filter(s => s.state === 'HALF_OPEN').length;

    return {
      totalBreakers: total,
      healthyBreakers: healthy,
      openBreakers: open,
      halfOpenBreakers: halfOpen,
      overallHealth: total > 0 ? (healthy / total) * 100 : 100
    };
  }

  /**
   * Destruir todos los circuit breakers
   */
  destroy(): void {
    for (const [name, breaker] of this.breakers) {
      breaker.destroy();
    }
    this.breakers.clear();
  }
}

// Export singleton instance
export const circuitBreakerManager = CircuitBreakerManager.getInstance();
export default CircuitBreakerManager;
