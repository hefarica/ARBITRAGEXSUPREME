/**
 * ServiceConfigValidator.ts
 * ========================
 * 
 * VALIDADOR DE CONFIGURACIÓN DE SERVICIOS REALES
 * - Verifica que todos los servicios requeridos estén configurados
 * - Valida credenciales y conectividad
 * - Proporciona recomendaciones de configuración
 * - Integra con Truth Guard para detectar configuraciones mock
 */

interface ServiceConfig {
  name: string
  type: 'api_key' | 'rpc_url' | 'database_url' | 'oauth' | 'webhook'
  required: boolean
  configured: boolean
  valid: boolean
  lastTest?: Date
  error?: string
  recommendation?: string
}

interface ValidationResult {
  overall_status: 'valid' | 'partial' | 'invalid'
  total_services: number
  configured_services: number
  valid_services: number
  missing_services: string[]
  invalid_services: string[]
  recommendations: string[]
  next_steps: string[]
}

export class ServiceConfigValidator {
  private static instance: ServiceConfigValidator
  private configs: Map<string, ServiceConfig> = new Map()

  private constructor() {
    this.initializeRequiredServices()
  }

  static getInstance(): ServiceConfigValidator {
    if (!ServiceConfigValidator.instance) {
      ServiceConfigValidator.instance = new ServiceConfigValidator()
    }
    return ServiceConfigValidator.instance
  }

  /**
   * Initialize all required services for ArbitrageX Pro
   */
  private initializeRequiredServices(): void {
    const requiredServices: Partial<ServiceConfig>[] = [
      // Price Feed APIs
      {
        name: 'CoinGecko API',
        type: 'api_key',
        required: true,
        recommendation: 'Sign up at https://coingecko.com/api and get API key'
      },
      {
        name: 'Binance API',
        type: 'api_key',
        required: true,
        recommendation: 'Create API key at https://binance.com/api-management'
      },
      {
        name: 'Coinbase API',
        type: 'api_key',
        required: false,
        recommendation: 'Optional: Get API key from Coinbase Pro/Advanced Trade'
      },

      // Blockchain RPC Providers
      {
        name: 'Infura RPC',
        type: 'api_key',
        required: true,
        recommendation: 'Get project ID from https://infura.io/dashboard'
      },
      {
        name: 'Alchemy RPC',
        type: 'api_key',
        required: true,
        recommendation: 'Create API key at https://dashboard.alchemy.com'
      },
      {
        name: 'QuickNode RPC',
        type: 'rpc_url',
        required: false,
        recommendation: 'Optional: Premium RPC from https://quicknode.com'
      },

      // Database Services
      {
        name: 'MongoDB',
        type: 'database_url',
        required: true,
        recommendation: 'Configure MongoDB Atlas or local instance'
      },
      {
        name: 'Redis',
        type: 'database_url',
        required: true,
        recommendation: 'Configure Redis for caching and real-time data'
      },
      {
        name: 'Supabase',
        type: 'api_key',
        required: false,
        recommendation: 'Optional: Supabase for additional backend services'
      },

      // Authentication Services
      {
        name: 'Auth0',
        type: 'oauth',
        required: false,
        recommendation: 'Optional: Configure Auth0 for enterprise authentication'
      },

      // Notification Services
      {
        name: 'Telegram Bot',
        type: 'api_key',
        required: false,
        recommendation: 'Optional: Create bot via @BotFather for notifications'
      },
      {
        name: 'Discord Webhook',
        type: 'webhook',
        required: false,
        recommendation: 'Optional: Discord webhook for alerts'
      },

      // MEV Protection
      {
        name: 'Flashbots',
        type: 'api_key',
        required: true,
        recommendation: 'Configure Flashbots for MEV protection'
      },

      // Analytics
      {
        name: 'Etherscan API',
        type: 'api_key',
        required: true,
        recommendation: 'Get API key from https://etherscan.io/apis'
      },
      {
        name: 'BSCScan API',
        type: 'api_key',
        required: true,
        recommendation: 'Get API key from https://bscscan.com/apis'
      },
      {
        name: 'PolygonScan API',
        type: 'api_key',
        required: true,
        recommendation: 'Get API key from https://polygonscan.com/apis'
      }
    ]

    requiredServices.forEach(service => {
      this.configs.set(service.name!, {
        configured: false,
        valid: false,
        ...service
      } as ServiceConfig)
    })
  }

  /**
   * Validate all service configurations
   */
  async validateAllServices(): Promise<ValidationResult> {
    const results: ValidationResult = {
      overall_status: 'invalid',
      total_services: this.configs.size,
      configured_services: 0,
      valid_services: 0,
      missing_services: [],
      invalid_services: [],
      recommendations: [],
      next_steps: []
    }

    // Check each service configuration
    for (const [serviceName, config] of this.configs) {
      await this.validateSingleService(serviceName)
      const updatedConfig = this.configs.get(serviceName)!

      if (updatedConfig.configured) {
        results.configured_services++
      } else if (updatedConfig.required) {
        results.missing_services.push(serviceName)
        results.recommendations.push(updatedConfig.recommendation || `Configure ${serviceName}`)
      }

      if (updatedConfig.valid) {
        results.valid_services++
      } else if (updatedConfig.configured) {
        results.invalid_services.push(serviceName)
        if (updatedConfig.error) {
          results.recommendations.push(`Fix ${serviceName}: ${updatedConfig.error}`)
        }
      }
    }

    // Determine overall status
    const requiredServices = Array.from(this.configs.values()).filter(c => c.required).length
    const validRequiredServices = Array.from(this.configs.values())
      .filter(c => c.required && c.valid).length

    if (validRequiredServices === requiredServices) {
      results.overall_status = 'valid'
    } else if (validRequiredServices > 0) {
      results.overall_status = 'partial'
    } else {
      results.overall_status = 'invalid'
    }

    // Generate next steps
    results.next_steps = this.generateNextSteps(results)

    return results
  }

  /**
   * Validate a single service configuration
   */
  private async validateSingleService(serviceName: string): Promise<void> {
    const config = this.configs.get(serviceName)
    if (!config) return

    try {
      const validation = await this.performServiceValidation(serviceName, config)
      
      this.configs.set(serviceName, {
        ...config,
        configured: validation.configured,
        valid: validation.valid,
        lastTest: new Date(),
        error: validation.error
      })
    } catch (error) {
      this.configs.set(serviceName, {
        ...config,
        configured: false,
        valid: false,
        lastTest: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error'
      })
    }
  }

  /**
   * Perform actual validation for each service type
   */
  private async performServiceValidation(serviceName: string, config: ServiceConfig): Promise<{
    configured: boolean
    valid: boolean
    error?: string
  }> {
    switch (serviceName) {
      case 'CoinGecko API':
        return await this.validateCoinGeckoAPI()
      
      case 'Binance API':
        return await this.validateBinanceAPI()
      
      case 'Infura RPC':
        return await this.validateInfuraRPC()
      
      case 'Alchemy RPC':
        return await this.validateAlchemyRPC()
      
      case 'MongoDB':
        return await this.validateMongoDB()
      
      case 'Redis':
        return await this.validateRedis()
      
      case 'Flashbots':
        return await this.validateFlashbots()
      
      case 'Etherscan API':
        return await this.validateEtherscanAPI()
      
      default:
        return await this.validateGenericService(serviceName, config)
    }
  }

  /**
   * Specific validation methods for each service
   */
  private async validateCoinGeckoAPI(): Promise<{ configured: boolean; valid: boolean; error?: string }> {
    const apiKey = process.env.COINGECKO_API_KEY || process.env.REACT_APP_COINGECKO_API_KEY
    
    if (!apiKey || this.isPlaceholderValue(apiKey)) {
      return {
        configured: false,
        valid: false,
        error: 'CoinGecko API key not configured or contains placeholder'
      }
    }

    try {
      // Test API connection
      const response = await fetch(`https://api.coingecko.com/api/v3/ping?x_cg_demo_api_key=${apiKey}`)
      if (response.ok) {
        return { configured: true, valid: true }
      } else {
        return {
          configured: true,
          valid: false,
          error: `CoinGecko API returned ${response.status}: ${response.statusText}`
        }
      }
    } catch (error) {
      return {
        configured: true,
        valid: false,
        error: `CoinGecko API connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      }
    }
  }

  private async validateBinanceAPI(): Promise<{ configured: boolean; valid: boolean; error?: string }> {
    const apiKey = process.env.BINANCE_API_KEY || process.env.REACT_APP_BINANCE_API_KEY
    
    if (!apiKey || this.isPlaceholderValue(apiKey)) {
      return {
        configured: false,
        valid: false,
        error: 'Binance API key not configured'
      }
    }

    try {
      // Test Binance API
      const response = await fetch('https://api.binance.com/api/v3/exchangeInfo')
      if (response.ok) {
        return { configured: true, valid: true }
      } else {
        return {
          configured: true,
          valid: false,
          error: `Binance API error: ${response.statusText}`
        }
      }
    } catch (error) {
      return {
        configured: true,
        valid: false,
        error: `Binance API connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      }
    }
  }

  private async validateInfuraRPC(): Promise<{ configured: boolean; valid: boolean; error?: string }> {
    const projectId = process.env.INFURA_PROJECT_ID || process.env.REACT_APP_INFURA_PROJECT_ID
    
    if (!projectId || projectId.includes('YOUR_') || projectId === 'xxx') {
      return {
        configured: false,
        valid: false,
        error: 'Infura project ID not configured'
      }
    }

    try {
      // Test Infura RPC
      const response = await fetch(`https://mainnet.infura.io/v3/${projectId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'eth_blockNumber',
          params: [],
          id: 1
        })
      })

      if (response.ok) {
        const data = await response.json()
        if (data.result) {
          return { configured: true, valid: true }
        }
      }
      
      return {
        configured: true,
        valid: false,
        error: 'Infura RPC test failed'
      }
    } catch (error) {
      return {
        configured: true,
        valid: false,
        error: `Infura RPC connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      }
    }
  }

  private async validateAlchemyRPC(): Promise<{ configured: boolean; valid: boolean; error?: string }> {
    const apiKey = process.env.ALCHEMY_API_KEY || process.env.REACT_APP_ALCHEMY_API_KEY
    
    if (!apiKey || this.isPlaceholderValue(apiKey)) {
      return {
        configured: false,
        valid: false,
        error: 'Alchemy API key not configured'
      }
    }

    // For now, just check if it's configured (actual RPC test would need full URL)
    return { configured: true, valid: true }
  }

  private async validateMongoDB(): Promise<{ configured: boolean; valid: boolean; error?: string }> {
    const mongoUri = process.env.MONGODB_URI || process.env.REACT_APP_MONGODB_URI
    
    if (!mongoUri || mongoUri.includes('YOUR_') || mongoUri === 'xxx') {
      return {
        configured: false,
        valid: false,
        error: 'MongoDB URI not configured'
      }
    }

    // Basic URI validation
    if (!mongoUri.startsWith('mongodb://') && !mongoUri.startsWith('mongodb+srv://')) {
      return {
        configured: true,
        valid: false,
        error: 'Invalid MongoDB URI format'
      }
    }

    return { configured: true, valid: true } // Would need actual MongoDB connection to fully validate
  }

  private async validateRedis(): Promise<{ configured: boolean; valid: boolean; error?: string }> {
    const redisUrl = process.env.REDIS_URL || process.env.REACT_APP_REDIS_URL
    
    if (!redisUrl || redisUrl.includes('YOUR_') || redisUrl === 'xxx') {
      return {
        configured: false,
        valid: false,
        error: 'Redis URL not configured'
      }
    }

    return { configured: true, valid: true }
  }

  private async validateFlashbots(): Promise<{ configured: boolean; valid: boolean; error?: string }> {
    const privateKey = process.env.FLASHBOTS_PRIVATE_KEY
    
    if (!privateKey || privateKey.includes('YOUR_') || privateKey === 'xxx') {
      return {
        configured: false,
        valid: false,
        error: 'Flashbots private key not configured'
      }
    }

    return { configured: true, valid: true }
  }

  private async validateEtherscanAPI(): Promise<{ configured: boolean; valid: boolean; error?: string }> {
    const apiKey = process.env.ETHERSCAN_API_KEY || process.env.REACT_APP_ETHERSCAN_API_KEY
    
    if (!apiKey || this.isPlaceholderValue(apiKey)) {
      return {
        configured: false,
        valid: false,
        error: 'Etherscan API key not configured'
      }
    }

    try {
      // Test Etherscan API
      const response = await fetch(`https://api.etherscan.io/api?module=stats&action=ethsupply&apikey=${apiKey}`)
      if (response.ok) {
        const data = await response.json()
        if (data.status === '1') {
          return { configured: true, valid: true }
        }
      }
      
      return {
        configured: true,
        valid: false,
        error: 'Etherscan API test failed'
      }
    } catch (error) {
      return {
        configured: true,
        valid: false,
        error: `Etherscan API connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      }
    }
  }

  private async validateGenericService(serviceName: string, config: ServiceConfig): Promise<{
    configured: boolean; valid: boolean; error?: string
  }> {
    // Generic validation based on service type
    const envVarName = serviceName.replace(/\s+/g, '_').toUpperCase() + '_API_KEY'
    const envValue = process.env[envVarName] || process.env[`REACT_APP_${envVarName}`]
    
    if (!envValue || envValue.includes('YOUR_') || envValue === 'xxx') {
      return {
        configured: false,
        valid: false,
        error: `${serviceName} not configured (check ${envVarName})`
      }
    }

    return { configured: true, valid: true }
  }

  /**
   * Generate actionable next steps based on validation results
   */
  private generateNextSteps(results: ValidationResult): string[] {
    const steps: string[] = []

    if (results.missing_services.length > 0) {
      steps.push('Configure missing required services: ' + results.missing_services.join(', '))
    }

    if (results.invalid_services.length > 0) {
      steps.push('Fix invalid service configurations: ' + results.invalid_services.join(', '))
    }

    if (results.overall_status === 'valid') {
      steps.push('All required services are configured and valid')
      steps.push('Run Truth Guard audit to ensure no mock data remains')
      steps.push('Start real-time data feeds')
    } else {
      steps.push('Complete service configuration before enabling production mode')
      steps.push('Use TEST mode with testnet endpoints until all services are configured')
    }

    return steps
  }

  /**
   * Get configuration status for a specific service
   */
  getServiceConfig(serviceName: string): ServiceConfig | null {
    return this.configs.get(serviceName) || null
  }

  /**
   * Get all service configurations
   */
  getAllServiceConfigs(): Map<string, ServiceConfig> {
    return new Map(this.configs)
  }

  /**
   * Update service configuration manually
   */
  updateServiceConfig(serviceName: string, updates: Partial<ServiceConfig>): void {
    const current = this.configs.get(serviceName)
    if (current) {
      this.configs.set(serviceName, { ...current, ...updates })
    }
  }
}

// React hook for service validation
export function useServiceValidation() {
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null)
  const [isValidating, setIsValidating] = useState(false)

  const validator = ServiceConfigValidator.getInstance()

  const runValidation = async () => {
    setIsValidating(true)
    try {
      const result = await validator.validateAllServices()
      setValidationResult(result)
    } catch (error) {
      console.error('Service validation failed:', error)
    } finally {
      setIsValidating(false)
    }
  }

  useEffect(() => {
    runValidation()
  }, [])

  return {
    validationResult,
    isValidating,
    runValidation,
    validator
  }
}

export default ServiceConfigValidator