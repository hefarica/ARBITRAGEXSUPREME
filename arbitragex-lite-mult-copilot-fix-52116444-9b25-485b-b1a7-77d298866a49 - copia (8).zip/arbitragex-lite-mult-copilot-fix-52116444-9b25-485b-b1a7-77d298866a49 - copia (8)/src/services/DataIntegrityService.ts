// services/DataIntegrityService.ts
/**
 * SERVICIO DE INTEGRIDAD DE DATOS
 * Valida que todos los datos sean reales y no ficticios
 */

import { mockDataDetector } from '../audit/MockDataDetector';

export interface DataValidationResult {
  isValid: boolean;
  dataType: string;
  value: any;
  source: 'real' | 'mock' | 'unknown';
  integrationRequired?: string;
  credentialsNeeded?: string[];
  validationTimestamp: Date;
}

export class DataIntegrityService {
  private static instance: DataIntegrityService;
  private validationCache = new Map<string, DataValidationResult>();

  static getInstance(): DataIntegrityService {
    if (!DataIntegrityService.instance) {
      DataIntegrityService.instance = new DataIntegrityService();
    }
    return DataIntegrityService.instance;
  }

  /**
   * Valida si un valor es datos reales o mock
   */
  async validateData(dataType: string, value: any): Promise<DataValidationResult> {
    const cacheKey = `${dataType}:${JSON.stringify(value)}`;
    
    if (this.validationCache.has(cacheKey)) {
      return this.validationCache.get(cacheKey)!;
    }

    const result = await this.performValidation(dataType, value);
    this.validationCache.set(cacheKey, result);

    return result;
  }

  /**
   * Realiza la validación real de datos
   */
  private async performValidation(dataType: string, value: any): Promise<DataValidationResult> {
    const result: DataValidationResult = {
      isValid: true,
      dataType,
      value,
      source: 'unknown',
      validationTimestamp: new Date()
    };

    // Convertir a string para análisis
    const stringValue = String(value);

    // Detectar patrones de mock data
    if (this.isMockData(stringValue)) {
      result.isValid = false;
      result.source = 'mock';
      result.integrationRequired = this.getRequiredIntegration(dataType, stringValue);
      result.credentialsNeeded = this.getRequiredCredentials(dataType);
      
      console.warn(`🚨 Mock data detectado: ${dataType} = ${stringValue}`);
      console.warn(`🔧 Integración requerida: ${result.integrationRequired}`);
      
      return result;
    }

    // Validar según tipo de dato
    switch (dataType) {
      case 'email':
        result.isValid = await this.validateEmail(stringValue);
        result.source = result.isValid ? 'real' : 'mock';
        break;
        
      case 'phone':
        result.isValid = await this.validatePhoneNumber(stringValue);
        result.source = result.isValid ? 'real' : 'mock';
        break;
        
      case 'address':
        result.isValid = await this.validateAddress(stringValue);
        result.source = result.isValid ? 'real' : 'mock';
        break;
        
      case 'amount':
        result.isValid = await this.validateFinancialAmount(stringValue);
        result.source = result.isValid ? 'real' : 'mock';
        break;
        
      case 'user_name':
        result.isValid = await this.validateUserName(stringValue);
        result.source = result.isValid ? 'real' : 'mock';
        break;
        
      default:
        result.source = 'real'; // Asumir real si no es un tipo conocido
    }

    if (!result.isValid) {
      result.integrationRequired = this.getRequiredIntegration(dataType, stringValue);
      result.credentialsNeeded = this.getRequiredCredentials(dataType);
    }

    return result;
  }

  /**
   * Detecta si un valor es mock data usando patrones
   */
  private isMockData(value: string): boolean {
    const mockPatterns = [
      /mock/gi, /fake/gi, /dummy/gi, /sample/gi, /test/gi, /demo/gi,
      /example/gi, /placeholder/gi, /lorem/gi, /ipsum/gi,
      /test@[\w.-]+/gi, /demo@[\w.-]+/gi, /example@[\w.-]+/gi,
      /John Doe/gi, /Jane Smith/gi, /Test User/gi, /Demo User/gi,
      /123 Main St/gi, /Sample Street/gi, /Test Address/gi,
      /555-555-\d{4}/g, /000-000-\d{4}/g, /123-456-\d{4}/g,
      /\$100\.00/g, /\$999\.99/g, /2023-01-01/g
    ];

    return mockPatterns.some(pattern => pattern.test(value));
  }

  /**
   * Valida email real
   */
  private async validateEmail(email: string): Promise<boolean> {
    // Verificar formato básico
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return false;

    // Verificar dominios mock comunes
    const mockDomains = ['test.com', 'demo.com', 'example.com', 'fake.com'];
    const domain = email.split('@')[1];
    if (mockDomains.includes(domain)) return false;

    // En implementación real, verificar con servicio de validación de email
    // como Hunter.io, ZeroBounce, etc.
    
    return true; // Placeholder - implementar validación real
  }

  /**
   * Valida número de teléfono real
   */
  private async validatePhoneNumber(phone: string): Promise<boolean> {
    // Verificar patrones de números falsos
    const fakePatterns = [
      /555-555-\d{4}/, /000-000-\d{4}/, /123-456-\d{4}/, /999-999-\d{4}/
    ];
    
    if (fakePatterns.some(pattern => pattern.test(phone))) return false;

    // En implementación real, usar Twilio Lookup API o similar
    // para verificar que el número existe y es válido
    
    return true; // Placeholder - implementar validación real
  }

  /**
   * Valida dirección real
   */
  private async validateAddress(address: string): Promise<boolean> {
    // Verificar direcciones claramente falsas
    const fakeAddresses = [
      '123 Main St', 'Sample Street', 'Test Address', 'Fake Avenue', 'Demo Street'
    ];
    
    if (fakeAddresses.some(fake => address.includes(fake))) return false;

    // En implementación real, usar Google Geocoding API
    // para verificar que la dirección existe
    
    return true; // Placeholder - implementar validación real
  }

  /**
   * Valida monto financiero real
   */
  private async validateFinancialAmount(amount: string): Promise<boolean> {
    // Verificar montos obviamente falsos o redondos sospechosos
    const suspiciousAmounts = ['100.00', '999.99', '0.00', '1000.00'];
    
    if (suspiciousAmounts.includes(amount)) return false;

    // En implementación real, verificar con sistema contable
    // que el monto corresponde a una transacción real
    
    return true; // Placeholder - implementar validación real
  }

  /**
   * Valida nombre de usuario real
   */
  private async validateUserName(name: string): Promise<boolean> {
    // Verificar nombres claramente falsos
    const fakeNames = [
      'John Doe', 'Jane Smith', 'Test User', 'Demo User', 
      'Usuario Prueba', 'Sample User', 'Example User'
    ];
    
    if (fakeNames.includes(name)) return false;

    // En implementación real, verificar con directorio activo
    // o base de datos de usuarios que el nombre corresponde a un usuario real
    
    return true; // Placeholder - implementar validación real
  }

  /**
   * Obtiene la integración requerida para un tipo de dato
   */
  private getRequiredIntegration(dataType: string, value: string): string {
    switch (dataType) {
      case 'email':
      case 'user_name':
        return 'Azure AD / Microsoft Graph API';
      case 'phone':
        return 'Twilio Lookup API / CRM System';
      case 'address':
        return 'Google Geocoding API';
      case 'amount':
        return 'QuickBooks API / Sistema Contable';
      default:
        return 'Integración específica requerida';
    }
  }

  /**
   * Obtiene las credenciales requeridas para un tipo de dato
   */
  private getRequiredCredentials(dataType: string): string[] {
    switch (dataType) {
      case 'email':
      case 'user_name':
        return ['AZURE_CLIENT_ID', 'AZURE_CLIENT_SECRET', 'AZURE_TENANT_ID'];
      case 'phone':
        return ['TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN'];
      case 'address':
        return ['GOOGLE_MAPS_API_KEY'];
      case 'amount':
        return ['QB_CLIENT_ID', 'QB_CLIENT_SECRET', 'QB_COMPANY_ID'];
      default:
        return ['CREDENCIALES_ESPECIFICAS'];
    }
  }

  /**
   * Valida un objeto completo
   */
  async validateObject(obj: Record<string, any>): Promise<Record<string, DataValidationResult>> {
    const results: Record<string, DataValidationResult> = {};

    for (const [key, value] of Object.entries(obj)) {
      results[key] = await this.validateData(key, value);
    }

    return results;
  }

  /**
   * Obtiene estadísticas de validación
   */
  getValidationStats(): {
    totalValidations: number;
    realDataCount: number;
    mockDataCount: number;
    mockDataPercentage: number;
  } {
    const totalValidations = this.validationCache.size;
    const realDataCount = Array.from(this.validationCache.values())
      .filter(result => result.source === 'real').length;
    const mockDataCount = Array.from(this.validationCache.values())
      .filter(result => result.source === 'mock').length;

    return {
      totalValidations,
      realDataCount,
      mockDataCount,
      mockDataPercentage: totalValidations > 0 ? (mockDataCount / totalValidations) * 100 : 0
    };
  }

  /**
   * Limpia el cache de validaciones
   */
  clearValidationCache(): void {
    this.validationCache.clear();
  }

  /**
   * Ejecuta validación completa del sistema
   */
  async runSystemValidation(): Promise<{
    success: boolean;
    mockDataDetected: number;
    criticalIssues: number;
    deploymentBlocked: boolean;
  }> {
    console.log('🔍 Ejecutando validación completa del sistema...');

    try {
      // Ejecutar detector de mock data
      const findings = await mockDataDetector.scanProject();
      
      const criticalIssues = findings.filter(f => 
        f.severity === 'CRITICAL' || f.severity === 'HIGH'
      ).length;

      const result = {
        success: findings.length === 0,
        mockDataDetected: findings.length,
        criticalIssues,
        deploymentBlocked: criticalIssues > 0
      };

      if (result.deploymentBlocked) {
        console.log('🚫 VALIDACIÓN FALLIDA: Deployment bloqueado por datos mock críticos');
      } else if (findings.length > 0) {
        console.log('⚠️ VALIDACIÓN CON ADVERTENCIAS: Datos mock detectados');
      } else {
        console.log('✅ VALIDACIÓN EXITOSA: Sistema limpio');
      }

      return result;

    } catch (error) {
      console.error('❌ Error en validación del sistema:', error);
      return {
        success: false,
        mockDataDetected: 0,
        criticalIssues: 1,
        deploymentBlocked: true
      };
    }
  }
}

// Exportar instancia singleton
export const dataIntegrityService = DataIntegrityService.getInstance();