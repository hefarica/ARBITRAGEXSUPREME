import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from 'crypto'

/**
 * @title SecretsManager
 * @description Gestión segura de secretos y claves privadas
 * @author ArbitrageX Security Team 2025
 */
export class SecretsManager {
  private static instance: SecretsManager
  private secrets: Map<string, string> = new Map()
  private encryptionKey: Buffer
  private algorithm = 'aes-256-gcm'

  private constructor() {
    // Generar clave de encriptación desde variables de entorno
    const masterKey = process.env.MASTER_ENCRYPTION_KEY || randomBytes(32).toString('hex')
    this.encryptionKey = scryptSync(masterKey, 'salt', 32)
  }

  /**
   * Obtener instancia singleton
   */
  public static getInstance(): SecretsManager {
    if (!SecretsManager.instance) {
      SecretsManager.instance = new SecretsManager()
    }
    return SecretsManager.instance
  }

  /**
   * Encriptar un valor
   */
  private encrypt(text: string): { encrypted: string; iv: string; authTag: string } {
    const iv = randomBytes(16)
    const cipher = createCipheriv(this.algorithm, this.encryptionKey, iv)
    
    let encrypted = cipher.update(text, 'utf8', 'hex')
    encrypted += cipher.final('hex')
    
    return {
      encrypted,
      iv: iv.toString('hex'),
      authTag: cipher.getAuthTag().toString('hex')
    }
  }

  /**
   * Desencriptar un valor
   */
  private decrypt(encrypted: string, iv: string, authTag: string): string {
    const decipher = createDecipheriv(
      this.algorithm, 
      this.encryptionKey, 
      Buffer.from(iv, 'hex')
    )
    
    decipher.setAuthTag(Buffer.from(authTag, 'hex'))
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8')
    decrypted += decipher.final('utf8')
    
    return decrypted
  }

  /**
   * Almacenar un secreto de forma segura
   */
  public setSecret(key: string, value: string): void {
    const encrypted = this.encrypt(value)
    const encryptedData = JSON.stringify(encrypted)
    this.secrets.set(key, encryptedData)
  }

  /**
   * Obtener un secreto de forma segura
   */
  public getSecret(key: string): string | null {
    const encryptedData = this.secrets.get(key)
    if (!encryptedData) return null

    try {
      const encrypted = JSON.parse(encryptedData)
      return this.decrypt(encrypted.encrypted, encrypted.iv, encrypted.authTag)
    } catch (error) {
      console.error(`Error decrypting secret ${key}:`, error)
      return null
    }
  }

  /**
   * Eliminar un secreto
   */
  public deleteSecret(key: string): boolean {
    return this.secrets.delete(key)
  }

  /**
   * Listar todas las claves de secretos (sin valores)
   */
  public listSecretKeys(): string[] {
    return Array.from(this.secrets.keys())
  }

  /**
   * Verificar si existe un secreto
   */
  public hasSecret(key: string): boolean {
    return this.secrets.has(key)
  }

  /**
   * Rotar claves de forma segura
   */
  public rotateKey(oldKey: string, newKey: string): boolean {
    const value = this.getSecret(oldKey)
    if (!value) return false

    this.setSecret(newKey, value)
    this.deleteSecret(oldKey)
    return true
  }

  /**
   * Limpiar todos los secretos de memoria
   */
  public clearAll(): void {
    this.secrets.clear()
  }

  /**
   * Obtener estadísticas de seguridad
   */
  public getSecurityStats(): {
    totalSecrets: number
    encryptedKeys: string[]
    lastAccess: Date
  } {
    return {
      totalSecrets: this.secrets.size,
      encryptedKeys: this.listSecretKeys(),
      lastAccess: new Date()
    }
  }
}

/**
 * Configuración de secretos para ArbitrageX
 */
export class ArbitrageXSecrets {
  private static secretsManager = SecretsManager.getInstance()

  /**
   * Configurar secretos iniciales desde variables de entorno
   */
  public static initializeSecrets(): void {
    // API Keys
    if (process.env.UNISWAP_API_KEY) {
      this.secretsManager.setSecret('UNISWAP_API_KEY', process.env.UNISWAP_API_KEY)
    }
    
    if (process.env.PANCAKESWAP_API_KEY) {
      this.secretsManager.setSecret('PANCAKESWAP_API_KEY', process.env.PANCAKESWAP_API_KEY)
    }
    
    if (process.env.ETHERSCAN_API_KEY) {
      this.secretsManager.setSecret('ETHERSCAN_API_KEY', process.env.ETHERSCAN_API_KEY)
    }

    // Database
    if (process.env.DATABASE_URL) {
      this.secretsManager.setSecret('DATABASE_URL', process.env.DATABASE_URL)
    }

    // JWT
    if (process.env.JWT_SECRET) {
      this.secretsManager.setSecret('JWT_SECRET', process.env.JWT_SECRET)
    }

    // Blockchain
    if (process.env.PRIVATE_KEY) {
      this.secretsManager.setSecret('PRIVATE_KEY', process.env.PRIVATE_KEY)
    }

    if (process.env.INFURA_URL) {
      this.secretsManager.setSecret('INFURA_URL', process.env.INFURA_URL)
    }

    // External Services
    if (process.env.TELEGRAM_BOT_TOKEN) {
      this.secretsManager.setSecret('TELEGRAM_BOT_TOKEN', process.env.TELEGRAM_BOT_TOKEN)
    }

    if (process.env.DISCORD_WEBHOOK_URL) {
      this.secretsManager.setSecret('DISCORD_WEBHOOK_URL', process.env.DISCORD_WEBHOOK_URL)
    }
  }

  /**
   * Obtener API key de Uniswap
   */
  public static getUniswapApiKey(): string | null {
    return this.secretsManager.getSecret('UNISWAP_API_KEY')
  }

  /**
   * Obtener API key de PancakeSwap
   */
  public static getPancakeSwapApiKey(): string | null {
    return this.secretsManager.getSecret('PANCAKESWAP_API_KEY')
  }

  /**
   * Obtener API key de Etherscan
   */
  public static getEtherscanApiKey(): string | null {
    return this.secretsManager.getSecret('ETHERSCAN_API_KEY')
  }

  /**
   * Obtener URL de base de datos
   */
  public static getDatabaseUrl(): string | null {
    return this.secretsManager.getSecret('DATABASE_URL')
  }

  /**
   * Obtener JWT secret
   */
  public static getJwtSecret(): string | null {
    return this.secretsManager.getSecret('JWT_SECRET')
  }

  /**
   * Obtener private key
   */
  public static getPrivateKey(): string | null {
    return this.secretsManager.getSecret('PRIVATE_KEY')
  }

  /**
   * Obtener URL de Infura
   */
  public static getInfuraUrl(): string | null {
    return this.secretsManager.getSecret('INFURA_URL')
  }

  /**
   * Obtener token de bot de Telegram
   */
  public static getTelegramBotToken(): string | null {
    return this.secretsManager.getSecret('TELEGRAM_BOT_TOKEN')
  }

  /**
   * Obtener URL de webhook de Discord
   */
  public static getDiscordWebhookUrl(): string | null {
    return this.secretsManager.getSecret('DISCORD_WEBHOOK_URL')
  }

  /**
   * Rotar todas las claves de forma segura
   */
  public static rotateAllKeys(): void {
    const keys = this.secretsManager.listSecretKeys()
    
    keys.forEach(key => {
      const value = this.secretsManager.getSecret(key)
      if (value) {
        const newKey = `${key}_${Date.now()}`
        this.secretsManager.setSecret(newKey, value)
        this.secretsManager.deleteSecret(key)
      }
    })
  }

  /**
   * Obtener estadísticas de seguridad
   */
  public static getSecurityStats() {
    return this.secretsManager.getSecurityStats()
  }
} 