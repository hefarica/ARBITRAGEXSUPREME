/**
 * Servicio de Integración de Datos MEV para ArbitrageX
 * Integra datos de EigenPhi, Flashbots Explorer, MEVwatcher y Blocknative MEV Monitor
 */

export interface MEVOpportunity {
    id: string;
    strategy: string;
    chain: string;
    grossProfit: number;
    gasUsed: number;
    gasPrice: number;
    netProfit: number;
    successRate: number;
    executionTime: number;
    timestamp: number;
    source: string;
    priority: 'high' | 'medium' | 'low';
}

export interface MEVSourceConfig {
    name: string;
    baseUrl: string;
    apiKey?: string;
    rateLimit: number;
    enabled: boolean;
    priority: number;
}

export interface StrategyPerformance {
    strategy: string;
    totalOpportunities: number;
    successfulExecutions: number;
    avgNetProfit: number;
    avgGasEfficiency: number;
    successRate: number;
    recommendedChains: string[];
    optimalGasRange: {
        min: number;
        max: number;
    };
}

export class MEVDataIntegrationService {
    private sources: Map<string, MEVSourceConfig>;
    private opportunitiesCache: Map<string, MEVOpportunity[]>;
    private performanceCache: Map<string, StrategyPerformance>;
    private lastUpdate: Map<string, number>;
    private cacheExpiry = 60000; // 1 minuto

    constructor() {
        this.sources = new Map();
        this.opportunitiesCache = new Map();
        this.performanceCache = new Map();
        this.lastUpdate = new Map();
        this.initializeDataSources();
    }

    /**
     * Inicializar fuentes de datos MEV
     */
    private initializeDataSources() {
        const sources: MEVSourceConfig[] = [
            {
                name: 'eigenphi',
                baseUrl: 'https://api.eigenphi.io',
                rateLimit: 100,
                enabled: true,
                priority: 1
            },
            {
                name: 'flashbots-explorer',
                baseUrl: 'https://flashbots-explorer.marto.io',
                rateLimit: 50,
                enabled: true,
                priority: 2
            },
            {
                name: 'mevwatcher',
                baseUrl: 'https://api.mevwatcher.io',
                rateLimit: 75,
                enabled: true,
                priority: 3
            },
            {
                name: 'blocknative-mev',
                baseUrl: 'https://api.blocknative.com',
                rateLimit: 60,
                enabled: true,
                priority: 4
            }
        ];

        sources.forEach(source => {
            this.sources.set(source.name, source);
        });
    }

    /**
     * Obtener oportunidades MEV desde todas las fuentes
     */
    async getMEVOpportunities(
        strategy?: string,
        chain?: string,
        minProfit?: number
    ): Promise<MEVOpportunity[]> {
        const allOpportunities: MEVOpportunity[] = [];

        for (const [sourceName, source] of this.sources) {
            if (!source.enabled) continue;

            try {
                const opportunities = await this.fetchFromSource(sourceName, strategy, chain, minProfit);
                allOpportunities.push(...opportunities);
            } catch (error) {
                console.error(`Error obteniendo datos de ${sourceName}:`, error);
            }
        }

        // Ordenar por prioridad y profit
        return allOpportunities.sort((a, b) => {
            const priorityOrder = { high: 3, medium: 2, low: 1 };
            const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
            
            if (priorityDiff !== 0) return priorityDiff;
            return b.netProfit - a.netProfit;
        });
    }

    /**
     * Obtener datos desde una fuente específica
     */
    private async fetchFromSource(
        sourceName: string,
        strategy?: string,
        chain?: string,
        minProfit?: number
    ): Promise<MEVOpportunity[]> {
        const cacheKey = `${sourceName}_${strategy || 'all'}_${chain || 'all'}_${minProfit || 0}`;
        const cached = this.opportunitiesCache.get(cacheKey);
        const lastUpdate = this.lastUpdate.get(cacheKey) || 0;

        if (cached && Date.now() - lastUpdate < this.cacheExpiry) {
            return cached;
        }

        const source = this.sources.get(sourceName);
        if (!source) return [];

        let opportunities: MEVOpportunity[] = [];

        switch (sourceName) {
            case 'eigenphi':
                opportunities = await this.fetchFromEigenPhi(source, strategy, chain, minProfit);
                break;
            case 'flashbots-explorer':
                opportunities = await this.fetchFromFlashbotsExplorer(source, strategy, chain, minProfit);
                break;
            case 'mevwatcher':
                opportunities = await this.fetchFromMEVWatcher(source, strategy, chain, minProfit);
                break;
            case 'blocknative-mev':
                opportunities = await this.fetchFromBlocknativeMEV(source, strategy, chain, minProfit);
                break;
        }

        // Cachear resultados
        this.opportunitiesCache.set(cacheKey, opportunities);
        this.lastUpdate.set(cacheKey, Date.now());

        return opportunities;
    }

    /**
     * Obtener datos desde EigenPhi
     */
    private async fetchFromEigenPhi(
        source: MEVSourceConfig,
        strategy?: string,
        chain?: string,
        minProfit?: number
    ): Promise<MEVOpportunity[]> {
        try {
            // Simular llamada a API de EigenPhi
            const mockData: MEVOpportunity[] = [
                {
                    id: 'eigenphi_1',
                    strategy: 'triangular-arbitrage',
                    chain: 'ethereum',
                    grossProfit: 150.0,
                    gasUsed: 350000,
                    gasPrice: 25,
                    netProfit: 125.0,
                    successRate: 0.85,
                    executionTime: 12000,
                    timestamp: Date.now(),
                    source: 'eigenphi',
                    priority: 'high'
                },
                {
                    id: 'eigenphi_2',
                    strategy: 'flash-loan-arbitrage',
                    chain: 'arbitrum',
                    grossProfit: 75.0,
                    gasUsed: 380000,
                    gasPrice: 0.2,
                    netProfit: 72.0,
                    successRate: 0.92,
                    executionTime: 250,
                    timestamp: Date.now(),
                    source: 'eigenphi',
                    priority: 'high'
                }
            ];

            return this.filterOpportunities(mockData, strategy, chain, minProfit);
        } catch (error) {
            console.error('Error obteniendo datos de EigenPhi:', error);
            return [];
        }
    }

    /**
     * Obtener datos desde Flashbots Explorer
     */
    private async fetchFromFlashbotsExplorer(
        source: MEVSourceConfig,
        strategy?: string,
        chain?: string,
        minProfit?: number
    ): Promise<MEVOpportunity[]> {
        try {
            // Simular llamada a API de Flashbots Explorer
            const mockData: MEVOpportunity[] = [
                {
                    id: 'flashbots_1',
                    strategy: 'mev-arbitrage',
                    chain: 'ethereum',
                    grossProfit: 500.0,
                    gasUsed: 450000,
                    gasPrice: 30,
                    netProfit: 455.0,
                    successRate: 0.78,
                    executionTime: 15000,
                    timestamp: Date.now(),
                    source: 'flashbots-explorer',
                    priority: 'medium'
                },
                {
                    id: 'flashbots_2',
                    strategy: 'liquidation-arbitrage',
                    chain: 'ethereum',
                    grossProfit: 200.0,
                    gasUsed: 280000,
                    gasPrice: 28,
                    netProfit: 185.0,
                    successRate: 0.95,
                    executionTime: 8000,
                    timestamp: Date.now(),
                    source: 'flashbots-explorer',
                    priority: 'high'
                }
            ];

            return this.filterOpportunities(mockData, strategy, chain, minProfit);
        } catch (error) {
            console.error('Error obteniendo datos de Flashbots Explorer:', error);
            return [];
        }
    }

    /**
     * Obtener datos desde MEVWatcher
     */
    private async fetchFromMEVWatcher(
        source: MEVSourceConfig,
        strategy?: string,
        chain?: string,
        minProfit?: number
    ): Promise<MEVOpportunity[]> {
        try {
            // Simular llamada a API de MEVWatcher
            const mockData: MEVOpportunity[] = [
                {
                    id: 'mevwatcher_1',
                    strategy: 'cross-dex-arbitrage',
                    chain: 'polygon',
                    grossProfit: 45.0,
                    gasUsed: 320000,
                    gasPrice: 35,
                    netProfit: 42.0,
                    successRate: 0.88,
                    executionTime: 2000,
                    timestamp: Date.now(),
                    source: 'mevwatcher',
                    priority: 'medium'
                },
                {
                    id: 'mevwatcher_2',
                    strategy: 'yield-farming-arbitrage',
                    chain: 'bsc',
                    grossProfit: 120.0,
                    gasUsed: 400000,
                    gasPrice: 5,
                    netProfit: 118.0,
                    successRate: 0.82,
                    executionTime: 3000,
                    timestamp: Date.now(),
                    source: 'mevwatcher',
                    priority: 'medium'
                }
            ];

            return this.filterOpportunities(mockData, strategy, chain, minProfit);
        } catch (error) {
            console.error('Error obteniendo datos de MEVWatcher:', error);
            return [];
        }
    }

    /**
     * Obtener datos desde Blocknative MEV Monitor
     */
    private async fetchFromBlocknativeMEV(
        source: MEVSourceConfig,
        strategy?: string,
        chain?: string,
        minProfit?: number
    ): Promise<MEVOpportunity[]> {
        try {
            // Simular llamada a API de Blocknative MEV
            const mockData: MEVOpportunity[] = [
                {
                    id: 'blocknative_1',
                    strategy: 'nft-floor-arbitrage',
                    chain: 'ethereum',
                    grossProfit: 800.0,
                    gasUsed: 500000,
                    gasPrice: 35,
                    netProfit: 765.0,
                    successRate: 0.65,
                    executionTime: 20000,
                    timestamp: Date.now(),
                    source: 'blocknative-mev',
                    priority: 'low'
                },
                {
                    id: 'blocknative_2',
                    strategy: 'cross-chain-arbitrage',
                    chain: 'arbitrum',
                    grossProfit: 300.0,
                    gasUsed: 450000,
                    gasPrice: 0.2,
                    netProfit: 298.0,
                    successRate: 0.75,
                    executionTime: 500,
                    timestamp: Date.now(),
                    source: 'blocknative-mev',
                    priority: 'medium'
                }
            ];

            return this.filterOpportunities(mockData, strategy, chain, minProfit);
        } catch (error) {
            console.error('Error obteniendo datos de Blocknative MEV:', error);
            return [];
        }
    }

    /**
     * Filtrar oportunidades según criterios
     */
    private filterOpportunities(
        opportunities: MEVOpportunity[],
        strategy?: string,
        chain?: string,
        minProfit?: number
    ): MEVOpportunity[] {
        return opportunities.filter(opp => {
            if (strategy && opp.strategy !== strategy) return false;
            if (chain && opp.chain !== chain) return false;
            if (minProfit && opp.netProfit < minProfit) return false;
            return true;
        });
    }

    /**
     * Analizar rendimiento de estrategias
     */
    async analyzeStrategyPerformance(): Promise<StrategyPerformance[]> {
        const cacheKey = 'strategy_performance';
        const cached = this.performanceCache.get(cacheKey);
        const lastUpdate = this.lastUpdate.get(cacheKey) || 0;

        if (cached && Date.now() - lastUpdate < this.cacheExpiry) {
            return Array.from(cached.values());
        }

        const allOpportunities = await this.getMEVOpportunities();
        const performanceMap = new Map<string, StrategyPerformance>();

        // Agrupar oportunidades por estrategia
        allOpportunities.forEach(opp => {
            if (!performanceMap.has(opp.strategy)) {
                performanceMap.set(opp.strategy, {
                    strategy: opp.strategy,
                    totalOpportunities: 0,
                    successfulExecutions: 0,
                    avgNetProfit: 0,
                    avgGasEfficiency: 0,
                    successRate: 0,
                    recommendedChains: [],
                    optimalGasRange: { min: 0, max: 0 }
                });
            }

            const perf = performanceMap.get(opp.strategy)!;
            perf.totalOpportunities++;
            perf.successfulExecutions += Math.round(opp.successRate * 100);
            perf.avgNetProfit += opp.netProfit;
            perf.avgGasEfficiency += opp.netProfit / opp.gasUsed;

            // Agregar chain si no está en la lista
            if (!perf.recommendedChains.includes(opp.chain)) {
                perf.recommendedChains.push(opp.chain);
            }
        });

        // Calcular promedios y métricas
        performanceMap.forEach(perf => {
            perf.avgNetProfit = perf.avgNetProfit / perf.totalOpportunities;
            perf.avgGasEfficiency = perf.avgGasEfficiency / perf.totalOpportunities;
            perf.successRate = perf.successfulExecutions / perf.totalOpportunities;

            // Ordenar chains por rendimiento
            perf.recommendedChains.sort((a, b) => {
                const aOpps = allOpportunities.filter(opp => opp.strategy === perf.strategy && opp.chain === a);
                const bOpps = allOpportunities.filter(opp => opp.strategy === perf.strategy && opp.chain === b);
                
                const aAvgProfit = aOpps.reduce((sum, opp) => sum + opp.netProfit, 0) / aOpps.length;
                const bAvgProfit = bOpps.reduce((sum, opp) => sum + opp.netProfit, 0) / bOpps.length;
                
                return bAvgProfit - aAvgProfit;
            });

            // Calcular rango óptimo de gas
            const gasPrices = allOpportunities
                .filter(opp => opp.strategy === perf.strategy)
                .map(opp => opp.gasPrice);
            
            perf.optimalGasRange = {
                min: Math.min(...gasPrices),
                max: Math.max(...gasPrices)
            };
        });

        // Cachear resultados
        this.performanceCache.set(cacheKey, performanceMap);
        this.lastUpdate.set(cacheKey, Date.now());

        return Array.from(performanceMap.values()).sort((a, b) => b.successRate - a.successRate);
    }

    /**
     * Obtener recomendaciones de estrategias por chain
     */
    async getChainStrategyRecommendations(chain: string): Promise<{
        chain: string;
        topStrategies: string[];
        avgGasPrice: number;
        optimalExecutionTime: string;
        riskLevel: 'low' | 'medium' | 'high';
    }> {
        const opportunities = await this.getMEVOpportunities(undefined, chain);
        
        if (opportunities.length === 0) {
            return {
                chain,
                topStrategies: [],
                avgGasPrice: 0,
                optimalExecutionTime: 'N/A',
                riskLevel: 'high'
            };
        }

        // Agrupar por estrategia y calcular métricas
        const strategyMetrics = new Map<string, {
            count: number;
            totalProfit: number;
            avgGasPrice: number;
            successRate: number;
        }>();

        opportunities.forEach(opp => {
            if (!strategyMetrics.has(opp.strategy)) {
                strategyMetrics.set(opp.strategy, {
                    count: 0,
                    totalProfit: 0,
                    avgGasPrice: 0,
                    successRate: 0
                });
            }

            const metrics = strategyMetrics.get(opp.strategy)!;
            metrics.count++;
            metrics.totalProfit += opp.netProfit;
            metrics.avgGasPrice += opp.gasPrice;
            metrics.successRate += opp.successRate;
        });

        // Calcular promedios
        strategyMetrics.forEach(metrics => {
            metrics.avgGasPrice = metrics.avgGasPrice / metrics.count;
            metrics.successRate = metrics.successRate / metrics.count;
        });

        // Ordenar estrategias por rentabilidad
        const topStrategies = Array.from(strategyMetrics.entries())
            .sort((a, b) => (b[1].totalProfit / b[1].count) - (a[1].totalProfit / a[1].count))
            .slice(0, 3)
            .map(([strategy]) => strategy);

        // Calcular gas price promedio de la chain
        const avgGasPrice = opportunities.reduce((sum, opp) => sum + opp.gasPrice, 0) / opportunities.length;

        // Determinar tiempo de ejecución óptimo
        const executionTimes = opportunities.map(opp => opp.executionTime);
        const avgExecutionTime = executionTimes.reduce((sum, time) => sum + time, 0) / executionTimes.length;
        
        let optimalExecutionTime = 'N/A';
        if (avgExecutionTime < 1000) optimalExecutionTime = 'Sub-segundo';
        else if (avgExecutionTime < 5000) optimalExecutionTime = '1-5 segundos';
        else if (avgExecutionTime < 15000) optimalExecutionTime = '5-15 segundos';
        else optimalExecutionTime = 'Más de 15 segundos';

        // Determinar nivel de riesgo
        const avgSuccessRate = opportunities.reduce((sum, opp) => sum + opp.successRate, 0) / opportunities.length;
        let riskLevel: 'low' | 'medium' | 'high' = 'medium';
        if (avgSuccessRate > 0.85) riskLevel = 'low';
        else if (avgSuccessRate < 0.65) riskLevel = 'high';

        return {
            chain,
            topStrategies,
            avgGasPrice,
            optimalExecutionTime,
            riskLevel
        };
    }

    /**
     * Obtener métricas de latencia por fuente
     */
    async getLatencyMetrics(): Promise<{
        source: string;
        avgResponseTime: number;
        reliability: number;
        lastUpdate: number;
    }[]> {
        const metrics = [];

        for (const [sourceName, source] of this.sources) {
            if (!source.enabled) continue;

            // Simular métricas de latencia
            const avgResponseTime = 100 + Math.random() * 200; // 100-300ms
            const reliability = 0.85 + Math.random() * 0.15; // 85-100%
            const lastUpdate = Date.now() - Math.random() * 60000; // Último minuto

            metrics.push({
                source: sourceName,
                avgResponseTime,
                reliability,
                lastUpdate
            });
        }

        return metrics.sort((a, b) => a.avgResponseTime - b.avgResponseTime);
    }

    /**
     * Obtener alertas de oportunidades críticas
     */
    async getCriticalOpportunityAlerts(): Promise<{
        id: string;
        strategy: string;
        chain: string;
        profit: number;
        urgency: 'critical' | 'high' | 'medium';
        timeWindow: number; // en segundos
        recommendedAction: string;
    }[]> {
        const opportunities = await this.getMEVOpportunities();
        
        return opportunities
            .filter(opp => opp.priority === 'high' && opp.netProfit > 100)
            .map(opp => ({
                id: opp.id,
                strategy: opp.strategy,
                chain: opp.chain,
                profit: opp.netProfit,
                urgency: opp.netProfit > 500 ? 'critical' : opp.netProfit > 200 ? 'high' : 'medium',
                timeWindow: opp.executionTime / 1000, // Convertir a segundos
                recommendedAction: this.getRecommendedAction(opp)
            }))
            .sort((a, b) => b.profit - a.profit)
            .slice(0, 5);
    }

    /**
     * Obtener acción recomendada para una oportunidad
     */
    private getRecommendedAction(opportunity: MEVOpportunity): string {
        if (opportunity.netProfit > 500) {
            return 'Ejecutar inmediatamente con priority fee alto';
        } else if (opportunity.netProfit > 200) {
            return 'Ejecutar en los próximos 2-3 bloques';
        } else if (opportunity.netProfit > 100) {
            return 'Monitorear y ejecutar si gas price baja';
        } else {
            return 'Evaluar viabilidad antes de ejecutar';
        }
    }

    /**
     * Actualizar configuración de fuentes
     */
    updateSourceConfig(sourceName: string, config: Partial<MEVSourceConfig>): boolean {
        const source = this.sources.get(sourceName);
        if (!source) return false;

        Object.assign(source, config);
        return true;
    }

    /**
     * Habilitar/deshabilitar fuente
     */
    toggleSource(sourceName: string, enabled: boolean): boolean {
        const source = this.sources.get(sourceName);
        if (!source) return false;

        source.enabled = enabled;
        return true;
    }

    /**
     * Limpiar cache
     */
    clearCache(): void {
        this.opportunitiesCache.clear();
        this.performanceCache.clear();
        this.lastUpdate.clear();
    }
}

export default MEVDataIntegrationService;
