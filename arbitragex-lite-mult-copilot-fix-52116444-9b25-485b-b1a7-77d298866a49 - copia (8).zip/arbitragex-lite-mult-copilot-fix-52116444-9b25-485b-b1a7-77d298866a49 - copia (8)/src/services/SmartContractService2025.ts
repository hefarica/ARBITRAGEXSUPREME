import { ethers } from 'ethers'
import { credentialsManager } from './CredentialsManager'

// ABIs para los contratos de OPERATIVA
const FLASH_LOAN_ABI = [
  'function uniswapV2Call(address sender, uint256 amount0, uint256 amount1, bytes calldata data) external',
  'function pancakeCall(address sender, uint256 amount0, uint256 amount1, bytes calldata data) external',
  'function executeArbitrage(address tokenA, address tokenB, uint256 amount) external',
  'function withdraw() external'
]

const PREDICTION_MARKET_ABI = [
  'function betBull(uint256 epoch) external payable',
  'function betBear(uint256 epoch) external payable',
  'function claim(uint256 epoch) external',
  'function getRound(uint256 epoch) external view returns (tuple(uint256 epoch, uint256 startTimestamp, uint256 lockTimestamp, uint256 closeTimestamp, int256 lockPrice, int256 closePrice, uint256 lockOracleId, uint256 closeOracleId, uint256 totalAmount, uint256 bullAmount, uint256 bearAmount, bool oracleCalled))',
  'function getUserRounds(address user, uint256 cursor, uint256 size) external view returns (tuple(uint256[] rounds, uint256 cursor) memory)'
]

const DEX_ROUTER_ABI = [
  'function getAmountsOut(uint256 amountIn, address[] memory path) public view returns (uint256[] memory amounts)',
  'function swapExactTokensForTokens(uint256 amountIn, uint256 amountOutMin, address[] calldata path, address to, uint256 deadline) external returns (uint256[] memory amounts)',
  'function swapExactETHForTokens(uint256 amountOutMin, address[] calldata path, address to, uint256 deadline) external payable returns (uint256[] memory amounts)'
]

export interface ContractConfig {
  address: string
  abi: any[]
  chainId: string
  name: string
}

export interface FlashLoanConfig {
  uniswapFactory: string
  uniswapRouter: string
  sushiswapFactory: string
  sushiswapRouter: string
  pancakeFactory: string
  pancakeRouter: string
}

export class SmartContractService2025 {
  private providers: Map<string, ethers.providers.JsonRpcProvider> = new Map()
  private contracts: Map<string, ethers.Contract> = new Map()
  private flashLoanConfig: FlashLoanConfig

  constructor() {
    this.flashLoanConfig = {
      uniswapFactory: '0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f',
      uniswapRouter: '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D',
      sushiswapFactory: '0xC0AEe478e3658e2610c5F7A4A2E1777cE9e4f2Ac',
      sushiswapRouter: '0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F',
      pancakeFactory: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',
      pancakeRouter: '0x10ED43C718714eb63d5aA57B78B54704E256024E'
    }
  }

  async initializeProviders(): Promise<void> {
    const chains = ['ethereum', 'bsc', 'polygon', 'arbitrum', 'optimism', 'avalanche', 'fantom', 'cronos']
    
    for (const chain of chains) {
      try {
        const rpcUrl = await credentialsManager.getRpcUrl(chain)
        const provider = new ethers.providers.JsonRpcProvider(rpcUrl)
        this.providers.set(chain, provider)
        console.log(`✅ Provider inicializado para ${chain}`)
      } catch (error) {
        console.error(`❌ Error inicializando provider para ${chain}:`, error)
      }
    }
  }

  async getFlashLoanContract(chain: string, strategy: 'uniswap-sushi' | 'pancakeswap-multi'): Promise<ethers.Contract> {
    const contractKey = `flashloan-${chain}-${strategy}`
    
    if (this.contracts.has(contractKey)) {
      return this.contracts.get(contractKey)!
    }

    const provider = this.providers.get(chain)
    if (!provider) {
      throw new Error(`Provider no encontrado para ${chain}`)
    }

    // Direcciones de contratos flash loan (deberían ser desplegadas)
    const contractAddresses = {
      'ethereum': {
        'uniswap-sushi': '0x0000000000000000000000000000000000000000', // Deploy aquí
        'pancakeswap-multi': '0x0000000000000000000000000000000000000000'
      },
      'bsc': {
        'uniswap-sushi': '0x0000000000000000000000000000000000000000',
        'pancakeswap-multi': '0x0000000000000000000000000000000000000000'
      }
    }

    const address = contractAddresses[chain as keyof typeof contractAddresses]?.[strategy]
    if (!address || address === '0x0000000000000000000000000000000000000000') {
      throw new Error(`Contrato flash loan no desplegado para ${chain}-${strategy}`)
    }

    const contract = new ethers.Contract(address, FLASH_LOAN_ABI, provider)
    this.contracts.set(contractKey, contract)
    
    return contract
  }

  async getPredictionMarketContract(chain: string): Promise<ethers.Contract> {
    const contractKey = `prediction-${chain}`
    
    if (this.contracts.has(contractKey)) {
      return this.contracts.get(contractKey)!
    }

    const provider = this.providers.get(chain)
    if (!provider) {
      throw new Error(`Provider no encontrado para ${chain}`)
    }

    // Dirección del contrato de prediction market (BSC)
    const contractAddress = chain === 'bsc' 
      ? '0x18B2A687610328590Bc8F2e5fEdDe3b582A49cdA'
      : '0x0000000000000000000000000000000000000000'

    if (contractAddress === '0x0000000000000000000000000000000000000000') {
      throw new Error(`Contrato prediction market no disponible para ${chain}`)
    }

    const contract = new ethers.Contract(contractAddress, PREDICTION_MARKET_ABI, provider)
    this.contracts.set(contractKey, contract)
    
    return contract
  }

  async getDEXRouter(chain: string, dex: 'uniswap' | 'sushiswap' | 'pancakeswap'): Promise<ethers.Contract> {
    const contractKey = `router-${chain}-${dex}`
    
    if (this.contracts.has(contractKey)) {
      return this.contracts.get(contractKey)!
    }

    const provider = this.providers.get(chain)
    if (!provider) {
      throw new Error(`Provider no encontrado para ${chain}`)
    }

    let routerAddress: string
    switch (dex) {
      case 'uniswap':
        routerAddress = this.flashLoanConfig.uniswapRouter
        break
      case 'sushiswap':
        routerAddress = this.flashLoanConfig.sushiswapRouter
        break
      case 'pancakeswap':
        routerAddress = this.flashLoanConfig.pancakeRouter
        break
      default:
        throw new Error(`DEX no soportado: ${dex}`)
    }

    const contract = new ethers.Contract(routerAddress, DEX_ROUTER_ABI, provider)
    this.contracts.set(contractKey, contract)
    
    return contract
  }

  async executeFlashLoanArbitrage(
    chain: string,
    strategy: 'uniswap-sushi' | 'pancakeswap-multi',
    tokenA: string,
    tokenB: string,
    amount: string,
    wallet: ethers.Wallet
  ): Promise<ethers.ContractTransaction> {
    const contract = await this.getFlashLoanContract(chain, strategy)
    const connectedContract = contract.connect(wallet)
    
    // Ejecutar arbitraje flash loan
    const tx = await connectedContract.executeArbitrage(tokenA, tokenB, amount)
    return tx
  }

  async executePredictionMarketBet(
    chain: string,
    epoch: number,
    side: 'bull' | 'bear',
    amount: string,
    wallet: ethers.Wallet
  ): Promise<ethers.ContractTransaction> {
    const contract = await this.getPredictionMarketContract(chain)
    const connectedContract = contract.connect(wallet)
    
    const amountWei = ethers.utils.parseEther(amount)
    
    if (side === 'bull') {
      return await connectedContract.betBull(epoch, { value: amountWei })
    } else {
      return await connectedContract.betBear(epoch, { value: amountWei })
    }
  }

  async getPredictionMarketData(chain: string, epoch: number): Promise<any> {
    const contract = await this.getPredictionMarketContract(chain)
    const round = await contract.getRound(epoch)
    
    return {
      epoch: round.epoch.toString(),
      startTimestamp: round.startTimestamp.toString(),
      lockTimestamp: round.lockTimestamp.toString(),
      closeTimestamp: round.closeTimestamp.toString(),
      lockPrice: round.lockPrice.toString(),
      closePrice: round.closePrice.toString(),
      totalAmount: ethers.utils.formatEther(round.totalAmount),
      bullAmount: ethers.utils.formatEther(round.bullAmount),
      bearAmount: ethers.utils.formatEther(round.bearAmount),
      oracleCalled: round.oracleCalled
    }
  }

  async getDEXPrice(
    chain: string,
    dex: 'uniswap' | 'sushiswap' | 'pancakeswap',
    tokenA: string,
    tokenB: string,
    amount: string
  ): Promise<string> {
    const router = await this.getDEXRouter(chain, dex)
    const amountWei = ethers.utils.parseEther(amount)
    const path = [tokenA, tokenB]
    
    const amounts = await router.getAmountsOut(amountWei, path)
    return ethers.utils.formatEther(amounts[1])
  }

  async calculateArbitrageOpportunity(
    chain: string,
    tokenA: string,
    tokenB: string,
    amount: string
  ): Promise<{
    uniswapPrice: string
    sushiswapPrice: string
    priceDifference: number
    profitable: boolean
  }> {
    try {
      const uniswapPrice = await this.getDEXPrice(chain, 'uniswap', tokenA, tokenB, amount)
      const sushiswapPrice = await this.getDEXPrice(chain, 'sushiswap', tokenA, tokenB, amount)
      
      const priceDiff = Math.abs(parseFloat(uniswapPrice) - parseFloat(sushiswapPrice))
      const avgPrice = (parseFloat(uniswapPrice) + parseFloat(sushiswapPrice)) / 2
      const priceDifference = (priceDiff / avgPrice) * 100
      
      return {
        uniswapPrice,
        sushiswapPrice,
        priceDifference,
        profitable: priceDifference > 0.5 // 0.5% mínimo para ser rentable
      }
    } catch (error) {
      console.error('Error calculando oportunidad de arbitraje:', error)
      return {
        uniswapPrice: '0',
        sushiswapPrice: '0',
        priceDifference: 0,
        profitable: false
      }
    }
  }

  async estimateGasCost(chain: string, tx: ethers.ContractTransaction): Promise<string> {
    const provider = this.providers.get(chain)
    if (!provider) {
      throw new Error(`Provider no encontrado para ${chain}`)
    }

    const gasEstimate = await provider.estimateGas(tx)
    const gasPrice = await provider.getGasPrice()
    const gasCost = gasEstimate.mul(gasPrice)
    
    return ethers.utils.formatEther(gasCost)
  }

  // Métodos para obtener wallets
  async getWallet(chain: string): Promise<ethers.Wallet> {
    const privateKey = await credentialsManager.getPrivateKey(chain)
    const provider = this.providers.get(chain)
    
    if (!provider) {
      throw new Error(`Provider no encontrado para ${chain}`)
    }
    
    return new ethers.Wallet(privateKey, provider)
  }

  // Métodos de utilidad
  async getTokenBalance(chain: string, tokenAddress: string, walletAddress: string): Promise<string> {
    const provider = this.providers.get(chain)
    if (!provider) {
      throw new Error(`Provider no encontrado para ${chain}`)
    }

    const tokenContract = new ethers.Contract(
      tokenAddress,
      ['function balanceOf(address) view returns (uint256)'],
      provider
    )
    
    const balance = await tokenContract.balanceOf(walletAddress)
    return ethers.utils.formatEther(balance)
  }

  async getETHBalance(chain: string, address: string): Promise<string> {
    const provider = this.providers.get(chain)
    if (!provider) {
      throw new Error(`Provider no encontrado para ${chain}`)
    }

    const balance = await provider.getBalance(address)
    return ethers.utils.formatEther(balance)
  }
}

export const smartContractService2025 = new SmartContractService2025() 