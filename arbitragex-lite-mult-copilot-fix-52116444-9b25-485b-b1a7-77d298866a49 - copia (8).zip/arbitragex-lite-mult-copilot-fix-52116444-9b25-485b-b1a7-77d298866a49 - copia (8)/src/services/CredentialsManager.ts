import crypto from 'crypto'

export interface Credential {
  id: string
  name: string
  value: string
  category: 'blockchain' | 'exchange' | 'data' | 'defi' | 'security'
  required: boolean
  encrypted: boolean
  lastUpdated: number
  status: 'pending' | 'configured' | 'validated' | 'error'
  error?: string
}

export interface CredentialsConfig {
  encryptionKey: string
  storageMethod: 'local' | 'secure' | 'external'
  autoRotate: boolean
  rotationInterval: number // en días
}

export class CredentialsManager {
  private credentials: Map<string, Credential> = new Map()
  private config: CredentialsConfig
  private encryptionKey: Buffer

  constructor(config: CredentialsConfig) {
    this.config = config
    this.encryptionKey = Buffer.from(config.encryptionKey, 'hex')
    this.loadCredentials()
  }

  /**
   * Agregar o actualizar una credencial
   */
  async setCredential(id: string, credential: Omit<Credential, 'encrypted' | 'lastUpdated'>): Promise<void> {
    const encryptedValue = await this.encryptValue(credential.value)
    
    const newCredential: Credential = {
      ...credential,
      encrypted: true,
      lastUpdated: Date.now()
    }

    this.credentials.set(id, newCredential)
    await this.saveCredentials()
  }

  /**
   * Obtener una credencial (desencriptada)
   */
  async getCredential(id: string): Promise<Credential | null> {
    const credential = this.credentials.get(id)
    if (!credential) return null

    try {
      const decryptedValue = await this.decryptValue(credential.value)
      return {
        ...credential,
        value: decryptedValue
      }
    } catch (error) {
      console.error(`Error decrypting credential ${id}:`, error)
      return {
        ...credential,
        status: 'error',
        error: 'Error al desencriptar la credencial'
      }
    }
  }

  /**
   * Obtener todas las credenciales
   */
  async getAllCredentials(): Promise<Credential[]> {
    const credentials: Credential[] = []
    
    for (const [id, credential] of this.credentials) {
      try {
        const decryptedCredential = await this.getCredential(id)
        if (decryptedCredential) {
          credentials.push(decryptedCredential)
        }
      } catch (error) {
        console.error(`Error getting credential ${id}:`, error)
      }
    }

    return credentials
  }

  /**
   * Validar una credencial
   */
  async validateCredential(id: string): Promise<{ valid: boolean; error?: string }> {
    const credential = await this.getCredential(id)
    if (!credential) {
      return { valid: false, error: 'Credencial no encontrada' }
    }

    try {
      // Validar según el tipo de credencial
      switch (credential.category) {
        case 'blockchain':
          return await this.validateBlockchainCredential(credential)
        case 'exchange':
          return await this.validateExchangeCredential(credential)
        case 'data':
          return await this.validateDataProviderCredential(credential)
        case 'security':
          return await this.validateSecurityCredential(credential)
        default:
          return { valid: true }
      }
    } catch (error) {
      return { valid: false, error: `Error de validación: ${error.message}` }
    }
  }

  /**
   * Validar credencial de blockchain
   */
  private async validateBlockchainCredential(credential: Credential): Promise<{ valid: boolean; error?: string }> {
    try {
      // Simular validación de RPC
      const response = await fetch(credential.value, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'eth_blockNumber',
          params: [],
          id: 1
        })
      })

      if (!response.ok) {
        return { valid: false, error: 'RPC endpoint no responde correctamente' }
      }

      const data = await response.json()
      if (data.error) {
        return { valid: false, error: `Error RPC: ${data.error.message}` }
      }

      return { valid: true }
    } catch (error) {
      return { valid: false, error: `Error de conexión: ${error.message}` }
    }
  }

  /**
   * Validar credencial de exchange
   */
  private async validateExchangeCredential(credential: Credential): Promise<{ valid: boolean; error?: string }> {
    try {
      // Simular validación de API de exchange
      if (credential.id.includes('binance')) {
        // Validar formato de API key de Binance
        if (!/^[a-zA-Z0-9]{64}$/.test(credential.value)) {
          return { valid: false, error: 'Formato de API key inválido' }
        }
      }

      return { valid: true }
    } catch (error) {
      return { valid: false, error: `Error de validación: ${error.message}` }
    }
  }

  /**
   * Validar credencial de proveedor de datos
   */
  private async validateDataProviderCredential(credential: Credential): Promise<{ valid: boolean; error?: string }> {
    try {
      // Simular validación de API key
      if (credential.id.includes('coingecko')) {
        if (!/^CG-[a-zA-Z0-9]{32}$/.test(credential.value)) {
          return { valid: false, error: 'Formato de API key de CoinGecko inválido' }
        }
      }

      return { valid: true }
    } catch (error) {
      return { valid: false, error: `Error de validación: ${error.message}` }
    }
  }

  /**
   * Validar credencial de seguridad
   */
  private async validateSecurityCredential(credential: Credential): Promise<{ valid: boolean; error?: string }> {
    try {
      if (credential.id === 'jwt_secret') {
        if (credential.value.length < 32) {
          return { valid: false, error: 'JWT secret debe tener al menos 32 caracteres' }
        }
      }

      return { valid: true }
    } catch (error) {
      return { valid: false, error: `Error de validación: ${error.message}` }
    }
  }

  /**
   * Encriptar valor
   */
  private async encryptValue(value: string): Promise<string> {
    const iv = crypto.randomBytes(12)
    const cipher = crypto.createCipher('aes-256-gcm', this.encryptionKey)
    
    let encrypted = cipher.update(value, 'utf8', 'hex')
    encrypted += cipher.final('hex')
    
    const authTag = cipher.getAuthTag()
    
    return iv.toString('hex') + ':' + authTag.toString('hex') + ':' + encrypted
  }

  /**
   * Desencriptar valor
   */
  private async decryptValue(encryptedValue: string): Promise<string> {
    const parts = encryptedValue.split(':')
    if (parts.length !== 3) {
      throw new Error('Formato de valor encriptado inválido')
    }

    const iv = Buffer.from(parts[0], 'hex')
    const authTag = Buffer.from(parts[1], 'hex')
    const encrypted = parts[2]

    const decipher = crypto.createDecipher('aes-256-gcm', this.encryptionKey)
    decipher.setAuthTag(authTag)
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8')
    decrypted += decipher.final('utf8')
    
    return decrypted
  }

  /**
   * Cargar credenciales desde almacenamiento
   */
  private async loadCredentials(): Promise<void> {
    try {
      const stored = localStorage.getItem('arbitragex_credentials')
      if (stored) {
        const parsed = JSON.parse(stored)
        for (const [id, credential] of Object.entries(parsed)) {
          this.credentials.set(id, credential as Credential)
        }
      }
    } catch (error) {
      console.error('Error loading credentials:', error)
    }
  }

  /**
   * Guardar credenciales en almacenamiento
   */
  private async saveCredentials(): Promise<void> {
    try {
      const credentialsObj: Record<string, Credential> = {}
      for (const [id, credential] of this.credentials) {
        credentialsObj[id] = credential
      }
      
      localStorage.setItem('arbitragex_credentials', JSON.stringify(credentialsObj))
    } catch (error) {
      console.error('Error saving credentials:', error)
    }
  }

  /**
   * Eliminar una credencial
   */
  async removeCredential(id: string): Promise<void> {
    this.credentials.delete(id)
    await this.saveCredentials()
  }

  /**
   * Limpiar todas las credenciales
   */
  async clearAllCredentials(): Promise<void> {
    this.credentials.clear()
    await this.saveCredentials()
  }

  /**
   * Obtener estadísticas de credenciales
   */
  getCredentialsStats(): {
    total: number
    configured: number
    validated: number
    required: number
    missing: number
  } {
    const total = this.credentials.size
    const configured = Array.from(this.credentials.values()).filter(c => c.status === 'configured' || c.status === 'validated').length
    const validated = Array.from(this.credentials.values()).filter(c => c.status === 'validated').length
    const required = Array.from(this.credentials.values()).filter(c => c.required).length
    const missing = required - configured

    return { total, configured, validated, required, missing }
  }

  /**
   * Verificar si el sistema está listo para producción
   */
  async isProductionReady(): Promise<{ ready: boolean; issues: string[] }> {
    const issues: string[] = []
    const stats = this.getCredentialsStats()

    if (stats.missing > 0) {
      issues.push(`${stats.missing} credenciales requeridas faltan`)
    }

    // Verificar que todas las credenciales requeridas estén validadas
    for (const [id, credential] of this.credentials) {
      if (credential.required && credential.status !== 'validated') {
        issues.push(`Credencial requerida "${credential.name}" no está validada`)
      }
    }

    return {
      ready: issues.length === 0,
      issues
    }
  }
}

// Instancia singleton
export const credentialsManager = new CredentialsManager({
  encryptionKey: process.env.VITE_ENCRYPTION_KEY || crypto.randomBytes(32).toString('hex'),
  storageMethod: 'local',
  autoRotate: true,
  rotationInterval: 90
}) 