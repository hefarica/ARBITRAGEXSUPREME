/**
 * 🔗 Servicio de Integración de Blockchains
 * Conecta el servicio de reconexión automática con las blockchains existentes
 * del sistema ArbitrageX y sincroniza el estado de conexiones
 */

import { ethers } from 'ethers'
import { autoReconnectionService, BlockchainConnection } from './AutoReconnectionService'
import { realDeFiService } from './RealDeFiService'
import { realTimeDataService } from './realTimeDataService'

export interface BlockchainInfo {
  name: string
  chainId: number
  rpcUrl: string
  wsUrl?: string
  explorerUrl: string
  nativeCurrency: string
  enabled: boolean
}

export interface IntegrationStatus {
  isIntegrated: boolean
  totalBlockchains: number
  integratedBlockchains: number
  lastSync: number
  errors: string[]
}

export class BlockchainIntegrationService {
  private static instance: BlockchainIntegrationService
  private isInitialized = false
  private integrationStatus: IntegrationStatus = {
    isIntegrated: false,
    totalBlockchains: 0,
    integratedBlockchains: 0,
    lastSync: 0,
    errors: []
  }

  // Mapeo de blockchains del sistema a información de conexión
  private blockchainMapping: Map<string, BlockchainInfo> = new Map()

  private constructor() {
    this.initializeBlockchainMapping()
  }

  static getInstance(): BlockchainIntegrationService {
    if (!BlockchainIntegrationService.instance) {
      BlockchainIntegrationService.instance = new BlockchainIntegrationService()
    }
    return BlockchainIntegrationService.instance
  }

  /**
   * Inicializar el mapeo de blockchains
   */
  private initializeBlockchainMapping(): void {
    // Ethereum
    this.blockchainMapping.set('ethereum', {
      name: 'ethereum',
      chainId: 1,
      rpcUrl: 'https://eth-mainnet.g.alchemy.com/v2/demo',
      wsUrl: 'wss://eth-mainnet.g.alchemy.com/v2/demo',
      explorerUrl: 'https://etherscan.io',
      nativeCurrency: 'ETH',
      enabled: true
    })

    // Polygon
    this.blockchainMapping.set('polygon', {
      name: 'polygon',
      chainId: 137,
      rpcUrl: 'https://polygon-rpc.com',
      wsUrl: 'wss://polygon-rpc.com',
      explorerUrl: 'https://polygonscan.com',
      nativeCurrency: 'MATIC',
      enabled: true
    })

    // BSC
    this.blockchainMapping.set('bsc', {
      name: 'bsc',
      chainId: 56,
      rpcUrl: 'https://bsc-dataseed.binance.org',
      wsUrl: 'wss://bsc-ws-node.nariox.org:443',
      explorerUrl: 'https://bscscan.com',
      nativeCurrency: 'BNB',
      enabled: true
    })

    // Arbitrum
    this.blockchainMapping.set('arbitrum', {
      name: 'arbitrum',
      chainId: 42161,
      rpcUrl: 'https://arb1.arbitrum.io/rpc',
      wsUrl: 'wss://arb1.arbitrum.io/ws',
      explorerUrl: 'https://arbiscan.io',
      nativeCurrency: 'ETH',
      enabled: true
    })

    // Optimism
    this.blockchainMapping.set('optimism', {
      name: 'optimism',
      chainId: 10,
      rpcUrl: 'https://mainnet.optimism.io',
      wsUrl: 'wss://mainnet.optimism.io',
      explorerUrl: 'https://optimistic.etherscan.io',
      nativeCurrency: 'ETH',
      enabled: true
    })

    // Fantom
    this.blockchainMapping.set('fantom', {
      name: 'fantom',
      chainId: 250,
      rpcUrl: 'https://rpc.ftm.tools',
      wsUrl: 'wss://wsapi.fantom.network',
      explorerUrl: 'https://ftmscan.com',
      nativeCurrency: 'FTM',
      enabled: true
    })

    // Avalanche
    this.blockchainMapping.set('avalanche', {
      name: 'avalanche',
      chainId: 43114,
      rpcUrl: 'https://api.avax.network/ext/bc/C/rpc',
      wsUrl: 'wss://api.avax.network/ext/bc/C/ws',
      explorerUrl: 'https://snowtrace.io',
      nativeCurrency: 'AVAX',
      enabled: true
    })

    // Cronos
    this.blockchainMapping.set('cronos', {
      name: 'cronos',
      chainId: 25,
      rpcUrl: 'https://evm.cronos.org',
      wsUrl: 'wss://evm.cronos.org',
      explorerUrl: 'https://cronoscan.com',
      nativeCurrency: 'CRO',
      enabled: true
    })

    console.log(`🗺️ Mapeo de ${this.blockchainMapping.size} blockchains inicializado`)
  }

  /**
   * Inicializar el servicio de integración
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) {
      console.log('🔄 Servicio de integración ya está inicializado')
      return
    }

    try {
      console.log('🚀 Iniciando servicio de integración de blockchains...')

      // Iniciar el servicio de reconexión automática
      await autoReconnectionService.start()

      // Integrar todas las blockchains
      await this.integrateAllBlockchains()

      // Configurar listeners para sincronización
      this.setupSynchronizationListeners()

      this.isInitialized = true
      this.integrationStatus.isIntegrated = true
      this.integrationStatus.lastSync = Date.now()

      console.log('✅ Servicio de integración de blockchains inicializado correctamente')

    } catch (error) {
      console.error('❌ Error inicializando servicio de integración:', error)
      this.integrationStatus.errors.push(`Error de inicialización: ${error}`)
      throw error
    }
  }

  /**
   * Integrar todas las blockchains al servicio de reconexión
   */
  private async integrateAllBlockchains(): Promise<void> {
    console.log('🔗 Integrando blockchains con el servicio de reconexión...')

    const integrationPromises = Array.from(this.blockchainMapping.values())
      .filter(blockchain => blockchain.enabled)
      .map(async (blockchain) => {
        try {
          await this.integrateBlockchain(blockchain)
          this.integrationStatus.integratedBlockchains++
        } catch (error) {
          const errorMsg = `Error integrando ${blockchain.name}: ${error}`
          console.error(`❌ ${errorMsg}`)
          this.integrationStatus.errors.push(errorMsg)
        }
      })

    await Promise.allSettled(integrationPromises)
    this.integrationStatus.totalBlockchains = this.blockchainMapping.size

    console.log(`✅ ${this.integrationStatus.integratedBlockchains}/${this.integrationStatus.totalBlockchains} blockchains integradas`)
  }

  /**
   * Integrar una blockchain específica
   */
  private async integrateBlockchain(blockchain: BlockchainInfo): Promise<void> {
    console.log(`🔗 Integrando ${blockchain.name} (Chain ID: ${blockchain.chainId})...`)

    try {
      // Crear provider inicial
      const provider = new ethers.JsonRpcProvider(blockchain.rpcUrl)
      
      // Verificar conectividad inicial
      const network = await provider.getNetwork()
      const blockNumber = await provider.getBlockNumber()
      const feeData = await provider.getFeeData()
      
      // Medir latencia inicial
      const startTime = Date.now()
      await provider.getBlockNumber()
      const latency = Date.now() - startTime

      const gasPrice = ethers.formatUnits(feeData.gasPrice || feeData.maxFeePerGas || 0n, 'gwei')

      // Crear conexión para el servicio de reconexión
      const connection: Omit<BlockchainConnection, 'connectionAttempts' | 'maxRetries' | 'healthCheckInterval'> = {
        name: blockchain.name,
        chainId: blockchain.chainId,
        rpcUrl: blockchain.rpcUrl,
        wsUrl: blockchain.wsUrl,
        provider,
        isConnected: true,
        lastConnected: Date.now(),
        lastDisconnected: 0,
        status: 'connected',
        latency,
        blockHeight: Number(blockNumber),
        gasPrice
      }

      // Agregar al servicio de reconexión
      autoReconnectionService.addConnection(connection)

      console.log(`✅ ${blockchain.name} integrada exitosamente`)

    } catch (error) {
      console.error(`❌ Error integrando ${blockchain.name}:`, error)
      
      // Crear conexión en estado de error
      const errorConnection: Omit<BlockchainConnection, 'connectionAttempts' | 'maxRetries' | 'healthCheckInterval'> = {
        name: blockchain.name,
        chainId: blockchain.chainId,
        rpcUrl: blockchain.rpcUrl,
        wsUrl: blockchain.wsUrl,
        provider: new ethers.JsonRpcProvider(), // Provider vacío
        isConnected: false,
        lastConnected: 0,
        lastDisconnected: Date.now(),
        status: 'error',
        error: error instanceof Error ? error.message : 'Error desconocido',
        latency: 9999,
        blockHeight: 0,
        gasPrice: '0'
      }

      autoReconnectionService.addConnection(errorConnection)
      throw error
    }
  }

  /**
   * Configurar listeners para sincronización
   */
  private setupSynchronizationListeners(): void {
    const service = autoReconnectionService

    // Sincronizar cuando una blockchain se reconecta
    service.on('blockchain_reconnected', ({ name, chainId }) => {
      console.log(`🔄 Sincronizando estado de ${name} después de reconexión...`)
      this.synchronizeBlockchainState(name)
    })

    // Sincronizar cuando una blockchain se desconecta
    service.on('blockchain_disconnected', ({ name, chainId, error }) => {
      console.log(`🔄 Sincronizando estado de ${name} después de desconexión...`)
      this.synchronizeBlockchainState(name)
    })

    // Sincronizar cuando cambia el estado de conexión
    service.on('connection_status_changed', ({ name, previousStatus, newStatus }) => {
      console.log(`🔄 Estado de ${name} cambió de ${previousStatus} a ${newStatus}`)
      this.synchronizeBlockchainState(name)
    })

    // Sincronizar cuando se detecta latencia alta
    service.on('high_latency_detected', ({ name, latency }) => {
      console.log(`⚠️ Latencia alta detectada en ${name}: ${latency}ms`)
      this.handleHighLatency(name, latency)
    })

    console.log('🔄 Listeners de sincronización configurados')
  }

  /**
   * Sincronizar el estado de una blockchain específica
   */
  private async synchronizeBlockchainState(blockchainName: string): Promise<void> {
    try {
      const connection = autoReconnectionService.getConnectionStatus().get(blockchainName)
      if (!connection) {
        console.warn(`⚠️ Conexión no encontrada para ${blockchainName}`)
        return
      }

      // Sincronizar con RealDeFiService si está disponible
      if (realDeFiService && typeof realDeFiService.updateConnectionStatus === 'function') {
        try {
          // Actualizar estado en RealDeFiService
          const connectionStatus = realDeFiService.getConnectionStatus()
          const existingConnection = connectionStatus.find(c => c.blockchain === blockchainName)
          
          if (existingConnection) {
            existingConnection.connected = connection.isConnected
            existingConnection.latency = connection.latency
            existingConnection.lastBlock = connection.blockHeight
            existingConnection.error = connection.error
          }
        } catch (error) {
          console.warn(`⚠️ Error sincronizando con RealDeFiService: ${error}`)
        }
      }

      // Sincronizar con RealTimeDataService si está disponible
      if (realTimeDataService && typeof realTimeDataService.updateProviderHealth === 'function') {
        try {
          const isHealthy = connection.isConnected && connection.status === 'connected'
          realTimeDataService.updateProviderHealth(blockchainName, isHealthy)
        } catch (error) {
          console.warn(`⚠️ Error sincronizando con RealTimeDataService: ${error}`)
        }
      }

      console.log(`✅ Estado de ${blockchainName} sincronizado`)

    } catch (error) {
      console.error(`❌ Error sincronizando estado de ${blockchainName}:`, error)
    }
  }

  /**
   * Manejar latencia alta detectada
   */
  private handleHighLatency(blockchainName: string, latency: number): void {
    console.log(`⚠️ Manejando latencia alta en ${blockchainName}: ${latency}ms`)

    // Si la latencia es muy alta, considerar reconectar
    if (latency > 30000) { // Más de 30 segundos
      console.log(`🔄 Latencia crítica detectada en ${blockchainName}, programando reconexión...`)
      autoReconnectionService.reconnectBlockchain(blockchainName)
    }

    // Emitir evento de latencia alta para otros servicios
    this.emit('high_latency_detected', { blockchainName, latency, timestamp: Date.now() })
  }

  /**
   * Obtener estado de integración
   */
  getIntegrationStatus(): IntegrationStatus {
    return { ...this.integrationStatus }
  }

  /**
   * Obtener información de todas las blockchains
   */
  getAllBlockchains(): BlockchainInfo[] {
    return Array.from(this.blockchainMapping.values())
  }

  /**
   * Obtener información de una blockchain específica
   */
  getBlockchainInfo(name: string): BlockchainInfo | undefined {
    return this.blockchainMapping.get(name)
  }

  /**
   * Habilitar/deshabilitar una blockchain
   */
  setBlockchainEnabled(name: string, enabled: boolean): void {
    const blockchain = this.blockchainMapping.get(name)
    if (blockchain) {
      blockchain.enabled = enabled
      console.log(`⚙️ Blockchain ${name} ${enabled ? 'habilitada' : 'deshabilitada'}`)
      
      if (enabled) {
        // Integrar si no estaba integrada
        this.integrateBlockchain(blockchain)
      } else {
        // Remover del servicio de reconexión
        // Nota: El servicio de reconexión no tiene método removeConnection, 
        // pero podemos marcarla como desconectada
        const connection = autoReconnectionService.getConnectionStatus().get(name)
        if (connection) {
          autoReconnectionService.updateConnectionStatus(name, 'disconnected', 'Blockchain deshabilitada')
        }
      }
    }
  }

  /**
   * Actualizar RPC URL de una blockchain
   */
  updateBlockchainRPC(name: string, newRpcUrl: string): void {
    const blockchain = this.blockchainMapping.get(name)
    if (blockchain) {
      const oldRpcUrl = blockchain.rpcUrl
      blockchain.rpcUrl = newRpcUrl
      
      console.log(`🔄 RPC URL de ${name} actualizada: ${oldRpcUrl} → ${newRpcUrl}`)
      
      // Actualizar en el servicio de reconexión
      const connection = autoReconnectionService.getConnectionStatus().get(name)
      if (connection) {
        connection.rpcUrl = newRpcUrl
        // Intentar reconectar con la nueva URL
        autoReconnectionService.reconnectBlockchain(name)
      }
    }
  }

  /**
   * Forzar reconexión de todas las blockchains
   */
  async forceReconnectAll(): Promise<void> {
    console.log('🔄 Forzando reconexión de todas las blockchains...')
    
    try {
      await autoReconnectionService.reconnectAllDisconnected()
      console.log('✅ Reconexión forzada completada')
    } catch (error) {
      console.error('❌ Error en reconexión forzada:', error)
      throw error
    }
  }

  /**
   * Obtener estadísticas de integración
   */
  getIntegrationStats(): {
    totalBlockchains: number
    enabledBlockchains: number
    connectedBlockchains: number
    disconnectedBlockchains: number
    errorBlockchains: number
    averageLatency: number
  } {
    const connections = autoReconnectionService.getConnectionStatus()
    const connectedConnections = Array.from(connections.values()).filter(c => c.isConnected)
    
    const totalLatency = connectedConnections.reduce((sum, c) => sum + c.latency, 0)
    const averageLatency = connectedConnections.length > 0 ? totalLatency / connectedConnections.length : 0

    return {
      totalBlockchains: this.blockchainMapping.size,
      enabledBlockchains: Array.from(this.blockchainMapping.values()).filter(b => b.enabled).length,
      connectedBlockchains: connectedConnections.length,
      disconnectedBlockchains: Array.from(connections.values()).filter(c => !c.isConnected && c.status === 'disconnected').length,
      errorBlockchains: Array.from(connections.values()).filter(c => c.status === 'error').length,
      averageLatency: Math.round(averageLatency)
    }
  }

  /**
   * Verificar salud de la integración
   */
  checkIntegrationHealth(): {
    isHealthy: boolean
    issues: string[]
    recommendations: string[]
  } {
    const stats = this.getIntegrationStats()
    const issues: string[] = []
    const recommendations: string[] = []

    // Verificar si hay blockchains desconectadas
    if (stats.disconnectedBlockchains > 0) {
      issues.push(`${stats.disconnectedBlockchains} blockchain(s) desconectada(s)`)
      recommendations.push('Revisar configuración de RPCs y conectividad de red')
    }

    // Verificar si hay blockchains con errores
    if (stats.errorBlockchains > 0) {
      issues.push(`${stats.errorBlockchains} blockchain(s) con error(es)`)
      recommendations.push('Verificar logs de error y configurar RPCs de fallback')
    }

    // Verificar latencia promedio
    if (stats.averageLatency > 5000) {
      issues.push(`Latencia promedio alta: ${stats.averageLatency}ms`)
      recommendations.push('Considerar cambiar a RPCs más rápidos o configurar múltiples endpoints')
    }

    // Verificar tasa de conexión
    const connectionRate = (stats.connectedBlockchains / stats.enabledBlockchains) * 100
    if (connectionRate < 80) {
      issues.push(`Tasa de conexión baja: ${connectionRate.toFixed(1)}%`)
      recommendations.push('Revisar configuración de red y RPCs')
    }

    const isHealthy = issues.length === 0

    return {
      isHealthy,
      issues,
      recommendations
    }
  }

  /**
   * Limpiar recursos del servicio
   */
  cleanup(): void {
    console.log('🧹 Limpiando servicio de integración...')
    
    try {
      // Detener el servicio de reconexión
      autoReconnectionService.stop()
      
      // Limpiar estado
      this.isInitialized = false
      this.integrationStatus.isIntegrated = false
      
      console.log('✅ Servicio de integración limpiado')
    } catch (error) {
      console.error('❌ Error limpiando servicio de integración:', error)
    }
  }
}

// Exportar instancia singleton
export const blockchainIntegrationService = BlockchainIntegrationService.getInstance()
