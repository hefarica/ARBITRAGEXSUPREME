/**
 * MockEthers.ts
 * Mock temporal para evitar errores de compilación mientras desarrollamos
 * En producción se reemplazará por integración real con ethers
 */

// Mock temporal para development
export const ethers = {
  providers: {
    JsonRpcProvider: class MockJsonRpcProvider {
      constructor(url?: string) {
        this.url = url;
      }
      
      async getNetwork() {
        return { chainId: 1, name: 'homestead' };
      }
      
      async getBlockNumber() {
        return Math.floor(Math.random() * 1000000) + 18000000;
      }
      
      async getGasPrice() {
        return { 
          mul: (amount: number) => ({
            toString: () => (20000000000 * amount).toString()
          }),
          toString: () => '20000000000'
        };
      }
      
      async getCode(address: string) {
        return address.length === 42 ? '0x608060405234801561001057600080fd5b50' : '0x';
      }
    }
  },
  utils: {
    formatUnits: (value: any, unit: string = 'ether') => {
      if (typeof value === 'object' && value.toString) {
        const valueStr = value.toString();
        return (parseInt(valueStr) / Math.pow(10, unit === 'gwei' ? 9 : 18)).toString();
      }
      return value.toString();
    },
    formatEther: (value: any) => {
      return (parseInt(value.toString()) / Math.pow(10, 18)).toString();
    }
  }
};