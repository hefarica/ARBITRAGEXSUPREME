/**
 * 🚨 SECURITY ALERTING SYSTEM - ArbitrageX Pro 2025
 * Sistema completo de alertas de seguridad en tiempo real
 */

export interface SecurityAlert {
  id: string;
  timestamp: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: 'authentication' | 'authorization' | 'data_breach' | 'malicious_activity' | 'system_anomaly' | 'financial_risk';
  title: string;
  description: string;
  source: string;
  metadata: Record<string, any>;
  status: 'new' | 'acknowledged' | 'investigating' | 'resolved' | 'false_positive';
  assignedTo?: string;
  escalated: boolean;
  responseTime?: number;
  resolutionTime?: number;
}

export interface AlertRule {
  id: string;
  name: string;
  description: string;
  category: SecurityAlert['category'];
  severity: SecurityAlert['severity'];
  condition: (event: any) => boolean;
  enabled: boolean;
  cooldownMs: number;
  escalationThreshold: number;
  autoResolve: boolean;
  notificationChannels: string[];
}

export interface NotificationChannel {
  id: string;
  type: 'email' | 'slack' | 'discord' | 'webhook' | 'sms' | 'push';
  name: string;
  config: Record<string, any>;
  enabled: boolean;
  severityFilter: SecurityAlert['severity'][];
}

export class SecurityAlertingSystem {
  private static instance: SecurityAlertingSystem;
  private alerts: Map<string, SecurityAlert> = new Map();
  private alertRules: Map<string, AlertRule> = new Map();
  private notificationChannels: Map<string, NotificationChannel> = new Map();
  private cooldowns: Map<string, number> = new Map();
  private alertHistory: SecurityAlert[] = [];

  private constructor() {
    this.initializeDefaultRules();
    this.initializeNotificationChannels();
    this.startPeriodicTasks();
  }

  public static getInstance(): SecurityAlertingSystem {
    if (!SecurityAlertingSystem.instance) {
      SecurityAlertingSystem.instance = new SecurityAlertingSystem();
    }
    return SecurityAlertingSystem.instance;
  }

  /**
   * Inicializar reglas de alerta por defecto
   */
  private initializeDefaultRules(): void {
    // Regla: Múltiples intentos fallidos de login
    this.addAlertRule({
      id: 'failed_login_attempts',
      name: 'Múltiples Intentos de Login Fallidos',
      description: 'Detecta múltiples intentos fallidos de autenticación desde la misma IP',
      category: 'authentication',
      severity: 'high',
      condition: (event) => {
        return event.type === 'failed_login' && event.attempts >= 5;
      },
      enabled: true,
      cooldownMs: 300000, // 5 minutos
      escalationThreshold: 3,
      autoResolve: false,
      notificationChannels: ['discord', 'email']
    });

    // Regla: Transacción de alto valor sin autorización
    this.addAlertRule({
      id: 'unauthorized_high_value_tx',
      name: 'Transacción de Alto Valor No Autorizada',
      description: 'Detecta transacciones de alto valor sin la autorización adecuada',
      category: 'financial_risk',
      severity: 'critical',
      condition: (event) => {
        return event.type === 'transaction_attempt' && 
               event.value > 1000000000000000000 && // > 1 ETH
               !event.authorized;
      },
      enabled: true,
      cooldownMs: 0, // Sin cooldown para transacciones críticas
      escalationThreshold: 1,
      autoResolve: false,
      notificationChannels: ['discord', 'email', 'sms']
    });

    // Regla: Acceso desde ubicación anómala
    this.addAlertRule({
      id: 'anomalous_location_access',
      name: 'Acceso desde Ubicación Anómala',
      description: 'Detecta acceso desde ubicaciones geográficas inusuales',
      category: 'malicious_activity',
      severity: 'medium',
      condition: (event) => {
        return event.type === 'login_success' && 
               event.location && 
               event.isAnomalousLocation === true;
      },
      enabled: true,
      cooldownMs: 3600000, // 1 hora
      escalationThreshold: 2,
      autoResolve: true,
      notificationChannels: ['discord']
    });

    // Regla: Fallo en sistema crítico
    this.addAlertRule({
      id: 'critical_system_failure',
      name: 'Fallo en Sistema Crítico',
      description: 'Detecta fallos en componentes críticos del sistema',
      category: 'system_anomaly',
      severity: 'critical',
      condition: (event) => {
        return event.type === 'system_error' && 
               event.component && 
               ['arbitrage_engine', 'transaction_executor', 'price_oracle'].includes(event.component);
      },
      enabled: true,
      cooldownMs: 60000, // 1 minuto
      escalationThreshold: 1,
      autoResolve: false,
      notificationChannels: ['discord', 'email', 'webhook']
    });

    // Regla: Datos sensibles expuestos
    this.addAlertRule({
      id: 'sensitive_data_exposure',
      name: 'Exposición de Datos Sensibles',
      description: 'Detecta exposición accidental de datos sensibles en logs o APIs',
      category: 'data_breach',
      severity: 'critical',
      condition: (event) => {
        return event.type === 'data_exposure' || 
               (event.type === 'log_entry' && event.containsSensitiveData === true);
      },
      enabled: true,
      cooldownMs: 0,
      escalationThreshold: 1,
      autoResolve: false,
      notificationChannels: ['discord', 'email', 'webhook']
    });

    // Regla: Rate limit excedido severamente
    this.addAlertRule({
      id: 'severe_rate_limit_breach',
      name: 'Rate Limit Excedido Severamente',
      description: 'Detecta intentos masivos de superar rate limits',
      category: 'malicious_activity',
      severity: 'high',
      condition: (event) => {
        return event.type === 'rate_limit_exceeded' && 
               event.attempts > 100;
      },
      enabled: true,
      cooldownMs: 600000, // 10 minutos
      escalationThreshold: 2,
      autoResolve: true,
      notificationChannels: ['discord']
    });

    // Regla: Hardware wallet desconectado durante trading
    this.addAlertRule({
      id: 'hardware_wallet_disconnected',
      name: 'Hardware Wallet Desconectado Durante Trading',
      description: 'Hardware wallet se desconecta mientras hay operaciones activas',
      category: 'system_anomaly',
      severity: 'high',
      condition: (event) => {
        return event.type === 'wallet_disconnected' && 
               event.walletType === 'hardware' && 
               event.activeOperations > 0;
      },
      enabled: true,
      cooldownMs: 60000,
      escalationThreshold: 1,
      autoResolve: true,
      notificationChannels: ['discord', 'email']
    });

    console.log('🚨 Reglas de alerta de seguridad inicializadas');
  }

  /**
   * Inicializar canales de notificación
   */
  private initializeNotificationChannels(): void {
    // Discord webhook
    if (process.env.DISCORD_WEBHOOK_URL) {
      this.addNotificationChannel({
        id: 'discord',
        type: 'discord',
        name: 'Discord Security Channel',
        config: {
          webhookUrl: process.env.DISCORD_WEBHOOK_URL,
          username: 'ArbitrageX Security Bot',
          avatarUrl: 'https://i.imgur.com/arbitragex-security.png'
        },
        enabled: true,
        severityFilter: ['medium', 'high', 'critical']
      });
    }

    // Email notifications
    if (process.env.ALERT_EMAIL) {
      this.addNotificationChannel({
        id: 'email',
        type: 'email',
        name: 'Email Alerts',
        config: {
          smtpHost: process.env.SMTP_HOST,
          smtpPort: process.env.SMTP_PORT,
          smtpUser: process.env.SMTP_USER,
          smtpPass: process.env.SMTP_PASS,
          fromEmail: process.env.SMTP_USER,
          toEmail: process.env.ALERT_EMAIL
        },
        enabled: true,
        severityFilter: ['high', 'critical']
      });
    }

    // Telegram bot
    if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
      this.addNotificationChannel({
        id: 'telegram',
        type: 'webhook',
        name: 'Telegram Security Bot',
        config: {
          url: `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`,
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          bodyTemplate: {
            chat_id: process.env.TELEGRAM_CHAT_ID,
            text: '🚨 {title}\n\n{description}\n\nSeveridad: {severity}\nFuente: {source}\nTiempo: {timestamp}',
            parse_mode: 'Markdown'
          }
        },
        enabled: true,
        severityFilter: ['high', 'critical']
      });
    }

    // Webhook genérico para SIEM/SOAR
    if (process.env.SECURITY_WEBHOOK_URL) {
      this.addNotificationChannel({
        id: 'webhook',
        type: 'webhook',
        name: 'SIEM Integration',
        config: {
          url: process.env.SECURITY_WEBHOOK_URL,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.SECURITY_WEBHOOK_TOKEN || ''}`
          }
        },
        enabled: true,
        severityFilter: ['low', 'medium', 'high', 'critical']
      });
    }

    console.log('📢 Canales de notificación inicializados');
  }

  /**
   * Procesar evento de seguridad
   */
  async processSecurityEvent(event: any): Promise<SecurityAlert[]> {
    const triggeredAlerts: SecurityAlert[] = [];

    for (const [ruleId, rule] of this.alertRules) {
      if (!rule.enabled) continue;

      // Verificar cooldown
      const lastAlert = this.cooldowns.get(ruleId);
      if (lastAlert && Date.now() - lastAlert < rule.cooldownMs) {
        continue;
      }

      try {
        // Evaluar condición
        if (rule.condition(event)) {
          const alert = await this.createAlert(rule, event);
          triggeredAlerts.push(alert);
          
          // Actualizar cooldown
          this.cooldowns.set(ruleId, Date.now());
          
          // Enviar notificaciones
          await this.sendNotifications(alert, rule.notificationChannels);
          
          // Verificar escalation
          this.checkEscalation(alert, rule);
        }
      } catch (error) {
        console.error(`Error evaluando regla ${ruleId}:`, error);
      }
    }

    return triggeredAlerts;
  }

  /**
   * Crear alerta de seguridad
   */
  private async createAlert(rule: AlertRule, event: any): Promise<SecurityAlert> {
    const alert: SecurityAlert = {
      id: this.generateAlertId(),
      timestamp: new Date().toISOString(),
      severity: rule.severity,
      category: rule.category,
      title: rule.name,
      description: this.formatAlertDescription(rule.description, event),
      source: event.source || 'unknown',
      metadata: {
        ruleId: rule.id,
        originalEvent: event,
        autoResolve: rule.autoResolve
      },
      status: 'new',
      escalated: false
    };

    // Guardar alerta
    this.alerts.set(alert.id, alert);
    this.alertHistory.push(alert);

    // Mantener historial limitado
    if (this.alertHistory.length > 10000) {
      this.alertHistory = this.alertHistory.slice(-10000);
    }

    console.log(`🚨 Nueva alerta de seguridad: ${alert.title} (${alert.severity})`);
    
    return alert;
  }

  /**
   * Enviar notificaciones
   */
  private async sendNotifications(alert: SecurityAlert, channelIds: string[]): Promise<void> {
    const promises = channelIds.map(channelId => {
      const channel = this.notificationChannels.get(channelId);
      if (!channel || !channel.enabled) return Promise.resolve();
      
      // Verificar filtro de severidad
      if (!channel.severityFilter.includes(alert.severity)) return Promise.resolve();
      
      return this.sendNotification(alert, channel);
    });

    await Promise.allSettled(promises);
  }

  /**
   * Enviar notificación a canal específico
   */
  private async sendNotification(alert: SecurityAlert, channel: NotificationChannel): Promise<void> {
    try {
      switch (channel.type) {
        case 'discord':
          await this.sendDiscordNotification(alert, channel);
          break;
        case 'email':
          await this.sendEmailNotification(alert, channel);
          break;
        case 'webhook':
          await this.sendWebhookNotification(alert, channel);
          break;
        case 'sms':
          await this.sendSMSNotification(alert, channel);
          break;
        default:
          console.warn(`Tipo de canal no soportado: ${channel.type}`);
      }
    } catch (error) {
      console.error(`Error enviando notificación a ${channel.name}:`, error);
    }
  }

  /**
   * Enviar notificación Discord
   */
  private async sendDiscordNotification(alert: SecurityAlert, channel: NotificationChannel): Promise<void> {
    const color = this.getSeverityColor(alert.severity);
    const emoji = this.getSeverityEmoji(alert.severity);
    
    const embed = {
      title: `${emoji} ${alert.title}`,
      description: alert.description,
      color,
      fields: [
        { name: 'Severidad', value: alert.severity.toUpperCase(), inline: true },
        { name: 'Categoría', value: alert.category.replace('_', ' ').toUpperCase(), inline: true },
        { name: 'Fuente', value: alert.source, inline: true },
        { name: 'ID', value: alert.id, inline: true },
        { name: 'Timestamp', value: alert.timestamp, inline: false }
      ],
      timestamp: alert.timestamp,
      footer: {
        text: 'ArbitrageX Pro 2025 Security System'
      }
    };

    await fetch(channel.config.webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: channel.config.username || 'Security Bot',
        avatar_url: channel.config.avatarUrl,
        embeds: [embed]
      })
    });
  }

  /**
   * Enviar notificación por email
   */
  private async sendEmailNotification(alert: SecurityAlert, channel: NotificationChannel): Promise<void> {
    const nodemailer = require('nodemailer');
    
    const transporter = nodemailer.createTransporter({
      host: channel.config.smtpHost,
      port: channel.config.smtpPort,
      secure: channel.config.smtpPort === 465,
      auth: {
        user: channel.config.smtpUser,
        pass: channel.config.smtpPass
      }
    });

    const html = `
      <h2>🚨 Alerta de Seguridad - ArbitrageX Pro 2025</h2>
      <p><strong>Título:</strong> ${alert.title}</p>
      <p><strong>Severidad:</strong> <span style="color: ${this.getSeverityColor(alert.severity)}">${alert.severity.toUpperCase()}</span></p>
      <p><strong>Descripción:</strong> ${alert.description}</p>
      <p><strong>Categoría:</strong> ${alert.category}</p>
      <p><strong>Fuente:</strong> ${alert.source}</p>
      <p><strong>Timestamp:</strong> ${alert.timestamp}</p>
      <p><strong>ID:</strong> ${alert.id}</p>
      <hr>
      <p><small>Este es un mensaje automático del sistema de seguridad de ArbitrageX Pro 2025.</small></p>
    `;

    await transporter.sendMail({
      from: channel.config.fromEmail,
      to: channel.config.toEmail,
      subject: `🚨 [${alert.severity.toUpperCase()}] ${alert.title}`,
      html
    });
  }

  /**
   * Enviar notificación webhook
   */
  private async sendWebhookNotification(alert: SecurityAlert, channel: NotificationChannel): Promise<void> {
    let body: any;
    
    if (channel.config.bodyTemplate) {
      // Usar template personalizado
      body = this.fillTemplate(channel.config.bodyTemplate, alert);
    } else {
      // Payload estándar
      body = {
        alert: {
          id: alert.id,
          timestamp: alert.timestamp,
          severity: alert.severity,
          category: alert.category,
          title: alert.title,
          description: alert.description,
          source: alert.source,
          metadata: alert.metadata
        }
      };
    }

    await fetch(channel.config.url, {
      method: channel.config.method || 'POST',
      headers: channel.config.headers || { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  }

  /**
   * Enviar notificación SMS (placeholder)
   */
  private async sendSMSNotification(alert: SecurityAlert, channel: NotificationChannel): Promise<void> {
    // Implementar integración con servicio SMS (Twilio, AWS SNS, etc.)
    console.log(`📱 SMS notification: ${alert.title} - ${alert.severity}`);
  }

  /**
   * Verificar escalation de alerta
   */
  private checkEscalation(alert: SecurityAlert, rule: AlertRule): void {
    // Contar alertas similares recientes
    const recentAlerts = this.alertHistory.filter(a => 
      a.metadata.ruleId === rule.id && 
      new Date(a.timestamp).getTime() > Date.now() - 3600000 // Última hora
    ).length;

    if (recentAlerts >= rule.escalationThreshold && !alert.escalated) {
      alert.escalated = true;
      alert.severity = this.escalateSeverity(alert.severity);
      
      console.log(`🔺 Alerta escalada: ${alert.id} a severidad ${alert.severity}`);
      
      // Enviar notificación de escalation
      this.sendEscalationNotification(alert);
    }
  }

  /**
   * Escalar severidad
   */
  private escalateSeverity(currentSeverity: SecurityAlert['severity']): SecurityAlert['severity'] {
    const severityOrder: SecurityAlert['severity'][] = ['low', 'medium', 'high', 'critical'];
    const currentIndex = severityOrder.indexOf(currentSeverity);
    return currentIndex < severityOrder.length - 1 
      ? severityOrder[currentIndex + 1] 
      : currentSeverity;
  }

  /**
   * Agregar regla de alerta
   */
  addAlertRule(rule: AlertRule): void {
    this.alertRules.set(rule.id, rule);
  }

  /**
   * Agregar canal de notificación
   */
  addNotificationChannel(channel: NotificationChannel): void {
    this.notificationChannels.set(channel.id, channel);
  }

  /**
   * Obtener estadísticas de alertas
   */
  getAlertingStats(): {
    totalAlerts: number;
    alertsBySeverity: Record<string, number>;
    alertsByCategory: Record<string, number>;
    activeAlerts: number;
    escalatedAlerts: number;
    avgResponseTime: number;
    topRules: Array<{ ruleId: string; count: number }>;
  } {
    const alertsBySeverity: Record<string, number> = {};
    const alertsByCategory: Record<string, number> = {};
    
    for (const alert of this.alertHistory) {
      alertsBySeverity[alert.severity] = (alertsBySeverity[alert.severity] || 0) + 1;
      alertsByCategory[alert.category] = (alertsByCategory[alert.category] || 0) + 1;
    }

    const activeAlerts = Array.from(this.alerts.values())
      .filter(alert => alert.status === 'new' || alert.status === 'investigating').length;

    const escalatedAlerts = Array.from(this.alerts.values())
      .filter(alert => alert.escalated).length;

    // Calcular reglas más activas
    const ruleCount: Record<string, number> = {};
    for (const alert of this.alertHistory) {
      const ruleId = alert.metadata.ruleId;
      if (ruleId) {
        ruleCount[ruleId] = (ruleCount[ruleId] || 0) + 1;
      }
    }

    const topRules = Object.entries(ruleCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([ruleId, count]) => ({ ruleId, count }));

    return {
      totalAlerts: this.alertHistory.length,
      alertsBySeverity,
      alertsByCategory,
      activeAlerts,
      escalatedAlerts,
      avgResponseTime: 0, // Placeholder
      topRules
    };
  }

  // Métodos utilitarios privados

  private generateAlertId(): string {
    return `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private formatAlertDescription(template: string, event: any): string {
    return template.replace(/\{(\w+)\}/g, (match, key) => {
      return event[key] || match;
    });
  }

  private getSeverityColor(severity: SecurityAlert['severity']): number {
    switch (severity) {
      case 'low': return 3447003; // Azul
      case 'medium': return 16776960; // Amarillo
      case 'high': return 16744448; // Naranja
      case 'critical': return 15158332; // Rojo
      default: return 9807270; // Gris
    }
  }

  private getSeverityEmoji(severity: SecurityAlert['severity']): string {
    switch (severity) {
      case 'low': return 'ℹ️';
      case 'medium': return '⚠️';
      case 'high': return '🚨';
      case 'critical': return '🔥';
      default: return '❓';
    }
  }

  private fillTemplate(template: any, alert: SecurityAlert): any {
    const filled = JSON.parse(JSON.stringify(template));
    
    const replaceInObject = (obj: any): any => {
      if (typeof obj === 'string') {
        return obj.replace(/\{(\w+)\}/g, (match, key) => {
          return (alert as any)[key] || match;
        });
      } else if (Array.isArray(obj)) {
        return obj.map(replaceInObject);
      } else if (obj && typeof obj === 'object') {
        const result: any = {};
        for (const [key, value] of Object.entries(obj)) {
          result[key] = replaceInObject(value);
        }
        return result;
      }
      return obj;
    };

    return replaceInObject(filled);
  }

  private async sendEscalationNotification(alert: SecurityAlert): Promise<void> {
    // Enviar notificación especial para escalation
    const escalationEvent = {
      type: 'alert_escalated',
      alertId: alert.id,
      originalSeverity: alert.metadata.originalSeverity || 'unknown',
      newSeverity: alert.severity,
      source: 'SecurityAlertingSystem'
    };

    await this.processSecurityEvent(escalationEvent);
  }

  private startPeriodicTasks(): void {
    // Auto-resolver alertas si está configurado
    setInterval(() => {
      this.autoResolveAlerts();
    }, 300000); // Cada 5 minutos

    // Limpiar alertas antiguas
    setInterval(() => {
      this.cleanupOldAlerts();
    }, 3600000); // Cada hora
  }

  private autoResolveAlerts(): void {
    const now = Date.now();
    const autoResolveTimeout = 24 * 60 * 60 * 1000; // 24 horas

    for (const alert of this.alerts.values()) {
      if (alert.metadata.autoResolve && 
          alert.status === 'new' && 
          now - new Date(alert.timestamp).getTime() > autoResolveTimeout) {
        alert.status = 'resolved';
        alert.resolutionTime = now - new Date(alert.timestamp).getTime();
        console.log(`✅ Auto-resolviendo alerta: ${alert.id}`);
      }
    }
  }

  private cleanupOldAlerts(): void {
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000; // 30 días
    
    for (const [id, alert] of this.alerts) {
      if (new Date(alert.timestamp).getTime() < cutoff && 
          alert.status === 'resolved') {
        this.alerts.delete(id);
      }
    }
  }
}

// Export singleton instance
export const securityAlertingSystem = SecurityAlertingSystem.getInstance();
export default SecurityAlertingSystem;
