import { ethers } from 'ethers'

// Interfaces para el cálculo de viabilidad
export interface GasMetrics {
  gasPrice: number // en gwei
  gasUsed: number
  gasFeeUSD: number
  priorityFee?: number // para MEV protection
}

export interface ViabilityMetrics {
  isViable: boolean
  grossProfitUSD: number
  netProfitUSD: number
  netProfitPercentage: number
  gasCostUSD: number
  slippageCostUSD: number
  dexFeesUSD: number
  crossChainCostsUSD: number
  marginFactor: number // factor de margen sobre gas
  executionProbability: number // % de éxito
  recommendedBlockchain: string
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH'
}

export interface BlockchainGasProfile {
  name: string
  token: string
  avgGasPrice: number // gwei
  avgGasUsed: {
    simple: number
    triangular: number
    crossChain: number
    flashLoan: number
  }
  blockTime: number // segundos
  avgGasFeeUSD: number
  priorityFeeRange: [number, number] // gwei
  mempoolLatency: number // ms
}

export interface ArbitrageOpportunity {
  id: string
  type: 'simple' | 'triangular' | 'cross-chain' | 'nft-floor' | 'mev-liquidation'
  tokenPath: string[]
  dexPath: string[]
  chainPath: number[]
  amountInUSD: number
  expectedProfitUSD: number
  blockchain: string
  timestamp: number
}

export class ArbitrageViabilityCalculator {
  private blockchainProfiles: Map<string, BlockchainGasProfile>
  private currentGasPrices: Map<string, number>
  private slippageEstimates: Map<string, number>

  constructor() {
    this.initializeBlockchainProfiles()
    this.currentGasPrices = new Map()
    this.slippageEstimates = new Map()
  }

  /**
   * Inicializar perfiles de gas por blockchain con datos reales
   */
  private initializeBlockchainProfiles(): void {
    this.blockchainProfiles = new Map([
      ['ethereum', {
        name: 'Ethereum Mainnet',
        token: 'ETH',
        avgGasPrice: 32.5, // 25-40 gwei promedio
        avgGasUsed: {
          simple: 180000,
          triangular: 350000,
          crossChain: 450000,
          flashLoan: 550000
        },
        blockTime: 12,
        avgGasFeeUSD: 13, // $8-$18 promedio
        priorityFeeRange: [2, 8], // gwei
        mempoolLatency: 2000 // 2 segundos
      }],
      ['bsc', {
        name: 'Binance Smart Chain',
        token: 'BNB',
        avgGasPrice: 4.5, // 3-6 gwei promedio
        avgGasUsed: {
          simple: 150000,
          triangular: 280000,
          crossChain: 380000,
          flashLoan: 450000
        },
        blockTime: 3,
        avgGasFeeUSD: 0.175, // $0.10-$0.25 promedio
        priorityFeeRange: [0.5, 2],
        mempoolLatency: 500
      }],
      ['polygon', {
        name: 'Polygon',
        token: 'MATIC',
        avgGasPrice: 40, // 30-50 gwei promedio
        avgGasUsed: {
          simple: 120000,
          triangular: 250000,
          crossChain: 350000,
          flashLoan: 420000
        },
        blockTime: 2,
        avgGasFeeUSD: 0.085, // $0.05-$0.12 promedio
        priorityFeeRange: [1, 5],
        mempoolLatency: 300
      }],
      ['arbitrum', {
        name: 'Arbitrum',
        token: 'ETH',
        avgGasPrice: 0.2, // 0.1-0.3 gwei equivalente
        avgGasUsed: {
          simple: 200000,
          triangular: 400000,
          crossChain: 500000,
          flashLoan: 600000
        },
        blockTime: 0.25,
        avgGasFeeUSD: 0.065, // $0.03-$0.10 promedio
        priorityFeeRange: [0.05, 0.2],
        mempoolLatency: 100
      }],
      ['optimism', {
        name: 'Optimism',
        token: 'ETH',
        avgGasPrice: 0.2, // 0.1-0.3 gwei equivalente
        avgGasUsed: {
          simple: 180000,
          triangular: 350000,
          crossChain: 450000,
          flashLoan: 550000
        },
        blockTime: 0.25,
        avgGasFeeUSD: 0.065, // $0.03-$0.10 promedio
        priorityFeeRange: [0.05, 0.2],
        mempoolLatency: 150
      }],
      ['avalanche', {
        name: 'Avalanche',
        token: 'AVAX',
        avgGasPrice: 30, // 25-35 gwei promedio
        avgGasUsed: {
          simple: 140000,
          triangular: 280000,
          crossChain: 380000,
          flashLoan: 450000
        },
        blockTime: 2,
        avgGasFeeUSD: 0.225, // $0.15-$0.30 promedio
        priorityFeeRange: [1, 3],
        mempoolLatency: 400
      }],
      ['fantom', {
        name: 'Fantom',
        token: 'FTM',
        avgGasPrice: 2, // 1-3 gwei promedio
        avgGasUsed: {
          simple: 100000,
          triangular: 200000,
          crossChain: 300000,
          flashLoan: 380000
        },
        blockTime: 1,
        avgGasFeeUSD: 0.006, // $0.002-$0.01 promedio
        priorityFeeRange: [0.1, 0.5],
        mempoolLatency: 200
      }],
      ['base', {
        name: 'Base',
        token: 'ETH',
        avgGasPrice: 0.2, // 0.1-0.3 gwei
        avgGasUsed: {
          simple: 180000,
          triangular: 350000,
          crossChain: 450000,
          flashLoan: 550000
        },
        blockTime: 0.25,
        avgGasFeeUSD: 0.065, // $0.03-$0.10 promedio
        priorityFeeRange: [0.05, 0.2],
        mempoolLatency: 120
      }]
    ])
  }

  /**
   * Actualizar precios de gas en tiempo real
   */
  async updateGasPrices(): Promise<void> {
    try {
      // En producción, esto se conectaría a APIs reales
      for (const [chain, profile] of this.blockchainProfiles) {
        // Simular variación de gas price ±20%
        const variation = 0.8 + Math.random() * 0.4
        const currentPrice = profile.avgGasPrice * variation
        this.currentGasPrices.set(chain, currentPrice)
      }
    } catch (error) {
      console.error('Error actualizando precios de gas:', error)
    }
  }

  /**
   * Calcular métricas de viabilidad para una oportunidad
   */
  async calculateViability(
    opportunity: ArbitrageOpportunity,
    capitalUSD: number = 1000
  ): Promise<ViabilityMetrics> {
    const profile = this.blockchainProfiles.get(opportunity.blockchain)
    if (!profile) {
      throw new Error(`Blockchain no soportada: ${opportunity.blockchain}`)
    }

    // Obtener gas price actual
    const currentGasPrice = this.currentGasPrices.get(opportunity.blockchain) || profile.avgGasPrice

    // Calcular gas usado según tipo de estrategia
    const gasUsed = this.calculateGasUsed(opportunity.type, profile)
    
    // Calcular costo de gas en USD
    const gasCostUSD = this.calculateGasCostUSD(currentGasPrice, gasUsed, profile)
    
    // Calcular slippage estimado
    const slippageCostUSD = this.calculateSlippageCost(opportunity, profile)
    
    // Calcular fees de DEXs
    const dexFeesUSD = this.calculateDEXFees(opportunity, capitalUSD)
    
    // Calcular costos cross-chain si aplica
    const crossChainCostsUSD = this.calculateCrossChainCosts(opportunity, profile)
    
    // Calcular profit neto
    const grossProfitUSD = opportunity.expectedProfitUSD
    const netProfitUSD = grossProfitUSD - gasCostUSD - slippageCostUSD - dexFeesUSD - crossChainCostsUSD
    const netProfitPercentage = (netProfitUSD / capitalUSD) * 100
    
    // Calcular factor de margen sobre gas
    const marginFactor = netProfitUSD / gasCostUSD
    
    // Calcular probabilidad de ejecución
    const executionProbability = this.calculateExecutionProbability(opportunity, profile)
    
    // Determinar si es viable
    const isViable = this.isOpportunityViable(netProfitUSD, gasCostUSD, marginFactor, netProfitPercentage)
    
    // Determinar nivel de riesgo
    const riskLevel = this.calculateRiskLevel(netProfitUSD, gasCostUSD, marginFactor, executionProbability)
    
    // Recomendar blockchain óptima
    const recommendedBlockchain = this.recommendOptimalBlockchain(opportunity, capitalUSD)

    return {
      isViable,
      grossProfitUSD,
      netProfitUSD,
      netProfitPercentage,
      gasCostUSD,
      slippageCostUSD,
      dexFeesUSD,
      crossChainCostsUSD,
      marginFactor,
      executionProbability,
      recommendedBlockchain,
      riskLevel
    }
  }

  /**
   * Calcular gas usado según tipo de estrategia
   */
  private calculateGasUsed(strategyType: string, profile: BlockchainGasProfile): number {
    switch (strategyType) {
      case 'simple':
        return profile.avgGasUsed.simple
      case 'triangular':
        return profile.avgGasUsed.triangular
      case 'cross-chain':
        return profile.avgGasUsed.crossChain
      case 'nft-floor':
        return profile.avgGasUsed.simple + 50000 // +50k para operaciones NFT
      case 'mev-liquidation':
        return profile.avgGasUsed.flashLoan + 100000 // +100k para MEV
      default:
        return profile.avgGasUsed.simple
    }
  }

  /**
   * Calcular costo de gas en USD
   */
  private calculateGasCostUSD(gasPrice: number, gasUsed: number, profile: BlockchainGasProfile): number {
    // Convertir gwei a USD usando precio promedio del token
    const gasPriceInETH = gasPrice * 1e-9 // gwei a ETH
    const gasUsedInETH = gasUsed * gasPriceInETH
    
    // Usar precio promedio del token (en producción se obtendría en tiempo real)
    let tokenPriceUSD = 0
    switch (profile.token) {
      case 'ETH':
        tokenPriceUSD = 3000 // Precio aproximado
        break
      case 'BNB':
        tokenPriceUSD = 300
        break
      case 'MATIC':
        tokenPriceUSD = 0.8
        break
      case 'AVAX':
        tokenPriceUSD = 25
        break
      case 'FTM':
        tokenPriceUSD = 0.3
        break
      default:
        tokenPriceUSD = 1
    }
    
    return gasUsedInETH * tokenPriceUSD
  }

  /**
   * Calcular costo de slippage
   */
  private calculateSlippageCost(opportunity: ArbitrageOpportunity, profile: BlockchainGasProfile): number {
    // Slippage más alto en redes más lentas
    const baseSlippage = 0.002 // 0.2% base
    const networkSlippage = profile.blockTime > 5 ? 0.005 : 0.002 // +0.5% en redes lentas
    const totalSlippage = baseSlippage + networkSlippage
    
    return opportunity.amountInUSD * totalSlippage
  }

  /**
   * Calcular fees de DEXs
   */
  private calculateDEXFees(opportunity: ArbitrageOpportunity, capitalUSD: number): number {
    // Fee promedio de DEX: 0.3%
    const dexFee = 0.003
    const numSwaps = opportunity.dexPath.length
    
    return capitalUSD * dexFee * numSwaps
  }

  /**
   * Calcular costos cross-chain
   */
  private calculateCrossChainCosts(opportunity: ArbitrageOpportunity, profile: BlockchainGasProfile): number {
    if (opportunity.type !== 'cross-chain') return 0
    
    // Costo de bridge: $5-$50 dependiendo de la red
    const bridgeCosts = {
      'ethereum': 25,
      'bsc': 5,
      'polygon': 3,
      'arbitrum': 2,
      'optimism': 2,
      'avalanche': 8,
      'fantom': 1,
      'base': 2
    }
    
    return bridgeCosts[opportunity.blockchain] || 10
  }

  /**
   * Calcular probabilidad de ejecución exitosa
   */
  private calculateExecutionProbability(opportunity: ArbitrageOpportunity, profile: BlockchainGasProfile): number {
    // Base: 85% de éxito
    let probability = 0.85
    
    // Reducir probabilidad en redes lentas
    if (profile.blockTime > 10) probability *= 0.9
    
    // Reducir probabilidad en operaciones complejas
    if (opportunity.type === 'cross-chain') probability *= 0.8
    if (opportunity.type === 'mev-liquidation') probability *= 0.7
    
    // Aumentar probabilidad con priority fees
    probability *= 1.1
    
    return Math.min(probability, 0.95) // Máximo 95%
  }

  /**
   * Determinar si la oportunidad es viable
   */
  private isOpportunityViable(
    netProfitUSD: number,
    gasCostUSD: number,
    marginFactor: number,
    netProfitPercentage: number
  ): boolean {
    // Debe tener profit neto positivo
    if (netProfitUSD <= 0) return false
    
    // Factor de margen mínimo: 1.5x sobre gas
    if (marginFactor < 1.5) return false
    
    // ROI mínimo: 0.5% para operaciones pequeñas, 0.2% para grandes
    const minROI = netProfitUSD < 10 ? 0.005 : 0.002
    if (netProfitPercentage < minROI * 100) return false
    
    return true
  }

  /**
   * Calcular nivel de riesgo
   */
  private calculateRiskLevel(
    netProfitUSD: number,
    gasCostUSD: number,
    marginFactor: number,
    executionProbability: number
  ): 'LOW' | 'MEDIUM' | 'HIGH' {
    let riskScore = 0
    
    // Riesgo por margen bajo
    if (marginFactor < 2) riskScore += 30
    else if (marginFactor < 3) riskScore += 15
    
    // Riesgo por probabilidad de ejecución
    if (executionProbability < 0.7) riskScore += 40
    else if (executionProbability < 0.85) riskScore += 20
    
    // Riesgo por profit bajo
    if (netProfitUSD < gasCostUSD * 2) riskScore += 30
    
    if (riskScore >= 70) return 'HIGH'
    if (riskScore >= 40) return 'MEDIUM'
    return 'LOW'
  }

  /**
   * Recomendar blockchain óptima
   */
  private recommendOptimalBlockchain(opportunity: ArbitrageOpportunity, capitalUSD: number): string {
    // Para capital bajo, priorizar L2s y sidechains
    if (capitalUSD < 100) {
      return opportunity.type === 'mev-liquidation' ? 'arbitrum' : 'polygon'
    }
    
    // Para operaciones MEV, priorizar redes rápidas
    if (opportunity.type === 'mev-liquidation') {
      return 'arbitrum' // Más rápido
    }
    
    // Para arbitraje puro, priorizar costos bajos
    if (['simple', 'triangular'].includes(opportunity.type)) {
      return 'arbitrum' // Gas más bajo
    }
    
    // Para cross-chain, considerar costos de bridge
    if (opportunity.type === 'cross-chain') {
      return 'polygon' // Bridge más barato
    }
    
    return 'arbitrum' // Default: mejor balance
  }

  /**
   * Obtener recomendaciones específicas por estrategia
   */
  getStrategyRecommendations(strategyType: string, capitalUSD: number): {
    recommendedBlockchains: string[]
    minProfitThreshold: number
    gasOptimizationTips: string[]
  } {
    const recommendations = {
      'simple': {
        recommendedBlockchains: ['arbitrum', 'optimism', 'base', 'polygon'],
        minProfitThreshold: capitalUSD < 100 ? 0.8 : 0.3,
        gasOptimizationTips: [
          'Usar priority fees para ejecución rápida',
          'Batch múltiples swaps en una transacción',
          'Evitar Ethereum mainnet para capital < $100'
        ]
      },
      'triangular': {
        recommendedBlockchains: ['arbitrum', 'polygon', 'bsc'],
        minProfitThreshold: capitalUSD < 100 ? 1.2 : 0.5,
        gasOptimizationTips: [
          'Optimizar ruta para minimizar swaps',
          'Usar DEXs con mejor liquidez',
          'Considerar flash loans para capital alto'
        ]
      },
      'cross-chain': {
        recommendedBlockchains: ['polygon', 'bsc', 'avalanche'],
        minProfitThreshold: capitalUSD < 100 ? 2.0 : 1.0,
        gasOptimizationTips: [
          'Usar bridges con mejor liquidez',
          'Timing crítico para evitar slippage',
          'Considerar costos de bridge en ROI'
        ]
      },
      'nft-floor': {
        recommendedBlockchains: ['ethereum', 'polygon', 'arbitrum'],
        minProfitThreshold: capitalUSD < 100 ? 3.0 : 1.5,
        gasOptimizationTips: [
          'Monitorear floor price en tiempo real',
          'Usar aggregators para mejor precio',
          'Considerar gas de mint/burn'
        ]
      },
      'mev-liquidation': {
        recommendedBlockchains: ['arbitrum', 'base', 'optimism'],
        minProfitThreshold: capitalUSD < 100 ? 5.0 : 2.0,
        gasOptimizationTips: [
          'Priority fees altos para velocidad',
          'Monitorear mempool constantemente',
          'Usar flash loans para ejecución atómica'
        ]
      }
    }

    return recommendations[strategyType] || recommendations['simple']
  }

  /**
   * Generar reporte de viabilidad completo
   */
  async generateViabilityReport(opportunities: ArbitrageOpportunity[]): Promise<{
    totalOpportunities: number
    viableOpportunities: number
    totalPotentialProfit: number
    totalGasCosts: number
    recommendations: string[]
    blockchainRanking: Array<{chain: string, avgROI: number, successRate: number}>
  }> {
    const viabilityResults = await Promise.all(
      opportunities.map(opp => this.calculateViability(opp))
    )

    const viableOpps = viabilityResults.filter(v => v.isViable)
    const totalPotentialProfit = viableOpps.reduce((sum, v) => sum + v.netProfitUSD, 0)
    const totalGasCosts = viableOpps.reduce((sum, v) => sum + v.gasCostUSD, 0)

    // Ranking por blockchain
    const blockchainStats = new Map<string, {totalROI: number, count: number, successRate: number}>()
    
    for (const result of viabilityResults) {
      const chain = result.recommendedBlockchain
      if (!blockchainStats.has(chain)) {
        blockchainStats.set(chain, {totalROI: 0, count: 0, successRate: 0})
      }
      
      const stats = blockchainStats.get(chain)!
      stats.totalROI += result.netProfitPercentage
      stats.count += 1
      stats.successRate += result.executionProbability
    }

    const blockchainRanking = Array.from(blockchainStats.entries())
      .map(([chain, stats]) => ({
        chain,
        avgROI: stats.totalROI / stats.count,
        successRate: stats.successRate / stats.count
      }))
      .sort((a, b) => b.avgROI - a.avgROI)

    const recommendations = [
      `Priorizar ${blockchainRanking[0]?.chain} para mejor ROI promedio`,
      `Evitar operaciones con margen < 1.5x sobre gas`,
      `Usar priority fees en redes congestionadas`,
      `Considerar costos cross-chain en estrategias multi-red`
    ]

    return {
      totalOpportunities: opportunities.length,
      viableOpportunities: viableOpps.length,
      totalPotentialProfit,
      totalGasCosts,
      recommendations,
      blockchainRanking
    }
  }
}
