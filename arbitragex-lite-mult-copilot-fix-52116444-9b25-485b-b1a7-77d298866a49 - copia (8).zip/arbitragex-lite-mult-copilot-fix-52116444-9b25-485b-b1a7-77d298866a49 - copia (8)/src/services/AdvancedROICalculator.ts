import { ethers } from 'ethers'
import { secureLogger } from '../utils/SecurityUtils'

// Interfaces para cálculo avanzado de ROI
export interface GasEstimate {
  gasLimit: number
  gasPriceGwei: number
  maxFeePerGas?: number
  maxPriorityFeePerGas?: number
  totalCostETH: number
  totalCostUSD: number
  gasEfficiency: number // 1-10 scale
}

export interface FeeBreakdown {
  gasFees: number
  protocolFees: number
  flashLoanFees: number
  bridgeFees: number
  mevProtectionFees: number
  totalFees: number
  totalFeesUSD: number
}

export interface ROICalculation {
  grossProfit: number
  totalFees: number
  netProfit: number
  roi: number
  roiAnnualized: number
  breakEvenAmount: number
  minimumViableAmount: number
  riskAdjustedROI: number
  confidence: number
}

export interface MEVData {
  source: 'eigenphi' | 'flashbots' | 'blocknative' | 'mevwatch'
  timestamp: number
  gasPrice: number
  priorityFee: number
  baseFee: number
  maxFeePerGas: number
  maxPriorityFeePerGas: number
  blockNumber: number
  network: string
}

export interface StrategyROI {
  strategyId: string
  strategyName: string
  complexity: 'low' | 'medium' | 'high' | 'expert'
  riskLevel: number // 1-10
  expectedROI: number
  minimumCapital: number
  gasEfficiency: number
  executionTime: number
  successRate: number
  mevProtectionRequired: boolean
  flashLoanRequired: boolean
  crossChainRequired: boolean
}

export class AdvancedROICalculator {
  private providers: Map<number, ethers.Provider> = new Map()
  private mevDataCache: Map<string, MEVData[]> = new Map()
  private gasPriceHistory: Map<number, number[]> = new Map()
  private feeDataCache: Map<string, any> = new Map()
  private lastUpdate: number = 0
  private updateInterval: number = 30000 // 30 segundos

  constructor() {
    this.initializeProviders()
    this.startPeriodicUpdates()
  }

  private initializeProviders(): void {
    // Ethereum Mainnet
    this.providers.set(1, new ethers.JsonRpcProvider(process.env.VITE_ETHEREUM_RPC_URL))
    // Polygon
    this.providers.set(137, new ethers.JsonRpcProvider(process.env.VITE_POLYGON_RPC_URL))
    // BSC
    this.providers.set(56, new ethers.JsonRpcProvider(process.env.VITE_BSC_RPC_URL))
    // Arbitrum
    this.providers.set(42161, new ethers.JsonRpcProvider(process.env.VITE_ARBITRUM_RPC_URL))
    // Optimism
    this.providers.set(10, new ethers.JsonRpcProvider(process.env.VITE_OPTIMISM_RPC_URL))
    // Avalanche
    this.providers.set(43114, new ethers.JsonRpcProvider(process.env.VITE_AVALANCHE_RPC_URL))
    // Fantom
    this.providers.set(250, new ethers.JsonRpcProvider(process.env.VITE_FANTOM_RPC_URL))
    // Cronos
    this.providers.set(25, new ethers.JsonRpcProvider(process.env.VITE_CRONOS_RPC_URL))
  }

  /**
   * Calcular ROI completo para una estrategia de arbitraje
   */
  async calculateStrategyROI(
    strategy: StrategyROI,
    amountIn: number,
    expectedProfitPercentage: number,
    chainId: number
  ): Promise<ROICalculation> {
    try {
      // Obtener datos de gas en tiempo real
      const gasEstimate = await this.getRealTimeGasEstimate(chainId, strategy.strategyId)
      
      // Calcular fees totales
      const feeBreakdown = await this.calculateTotalFees(
        strategy,
        amountIn,
        gasEstimate,
        chainId
      )

      // Calcular ganancias
      const grossProfit = (amountIn * expectedProfitPercentage) / 100
      const netProfit = grossProfit - feeBreakdown.totalFeesUSD
      const roi = (netProfit / amountIn) * 100
      const roiAnnualized = this.calculateAnnualizedROI(roi, strategy.executionTime)

      // Calcular monto mínimo viable
      const breakEvenAmount = this.calculateBreakEvenAmount(feeBreakdown.totalFeesUSD, expectedProfitPercentage)
      const minimumViableAmount = this.calculateMinimumViableAmount(
        strategy,
        feeBreakdown,
        expectedProfitPercentage
      )

      // Calcular ROI ajustado por riesgo
      const riskAdjustedROI = this.calculateRiskAdjustedROI(roi, strategy.riskLevel)

      // Calcular confianza basada en datos históricos
      const confidence = await this.calculateConfidence(chainId, strategy)

      return {
        grossProfit,
        totalFees: feeBreakdown.totalFeesUSD,
        netProfit,
        roi,
        roiAnnualized,
        breakEvenAmount,
        minimumViableAmount,
        riskAdjustedROI,
        confidence
      }
    } catch (error) {
      secureLogger.error('Error calculando ROI de estrategia', {
        strategy: strategy.strategyId,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'AdvancedROICalculator')

      // Retornar cálculo conservador en caso de error
      return this.getConservativeROI(amountIn, expectedProfitPercentage)
    }
  }

  /**
   * Obtener estimación de gas en tiempo real
   */
  private async getRealTimeGasEstimate(
    chainId: number,
    strategyId: string
  ): Promise<GasEstimate> {
    const provider = this.providers.get(chainId)
    if (!provider) {
      throw new Error(`Provider no disponible para chain ${chainId}`)
    }

    try {
      // Obtener datos de gas actuales
      const feeData = await provider.getFeeData()
      const currentBlock = await provider.getBlockNumber()
      
      // Obtener datos de MEV para optimización
      const mevData = await this.getMEVData(chainId)
      
      // Calcular gas limit óptimo basado en estrategia
      const gasLimit = this.calculateOptimalGasLimit(strategyId, chainId)
      
      // Calcular gas price óptimo
      const gasPriceGwei = this.calculateOptimalGasPrice(feeData, mevData)
      
      // Calcular costos
      const totalCostETH = (gasLimit * gasPriceGwei * 1e9) / 1e18
      const ethPriceUSD = await this.getETHPriceUSD()
      const totalCostUSD = totalCostETH * ethPriceUSD
      
      // Calcular eficiencia de gas
      const gasEfficiency = this.calculateGasEfficiency(gasLimit, strategyId)

      return {
        gasLimit,
        gasPriceGwei,
        maxFeePerGas: feeData.maxFeePerGas ? parseFloat(ethers.formatUnits(feeData.maxFeePerGas, 'gwei')) : undefined,
        maxPriorityFeePerGas: feeData.maxPriorityFeePerGas ? parseFloat(ethers.formatUnits(feeData.maxPriorityFeePerGas, 'gwei')) : undefined,
        totalCostETH,
        totalCostUSD,
        gasEfficiency
      }
    } catch (error) {
      throw new Error(`Error estimando gas: ${error}`)
    }
  }

  /**
   * Calcular fees totales incluyendo todos los costos
   */
  private async calculateTotalFees(
    strategy: StrategyROI,
    amountIn: number,
    gasEstimate: GasEstimate,
    chainId: number
  ): Promise<FeeBreakdown> {
    const gasFees = gasEstimate.totalCostUSD
    
    // Protocol fees (DEX fees)
    const protocolFees = this.calculateProtocolFees(strategy, amountIn)
    
    // Flash loan fees si es requerido
    const flashLoanFees = strategy.flashLoanRequired ? 
      this.calculateFlashLoanFees(amountIn, chainId) : 0
    
    // Bridge fees si es cross-chain
    const bridgeFees = strategy.crossChainRequired ? 
      this.calculateBridgeFees(amountIn, chainId) : 0
    
    // MEV protection fees
    const mevProtectionFees = strategy.mevProtectionRequired ? 
      this.calculateMEVProtectionFees(chainId) : 0
    
    const totalFees = gasFees + protocolFees + flashLoanFees + bridgeFees + mevProtectionFees

    return {
      gasFees,
      protocolFees,
      flashLoanFees,
      bridgeFees,
      mevProtectionFees,
      totalFees,
      totalFeesUSD: totalFees
    }
  }

  /**
   * Calcular fees de protocolo (DEX)
   */
  private calculateProtocolFees(strategy: StrategyROI, amountIn: number): number {
    // Fees típicos por DEX
    const dexFees = {
      'uniswap-v3': 0.003, // 0.3%
      'sushiswap': 0.003,  // 0.3%
      'pancakeswap': 0.0025, // 0.25%
      'balancer': 0.002,   // 0.2%
      'curve': 0.001       // 0.1%
    }

    // Calcular fees basado en complejidad de la estrategia
    const complexityMultiplier = {
      'low': 1,
      'medium': 1.5,
      'high': 2,
      'expert': 2.5
    }[strategy.complexity] || 1

    const baseFee = 0.003 // Fee promedio
    return (amountIn * baseFee * complexityMultiplier)
  }

  /**
   * Calcular fees de flash loan
   */
  private calculateFlashLoanFees(amountIn: number, chainId: number): number {
    // Fees de flash loan por protocolo
    const flashLoanFees = {
      1: 0.0009,    // Ethereum: Aave 0.09%
      137: 0.0009,  // Polygon: Aave 0.09%
      56: 0.0008,   // BSC: Venus 0.08%
      42161: 0.0009, // Arbitrum: Aave 0.09%
      10: 0.0009,   // Optimism: Aave 0.09%
      43114: 0.0009, // Avalanche: Aave 0.09%
      250: 0.0009,  // Fantom: Aave 0.09%
      25: 0.0008    // Cronos: Venus 0.08%
    }

    const fee = flashLoanFees[chainId as keyof typeof flashLoanFees] || 0.0009
    return amountIn * fee
  }

  /**
   * Calcular fees de bridge
   */
  private calculateBridgeFees(amountIn: number, chainId: number): number {
    // Fees de bridge por protocolo
    const bridgeFees = {
      'wormhole': 0.001,   // 0.1%
      'axelar': 0.0015,    // 0.15%
      'layerzero': 0.0012, // 0.12%
      'multichain': 0.0018 // 0.18%
    }

    const avgBridgeFee = 0.0013 // Fee promedio
    return amountIn * avgBridgeFee
  }

  /**
   * Calcular fees de protección MEV
   */
  private calculateMEVProtectionFees(chainId: number): number {
    // Fees de protección MEV
    const mevFees = {
      1: 0.0005,    // Ethereum: Flashbots 0.05%
      137: 0.0003,  // Polygon: MEV-Share 0.03%
      56: 0.0002,   // BSC: MEV-Share 0.02%
      42161: 0.0004, // Arbitrum: Flashbots 0.04%
      10: 0.0004,   // Optimism: Flashbots 0.04%
      43114: 0.0003, // Avalanche: MEV-Share 0.03%
      250: 0.0003,  // Fantom: MEV-Share 0.03%
      25: 0.0002    // Cronos: MEV-Share 0.02%
    }

    return mevFees[chainId as keyof typeof mevFees] || 0.0003
  }

  /**
   * Obtener datos de MEV de múltiples fuentes
   */
  private async getMEVData(chainId: number): Promise<MEVData[]> {
    const cacheKey = `${chainId}_${Math.floor(Date.now() / 60000)}` // Cache por minuto
    
    if (this.mevDataCache.has(cacheKey)) {
      return this.mevDataCache.get(cacheKey)!
    }

    try {
      const mevData: MEVData[] = []

      // Simular datos de EigenPhi
      if (chainId === 1) { // Solo Ethereum para EigenPhi
        mevData.push({
          source: 'eigenphi',
          timestamp: Date.now(),
          gasPrice: 25 + Math.random() * 10,
          priorityFee: 2 + Math.random() * 3,
          baseFee: 20 + Math.random() * 8,
          maxFeePerGas: 35 + Math.random() * 15,
          maxPriorityFeePerGas: 3 + Math.random() * 4,
          blockNumber: await this.getCurrentBlockNumber(chainId),
          network: 'ethereum'
        })
      }

      // Simular datos de Flashbots
      mevData.push({
        source: 'flashbots',
        timestamp: Date.now(),
        gasPrice: 22 + Math.random() * 8,
        priorityFee: 1.5 + Math.random() * 2.5,
        baseFee: 18 + Math.random() * 6,
        maxFeePerGas: 30 + Math.random() * 12,
        maxPriorityFeePerGas: 2.5 + Math.random() * 3,
        blockNumber: await this.getCurrentBlockNumber(chainId),
        network: this.getNetworkName(chainId)
      })

      // Simular datos de Blocknative
      mevData.push({
        source: 'blocknative',
        timestamp: Date.now(),
        gasPrice: 24 + Math.random() * 9,
        priorityFee: 2.2 + Math.random() * 2.8,
        baseFee: 19 + Math.random() * 7,
        maxFeePerGas: 32 + Math.random() * 14,
        maxPriorityFeePerGas: 2.8 + Math.random() * 3.2,
        blockNumber: await this.getCurrentBlockNumber(chainId),
        network: this.getNetworkName(chainId)
      })

      // Simular datos de MEVWatch
      mevData.push({
        source: 'mevwatch',
        timestamp: Date.now(),
        gasPrice: 23 + Math.random() * 8,
        priorityFee: 1.8 + Math.random() * 2.6,
        baseFee: 18.5 + Math.random() * 6.5,
        maxFeePerGas: 31 + Math.random() * 13,
        maxPriorityFeePerGas: 2.6 + Math.random() * 3.1,
        blockNumber: await this.getCurrentBlockNumber(chainId),
        network: this.getNetworkName(chainId)
      })

      this.mevDataCache.set(cacheKey, mevData)
      return mevData

    } catch (error) {
      secureLogger.error('Error obteniendo datos MEV', {
        chainId,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'AdvancedROICalculator')

      // Retornar datos por defecto
      return [{
        source: 'flashbots',
        timestamp: Date.now(),
        gasPrice: 25,
        priorityFee: 2,
        baseFee: 20,
        maxFeePerGas: 35,
        maxPriorityFeePerGas: 3,
        blockNumber: 0,
        network: this.getNetworkName(chainId)
      }]
    }
  }

  /**
   * Calcular gas limit óptimo basado en estrategia
   */
  private calculateOptimalGasLimit(strategyId: string, chainId: number): number {
    // Gas limits base por estrategia
    const baseGasLimits = {
      'simple-arbitrage': 200000,
      'flash-loan-arbitrage': 500000,
      'triangular-arbitrage': 400000,
      'cross-chain-arbitrage': 600000,
      'jit-liquidity': 350000,
      'sandwich-attack': 450000,
      'liquidation': 300000
    }

    // Multiplicadores por blockchain
    const chainMultipliers = {
      1: 1.0,      // Ethereum
      137: 0.8,    // Polygon
      56: 0.7,     // BSC
      42161: 0.9,  // Arbitrum
      10: 0.85,    // Optimism
      43114: 0.8,  // Avalanche
      250: 0.75,   // Fantom
      25: 0.7      // Cronos
    }

    const baseGas = baseGasLimits[strategyId as keyof typeof baseGasLimits] || 300000
    const multiplier = chainMultipliers[chainId as keyof typeof chainMultipliers] || 1.0

    return Math.floor(baseGas * multiplier)
  }

  /**
   * Calcular gas price óptimo basado en datos MEV
   */
  private calculateOptimalGasPrice(feeData: any, mevData: MEVData[]): number {
    if (mevData.length === 0) {
      return feeData.gasPrice ? parseFloat(ethers.formatUnits(feeData.gasPrice, 'gwei')) : 25
    }

    // Calcular gas price óptimo basado en datos MEV
    const gasPrices = mevData.map(data => data.gasPrice)
    const avgGasPrice = gasPrices.reduce((a, b) => a + b, 0) / gasPrices.length
    
    // Ajustar basado en prioridad
    const priorityFee = mevData[0]?.priorityFee || 2
    const optimalGasPrice = Math.max(avgGasPrice, feeData.gasPrice ? 
      parseFloat(ethers.formatUnits(feeData.gasPrice, 'gwei')) : 20)

    return Math.ceil(optimalGasPrice + priorityFee)
  }

  /**
   * Calcular eficiencia de gas
   */
  private calculateGasEfficiency(gasLimit: number, strategyId: string): number {
    const baseEfficiency = {
      'simple-arbitrage': 9,
      'flash-loan-arbitrage': 7,
      'triangular-arbitrage': 8,
      'cross-chain-arbitrage': 6,
      'jit-liquidity': 8,
      'sandwich-attack': 7,
      'liquidation': 9
    }

    const base = baseEfficiency[strategyId as keyof typeof baseEfficiency] || 7
    
    // Ajustar basado en gas limit
    if (gasLimit <= 200000) return Math.min(10, base + 1)
    if (gasLimit <= 400000) return base
    if (gasLimit <= 600000) return Math.max(1, base - 1)
    return Math.max(1, base - 2)
  }

  /**
   * Calcular ROI anualizado
   */
  private calculateAnnualizedROI(roi: number, executionTimeSeconds: number): number {
    const executionsPerDay = (24 * 60 * 60) / executionTimeSeconds
    const executionsPerYear = executionsPerDay * 365
    return roi * executionsPerYear
  }

  /**
   * Calcular monto de equilibrio
   */
  private calculateBreakEvenAmount(totalFees: number, profitPercentage: number): number {
    return (totalFees / (profitPercentage / 100))
  }

  /**
   * Calcular monto mínimo viable
   */
  private calculateMinimumViableAmount(
    strategy: StrategyROI,
    feeBreakdown: FeeBreakdown,
    expectedProfitPercentage: number
  ): number {
    // Mínimo 2% de ROI después de fees
    const minROI = 2
    const totalFeesPercentage = (feeBreakdown.totalFeesUSD / strategy.minimumCapital) * 100
    
    if (expectedProfitPercentage <= totalFeesPercentage + minROI) {
      return strategy.minimumCapital
    }

    // Calcular monto que genere ROI mínimo
    const requiredProfit = feeBreakdown.totalFeesUSD + (strategy.minimumCapital * minROI / 100)
    return (requiredProfit / (expectedProfitPercentage / 100))
  }

  /**
   * Calcular ROI ajustado por riesgo
   */
  private calculateRiskAdjustedROI(roi: number, riskLevel: number): number {
    const riskAdjustment = 1 - (riskLevel - 1) * 0.1 // Reducir 10% por nivel de riesgo
    return roi * Math.max(0.1, riskAdjustment)
  }

  /**
   * Calcular confianza basada en datos históricos
   */
  private async calculateConfidence(chainId: number, strategy: StrategyROI): Promise<number> {
    try {
      // Simular cálculo de confianza basado en datos históricos
      const baseConfidence = 0.7
      
      // Ajustar por complejidad
      const complexityAdjustment = {
        'low': 0.1,
        'medium': 0,
        'high': -0.1,
        'expert': -0.2
      }[strategy.complexity] || 0

      // Ajustar por blockchain
      const blockchainAdjustment = {
        1: 0.1,      // Ethereum: más estable
        137: 0.05,   // Polygon: estable
        56: 0,       // BSC: neutral
        42161: 0.05, // Arbitrum: estable
        10: 0.05,    // Optimism: estable
        43114: 0,    // Avalanche: neutral
        250: -0.05,  // Fantom: menos estable
        25: -0.05    // Cronos: menos estable
      }[chainId] || 0

      const confidence = baseConfidence + complexityAdjustment + blockchainAdjustment
      return Math.max(0.1, Math.min(1, confidence))

    } catch (error) {
      return 0.5 // Confianza neutral por defecto
    }
  }

  /**
   * Obtener precio de ETH en USD
   */
  private async getETHPriceUSD(): Promise<number> {
    try {
      // En producción, consultar oracle real
      // Por ahora, usar precio fijo
      return 3000
    } catch (error) {
      return 3000 // Fallback
    }
  }

  /**
   * Obtener número de bloque actual
   */
  private async getCurrentBlockNumber(chainId: number): Promise<number> {
    try {
      const provider = this.providers.get(chainId)
      if (provider) {
        return await provider.getBlockNumber()
      }
      return 0
    } catch (error) {
      return 0
    }
  }

  /**
   * Obtener nombre de red
   */
  private getNetworkName(chainId: number): string {
    const networks = {
      1: 'ethereum',
      137: 'polygon',
      56: 'bsc',
      42161: 'arbitrum',
      10: 'optimism',
      43114: 'avalanche',
      250: 'fantom',
      25: 'cronos'
    }
    return networks[chainId as keyof typeof networks] || 'unknown'
  }

  /**
   * ROI conservador en caso de error
   */
  private getConservativeROI(amountIn: number, expectedProfitPercentage: number): ROICalculation {
    const grossProfit = (amountIn * expectedProfitPercentage) / 100
    const totalFees = amountIn * 0.01 // 1% conservador
    const netProfit = grossProfit - totalFees
    const roi = (netProfit / amountIn) * 100

    return {
      grossProfit,
      totalFees,
      netProfit,
      roi,
      roiAnnualized: roi * 24 * 365, // Asumiendo 1 ejecución por hora
      breakEvenAmount: totalFees / (expectedProfitPercentage / 100),
      minimumViableAmount: amountIn,
      riskAdjustedROI: roi * 0.8, // 20% reducción por riesgo
      confidence: 0.5
    }
  }

  /**
   * Iniciar actualizaciones periódicas
   */
  private startPeriodicUpdates(): void {
    setInterval(() => {
      this.updateGasPriceHistory()
      this.cleanupCache()
    }, this.updateInterval)
  }

  /**
   * Actualizar historial de precios de gas
   */
  private async updateGasPriceHistory(): Promise<void> {
    for (const [chainId, provider] of this.providers) {
      try {
        const feeData = await provider.getFeeData()
        const gasPrice = feeData.gasPrice ? 
          parseFloat(ethers.formatUnits(feeData.gasPrice, 'gwei')) : 25

        if (!this.gasPriceHistory.has(chainId)) {
          this.gasPriceHistory.set(chainId, [])
        }

        const history = this.gasPriceHistory.get(chainId)!
        history.push(gasPrice)

        // Mantener solo últimos 100 precios
        if (history.length > 100) {
          history.shift()
        }
      } catch (error) {
        // Ignorar errores en actualizaciones periódicas
      }
    }
  }

  /**
   * Limpiar cache expirado
   */
  private cleanupCache(): void {
    const now = Date.now()
    const maxAge = 5 * 60 * 1000 // 5 minutos

    for (const [key, data] of this.mevDataCache) {
      if (now - data[0]?.timestamp > maxAge) {
        this.mevDataCache.delete(key)
      }
    }

    // Limpiar fee data cache
    for (const [key, data] of this.feeDataCache) {
      if (now - data.timestamp > maxAge) {
        this.feeDataCache.delete(key)
      }
    }
  }

  /**
   * Obtener estadísticas de gas por blockchain
   */
  async getGasStatistics(chainId: number): Promise<{
    currentGasPrice: number
    averageGasPrice: number
    gasPriceTrend: 'increasing' | 'decreasing' | 'stable'
    recommendedGasPrice: number
    gasEfficiency: number
  }> {
    const history = this.gasPriceHistory.get(chainId) || []
    const currentGasPrice = history[history.length - 1] || 25
    
    const averageGasPrice = history.length > 0 ? 
      history.reduce((a, b) => a + b, 0) / history.length : 25

    let gasPriceTrend: 'increasing' | 'decreasing' | 'stable' = 'stable'
    if (history.length >= 2) {
      const recent = history.slice(-5)
      const older = history.slice(-10, -5)
      if (recent.length > 0 && older.length > 0) {
        const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length
        const olderAvg = older.reduce((a, b) => a + b, 0) / older.length
        if (recentAvg > olderAvg * 1.1) gasPriceTrend = 'increasing'
        else if (recentAvg < olderAvg * 0.9) gasPriceTrend = 'decreasing'
      }
    }

    const recommendedGasPrice = Math.ceil(currentGasPrice * 1.1) // 10% buffer
    const gasEfficiency = this.calculateGasEfficiency(200000, 'simple-arbitrage')

    return {
      currentGasPrice,
      averageGasPrice,
      gasPriceTrend,
      recommendedGasPrice,
      gasEfficiency
    }
  }

  /**
   * Obtener estrategias más rentables
   */
  getMostProfitableStrategies(): StrategyROI[] {
    return [
      {
        strategyId: 'cross-chain-multi-hop-flash',
        strategyName: 'Cross-Chain Multi-Hop Flash-Loan',
        complexity: 'expert',
        riskLevel: 8.5,
        expectedROI: 20,
        minimumCapital: 50000,
        gasEfficiency: 7,
        executionTime: 60,
        successRate: 85,
        mevProtectionRequired: true,
        flashLoanRequired: true,
        crossChainRequired: true
      },
      {
        strategyId: 'flash-loan-triangular-cross-dex',
        strategyName: 'Flash-Loan Triangular Cross-DEX',
        complexity: 'high',
        riskLevel: 7.2,
        expectedROI: 15,
        minimumCapital: 20000,
        gasEfficiency: 8,
        executionTime: 35,
        successRate: 80,
        mevProtectionRequired: true,
        flashLoanRequired: true,
        crossChainRequired: false
      },
      {
        strategyId: 'jit-liquidity-arbitrage',
        strategyName: 'JIT Liquidity Arbitrage',
        complexity: 'expert',
        riskLevel: 7.8,
        expectedROI: 12,
        minimumCapital: 30000,
        gasEfficiency: 8,
        executionTime: 15,
        successRate: 75,
        mevProtectionRequired: true,
        flashLoanRequired: false,
        crossChainRequired: false
      }
    ]
  }
}

// Instancia singleton
export const advancedROICalculator = new AdvancedROICalculator()
