import { ArbitrageViabilityCalculator, ViabilityMetrics } from './ArbitrageViabilityCalculator'

export interface StrategyViability {
  id: string
  name: string
  description: string
  type: string
  capitalRequired: number
  expectedProfitRange: [number, number] // [min, max] en USD
  gasIntensive: boolean
  timeSensitive: boolean
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH'
  recommendedBlockchains: string[]
  viabilityScore: number // 0-100
  isViable: boolean
  gasOptimizationTips: string[]
  executionRequirements: string[]
}

export interface StrategyComparison {
  strategy: StrategyViability
  viabilityMetrics: ViabilityMetrics
  roiByBlockchain: Map<string, number>
  gasEfficiency: number
  executionProbability: number
}

export class StrategyViabilityService {
  private calculator: ArbitrageViabilityCalculator
  private strategies: StrategyViability[]

  constructor() {
    this.calculator = new ArbitrageViabilityCalculator()
    this.initializeStrategies()
  }

  /**
   * Inicializar las 8 estrategias con parámetros reales
   */
  private initializeStrategies(): void {
    this.strategies = [
      {
        id: '1',
        name: 'Arbitraje Simple DEX',
        description: 'Compra en DEX A, vende en DEX B - misma blockchain',
        type: 'simple',
        capitalRequired: 100,
        expectedProfitRange: [2, 25],
        gasIntensive: false,
        timeSensitive: true,
        riskLevel: 'LOW',
        recommendedBlockchains: ['arbitrum', 'optimism', 'base', 'polygon'],
        viabilityScore: 0,
        isViable: false,
        gasOptimizationTips: [
          'Usar priority fees para ejecución rápida',
          'Batch múltiples swaps en una transacción',
          'Evitar Ethereum mainnet para capital < $100'
        ],
        executionRequirements: [
          'Monitoreo en tiempo real de precios',
          'Ejecución automática con slippage < 0.5%',
          'Liquidez mínima $10k en ambos DEXs'
        ]
      },
      {
        id: '2',
        name: 'Arbitraje Triangular',
        description: 'ETH → USDC → DAI → ETH en misma blockchain',
        type: 'triangular',
        capitalRequired: 500,
        expectedProfitRange: [8, 60],
        gasIntensive: true,
        timeSensitive: true,
        riskLevel: 'MEDIUM',
        recommendedBlockchains: ['arbitrum', 'polygon', 'bsc'],
        viabilityScore: 0,
        isViable: false,
        gasOptimizationTips: [
          'Optimizar ruta para minimizar swaps',
          'Usar DEXs con mejor liquidez',
          'Considerar flash loans para capital alto'
        ],
        executionRequirements: [
          'Simulación previa de ruta completa',
          'Slippage máximo 0.3% por swap',
          'Liquidez mínima $50k en cada DEX'
        ]
      },
      {
        id: '3',
        name: 'Arbitraje Cross-Chain',
        description: 'Explotar diferencias entre blockchains',
        type: 'cross-chain',
        capitalRequired: 1000,
        expectedProfitRange: [15, 120],
        gasIntensive: true,
        timeSensitive: true,
        riskLevel: 'HIGH',
        recommendedBlockchains: ['polygon', 'bsc', 'avalanche'],
        viabilityScore: 0,
        isViable: false,
        gasOptimizationTips: [
          'Usar bridges con mejor liquidez',
          'Timing crítico para evitar slippage',
          'Considerar costos de bridge en ROI'
        ],
        executionRequirements: [
          'Monitoreo de bridges en tiempo real',
          'Cálculo de costos de bridge',
          'Liquidez mínima $100k en ambas redes'
        ]
      },
      {
        id: '4',
        name: 'Arbitraje NFT Floor',
        description: 'Compra en marketplace A, vende en B',
        type: 'nft-floor',
        capitalRequired: 1000,
        expectedProfitRange: [20, 200],
        gasIntensive: true,
        timeSensitive: false,
        riskLevel: 'MEDIUM',
        recommendedBlockchains: ['ethereum', 'polygon', 'arbitrum'],
        viabilityScore: 0,
        isViable: false,
        gasOptimizationTips: [
          'Monitorear floor price en tiempo real',
          'Usar aggregators para mejor precio',
          'Considerar gas de mint/burn'
        ],
        executionRequirements: [
          'API de floor price en tiempo real',
          'Análisis de liquidez del NFT',
          'Capital mínimo $1k por operación'
        ]
      },
      {
        id: '5',
        name: 'Capital $1 Arbitraje',
        description: 'Micro-arbitrajes con capital mínimo',
        type: 'simple',
        capitalRequired: 1,
        expectedProfitRange: [0.05, 0.5],
        gasIntensive: false,
        timeSensitive: true,
        riskLevel: 'HIGH',
        recommendedBlockchains: ['polygon', 'bsc', 'fantom'],
        viabilityScore: 0,
        isViable: false,
        gasOptimizationTips: [
          'Solo redes con gas < $0.01',
          'Batch múltiples operaciones',
          'Evitar Ethereum mainnet completamente'
        ],
        executionRequirements: [
          'Gas price < $0.01 por operación',
          'Profit mínimo 5x sobre gas',
          'Ejecución en lotes de 10+ operaciones'
        ]
      },
      {
        id: '6',
        name: 'NFT Floor Cross-Chain',
        description: 'Arbitraje NFT entre blockchains',
        type: 'cross-chain',
        capitalRequired: 2000,
        expectedProfitRange: [50, 400],
        gasIntensive: true,
        timeSensitive: false,
        riskLevel: 'HIGH',
        recommendedBlockchains: ['polygon', 'bsc', 'avalanche'],
        viabilityScore: 0,
        isViable: false,
        gasOptimizationTips: [
          'Evaluar costos de bridge vs profit',
          'Usar bridges con mejor liquidez',
          'Considerar gas de mint/burn en ambas redes'
        ],
        executionRequirements: [
          'Análisis de costos de bridge',
          'Floor price en ambas blockchains',
          'Capital mínimo $2k por operación'
        ]
      },
      {
        id: '7',
        name: 'MEV Liquidation Backrun',
        description: 'Explotar liquidaciones de DeFi',
        type: 'mev-liquidation',
        capitalRequired: 5000,
        expectedProfitRange: [100, 800],
        gasIntensive: true,
        timeSensitive: true,
        riskLevel: 'HIGH',
        recommendedBlockchains: ['arbitrum', 'base', 'optimism'],
        viabilityScore: 0,
        isViable: false,
        gasOptimizationTips: [
          'Priority fees altos para velocidad',
          'Monitorear mempool constantemente',
          'Usar flash loans para ejecución atómica'
        ],
        executionRequirements: [
          'Monitoreo de mempool en tiempo real',
          'Priority fees > 2x gas base',
          'Capital mínimo $5k por operación'
        ]
      },
      {
        id: '8',
        name: 'Capital $1 MEV',
        description: 'MEV con capital mínimo',
        type: 'mev-liquidation',
        capitalRequired: 1,
        expectedProfitRange: [0.1, 2],
        gasIntensive: false,
        timeSensitive: true,
        riskLevel: 'HIGH',
        recommendedBlockchains: ['polygon', 'bsc', 'fantom'],
        viabilityScore: 0,
        isViable: false,
        gasOptimizationTips: [
          'Solo redes ultra-rápidas',
          'Gas price < $0.005',
          'Ejecución en lotes masivos'
        ],
        executionRequirements: [
          'Gas price < $0.005 por operación',
          'Profit mínimo 10x sobre gas',
          'Ejecución en lotes de 50+ operaciones'
        ]
      }
    ]
  }

  /**
   * Calcular viabilidad de todas las estrategias
   */
  async calculateAllStrategiesViability(capitalUSD: number): Promise<StrategyComparison[]> {
    const comparisons: StrategyComparison[] = []

    for (const strategy of this.strategies) {
      // Crear oportunidad de ejemplo para la estrategia
      const opportunity = this.createOpportunityFromStrategy(strategy, capitalUSD)
      
      // Calcular viabilidad
      const viabilityMetrics = await this.calculator.calculateViability(opportunity, capitalUSD)
      
      // Calcular ROI por blockchain
      const roiByBlockchain = this.calculateROIByBlockchain(strategy, capitalUSD)
      
      // Calcular eficiencia de gas
      const gasEfficiency = this.calculateGasEfficiency(strategy, viabilityMetrics)
      
      // Calcular probabilidad de ejecución
      const executionProbability = this.calculateExecutionProbability(strategy, viabilityMetrics)
      
      // Actualizar score de viabilidad
      strategy.viabilityScore = this.calculateViabilityScore(strategy, viabilityMetrics, capitalUSD)
      strategy.isViable = strategy.viabilityScore >= 70

      comparisons.push({
        strategy,
        viabilityMetrics,
        roiByBlockchain,
        gasEfficiency,
        executionProbability
      })
    }

    return comparisons.sort((a, b) => b.strategy.viabilityScore - a.strategy.viabilityScore)
  }

  /**
   * Crear oportunidad de ejemplo para una estrategia
   */
  private createOpportunityFromStrategy(strategy: StrategyViability, capitalUSD: number) {
    const [minProfit, maxProfit] = strategy.expectedProfitRange
    const expectedProfit = minProfit + (maxProfit - minProfit) * 0.6 // 60% del rango

    return {
      id: strategy.id,
      type: strategy.type as any,
      tokenPath: ['ETH', 'USDC'],
      dexPath: ['DEX_A', 'DEX_B'],
      chainPath: [1, 1],
      amountInUSD: Math.max(strategy.capitalRequired, capitalUSD * 0.1),
      expectedProfitUSD: expectedProfit,
      blockchain: strategy.recommendedBlockchains[0],
      timestamp: Date.now()
    }
  }

  /**
   * Calcular ROI por blockchain para una estrategia
   */
  private calculateROIByBlockchain(strategy: StrategyViability, capitalUSD: number): Map<string, number> {
    const roiMap = new Map<string, number>()
    
    for (const blockchain of strategy.recommendedBlockchains) {
      // ROI base según tipo de estrategia
      let baseROI = 0
      switch (strategy.type) {
        case 'simple':
          baseROI = 2.5
          break
        case 'triangular':
          baseROI = 4.0
          break
        case 'cross-chain':
          baseROI = 6.0
          break
        case 'nft-floor':
          baseROI = 8.0
          break
        case 'mev-liquidation':
          baseROI = 10.0
          break
      }

      // Ajustar por blockchain
      const blockchainMultiplier = this.getBlockchainMultiplier(blockchain)
      const adjustedROI = baseROI * blockchainMultiplier

      // Ajustar por capital
      const capitalMultiplier = capitalUSD < 100 ? 0.5 : capitalUSD < 1000 ? 0.8 : 1.0
      
      roiMap.set(blockchain, adjustedROI * capitalMultiplier)
    }

    return roiMap
  }

  /**
   * Obtener multiplicador por blockchain
   */
  private getBlockchainMultiplier(blockchain: string): number {
    const multipliers: Record<string, number> = {
      'ethereum': 0.6,    // Gas alto
      'arbitrum': 1.2,    // Gas bajo, rápido
      'optimism': 1.1,    // Gas bajo, rápido
      'base': 1.1,        // Gas bajo, rápido
      'polygon': 0.9,     // Gas medio
      'bsc': 0.8,         // Gas bajo, lento
      'avalanche': 0.9,   // Gas medio
      'fantom': 0.7       // Gas bajo, muy lento
    }
    return multipliers[blockchain] || 1.0
  }

  /**
   * Calcular eficiencia de gas
   */
  private calculateGasEfficiency(strategy: StrategyViability, viabilityMetrics: ViabilityMetrics): number {
    if (viabilityMetrics.gasCostUSD === 0) return 100
    
    const gasToProfitRatio = viabilityMetrics.gasCostUSD / viabilityMetrics.grossProfitUSD
    const efficiency = Math.max(0, 100 - (gasToProfitRatio * 100))
    
    return Math.min(100, efficiency)
  }

  /**
   * Calcular probabilidad de ejecución
   */
  private calculateExecutionProbability(strategy: StrategyViability, viabilityMetrics: ViabilityMetrics): number {
    let baseProbability = viabilityMetrics.executionProbability

    // Ajustar por sensibilidad al tiempo
    if (strategy.timeSensitive) {
      baseProbability *= 0.9
    }

    // Ajustar por intensidad de gas
    if (strategy.gasIntensive) {
      baseProbability *= 0.85
    }

    // Ajustar por nivel de riesgo
    switch (strategy.riskLevel) {
      case 'HIGH':
        baseProbability *= 0.7
        break
      case 'MEDIUM':
        baseProbability *= 0.85
        break
      case 'LOW':
        baseProbability *= 1.0
        break
    }

    return Math.min(100, baseProbability * 100)
  }

  /**
   * Calcular score de viabilidad (0-100)
   */
  private calculateViabilityScore(
    strategy: StrategyViability, 
    viabilityMetrics: ViabilityMetrics, 
    capitalUSD: number
  ): number {
    let score = 0

    // Viabilidad básica (40 puntos)
    if (viabilityMetrics.isViable) {
      score += 40
    }

    // ROI atractivo (25 puntos)
    const roiScore = Math.min(25, viabilityMetrics.netProfitPercentage * 2)
    score += roiScore

    // Eficiencia de gas (20 puntos)
    const gasEfficiency = this.calculateGasEfficiency(strategy, viabilityMetrics)
    score += (gasEfficiency * 0.2)

    // Probabilidad de ejecución (15 puntos)
    const executionProb = this.calculateExecutionProbability(strategy, viabilityMetrics)
    score += (executionProb * 0.15)

    // Ajustes por capital
    if (capitalUSD < strategy.capitalRequired) {
      score *= 0.5 // Penalizar si no hay capital suficiente
    }

    return Math.min(100, Math.max(0, score))
  }

  /**
   * Generar reporte de viabilidad de estrategias
   */
  async generateStrategyViabilityReport(capitalUSD: number): Promise<{
    summary: {
      totalStrategies: number
      viableStrategies: number
      averageViabilityScore: number
      bestStrategy: string
      worstStrategy: string
    }
    recommendations: string[]
    blockchainAnalysis: Array<{
      blockchain: string
      bestStrategy: string
      avgROI: number
      gasEfficiency: number
    }>
    capitalRecommendations: Array<{
      capitalRange: string
      recommendedStrategies: string[]
      expectedROI: number
    }>
  }> {
    const comparisons = await this.calculateAllStrategiesViability(capitalUSD)
    
    const viableStrategies = comparisons.filter(c => c.strategy.isViable)
    const averageScore = comparisons.reduce((sum, c) => sum + c.strategy.viabilityScore, 0) / comparisons.length
    
    const bestStrategy = comparisons[0]?.strategy.name || 'N/A'
    const worstStrategy = comparisons[comparisons.length - 1]?.strategy.name || 'N/A'

    // Análisis por blockchain
    const blockchainAnalysis = this.analyzeBlockchainPerformance(comparisons)
    
    // Recomendaciones por capital
    const capitalRecommendations = this.generateCapitalRecommendations()

    const recommendations = [
      `Priorizar ${viableStrategies.length} estrategias viables de ${comparisons.length} total`,
      `Mejor estrategia: ${bestStrategy} (Score: ${comparisons[0]?.strategy.viabilityScore.toFixed(1)})`,
      `Para capital $${capitalUSD}: ${viableStrategies.length > 0 ? 'Hay oportunidades viables' : 'Considerar aumentar capital'}`,
      `Blockchain recomendada: ${blockchainAnalysis[0]?.blockchain || 'N/A'}`
    ]

    return {
      summary: {
        totalStrategies: comparisons.length,
        viableStrategies: viableStrategies.length,
        averageViabilityScore: averageScore,
        bestStrategy,
        worstStrategy
      },
      recommendations,
      blockchainAnalysis,
      capitalRecommendations
    }
  }

  /**
   * Analizar rendimiento por blockchain
   */
  private analyzeBlockchainPerformance(comparisons: StrategyComparison[]) {
    const blockchainStats = new Map<string, {
      strategies: string[]
      totalROI: number
      totalGasEfficiency: number
      count: number
    }>()

    for (const comparison of comparisons) {
      for (const [blockchain, roi] of comparison.roiByBlockchain) {
        if (!blockchainStats.has(blockchain)) {
          blockchainStats.set(blockchain, {
            strategies: [],
            totalROI: 0,
            totalGasEfficiency: 0,
            count: 0
          })
        }

        const stats = blockchainStats.get(blockchain)!
        stats.strategies.push(comparison.strategy.name)
        stats.totalROI += roi
        stats.totalGasEfficiency += comparison.gasEfficiency
        stats.count += 1
      }
    }

    return Array.from(blockchainStats.entries())
      .map(([blockchain, stats]) => ({
        blockchain,
        bestStrategy: stats.strategies[0] || 'N/A',
        avgROI: stats.totalROI / stats.count,
        gasEfficiency: stats.totalGasEfficiency / stats.count
      }))
      .sort((a, b) => b.avgROI - a.avgROI)
  }

  /**
   * Generar recomendaciones por capital
   */
  private generateCapitalRecommendations() {
    return [
      {
        capitalRange: '$1 - $100',
        recommendedStrategies: ['Capital $1 Arbitraje', 'Capital $1 MEV'],
        expectedROI: 0.5
      },
      {
        capitalRange: '$100 - $1,000',
        recommendedStrategies: ['Arbitraje Simple DEX', 'Arbitraje Triangular'],
        expectedROI: 2.5
      },
      {
        capitalRange: '$1,000 - $5,000',
        recommendedStrategies: ['Arbitraje Cross-Chain', 'NFT Floor Arbitraje'],
        expectedROI: 5.0
      },
      {
        capitalRange: '$5,000+',
        recommendedStrategies: ['MEV Liquidation Backrun', 'Todas las estrategias'],
        expectedROI: 8.0
      }
    ]
  }

  /**
   * Obtener estrategias por nivel de riesgo
   */
  getStrategiesByRiskLevel(riskLevel: 'LOW' | 'MEDIUM' | 'HIGH'): StrategyViability[] {
    return this.strategies.filter(s => s.riskLevel === riskLevel)
  }

  /**
   * Obtener estrategias por capital mínimo
   */
  getStrategiesByCapital(capitalUSD: number): StrategyViability[] {
    return this.strategies.filter(s => s.capitalRequired <= capitalUSD)
  }

  /**
   * Obtener estrategias por blockchain
   */
  getStrategiesByBlockchain(blockchain: string): StrategyViability[] {
    return this.strategies.filter(s => s.recommendedBlockchains.includes(blockchain))
  }
}
