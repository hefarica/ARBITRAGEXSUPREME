import { 
  NotificationConfig, 
  NotificationEvent, 
  NotificationHistory, 
  TelegramConfig, 
  DiscordConfig,
  NotificationChannel
} from '../components/notifications/types'

/**
 * Servicio principal para gestionar notificaciones en tiempo real
 * Soporta múltiples canales: Telegram, Discord, Email, Webhook, SMS
 */
export class NotificationService {
  private config: NotificationConfig | null = null
  private rateLimiters: Map<string, RateLimiter> = new Map()
  private retryQueues: Map<string, RetryQueue> = new Map()

  /**
   * Inicializar el servicio con configuración
   */
  async initialize(config: NotificationConfig): Promise<void> {
    this.config = config
    
    // Configurar rate limiters para cada canal
    for (const channel of config.channels) {
      if (channel.enabled) {
        this.rateLimiters.set(channel.id, new RateLimiter(config.rateLimiting))
        this.retryQueues.set(channel.id, new RetryQueue(channel))
      }
    }
  }

  /**
   * Actualizar configuración
   */
  async updateConfig(config: NotificationConfig): Promise<void> {
    this.config = config
    await this.initialize(config)
  }

  /**
   * Enviar notificación
   */
  async sendNotification(event: NotificationEvent, data: any): Promise<NotificationHistory> {
    if (!this.config || !event.enabled) {
      throw new Error('Notification service not initialized or event disabled')
    }

    const notificationId = crypto.randomUUID()
    const timestamp = new Date()

    // Crear entrada de historial
    const historyEntry: NotificationHistory = {
      id: notificationId,
      eventType: event.type,
      channel: '', // Se actualizará por canal
      status: 'pending',
      message: '',
      metadata: data,
      retryCount: 0,
      createdAt: timestamp
    }

    // Aplicar filtros
    if (!this.shouldPaperPlaneNotification(event, data)) {
      historyEntry.status = 'cancelled'
      return historyEntry
    }

    // Construir mensaje
    const message = await this.buildMessage(event, data)
    historyEntry.message = message

    // Enviar a todos los canales habilitados
    const sendPromises = this.config.channels
      .filter(channel => channel.enabled)
      .map(async (channel) => {
        const channelHistory = { ...historyEntry, channel: channel.type }
        
        try {
          // Verificar rate limit
          if (!this.rateLimiters.get(channel.id)?.canPaperPlane()) {
            channelHistory.status = 'failed'
            channelHistory.failureReason = 'Rate limit exceeded'
            return channelHistory
          }

          // Enviar según el tipo de canal
          await this.sendToChannel(channel, message, data)
          
          channelHistory.status = 'sent'
          channelHistory.sentAt = new Date()
          channelHistory.deliveredAt = new Date()
          
        } catch (error) {
          channelHistory.status = 'failed'
          channelHistory.failureReason = error instanceof Error ? error.message : 'Unknown error'
          
          // Agregar a cola de reintentos
          this.retryQueues.get(channel.id)?.add(channelHistory)
        }

        return channelHistory
      })

    const results = await Promise.allSettled(sendPromises)
    
    // Retornar el primer resultado exitoso o el primer error
    const successfulResult = results.find(r => r.status === 'fulfilled' && r.value.status === 'sent')
    if (successfulResult && successfulResult.status === 'fulfilled') {
      return successfulResult.value
    }

    const firstResult = results[0]
    if (firstResult?.status === 'fulfilled') {
      return firstResult.value
    }

    throw new Error('All notification channels failed')
  }

  /**
   * Enviar notificación de prueba
   */
  async sendTestNotification(channelId: string, message: string): Promise<void> {
    if (!this.config) {
      throw new Error('Notification service not initialized')
    }

    const channel = this.config.channels.find(ch => ch.id === channelId)
    if (!channel) {
      throw new Error(`Channel ${channelId} not found`)
    }

    await this.sendToChannel(channel, message, { test: true })
  }

  /**
   * Enviar a un canal específico
   */
  private async sendToChannel(channel: NotificationChannel, message: string, data: any): Promise<void> {
    switch (channel.type) {
      case 'telegram':
        await this.sendToTelegram(channel.config as TelegramConfig, message, data)
        break
      case 'discord':
        await this.sendToDiscord(channel.config as DiscordConfig, message, data)
        break
      case 'email':
        await this.sendToEmail(channel.config as any, message, data)
        break
      case 'webhook':
        await this.sendToWebhook(channel.config as any, message, data)
        break
      case 'sms':
        await this.sendToSMS(channel.config as any, message, data)
        break
      default:
        throw new Error(`Unsupported channel type: ${channel.type}`)
    }
  }

  /**
   * Enviar a Telegram
   */
  private async sendToTelegram(config: TelegramConfig, message: string, data: any): Promise<void> {
    const url = `https://api.telegram.org/bot${config.botToken}/sendMessage`
    
    const payload = {
      chat_id: config.chatId,
      text: message,
      parse_mode: config.parseMode || 'HTML',
      disable_web_page_preview: config.disableWebPagePreview || false,
      disable_notification: config.disableNotification || false,
      reply_markup: config.customKeyboard || undefined,
      message_thread_id: config.threadId || undefined
    }

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ description: 'Unknown error' }))
      throw new Error(`Telegram API error: ${errorData.description || response.statusText}`)
    }
  }

  /**
   * Enviar a Discord
   */
  private async sendToDiscord(config: DiscordConfig, message: string, data: any): Promise<void> {
    const payload: any = {
      username: config.username || 'ArbitrageX Pro',
      avatar_url: config.avatarUrl || undefined,
      tts: config.tts || false
    }

    if (config.embeds) {
      // Crear embed enriquecido
      payload.embeds = [this.createDiscordEmbed(message, data)]
    } else {
      payload.content = message
    }

    if (config.threadId) {
      payload.thread_id = config.threadId
    }

    const response = await fetch(config.webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    })

    if (!response.ok) {
      const errorText = await response.text().catch(() => 'Unknown error')
      throw new Error(`Discord webhook error: ${errorText}`)
    }
  }

  /**
   * Crear embed de Discord
   */
  private createDiscordEmbed(message: string, data: any): any {
    const embed: any = {
      title: this.getEmbedTitle(data),
      description: message,
      color: this.getEmbedColor(data),
      timestamp: new Date().toISOString(),
      footer: {
        text: 'ArbitrageX Pro 2025'
      }
    }

    // Agregar campos específicos según el tipo de evento
    if (data.opportunity) {
      embed.fields = [
        {
          name: '💰 Profit Estimado',
          value: `$${data.opportunity.profit?.toFixed(2) || 'N/A'}`,
          inline: true
        },
        {
          name: '📈 ROI',
          value: `${data.opportunity.profitPercentage?.toFixed(2) || 'N/A'}%`,
          inline: true
        },
        {
          name: '⚡ Estrategia',
          value: data.opportunity.strategy || 'N/A',
          inline: true
        }
      ]
    }

    if (data.trade) {
      embed.fields = [
        {
          name: '💱 Par',
          value: data.trade.tokenPair || 'N/A',
          inline: true
        },
        {
          name: '💰 Cantidad',
          value: `$${data.trade.amount?.toFixed(2) || 'N/A'}`,
          inline: true
        },
        {
          name: '📊 Estado',
          value: data.trade.status || 'N/A',
          inline: true
        }
      ]
    }

    return embed
  }

  /**
   * Obtener título para embed
   */
  private getEmbedTitle(data: any): string {
    if (data.opportunity) return '🚀 Nueva Oportunidad de Arbitraje'
    if (data.trade) return '✅ Trade Ejecutado'
    if (data.alert) return '⚠️ Alerta de Seguridad'
    return '📢 Notificación del Sistema'
  }

  /**
   * Obtener color para embed
   */
  private getEmbedColor(data: any): number {
    if (data.opportunity) return 0x00ff88 // Verde
    if (data.trade) return 0x0099ff // Azul
    if (data.alert) return 0xff4444 // Rojo
    return 0x888888 // Gris
  }

  /**
   * Enviar por email usando configuración SMTP
   */
  private async sendToEmail(config: any, message: string, data: any): Promise<void> {
    // Implementar integración con servicio de email (PaperPlaneGridFour, SES, etc.)
    console.log('Email notification not implemented yet')
  }

  /**
   * Enviar por webhook usando URL configurada
   */
  private async sendToWebhook(config: any, message: string, data: any): Promise<void> {
    // Implementar webhook personalizado
    console.log('Webhook notification not implemented yet')
  }

  /**
   * Enviar SMS usando proveedor configurado
   */
  private async sendToSMS(config: any, message: string, data: any): Promise<void> {
    // Implementar integración con Twilio, AWS SNS, etc.
    console.log('SMS notification not implemented yet')
  }

  /**
   * Construir mensaje de notificación
   */
  private async buildMessage(event: NotificationEvent, data: any): Promise<string> {
    // Usar template personalizado si existe
    if (event.template?.body) {
      return this.processTemplate(event.template.body, data)
    }

    // Generar mensaje por defecto según el tipo de evento
    switch (event.type) {
      case 'arbitrage_opportunity':
        return this.buildArbitrageOpportunityMessage(data)
      case 'trade_executed':
        return this.buildTradeExecutedMessage(data)
      case 'security_alert':
        return this.buildSecurityAlertMessage(data)
      case 'price_alert':
        return this.buildPriceAlertMessage(data)
      default:
        return `📢 Evento del sistema: ${event.type}\n\nTimestamp: ${new Date().toLocaleString()}`
    }
  }

  /**
   * Construir mensaje de oportunidad de arbitraje
   */
  private buildArbitrageOpportunityMessage(data: any): string {
    const opportunity = data.opportunity
    return `🚀 <b>Nueva Oportunidad de Arbitraje</b>\n\n` +
      `💰 <b>Profit Estimado:</b> $${opportunity.profit?.toFixed(2) || 'N/A'}\n` +
      `📈 <b>ROI:</b> ${opportunity.profitPercentage?.toFixed(2) || 'N/A'}%\n` +
      `💱 <b>Par:</b> ${opportunity.tokenPair || 'N/A'}\n` +
      `⚡ <b>Estrategia:</b> ${opportunity.strategy || 'N/A'}\n` +
      `🔗 <b>Blockchain:</b> ${opportunity.blockchain || 'N/A'}\n` +
      `⏰ <b>Timestamp:</b> ${new Date().toLocaleString()}\n\n` +
      `<i>Oportunidad detectada y lista para ejecución</i>`
  }

  /**
   * Construir mensaje de trade ejecutado
   */
  private buildTradeExecutedMessage(data: any): string {
    const trade = data.trade
    return `✅ <b>Trade Ejecutado</b>\n\n` +
      `💱 <b>Par:</b> ${trade.tokenPair || 'N/A'}\n` +
      `💰 <b>Cantidad:</b> $${trade.amount?.toFixed(2) || 'N/A'}\n` +
      `📊 <b>Precio:</b> $${trade.price?.toFixed(6) || 'N/A'}\n` +
      `💸 <b>Profit:</b> $${trade.profit?.toFixed(2) || 'N/A'}\n` +
      `⛽ <b>Gas:</b> ${trade.gas || 'N/A'}\n` +
      `📋 <b>Estado:</b> ${trade.status || 'N/A'}\n` +
      `🔗 <b>Hash:</b> ${trade.hash || 'N/A'}\n` +
      `⏰ <b>Timestamp:</b> ${new Date().toLocaleString()}`
  }

  /**
   * Construir mensaje de alerta de seguridad
   */
  private buildSecurityAlertMessage(data: any): string {
    const alert = data.alert
    return `⚠️ <b>Alerta de Seguridad</b>\n\n` +
      `🚨 <b>Severidad:</b> ${alert.severity?.toUpperCase() || 'N/A'}\n` +
      `📂 <b>Categoría:</b> ${alert.category || 'N/A'}\n` +
      `📝 <b>Descripción:</b> ${alert.description || 'N/A'}\n` +
      `⏰ <b>Timestamp:</b> ${new Date().toLocaleString()}\n\n` +
      `<i>Revisa inmediatamente el sistema de seguridad</i>`
  }

  /**
   * Construir mensaje de alerta de precio
   */
  private buildPriceAlertMessage(data: any): string {
    const alert = data.alert
    return `📈 <b>Alerta de Precio</b>\n\n` +
      `🪙 <b>Token:</b> ${alert.token || 'N/A'}\n` +
      `💰 <b>Precio Actual:</b> $${alert.price?.toFixed(6) || 'N/A'}\n` +
      `📊 <b>Cambio 24h:</b> ${alert.changePercentage?.toFixed(2) || 'N/A'}%\n` +
      `🏪 <b>Exchange:</b> ${alert.exchange || 'N/A'}\n` +
      `⏰ <b>Timestamp:</b> ${new Date().toLocaleString()}`
  }

  /**
   * Procesar template con variables
   */
  private processTemplate(template: string, data: any): string {
    let processed = template
    
    // Reemplazar variables básicas
    processed = processed.replace(/\{\{timestamp\}\}/g, new Date().toLocaleString())
    processed = processed.replace(/\{\{date\}\}/g, new Date().toDateString())
    processed = processed.replace(/\{\{time\}\}/g, new Date().toTimeString())
    
    // Reemplazar variables de datos
    const replaceDataVariables = (obj: any, prefix = '') => {
      for (const [key, value] of Object.entries(obj)) {
        if (typeof value === 'object' && value !== null) {
          replaceDataVariables(value, `${prefix}${key}.`)
        } else {
          const variable = `{{${prefix}${key}}}`
          processed = processed.replace(new RegExp(variable.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), String(value))
        }
      }
    }
    
    replaceDataVariables(data)
    
    return processed
  }

  /**
   * Verificar si se debe enviar la notificación
   */
  private shouldPaperPlaneNotification(event: NotificationEvent, data: any): boolean {
    if (!this.config) return false

    // Aplicar filtros configurados
    for (const filter of this.config.filters) {
      if (!filter.enabled) continue

      const matches = filter.conditions.every(condition => {
        return this.evaluateCondition(condition, data)
      })

      if (matches) {
        return filter.action === 'allow'
      }
    }

    return true
  }

  /**
   * Evaluar condición de filtro
   */
  private evaluateCondition(condition: any, data: any): boolean {
    const value = this.getValueFromPath(data, condition.field)
    
    switch (condition.operator) {
      case 'equals': return value === condition.value
      case 'not_equals': return value !== condition.value
      case 'greater_than': return Number(value) > Number(condition.value)
      case 'less_than': return Number(value) < Number(condition.value)
      case 'greater_equal': return Number(value) >= Number(condition.value)
      case 'less_equal': return Number(value) <= Number(condition.value)
      case 'contains': return String(value).includes(String(condition.value))
      case 'not_contains': return !String(value).includes(String(condition.value))
      case 'in': return Array.isArray(condition.value) && condition.value.includes(value)
      case 'not_in': return Array.isArray(condition.value) && !condition.value.includes(value)
      default: return false
    }
  }

  /**
   * Obtener valor desde un path de objeto
   */
  private getValueFromPath(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj)
  }

  /**
   * Limpiar recursos
   */
  cleanup(): void {
    this.rateLimiters.clear()
    this.retryQueues.clear()
  }
}

/**
 * Rate limiter para controlar el envío de notificaciones
 */
class RateLimiter {
  private tokens: number
  private lastRefill: number
  private config: any

  constructor(config: any) {
    this.config = config
    this.tokens = config.maxPerMinute
    this.lastRefill = Date.now()
  }

  canPaperPlane(): boolean {
    this.refillTokens()
    
    if (this.tokens > 0) {
      this.tokens--
      return true
    }
    
    return false
  }

  private refillTokens(): void {
    const now = Date.now()
    const timePassed = now - this.lastRefill
    const tokensToAdd = Math.floor(timePassed / 60000) * this.config.maxPerMinute
    
    if (tokensToAdd > 0) {
      this.tokens = Math.min(this.config.maxPerMinute, this.tokens + tokensToAdd)
      this.lastRefill = now
    }
  }
}

/**
 * Cola de reintentos para notificaciones fallidas
 */
class RetryQueue {
  private queue: NotificationHistory[] = []
  private channel: NotificationChannel

  constructor(channel: NotificationChannel) {
    this.channel = channel
  }

  add(notification: NotificationHistory): void {
    this.queue.push(notification)
    this.scheduleRetry(notification)
  }

  private scheduleRetry(notification: NotificationHistory): void {
    const delay = Math.min(1000 * Math.pow(2, notification.retryCount), 60000) // Exponential backoff, max 1 minute
    
    setTimeout(async () => {
      if (notification.retryCount < 3) { // Max 3 retries
        try {
          notification.retryCount++
          // Retry logic would go here
          notification.status = 'sent'
        } catch (error) {
          this.scheduleRetry(notification)
        }
      } else {
        notification.status = 'failed'
        notification.failureReason = 'Max retries exceeded'
      }
    }, delay)
  }
}