import { credentialsManager } from './CredentialsManager'

export interface PriceData {
  token: string
  price: number
  timestamp: number
  source: string
  blockchain: string
}

export interface ArbitrageOpportunity {
  id: string
  tokenA: string
  tokenB: string
  dexA: string
  dexB: string
  blockchain: string
  priceA: number
  priceB: number
  profitPercentage: number
  estimatedProfit: number
  gasEstimate: number
  risk: 'low' | 'medium' | 'high'
  timestamp: number
}

export interface BlockchainConnection {
  blockchain: string
  connected: boolean
  latency: number
  lastBlock: number
  error?: string
}

export class RealDeFiService {
  private connections: Map<string, BlockchainConnection> = new Map()
  private priceCache: Map<string, PriceData> = new Map()
  private opportunities: ArbitrageOpportunity[] = []

  constructor() {
    this.initializeConnections()
  }

  /**
   * Inicializar conexiones con blockchains
   */
  private async initializeConnections(): Promise<void> {
    const blockchains = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism']
    
    for (const blockchain of blockchains) {
      await this.testConnection(blockchain)
    }
  }

  /**
   * Probar conexión con una blockchain
   */
  private async testConnection(blockchain: string): Promise<void> {
    try {
      const rpcUrl = await this.getRPCUrl(blockchain)
      if (!rpcUrl) {
        this.connections.set(blockchain, {
          blockchain,
          connected: false,
          latency: 0,
          lastBlock: 0,
          error: 'RPC URL no configurada'
        })
        return
      }

      const startTime = Date.now()
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'eth_blockNumber',
          params: [],
          id: 1
        })
      })

      const latency = Date.now() - startTime

      if (response.ok) {
        const data = await response.json()
        this.connections.set(blockchain, {
          blockchain,
          connected: true,
          latency,
          lastBlock: parseInt(data.result, 16),
          error: undefined
        })
      } else {
        this.connections.set(blockchain, {
          blockchain,
          connected: false,
          latency: 0,
          lastBlock: 0,
          error: `HTTP ${response.status}: ${response.statusText}`
        })
      }
    } catch (error) {
      this.connections.set(blockchain, {
        blockchain,
        connected: false,
        latency: 0,
        lastBlock: 0,
        error: error.message
      })
    }
  }

  /**
   * Obtener URL RPC para una blockchain
   */
  private async getRPCUrl(blockchain: string): Promise<string | null> {
    const credential = await credentialsManager.getCredential(`${blockchain}_rpc`)
    return credential?.value || null
  }

  /**
   * Obtener precios reales de tokens
   */
  async getTokenPrices(tokens: string[]): Promise<PriceData[]> {
    const prices: PriceData[] = []

    for (const token of tokens) {
      try {
        // Intentar obtener precio de CoinGecko
        const coingeckoPrice = await this.getCoinGeckoPrice(token)
        if (coingeckoPrice) {
          prices.push(coingeckoPrice)
          continue
        }

        // Intentar obtener precio de Binance
        const binancePrice = await this.getBinancePrice(token)
        if (binancePrice) {
          prices.push(binancePrice)
          continue
        }

        // Si no se puede obtener precio real, usar precio simulado
        const simulatedPrice = this.getSimulatedPrice(token)
        prices.push(simulatedPrice)
      } catch (error) {
        console.error(`Error getting price for ${token}:`, error)
        // Fallback a precio simulado
        const simulatedPrice = this.getSimulatedPrice(token)
        prices.push(simulatedPrice)
      }
    }

    return prices
  }

  /**
   * Obtener precio de CoinGecko
   */
  private async getCoinGeckoPrice(token: string): Promise<PriceData | null> {
    try {
      const credential = await credentialsManager.getCredential('coingecko_api_key')
      if (!credential?.value) return null

      const response = await fetch(
        `https://api.coingecko.com/api/v3/simple/price?ids=${token}&vs_currencies=usd`,
        {
          headers: {
            'X-CG-Pro-API-Key': credential.value
          }
        }
      )

      if (response.ok) {
        const data = await response.json()
        const price = data[token]?.usd
        if (price) {
          return {
            token,
            price,
            timestamp: Date.now(),
            source: 'coingecko',
            blockchain: 'multi'
          }
        }
      }
    } catch (error) {
      console.error('Error fetching CoinGecko price:', error)
    }

    return null
  }

  /**
   * Obtener precio de Binance
   */
  private async getBinancePrice(token: string): Promise<PriceData | null> {
    try {
      const credential = await credentialsManager.getCredential('binance_api_key')
      if (!credential?.value) return null

      // Convertir token a par de trading (ej: ETH -> ETHUSDT)
      const tradingPair = `${token}USDT`
      
      const response = await fetch(
        `https://api.binance.com/api/v3/ticker/price?symbol=${tradingPair}`
      )

      if (response.ok) {
        const data = await response.json()
        const price = parseFloat(data.price)
        if (price > 0) {
          return {
            token,
            price,
            timestamp: Date.now(),
            source: 'binance',
            blockchain: 'multi'
          }
        }
      }
    } catch (error) {
      console.error('Error fetching Binance price:', error)
    }

    return null
  }

  /**
   * Obtener precio simulado (fallback)
   */
  private getSimulatedPrice(token: string): PriceData {
    // Generar precio simulado basado en el token
    const basePrice = await this.getCoinGeckoPrice(token)
    const variation = await this.calculateMarketVariation(token) // ±5% variación
    
    return {
      token,
      price: basePrice * (1 + variation),
      timestamp: Date.now(),
      source: 'simulated',
      blockchain: 'ethereum'
    }
  }

  /**
   * Buscar oportunidades de arbitraje reales
   */
  async findArbitrageOpportunities(): Promise<ArbitrageOpportunity[]> {
    const opportunities: ArbitrageOpportunity[] = []

    try {
      // Obtener precios de diferentes fuentes
      const tokens = ['ethereum', 'bitcoin', 'polygon', 'binancecoin']
      const prices = await this.getTokenPrices(tokens)

      // Buscar diferencias de precios entre fuentes
      for (let i = 0; i < prices.length; i++) {
        for (let j = i + 1; j < prices.length; j++) {
          const priceA = prices[i]
          const priceB = prices[j]

          if (priceA.token === priceB.token && priceA.source !== priceB.source) {
            const priceDiff = Math.abs(priceA.price - priceB.price)
            const avgPrice = (priceA.price + priceB.price) / 2
            const profitPercentage = (priceDiff / avgPrice) * 100

            // Solo considerar oportunidades con profit > 0.5%
            if (profitPercentage > 0.5) {
              const opportunity: ArbitrageOpportunity = {
                id: await this.generateOpportunityId(),
                tokenA: priceA.token,
                tokenB: priceB.token,
                dexA: priceA.source,
                dexB: priceB.source,
                blockchain: priceA.blockchain,
                priceA: priceA.price,
                priceB: priceB.price,
                profitPercentage,
                estimatedProfit: priceDiff,
                gasEstimate: this.estimateGas(priceA.blockchain),
                risk: this.calculateRisk(profitPercentage),
                timestamp: Date.now()
              }

              opportunities.push(opportunity)
            }
          }
        }
      }

      // Ordenar por profit percentage
      opportunities.sort((a, b) => b.profitPercentage - a.profitPercentage)
      
      this.opportunities = opportunities.slice(0, 20) // Limitar a top 20
    } catch (error) {
      console.error('Error finding arbitrage opportunities:', error)
    }

    return this.opportunities
  }

  /**
   * Estimar gas para una blockchain
   */
  private estimateGas(blockchain: string): number {
    const gasEstimates = {
      ethereum: 21000,
      polygon: 21000,
      bsc: 21000,
      arbitrum: 21000,
      optimism: 21000
    }

    return gasEstimates[blockchain as keyof typeof gasEstimates] || 21000
  }

  /**
   * Calcular riesgo basado en profit percentage
   */
  private calculateRisk(profitPercentage: number): 'low' | 'medium' | 'high' {
    if (profitPercentage < 1) return 'low'
    if (profitPercentage < 3) return 'medium'
    return 'high'
  }

  /**
   * Obtener estado de conexiones
   */
  getConnectionStatus(): BlockchainConnection[] {
    return Array.from(this.connections.values())
  }

  /**
   * Verificar si el sistema está conectado a datos reales
   */
  async isConnectedToRealData(): Promise<boolean> {
    const connections = this.getConnectionStatus()
    const connectedCount = connections.filter(c => c.connected).length
    
    // Requerir al menos 2 conexiones activas para considerar datos reales
    return connectedCount >= 2
  }

  /**
   * Obtener estadísticas del sistema
   */
  getSystemStats(): {
    totalConnections: number
    activeConnections: number
    averageLatency: number
    lastOpportunities: number
    dataSource: 'real' | 'mixed' | 'simulated'
  } {
    const connections = this.getConnectionStatus()
    const activeConnections = connections.filter(c => c.connected).length
    const averageLatency = connections
      .filter(c => c.connected)
      .reduce((sum, c) => sum + c.latency, 0) / activeConnections || 0

    let dataSource: 'real' | 'mixed' | 'simulated' = 'simulated'
    if (activeConnections >= 3) {
      dataSource = 'real'
    } else if (activeConnections >= 1) {
      dataSource = 'mixed'
    }

    return {
      totalConnections: connections.length,
      activeConnections,
      averageLatency,
      lastOpportunities: this.opportunities.length,
      dataSource
    }
  }

  /**
   * Ejecutar una estrategia de arbitraje
   */
  async executeArbitrageStrategy(
    opportunity: ArbitrageOpportunity,
    amount: number
  ): Promise<{
    success: boolean
    transactionHash?: string
    actualProfit?: number
    gasUsed?: number
    error?: string
  }> {
    try {
      // Verificar que tenemos conexiones reales
      const isRealData = await this.isConnectedToRealData()
      if (!isRealData) {
        return {
          success: false,
          error: 'Sistema no conectado a datos reales. No se puede ejecutar arbitraje.'
        }
      }

      // Simular ejecución de transacción
      const gasUsed = this.estimateGas(opportunity.blockchain)
      const gasCost = gasUsed * 0.000000001 // Precio estimado del gas
      const actualProfit = opportunity.estimatedProfit - gasCost

      if (actualProfit <= 0) {
        return {
          success: false,
          error: 'Profit estimado no cubre costos de gas'
        }
      }

      // Simular hash de transacción
      const transactionHash = await this.executeBlockchainTransaction(params)

      return {
        success: true,
        transactionHash,
        actualProfit,
        gasUsed
      }
    } catch (error) {
      return {
        success: false,
        error: error.message
      }
    }
  }
}

// Instancia singleton
export const realDeFiService = new RealDeFiService() 