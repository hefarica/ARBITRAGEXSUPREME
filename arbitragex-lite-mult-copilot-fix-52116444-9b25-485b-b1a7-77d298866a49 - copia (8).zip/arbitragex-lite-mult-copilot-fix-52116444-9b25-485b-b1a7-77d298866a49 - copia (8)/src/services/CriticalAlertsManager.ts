/**
 * CriticalAlertsManager.ts
 * Sistema de alertas críticas para ArbitrageX Pro 2025
 * RESUELVE: Problema #21 - Falta de alertas para producción
 */

import { EventEmitter } from 'events';
import { SystemMetrics, PerformanceAlert } from './PerformanceMetricsService';

export type AlertSeverity = 'low' | 'medium' | 'high' | 'critical';

export interface AlertRule {
  id: string;
  name: string;
  description: string;
  condition: (metrics: SystemMetrics) => boolean;
  severity: AlertSeverity;
  message: string;
  actions: AlertAction[];
  cooldownMs: number; // Tiempo mínimo entre alertas del mismo tipo
  enabled: boolean;
}

export type AlertAction = 
  | 'emergency_stop'
  | 'notify_admin'
  | 'notify_team'
  | 'log_incident'
  | 'reduce_volume'
  | 'switch_rpc_providers'
  | 'restart_service'
  | 'backup_data';

export interface Alert {
  id: string;
  ruleId: string;
  severity: AlertSeverity;
  message: string;
  timestamp: number;
  metrics: SystemMetrics;
  resolved: boolean;
  resolvedAt?: number;
  actions: AlertAction[];
}

export interface AlertChannel {
  name: string;
  type: 'email' | 'discord' | 'slack' | 'webhook' | 'sms' | 'console';
  enabled: boolean;
  config: any;
  severityFilter: AlertSeverity[];
}

export class CriticalAlertsManager extends EventEmitter {
  private static instance: CriticalAlertsManager;
  private alertRules: Map<string, AlertRule> = new Map();
  private alertChannels: Map<string, AlertChannel> = new Map();
  private alertHistory: Alert[] = [];
  private lastAlertTime: Map<string, number> = new Map();
  private emergencyStopTriggered: boolean = false;

  private constructor() {
    super();
    this.initializeCriticalRules();
    this.initializeAlertChannels();
  }

  static getInstance(): CriticalAlertsManager {
    if (!CriticalAlertsManager.instance) {
      CriticalAlertsManager.instance = new CriticalAlertsManager();
    }
    return CriticalAlertsManager.instance;
  }

  /**
   * Inicializar reglas críticas de alertas
   */
  private initializeCriticalRules(): void {
    console.log('🚨 Inicializando reglas de alertas críticas...');

    // 1. ALERTA CRÍTICA: Pérdidas financieras significativas
    this.addAlertRule({
      id: 'financial_loss_critical',
      name: 'Pérdida Financiera Crítica',
      description: 'Pérdida diaria superior a $1000',
      condition: (metrics: SystemMetrics) => 
        metrics.financial.dailyProfit < -1000,
      severity: 'critical',
      message: '🚨 PÉRDIDA FINANCIERA CRÍTICA: Pérdida diaria > $1000',
      actions: ['emergency_stop', 'notify_admin', 'log_incident', 'backup_data'],
      cooldownMs: 300000, // 5 minutos
      enabled: true
    });

    // 2. ALERTA CRÍTICA: Alta tasa de fallos de ejecución
    this.addAlertRule({
      id: 'execution_failure_rate',
      name: 'Alta Tasa de Fallos',
      description: 'Tasa de errores superior al 15%',
      condition: (metrics: SystemMetrics) => 
        metrics.performance.errorRate > 15,
      severity: 'critical',
      message: '⚠️ ALTA TASA DE FALLOS: Error rate > 15%',
      actions: ['emergency_stop', 'notify_team', 'log_incident'],
      cooldownMs: 180000, // 3 minutos
      enabled: true
    });

    // 3. ALERTA CRÍTICA: Múltiples conexiones blockchain caídas
    this.addAlertRule({
      id: 'blockchain_connectivity_critical',
      name: 'Conectividad Blockchain Crítica',
      description: 'Más del 50% de conexiones RPC caídas',
      condition: (metrics: SystemMetrics) => {
        const totalConnections = metrics.health.rpcConnections.length;
        const downConnections = metrics.health.rpcConnections.filter(
          conn => conn.status === 'down'
        ).length;
        return totalConnections > 0 && (downConnections / totalConnections) > 0.5;
      },
      severity: 'critical',
      message: '🔌 CONECTIVIDAD BLOCKCHAIN CRÍTICA: >50% conexiones caídas',
      actions: ['emergency_stop', 'switch_rpc_providers', 'notify_admin'],
      cooldownMs: 120000, // 2 minutos
      enabled: true
    });

    // 4. ALERTA ALTA: Sistema sobrecargado
    this.addAlertRule({
      id: 'system_overload',
      name: 'Sistema Sobrecargado',
      description: 'CPU > 90% o RAM > 95%',
      condition: (metrics: SystemMetrics) => 
        metrics.performance.cpuUsage > 90 || 
        metrics.performance.memoryUsage.percentage > 95,
      severity: 'high',
      message: '🔥 SISTEMA SOBRECARGADO: Recursos críticos',
      actions: ['reduce_volume', 'notify_team', 'log_incident'],
      cooldownMs: 300000, // 5 minutos
      enabled: true
    });

    // 5. ALERTA ALTA: Tiempo de respuesta elevado
    this.addAlertRule({
      id: 'high_response_time',
      name: 'Tiempo de Respuesta Elevado',
      description: 'Tiempo de respuesta promedio > 5 segundos',
      condition: (metrics: SystemMetrics) => 
        metrics.performance.avgResponseTime > 5000,
      severity: 'high',
      message: '⏱️ TIEMPO DE RESPUESTA ELEVADO: >5 segundos',
      actions: ['reduce_volume', 'notify_team'],
      cooldownMs: 600000, // 10 minutos
      enabled: true
    });

    // 6. ALERTA MEDIA: Base de datos degradada
    this.addAlertRule({
      id: 'database_degraded',
      name: 'Base de Datos Degradada',
      description: 'Estado de base de datos degradado',
      condition: (metrics: SystemMetrics) => 
        metrics.health.databaseStatus === 'degraded',
      severity: 'medium',
      message: '🗄️ BASE DE DATOS DEGRADADA: Performance reducido',
      actions: ['notify_team', 'log_incident'],
      cooldownMs: 900000, // 15 minutos
      enabled: true
    });

    // 7. ALERTA CRÍTICA: Tasa de éxito muy baja
    this.addAlertRule({
      id: 'low_success_rate',
      name: 'Tasa de Éxito Baja',
      description: 'Tasa de éxito < 70%',
      condition: (metrics: SystemMetrics) => 
        metrics.financial.successRate < 70 && 
        metrics.financial.totalTrades > 10, // Solo si hay suficientes trades
      severity: 'high',
      message: '📉 TASA DE ÉXITO BAJA: <70% trades exitosos',
      actions: ['reduce_volume', 'notify_admin', 'log_incident'],
      cooldownMs: 300000, // 5 minutos
      enabled: true
    });

    // 8. ALERTA CRÍTICA: Espacio en disco crítico
    this.addAlertRule({
      id: 'disk_space_critical',
      name: 'Espacio en Disco Crítico',
      description: 'Espacio en disco > 95%',
      condition: (metrics: SystemMetrics) => 
        metrics.health.diskSpace.percentage > 95,
      severity: 'critical',
      message: '💾 ESPACIO EN DISCO CRÍTICO: >95% usado',
      actions: ['emergency_stop', 'backup_data', 'notify_admin'],
      cooldownMs: 300000, // 5 minutos
      enabled: true
    });

    console.log(`✅ ${this.alertRules.size} reglas de alertas inicializadas`);
  }

  /**
   * Inicializar canales de alertas
   */
  private initializeAlertChannels(): void {
    console.log('📢 Inicializando canales de alertas...');

    // Canal de consola (siempre habilitado para desarrollo)
    this.addAlertChannel({
      name: 'console',
      type: 'console',
      enabled: true,
      config: {
        colorize: true,
        timestamp: true
      },
      severityFilter: ['low', 'medium', 'high', 'critical']
    });

    // Canal de Discord (configurar en producción)
    this.addAlertChannel({
      name: 'discord_critical',
      type: 'discord',
      enabled: false, // Habilitar cuando se configure webhook
      config: {
        webhookUrl: process.env.DISCORD_WEBHOOK_URL || '',
        username: 'ArbitrageX Alerts',
        avatar: 'https://cdn.discordapp.com/emojis/🚨.png'
      },
      severityFilter: ['high', 'critical']
    });

    // Canal de email (configurar en producción)
    this.addAlertChannel({
      name: 'email_admin',
      type: 'email',
      enabled: false, // Habilitar cuando se configure SMTP
      config: {
        to: process.env.ADMIN_EMAIL || '',
        from: process.env.ALERT_FROM_EMAIL || '',
        smtp: {
          host: process.env.SMTP_HOST || '',
          port: parseInt(process.env.SMTP_PORT || '587'),
          secure: false,
          auth: {
            user: process.env.SMTP_USER || '',
            pass: process.env.SMTP_PASS || ''
          }
        }
      },
      severityFilter: ['critical']
    });

    console.log(`✅ ${this.alertChannels.size} canales de alertas inicializados`);
  }

  /**
   * Procesar métricas y verificar reglas de alertas
   */
  async processMetrics(metrics: SystemMetrics): Promise<void> {
    const triggeredAlerts: Alert[] = [];

    for (const [ruleId, rule] of this.alertRules) {
      if (!rule.enabled) continue;

      try {
        // Verificar cooldown
        const lastAlert = this.lastAlertTime.get(ruleId);
        if (lastAlert && (Date.now() - lastAlert) < rule.cooldownMs) {
          continue; // En cooldown, skip
        }

        // Evaluar condición
        if (rule.condition(metrics)) {
          const alert: Alert = {
            id: `${ruleId}_${Date.now()}`,
            ruleId,
            severity: rule.severity,
            message: rule.message,
            timestamp: Date.now(),
            metrics,
            resolved: false,
            actions: rule.actions
          };

          triggeredAlerts.push(alert);
          this.alertHistory.push(alert);
          this.lastAlertTime.set(ruleId, Date.now());

          console.log(`🚨 ALERTA DISPARADA: ${rule.name}`);
        }
      } catch (error) {
        console.error(`❌ Error evaluando regla ${ruleId}:`, error);
      }
    }

    // Procesar alertas disparadas
    for (const alert of triggeredAlerts) {
      await this.processAlert(alert);
    }

    // Emitir evento si hay alertas
    if (triggeredAlerts.length > 0) {
      this.emit('alerts-triggered', triggeredAlerts);
    }
  }

  /**
   * Procesar una alerta individual
   */
  private async processAlert(alert: Alert): Promise<void> {
    console.log(`🚨 Procesando alerta: ${alert.message}`);

    // Enviar a todos los canales configurados
    await this.sendToChannels(alert);

    // Ejecutar acciones automáticas
    await this.executeActions(alert);

    // Emitir evento de alerta
    this.emit('alert-processed', alert);
  }

  /**
   * Enviar alerta a todos los canales configurados
   */
  private async sendToChannels(alert: Alert): Promise<void> {
    for (const [channelName, channel] of this.alertChannels) {
      if (!channel.enabled) continue;
      
      // Verificar filtro de severidad
      if (!channel.severityFilter.includes(alert.severity)) continue;

      try {
        switch (channel.type) {
          case 'console':
            await this.sendToConsole(alert, channel);
            break;
          case 'discord':
            await this.sendToDiscord(alert, channel);
            break;
          case 'email':
            await this.sendToEmail(alert, channel);
            break;
          case 'webhook':
            await this.sendToWebhook(alert, channel);
            break;
          default:
            console.warn(`⚠️ Tipo de canal no soportado: ${channel.type}`);
        }
      } catch (error) {
        console.error(`❌ Error enviando alerta a ${channelName}:`, error);
      }
    }
  }

  /**
   * Enviar alerta a consola
   */
  private async sendToConsole(alert: Alert, channel: AlertChannel): Promise<void> {
    const timestamp = new Date(alert.timestamp).toISOString();
    const severity = alert.severity.toUpperCase();
    
    let color = '';
    switch (alert.severity) {
      case 'critical': color = '\x1b[41m'; break; // Fondo rojo
      case 'high': color = '\x1b[31m'; break;     // Texto rojo
      case 'medium': color = '\x1b[33m'; break;   // Texto amarillo
      case 'low': color = '\x1b[36m'; break;      // Texto cyan
    }
    
    console.log(`${color}[${timestamp}] ${severity}: ${alert.message}\x1b[0m`);
  }

  /**
   * Enviar alerta a Discord
   */
  private async sendToDiscord(alert: Alert, channel: AlertChannel): Promise<void> {
    if (!channel.config.webhookUrl) {
      console.warn('⚠️ Discord webhook no configurado');
      return;
    }

    const embed = {
      title: `🚨 ArbitrageX Alert - ${alert.severity.toUpperCase()}`,
      description: alert.message,
      color: this.getSeverityColor(alert.severity),
      timestamp: new Date(alert.timestamp).toISOString(),
      fields: [
        {
          name: '📊 CPU Usage',
          value: `${alert.metrics.performance.cpuUsage.toFixed(1)}%`,
          inline: true
        },
        {
          name: '💾 Memory Usage',
          value: `${alert.metrics.performance.memoryUsage.percentage.toFixed(1)}%`,
          inline: true
        },
        {
          name: '⚡ Error Rate',
          value: `${alert.metrics.performance.errorRate.toFixed(1)}%`,
          inline: true
        }
      ]
    };

    try {
      await fetch(channel.config.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: channel.config.username,
          embeds: [embed]
        })
      });
    } catch (error) {
      console.error('❌ Error enviando a Discord:', error);
    }
  }

  /**
   * Enviar alerta por email
   */
  private async sendToEmail(alert: Alert, channel: AlertChannel): Promise<void> {
    // TODO: Implementar envío de email usando nodemailer
    console.log(`📧 EMAIL ALERT: ${alert.message}`);
  }

  /**
   * Enviar alerta a webhook
   */
  private async sendToWebhook(alert: Alert, channel: AlertChannel): Promise<void> {
    try {
      await fetch(channel.config.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          alert,
          timestamp: Date.now(),
          source: 'ArbitrageX Pro 2025'
        })
      });
    } catch (error) {
      console.error('❌ Error enviando a webhook:', error);
    }
  }

  /**
   * Ejecutar acciones automáticas de una alerta
   */
  private async executeActions(alert: Alert): Promise<void> {
    for (const action of alert.actions) {
      try {
        await this.executeAction(action, alert);
      } catch (error) {
        console.error(`❌ Error ejecutando acción ${action}:`, error);
      }
    }
  }

  /**
   * Ejecutar una acción específica
   */
  private async executeAction(action: AlertAction, alert: Alert): Promise<void> {
    console.log(`🔧 Ejecutando acción: ${action}`);

    switch (action) {
      case 'emergency_stop':
        await this.triggerEmergencyStop(alert);
        break;
      case 'notify_admin':
        console.log('📧 Notificando administrador...');
        break;
      case 'notify_team':
        console.log('👥 Notificando equipo...');
        break;
      case 'log_incident':
        await this.logIncident(alert);
        break;
      case 'reduce_volume':
        console.log('📉 Reduciendo volumen de trading...');
        break;
      case 'switch_rpc_providers':
        console.log('🔄 Cambiando a RPC providers alternativos...');
        break;
      case 'restart_service':
        console.log('🔄 Reiniciando servicio...');
        break;
      case 'backup_data':
        console.log('💾 Iniciando backup de emergencia...');
        break;
    }
  }

  /**
   * Disparar parada de emergencia
   */
  private async triggerEmergencyStop(alert: Alert): Promise<void> {
    if (this.emergencyStopTriggered) {
      console.log('⚠️ Emergency stop ya activado');
      return;
    }

    console.log('🛑 EMERGENCY STOP DISPARADO');
    this.emergencyStopTriggered = true;

    // Emitir evento de emergency stop
    this.emit('emergency-stop', {
      reason: alert.message,
      timestamp: Date.now(),
      alert
    });

    // TODO: Implementar lógica real de parada de emergencia
    // - Detener todos los trades activos
    // - Cerrar posiciones abiertas
    // - Pausar detección de oportunidades
  }

  /**
   * Registrar incidente
   */
  private async logIncident(alert: Alert): Promise<void> {
    const incident = {
      id: `incident_${Date.now()}`,
      alertId: alert.id,
      severity: alert.severity,
      message: alert.message,
      timestamp: alert.timestamp,
      metrics: alert.metrics,
      status: 'open'
    };

    // TODO: Guardar en base de datos o sistema de incidentes
    console.log(`📝 Incidente registrado: ${incident.id}`);
  }

  /**
   * Obtener color para Discord basado en severidad
   */
  private getSeverityColor(severity: AlertSeverity): number {
    switch (severity) {
      case 'critical': return 0xFF0000; // Rojo
      case 'high': return 0xFF8000;     // Naranja
      case 'medium': return 0xFFFF00;   // Amarillo
      case 'low': return 0x00FFFF;      // Cyan
      default: return 0x808080;         // Gris
    }
  }

  /**
   * Agregar nueva regla de alerta
   */
  addAlertRule(rule: AlertRule): void {
    this.alertRules.set(rule.id, rule);
    console.log(`✅ Regla de alerta añadida: ${rule.name}`);
  }

  /**
   * Agregar nuevo canal de alerta
   */
  addAlertChannel(channel: AlertChannel): void {
    this.alertChannels.set(channel.name, channel);
    console.log(`✅ Canal de alerta añadido: ${channel.name}`);
  }

  /**
   * Obtener historial de alertas
   */
  getAlertHistory(limit: number = 100): Alert[] {
    return this.alertHistory
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit);
  }

  /**
   * Obtener alertas activas (no resueltas)
   */
  getActiveAlerts(): Alert[] {
    return this.alertHistory.filter(alert => !alert.resolved);
  }

  /**
   * Resolver una alerta
   */
  resolveAlert(alertId: string): boolean {
    const alert = this.alertHistory.find(a => a.id === alertId);
    if (alert && !alert.resolved) {
      alert.resolved = true;
      alert.resolvedAt = Date.now();
      console.log(`✅ Alerta resuelta: ${alertId}`);
      return true;
    }
    return false;
  }

  /**
   * Resetear emergency stop
   */
  resetEmergencyStop(): void {
    this.emergencyStopTriggered = false;
    console.log('🟢 Emergency stop reseteado');
    this.emit('emergency-stop-reset', { timestamp: Date.now() });
  }

  /**
   * Obtener estadísticas de alertas
   */
  getAlertStats(): any {
    const total = this.alertHistory.length;
    const resolved = this.alertHistory.filter(a => a.resolved).length;
    const bySeverity = {
      critical: this.alertHistory.filter(a => a.severity === 'critical').length,
      high: this.alertHistory.filter(a => a.severity === 'high').length,
      medium: this.alertHistory.filter(a => a.severity === 'medium').length,
      low: this.alertHistory.filter(a => a.severity === 'low').length
    };

    return {
      total,
      resolved,
      active: total - resolved,
      bySeverity,
      emergencyStopActive: this.emergencyStopTriggered
    };
  }
}

// Exportar instancia singleton
export const criticalAlertsManager = CriticalAlertsManager.getInstance();
