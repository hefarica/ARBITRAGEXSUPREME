import { ethers } from 'ethers'
import { secureLogger } from '../utils/SecurityUtils'
import { mevLatencyMonitor, MEVOpportunity, LatencyMetrics } from './MEVLatencyMonitor'
import { AdvancedROICalculator, ROICalculation, GasEstimate } from './AdvancedROICalculator'

// Interfaces para optimización de estrategias MEV
export interface MEVStrategy {
  id: string
  name: string
  type: 'arbitrage' | 'liquidation' | 'sandwich' | 'jit' | 'cross-chain'
  description: string
  chainId: number
  gasLimit: number
  estimatedGasPrice: number
  priorityFee: number
  executionTime: number // ms
  successRate: number // 0-1
  riskLevel: 'low' | 'medium' | 'high' | 'extreme'
  minimumCapital: number
  expectedROI: number
  gasEfficiency: number // 1-10
  latencyTolerance: number // ms
  mevProtection: boolean
  flashbotsCompatible: boolean
  eigenphiOptimized: boolean
  blocknativeOptimized: boolean
  lastOptimized: number
  optimizationScore: number // 0-100
}

export interface StrategyOptimization {
  strategyId: string
  originalStrategy: MEVStrategy
  optimizedStrategy: MEVStrategy
  improvements: {
    gasEfficiency: number
    roiImprovement: number
    latencyReduction: number
    riskReduction: number
    capitalOptimization: number
  }
  optimizationTimestamp: number
  confidence: number
}

export interface ExecutionRecommendation {
  strategyId: string
  recommendation: 'execute' | 'wait' | 'skip' | 'optimize'
  reason: string
  optimalExecutionTime: number
  expectedGasPrice: number
  priorityFee: number
  confidence: number
  riskAssessment: {
    level: 'low' | 'medium' | 'high' | 'extreme'
    factors: string[]
    mitigation: string[]
  }
}

export interface NetworkStrategyMapping {
  chainId: number
  networkName: string
  optimalStrategies: string[]
  gasPriceRange: { min: number; optimal: number; max: number }
  latencyThresholds: { low: number; medium: number; high: number }
  mevOpportunityRate: number
  successRate: number
  lastUpdate: number
}

export class MEVStrategyOptimizer {
  private strategies: Map<string, MEVStrategy> = new Map()
  private optimizations: Map<string, StrategyOptimization[]> = new Map()
  private networkMappings: Map<number, NetworkStrategyMapping> = new Map()
  private roiCalculator: AdvancedROICalculator
  private isOptimizing: boolean = false
  private optimizationInterval: number = 30000 // 30 segundos

  constructor() {
    this.roiCalculator = new AdvancedROICalculator()
    this.initializeStrategies()
    this.initializeNetworkMappings()
  }

  /**
   * Inicializar estrategias MEV predefinidas
   */
  private initializeStrategies(): void {
    // Estrategias de arbitraje
    this.addStrategy({
      id: 'arb_uniswap_sushiswap',
      name: 'Uniswap-SushiSwap Arbitrage',
      type: 'arbitrage',
      description: 'Arbitraje entre DEXs más populares con protección MEV',
      chainId: 1,
      gasLimit: 300000,
      estimatedGasPrice: 25,
      priorityFee: 2,
      executionTime: 5000,
      successRate: 0.85,
      riskLevel: 'low',
      minimumCapital: 15000,
      expectedROI: 8.5,
      gasEfficiency: 8,
      latencyTolerance: 3000,
      mevProtection: true,
      flashbotsCompatible: true,
      eigenphiOptimized: true,
      blocknativeOptimized: true,
      lastOptimized: Date.now(),
      optimizationScore: 85
    })

    this.addStrategy({
      id: 'arb_cross_dex',
      name: 'Cross-DEX Multi-Pair Arbitrage',
      type: 'arbitrage',
      description: 'Arbitraje entre múltiples pares y DEXs',
      chainId: 1,
      gasLimit: 450000,
      estimatedGasPrice: 30,
      priorityFee: 3,
      executionTime: 8000,
      successRate: 0.75,
      riskLevel: 'medium',
      minimumCapital: 25000,
      expectedROI: 12.0,
      gasEfficiency: 7,
      latencyTolerance: 5000,
      mevProtection: true,
      flashbotsCompatible: true,
      eigenphiOptimized: true,
      blocknativeOptimized: true,
      lastOptimized: Date.now(),
      optimizationScore: 78
    })

    // Estrategias de liquidación
    this.addStrategy({
      id: 'liq_aave_compound',
      name: 'Aave-Compound Liquidation',
      type: 'liquidation',
      description: 'Liquidación de posiciones en protocolos de lending',
      chainId: 1,
      gasLimit: 250000,
      estimatedGasPrice: 35,
      priorityFee: 4,
      executionTime: 3000,
      successRate: 0.90,
      riskLevel: 'low',
      minimumCapital: 20000,
      expectedROI: 15.0,
      gasEfficiency: 9,
      latencyTolerance: 2000,
      mevProtection: false,
      flashbotsCompatible: true,
      eigenphiOptimized: false,
      blocknativeOptimized: true,
      lastOptimized: Date.now(),
      optimizationScore: 92
    })

    // Estrategias JIT
    this.addStrategy({
      id: 'jit_uniswap_v3',
      name: 'Uniswap V3 JIT Liquidity',
      type: 'jit',
      description: 'Just-In-Time liquidity provision en pools concentrados',
      chainId: 1,
      gasLimit: 400000,
      estimatedGasPrice: 40,
      priorityFee: 5,
      executionTime: 6000,
      successRate: 0.70,
      riskLevel: 'high',
      minimumCapital: 35000,
      expectedROI: 18.0,
      gasEfficiency: 6,
      latencyTolerance: 4000,
      mevProtection: true,
      flashbotsCompatible: true,
      eigenphiOptimized: true,
      blocknativeOptimized: false,
      lastOptimized: Date.now(),
      optimizationScore: 72
    })

    // Estrategias cross-chain
    this.addStrategy({
      id: 'cross_arbitrum_optimism',
      name: 'Arbitrum-Optimism Bridge Arbitrage',
      type: 'cross-chain',
      description: 'Arbitraje entre L2s usando bridges',
      chainId: 1,
      gasLimit: 600000,
      estimatedGasPrice: 45,
      priorityFee: 6,
      executionTime: 15000,
      successRate: 0.65,
      riskLevel: 'extreme',
      minimumCapital: 50000,
      expectedROI: 25.0,
      gasEfficiency: 5,
      latencyTolerance: 10000,
      mevProtection: true,
      flashbotsCompatible: false,
      eigenphiOptimized: false,
      blocknativeOptimized: true,
      lastOptimized: Date.now(),
      optimizationScore: 68
    })

    // Estrategias para otras redes
    this.addStrategy({
      id: 'arb_polygon_quickswap',
      name: 'Polygon QuickSwap Arbitrage',
      type: 'arbitrage',
      description: 'Arbitraje en Polygon con gas bajo',
      chainId: 137,
      gasLimit: 200000,
      estimatedGasPrice: 30,
      priorityFee: 1,
      executionTime: 2000,
      successRate: 0.80,
      riskLevel: 'low',
      minimumCapital: 10000,
      expectedROI: 6.0,
      gasEfficiency: 9,
      latencyTolerance: 1500,
      mevProtection: false,
      flashbotsCompatible: false,
      eigenphiOptimized: false,
      blocknativeOptimized: true,
      lastOptimized: Date.now(),
      optimizationScore: 82
    })

    this.addStrategy({
      id: 'arb_bsc_pancakeswap',
      name: 'BSC PancakeSwap Arbitrage',
      type: 'arbitrage',
      description: 'Arbitraje en BSC con alta velocidad',
      chainId: 56,
      gasLimit: 250000,
      estimatedGasPrice: 5,
      priorityFee: 0.5,
      executionTime: 3000,
      successRate: 0.78,
      riskLevel: 'low',
      minimumCapital: 8000,
      expectedROI: 5.5,
      gasEfficiency: 8,
      latencyTolerance: 2000,
      mevProtection: false,
      flashbotsCompatible: false,
      eigenphiOptimized: false,
      blocknativeOptimized: true,
      lastOptimized: Date.now(),
      optimizationScore: 80
    })
  }

  /**
   * Inicializar mapeos de red
   */
  private initializeNetworkMappings(): void {
    const networks = [
      { chainId: 1, name: 'Ethereum' },
      { chainId: 137, name: 'Polygon' },
      { chainId: 56, name: 'BSC' },
      { chainId: 42161, name: 'Arbitrum' },
      { chainId: 10, name: 'Optimism' },
      { chainId: 43114, name: 'Avalanche' },
      { chainId: 250, name: 'Fantom' },
      { chainId: 25, name: 'Cronos' }
    ]

    for (const network of networks) {
      this.networkMappings.set(network.chainId, {
        chainId: network.chainId,
        networkName: network.name,
        optimalStrategies: [],
        gasPriceRange: { min: 5, optimal: 25, max: 100 },
        latencyThresholds: { low: 1000, medium: 3000, high: 8000 },
        mevOpportunityRate: 0,
        successRate: 0,
        lastUpdate: Date.now()
      })
    }
  }

  /**
   * Agregar estrategia
   */
  private addStrategy(strategy: MEVStrategy): void {
    this.strategies.set(strategy.id, strategy)
    
    // Actualizar mapeo de red
    const networkMapping = this.networkMappings.get(strategy.chainId)
    if (networkMapping) {
      networkMapping.optimalStrategies.push(strategy.id)
      networkMapping.lastUpdate = Date.now()
    }
  }

  /**
   * Iniciar optimización continua
   */
  async startOptimization(): Promise<void> {
    if (this.isOptimizing) return

    this.isOptimizing = true
    secureLogger.info('Iniciando optimización continua de estrategias MEV', {}, 'MEVStrategyOptimizer')

    setInterval(async () => {
      if (this.isOptimizing) {
        await this.optimizeAllStrategies()
      }
    }, this.optimizationInterval)
  }

  /**
   * Detener optimización
   */
  stopOptimization(): void {
    this.isOptimizing = false
    secureLogger.info('Deteniendo optimización de estrategias MEV', {}, 'MEVStrategyOptimizer')
  }

  /**
   * Optimizar todas las estrategias
   */
  private async optimizeAllStrategies(): Promise<void> {
    const promises = Array.from(this.strategies.values()).map(strategy =>
      this.optimizeStrategy(strategy)
    )

    await Promise.allSettled(promises)
    
    // Actualizar mapeos de red
    this.updateNetworkMappings()
  }

  /**
   * Optimizar estrategia específica
   */
  private async optimizeStrategy(strategy: MEVStrategy): Promise<void> {
    try {
      // Obtener métricas de latencia actuales
      const latencyMetrics = await mevLatencyMonitor.getLatencyMetrics(strategy.chainId)
      
      // Obtener oportunidades MEV activas
      const mevOpportunities = mevLatencyMonitor.getActiveMEVOpportunities()
      const relevantOpportunities = mevOpportunities.filter(opp => 
        opp.chainId === strategy.chainId && opp.type === strategy.type
      )

      // Calcular ROI optimizado
      const roiCalculation = await this.calculateOptimizedROI(strategy, latencyMetrics, relevantOpportunities)
      
      // Crear estrategia optimizada
      const optimizedStrategy = this.createOptimizedStrategy(strategy, roiCalculation, latencyMetrics)
      
      // Almacenar optimización
      this.storeOptimization(strategy, optimizedStrategy, roiCalculation)
      
      // Actualizar estrategia
      this.strategies.set(strategy.id, optimizedStrategy)
      
    } catch (error) {
      secureLogger.error('Error optimizando estrategia', {
        strategyId: strategy.id,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'MEVStrategyOptimizer')
    }
  }

  /**
   * Calcular ROI optimizado
   */
  private async calculateOptimizedROI(
    strategy: MEVStrategy,
    latencyMetrics: LatencyMetrics,
    mevOpportunities: MEVOpportunity[]
  ): Promise<ROICalculation> {
    try {
      // Calcular estimación de gas optimizada
      const gasEstimate = await this.calculateOptimizedGas(strategy, latencyMetrics)
      
      // Calcular fees optimizados
      const feeBreakdown = await this.calculateOptimizedFees(strategy, gasEstimate)
      
      // Calcular ROI considerando latencia y oportunidades MEV
      const roiCalculation = await this.roiCalculator.calculateROI({
        investmentAmount: strategy.minimumCapital,
        expectedReturn: strategy.expectedROI / 100,
        gasEstimate,
        feeBreakdown,
        executionTime: strategy.executionTime,
        networkLatency: latencyMetrics.totalLatency,
        mevOpportunities: mevOpportunities.length,
        riskLevel: strategy.riskLevel
      })

      return roiCalculation
      
    } catch (error) {
      secureLogger.error('Error calculando ROI optimizado', {
        strategyId: strategy.id,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'MEVStrategyOptimizer')
      
      // Retornar cálculo por defecto
      return this.getDefaultROICalculation(strategy)
    }
  }

  /**
   * Calcular gas optimizado
   */
  private async calculateOptimizedGas(
    strategy: MEVStrategy,
    latencyMetrics: LatencyMetrics
  ): Promise<GasEstimate> {
    try {
      // Obtener estadísticas de latencia
      const latencyStats = mevLatencyMonitor.getLatencyStatistics(strategy.chainId)
      
      // Ajustar gas price basado en latencia y tendencia
      let optimizedGasPrice = strategy.estimatedGasPrice
      let gasEfficiency = strategy.gasEfficiency
      
      if (latencyStats.trend === 'improving') {
        optimizedGasPrice = Math.max(5, optimizedGasPrice * 0.9)
        gasEfficiency = Math.min(10, gasEfficiency + 1)
      } else if (latencyStats.trend === 'degrading') {
        optimizedGasPrice = Math.min(100, optimizedGasPrice * 1.2)
        gasEfficiency = Math.max(1, gasEfficiency - 1)
      }
      
      // Ajustar basado en latencia actual
      if (latencyMetrics.totalLatency > 5000) {
        optimizedGasPrice = Math.min(100, optimizedGasPrice * 1.15)
      } else if (latencyMetrics.totalLatency < 2000) {
        optimizedGasPrice = Math.max(5, optimizedGasPrice * 0.95)
      }
      
      // Calcular gas limit optimizado
      const optimizedGasLimit = Math.round(strategy.gasLimit * (1 + (10 - gasEfficiency) / 20))
      
      // Calcular costo total
      const totalCostETH = (optimizedGasLimit * optimizedGasPrice) / 1e9
      const totalCostUSD = totalCostETH * 2000 // Asumiendo ETH = $2000
      
      return {
        gasLimit: optimizedGasLimit,
        gasPriceGwei: optimizedGasPrice,
        totalCostETH,
        totalCostUSD,
        gasEfficiency
      }
      
    } catch (error) {
      secureLogger.error('Error calculando gas optimizado', {
        strategyId: strategy.id,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'MEVStrategyOptimizer')
      
      // Retornar estimación por defecto
      return {
        gasLimit: strategy.gasLimit,
        gasPriceGwei: strategy.estimatedGasPrice,
        totalCostETH: (strategy.gasLimit * strategy.estimatedGasPrice) / 1e9,
        totalCostUSD: (strategy.gasLimit * strategy.estimatedGasPrice * 2000) / 1e9,
        gasEfficiency: strategy.gasEfficiency
      }
    }
  }

  /**
   * Calcular fees optimizados
   */
  private async calculateOptimizedFees(
    strategy: MEVStrategy,
    gasEstimate: GasEstimate
  ): Promise<any> {
    try {
      // Calcular priority fee optimizado
      let priorityFee = strategy.priorityFee
      
      // Ajustar basado en eficiencia de gas
      if (gasEstimate.gasEfficiency >= 8) {
        priorityFee = Math.max(0.5, priorityFee * 0.8)
      } else if (gasEstimate.gasEfficiency <= 4) {
        priorityFee = Math.min(10, priorityFee * 1.3)
      }
      
      // Calcular fees totales
      const gasFees = gasEstimate.totalCostUSD
      const protocolFees = strategy.minimumCapital * 0.002 // 0.2%
      const flashLoanFees = strategy.type === 'arbitrage' ? strategy.minimumCapital * 0.0009 : 0 // 0.09%
      const bridgeFees = strategy.type === 'cross-chain' ? strategy.minimumCapital * 0.005 : 0 // 0.5%
      const mevProtectionFees = strategy.mevProtection ? gasEstimate.totalCostUSD * 0.1 : 0 // 10% extra
      
      const totalFees = gasFees + protocolFees + flashLoanFees + bridgeFees + mevProtectionFees
      
      return {
        gasFees,
        protocolFees,
        flashLoanFees,
        bridgeFees,
        mevProtectionFees,
        totalFees,
        totalFeesUSD: totalFees,
        priorityFee
      }
      
    } catch (error) {
      secureLogger.error('Error calculando fees optimizados', {
        strategyId: strategy.id,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'MEVStrategyOptimizer')
      
      // Retornar fees por defecto
      return {
        gasFees: gasEstimate.totalCostUSD,
        protocolFees: strategy.minimumCapital * 0.002,
        flashLoanFees: 0,
        bridgeFees: 0,
        mevProtectionFees: 0,
        totalFees: gasEstimate.totalCostUSD + (strategy.minimumCapital * 0.002),
        totalFeesUSD: gasEstimate.totalCostUSD + (strategy.minimumCapital * 0.002),
        priorityFee: strategy.priorityFee
      }
    }
  }

  /**
   * Crear estrategia optimizada
   */
  private createOptimizedStrategy(
    originalStrategy: MEVStrategy,
    roiCalculation: ROICalculation,
    latencyMetrics: LatencyMetrics
  ): MEVStrategy {
    const now = Date.now()
    
    // Calcular score de optimización
    const optimizationScore = this.calculateOptimizationScore(originalStrategy, roiCalculation, latencyMetrics)
    
    // Ajustar parámetros basados en ROI
    const adjustedGasPrice = roiCalculation.gasEfficiency > originalStrategy.gasEfficiency ? 
      originalStrategy.estimatedGasPrice * 0.95 : originalStrategy.estimatedGasPrice * 1.05
    
    const adjustedExecutionTime = latencyMetrics.totalLatency < originalStrategy.latencyTolerance ?
      Math.max(1000, originalStrategy.executionTime * 0.9) : originalStrategy.executionTime * 1.1
    
    const adjustedSuccessRate = Math.min(0.95, originalStrategy.successRate * (1 + (roiCalculation.roi - originalStrategy.expectedROI) / 100))
    
    return {
      ...originalStrategy,
      estimatedGasPrice: Math.max(5, Math.min(100, adjustedGasPrice)),
      executionTime: Math.max(1000, Math.min(30000, adjustedExecutionTime)),
      successRate: Math.max(0.5, Math.min(0.95, adjustedSuccessRate)),
      expectedROI: roiCalculation.roi,
      gasEfficiency: roiCalculation.gasEfficiency,
      lastOptimized: now,
      optimizationScore
    }
  }

  /**
   * Calcular score de optimización
   */
  private calculateOptimizationScore(
    originalStrategy: MEVStrategy,
    roiCalculation: ROICalculation,
    latencyMetrics: LatencyMetrics
  ): number {
    let score = 50 // Score base
    
    // Mejora en ROI
    const roiImprovement = roiCalculation.roi - originalStrategy.expectedROI
    if (roiImprovement > 0) {
      score += Math.min(20, roiImprovement * 2)
    } else {
      score -= Math.min(15, Math.abs(roiImprovement) * 1.5)
    }
    
    // Mejora en eficiencia de gas
    const gasEfficiencyImprovement = roiCalculation.gasEfficiency - originalStrategy.gasEfficiency
    if (gasEfficiencyImprovement > 0) {
      score += Math.min(15, gasEfficiencyImprovement * 3)
    } else {
      score -= Math.min(10, Math.abs(gasEfficiencyImprovement) * 2)
    }
    
    // Latencia
    if (latencyMetrics.totalLatency < originalStrategy.latencyTolerance) {
      score += 10
    } else if (latencyMetrics.totalLatency > originalStrategy.latencyTolerance * 2) {
      score -= 15
    }
    
    // Confianza en métricas
    score += Math.round(latencyMetrics.confidence * 10)
    
    return Math.max(0, Math.min(100, score))
  }

  /**
   * Almacenar optimización
   */
  private storeOptimization(
    originalStrategy: MEVStrategy,
    optimizedStrategy: MEVStrategy,
    roiCalculation: ROICalculation
  ): void {
    const optimization: StrategyOptimization = {
      strategyId: originalStrategy.id,
      originalStrategy,
      optimizedStrategy,
      improvements: {
        gasEfficiency: optimizedStrategy.gasEfficiency - originalStrategy.gasEfficiency,
        roiImprovement: optimizedStrategy.expectedROI - originalStrategy.expectedROI,
        latencyReduction: originalStrategy.executionTime - optimizedStrategy.executionTime,
        riskReduction: this.calculateRiskReduction(originalStrategy.riskLevel, optimizedStrategy.riskLevel),
        capitalOptimization: originalStrategy.minimumCapital - optimizedStrategy.minimumCapital
      },
      optimizationTimestamp: Date.now(),
      confidence: roiCalculation.confidence
    }
    
    if (!this.optimizations.has(originalStrategy.id)) {
      this.optimizations.set(originalStrategy.id, [])
    }
    
    const strategyOptimizations = this.optimizations.get(originalStrategy.id)!
    strategyOptimizations.push(optimization)
    
    // Mantener solo últimas 10 optimizaciones
    if (strategyOptimizations.length > 10) {
      strategyOptimizations.shift()
    }
  }

  /**
   * Calcular reducción de riesgo
   */
  private calculateRiskReduction(
    originalRisk: string,
    optimizedRisk: string
  ): number {
    const riskValues = { 'low': 1, 'medium': 2, 'high': 3, 'extreme': 4 }
    const originalValue = riskValues[originalRisk as keyof typeof riskValues] || 2
    const optimizedValue = riskValues[optimizedRisk as keyof typeof riskValues] || 2
    
    return originalValue - optimizedValue
  }

  /**
   * Actualizar mapeos de red
   */
  private updateNetworkMappings(): void {
    for (const [chainId, mapping] of this.networkMappings) {
      const strategies = Array.from(this.strategies.values())
        .filter(s => s.chainId === chainId)
        .sort((a, b) => b.optimizationScore - a.optimizationScore)
      
      mapping.optimalStrategies = strategies.slice(0, 5).map(s => s.id)
      mapping.mevOpportunityRate = mevLatencyMonitor.getNetworkPerformance()
        .find(n => n.chainId === chainId)?.mevOpportunityRate || 0
      mapping.successRate = strategies.length > 0 ? 
        strategies.reduce((sum, s) => sum + s.successRate, 0) / strategies.length : 0
      mapping.lastUpdate = Date.now()
    }
  }

  /**
   * Obtener recomendación de ejecución
   */
  async getExecutionRecommendation(strategyId: string): Promise<ExecutionRecommendation> {
    const strategy = this.strategies.get(strategyId)
    if (!strategy) {
      throw new Error(`Estrategia no encontrada: ${strategyId}`)
    }
    
    try {
      // Obtener métricas de latencia
      const latencyMetrics = await mevLatencyMonitor.getLatencyMetrics(strategy.chainId)
      
      // Obtener oportunidades MEV
      const mevOpportunities = mevLatencyMonitor.getActiveMEVOpportunities()
      const relevantOpportunities = mevOpportunities.filter(opp => 
        opp.chainId === strategy.chainId && opp.type === strategy.type
      )
      
      // Calcular ROI actual
      const roiCalculation = await this.calculateOptimizedROI(strategy, latencyMetrics, relevantOpportunities)
      
      // Determinar recomendación
      let recommendation: 'execute' | 'wait' | 'skip' | 'optimize' = 'execute'
      let reason = 'Estrategia optimizada y lista para ejecución'
      let confidence = roiCalculation.confidence
      
      // Verificar si debe esperar
      if (latencyMetrics.totalLatency > strategy.latencyTolerance * 1.5) {
        recommendation = 'wait'
        reason = 'Latencia de red demasiado alta para ejecución óptima'
        confidence *= 0.7
      }
      
      // Verificar si debe saltarse
      if (roiCalculation.roi < 2 || roiCalculation.netProfit < 50) {
        recommendation = 'skip'
        reason = 'ROI demasiado bajo para ser rentable'
        confidence *= 0.5
      }
      
      // Verificar si necesita optimización
      if (strategy.optimizationScore < 60) {
        recommendation = 'optimize'
        reason = 'Estrategia requiere optimización adicional'
        confidence *= 0.8
      }
      
      // Calcular tiempo óptimo de ejecución
      const optimalExecutionTime = Date.now() + (latencyMetrics.totalLatency < 2000 ? 0 : 5000)
      
      // Calcular gas price y priority fee óptimos
      const gasEstimate = await this.calculateOptimizedGas(strategy, latencyMetrics)
      const feeBreakdown = await this.calculateOptimizedFees(strategy, gasEstimate)
      
      // Evaluar riesgo
      const riskFactors: string[] = []
      const mitigation: string[] = []
      
      if (latencyMetrics.totalLatency > 5000) {
        riskFactors.push('Alta latencia de red')
        mitigation.push('Usar Flashbots para protección MEV')
      }
      
      if (gasEstimate.gasPriceGwei > 50) {
        riskFactors.push('Gas price alto')
        mitigation.push('Esperar a que baje el gas price')
      }
      
      if (strategy.riskLevel === 'extreme') {
        riskFactors.push('Riesgo extremo')
        mitigation.push('Reducir tamaño de posición')
      }
      
      const riskLevel = riskFactors.length === 0 ? 'low' : 
                       riskFactors.length === 1 ? 'medium' : 
                       riskFactors.length === 2 ? 'high' : 'extreme'
      
      return {
        strategyId,
        recommendation,
        reason,
        optimalExecutionTime,
        expectedGasPrice: gasEstimate.gasPriceGwei,
        priorityFee: feeBreakdown.priorityFee,
        confidence: Math.max(0.1, Math.min(1, confidence)),
        riskAssessment: {
          level: riskLevel,
          factors: riskFactors,
          mitigation
        }
      }
      
    } catch (error) {
      secureLogger.error('Error obteniendo recomendación de ejecución', {
        strategyId,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'MEVStrategyOptimizer')
      
      // Retornar recomendación por defecto
      return {
        strategyId,
        recommendation: 'skip',
        reason: 'Error al analizar estrategia',
        optimalExecutionTime: Date.now() + 60000,
        expectedGasPrice: strategy.estimatedGasPrice,
        priorityFee: strategy.priorityFee,
        confidence: 0.1,
        riskAssessment: {
          level: 'high',
          factors: ['Error de análisis'],
          mitigation: ['Revisar logs y reintentar']
        }
      }
    }
  }

  /**
   * Obtener estrategias optimizadas
   */
  getOptimizedStrategies(): MEVStrategy[] {
    return Array.from(this.strategies.values())
      .sort((a, b) => b.optimizationScore - a.optimizationScore)
  }

  /**
   * Obtener estrategias por red
   */
  getStrategiesByNetwork(chainId: number): MEVStrategy[] {
    return Array.from(this.strategies.values())
      .filter(s => s.chainId === chainId)
      .sort((a, b) => b.optimizationScore - a.optimizationScore)
  }

  /**
   * Obtener historial de optimizaciones
   */
  getOptimizationHistory(strategyId: string): StrategyOptimization[] {
    return this.optimizations.get(strategyId) || []
  }

  /**
   * Obtener mapeos de red
   */
  getNetworkMappings(): NetworkStrategyMapping[] {
    return Array.from(this.networkMappings.values())
  }

  /**
   * Obtener ROI por defecto
   */
  private getDefaultROICalculation(strategy: MEVStrategy): ROICalculation {
    return {
      grossProfit: strategy.minimumCapital * (strategy.expectedROI / 100),
      totalFees: strategy.minimumCapital * 0.005, // 0.5% por defecto
      netProfit: 0,
      roi: strategy.expectedROI,
      roiAnnualized: strategy.expectedROI * 365,
      breakEvenAmount: strategy.minimumCapital * 0.005,
      minimumViableAmount: strategy.minimumCapital,
      riskAdjustedROI: strategy.expectedROI * (1 - (strategy.riskLevel === 'extreme' ? 0.4 : 
                                                   strategy.riskLevel === 'high' ? 0.2 : 
                                                   strategy.riskLevel === 'medium' ? 0.1 : 0)),
      gasEfficiency: strategy.gasEfficiency,
      confidence: 0.7,
      executionTime: strategy.executionTime,
      networkLatency: 0,
      mevOpportunities: 0,
      riskLevel: strategy.riskLevel
    }
  }
}

// Instancia singleton
export const mevStrategyOptimizer = new MEVStrategyOptimizer()
