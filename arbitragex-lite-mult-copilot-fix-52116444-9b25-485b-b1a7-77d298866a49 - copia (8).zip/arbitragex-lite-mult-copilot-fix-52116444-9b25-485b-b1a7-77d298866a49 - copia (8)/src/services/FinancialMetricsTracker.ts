/**
 * FinancialMetricsTracker.ts
 * Sistema de tracking de métricas financieras reales para ArbitrageX Pro 2025
 * RESUELVE: Problema #21 - Métricas financieras simuladas
 */

import { EventEmitter } from 'events';

export interface Trade {
  id: string;
  strategy: string;
  pair: string;
  type: 'arbitrage' | 'flash_loan' | 'mev' | 'triangular';
  amountIn: number;
  amountOut: number;
  gasCosts: number;
  timestamp: number;
  executionTime: number;
  profit: number;
  profitPercentage: number;
  status: 'pending' | 'completed' | 'failed' | 'reverted';
  blockNumber?: number;
  transactionHash?: string;
  dexes: string[];
  slippage: number;
}

export interface FinancialMetrics {
  // Métricas de trading
  dailyProfit: number;
  weeklyProfit: number;
  monthlyProfit: number;
  totalProfit: number;
  totalVolume: number;
  
  // Métricas de rendimiento
  totalTrades: number;
  successfulTrades: number;
  failedTrades: number;
  successRate: number;
  averageProfit: number;
  averageProfitPercentage: number;
  
  // Métricas de costos
  totalGasCosts: number;
  averageGasCost: number;
  gasCostPercentage: number;
  
  // Métricas de riesgo
  largestProfit: number;
  largestLoss: number;
  maxDrawdown: number;
  sharpeRatio: number;
  winRate: number;
  
  // Métricas de tiempo
  averageExecutionTime: number;
  totalExecutionTime: number;
  
  // Portfolio
  portfolioValue: number;
  dailyROI: number;
  totalROI: number;
  
  // Timestamp
  lastUpdated: number;
}

export interface PortfolioPosition {
  token: string;
  balance: number;
  value: number; // En USD
  percentage: number;
  lastUpdated: number;
}

export interface ProfitLossReport {
  period: 'daily' | 'weekly' | 'monthly' | 'yearly';
  startDate: number;
  endDate: number;
  totalProfit: number;
  totalVolume: number;
  totalTrades: number;
  averageProfit: number;
  bestTrade: Trade;
  worstTrade: Trade;
  profitByStrategy: Record<string, number>;
  profitByDex: Record<string, number>;
  dailyBreakdown: Array<{
    date: string;
    profit: number;
    trades: number;
    volume: number;
  }>;
}

export class FinancialMetricsTracker extends EventEmitter {
  private static instance: FinancialMetricsTracker;
  private trades: Map<string, Trade> = new Map();
  private portfolio: Map<string, PortfolioPosition> = new Map();
  private metrics: FinancialMetrics | null = null;
  private isTracking: boolean = false;
  private updateInterval: NodeJS.Timeout | null = null;
  
  // Configuración
  private config = {
    updateIntervalMs: 10000, // 10 segundos
    maxTradesInMemory: 10000,
    portfolioUpdateMs: 30000, // 30 segundos
    riskFreeRate: 0.02 // 2% anual para Sharpe ratio
  };

  private constructor() {
    super();
    this.initializeMetrics();
  }

  static getInstance(): FinancialMetricsTracker {
    if (!FinancialMetricsTracker.instance) {
      FinancialMetricsTracker.instance = new FinancialMetricsTracker();
    }
    return FinancialMetricsTracker.instance;
  }

  /**
   * Inicializar métricas base
   */
  private initializeMetrics(): void {
    this.metrics = {
      dailyProfit: 0,
      weeklyProfit: 0,
      monthlyProfit: 0,
      totalProfit: 0,
      totalVolume: 0,
      totalTrades: 0,
      successfulTrades: 0,
      failedTrades: 0,
      successRate: 0,
      averageProfit: 0,
      averageProfitPercentage: 0,
      totalGasCosts: 0,
      averageGasCost: 0,
      gasCostPercentage: 0,
      largestProfit: 0,
      largestLoss: 0,
      maxDrawdown: 0,
      sharpeRatio: 0,
      winRate: 0,
      averageExecutionTime: 0,
      totalExecutionTime: 0,
      portfolioValue: 0,
      dailyROI: 0,
      totalROI: 0,
      lastUpdated: Date.now()
    };
  }

  /**
   * Iniciar tracking de métricas
   */
  startTracking(): void {
    if (this.isTracking) {
      console.log('💰 Financial metrics tracker ya está ejecutándose');
      return;
    }

    console.log('🚀 Iniciando tracking de métricas financieras...');
    this.isTracking = true;

    // Actualizar métricas inmediatamente
    this.updateMetrics();

    // Configurar intervalo de actualización
    this.updateInterval = setInterval(() => {
      this.updateMetrics();
    }, this.config.updateIntervalMs);

    console.log(`✅ Tracking iniciado - actualizaciones cada ${this.config.updateIntervalMs}ms`);
  }

  /**
   * Detener tracking
   */
  stopTracking(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
    this.isTracking = false;
    console.log('⏹️ Financial metrics tracking detenido');
  }

  /**
   * Registrar un nuevo trade
   */
  async recordTrade(trade: Trade): Promise<void> {
    // Calcular profit y porcentaje
    const profit = trade.amountOut - trade.amountIn - trade.gasCosts;
    const profitPercentage = (profit / trade.amountIn) * 100;

    const enrichedTrade: Trade = {
      ...trade,
      profit,
      profitPercentage,
      timestamp: trade.timestamp || Date.now()
    };

    // Almacenar trade
    this.trades.set(trade.id, enrichedTrade);

    // Mantener solo los últimos N trades en memoria
    if (this.trades.size > this.config.maxTradesInMemory) {
      const oldestTrade = Array.from(this.trades.entries())
        .sort(([, a], [, b]) => a.timestamp - b.timestamp)[0];
      this.trades.delete(oldestTrade[0]);
    }

    console.log(`💰 Trade registrado: ${trade.id} | Profit: $${profit.toFixed(2)} (${profitPercentage.toFixed(2)}%)`);

    // Actualizar métricas inmediatamente
    await this.updateMetrics();

    // Verificar si necesita alerta por pérdida grande
    if (profit < -100) {
      await this.alertLargeLoss(enrichedTrade);
    }

    // Emitir evento
    this.emit('trade-recorded', enrichedTrade);
  }

  /**
   * Actualizar métricas financieras
   */
  private async updateMetrics(): Promise<void> {
    try {
      const now = Date.now();
      const trades = Array.from(this.trades.values());

      // Filtros de tiempo
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
      const monthAgo = new Date(now - 30 * 24 * 60 * 60 * 1000);

      const dailyTrades = trades.filter(t => t.timestamp >= today.getTime());
      const weeklyTrades = trades.filter(t => t.timestamp >= weekAgo.getTime());
      const monthlyTrades = trades.filter(t => t.timestamp >= monthAgo.getTime());
      const completedTrades = trades.filter(t => t.status === 'completed');
      const successfulTrades = trades.filter(t => t.status === 'completed' && t.profit > 0);

      // Calcular métricas básicas
      const totalProfit = trades.reduce((sum, t) => sum + t.profit, 0);
      const dailyProfit = dailyTrades.reduce((sum, t) => sum + t.profit, 0);
      const weeklyProfit = weeklyTrades.reduce((sum, t) => sum + t.profit, 0);
      const monthlyProfit = monthlyTrades.reduce((sum, t) => sum + t.profit, 0);
      
      const totalVolume = trades.reduce((sum, t) => sum + t.amountIn, 0);
      const totalGasCosts = trades.reduce((sum, t) => sum + t.gasCosts, 0);
      const totalExecutionTime = trades.reduce((sum, t) => sum + (t.executionTime || 0), 0);

      // Calcular ratios
      const successRate = trades.length > 0 ? (completedTrades.length / trades.length) * 100 : 0;
      const winRate = completedTrades.length > 0 ? (successfulTrades.length / completedTrades.length) * 100 : 0;
      const averageProfit = trades.length > 0 ? totalProfit / trades.length : 0;
      const averageProfitPercentage = trades.length > 0 ? 
        trades.reduce((sum, t) => sum + t.profitPercentage, 0) / trades.length : 0;
      const averageGasCost = trades.length > 0 ? totalGasCosts / trades.length : 0;
      const gasCostPercentage = totalVolume > 0 ? (totalGasCosts / totalVolume) * 100 : 0;
      const averageExecutionTime = trades.length > 0 ? totalExecutionTime / trades.length : 0;

      // Calcular largest profit/loss
      const profits = trades.map(t => t.profit);
      const largestProfit = profits.length > 0 ? Math.max(...profits) : 0;
      const largestLoss = profits.length > 0 ? Math.min(...profits) : 0;

      // Calcular max drawdown
      const maxDrawdown = this.calculateMaxDrawdown(trades);

      // Calcular Sharpe ratio
      const sharpeRatio = this.calculateSharpeRatio(trades);

      // Calcular ROI
      const initialPortfolioValue = 10000; // TODO: Obtener valor inicial real
      const portfolioValue = await this.calculatePortfolioValue();
      const totalROI = ((portfolioValue - initialPortfolioValue) / initialPortfolioValue) * 100;
      const dailyROI = dailyTrades.length > 0 ? (dailyProfit / portfolioValue) * 100 : 0;

      // Actualizar métricas
      this.metrics = {
        dailyProfit,
        weeklyProfit,
        monthlyProfit,
        totalProfit,
        totalVolume,
        totalTrades: trades.length,
        successfulTrades: successfulTrades.length,
        failedTrades: trades.filter(t => t.status === 'failed').length,
        successRate,
        averageProfit,
        averageProfitPercentage,
        totalGasCosts,
        averageGasCost,
        gasCostPercentage,
        largestProfit,
        largestLoss,
        maxDrawdown,
        sharpeRatio,
        winRate,
        averageExecutionTime,
        totalExecutionTime,
        portfolioValue,
        dailyROI,
        totalROI,
        lastUpdated: now
      };

      // Emitir evento de métricas actualizadas
      this.emit('metrics-updated', this.metrics);

    } catch (error) {
      console.error('❌ Error actualizando métricas financieras:', error);
      this.emit('metrics-error', error);
    }
  }

  /**
   * Calcular max drawdown
   */
  private calculateMaxDrawdown(trades: Trade[]): number {
    if (trades.length === 0) return 0;

    const sortedTrades = trades.sort((a, b) => a.timestamp - b.timestamp);
    let peak = 0;
    let maxDrawdown = 0;
    let currentValue = 0;

    for (const trade of sortedTrades) {
      currentValue += trade.profit;
      if (currentValue > peak) {
        peak = currentValue;
      }
      const drawdown = ((peak - currentValue) / peak) * 100;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }
    }

    return maxDrawdown;
  }

  /**
   * Calcular Sharpe ratio
   */
  private calculateSharpeRatio(trades: Trade[]): number {
    if (trades.length < 2) return 0;

    // Calcular retornos diarios
    const dailyReturns = this.calculateDailyReturns(trades);
    if (dailyReturns.length < 2) return 0;

    // Calcular promedio y desviación estándar
    const avgReturn = dailyReturns.reduce((sum, r) => sum + r, 0) / dailyReturns.length;
    const variance = dailyReturns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / (dailyReturns.length - 1);
    const stdDev = Math.sqrt(variance);

    if (stdDev === 0) return 0;

    // Sharpe ratio = (Retorno promedio - Tasa libre de riesgo) / Desviación estándar
    const dailyRiskFreeRate = this.config.riskFreeRate / 365;
    return (avgReturn - dailyRiskFreeRate) / stdDev;
  }

  /**
   * Calcular retornos diarios
   */
  private calculateDailyReturns(trades: Trade[]): number[] {
    const dailyProfits = new Map<string, number>();

    // Agrupar trades por día
    for (const trade of trades) {
      const dateKey = new Date(trade.timestamp).toDateString();
      dailyProfits.set(dateKey, (dailyProfits.get(dateKey) || 0) + trade.profit);
    }

    // Convertir a retornos porcentuales
    const portfolioValue = 10000; // TODO: Obtener valor real
    return Array.from(dailyProfits.values()).map(profit => (profit / portfolioValue) * 100);
  }

  /**
   * Calcular valor del portfolio
   */
  private async calculatePortfolioValue(): Promise<number> {
    // TODO: Implementar cálculo real del portfolio
    // Por ahora retornamos un valor simulado basado en profits
    const totalProfit = Array.from(this.trades.values()).reduce((sum, t) => sum + t.profit, 0);
    return 10000 + totalProfit; // Valor inicial + profits acumulados
  }

  /**
   * Alerta por pérdida grande
   */
  private async alertLargeLoss(trade: Trade): Promise<void> {
    console.log(`🚨 PÉRDIDA GRANDE DETECTADA: ${trade.id} | Loss: $${Math.abs(trade.profit).toFixed(2)}`);
    
    this.emit('large-loss', {
      trade,
      loss: Math.abs(trade.profit),
      timestamp: Date.now()
    });

    // TODO: Integrar con sistema de alertas
  }

  /**
   * Generar reporte de P&L
   */
  async generateProfitLossReport(period: 'daily' | 'weekly' | 'monthly' | 'yearly'): Promise<ProfitLossReport> {
    const now = Date.now();
    let startDate: number;

    switch (period) {
      case 'daily':
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        startDate = today.getTime();
        break;
      case 'weekly':
        startDate = now - 7 * 24 * 60 * 60 * 1000;
        break;
      case 'monthly':
        startDate = now - 30 * 24 * 60 * 60 * 1000;
        break;
      case 'yearly':
        startDate = now - 365 * 24 * 60 * 60 * 1000;
        break;
    }

    const trades = Array.from(this.trades.values())
      .filter(t => t.timestamp >= startDate);

    if (trades.length === 0) {
      return {
        period,
        startDate,
        endDate: now,
        totalProfit: 0,
        totalVolume: 0,
        totalTrades: 0,
        averageProfit: 0,
        bestTrade: null as any,
        worstTrade: null as any,
        profitByStrategy: {},
        profitByDex: {},
        dailyBreakdown: []
      };
    }

    // Calcular métricas básicas
    const totalProfit = trades.reduce((sum, t) => sum + t.profit, 0);
    const totalVolume = trades.reduce((sum, t) => sum + t.amountIn, 0);
    const averageProfit = totalProfit / trades.length;

    // Encontrar mejor y peor trade
    const bestTrade = trades.reduce((best, current) => 
      current.profit > best.profit ? current : best);
    const worstTrade = trades.reduce((worst, current) => 
      current.profit < worst.profit ? current : worst);

    // Profit por estrategia
    const profitByStrategy: Record<string, number> = {};
    for (const trade of trades) {
      profitByStrategy[trade.strategy] = (profitByStrategy[trade.strategy] || 0) + trade.profit;
    }

    // Profit por DEX
    const profitByDex: Record<string, number> = {};
    for (const trade of trades) {
      for (const dex of trade.dexes) {
        profitByDex[dex] = (profitByDex[dex] || 0) + trade.profit / trade.dexes.length;
      }
    }

    // Breakdown diario
    const dailyBreakdown = this.calculateDailyBreakdown(trades, startDate, now);

    return {
      period,
      startDate,
      endDate: now,
      totalProfit,
      totalVolume,
      totalTrades: trades.length,
      averageProfit,
      bestTrade,
      worstTrade,
      profitByStrategy,
      profitByDex,
      dailyBreakdown
    };
  }

  /**
   * Calcular breakdown diario
   */
  private calculateDailyBreakdown(trades: Trade[], startDate: number, endDate: number): Array<{date: string; profit: number; trades: number; volume: number}> {
    const dailyData = new Map<string, {profit: number; trades: number; volume: number}>();

    // Inicializar todos los días en el rango
    for (let date = new Date(startDate); date <= new Date(endDate); date.setDate(date.getDate() + 1)) {
      const dateKey = date.toISOString().split('T')[0];
      dailyData.set(dateKey, { profit: 0, trades: 0, volume: 0 });
    }

    // Agregar datos de trades
    for (const trade of trades) {
      const dateKey = new Date(trade.timestamp).toISOString().split('T')[0];
      const existing = dailyData.get(dateKey) || { profit: 0, trades: 0, volume: 0 };
      dailyData.set(dateKey, {
        profit: existing.profit + trade.profit,
        trades: existing.trades + 1,
        volume: existing.volume + trade.amountIn
      });
    }

    return Array.from(dailyData.entries()).map(([date, data]) => ({
      date,
      ...data
    }));
  }

  /**
   * Obtener métricas actuales
   */
  getCurrentMetrics(): FinancialMetrics | null {
    return this.metrics;
  }

  /**
   * Obtener trades recientes
   */
  getRecentTrades(limit: number = 50): Trade[] {
    return Array.from(this.trades.values())
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit);
  }

  /**
   * Obtener trade por ID
   */
  getTrade(id: string): Trade | undefined {
    return this.trades.get(id);
  }

  /**
   * Obtener estadísticas de trades
   */
  getTradeStats(): any {
    const trades = Array.from(this.trades.values());
    const strategies = new Set(trades.map(t => t.strategy));
    const dexes = new Set(trades.flatMap(t => t.dexes));

    return {
      totalTrades: trades.length,
      uniqueStrategies: strategies.size,
      uniqueDexes: dexes.size,
      averageExecutionTime: trades.reduce((sum, t) => sum + (t.executionTime || 0), 0) / trades.length,
      statusDistribution: {
        completed: trades.filter(t => t.status === 'completed').length,
        pending: trades.filter(t => t.status === 'pending').length,
        failed: trades.filter(t => t.status === 'failed').length,
        reverted: trades.filter(t => t.status === 'reverted').length
      }
    };
  }

  /**
   * Resetear métricas (para testing)
   */
  reset(): void {
    this.trades.clear();
    this.portfolio.clear();
    this.initializeMetrics();
    console.log('🔄 Financial metrics reseteadas');
  }
}

// Exportar instancia singleton
export const financialMetricsTracker = FinancialMetricsTracker.getInstance();
