/**
 * 🛡️ RESILIENT API SERVICE - ArbitrageX Pro 2025
 * Servicio de API con circuit breakers y recuperación automática
 */

import { circuitBreakerManager, CircuitBreaker } from './CircuitBreakerManager';

export interface ApiCall {
  url: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  body?: any;
  timeout?: number;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  responseTime: number;
  fromCache?: boolean;
  fromFallback?: boolean;
  serviceName: string;
  timestamp: number;
}

export interface ServiceConfig {
  name: string;
  baseUrl: string;
  apiKey?: string;
  circuitBreakerConfig?: any;
  retryConfig?: {
    maxRetries: number;
    retryDelay: number;
    exponentialBackoff: boolean;
  };
  cacheConfig?: {
    enabled: boolean;
    ttl: number; // Time to live en ms
    maxSize: number;
  };
}

export class ResilientApiService {
  private circuitBreaker: CircuitBreaker;
  private config: ServiceConfig;
  private cache: Map<string, { data: any; timestamp: number; ttl: number }> = new Map();
  private retryCount: Map<string, number> = new Map();

  constructor(config: ServiceConfig) {
    this.config = config;

    // Crear circuit breaker específico para este servicio
    this.circuitBreaker = circuitBreakerManager.createBreaker({
      name: config.name,
      failureThreshold: 5,
      resetTimeout: 30000,
      monitoringWindow: 60000,
      halfOpenMaxCalls: 3,
      healthCheckInterval: 15000,
      timeoutDuration: 10000,
      ...config.circuitBreakerConfig
    });
  }

  /**
   * Realizar llamada a API con circuit breaker
   */
  async call<T = any>(apiCall: ApiCall): Promise<ApiResponse<T>> {
    const cacheKey = this.generateCacheKey(apiCall);
    const serviceName = this.config.name;

    // Verificar cache primero
    if (this.config.cacheConfig?.enabled) {
      const cached = this.getFromCache<T>(cacheKey);
      if (cached) {
        return {
          success: true,
          data: cached,
          responseTime: 0,
          fromCache: true,
          serviceName,
          timestamp: Date.now()
        };
      }
    }

    // Ejecutar con circuit breaker
    const result = await this.circuitBreaker.execute(
      () => this.executeApiCall<T>(apiCall),
      () => this.getFallbackData<T>(apiCall)
    );

    const response: ApiResponse<T> = {
      success: result.success,
      data: result.data,
      error: result.error?.message,
      responseTime: result.responseTime,
      fromFallback: !result.success && result.data !== undefined,
      serviceName,
      timestamp: result.timestamp
    };

    // Guardar en cache si fue exitoso
    if (result.success && result.data && this.config.cacheConfig?.enabled) {
      this.saveToCache(cacheKey, result.data, this.config.cacheConfig.ttl);
    }

    return response;
  }

  /**
   * Ejecutar llamada a API con reintentos
   */
  private async executeApiCall<T>(apiCall: ApiCall): Promise<T> {
    const maxRetries = this.config.retryConfig?.maxRetries || 3;
    const retryDelay = this.config.retryConfig?.retryDelay || 1000;
    const exponentialBackoff = this.config.retryConfig?.exponentialBackoff || true;

    let lastError: Error;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        // Construir URL completa
        const url = apiCall.url.startsWith('http') 
          ? apiCall.url 
          : `${this.config.baseUrl}${apiCall.url}`;

        // Preparar headers
        const headers: Record<string, string> = {
          'Content-Type': 'application/json',
          'User-Agent': 'ArbitrageX-Pro/1.0.0',
          ...apiCall.headers
        };

        // Agregar API key si está configurada
        if (this.config.apiKey) {
          headers['Authorization'] = `Bearer ${this.config.apiKey}`;
        }

        // Preparar opciones de fetch
        const fetchOptions: RequestInit = {
          method: apiCall.method,
          headers,
          signal: AbortSignal.timeout(apiCall.timeout || 10000)
        };

        // Agregar body si es necesario
        if (apiCall.body && ['POST', 'PUT'].includes(apiCall.method)) {
          fetchOptions.body = JSON.stringify(apiCall.body);
        }

        // Realizar llamada
        const response = await fetch(url, fetchOptions);

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        
        // Resetear contador de reintentos en éxito
        this.retryCount.delete(this.generateCacheKey(apiCall));
        
        return data;

      } catch (error) {
        lastError = error as Error;
        
        // No reintentar en el último intento
        if (attempt === maxRetries) {
          break;
        }

        // Calcular delay para el siguiente intento
        const delay = exponentialBackoff 
          ? retryDelay * Math.pow(2, attempt)
          : retryDelay;

        console.warn(
          `⚠️ ${this.config.name} intento ${attempt + 1}/${maxRetries + 1} falló: ${lastError.message}. Reintentando en ${delay}ms...`
        );

        // Esperar antes del siguiente intento
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    // Registrar fallo persistente
    const cacheKey = this.generateCacheKey(apiCall);
    const currentRetries = this.retryCount.get(cacheKey) || 0;
    this.retryCount.set(cacheKey, currentRetries + 1);

    throw lastError!;
  }

  /**
   * Obtener datos de fallback
   */
  private async getFallbackData<T>(apiCall: ApiCall): Promise<T> {
    const cacheKey = this.generateCacheKey(apiCall);
    
    // Intentar cache stale como fallback
    const staleData = this.getFromCache<T>(cacheKey, true);
    if (staleData) {
      console.log(`🔄 Usando datos stale como fallback para ${this.config.name}`);
      return staleData;
    }

    // Datos por defecto según el servicio
    return this.getDefaultFallbackData<T>(apiCall);
  }

  /**
   * Obtener datos de fallback por defecto
   */
  private getDefaultFallbackData<T>(apiCall: ApiCall): T {
    const serviceName = this.config.name.toLowerCase();

    // Fallbacks específicos por servicio
    switch (serviceName) {
      case 'coingecko':
        if (apiCall.url.includes('/simple/price')) {
          return { ethereum: { usd: 2000 }, bitcoin: { usd: 40000 } } as T;
        }
        break;

      case 'binance':
        if (apiCall.url.includes('/ticker/price')) {
          return { symbol: 'ETHUSDT', price: '2000.00' } as T;
        }
        break;

      case 'ethereum-rpc':
      case 'polygon-rpc':
      case 'bsc-rpc':
        if (apiCall.body?.method === 'eth_blockNumber') {
          return { result: '0x' + (18000000).toString(16) } as T;
        }
        if (apiCall.body?.method === 'eth_gasPrice') {
          return { result: '0x' + (20000000000).toString(16) } as T; // 20 gwei
        }
        break;

      default:
        break;
    }

    // Fallback genérico
    throw new Error(`No hay datos de fallback disponibles para ${this.config.name}`);
  }

  /**
   * Gestión de cache
   */
  private getFromCache<T>(key: string, allowStale: boolean = false): T | null {
    const cached = this.cache.get(key);
    if (!cached) return null;

    const now = Date.now();
    const isExpired = now - cached.timestamp > cached.ttl;

    if (isExpired && !allowStale) {
      this.cache.delete(key);
      return null;
    }

    return cached.data as T;
  }

  private saveToCache<T>(key: string, data: T, ttl: number): void {
    // Verificar límite de tamaño del cache
    const maxSize = this.config.cacheConfig?.maxSize || 1000;
    if (this.cache.size >= maxSize) {
      // Eliminar el más antiguo
      const oldestKey = this.cache.keys().next().value;
      this.cache.delete(oldestKey);
    }

    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  private generateCacheKey(apiCall: ApiCall): string {
    const url = apiCall.url;
    const method = apiCall.method;
    const body = apiCall.body ? JSON.stringify(apiCall.body) : '';
    return `${this.config.name}:${method}:${url}:${body}`;
  }

  /**
   * Obtener métricas del servicio
   */
  getMetrics() {
    return {
      circuitBreakerState: this.circuitBreaker.getState(),
      cacheSize: this.cache.size,
      retryCounters: Object.fromEntries(this.retryCount)
    };
  }

  /**
   * Limpiar cache
   */
  clearCache(): void {
    this.cache.clear();
    console.log(`🧹 Cache limpiado para ${this.config.name}`);
  }

  /**
   * Reset del servicio
   */
  reset(): void {
    this.circuitBreaker.reset();
    this.clearCache();
    this.retryCount.clear();
    console.log(`🔄 Servicio ${this.config.name} reseteado`);
  }
}

/**
 * Factory para crear servicios resilientes
 */
export class ResilientApiServiceFactory {
  private static services: Map<string, ResilientApiService> = new Map();

  /**
   * Crear servicios para APIs comunes
   */
  static initializeCommonServices(): void {
    // CoinGecko
    this.createService({
      name: 'coingecko',
      baseUrl: 'https://api.coingecko.com/api/v3',
      circuitBreakerConfig: {
        failureThreshold: 5,
        resetTimeout: 30000,
        timeoutDuration: 5000
      },
      retryConfig: {
        maxRetries: 3,
        retryDelay: 1000,
        exponentialBackoff: true
      },
      cacheConfig: {
        enabled: true,
        ttl: 30000, // 30s
        maxSize: 500
      }
    });

    // Binance
    this.createService({
      name: 'binance',
      baseUrl: 'https://api.binance.com/api/v3',
      circuitBreakerConfig: {
        failureThreshold: 3,
        resetTimeout: 20000,
        timeoutDuration: 3000
      },
      retryConfig: {
        maxRetries: 2,
        retryDelay: 500,
        exponentialBackoff: true
      },
      cacheConfig: {
        enabled: true,
        ttl: 10000, // 10s
        maxSize: 200
      }
    });

    // The Graph
    this.createService({
      name: 'thegraph',
      baseUrl: 'https://api.thegraph.com/subgraphs/name',
      circuitBreakerConfig: {
        failureThreshold: 4,
        resetTimeout: 25000,
        timeoutDuration: 7000
      },
      retryConfig: {
        maxRetries: 3,
        retryDelay: 1500,
        exponentialBackoff: true
      },
      cacheConfig: {
        enabled: true,
        ttl: 60000, // 1 min
        maxSize: 300
      }
    });

    console.log('🛡️ Servicios resilientes inicializados');
  }

  /**
   * Crear servicio
   */
  static createService(config: ServiceConfig): ResilientApiService {
    const service = new ResilientApiService(config);
    this.services.set(config.name, service);
    return service;
  }

  /**
   * Obtener servicio
   */
  static getService(name: string): ResilientApiService | undefined {
    return this.services.get(name);
  }

  /**
   * Obtener métricas de todos los servicios
   */
  static getAllMetrics() {
    const metrics: Record<string, any> = {};
    
    for (const [name, service] of this.services) {
      metrics[name] = service.getMetrics();
    }

    return metrics;
  }

  /**
   * Reset de todos los servicios
   */
  static resetAll(): void {
    for (const [name, service] of this.services) {
      service.reset();
    }
    console.log('🔄 Todos los servicios resilientes reseteados');
  }
}

// Inicializar servicios comunes
ResilientApiServiceFactory.initializeCommonServices();

export { ResilientApiServiceFactory };
export default ResilientApiService;
