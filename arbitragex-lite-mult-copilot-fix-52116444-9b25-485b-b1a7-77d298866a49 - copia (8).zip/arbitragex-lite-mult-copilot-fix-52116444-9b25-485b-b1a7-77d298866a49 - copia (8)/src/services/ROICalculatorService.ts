/**
 * Servicio de Cálculo de ROI Neto para ArbitrageX
 * Calcula la viabilidad real de estrategias considerando gas, fees, slippage y otros costos
 */

export interface GasEstimate {
    gasPrice: number; // en gwei
    gasUsed: number;
    gasFeeUSD: number;
    gasToken: string;
    blockTime: number; // en segundos
}

export interface SlippageEstimate {
    expectedPrice: number;
    actualPrice: number;
    slippagePercentage: number;
    slippageUSD: number;
}

export interface OpportunityViability {
    isViable: boolean;
    grossValue: number;
    netValue: number;
    totalCosts: number;
    netROI: number;
    executionProbability: number;
    recommendedChain: string;
    gasOptimization: string;
}

export interface BlockchainGasProfile {
    chain: string;
    token: string;
    avgGasPrice: number; // gwei
    avgGasUsed: {
        simple: number;
        complex: number;
        flashLoan: number;
        multiHop: number;
    };
    avgGasFeeUSD: {
        simple: number;
        complex: number;
        flashLoan: number;
        multiHop: number;
    };
    blockTime: number;
    priorityFeeMultiplier: number;
    l2Optimization: boolean;
}

export class ROICalculatorService {
    private blockchainProfiles: Map<string, BlockchainGasProfile>;
    private gasPriceCache: Map<string, { price: number; timestamp: number }>;
    private cacheExpiry = 30000; // 30 segundos

    constructor() {
        this.blockchainProfiles = new Map();
        this.gasPriceCache = new Map();
        this.initializeBlockchainProfiles();
    }

    /**
     * Inicializar perfiles de gas por blockchain
     */
    private initializeBlockchainProfiles() {
        const profiles: BlockchainGasProfile[] = [
            {
                chain: 'ethereum',
                token: 'ETH',
                avgGasPrice: 32.5,
                avgGasUsed: {
                    simple: 150000,
                    complex: 300000,
                    flashLoan: 450000,
                    multiHop: 550000
                },
                avgGasFeeUSD: {
                    simple: 12.5,
                    complex: 25.0,
                    flashLoan: 37.5,
                    multiHop: 45.8
                },
                blockTime: 12,
                priorityFeeMultiplier: 1.2,
                l2Optimization: false
            },
            {
                chain: 'bsc',
                token: 'BNB',
                avgGasPrice: 4.5,
                avgGasUsed: {
                    simple: 200000,
                    complex: 350000,
                    flashLoan: 500000,
                    multiHop: 600000
                },
                avgGasFeeUSD: {
                    simple: 0.18,
                    complex: 0.32,
                    flashLoan: 0.45,
                    multiHop: 0.54
                },
                blockTime: 3,
                priorityFeeMultiplier: 1.1,
                l2Optimization: false
            },
            {
                chain: 'polygon',
                token: 'MATIC',
                avgGasPrice: 40.0,
                avgGasUsed: {
                    simple: 180000,
                    complex: 320000,
                    flashLoan: 480000,
                    multiHop: 580000
                },
                avgGasFeeUSD: {
                    simple: 0.09,
                    complex: 0.16,
                    flashLoan: 0.24,
                    multiHop: 0.29
                },
                blockTime: 2,
                priorityFeeMultiplier: 1.15,
                l2Optimization: true
            },
            {
                chain: 'arbitrum',
                token: 'ETH',
                avgGasPrice: 0.2,
                avgGasUsed: {
                    simple: 120000,
                    complex: 250000,
                    flashLoan: 380000,
                    multiHop: 450000
                },
                avgGasFeeUSD: {
                    simple: 0.06,
                    complex: 0.13,
                    flashLoan: 0.19,
                    multiHop: 0.23
                },
                blockTime: 0.25,
                priorityFeeMultiplier: 1.05,
                l2Optimization: true
            },
            {
                chain: 'optimism',
                token: 'ETH',
                avgGasPrice: 0.2,
                avgGasUsed: {
                    simple: 110000,
                    complex: 230000,
                    flashLoan: 350000,
                    multiHop: 420000
                },
                avgGasFeeUSD: {
                    simple: 0.05,
                    complex: 0.11,
                    flashLoan: 0.17,
                    multiHop: 0.21
                },
                blockTime: 0.25,
                priorityFeeMultiplier: 1.05,
                l2Optimization: true
            },
            {
                chain: 'base',
                token: 'ETH',
                avgGasPrice: 0.2,
                avgGasUsed: {
                    simple: 115000,
                    complex: 240000,
                    flashLoan: 360000,
                    multiHop: 430000
                },
                avgGasFeeUSD: {
                    simple: 0.06,
                    complex: 0.12,
                    flashLoan: 0.18,
                    multiHop: 0.22
                },
                blockTime: 0.25,
                priorityFeeMultiplier: 1.05,
                l2Optimization: true
            },
            {
                chain: 'avalanche',
                token: 'AVAX',
                avgGasPrice: 30.0,
                avgGasUsed: {
                    simple: 160000,
                    complex: 280000,
                    flashLoan: 420000,
                    multiHop: 520000
                },
                avgGasFeeUSD: {
                    simple: 0.24,
                    complex: 0.42,
                    flashLoan: 0.63,
                    multiHop: 0.78
                },
                blockTime: 2,
                priorityFeeMultiplier: 1.1,
                l2Optimization: false
            },
            {
                chain: 'fantom',
                token: 'FTM',
                avgGasPrice: 2.0,
                avgGasUsed: {
                    simple: 140000,
                    complex: 260000,
                    flashLoan: 400000,
                    multiHop: 500000
                },
                avgGasFeeUSD: {
                    simple: 0.006,
                    complex: 0.011,
                    flashLoan: 0.016,
                    multiHop: 0.020
                },
                blockTime: 1,
                priorityFeeMultiplier: 1.08,
                l2Optimization: false
            }
        ];

        profiles.forEach(profile => {
            this.blockchainProfiles.set(profile.chain, profile);
        });
    }

    /**
     * Obtener precio de gas en tiempo real desde RPC
     */
    async getRealTimeGasPrice(chain: string, rpcUrl: string): Promise<number> {
        const cacheKey = `${chain}_${rpcUrl}`;
        const cached = this.gasPriceCache.get(cacheKey);
        
        if (cached && Date.now() - cached.timestamp < this.cacheExpiry) {
            return cached.price;
        }

        try {
            const response = await fetch(rpcUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'eth_gasPrice',
                    params: [],
                    id: 1
                })
            });

            const data = await response.json();
            if (data.result) {
                const gasPriceGwei = parseInt(data.result, 16) / 1e9;
                
                this.gasPriceCache.set(cacheKey, {
                    price: gasPriceGwei,
                    timestamp: Date.now()
                });

                return gasPriceGwei;
            }
        } catch (error) {
            console.error(`Error obteniendo gas price para ${chain}:`, error);
        }

        // Fallback al perfil promedio
        const profile = this.blockchainProfiles.get(chain);
        return profile?.avgGasPrice || 20;
    }

    /**
     * Calcular gas usado basado en la estrategia
     */
    calculateGasUsed(strategy: string, complexity: 'simple' | 'complex' | 'flashLoan' | 'multiHop'): number {
        const baseGas = {
            'triangular-arbitrage': 'complex',
            'flash-loan-arbitrage': 'flashLoan',
            'cross-dex-arbitrage': 'multiHop',
            'mev-arbitrage': 'complex',
            'nft-floor-arbitrage': 'complex',
            'liquidation-arbitrage': 'simple',
            'yield-farming-arbitrage': 'multiHop',
            'cross-chain-arbitrage': 'multiHop'
        };

        const gasType = baseGas[strategy] || 'complex';
        return this.getAverageGasUsed(gasType);
    }

    /**
     * Obtener gas promedio por tipo de operación
     */
    private getAverageGasUsed(type: string): number {
        let total = 0;
        let count = 0;

        this.blockchainProfiles.forEach(profile => {
            total += profile.avgGasUsed[type];
            count++;
        });

        return Math.round(total / count);
    }

    /**
     * Calcular slippage real esperado
     */
    async calculateSlippage(
        chain: string,
        rpcUrl: string,
        tokenIn: string,
        tokenOut: string,
        amountIn: number,
        strategy: string
    ): Promise<SlippageEstimate> {
        try {
            // Simular transacción para obtener slippage real
            const response = await fetch(rpcUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'eth_call',
                    params: [{
                        to: '0x...', // DEX router address
                        data: '0x...', // Swap function data
                        value: '0x0'
                    }, 'latest'],
                    id: 1
                })
            });

            // Por ahora, usar estimaciones basadas en la estrategia
            const slippageRates = {
                'triangular-arbitrage': 0.3,
                'flash-loan-arbitrage': 0.5,
                'cross-dex-arbitrage': 0.4,
                'mev-arbitrage': 0.2,
                'nft-floor-arbitrage': 1.0,
                'liquidation-arbitrage': 0.1,
                'yield-farming-arbitrage': 0.6,
                'cross-chain-arbitrage': 0.8
            };

            const slippageRate = slippageRates[strategy] || 0.5;
            const expectedPrice = amountIn * 1.0; // Precio teórico
            const actualPrice = expectedPrice * (1 - slippageRate / 100);

            return {
                expectedPrice,
                actualPrice,
                slippagePercentage: slippageRate,
                slippageUSD: (expectedPrice - actualPrice) * 0.5 // Asumiendo precio USD promedio
            };
        } catch (error) {
            console.error('Error calculando slippage:', error);
            // Fallback a estimación conservadora
            return {
                expectedPrice: amountIn,
                actualPrice: amountIn * 0.95,
                slippagePercentage: 5.0,
                slippageUSD: amountIn * 0.025
            };
        }
    }

    /**
     * Calcular viabilidad completa de una oportunidad
     */
    async calculateOpportunityViability(
        opportunity: {
            strategy: string;
            chain: string;
            rpcUrl: string;
            grossProfit: number;
            capitalRequired: number;
            tokens: string[];
        }
    ): Promise<OpportunityViability> {
        const { strategy, chain, rpcUrl, grossProfit, capitalRequired, tokens } = opportunity;

        // 1. Obtener gas price en tiempo real
        const gasPrice = await this.getRealTimeGasPrice(chain, rpcUrl);
        
        // 2. Calcular gas usado
        const gasUsed = this.calculateGasUsed(strategy, 'complex');
        
        // 3. Calcular fee de gas en USD
        const gasFeeUSD = this.calculateGasFeeUSD(chain, gasPrice, gasUsed);
        
        // 4. Calcular slippage
        const slippage = await this.calculateSlippage(chain, rpcUrl, tokens[0], tokens[1], capitalRequired, strategy);
        
        // 5. Calcular otros costos
        const dexFees = this.calculateDEXFees(strategy, capitalRequired);
        const crossChainCosts = this.calculateCrossChainCosts(strategy, chain);
        
        // 6. Calcular valor neto
        const totalCosts = gasFeeUSD + slippage.slippageUSD + dexFees + crossChainCosts;
        const netValue = grossProfit - totalCosts;
        
        // 7. Calcular ROI neto
        const netROI = (netValue / capitalRequired) * 100;
        
        // 8. Determinar viabilidad
        const isViable = this.isOpportunityViable(netValue, totalCosts, netROI, strategy);
        
        // 9. Calcular probabilidad de ejecución
        const executionProbability = this.calculateExecutionProbability(chain, strategy, gasPrice);
        
        // 10. Recomendar blockchain optimizada
        const recommendedChain = this.recommendOptimalChain(strategy, netROI);
        
        // 11. Sugerencias de optimización de gas
        const gasOptimization = this.suggestGasOptimization(chain, strategy, gasPrice);

        return {
            isViable,
            grossValue: grossProfit,
            netValue,
            totalCosts,
            netROI,
            executionProbability,
            recommendedChain,
            gasOptimization
        };
    }

    /**
     * Calcular fee de gas en USD
     */
    private calculateGasFeeUSD(chain: string, gasPrice: number, gasUsed: number): number {
        const profile = this.blockchainProfiles.get(chain);
        if (!profile) return 0;

        // Convertir gas price de gwei a ETH
        const gasPriceETH = gasPrice / 1e9;
        
        // Calcular fee en tokens nativos
        const gasFeeNative = gasPriceETH * gasUsed;
        
        // Convertir a USD (usar precio promedio del token)
        const tokenPricesUSD = {
            'ETH': 2000,
            'BNB': 300,
            'MATIC': 0.8,
            'AVAX': 25,
            'FTM': 0.3
        };

        const tokenPrice = tokenPricesUSD[profile.token] || 1;
        return gasFeeNative * tokenPrice;
    }

    /**
     * Calcular fees de DEX
     */
    private calculateDEXFees(strategy: string, capital: number): number {
        const feeRates = {
            'triangular-arbitrage': 0.003, // 0.3%
            'flash-loan-arbitrage': 0.005, // 0.5%
            'cross-dex-arbitrage': 0.004, // 0.4%
            'mev-arbitrage': 0.002, // 0.2%
            'nft-floor-arbitrage': 0.025, // 2.5%
            'liquidation-arbitrage': 0.001, // 0.1%
            'yield-farming-arbitrage': 0.006, // 0.6%
            'cross-chain-arbitrage': 0.008 // 0.8%
        };

        const feeRate = feeRates[strategy] || 0.005;
        return capital * feeRate;
    }

    /**
     * Calcular costos cross-chain
     */
    private calculateCrossChainCosts(strategy: string, chain: string): number {
        if (strategy !== 'cross-chain-arbitrage') return 0;

        const bridgeCosts = {
            'ethereum': 15, // USD
            'bsc': 5,
            'polygon': 2,
            'arbitrum': 1,
            'optimism': 1,
            'base': 1,
            'avalanche': 3,
            'fantom': 1
        };

        return bridgeCosts[chain] || 5;
    }

    /**
     * Determinar si una oportunidad es viable
     */
    private isOpportunityViable(netValue: number, totalCosts: number, netROI: number, strategy: string): boolean {
        // Factor de margen mínimo (1.5x - 2x)
        const minMarginFactor = 1.5;
        
        // ROI mínimo por estrategia
        const minROI = {
            'triangular-arbitrage': 2.0,
            'flash-loan-arbitrage': 3.0,
            'cross-dex-arbitrage': 2.5,
            'mev-arbitrage': 1.5,
            'nft-floor-arbitrage': 5.0,
            'liquidation-arbitrage': 1.0,
            'yield-farming-arbitrage': 4.0,
            'cross-chain-arbitrage': 6.0
        };

        const requiredROI = minROI[strategy] || 2.0;
        
        // Verificar margen mínimo
        const hasMinMargin = netValue > (totalCosts * minMarginFactor);
        
        // Verificar ROI mínimo
        const hasMinROI = netROI >= requiredROI;
        
        // Verificar que sea positivo
        const isPositive = netValue > 0;

        return hasMinMargin && hasMinROI && isPositive;
    }

    /**
     * Calcular probabilidad de ejecución exitosa
     */
    private calculateExecutionProbability(chain: string, strategy: string, gasPrice: number): number {
        const profile = this.blockchainProfiles.get(chain);
        if (!profile) return 0;

        // Base probability por blockchain
        let baseProbability = 0.8;

        // Ajustar por velocidad de bloque
        if (profile.blockTime < 1) baseProbability += 0.1;
        else if (profile.blockTime > 10) baseProbability -= 0.2;

        // Ajustar por optimización L2
        if (profile.l2Optimization) baseProbability += 0.1;

        // Ajustar por gas price (precios altos = menor probabilidad)
        const gasPriceFactor = Math.max(0, 1 - (gasPrice / 100));
        baseProbability *= gasPriceFactor;

        // Ajustar por estrategia
        const strategyFactors = {
            'triangular-arbitrage': 0.9,
            'flash-loan-arbitrage': 0.7,
            'cross-dex-arbitrage': 0.8,
            'mev-arbitrage': 0.6,
            'nft-floor-arbitrage': 0.5,
            'liquidation-arbitrage': 0.9,
            'yield-farming-arbitrage': 0.7,
            'cross-chain-arbitrage': 0.4
        };

        const strategyFactor = strategyFactors[strategy] || 0.8;
        baseProbability *= strategyFactor;

        return Math.min(0.95, Math.max(0.05, baseProbability));
    }

    /**
     * Recomendar blockchain óptima
     */
    private recommendOptimalChain(strategy: string, netROI: number): string {
        const chainRecommendations = {
            'triangular-arbitrage': ['arbitrum', 'optimism', 'base', 'polygon'],
            'flash-loan-arbitrage': ['arbitrum', 'bsc', 'polygon'],
            'cross-dex-arbitrage': ['arbitrum', 'optimism', 'base'],
            'mev-arbitrage': ['arbitrum', 'base', 'optimism'],
            'nft-floor-arbitrage': ['ethereum', 'polygon'],
            'liquidation-arbitrage': ['arbitrum', 'base', 'optimism'],
            'yield-farming-arbitrage': ['polygon', 'bsc', 'avalanche'],
            'cross-chain-arbitrage': ['arbitrum', 'base', 'optimism']
        };

        const recommendations = chainRecommendations[strategy] || ['arbitrum', 'polygon'];
        return recommendations[0];
    }

    /**
     * Sugerir optimizaciones de gas
     */
    private suggestGasOptimization(chain: string, strategy: string, gasPrice: number): string {
        const profile = this.blockchainProfiles.get(chain);
        if (!profile) return 'No se pudo determinar optimización';

        if (gasPrice > profile.avgGasPrice * 1.5) {
            return `Gas price alto (${gasPrice.toFixed(1)} gwei). Considerar esperar o usar ${this.recommendOptimalChain(strategy, 0)}`;
        }

        if (profile.l2Optimization) {
            return `L2 optimizado. Usar priority fee de ${profile.priorityFeeMultiplier}x para ejecución rápida`;
        }

        if (chain === 'ethereum' && gasPrice > 30) {
            return 'Ethereum mainnet congestionado. Considerar L2s o sidechains';
        }

        return 'Gas price óptimo. Ejecutar con priority fee estándar';
    }

    /**
     * Obtener análisis completo de viabilidad por estrategia
     */
    async getStrategyViabilityAnalysis(): Promise<Map<string, any>> {
        const analysis = new Map();

        for (const [chain, profile] of this.blockchainProfiles) {
            for (const strategy of [
                'triangular-arbitrage',
                'flash-loan-arbitrage',
                'cross-dex-arbitrage',
                'mev-arbitrage',
                'nft-floor-arbitrage',
                'liquidation-arbitrage',
                'yield-farming-arbitrage',
                'cross-chain-arbitrage'
            ]) {
                const key = `${strategy}_${chain}`;
                
                // Simular oportunidad con capital mínimo
                const minCapital = this.getMinimumCapital(strategy);
                const grossProfit = minCapital * 0.02; // 2% profit típico

                const viability = await this.calculateOpportunityViability({
                    strategy,
                    chain,
                    rpcUrl: 'simulated',
                    grossProfit,
                    capitalRequired: minCapital,
                    tokens: ['TOKEN1', 'TOKEN2']
                });

                analysis.set(key, {
                    strategy,
                    chain,
                    minCapital,
                    viability,
                    gasProfile: profile
                });
            }
        }

        return analysis;
    }

    /**
     * Obtener capital mínimo por estrategia
     */
    private getMinimumCapital(strategy: string): number {
        const minCapitals = {
            'triangular-arbitrage': 100,
            'flash-loan-arbitrage': 50,
            'cross-dex-arbitrage': 200,
            'mev-arbitrage': 500,
            'nft-floor-arbitrage': 1000,
            'liquidation-arbitrage': 100,
            'yield-farming-arbitrage': 300,
            'cross-chain-arbitrage': 500
        };

        return minCapitals[strategy] || 100;
    }

    /**
     * Obtener métricas de gas en tiempo real
     */
    async getRealTimeGasMetrics(chain: string): Promise<{
        currentGasPrice: number;
        avgGasPrice: number;
        gasTrend: 'increasing' | 'decreasing' | 'stable';
        recommendedAction: string;
    }> {
        const profile = this.blockchainProfiles.get(chain);
        if (!profile) {
            throw new Error(`Blockchain ${chain} no soportada`);
        }

        // Simular obtención de gas price en tiempo real
        const currentGasPrice = profile.avgGasPrice * (0.8 + Math.random() * 0.4);
        
        const gasTrend = currentGasPrice > profile.avgGasPrice * 1.1 ? 'increasing' :
                        currentGasPrice < profile.avgGasPrice * 0.9 ? 'decreasing' : 'stable';

        let recommendedAction = '';
        if (gasTrend === 'increasing') {
            recommendedAction = 'Gas price subiendo. Considerar esperar o usar L2s';
        } else if (gasTrend === 'decreasing') {
            recommendedAction = 'Gas price bajando. Momento óptimo para ejecutar';
        } else {
            recommendedAction = 'Gas price estable. Ejecutar cuando sea conveniente';
        }

        return {
            currentGasPrice,
            avgGasPrice: profile.avgGasPrice,
            gasTrend,
            recommendedAction
        };
    }
}

export default ROICalculatorService;
