import { EventEmitter } from 'events'

/**
 * @title NotificationQueue
 * @description Sistema de colas de notificaciones para prevenir race conditions
 * @author ArbitrageX Security Team 2025
 */
export interface NotificationMessage {
  id: string
  type: 'critical' | 'high' | 'medium' | 'low'
  title: string
  message: string
  userId?: string
  timestamp: Date
  priority: number
  channels: string[]
  retryCount: number
  maxRetries: number
  status: 'pending' | 'processing' | 'sent' | 'failed'
}

export class NotificationQueue extends EventEmitter {
  private static instance: NotificationQueue
  private queue: NotificationMessage[] = []
  private processing: Set<string> = new Set()
  private locks: Map<string, boolean> = new Map()
  private isProcessing = false
  private maxConcurrent = 5
  private currentProcessing = 0

  private constructor() {
    super()
    this.startProcessing()
  }

  /**
   * Obtener instancia singleton
   */
  public static getInstance(): NotificationQueue {
    if (!NotificationQueue.instance) {
      NotificationQueue.instance = new NotificationQueue()
    }
    return NotificationQueue.instance
  }

  /**
   * Agregar notificación a la cola
   */
  public async addNotification(notification: Omit<NotificationMessage, 'id' | 'timestamp' | 'retryCount' | 'status'>): Promise<string> {
    const id = this.generateId()
    const message: NotificationMessage = {
      ...notification,
      id,
      timestamp: new Date(),
      retryCount: 0,
      status: 'pending'
    }

    // Verificar si ya existe una notificación similar para evitar duplicados
    const existingIndex = this.queue.findIndex(n => 
      n.type === message.type && 
      n.title === message.title && 
      n.userId === message.userId &&
      Date.now() - n.timestamp.getTime() < 5000 // 5 segundos
    )

    if (existingIndex !== -1) {
      console.warn('Duplicate notification detected, skipping:', message.title)
      return this.queue[existingIndex].id
    }

    // Agregar a la cola con prioridad
    this.insertWithPriority(message)
    
    this.emit('notificationAdded', message)
    return id
  }

  /**
   * Insertar notificación con prioridad
   */
  private insertWithPriority(message: NotificationMessage): void {
    const insertIndex = this.queue.findIndex(n => n.priority < message.priority)
    
    if (insertIndex === -1) {
      this.queue.push(message)
    } else {
      this.queue.splice(insertIndex, 0, message)
    }
  }

  /**
   * Obtener siguiente notificación de la cola
   */
  private getNextNotification(): NotificationMessage | null {
    if (this.queue.length === 0) return null
    
    // Buscar la notificación de mayor prioridad que no esté siendo procesada
    for (let i = 0; i < this.queue.length; i++) {
      const notification = this.queue[i]
      if (!this.processing.has(notification.id) && !this.isLocked(notification.id)) {
        return notification
      }
    }
    
    return null
  }

  /**
   * Verificar si una notificación está bloqueada
   */
  private isLocked(id: string): boolean {
    return this.locks.get(id) || false
  }

  /**
   * Bloquear notificación
   */
  private lockNotification(id: string): void {
    this.locks.set(id, true)
  }

  /**
   * Desbloquear notificación
   */
  private unlockNotification(id: string): void {
    this.locks.delete(id)
  }

  /**
   * Iniciar procesamiento de la cola
   */
  private startProcessing(): void {
    setInterval(() => {
      this.processQueue()
    }, 100) // Procesar cada 100ms
  }

  /**
   * Procesar cola de notificaciones
   */
  private async processQueue(): Promise<void> {
    if (this.isProcessing || this.currentProcessing >= this.maxConcurrent) {
      return
    }

    this.isProcessing = true

    try {
      while (this.currentProcessing < this.maxConcurrent) {
        const notification = this.getNextNotification()
        
        if (!notification) {
          break
        }

        this.currentProcessing++
        this.processing.add(notification.id)
        this.lockNotification(notification.id)

        // Procesar notificación en background
        this.processNotification(notification).finally(() => {
          this.currentProcessing--
          this.processing.delete(notification.id)
          this.unlockNotification(notification.id)
        })
      }
    } finally {
      this.isProcessing = false
    }
  }

  /**
   * Procesar notificación individual
   */
  private async processNotification(notification: NotificationMessage): Promise<void> {
    try {
      // Actualizar estado
      notification.status = 'processing'
      this.emit('notificationProcessing', notification)

      // Simular envío de notificación
      await this.sendNotification(notification)

      // Marcar como enviada
      notification.status = 'sent'
      this.removeFromQueue(notification.id)
      
      this.emit('notificationSent', notification)

    } catch (error) {
      console.error('Error processing notification:', error)
      
      notification.retryCount++
      notification.status = 'failed'

      if (notification.retryCount >= notification.maxRetries) {
        // Eliminar de la cola después de máximo reintentos
        this.removeFromQueue(notification.id)
        this.emit('notificationFailed', notification)
      } else {
        // Reintentar más tarde
        setTimeout(() => {
          notification.status = 'pending'
          this.emit('notificationRetry', notification)
        }, Math.pow(2, notification.retryCount) * 1000) // Exponential backoff
      }
    }
  }

  /**
   * Enviar notificación
   */
  private async sendNotification(notification: NotificationMessage): Promise<void> {
    // Simular delay de red
    await new Promise(resolve => setTimeout(resolve, 100 + Math.random() * 200))

    // Simular diferentes canales
    for (const channel of notification.channels) {
      await this.sendToChannel(channel, notification)
    }
  }

  /**
   * Enviar a canal específico
   */
  private async sendToChannel(channel: string, notification: NotificationMessage): Promise<void> {
    switch (channel) {
      case 'email':
        await this.sendEmail(notification)
        break
      case 'telegram':
        await this.sendTelegram(notification)
        break
      case 'discord':
        await this.sendDiscord(notification)
        break
      case 'push':
        await this.sendPush(notification)
        break
      case 'sms':
        await this.sendSMS(notification)
        break
      default:
        console.warn('Unknown channel:', channel)
    }
  }

  /**
   * Enviar email
   */
  private async sendEmail(notification: NotificationMessage): Promise<void> {
    // Implementar envío de email
    console.log('Sending email:', notification.title)
  }

  /**
   * Enviar Telegram
   */
  private async sendTelegram(notification: NotificationMessage): Promise<void> {
    // Implementar envío a Telegram
    console.log('Sending Telegram:', notification.title)
  }

  /**
   * Enviar Discord
   */
  private async sendDiscord(notification: NotificationMessage): Promise<void> {
    // Implementar envío a Discord
    console.log('Sending Discord:', notification.title)
  }

  /**
   * Enviar Push
   */
  private async sendPush(notification: NotificationMessage): Promise<void> {
    // Implementar push notification
    console.log('Sending Push:', notification.title)
  }

  /**
   * Enviar SMS
   */
  private async sendSMS(notification: NotificationMessage): Promise<void> {
    // Implementar envío de SMS
    console.log('Sending SMS:', notification.title)
  }

  /**
   * Remover notificación de la cola
   */
  private removeFromQueue(id: string): void {
    const index = this.queue.findIndex(n => n.id === id)
    if (index !== -1) {
      this.queue.splice(index, 1)
    }
  }

  /**
   * Generar ID único
   */
  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
  }

  /**
   * Obtener estadísticas de la cola
   */
  public getQueueStats(): {
    total: number
    pending: number
    processing: number
    sent: number
    failed: number
    currentProcessing: number
  } {
    const stats = {
      total: this.queue.length,
      pending: 0,
      processing: 0,
      sent: 0,
      failed: 0,
      currentProcessing: this.currentProcessing
    }

    this.queue.forEach(notification => {
      switch (notification.status) {
        case 'pending':
          stats.pending++
          break
        case 'processing':
          stats.processing++
          break
        case 'sent':
          stats.sent++
          break
        case 'failed':
          stats.failed++
          break
      }
    })

    return stats
  }

  /**
   * Limpiar cola
   */
  public clearQueue(): void {
    this.queue = []
    this.processing.clear()
    this.locks.clear()
    this.currentProcessing = 0
    this.emit('queueCleared')
  }

  /**
   * Obtener notificaciones por tipo
   */
  public getNotificationsByType(type: string): NotificationMessage[] {
    return this.queue.filter(n => n.type === type)
  }

  /**
   * Obtener notificaciones por usuario
   */
  public getNotificationsByUser(userId: string): NotificationMessage[] {
    return this.queue.filter(n => n.userId === userId)
  }

  /**
   * Cancelar notificación
   */
  public cancelNotification(id: string): boolean {
    const index = this.queue.findIndex(n => n.id === id)
    if (index !== -1) {
      const notification = this.queue[index]
      this.queue.splice(index, 1)
      this.processing.delete(id)
      this.locks.delete(id)
      this.emit('notificationCancelled', notification)
      return true
    }
    return false
  }
}

/**
 * Cliente de notificaciones para uso en la aplicación
 */
export class NotificationClient {
  private static queue = NotificationQueue.getInstance()

  /**
   * Enviar notificación crítica
   */
  public static async sendCritical(title: string, message: string, userId?: string, channels: string[] = ['email', 'telegram', 'discord']): Promise<string> {
    return this.queue.addNotification({
      type: 'critical',
      title,
      message,
      userId,
      priority: 100,
      channels,
      maxRetries: 5
    })
  }

  /**
   * Enviar notificación alta
   */
  public static async sendHigh(title: string, message: string, userId?: string, channels: string[] = ['email', 'telegram']): Promise<string> {
    return this.queue.addNotification({
      type: 'high',
      title,
      message,
      userId,
      priority: 80,
      channels,
      maxRetries: 3
    })
  }

  /**
   * Enviar notificación media
   */
  public static async sendMedium(title: string, message: string, userId?: string, channels: string[] = ['email']): Promise<string> {
    return this.queue.addNotification({
      type: 'medium',
      title,
      message,
      userId,
      priority: 60,
      channels,
      maxRetries: 2
    })
  }

  /**
   * Enviar notificación baja
   */
  public static async sendLow(title: string, message: string, userId?: string, channels: string[] = ['email']): Promise<string> {
    return this.queue.addNotification({
      type: 'low',
      title,
      message,
      userId,
      priority: 40,
      channels,
      maxRetries: 1
    })
  }

  /**
   * Obtener estadísticas
   */
  public static getStats() {
    return this.queue.getQueueStats()
  }
} 