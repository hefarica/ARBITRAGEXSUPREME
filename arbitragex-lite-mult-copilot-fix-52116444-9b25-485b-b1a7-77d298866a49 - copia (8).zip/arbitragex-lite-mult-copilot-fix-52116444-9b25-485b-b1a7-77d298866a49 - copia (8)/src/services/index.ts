// services/index.ts
/**
 * Barrel exports para servicios REALES
 */

export { realDataService } from './RealDataService';
export { realStrategyService } from './RealStrategyService';

export type { 
  RealOpportunity, 
  BlockchainConnection, 
  DEXData 
} from './RealDataService';

export type { 
  StrategyExecution, 
  StrategyDefinition 
} from './RealStrategyService';