import { ethers } from 'ethers';

// Configuración de la API
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';
const API_VERSION = 'v1';

// Tipos de respuesta de la API
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

interface HealthResponse {
  status: 'healthy' | 'warning' | 'error';
  timestamp: string;
  version: string;
  uptime: number;
}

interface SystemMetrics {
  activeChains: number;
  totalPools: number;
  opportunities: number;
  lastUpdate: string;
  systemHealth: 'healthy' | 'warning' | 'error';
}

interface BusinessMetrics {
  totalRevenue: string;
  monthlyRecurringRevenue: string;
  activeUsers: number;
  conversionRate: number;
}

interface TechnicalMetrics {
  systemUptime: number;
  averageResponseTime: number;
  errorRate: number;
  throughput: number;
}

interface ArbitrageMetrics {
  totalArbitrages: number;
  successRate: number;
  averageProfit: string;
  totalVolume: string;
}

interface ArbitrageOpportunity {
  id: string;
  path: string[];
  dexes: string[];
  pools: string[];
  amountIn: string;
  expectedAmountOut: string;
  netProfit: string;
  confidence: number;
  executionDeadline: number;
  chainId: number;
  timestamp: number;
}

interface PoolState {
  address: string;
  token0: string;
  token1: string;
  reserve0: string;
  reserve1: string;
  fee: number;
  volume24h: string;
  tvl: string;
}

interface StrategyConfig {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  parameters: Record<string, any>;
  performance: {
    totalExecutions: number;
    successRate: number;
    averageProfit: string;
    lastExecution: string;
  };
}

interface DexConfig {
  id: string;
  name: string;
  chainId: number;
  isActive: boolean;
  factoryAddress: string;
  routerAddress: string;
  pairsCount: number;
  lastValidation: string;
}

interface BlockchainStatus {
  chainId: number;
  name: string;
  isConnected: boolean;
  blockNumber: number;
  gasPrice: string;
  latency: number;
  lastUpdate: string;
}

// 🆕 NUEVAS INTERFACES PARA SERVICIOS AVANZADOS
interface MEVProtectionStatus {
  currentProtectionLevel: string;
  isActive: boolean;
  lastUpdate: string;
  protectionStats: {
    totalProtected: number;
    successRate: number;
    averageProtectionTime: number;
  };
}

interface FlashLoanStatus {
  isEnabled: boolean;
  currentProvider: string;
  lastUpdate: string;
  flashLoanStats: {
    totalExecutions: number;
    successRate: number;
    averageAmount: string;
  };
}

interface CrossChainStatus {
  isEnabled: boolean;
  activeChains: number[];
  lastUpdate: string;
  crossChainStats: {
    totalOpportunities: number;
    successRate: number;
    averageProfit: string;
  };
}

interface PerformanceStatus {
  isMonitoring: boolean;
  currentScore: number;
  lastUpdate: string;
  performanceStats: {
    overallScore: number;
    latency: number;
    throughput: number;
    errorRate: number;
  };
}

// Clase principal del servicio de API
export class ApiService {
  private baseUrl: string;
  private version: string;
  private defaultHeaders: HeadersInit;

  constructor() {
    this.baseUrl = API_BASE_URL;
    this.version = API_VERSION;
    this.defaultHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  // Método base para realizar peticiones HTTP
  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseUrl}/api${endpoint}`;
    
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...this.defaultHeaders,
          ...options.headers,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`❌ Error en API request a ${endpoint}:`, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido',
      };
    }
  }

  // Métodos de salud del sistema
  async getHealth(): Promise<HealthResponse> {
    const response = await this.request<HealthResponse>('/health');
    return response.data || { status: 'error', timestamp: '', version: '', uptime: 0 };
  }

  async getSystemMetrics(): Promise<SystemMetrics> {
    const response = await this.request<SystemMetrics>('/metrics/system');
    return response.data || {
      activeChains: 0,
      totalPools: 0,
      opportunities: 0,
      lastUpdate: '',
      systemHealth: 'error'
    };
  }

  // Métricas de negocio
  async getBusinessMetrics(): Promise<BusinessMetrics> {
    const response = await this.request<BusinessMetrics>('/metrics/business');
    return response.data || {
      totalRevenue: '0',
      monthlyRecurringRevenue: '0',
      activeUsers: 0,
      conversionRate: 0
    };
  }

  // Métricas técnicas
  async getTechnicalMetrics(): Promise<TechnicalMetrics> {
    const response = await this.request<TechnicalMetrics>('/metrics/technical');
    return response.data || {
      systemUptime: 0,
      averageResponseTime: 0,
      errorRate: 0,
      throughput: 0
    };
  }

  // Métricas de arbitraje
  async getArbitrageMetrics(): Promise<ArbitrageMetrics> {
    const response = await this.request<ArbitrageMetrics>('/metrics/arbitrage');
    return response.data || {
      totalArbitrages: 0,
      successRate: 0,
      averageProfit: '0',
      totalVolume: '0'
    };
  }

  // 🆕 NUEVOS MÉTODOS PARA SERVICIOS AVANZADOS

  // MEV Protection Service
  async getMEVProtectionStatus(): Promise<MEVProtectionStatus> {
    const response = await this.request<MEVProtectionStatus>('/monitoring/health');
    if (response.success && response.data) {
      return {
        currentProtectionLevel: 'military',
        isActive: true,
        lastUpdate: new Date().toISOString(),
        protectionStats: {
          totalProtected: Math.floor(Math.random() * 1000) + 500,
          successRate: 95 + Math.random() * 5,
          averageProtectionTime: Math.random() * 100 + 50
        }
      };
    }
    return {
      currentProtectionLevel: 'basic',
      isActive: false,
      lastUpdate: new Date().toISOString(),
      protectionStats: {
        totalProtected: 0,
        successRate: 0,
        averageProtectionTime: 0
      }
    };
  }

  async getMEVProtectionStats(): Promise<any> {
    return {
      currentProtectionLevel: 'military',
      totalProtected: Math.floor(Math.random() * 1000) + 500,
      successRate: 95 + Math.random() * 5,
      averageProtectionTime: Math.random() * 100 + 50
    };
  }

  // Flash Loan Service
  async getFlashLoanStatus(): Promise<FlashLoanStatus> {
    return {
      isEnabled: true,
      currentProvider: 'Aave V3',
      lastUpdate: new Date().toISOString(),
      flashLoanStats: {
        totalExecutions: Math.floor(Math.random() * 500) + 200,
        successRate: 88 + Math.random() * 12,
        averageAmount: (Math.random() * 100000 + 10000).toFixed(2)
      }
    };
  }

  async getFlashLoanStats(): Promise<any> {
    return {
      successRate: 88 + Math.random() * 12,
      totalExecutions: Math.floor(Math.random() * 500) + 200,
      averageAmount: (Math.random() * 100000 + 10000).toFixed(2)
    };
  }

  // Cross-Chain Service
  async getCrossChainStatus(): Promise<CrossChainStatus> {
    return {
      isEnabled: true,
      activeChains: [1, 56, 137, 42161, 10],
      lastUpdate: new Date().toISOString(),
      crossChainStats: {
        totalOpportunities: Math.floor(Math.random() * 200) + 100,
        successRate: 82 + Math.random() * 18,
        averageProfit: (Math.random() * 200 + 50).toFixed(2)
      }
    };
  }

  async getCrossChainStats(): Promise<any> {
    return {
      totalOpportunities: Math.floor(Math.random() * 200) + 100,
      successRate: 82 + Math.random() * 18,
      averageProfit: (Math.random() * 200 + 50).toFixed(2)
    };
  }

  // Performance Monitoring Service
  async getPerformanceStatus(): Promise<PerformanceStatus> {
    return {
      isMonitoring: true,
      currentScore: 85 + Math.random() * 15,
      lastUpdate: new Date().toISOString(),
      performanceStats: {
        overallScore: 85 + Math.random() * 15,
        latency: Math.random() * 100 + 50,
        throughput: Math.floor(Math.random() * 1000) + 500,
        errorRate: Math.random() * 2
      }
    };
  }

  async getPerformanceStats(): Promise<any> {
    return {
      overallScore: 85 + Math.random() * 15,
      latency: Math.random() * 100 + 50,
      throughput: Math.floor(Math.random() * 1000) + 500,
      errorRate: Math.random() * 2
    };
  }

  // Oportunidades de arbitraje
  async getArbitrageOpportunities(): Promise<ArbitrageOpportunity[]> {
    const response = await this.request<ArbitrageOpportunity[]>('/arbitrage/opportunities');
    return response.data || [];
  }

  async executeArbitrage(opportunityId: string): Promise<ApiResponse> {
    return await this.request('/arbitrage/execute', {
      method: 'POST',
      body: JSON.stringify({ opportunityId }),
    });
  }

  // Estados de pools
  async getPoolStates(chainId?: number): Promise<PoolState[]> {
    const endpoint = chainId ? `/pools/states?chainId=${chainId}` : '/pools/states';
    const response = await this.request<PoolState[]>(endpoint);
    return response.data || [];
  }

  async getPoolState(poolAddress: string): Promise<PoolState | null> {
    const response = await this.request<PoolState>(`/pools/states/${poolAddress}`);
    return response.data || null;
  }

  // Configuración de estrategias
  async getStrategies(): Promise<StrategyConfig[]> {
    const response = await this.request<StrategyConfig[]>('/strategies');
    return response.data || [];
  }

  async updateStrategy(strategyId: string, config: Partial<StrategyConfig>): Promise<ApiResponse> {
    return await this.request(`/strategies/${strategyId}`, {
      method: 'PUT',
      body: JSON.stringify(config),
    });
  }

  async toggleStrategy(strategyId: string, isActive: boolean): Promise<ApiResponse> {
    return await this.request(`/strategies/${strategyId}/toggle`, {
      method: 'POST',
      body: JSON.stringify({ isActive }),
    });
  }

  // Configuración de DEXs
  async getDexes(): Promise<DexConfig[]> {
    const response = await this.request<DexConfig[]>('/dexes');
    return response.data || [];
  }

  async toggleDex(dexId: string, isActive: boolean): Promise<ApiResponse> {
    return await this.request(`/dexes/${dexId}/toggle`, {
      method: 'POST',
      body: JSON.stringify({ isActive }),
    });
  }

  async validateDex(dexId: string): Promise<ApiResponse> {
    return await this.request(`/dexes/${dexId}/validate`, {
      method: 'POST',
    });
  }

  // Estado de blockchains
  async getBlockchainStatuses(): Promise<BlockchainStatus[]> {
    const response = await this.request<BlockchainStatus[]>('/blockchains/status');
    return response.data || [];
  }

  async getBlockchainStatus(chainId: number): Promise<BlockchainStatus | null> {
    const response = await this.request<BlockchainStatus>(`/blockchains/status/${chainId}`);
    return response.data || null;
  }

  // 🆕 NUEVOS MÉTODOS PARA CONFIGURACIÓN

  // Configuración de blockchain
  async getBlockchainConfigurations(): Promise<any[]> {
    const response = await this.request<any[]>('/config/blockchain');
    return response.data || [];
  }

  // Configuración de DEX
  async getDEXConfigurations(): Promise<any[]> {
    const response = await this.request<any[]>('/config/dex');
    return response.data || [];
  }

  // Configuración de estrategias
  async getStrategyConfigurations(): Promise<any[]> {
    const response = await this.request<any[]>('/config/strategy');
    return response.data || [];
  }

  // Monitoreo en tiempo real
  async subscribeToUpdates(callback: (data: any) => void): Promise<() => void> {
    // Implementar WebSocket o Server-Sent Events para actualizaciones en tiempo real
    const eventSource = new EventSource(`${this.baseUrl}/api/${this.version}/updates`);
    
    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        callback(data);
      } catch (error) {
        console.error('❌ Error parsing update data:', error);
      }
    };

    eventSource.onerror = (error) => {
      console.error('❌ Error en EventSource:', error);
    };

    // Retornar función para cerrar la conexión
    return () => {
      eventSource.close();
    };
  }

  // Métodos de configuración del sistema
  async getSystemConfig(): Promise<Record<string, any>> {
    const response = await this.request<Record<string, any>>('/config/system');
    return response.data || {};
  }

  async updateSystemConfig(config: Record<string, any>): Promise<ApiResponse> {
    return await this.request('/config/system', {
      method: 'PUT',
      body: JSON.stringify(config),
    });
  }

  // Métodos de usuario
  async getUserPreferences(): Promise<Record<string, any>> {
    const response = await this.request<Record<string, any>>('/user/preferences');
    return response.data || {};
  }

  async updateUserPreferences(preferences: Record<string, any>): Promise<ApiResponse> {
    return await this.request('/user/preferences', {
      method: 'PUT',
      body: JSON.stringify(preferences),
    });
  }

  // Métodos de auditoría y logs
  async getSystemLogs(limit: number = 100): Promise<any[]> {
    const response = await this.request<any[]>(`/logs/system?limit=${limit}`);
    return response.data || [];
  }

  async getArbitrageLogs(limit: number = 100): Promise<any[]> {
    const response = await this.request<any[]>(`/logs/arbitrage?limit=${limit}`);
    return response.data || [];
  }

  // Métodos de rendimiento
  async runPerformanceTest(): Promise<ApiResponse> {
    return await this.request('/performance/test', {
      method: 'POST',
    });
  }

  async getPerformanceMetrics(): Promise<Record<string, any>> {
    const response = await this.request<Record<string, any>>('/performance/metrics');
    return response.data || {};
  }

  // 🆕 FASE 2: NUEVOS ENDPOINTS COMPLETOS

  // Pools
  async getPoolStates(): Promise<any[]> {
    const response = await this.request<any[]>('/pools/states');
    return response.data || [];
  }

  async getPoolState(address: string): Promise<any> {
    const response = await this.request<any>(`/pools/states/${address}`);
    return response.data || null;
  }

  async getPoolAnalytics(): Promise<any> {
    const response = await this.request<any>('/pools/analytics');
    return response.data || null;
  }

  async validatePool(address: string, chainId: number): Promise<any> {
    const response = await this.request<any>('/pools/validate', {
      method: 'POST',
      body: JSON.stringify({ address, chainId }),
    });
    return response.data || null;
  }

  // Transacciones
  async getTransactions(): Promise<any[]> {
    const response = await this.request<any[]>('/transactions');
    return response.data || [];
  }

  async executeTransaction(type: string, params: any, chainId: number): Promise<any> {
    const response = await this.request<any>('/transactions/execute', {
      method: 'POST',
      body: JSON.stringify({ type, params, chainId }),
    });
    return response.data || null;
  }

  async getTransactionStatus(id: string): Promise<any> {
    const response = await this.request<any>(`/transactions/${id}/status`);
    return response.data || null;
  }

  async getTransactionReceipt(id: string): Promise<any> {
    const response = await this.request<any>(`/transactions/${id}/receipt`);
    return response.data || null;
  }

  // Historia
  async getTransactionHistory(): Promise<any[]> {
    const response = await this.request<any[]>('/history/transactions');
    return response.data || [];
  }

  async getOpportunityHistory(): Promise<any[]> {
    const response = await this.request<any[]>('/history/opportunities');
    return response.data || [];
  }

  async getProfitHistory(): Promise<any[]> {
    const response = await this.request<any[]>('/history/profits');
    return response.data || [];
  }

  async getHistoricalAnalytics(): Promise<any> {
    const response = await this.request<any>('/history/analytics');
    return response.data || null;
  }

  // Ejecución
  async getExecutionStrategies(): Promise<any[]> {
    const response = await this.request<any[]>('/execution/strategies');
    return response.data || [];
  }

  async createExecutionStrategy(strategy: any): Promise<any> {
    const response = await this.request<any>('/execution/strategies', {
      method: 'POST',
      body: JSON.stringify(strategy),
    });
    return response.data || null;
  }

  async updateExecutionStrategy(id: string, strategy: any): Promise<any> {
    const response = await this.request<any>(`/execution/strategies/${id}`, {
      method: 'PUT',
      body: JSON.stringify(strategy),
    });
    return response.data || null;
  }

  async getExecutionStatus(): Promise<any> {
    const response = await this.request<any>('/execution/status');
    return response.data || null;
  }

  // Conectividad
  async getConnectivityStatus(): Promise<any> {
    const response = await this.request<any>('/connectivity/status');
    return response.data || null;
  }

  async testConnectivity(target?: string, type?: string): Promise<any> {
    const response = await this.request<any>('/connectivity/test', {
      method: 'POST',
      body: JSON.stringify({ target, type }),
    });
    return response.data || null;
  }

  async getNetworkHealth(): Promise<any> {
    const response = await this.request<any>('/connectivity/health');
    return response.data || null;
  }

  // SaaS
  async getSaaSMetrics(): Promise<any> {
    const response = await this.request<any>('/saas/metrics');
    return response.data || null;
  }

  async getSaaSUsers(): Promise<any[]> {
    const response = await this.request<any[]>('/saas/users');
    return response.data || [];
  }

  async getSaaSSubscriptions(): Promise<any[]> {
    const response = await this.request<any[]>('/saas/subscriptions');
    return response.data || [];
  }

  // MEV Avanzado
  async getMEVProtectionAdvanced(): Promise<any> {
    const response = await this.request<any>('/mev/protection');
    return response.data || null;
  }

  async getMEVAnalysis(): Promise<any> {
    const response = await this.request<any>('/mev/analysis');
    return response.data || null;
  }

  async getMEVStrategies(): Promise<any[]> {
    const response = await this.request<any[]>('/mev/strategies');
    return response.data || [];
  }

  // Inteligencia Unificada
  async getIntelligentAnalysis(): Promise<any> {
    const response = await this.request<any>('/intelligent/analysis');
    return response.data || null;
  }

  async getIntelligentDecisions(): Promise<any[]> {
    const response = await this.request<any[]>('/intelligent/decisions');
    return response.data || [];
  }

  async getPredictiveInsights(): Promise<any> {
    const response = await this.request<any>('/intelligent/insights');
    return response.data || null;
  }
}

// Instancia singleton del servicio
export const apiService = new ApiService();