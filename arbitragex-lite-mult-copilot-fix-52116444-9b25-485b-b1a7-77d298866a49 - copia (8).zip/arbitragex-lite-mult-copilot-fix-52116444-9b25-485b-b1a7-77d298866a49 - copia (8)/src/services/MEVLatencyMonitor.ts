import { ethers } from 'ethers'
import { secureLogger } from '../utils/SecurityUtils'

// Interfaces para monitoreo de latencia MEV
export interface LatencyMetrics {
  networkLatency: number // ms
  blockTime: number // ms
  gasPriceLatency: number // ms
  mevDetectionLatency: number // ms
  totalLatency: number // ms
  confidence: number // 0-1
}

export interface MEVOpportunity {
  id: string
  type: 'arbitrage' | 'liquidation' | 'sandwich' | 'jit' | 'cross-chain'
  chainId: number
  blockNumber: number
  gasPrice: number
  priorityFee: number
  expectedProfit: number
  riskLevel: 'low' | 'medium' | 'high' | 'extreme'
  executionWindow: number // ms
  detectedAt: number
  expiresAt: number
  source: 'eigenphi' | 'flashbots' | 'blocknative' | 'mevwatch'
  confidence: number
  gasEfficiency: number
  roi: number
  minimumCapital: number
}

export interface NetworkPerformance {
  chainId: number
  networkName: string
  averageBlockTime: number
  gasPriceVolatility: number
  mevOpportunityRate: number
  averageLatency: number
  uptime: number
  lastUpdate: number
}

export interface LatencyAlert {
  id: string
  type: 'high-latency' | 'gas-spike' | 'mev-detected' | 'network-congestion'
  severity: 'low' | 'medium' | 'high' | 'critical'
  message: string
  chainId: number
  timestamp: number
  data: any
}

export class MEVLatencyMonitor {
  private providers: Map<number, ethers.Provider> = new Map()
  private latencyHistory: Map<number, number[]> = new Map()
  private mevOpportunities: Map<string, MEVOpportunity> = new Map()
  private networkPerformance: Map<number, NetworkPerformance> = new Map()
  private alerts: LatencyAlert[] = []
  private isMonitoring: boolean = false
  private monitoringInterval: number = 1000 // 1 segundo
  private lastBlockNumbers: Map<number, number> = new Map()
  private lastGasPrices: Map<number, number> = new Map()
  private performanceMetrics: Map<number, {
    blockTimes: number[]
    gasPrices: number[]
    latencies: number[]
    mevCount: number
  }> = new Map()

  constructor() {
    this.initializeProviders()
    this.initializeNetworkPerformance()
  }

  private initializeProviders(): void {
    // Ethereum Mainnet
    this.providers.set(1, new ethers.JsonRpcProvider(process.env.VITE_ETHEREUM_RPC_URL))
    // Polygon
    this.providers.set(137, new ethers.JsonRpcProvider(process.env.VITE_POLYGON_RPC_URL))
    // BSC
    this.providers.set(56, new ethers.JsonRpcProvider(process.env.VITE_BSC_RPC_URL))
    // Arbitrum
    this.providers.set(42161, new ethers.JsonRpcProvider(process.env.VITE_ARBITRUM_RPC_URL))
    // Optimism
    this.providers.set(10, new ethers.JsonRpcProvider(process.env.VITE_OPTIMISM_RPC_URL))
    // Avalanche
    this.providers.set(43114, new ethers.JsonRpcProvider(process.env.VITE_AVALANCHE_RPC_URL))
    // Fantom
    this.providers.set(250, new ethers.JsonRpcProvider(process.env.VITE_FANTOM_RPC_URL))
    // Cronos
    this.providers.set(25, new ethers.JsonRpcProvider(process.env.VITE_CRONOS_RPC_URL))
  }

  private initializeNetworkPerformance(): void {
    for (const [chainId] of this.providers) {
      this.networkPerformance.set(chainId, {
        chainId,
        networkName: this.getNetworkName(chainId),
        averageBlockTime: this.getDefaultBlockTime(chainId),
        gasPriceVolatility: 0,
        mevOpportunityRate: 0,
        averageLatency: 0,
        uptime: 100,
        lastUpdate: Date.now()
      })

      this.performanceMetrics.set(chainId, {
        blockTimes: [],
        gasPrices: [],
        latencies: [],
        mevCount: 0
      })
    }
  }

  /**
   * Iniciar monitoreo de latencia
   */
  async startMonitoring(): Promise<void> {
    if (this.isMonitoring) return

    this.isMonitoring = true
    secureLogger.info('Iniciando monitoreo de latencia MEV', {}, 'MEVLatencyMonitor')

    // Monitoreo continuo
    setInterval(async () => {
      if (this.isMonitoring) {
        await this.monitorAllNetworks()
      }
    }, this.monitoringInterval)

    // Monitoreo de bloques
    for (const [chainId, provider] of this.providers) {
      this.monitorBlockProduction(chainId, provider)
    }
  }

  /**
   * Detener monitoreo
   */
  stopMonitoring(): void {
    this.isMonitoring = false
    secureLogger.info('Deteniendo monitoreo de latencia MEV', {}, 'MEVLatencyMonitor')
  }

  /**
   * Monitorear todas las redes
   */
  private async monitorAllNetworks(): Promise<void> {
    const promises = Array.from(this.providers.entries()).map(([chainId, provider]) =>
      this.monitorNetwork(chainId, provider)
    )

    await Promise.allSettled(promises)
  }

  /**
   * Monitorear red específica
   */
  private async monitorNetwork(chainId: number, provider: ethers.Provider): Promise<void> {
    try {
      const startTime = Date.now()
      
      // Obtener bloque actual
      const currentBlock = await provider.getBlockNumber()
      const currentBlockTime = Date.now()
      
      // Obtener datos de gas
      const feeData = await provider.getFeeData()
      const gasPrice = feeData.gasPrice ? 
        parseFloat(ethers.formatUnits(feeData.gasPrice, 'gwei')) : 25
      
      // Calcular latencias
      const networkLatency = currentBlockTime - startTime
      const blockTime = this.calculateBlockTime(chainId, currentBlock)
      const gasPriceLatency = this.calculateGasPriceLatency(chainId, gasPrice)
      
      // Detectar oportunidades MEV
      const mevOpportunity = await this.detectMEVOpportunity(chainId, currentBlock, gasPrice)
      const mevDetectionLatency = Date.now() - startTime
      
      // Calcular latencia total
      const totalLatency = networkLatency + blockTime + gasPriceLatency + mevDetectionLatency
      
      // Actualizar métricas
      this.updatePerformanceMetrics(chainId, {
        blockTime,
        gasPrice,
        latency: totalLatency,
        mevDetected: !!mevOpportunity
      })
      
      // Actualizar historial de latencia
      this.updateLatencyHistory(chainId, totalLatency)
      
      // Verificar alertas
      this.checkLatencyAlerts(chainId, totalLatency, gasPrice, mevOpportunity)
      
      // Actualizar último bloque y gas price
      this.lastBlockNumbers.set(chainId, currentBlock)
      this.lastGasPrices.set(chainId, gasPrice)
      
    } catch (error) {
      secureLogger.error('Error monitoreando red', {
        chainId,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'MEVLatencyMonitor')
      
      // Marcar red como down
      this.markNetworkDown(chainId)
    }
  }

  /**
   * Monitorear producción de bloques
   */
  private monitorBlockProduction(chainId: number, provider: ethers.Provider): void {
    provider.on('block', async (blockNumber: number) => {
      try {
        const blockTime = Date.now()
        const lastBlockTime = this.lastBlockNumbers.get(chainId)
        
        if (lastBlockTime) {
          const blockInterval = blockTime - lastBlockTime
          this.updateBlockTimeMetrics(chainId, blockInterval)
        }
        
        this.lastBlockNumbers.set(chainId, blockTime)
        
        // Verificar si hay oportunidades MEV en este bloque
        await this.analyzeBlockForMEV(chainId, blockNumber)
        
      } catch (error) {
        secureLogger.error('Error procesando nuevo bloque', {
          chainId,
          blockNumber,
          error: error instanceof Error ? error.message : 'Unknown error'
        }, 'MEVLatencyMonitor')
      }
    })
  }

  /**
   * Detectar oportunidad MEV
   */
  private async detectMEVOpportunity(
    chainId: number,
    blockNumber: number,
    gasPrice: number
  ): Promise<MEVOpportunity | null> {
    try {
      // Simular detección de oportunidades MEV basada en múltiples fuentes
      const opportunities = await this.scanMEVSources(chainId, blockNumber, gasPrice)
      
      if (opportunities.length === 0) return null
      
      // Seleccionar la mejor oportunidad
      const bestOpportunity = opportunities.reduce((best, current) => 
        current.roi > best.roi ? current : best
      )
      
      // Generar ID único
      const opportunityId = `mev_${chainId}_${blockNumber}_${Date.now()}`
      bestOpportunity.id = opportunityId
      
      // Almacenar oportunidad
      this.mevOpportunities.set(opportunityId, bestOpportunity)
      
      // Limpiar oportunidades expiradas
      this.cleanupExpiredOpportunities()
      
      return bestOpportunity
      
    } catch (error) {
      secureLogger.error('Error detectando oportunidad MEV', {
        chainId,
        blockNumber,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'MEVLatencyMonitor')
      
      return null
    }
  }

  /**
   * Escanear fuentes MEV
   */
  private async scanMEVSources(
    chainId: number,
    blockNumber: number,
    gasPrice: number
  ): Promise<MEVOpportunity[]> {
    const opportunities: MEVOpportunity[] = []
    
    try {
      // Simular datos de EigenPhi (solo Ethereum)
      if (chainId === 1) {
        const eigenphiOpp = this.simulateEigenPhiOpportunity(chainId, blockNumber, gasPrice)
        if (eigenphiOpp) opportunities.push(eigenphiOpp)
      }
      
      // Simular datos de Flashbots
      const flashbotsOpp = this.simulateFlashbotsOpportunity(chainId, blockNumber, gasPrice)
      if (flashbotsOpp) opportunities.push(flashbotsOpp)
      
      // Simular datos de Blocknative
      const blocknativeOpp = this.simulateBlocknativeOpportunity(chainId, blockNumber, gasPrice)
      if (blocknativeOpp) opportunities.push(blocknativeOpp)
      
      // Simular datos de MEVWatch
      const mevwatchOpp = this.simulateMEVWatchOpportunity(chainId, blockNumber, gasPrice)
      if (mevwatchOpp) opportunities.push(mevwatchOpp)
      
    } catch (error) {
      secureLogger.error('Error escaneando fuentes MEV', {
        chainId,
        blockNumber,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'MEVLatencyMonitor')
    }
    
    return opportunities
  }

  /**
   * Simular oportunidad de EigenPhi
   */
  private simulateEigenPhiOpportunity(
    chainId: number,
    blockNumber: number,
    gasPrice: number
  ): MEVOpportunity | null {
    // Solo generar oportunidades con cierta probabilidad
    if (Math.random() > 0.3) return null
    
    const types: Array<'arbitrage' | 'liquidation' | 'sandwich' | 'jit'> = ['arbitrage', 'liquidation', 'sandwich', 'jit']
    const type = types[Math.floor(Math.random() * types.length)]
    
    return {
      id: '',
      type,
      chainId,
      blockNumber,
      gasPrice: gasPrice + Math.random() * 5,
      priorityFee: 1 + Math.random() * 3,
      expectedProfit: 100 + Math.random() * 500,
      riskLevel: this.calculateRiskLevel(type, gasPrice),
      executionWindow: 12000 + Math.random() * 30000, // 12-42 segundos
      detectedAt: Date.now(),
      expiresAt: Date.now() + 60000, // 1 minuto
      source: 'eigenphi',
      confidence: 0.7 + Math.random() * 0.3,
      gasEfficiency: 7 + Math.floor(Math.random() * 4),
      roi: 5 + Math.random() * 15,
      minimumCapital: 10000 + Math.random() * 40000
    }
  }

  /**
   * Simular oportunidad de Flashbots
   */
  private simulateFlashbotsOpportunity(
    chainId: number,
    blockNumber: number,
    gasPrice: number
  ): MEVOpportunity | null {
    if (Math.random() > 0.4) return null
    
    const types: Array<'arbitrage' | 'sandwich' | 'jit'> = ['arbitrage', 'sandwich', 'jit']
    const type = types[Math.floor(Math.random() * types.length)]
    
    return {
      id: '',
      type,
      chainId,
      blockNumber,
      gasPrice: gasPrice + Math.random() * 3,
      priorityFee: 1.5 + Math.random() * 2.5,
      expectedProfit: 80 + Math.random() * 300,
      riskLevel: this.calculateRiskLevel(type, gasPrice),
      executionWindow: 8000 + Math.random() * 20000, // 8-28 segundos
      detectedAt: Date.now(),
      expiresAt: Date.now() + 45000, // 45 segundos
      source: 'flashbots',
      confidence: 0.8 + Math.random() * 0.2,
      gasEfficiency: 8 + Math.floor(Math.random() * 3),
      roi: 4 + Math.random() * 12,
      minimumCapital: 8000 + Math.random() * 25000
    }
  }

  /**
   * Simular oportunidad de Blocknative
   */
  private simulateBlocknativeOpportunity(
    chainId: number,
    blockNumber: number,
    gasPrice: number
  ): MEVOpportunity | null {
    if (Math.random() > 0.35) return null
    
    const types: Array<'arbitrage' | 'liquidation' | 'cross-chain'> = ['arbitrage', 'liquidation', 'cross-chain']
    const type = types[Math.floor(Math.random() * types.length)]
    
    return {
      id: '',
      type,
      chainId,
      blockNumber,
      gasPrice: gasPrice + Math.random() * 4,
      priorityFee: 1.2 + Math.random() * 2.8,
      expectedProfit: 120 + Math.random() * 400,
      riskLevel: this.calculateRiskLevel(type, gasPrice),
      executionWindow: 15000 + Math.random() * 35000, // 15-50 segundos
      detectedAt: Date.now(),
      expiresAt: Date.now() + 75000, // 1.25 minutos
      source: 'blocknative',
      confidence: 0.75 + Math.random() * 0.25,
      gasEfficiency: 7 + Math.floor(Math.random() * 3),
      roi: 6 + Math.random() * 18,
      minimumCapital: 15000 + Math.random() * 35000
    }
  }

  /**
   * Simular oportunidad de MEVWatch
   */
  private simulateMEVWatchOpportunity(
    chainId: number,
    blockNumber: number,
    gasPrice: number
  ): MEVOpportunity | null {
    if (Math.random() > 0.25) return null
    
    const types: Array<'arbitrage' | 'sandwich' | 'jit' | 'cross-chain'> = ['arbitrage', 'sandwich', 'jit', 'cross-chain']
    const type = types[Math.floor(Math.random() * types.length)]
    
    return {
      id: '',
      type,
      chainId,
      blockNumber,
      gasPrice: gasPrice + Math.random() * 6,
      priorityFee: 1.8 + Math.random() * 3.2,
      expectedProfit: 150 + Math.random() * 600,
      riskLevel: this.calculateRiskLevel(type, gasPrice),
      executionWindow: 20000 + Math.random() * 40000, // 20-60 segundos
      detectedAt: Date.now(),
      expiresAt: Date.now() + 90000, // 1.5 minutos
      source: 'mevwatch',
      confidence: 0.6 + Math.random() * 0.4,
      gasEfficiency: 6 + Math.floor(Math.random() * 4),
      roi: 8 + Math.random() * 22,
      minimumCapital: 20000 + Math.random() * 50000
    }
  }

  /**
   * Calcular nivel de riesgo
   */
  private calculateRiskLevel(type: string, gasPrice: number): 'low' | 'medium' | 'high' | 'extreme' {
    const baseRisk = {
      'arbitrage': 0.3,
      'liquidation': 0.5,
      'sandwich': 0.7,
      'jit': 0.6,
      'cross-chain': 0.8
    }[type] || 0.5
    
    const gasRisk = gasPrice > 50 ? 0.3 : gasPrice > 30 ? 0.2 : 0.1
    
    const totalRisk = baseRisk + gasRisk
    
    if (totalRisk < 0.4) return 'low'
    if (totalRisk < 0.6) return 'medium'
    if (totalRisk < 0.8) return 'high'
    return 'extreme'
  }

  /**
   * Analizar bloque para MEV
   */
  private async analyzeBlockForMEV(chainId: number, blockNumber: number): Promise<void> {
    try {
      // Simular análisis de transacciones en el bloque
      const mevTransactions = Math.floor(Math.random() * 5)
      
      if (mevTransactions > 0) {
        this.updateMEVCount(chainId, mevTransactions)
        
        // Generar alerta si hay mucho MEV
        if (mevTransactions >= 3) {
          this.generateAlert('mev-detected', 'high', 
            `Alto volumen de MEV detectado en bloque ${blockNumber}`, chainId, { mevTransactions })
        }
      }
      
    } catch (error) {
      // Ignorar errores en análisis de bloques
    }
  }

  /**
   * Obtener métricas de latencia para una red
   */
  async getLatencyMetrics(chainId: number): Promise<LatencyMetrics> {
    const history = this.latencyHistory.get(chainId) || []
    const currentLatency = history[history.length - 1] || 0
    
    const networkPerformance = this.networkPerformance.get(chainId)
    const performanceMetrics = this.performanceMetrics.get(chainId)
    
    if (!networkPerformance || !performanceMetrics) {
      return this.getDefaultLatencyMetrics()
    }
    
    const averageLatency = performanceMetrics.latencies.length > 0 ?
      performanceMetrics.latencies.reduce((a, b) => a + b, 0) / performanceMetrics.latencies.length : 0
    
    const confidence = Math.max(0.1, Math.min(1, 1 - (averageLatency / 10000))) // Menor latencia = mayor confianza
    
    return {
      networkLatency: currentLatency * 0.3,
      blockTime: networkPerformance.averageBlockTime,
      gasPriceLatency: currentLatency * 0.2,
      mevDetectionLatency: currentLatency * 0.5,
      totalLatency: currentLatency,
      confidence
    }
  }

  /**
   * Obtener oportunidades MEV activas
   */
  getActiveMEVOpportunities(): MEVOpportunity[] {
    const now = Date.now()
    return Array.from(this.mevOpportunities.values())
      .filter(opp => opp.expiresAt > now)
      .sort((a, b) => b.roi - a.roi)
  }

  /**
   * Obtener rendimiento de red
   */
  getNetworkPerformance(): NetworkPerformance[] {
    return Array.from(this.networkPerformance.values())
  }

  /**
   * Obtener alertas activas
   */
  getActiveAlerts(): LatencyAlert[] {
    const now = Date.now()
    return this.alerts.filter(alert => 
      now - alert.timestamp < 300000 // Últimos 5 minutos
    )
  }

  /**
   * Calcular tiempo de bloque
   */
  private calculateBlockTime(chainId: number, currentBlock: number): number {
    const lastBlock = this.lastBlockNumbers.get(chainId)
    if (!lastBlock) return this.getDefaultBlockTime(chainId)
    
    return Date.now() - lastBlock
  }

  /**
   * Calcular latencia de gas price
   */
  private calculateGasPriceLatency(chainId: number, currentGasPrice: number): number {
    const lastGasPrice = this.lastGasPrices.get(chainId)
    if (!lastGasPrice) return 0
    
    const gasPriceChange = Math.abs(currentGasPrice - lastGasPrice)
    return gasPriceChange > 5 ? 1000 : 0 // 1 segundo si cambio significativo
  }

  /**
   * Actualizar métricas de rendimiento
   */
  private updatePerformanceMetrics(
    chainId: number,
    data: { blockTime: number; gasPrice: number; latency: number; mevDetected: boolean }
  ): void {
    const metrics = this.performanceMetrics.get(chainId)
    if (!metrics) return
    
    metrics.blockTimes.push(data.blockTime)
    metrics.gasPrices.push(data.gasPrice)
    metrics.latencies.push(data.latency)
    
    if (data.mevDetected) {
      metrics.mevCount++
    }
    
    // Mantener solo últimos 100 valores
    if (metrics.blockTimes.length > 100) {
      metrics.blockTimes.shift()
      metrics.gasPrices.shift()
      metrics.latencies.shift()
    }
    
    // Actualizar rendimiento de red
    this.updateNetworkPerformance(chainId, metrics)
  }

  /**
   * Actualizar rendimiento de red
   */
  private updateNetworkPerformance(chainId: number, metrics: any): void {
    const performance = this.networkPerformance.get(chainId)
    if (!performance) return
    
    performance.averageBlockTime = metrics.blockTimes.length > 0 ?
      metrics.blockTimes.reduce((a: number, b: number) => a + b, 0) / metrics.blockTimes.length : 0
    
    performance.averageLatency = metrics.latencies.length > 0 ?
      metrics.latencies.reduce((a: number, b: number) => a + b, 0) / metrics.latencies.length : 0
    
    performance.gasPriceVolatility = this.calculateGasPriceVolatility(metrics.gasPrices)
    performance.mevOpportunityRate = metrics.mevCount / Math.max(1, metrics.blockTimes.length)
    performance.lastUpdate = Date.now()
  }

  /**
   * Calcular volatilidad del gas price
   */
  private calculateGasPriceVolatility(gasPrices: number[]): number {
    if (gasPrices.length < 2) return 0
    
    const mean = gasPrices.reduce((a, b) => a + b, 0) / gasPrices.length
    const variance = gasPrices.reduce((sum, price) => sum + Math.pow(price - mean, 2), 0) / gasPrices.length
    
    return Math.sqrt(variance)
  }

  /**
   * Actualizar historial de latencia
   */
  private updateLatencyHistory(chainId: number, latency: number): void {
    if (!this.latencyHistory.has(chainId)) {
      this.latencyHistory.set(chainId, [])
    }
    
    const history = this.latencyHistory.get(chainId)!
    history.push(latency)
    
    // Mantener solo últimos 100 valores
    if (history.length > 100) {
      history.shift()
    }
  }

  /**
   * Actualizar métricas de tiempo de bloque
   */
  private updateBlockTimeMetrics(chainId: number, blockTime: number): void {
    const metrics = this.performanceMetrics.get(chainId)
    if (!metrics) return
    
    metrics.blockTimes.push(blockTime)
    
    if (metrics.blockTimes.length > 100) {
      metrics.blockTimes.shift()
    }
  }

  /**
   * Actualizar conteo de MEV
   */
  private updateMEVCount(chainId: number, count: number): void {
    const metrics = this.performanceMetrics.get(chainId)
    if (!metrics) return
    
    metrics.mevCount += count
  }

  /**
   * Verificar alertas de latencia
   */
  private checkLatencyAlerts(
    chainId: number,
    latency: number,
    gasPrice: number,
    mevOpportunity: MEVOpportunity | null
  ): void {
    // Alerta de alta latencia
    if (latency > 5000) { // >5 segundos
      this.generateAlert('high-latency', 'high',
        `Alta latencia detectada: ${latency}ms`, chainId, { latency })
    }
    
    // Alerta de spike de gas
    const lastGasPrice = this.lastGasPrices.get(chainId)
    if (lastGasPrice && gasPrice > lastGasPrice * 1.5) {
      this.generateAlert('gas-spike', 'medium',
        `Spike de gas detectado: ${lastGasPrice} → ${gasPrice} gwei`, chainId, { lastGasPrice, currentGasPrice: gasPrice })
    }
    
    // Alerta de congestión de red
    if (latency > 10000) { // >10 segundos
      this.generateAlert('network-congestion', 'critical',
        `Congestión crítica de red detectada`, chainId, { latency })
    }
  }

  /**
   * Generar alerta
   */
  private generateAlert(
    type: string,
    severity: 'low' | 'medium' | 'high' | 'critical',
    message: string,
    chainId: number,
    data: any
  ): void {
    const alert: LatencyAlert = {
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: type as any,
      severity,
      message,
      chainId,
      timestamp: Date.now(),
      data
    }
    
    this.alerts.push(alert)
    
    // Mantener solo últimas 100 alertas
    if (this.alerts.length > 100) {
      this.alerts.shift()
    }
    
    // Log de alertas críticas
    if (severity === 'critical') {
      secureLogger.warn('Alerta crítica de latencia MEV', {
        type,
        chainId,
        message,
        data
      }, 'MEVLatencyMonitor')
    }
  }

  /**
   * Marcar red como down
   */
  private markNetworkDown(chainId: number): void {
    const performance = this.networkPerformance.get(chainId)
    if (performance) {
      performance.uptime = Math.max(0, performance.uptime - 10)
      performance.lastUpdate = Date.now()
    }
  }

  /**
   * Limpiar oportunidades expiradas
   */
  private cleanupExpiredOpportunities(): void {
    const now = Date.now()
    for (const [id, opportunity] of this.mevOpportunities) {
      if (opportunity.expiresAt <= now) {
        this.mevOpportunities.delete(id)
      }
    }
  }

  /**
   * Obtener tiempo de bloque por defecto
   */
  private getDefaultBlockTime(chainId: number): number {
    const defaultTimes = {
      1: 12000,      // Ethereum: 12 segundos
      137: 2000,     // Polygon: 2 segundos
      56: 3000,      // BSC: 3 segundos
      42161: 1000,   // Arbitrum: 1 segundo
      10: 2000,      // Optimism: 2 segundos
      43114: 2000,   // Avalanche: 2 segundos
      250: 1000,     // Fantom: 1 segundo
      25: 6000       // Cronos: 6 segundos
    }
    
    return defaultTimes[chainId as keyof typeof defaultTimes] || 5000
  }

  /**
   * Obtener nombre de red
   */
  private getNetworkName(chainId: number): string {
    const networks = {
      1: 'Ethereum',
      137: 'Polygon',
      56: 'BSC',
      42161: 'Arbitrum',
      10: 'Optimism',
      43114: 'Avalanche',
      250: 'Fantom',
      25: 'Cronos'
    }
    
    return networks[chainId as keyof typeof networks] || 'Unknown'
  }

  /**
   * Obtener métricas de latencia por defecto
   */
  private getDefaultLatencyMetrics(): LatencyMetrics {
    return {
      networkLatency: 0,
      blockTime: 0,
      gasPriceLatency: 0,
      mevDetectionLatency: 0,
      totalLatency: 0,
      confidence: 0.5
    }
  }

  /**
   * Obtener estadísticas de latencia
   */
  getLatencyStatistics(chainId: number): {
    current: number
    average: number
    min: number
    max: number
    trend: 'improving' | 'stable' | 'degrading'
  } {
    const history = this.latencyHistory.get(chainId) || []
    const current = history[history.length - 1] || 0
    const average = history.length > 0 ? history.reduce((a, b) => a + b, 0) / history.length : 0
    const min = history.length > 0 ? Math.min(...history) : 0
    const max = history.length > 0 ? Math.max(...history) : 0
    
    let trend: 'improving' | 'stable' | 'degrading' = 'stable'
    if (history.length >= 10) {
      const recent = history.slice(-5)
      const older = history.slice(-10, -5)
      if (recent.length > 0 && older.length > 0) {
        const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length
        const olderAvg = older.reduce((a, b) => a + b, 0) / older.length
        if (recentAvg < olderAvg * 0.9) trend = 'improving'
        else if (recentAvg > olderAvg * 1.1) trend = 'degrading'
      }
    }
    
    return { current, average, min, max, trend }
  }
}

// Instancia singleton
export const mevLatencyMonitor = new MEVLatencyMonitor()
