import { FigmaAPI } from 'figma-api';

export interface FigmaAsset {
  id: string;
  name: string;
  url: string;
  format: 'png' | 'jpg' | 'svg' | 'pdf';
  scale: number;
}

export interface FigmaDesign {
  id: string;
  name: string;
  lastModified: string;
  thumbnailUrl: string;
  version: string;
}

export class FigmaAssetService {
  private figma: FigmaAPI;
  private accessToken: string;

  constructor(accessToken: string) {
    this.accessToken = accessToken;
    this.figma = new FigmaAPI({ personalAccessToken: accessToken });
  }

  /**
   * Obtiene información de un archivo de Figma
   */
  async getFileInfo(fileId: string): Promise<FigmaDesign> {
    try {
      const file = await this.figma.getFile(fileId);
      return {
        id: file.key,
        name: file.name,
        lastModified: file.lastModified,
        thumbnailUrl: file.thumbnailUrl || '',
        version: file.version
      };
    } catch (error) {
      console.error('Error obteniendo información del archivo Figma:', error);
      throw error;
    }
  }

  /**
   * Obtiene assets de un archivo de Figma
   */
  async getAssets(fileId: string, nodeIds: string[], format: 'png' | 'jpg' | 'svg' | 'pdf' = 'png', scale: number = 1): Promise<FigmaAsset[]> {
    try {
      const images = await this.figma.getImage(fileId, {
        ids: nodeIds,
        format,
        scale
      });

      return Object.entries(images.images).map(([id, url]) => ({
        id,
        name: `asset_${id}`,
        url,
        format,
        scale
      }));
    } catch (error) {
      console.error('Error obteniendo assets de Figma:', error);
      throw error;
    }
  }

  /**
   * Descarga un asset de Figma y lo guarda localmente
   */
  async downloadAsset(asset: FigmaAsset, outputPath: string): Promise<string> {
    try {
      const response = await fetch(asset.url);
      const buffer = await response.arrayBuffer();
      
      // Aquí implementarías la lógica para guardar el archivo
      // usando el servidor MCP de filesystem
      
      return outputPath;
    } catch (error) {
      console.error('Error descargando asset:', error);
      throw error;
    }
  }

  /**
   * Obtiene todos los componentes de un archivo
   */
  async getComponents(fileId: string): Promise<any[]> {
    try {
      const file = await this.figma.getFile(fileId);
      const components: any[] = [];
      
      // Recursivamente buscar componentes
      const findComponents = (node: any) => {
        if (node.type === 'COMPONENT' || node.type === 'COMPONENT_SET') {
          components.push({
            id: node.id,
            name: node.name,
            description: node.description || '',
            key: node.key
          });
        }
        
        if (node.children) {
          node.children.forEach(findComponents);
        }
      };
      
      if (file.document) {
        findComponents(file.document);
      }
      
      return components;
    } catch (error) {
      console.error('Error obteniendo componentes:', error);
      throw error;
    }
  }

  /**
   * Sincroniza assets desde Figma a tu proyecto
   */
  async syncAssetsToProject(fileId: string, outputDir: string): Promise<void> {
    try {
      // Obtener componentes
      const components = await this.getComponents(fileId);
      
      // Obtener assets de cada componente
      const nodeIds = components.map(c => c.id);
      const assets = await this.getAssets(fileId, nodeIds, 'png', 2);
      
      // Descargar cada asset
      for (const asset of assets) {
        const fileName = `${asset.name}_${asset.id}.${asset.format}`;
        const outputPath = `${outputDir}/${fileName}`;
        
        await this.downloadAsset(asset, outputPath);
        console.log(`Asset descargado: ${fileName}`);
      }
      
      console.log(`Sincronización completada: ${assets.length} assets descargados`);
    } catch (error) {
      console.error('Error en sincronización:', error);
      throw error;
    }
  }
}
