/**
 * 🔍 BLOCKCHAIN TRANSACTION MONITOR - ArbitrageX Pro 2025
 * Monitoreo completo de transacciones blockchain y manejo de fallos
 */

import { ethers } from 'ethers';
import { secureLogger } from '../security/SecureLoggingManager';

export interface TransactionStatus {
  hash: string;
  status: 'pending' | 'confirmed' | 'failed' | 'dropped' | 'replaced';
  blockNumber?: number;
  gasUsed?: number;
  gasPrice?: string;
  actualGasCost?: string;
  confirmations: number;
  timestamp: string;
  error?: string;
  receipt?: ethers.TransactionReceipt;
}

export interface FailureAnalysis {
  reason: 'gas_limit' | 'gas_price' | 'revert' | 'nonce' | 'network' | 'unknown';
  description: string;
  canRetry: boolean;
  suggestedFix: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface MonitoringConfig {
  maxConfirmations: number;
  timeoutMs: number;
  retryAttempts: number;
  gasAnalysisEnabled: boolean;
  mevDetectionEnabled: boolean;
  alertThresholds: {
    gasSpike: number;
    failureRate: number;
    pendingDuration: number;
  };
}

export class BlockchainTransactionMonitor {
  private static instance: BlockchainTransactionMonitor;
  private providers: Map<number, ethers.Provider> = new Map();
  private monitoredTransactions: Map<string, TransactionStatus> = new Map();
  private failureHistory: Map<string, FailureAnalysis[]> = new Map();
  private config: MonitoringConfig;
  private monitoringIntervals: Map<string, NodeJS.Timeout> = new Map();

  private constructor() {
    this.config = {
      maxConfirmations: 12,
      timeoutMs: 300000, // 5 minutos
      retryAttempts: 3,
      gasAnalysisEnabled: true,
      mevDetectionEnabled: true,
      alertThresholds: {
        gasSpike: 2.0, // 200% del gas normal
        failureRate: 0.1, // 10% de fallos
        pendingDuration: 60000 // 1 minuto
      }
    };

    this.initializeProviders();
  }

  public static getInstance(): BlockchainTransactionMonitor {
    if (!BlockchainTransactionMonitor.instance) {
      BlockchainTransactionMonitor.instance = new BlockchainTransactionMonitor();
    }
    return BlockchainTransactionMonitor.instance;
  }

  /**
   * Inicializar providers para diferentes chains
   */
  private initializeProviders(): void {
    const chains = [
      { id: 1, name: 'Ethereum', rpc: process.env.ETHEREUM_RPC_URL },
      { id: 56, name: 'BSC', rpc: process.env.BSC_RPC_URL },
      { id: 137, name: 'Polygon', rpc: process.env.POLYGON_RPC_URL },
      { id: 42161, name: 'Arbitrum', rpc: process.env.ARBITRUM_RPC_URL },
      { id: 10, name: 'Optimism', rpc: process.env.OPTIMISM_RPC_URL }
    ];

    for (const chain of chains) {
      if (chain.rpc) {
        try {
          const provider = new ethers.JsonRpcProvider(chain.rpc);
          this.providers.set(chain.id, provider);
          console.log(`✅ Provider inicializado para ${chain.name} (${chain.id})`);
        } catch (error) {
          console.error(`❌ Error inicializando provider para ${chain.name}:`, error);
        }
      }
    }
  }

  /**
   * Monitorear transacción
   */
  async monitorTransaction(
    hash: string, 
    chainId: number,
    options: {
      maxWaitTime?: number;
      requiredConfirmations?: number;
      onUpdate?: (status: TransactionStatus) => void;
    } = {}
  ): Promise<TransactionStatus> {
    const provider = this.providers.get(chainId);
    if (!provider) {
      throw new Error(`Provider no disponible para chain ${chainId}`);
    }

    const initialStatus: TransactionStatus = {
      hash,
      status: 'pending',
      confirmations: 0,
      timestamp: new Date().toISOString()
    };

    this.monitoredTransactions.set(hash, initialStatus);
    
    secureLogger.info('Iniciando monitoreo de transacción', {
      hash,
      chainId
    }, 'BlockchainTransactionMonitor');

    return new Promise((resolve, reject) => {
      const maxWaitTime = options.maxWaitTime || this.config.timeoutMs;
      const requiredConfirmations = options.requiredConfirmations || this.config.maxConfirmations;
      
      let timeoutHandle: NodeJS.Timeout;
      let monitoringHandle: NodeJS.Timeout;

      // Timeout general
      timeoutHandle = setTimeout(() => {
        this.stopMonitoring(hash);
        const status = this.monitoredTransactions.get(hash)!;
        status.status = 'dropped';
        status.error = 'Transaction timeout';
        
        secureLogger.warn('Transacción timeout', { hash, chainId }, 'BlockchainTransactionMonitor');
        resolve(status);
      }, maxWaitTime);

      // Monitoreo periódico
      const checkTransaction = async () => {
        try {
          const tx = await provider.getTransaction(hash);
          const status = this.monitoredTransactions.get(hash)!;

          if (!tx) {
            // Transacción no encontrada - posiblemente dropped
            status.status = 'dropped';
            status.error = 'Transaction not found in mempool';
            
            this.stopMonitoring(hash);
            clearTimeout(timeoutHandle);
            
            secureLogger.warn('Transacción no encontrada', { hash, chainId }, 'BlockchainTransactionMonitor');
            resolve(status);
            return;
          }

          // Actualizar información básica
          status.gasPrice = tx.gasPrice?.toString();

          if (tx.blockNumber) {
            // Transacción minada
            const receipt = await provider.getTransactionReceipt(hash);
            const currentBlock = await provider.getBlockNumber();
            const confirmations = currentBlock - tx.blockNumber + 1;

            status.blockNumber = tx.blockNumber;
            status.confirmations = confirmations;
            status.receipt = receipt || undefined;

            if (receipt) {
              status.gasUsed = Number(receipt.gasUsed);
              status.actualGasCost = (BigInt(receipt.gasUsed) * BigInt(tx.gasPrice || 0)).toString();

              if (receipt.status === 1) {
                status.status = 'confirmed';
                
                // Verificar si tenemos suficientes confirmaciones
                if (confirmations >= requiredConfirmations) {
                  this.stopMonitoring(hash);
                  clearTimeout(timeoutHandle);
                  
                  secureLogger.info('Transacción confirmada', {
                    hash,
                    chainId,
                    confirmations,
                    gasUsed: status.gasUsed,
                    gasCost: status.actualGasCost
                  }, 'BlockchainTransactionMonitor');
                  
                  resolve(status);
                  return;
                }
              } else {
                // Transacción falló
                status.status = 'failed';
                const analysis = await this.analyzeFailure(hash, chainId, receipt);
                status.error = analysis.description;
                
                this.recordFailure(hash, analysis);
                this.stopMonitoring(hash);
                clearTimeout(timeoutHandle);
                
                secureLogger.error('Transacción falló', {
                  hash,
                  chainId,
                  analysis
                }, 'BlockchainTransactionMonitor');
                
                resolve(status);
                return;
              }
            }
          }

          // Callback de actualización
          if (options.onUpdate) {
            options.onUpdate(status);
          }

        } catch (error) {
          console.error(`Error monitoreando transacción ${hash}:`, error);
          
          const status = this.monitoredTransactions.get(hash)!;
          status.status = 'failed';
          status.error = error instanceof Error ? error.message : 'Unknown error';
          
          this.stopMonitoring(hash);
          clearTimeout(timeoutHandle);
          
          secureLogger.error('Error monitoreando transacción', {
            hash,
            chainId,
            error: status.error
          }, 'BlockchainTransactionMonitor');
          
          reject(error);
        }
      };

      // Iniciar monitoreo
      monitoringHandle = setInterval(checkTransaction, 5000); // Check cada 5 segundos
      this.monitoringIntervals.set(hash, monitoringHandle);
      
      // Primera verificación inmediata
      checkTransaction();
    });
  }

  /**
   * Analizar fallo de transacción
   */
  private async analyzeFailure(
    hash: string, 
    chainId: number, 
    receipt: ethers.TransactionReceipt
  ): Promise<FailureAnalysis> {
    const provider = this.providers.get(chainId);
    if (!provider) {
      return {
        reason: 'unknown',
        description: 'Provider no disponible para análisis',
        canRetry: false,
        suggestedFix: 'Verificar configuración del provider',
        severity: 'medium'
      };
    }

    try {
      // Obtener transacción original
      const tx = await provider.getTransaction(hash);
      if (!tx) {
        return {
          reason: 'unknown',
          description: 'Transacción no encontrada',
          canRetry: false,
          suggestedFix: 'Verificar hash de transacción',
          severity: 'low'
        };
      }

      // Analizar gas usage
      const gasUsedRatio = Number(receipt.gasUsed) / Number(tx.gasLimit);
      
      if (gasUsedRatio > 0.95) {
        return {
          reason: 'gas_limit',
          description: 'Transacción falló por gas limit insuficiente',
          canRetry: true,
          suggestedFix: `Aumentar gas limit a ${Math.ceil(Number(tx.gasLimit) * 1.5)}`,
          severity: 'medium'
        };
      }

      // Intentar replay para obtener razón específica
      try {
        await provider.call({
          to: tx.to,
          data: tx.data,
          value: tx.value,
          gasLimit: tx.gasLimit,
          gasPrice: tx.gasPrice
        }, tx.blockNumber! - 1);
        
        return {
          reason: 'revert',
          description: 'Contrato revirtió la transacción',
          canRetry: false,
          suggestedFix: 'Verificar condiciones del contrato y parámetros',
          severity: 'high'
        };
      } catch (replayError) {
        const errorMsg = replayError instanceof Error ? replayError.message : 'Unknown error';
        
        if (errorMsg.includes('insufficient funds')) {
          return {
            reason: 'gas_price',
            description: 'Fondos insuficientes para pagar gas',
            canRetry: true,
            suggestedFix: 'Verificar balance y reducir gas price',
            severity: 'medium'
          };
        }

        if (errorMsg.includes('nonce')) {
          return {
            reason: 'nonce',
            description: 'Nonce incorrecto o ya usado',
            canRetry: true,
            suggestedFix: 'Obtener nonce correcto del network',
            severity: 'medium'
          };
        }

        return {
          reason: 'revert',
          description: `Contrato revirtió: ${errorMsg}`,
          canRetry: false,
          suggestedFix: 'Revisar lógica del contrato y parámetros',
          severity: 'high'
        };
      }

    } catch (error) {
      return {
        reason: 'network',
        description: 'Error de red durante el análisis',
        canRetry: true,
        suggestedFix: 'Reintentar después de verificar conectividad',
        severity: 'medium'
      };
    }
  }

  /**
   * Registrar fallo para análisis posterior
   */
  private recordFailure(hash: string, analysis: FailureAnalysis): void {
    if (!this.failureHistory.has(hash)) {
      this.failureHistory.set(hash, []);
    }
    this.failureHistory.get(hash)!.push(analysis);

    // Mantener historial limitado
    if (this.failureHistory.size > 1000) {
      const oldestKey = this.failureHistory.keys().next().value;
      this.failureHistory.delete(oldestKey);
    }
  }

  /**
   * Detener monitoreo de transacción
   */
  private stopMonitoring(hash: string): void {
    const interval = this.monitoringIntervals.get(hash);
    if (interval) {
      clearInterval(interval);
      this.monitoringIntervals.delete(hash);
    }
  }

  /**
   * Estimar gas óptimo para transacción
   */
  async estimateOptimalGas(
    transaction: any, 
    chainId: number
  ): Promise<{
    gasLimit: number;
    gasPrice: string;
    maxFeePerGas?: string;
    maxPriorityFeePerGas?: string;
  }> {
    const provider = this.providers.get(chainId);
    if (!provider) {
      throw new Error(`Provider no disponible para chain ${chainId}`);
    }

    try {
      // Estimar gas limit
      const estimatedGas = await provider.estimateGas(transaction);
      const gasLimit = Math.ceil(Number(estimatedGas) * 1.2); // 20% buffer

      // Obtener gas price actual
      const feeData = await provider.getFeeData();
      
      if (feeData.maxFeePerGas && feeData.maxPriorityFeePerGas) {
        // EIP-1559 transaction
        return {
          gasLimit,
          gasPrice: feeData.gasPrice?.toString() || '20000000000',
          maxFeePerGas: feeData.maxFeePerGas.toString(),
          maxPriorityFeePerGas: feeData.maxPriorityFeePerGas.toString()
        };
      } else {
        // Legacy transaction
        return {
          gasLimit,
          gasPrice: feeData.gasPrice?.toString() || '20000000000'
        };
      }

    } catch (error) {
      secureLogger.error('Error estimando gas', {
        chainId,
        transaction,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'BlockchainTransactionMonitor');

      // Fallback values
      return {
        gasLimit: 200000,
        gasPrice: '20000000000' // 20 gwei
      };
    }
  }

  /**
   * Verificar si una transacción está siendo frontrun
   */
  async detectMEVAttack(hash: string, chainId: number): Promise<{
    isMEVAttack: boolean;
    confidence: number;
    attackType?: 'frontrun' | 'sandwich' | 'backrun';
    details?: string;
  }> {
    if (!this.config.mevDetectionEnabled) {
      return { isMEVAttack: false, confidence: 0 };
    }

    const provider = this.providers.get(chainId);
    if (!provider) {
      return { isMEVAttack: false, confidence: 0 };
    }

    try {
      const tx = await provider.getTransaction(hash);
      if (!tx || !tx.blockNumber) {
        return { isMEVAttack: false, confidence: 0 };
      }

      // Obtener transacciones del mismo bloque
      const block = await provider.getBlock(tx.blockNumber, true);
      if (!block || !block.transactions) {
        return { isMEVAttack: false, confidence: 0 };
      }

      const txIndex = block.transactions.findIndex(blockTx => 
        typeof blockTx === 'object' && blockTx.hash === hash
      );

      if (txIndex === -1) {
        return { isMEVAttack: false, confidence: 0 };
      }

      // Analizar transacciones adyacentes
      const prevTx = txIndex > 0 ? block.transactions[txIndex - 1] : null;
      const nextTx = txIndex < block.transactions.length - 1 ? block.transactions[txIndex + 1] : null;

      let confidence = 0;
      let attackType: 'frontrun' | 'sandwich' | 'backrun' | undefined;
      let details = '';

      // Detectar frontrunning (transacción similar antes)
      if (prevTx && typeof prevTx === 'object') {
        if (prevTx.to === tx.to && 
            prevTx.gasPrice && tx.gasPrice &&
            BigInt(prevTx.gasPrice) > BigInt(tx.gasPrice)) {
          confidence += 40;
          attackType = 'frontrun';
          details += 'Transacción similar con mayor gas price detectada antes. ';
        }
      }

      // Detectar sandwich attack (transacciones antes y después)
      if (prevTx && nextTx && 
          typeof prevTx === 'object' && typeof nextTx === 'object') {
        if (prevTx.to === tx.to && nextTx.to === tx.to) {
          confidence += 60;
          attackType = 'sandwich';
          details += 'Transacciones de sandwich detectadas. ';
        }
      }

      // Detectar backrunning (transacción que aprovecha el resultado)
      if (nextTx && typeof nextTx === 'object') {
        if (nextTx.to === tx.to &&
            nextTx.gasPrice && tx.gasPrice &&
            BigInt(nextTx.gasPrice) >= BigInt(tx.gasPrice)) {
          confidence += 30;
          attackType = attackType || 'backrun';
          details += 'Transacción de backrun detectada. ';
        }
      }

      const isMEVAttack = confidence >= 50;

      if (isMEVAttack) {
        secureLogger.warn('Posible ataque MEV detectado', {
          hash,
          chainId,
          attackType,
          confidence,
          details
        }, 'BlockchainTransactionMonitor');
      }

      return {
        isMEVAttack,
        confidence,
        attackType,
        details
      };

    } catch (error) {
      secureLogger.error('Error detectando MEV', {
        hash,
        chainId,
        error: error instanceof Error ? error.message : 'Unknown error'
      }, 'BlockchainTransactionMonitor');

      return { isMEVAttack: false, confidence: 0 };
    }
  }

  /**
   * Obtener estadísticas de monitoreo
   */
  getMonitoringStats(): {
    activeMonitoring: number;
    totalMonitored: number;
    successRate: number;
    failuresByReason: Record<string, number>;
    avgConfirmationTime: number;
  } {
    const total = this.monitoredTransactions.size;
    const completed = Array.from(this.monitoredTransactions.values())
      .filter(tx => tx.status === 'confirmed' || tx.status === 'failed').length;
    const successful = Array.from(this.monitoredTransactions.values())
      .filter(tx => tx.status === 'confirmed').length;

    const failuresByReason: Record<string, number> = {};
    for (const failures of this.failureHistory.values()) {
      for (const failure of failures) {
        failuresByReason[failure.reason] = (failuresByReason[failure.reason] || 0) + 1;
      }
    }

    return {
      activeMonitoring: this.monitoringIntervals.size,
      totalMonitored: total,
      successRate: completed > 0 ? (successful / completed) * 100 : 100,
      failuresByReason,
      avgConfirmationTime: 30000 // Placeholder - calcular real
    };
  }

  /**
   * Limpiar monitoreo y historial
   */
  cleanup(): void {
    // Detener todos los monitoreos activos
    for (const interval of this.monitoringIntervals.values()) {
      clearInterval(interval);
    }
    this.monitoringIntervals.clear();

    // Limpiar datos antiguos
    const cutoff = Date.now() - 24 * 60 * 60 * 1000; // 24 horas
    
    for (const [hash, status] of this.monitoredTransactions) {
      if (new Date(status.timestamp).getTime() < cutoff) {
        this.monitoredTransactions.delete(hash);
      }
    }

    console.log('🧹 Limpieza de monitoreo completada');
  }
}

// Export singleton instance
export const blockchainTransactionMonitor = BlockchainTransactionMonitor.getInstance();
export default BlockchainTransactionMonitor;
