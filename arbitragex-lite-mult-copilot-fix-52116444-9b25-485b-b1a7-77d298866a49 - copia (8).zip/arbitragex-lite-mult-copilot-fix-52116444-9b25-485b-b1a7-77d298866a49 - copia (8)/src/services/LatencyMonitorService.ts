/**
 * Servicio de Monitoreo de Latencia para ArbitrageX
 * Proporciona indicadores de latencia en tiempo real para optimizar la ejecución de estrategias
 */

export interface LatencyMetrics {
    timestamp: number;
    rpcLatency: number; // en ms
    mempoolLatency: number; // en ms
    blockConfirmationLatency: number; // en ms
    totalExecutionLatency: number; // en ms
    networkCongestion: 'low' | 'medium' | 'high';
    recommendedGasAdjustment: number;
}

export interface ChainLatencyProfile {
    chain: string;
    avgRpcLatency: number;
    avgBlockTime: number;
    avgConfirmationTime: number;
    optimalExecutionWindow: number; // en ms
    gasPriceSensitivity: number; // factor de sensibilidad
}

export interface LatencyAlert {
    id: string;
    type: 'high-latency' | 'network-congestion' | 'optimal-execution' | 'gas-spike';
    chain: string;
    severity: 'critical' | 'warning' | 'info';
    message: string;
    timestamp: number;
    recommendedAction: string;
}

export class LatencyMonitorService {
    private latencyHistory: Map<string, LatencyMetrics[]>;
    private chainProfiles: Map<string, ChainLatencyProfile>;
    private activeAlerts: Map<string, LatencyAlert>;
    private monitoringInterval: NodeJS.Timeout | null;
    private isMonitoring: boolean = false;
    private maxHistorySize = 1000; // Máximo de métricas históricas por chain

    constructor() {
        this.latencyHistory = new Map();
        this.chainProfiles = new Map();
        this.activeAlerts = new Map();
        this.monitoringInterval = null;
        this.initializeChainProfiles();
    }

    /**
     * Inicializar perfiles de latencia por blockchain
     */
    private initializeChainProfiles() {
        const profiles: ChainLatencyProfile[] = [
            {
                chain: 'ethereum',
                avgRpcLatency: 150,
                avgBlockTime: 12000,
                avgConfirmationTime: 180000,
                optimalExecutionWindow: 5000,
                gasPriceSensitivity: 1.0
            },
            {
                chain: 'bsc',
                avgRpcLatency: 80,
                avgBlockTime: 3000,
                avgConfirmationTime: 9000,
                optimalExecutionWindow: 2000,
                gasPriceSensitivity: 0.8
            },
            {
                chain: 'polygon',
                avgRpcLatency: 120,
                avgBlockTime: 2000,
                avgConfirmationTime: 6000,
                optimalExecutionWindow: 1500,
                gasPriceSensitivity: 0.9
            },
            {
                chain: 'arbitrum',
                avgRpcLatency: 60,
                avgBlockTime: 250,
                avgConfirmationTime: 1000,
                optimalExecutionWindow: 500,
                gasPriceSensitivity: 0.6
            },
            {
                chain: 'optimism',
                avgRpcLatency: 70,
                avgBlockTime: 250,
                avgConfirmationTime: 1000,
                optimalExecutionWindow: 500,
                gasPriceSensitivity: 0.6
            },
            {
                chain: 'base',
                avgRpcLatency: 65,
                avgBlockTime: 250,
                avgConfirmationTime: 1000,
                optimalExecutionWindow: 500,
                gasPriceSensitivity: 0.6
            },
            {
                chain: 'avalanche',
                avgRpcLatency: 100,
                avgBlockTime: 2000,
                avgConfirmationTime: 6000,
                optimalExecutionWindow: 1500,
                gasPriceSensitivity: 0.85
            },
            {
                chain: 'fantom',
                avgRpcLatency: 90,
                avgBlockTime: 1000,
                avgConfirmationTime: 3000,
                optimalExecutionWindow: 1000,
                gasPriceSensitivity: 0.75
            }
        ];

        profiles.forEach(profile => {
            this.chainProfiles.set(profile.chain, profile);
        });
    }

    /**
     * Iniciar monitoreo de latencia
     */
    startMonitoring(intervalMs: number = 5000): void {
        if (this.isMonitoring) return;

        this.isMonitoring = true;
        this.monitoringInterval = setInterval(() => {
            this.updateLatencyMetrics();
        }, intervalMs);

        console.log('🚀 Monitoreo de latencia iniciado');
    }

    /**
     * Detener monitoreo de latencia
     */
    stopMonitoring(): void {
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
            this.monitoringInterval = null;
        }
        this.isMonitoring = false;
        console.log('⏹️ Monitoreo de latencia detenido');
    }

    /**
     * Actualizar métricas de latencia para todas las chains
     */
    private async updateLatencyMetrics(): Promise<void> {
        for (const [chain, profile] of this.chainProfiles) {
            try {
                const metrics = await this.measureChainLatency(chain, profile);
                this.storeLatencyMetrics(chain, metrics);
                this.checkLatencyAlerts(chain, metrics);
            } catch (error) {
                console.error(`Error midiendo latencia para ${chain}:`, error);
            }
        }
    }

    /**
     * Medir latencia de una blockchain específica
     */
    async measureChainLatency(
        chain: string,
        profile: ChainLatencyProfile
    ): Promise<LatencyMetrics> {
        const timestamp = Date.now();

        // Simular medición de RPC latency
        const rpcLatency = await this.measureRPCLatency(chain);
        
        // Simular medición de mempool latency
        const mempoolLatency = await this.measureMempoolLatency(chain);
        
        // Simular medición de block confirmation latency
        const blockConfirmationLatency = await this.measureBlockConfirmationLatency(chain, profile);
        
        // Calcular latencia total de ejecución
        const totalExecutionLatency = rpcLatency + mempoolLatency + blockConfirmationLatency;
        
        // Determinar nivel de congestión de red
        const networkCongestion = this.determineNetworkCongestion(chain, totalExecutionLatency, profile);
        
        // Calcular ajuste de gas recomendado
        const recommendedGasAdjustment = this.calculateGasAdjustment(
            chain,
            totalExecutionLatency,
            profile
        );

        return {
            timestamp,
            rpcLatency,
            mempoolLatency,
            blockConfirmationLatency,
            totalExecutionLatency,
            networkCongestion,
            recommendedGasAdjustment
        };
    }

    /**
     * Medir latencia de RPC
     */
    private async measureRPCLatency(chain: string): Promise<number> {
        // Simular medición de latencia RPC
        const baseLatency = this.chainProfiles.get(chain)?.avgRpcLatency || 100;
        const variation = (Math.random() - 0.5) * 0.4; // ±20% variación
        
        return Math.max(10, baseLatency * (1 + variation));
    }

    /**
     * Medir latencia de mempool
     */
    private async measureMempoolLatency(chain: string): Promise<number> {
        // Simular latencia de mempool basada en congestión de red
        const baseLatency = 50 + Math.random() * 100; // 50-150ms base
        
        // Añadir variación por congestión
        const congestionFactor = 1 + Math.random() * 2; // 1x-3x
        
        return Math.round(baseLatency * congestionFactor);
    }

    /**
     * Medir latencia de confirmación de bloque
     */
    private async measureBlockConfirmationLatency(
        chain: string,
        profile: ChainLatencyProfile
    ): Promise<number> {
        // Simular latencia de confirmación basada en block time
        const baseLatency = profile.avgConfirmationTime;
        const variation = (Math.random() - 0.5) * 0.3; // ±15% variación
        
        return Math.round(baseLatency * (1 + variation));
    }

    /**
     * Determinar nivel de congestión de red
     */
    private determineNetworkCongestion(
        chain: string,
        totalLatency: number,
        profile: ChainLatencyProfile
    ): 'low' | 'medium' | 'high' {
        const expectedLatency = profile.avgRpcLatency + profile.avgConfirmationTime;
        const latencyRatio = totalLatency / expectedLatency;

        if (latencyRatio < 1.2) return 'low';
        if (latencyRatio < 1.8) return 'medium';
        return 'high';
    }

    /**
     * Calcular ajuste de gas recomendado
     */
    private calculateGasAdjustment(
        chain: string,
        totalLatency: number,
        profile: ChainLatencyProfile
    ): number {
        const expectedLatency = profile.avgRpcLatency + profile.avgConfirmationTime;
        const latencyRatio = totalLatency / expectedLatency;
        
        // Factor base de ajuste
        let adjustment = 1.0;
        
        if (latencyRatio > 1.5) {
            // Alta congestión - aumentar gas significativamente
            adjustment = 1.5 + (latencyRatio - 1.5) * profile.gasPriceSensitivity;
        } else if (latencyRatio > 1.2) {
            // Congestión moderada - aumentar gas moderadamente
            adjustment = 1.0 + (latencyRatio - 1.2) * profile.gasPriceSensitivity;
        } else if (latencyRatio < 0.8) {
            // Red rápida - posiblemente reducir gas
            adjustment = Math.max(0.8, 1.0 - (0.8 - latencyRatio) * 0.5);
        }
        
        return Math.round(adjustment * 100) / 100; // Redondear a 2 decimales
    }

    /**
     * Almacenar métricas de latencia
     */
    private storeLatencyMetrics(chain: string, metrics: LatencyMetrics): void {
        if (!this.latencyHistory.has(chain)) {
            this.latencyHistory.set(chain, []);
        }

        const history = this.latencyHistory.get(chain)!;
        history.push(metrics);

        // Mantener solo las últimas métricas
        if (history.length > this.maxHistorySize) {
            history.splice(0, history.length - this.maxHistorySize);
        }
    }

    /**
     * Verificar alertas de latencia
     */
    private checkLatencyAlerts(chain: string, metrics: LatencyMetrics): void {
        const profile = this.chainProfiles.get(chain);
        if (!profile) return;

        // Alerta de latencia alta
        if (metrics.totalExecutionLatency > profile.avgConfirmationTime * 1.5) {
            this.createLatencyAlert({
                id: `high-latency-${chain}-${Date.now()}`,
                type: 'high-latency',
                chain,
                severity: 'warning',
                message: `Latencia alta detectada en ${chain}: ${metrics.totalExecutionLatency}ms`,
                timestamp: Date.now(),
                recommendedAction: `Considerar aumentar gas price o cambiar a L2`
            });
        }

        // Alerta de congestión de red
        if (metrics.networkCongestion === 'high') {
            this.createLatencyAlert({
                id: `congestion-${chain}-${Date.now()}`,
                type: 'network-congestion',
                chain,
                severity: 'critical',
                message: `Alta congestión de red en ${chain}`,
                timestamp: Date.now(),
                recommendedAction: `Aumentar gas price a ${metrics.recommendedGasAdjustment}x o esperar`
            });
        }

        // Alerta de ejecución óptima
        if (metrics.totalExecutionLatency < profile.optimalExecutionWindow) {
            this.createLatencyAlert({
                id: `optimal-${chain}-${Date.now()}`,
                type: 'optimal-execution',
                chain,
                severity: 'info',
                message: `Condiciones óptimas de ejecución en ${chain}`,
                timestamp: Date.now(),
                recommendedAction: `Ejecutar estrategias con gas price estándar`
            });
        }
    }

    /**
     * Crear alerta de latencia
     */
    private createLatencyAlert(alert: LatencyAlert): void {
        this.activeAlerts.set(alert.id, alert);
        
        // Limpiar alertas antiguas (más de 1 hora)
        const oneHourAgo = Date.now() - 3600000;
        for (const [id, existingAlert] of this.activeAlerts) {
            if (existingAlert.timestamp < oneHourAgo) {
                this.activeAlerts.delete(id);
            }
        }

        // Emitir evento para el frontend
        this.emitLatencyAlert(alert);
    }

    /**
     * Emitir alerta de latencia (para integración con frontend)
     */
    private emitLatencyAlert(alert: LatencyAlert): void {
        // Aquí se puede integrar con WebSocket o Server-Sent Events
        if (typeof window !== 'undefined' && window.dispatchEvent) {
            window.dispatchEvent(new CustomEvent('latency-alert', { detail: alert }));
        }
    }

    /**
     * Obtener métricas de latencia actuales
     */
    getCurrentLatencyMetrics(chain?: string): LatencyMetrics[] {
        if (chain) {
            return this.latencyHistory.get(chain) || [];
        }

        const allMetrics: LatencyMetrics[] = [];
        for (const metrics of this.latencyHistory.values()) {
            if (metrics.length > 0) {
                allMetrics.push(metrics[metrics.length - 1]);
            }
        }
        return allMetrics;
    }

    /**
     * Obtener métricas de latencia históricas
     */
    getLatencyHistory(
        chain: string,
        timeWindow: number = 3600000 // 1 hora por defecto
    ): LatencyMetrics[] {
        const history = this.latencyHistory.get(chain) || [];
        const cutoffTime = Date.now() - timeWindow;
        
        return history.filter(metrics => metrics.timestamp >= cutoffTime);
    }

    /**
     * Obtener alertas activas
     */
    getActiveAlerts(chain?: string): LatencyAlert[] {
        const alerts = Array.from(this.activeAlerts.values());
        
        if (chain) {
            return alerts.filter(alert => alert.chain === chain);
        }
        
        return alerts;
    }

    /**
     * Obtener perfil de latencia de una chain
     */
    getChainLatencyProfile(chain: string): ChainLatencyProfile | undefined {
        return this.chainProfiles.get(chain);
    }

    /**
     * Calcular métricas agregadas de latencia
     */
    getAggregatedLatencyMetrics(chain: string, timeWindow: number = 3600000): {
        avgRpcLatency: number;
        avgTotalLatency: number;
        avgNetworkCongestion: number;
        optimalExecutionPercentage: number;
        gasAdjustmentTrend: number;
    } {
        const history = this.getLatencyHistory(chain, timeWindow);
        
        if (history.length === 0) {
            return {
                avgRpcLatency: 0,
                avgTotalLatency: 0,
                avgNetworkCongestion: 0,
                optimalExecutionPercentage: 0,
                gasAdjustmentTrend: 0
            };
        }

        const avgRpcLatency = history.reduce((sum, m) => sum + m.rpcLatency, 0) / history.length;
        const avgTotalLatency = history.reduce((sum, m) => sum + m.totalExecutionLatency, 0) / history.length;
        
        const congestionScores = history.map(m => m.networkCongestion === 'high' ? 1 : m.networkCongestion === 'medium' ? 0.5 : 0);
        const avgNetworkCongestion = congestionScores.reduce((sum, score) => sum + score, 0) / congestionScores.length;
        
        const profile = this.chainProfiles.get(chain);
        const optimalExecutions = history.filter(m => 
            profile && m.totalExecutionLatency < profile.optimalExecutionWindow
        ).length;
        const optimalExecutionPercentage = (optimalExecutions / history.length) * 100;
        
        const gasAdjustments = history.map(m => m.recommendedGasAdjustment);
        const gasAdjustmentTrend = gasAdjustments[gasAdjustments.length - 1] - gasAdjustments[0];

        return {
            avgRpcLatency: Math.round(avgRpcLatency),
            avgTotalLatency: Math.round(avgTotalLatency),
            avgNetworkCongestion: Math.round(avgNetworkCongestion * 100) / 100,
            optimalExecutionPercentage: Math.round(optimalExecutionPercentage * 100) / 100,
            gasAdjustmentTrend: Math.round(gasAdjustmentTrend * 100) / 100
        };
    }

    /**
     * Obtener recomendaciones de ejecución basadas en latencia
     */
    getExecutionRecommendations(chain: string): {
        isOptimal: boolean;
        recommendedGasMultiplier: number;
        executionWindow: number;
        riskLevel: 'low' | 'medium' | 'high';
        recommendations: string[];
    } {
        const currentMetrics = this.getCurrentLatencyMetrics(chain)[0];
        const profile = this.chainProfiles.get(chain);
        
        if (!currentMetrics || !profile) {
            return {
                isOptimal: false,
                recommendedGasMultiplier: 1.0,
                executionWindow: 0,
                riskLevel: 'high',
                recommendations: ['No hay datos suficientes para recomendar']
            };
        }

        const isOptimal = currentMetrics.totalExecutionLatency < profile.optimalExecutionWindow;
        const recommendedGasMultiplier = currentMetrics.recommendedGasAdjustment;
        
        let executionWindow = profile.optimalExecutionWindow;
        if (currentMetrics.networkCongestion === 'high') {
            executionWindow *= 2;
        } else if (currentMetrics.networkCongestion === 'low') {
            executionWindow *= 0.8;
        }

        let riskLevel: 'low' | 'medium' | 'high' = 'medium';
        if (currentMetrics.networkCongestion === 'low' && isOptimal) {
            riskLevel = 'low';
        } else if (currentMetrics.networkCongestion === 'high') {
            riskLevel = 'high';
        }

        const recommendations: string[] = [];
        
        if (isOptimal) {
            recommendations.push('Condiciones óptimas para ejecución');
        } else {
            recommendations.push('Considerar esperar mejores condiciones');
        }

        if (currentMetrics.networkCongestion === 'high') {
            recommendations.push('Red congestionada - aumentar gas price');
        }

        if (recommendedGasMultiplier > 1.2) {
            recommendations.push(`Usar gas price ${recommendedGasMultiplier}x para prioridad`);
        }

        if (chain === 'ethereum' && currentMetrics.totalExecutionLatency > 30000) {
            recommendations.push('Considerar migrar a L2s (Arbitrum, Optimism, Base)');
        }

        return {
            isOptimal,
            recommendedGasMultiplier,
            executionWindow: Math.round(executionWindow),
            riskLevel,
            recommendations
        };
    }

    /**
     * Limpiar historial de latencia
     */
    clearLatencyHistory(chain?: string): void {
        if (chain) {
            this.latencyHistory.delete(chain);
        } else {
            this.latencyHistory.clear();
        }
    }

    /**
     * Limpiar alertas
     */
    clearAlerts(chain?: string): void {
        if (chain) {
            for (const [id, alert] of this.activeAlerts) {
                if (alert.chain === chain) {
                    this.activeAlerts.delete(id);
                }
            }
        } else {
            this.activeAlerts.clear();
        }
    }

    /**
     * Obtener estado del monitoreo
     */
    getMonitoringStatus(): {
        isActive: boolean;
        activeChains: string[];
        totalMetrics: number;
        lastUpdate: number;
    } {
        const activeChains = Array.from(this.latencyHistory.keys());
        const totalMetrics = Array.from(this.latencyHistory.values())
            .reduce((sum, metrics) => sum + metrics.length, 0);
        
        const lastUpdate = activeChains.length > 0 
            ? Math.max(...activeChains.map(chain => {
                const metrics = this.latencyHistory.get(chain);
                return metrics && metrics.length > 0 ? metrics[metrics.length - 1].timestamp : 0;
            }))
            : 0;

        return {
            isActive: this.isMonitoring,
            activeChains,
            totalMetrics,
            lastUpdate
        };
    }
}

export default LatencyMonitorService;
