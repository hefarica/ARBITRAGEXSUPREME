/**
 * Servicio WebSocket para comunicación en tiempo real
 * Maneja conexiones, reconexiones automáticas y eventos
 */
export class WebSocketService {
  private ws: WebSocket | null = null
  private reconnectAttempts = 0
  private maxReconnectAttempts = 10
  private reconnectDelay = 1000
  private eventListeners: Map<string, Function[]> = new Map()
  private isConnecting = false
  private shouldReconnect = true
  private heartbeatInterval: NodeJS.Timeout | null = null
  private connectionTimeout: NodeJS.Timeout | null = null

  constructor(private url: string = 'ws://localhost:8080') {}

  /**
   * Conectar al WebSocket
   */
  async connect(): Promise<void> {
    if (this.ws?.readyState === WebSocket.OPEN || this.isConnecting) {
      return
    }

    this.isConnecting = true
    this.shouldReconnect = true

    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(this.url)

        // Timeout para la conexión
        this.connectionTimeout = setTimeout(() => {
          if (this.ws?.readyState !== WebSocket.OPEN) {
            this.ws?.close()
            reject(new Error('Connection timeout'))
          }
        }, 10000)

        this.ws.onopen = () => {
          console.log('✅ WebSocket connected')
          this.isConnecting = false
          this.reconnectAttempts = 0
          
          if (this.connectionTimeout) {
            clearTimeout(this.connectionTimeout)
            this.connectionTimeout = null
          }

          this.startHeartbeat()
          this.emit('connection_status', true)
          resolve()
        }

        this.ws.onmessage = (event) => {
          this.handleMessage(event)
        }

        this.ws.onclose = (event) => {
          console.log('❌ WebSocket disconnected:', event.code, event.reason)
          this.isConnecting = false
          this.stopHeartbeat()
          this.emit('connection_status', false)

          if (this.shouldReconnect && !event.wasClean) {
            this.scheduleReconnect()
          }
        }

        this.ws.onerror = (error) => {
          console.error('💥 WebSocket error:', error)
          this.isConnecting = false
          this.emit('error', error)
          
          if (this.connectionTimeout) {
            clearTimeout(this.connectionTimeout)
            this.connectionTimeout = null
          }
          
          reject(error)
        }

      } catch (error) {
        this.isConnecting = false
        reject(error)
      }
    })
  }

  /**
   * Desconectar del WebSocket
   */
  disconnect(): void {
    this.shouldReconnect = false
    this.stopHeartbeat()
    
    if (this.connectionTimeout) {
      clearTimeout(this.connectionTimeout)
      this.connectionTimeout = null
    }

    if (this.ws) {
      this.ws.close(1000, 'Intentional disconnect')
      this.ws = null
    }
  }

  /**
   * Enviar mensaje al servidor
   */
  send(type: string, data: any): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      const message = JSON.stringify({ type, data, timestamp: Date.now() })
      this.ws.send(message)
    } else {
      console.warn('⚠️ WebSocket not connected, message not sent:', type)
    }
  }

  /**
   * Suscribirse a eventos
   */
  on(event: string, callback: Function): void {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, [])
    }
    this.eventListeners.get(event)!.push(callback)
  }

  /**
   * Desuscribirse de eventos
   */
  off(event: string, callback?: Function): void {
    if (!callback) {
      this.eventListeners.delete(event)
    } else {
      const listeners = this.eventListeners.get(event)
      if (listeners) {
        const index = listeners.indexOf(callback)
        if (index > -1) {
          listeners.splice(index, 1)
        }
      }
    }
  }

  /**
   * Emitir evento
   */
  private emit(event: string, data: any): void {
    const listeners = this.eventListeners.get(event)
    if (listeners) {
      listeners.forEach(callback => {
        try {
          callback(data)
        } catch (error) {
          console.error(`Error in event listener for ${event}:`, error)
        }
      })
    }
  }

  /**
   * Manejar mensajes entrantes
   */
  private handleMessage(event: MessageEvent): void {
    try {
      const message = JSON.parse(event.data)
      
      // Manejar diferentes tipos de mensajes
      switch (message.type) {
        case 'heartbeat':
          this.handleHeartbeat(message)
          break
        
        case 'arbitrage_opportunity':
          this.emit('arbitrage_opportunity', message.data)
          break
        
        case 'trade_executed':
          this.emit('trade_executed', message.data)
          break
        
        case 'security_alert':
          this.emit('security_alert', message.data)
          break
        
        case 'price_alert':
          this.emit('price_alert', message.data)
          break
        
        case 'system_status':
          this.emit('system_status', message.data)
          break
        
        case 'balance_update':
          this.emit('balance_update', message.data)
          break
        
        case 'strategy_update':
          this.emit('strategy_update', message.data)
          break
        
        case 'mev_detected':
          this.emit('mev_detected', message.data)
          break
        
        case 'gas_price_update':
          this.emit('gas_price_update', message.data)
          break
        
        case 'volume_spike':
          this.emit('volume_spike', message.data)
          break
        
        default:
          console.log('Unknown message type:', message.type)
          this.emit('unknown_message', message)
      }
      
    } catch (error) {
      console.error('Error parsing WebSocket message:', error)
    }
  }

  /**
   * Manejar heartbeat
   */
  private handleHeartbeat(message: any): void {
    // Responder al heartbeat del servidor
    this.send('heartbeat_response', { 
      timestamp: Date.now(),
      clientTime: new Date().toISOString()
    })
  }

  /**
   * Iniciar heartbeat
   */
  private startHeartbeat(): void {
    this.heartbeatInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.send('heartbeat', { 
          timestamp: Date.now(),
          clientTime: new Date().toISOString()
        })
      }
    }, 30000) // 30 segundos
  }

  /**
   * Detener heartbeat
   */
  private stopHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval)
      this.heartbeatInterval = null
    }
  }

  /**
   * Programar reconexión
   */
  private scheduleReconnect(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('❌ Max reconnection attempts reached')
      this.emit('max_reconnect_attempts_reached', this.reconnectAttempts)
      return
    }

    const delay = Math.min(this.reconnectDelay * Math.pow(2, this.reconnectAttempts), 30000)
    this.reconnectAttempts++

    console.log(`🔄 Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`)
    this.emit('reconnecting', { attempt: this.reconnectAttempts, delay })

    setTimeout(() => {
      if (this.shouldReconnect) {
        this.connect().catch(error => {
          console.error('Reconnection failed:', error)
        })
      }
    }, delay)
  }

  /**
   * Obtener estado de la conexión
   */
  getConnectionState(): string {
    if (!this.ws) return 'CLOSED'
    
    switch (this.ws.readyState) {
      case WebSocket.CONNECTING: return 'CONNECTING'
      case WebSocket.OPEN: return 'OPEN'
      case WebSocket.CLOSING: return 'CLOSING'
      case WebSocket.CLOSED: return 'CLOSED'
      default: return 'UNKNOWN'
    }
  }

  /**
   * Verificar si está conectado
   */
  isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN
  }

  /**
   * Suscribirse a actualizaciones de oportunidades de arbitraje
   */
  subscribeToArbitrageOpportunities(callback: (opportunity: any) => void): void {
    this.on('arbitrage_opportunity', callback)
    this.send('subscribe', { channel: 'arbitrage_opportunities' })
  }

  /**
   * Suscribirse a actualizaciones de trades
   */
  subscribeToTradeUpdates(callback: (trade: any) => void): void {
    this.on('trade_executed', callback)
    this.send('subscribe', { channel: 'trade_updates' })
  }

  /**
   * Suscribirse a alertas de seguridad
   */
  subscribeToSecurityAlerts(callback: (alert: any) => void): void {
    this.on('security_alert', callback)
    this.send('subscribe', { channel: 'security_alerts' })
  }

  /**
   * Suscribirse a alertas de precio
   */
  subscribeToPriceAlerts(callback: (alert: any) => void): void {
    this.on('price_alert', callback)
    this.send('subscribe', { channel: 'price_alerts' })
  }

  /**
   * Suscribirse a actualizaciones de balance
   */
  subscribeToBalanceUpdates(callback: (balance: any) => void): void {
    this.on('balance_update', callback)
    this.send('subscribe', { channel: 'balance_updates' })
  }

  /**
   * Suscribirse a actualizaciones de estado del sistema
   */
  subscribeToSystemStatus(callback: (status: any) => void): void {
    this.on('system_status', callback)
    this.send('subscribe', { channel: 'system_status' })
  }

  /**
   * Desuscribirse de un canal
   */
  unsubscribe(channel: string): void {
    this.send('unsubscribe', { channel })
  }

  /**
   * Solicitar datos históricos
   */
  requestHistoricalData(type: string, params: any): void {
    this.send('request_historical', { type, params })
  }

  /**
   * Enviar comando al sistema
   */
  sendCommand(command: string, params: any): void {
    this.send('command', { command, params })
  }
}

/**
 * Instancia global del servicio WebSocket
 */
export const websocketService = new WebSocketService(
  import.meta.env.MODE === 'production' 
    ? 'wss://api.arbitragex.com/ws'
    : 'ws://localhost:8080'
)