import { ethers } from 'ethers'
import { PriceQuote, SUPPORTED_CHAINS, COMMON_TOKENS } from './types'

export interface PriceFeed {
  source: string
  tokenAddress: string
  chainId: number
  price: number
  timestamp: number
  blockNumber?: number
  volume24h?: number
  change24h?: number
}

export interface WebSocketPriceUpdate {
  type: 'price_update' | 'block_update' | 'liquidityUpdate'
  chainId: number
  data: PriceFeed | BlockUpdate | LiquidityUpdate
}

export interface BlockUpdate {
  chainId: number
  blockNumber: number
  timestamp: number
  gasPrice: string
}

export interface LiquidityUpdate {
  chainId: number
  dex: string
  pair: string
  reserve0: string
  reserve1: string
  timestamp: number
}

export class RealTimePriceMonitor {
  private wsConnections: Map<string, WebSocket> = new Map()
  private providers: Map<number, ethers.Provider> = new Map()
  private priceCache: Map<string, PriceFeed> = new Map()
  private subscribers: Set<(update: WebSocketPriceUpdate) => void> = new Set()
  private isRunning: boolean = false
  private blockListeners: Map<number, () => void> = new Map()

  constructor(rpcUrls: Record<number, string>) {
    this.initializeProviders(rpcUrls)
  }

  private initializeProviders(rpcUrls: Record<number, string>) {
    for (const [chainId, rpcUrl] of Object.entries(rpcUrls)) {
      const provider = new ethers.JsonRpcProvider(rpcUrl)
      this.providers.set(parseInt(chainId), provider)
    }
  }

  // Start monitoring prices and blockchain events
  async startMonitoring() {
    if (this.isRunning) return

    this.isRunning = true

    // Initialize WebSocket connections for price feeds
    await this.initializePriceFeeds()
    
    // Start block monitoring for gas prices
    this.startBlockMonitoring()
    
    // Start DEX event monitoring
    this.startDEXEventMonitoring()

    console.log('Real-time price monitoring started')
  }

  // Stop monitoring
  async stopMonitoring() {
    this.isRunning = false

    // Close WebSocket connections
    for (const ws of this.wsConnections.values()) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close()
      }
    }
    this.wsConnections.clear()

    // Remove block listeners
    for (const [chainId, provider] of this.providers) {
      const listener = this.blockListeners.get(chainId)
      if (listener) {
        provider.off('block', listener)
      }
    }
    this.blockListeners.clear()

    console.log('Real-time price monitoring stopped')
  }

  // Initialize price feed WebSocket connections
  private async initializePriceFeeds() {
    // CoinGecko WebSocket for price feeds
    this.initializeCoinGeckoWS()
    
    // Binance WebSocket for additional price data
    this.initializeBinanceWS()
    
    // DEX-specific WebSockets
    this.initializeDEXWebSockets()
  }

  // Initialize CoinGecko WebSocket
  private initializeCoinGeckoWS() {
    try {
      // Note: CoinGecko doesn't have public WebSocket API
      // This is a placeholder for when they do or for alternative providers
      console.log('CoinGecko WebSocket not available, using polling instead')
      this.startCoinGeckoPricePolling()
    } catch (error) {
      console.error('Error initializing CoinGecko WebSocket:', error)
    }
  }

  // Initialize Binance WebSocket for price data
  private initializeBinanceWS() {
    const binanceWS = new WebSocket('wss://stream.binance.com:9443/ws/!ticker@arr')
    
    binanceWS.onopen = () => {
      console.log('Connected to Binance WebSocket')
      this.wsConnections.set('binance', binanceWS)
    }

    binanceWS.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        if (Array.isArray(data)) {
          for (const ticker of data) {
            this.processBinanceTicker(ticker)
          }
        }
      } catch (error) {
        console.error('Error processing Binance data:', error)
      }
    }

    binanceWS.onerror = (error) => {
      console.error('Binance WebSocket error:', error)
    }

    binanceWS.onclose = () => {
      console.log('Binance WebSocket closed')
      this.wsConnections.delete('binance')
      
      // Reconnect after 5 seconds if still running
      if (this.isRunning) {
        setTimeout(() => this.initializeBinanceWS(), 5000)
      }
    }
  }

  // Initialize DEX-specific WebSockets
  private initializeDEXWebSockets() {
    // The Graph Protocol WebSocket for Uniswap data
    this.initializeUniswapWS()
    
    // Additional DEX WebSockets can be added here
  }

  // Initialize Uniswap WebSocket through The Graph
  private initializeUniswapWS() {
    try {
      // The Graph WebSocket subscription
      const graphWS = new WebSocket('wss://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3')
      
      graphWS.onopen = () => {
        console.log('Connected to The Graph WebSocket')
        this.wsConnections.set('thegraph', graphWS)
        
        // Subscribe to pool events
        const subscription = {
          id: '1',
          type: 'start',
          payload: {
            query: `
              subscription {
                pools(first: 100, orderBy: totalValueLockedUSD, orderDirection: desc) {
                  id
                  token0 { symbol, id }
                  token1 { symbol, id }
                  feeTier
                  liquidity
                  sqrtPrice
                  token0Price
                  token1Price
                  totalValueLockedUSD
                }
              }
            `
          }
        }
        
        graphWS.send(JSON.stringify(subscription))
      }

      graphWS.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          this.processUniswapData(data)
        } catch (error) {
          console.error('Error processing Uniswap data:', error)
        }
      }

      graphWS.onerror = (error) => {
        console.error('The Graph WebSocket error:', error)
      }

      graphWS.onclose = () => {
        console.log('The Graph WebSocket closed')
        this.wsConnections.delete('thegraph')
        
        if (this.isRunning) {
          setTimeout(() => this.initializeUniswapWS(), 5000)
        }
      }
    } catch (error) {
      console.error('Error initializing The Graph WebSocket:', error)
    }
  }

  // Start polling CoinGecko API for prices
  private startCoinGeckoPricePolling() {
    const pollInterval = 10000 // 10 seconds
    
    const poll = async () => {
      if (!this.isRunning) return

      try {
        // Get major token prices
        const response = await fetch(
          'https://api.coingecko.com/api/v3/simple/price?ids=ethereum,bitcoin,binancecoin,matic-network,optimism&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true'
        )
        
        if (response.ok) {
          const data = await response.json()
          this.processCoinGeckoData(data)
        }
      } catch (error) {
        console.error('Error polling CoinGecko:', error)
      }

      if (this.isRunning) {
        setTimeout(poll, pollInterval)
      }
    }

    poll()
  }

  // Start monitoring blockchain blocks
  private startBlockMonitoring() {
    for (const [chainId, provider] of this.providers) {
      const blockListener = async (blockNumber: number) => {
        try {
          const block = await provider.getBlock(blockNumber)
          if (block) {
            const gasPrice = await provider.getFeeData()
            
            const blockUpdate: BlockUpdate = {
              chainId,
              blockNumber,
              timestamp: block.timestamp * 1000,
              gasPrice: gasPrice.gasPrice?.toString() || '0'
            }

            this.notifySubscribers({
              type: 'block_update',
              chainId,
              data: blockUpdate
            })
          }
        } catch (error) {
          console.error(`Error processing block ${blockNumber} on chain ${chainId}:`, error)
        }
      }

      provider.on('block', blockListener)
      this.blockListeners.set(chainId, blockListener)
    }
  }

  // Start monitoring DEX events
  private startDEXEventMonitoring() {
    // Monitor Uniswap V2 Sync events
    this.monitorUniswapV2Events()
    
    // Monitor Uniswap V3 Swap events
    this.monitorUniswapV3Events()
  }

  // Monitor Uniswap V2 events
  private monitorUniswapV2Events() {
    for (const [chainId, provider] of this.providers) {
      try {
        // Uniswap V2 Pair contract ABI for Sync event
        const pairAbi = [
          'event Sync(uint112 reserve0, uint112 reserve1)'
        ]

        // Filter for Sync events
        const filter = {
          topics: [ethers.id('Sync(uint112,uint112)')]
        }

        provider.on(filter, (log) => {
          try {
            const parsedLog = ethers.AbiCoder.defaultAbiCoder().decode(
              ['uint112', 'uint112'],
              log.data
            )

            const liquidityUpdate: LiquidityUpdate = {
              chainId,
              dex: 'uniswap-v2',
              pair: log.address,
              reserve0: parsedLog[0].toString(),
              reserve1: parsedLog[1].toString(),
              timestamp: Date.now()
            }

            this.notifySubscribers({
              type: 'liquidityUpdate',
              chainId,
              data: liquidityUpdate
            })
          } catch (error) {
            console.error('Error parsing Uniswap V2 Sync event:', error)
          }
        })
      } catch (error) {
        console.error(`Error setting up Uniswap V2 monitoring on chain ${chainId}:`, error)
      }
    }
  }

  // Monitor Uniswap V3 events
  private monitorUniswapV3Events() {
    for (const [chainId, provider] of this.providers) {
      try {
        // Uniswap V3 Pool contract ABI for Swap event
        const poolAbi = [
          'event Swap(address indexed sender, address indexed recipient, int256 amount0, int256 amount1, uint160 sqrtPriceX96, uint128 liquidity, int24 tick)'
        ]

        // Filter for Swap events
        const filter = {
          topics: [ethers.id('Swap(address,address,int256,int256,uint160,uint128,int24)')]
        }

        provider.on(filter, (log) => {
          try {
            const parsedLog = ethers.AbiCoder.defaultAbiCoder().decode(
              ['address', 'address', 'int256', 'int256', 'uint160', 'uint128', 'int24'],
              log.data
            )

            // Extract price information from sqrtPriceX96
            const sqrtPriceX96 = parsedLog[4]
            const price = this.sqrtPriceX96ToPrice(sqrtPriceX96)

            const priceFeed: PriceFeed = {
              source: 'uniswap-v3',
              tokenAddress: log.address,
              chainId,
              price,
              timestamp: Date.now(),
              blockNumber: log.blockNumber
            }

            this.updatePriceCache(priceFeed)
            this.notifySubscribers({
              type: 'price_update',
              chainId,
              data: priceFeed
            })
          } catch (error) {
            console.error('Error parsing Uniswap V3 Swap event:', error)
          }
        })
      } catch (error) {
        console.error(`Error setting up Uniswap V3 monitoring on chain ${chainId}:`, error)
      }
    }
  }

  // Process Binance ticker data
  private processBinanceTicker(ticker: any) {
    try {
      const symbol = ticker.s // Symbol like 'ETHUSDT'
      const price = parseFloat(ticker.c) // Current price
      const change24h = parseFloat(ticker.P) // 24h change percentage
      const volume24h = parseFloat(ticker.v) // 24h volume

      // Map Binance symbols to our token addresses
      const tokenMapping = this.getBinanceTokenMapping()
      const tokenInfo = tokenMapping[symbol]

      if (tokenInfo) {
        const priceFeed: PriceFeed = {
          source: 'binance',
          tokenAddress: tokenInfo.address,
          chainId: tokenInfo.chainId,
          price,
          timestamp: Date.now(),
          volume24h,
          change24h
        }

        this.updatePriceCache(priceFeed)
        this.notifySubscribers({
          type: 'price_update',
          chainId: tokenInfo.chainId,
          data: priceFeed
        })
      }
    } catch (error) {
      console.error('Error processing Binance ticker:', error)
    }
  }

  // Process CoinGecko data
  private processCoinGeckoData(data: any) {
    try {
      const coinMapping = this.getCoinGeckoMapping()

      for (const [coinId, priceData] of Object.entries(data)) {
        const tokenInfo = coinMapping[coinId]
        if (tokenInfo && typeof priceData === 'object' && priceData !== null) {
          const priceDataObj = priceData as any
          
          const priceFeed: PriceFeed = {
            source: 'coingecko',
            tokenAddress: tokenInfo.address,
            chainId: tokenInfo.chainId,
            price: priceDataObj.usd,
            timestamp: Date.now(),
            volume24h: priceDataObj.usd_24h_vol,
            change24h: priceDataObj.usd_24h_change
          }

          this.updatePriceCache(priceFeed)
          this.notifySubscribers({
            type: 'price_update',
            chainId: tokenInfo.chainId,
            data: priceFeed
          })
        }
      }
    } catch (error) {
      console.error('Error processing CoinGecko data:', error)
    }
  }

  // Process Uniswap data from The Graph
  private processUniswapData(data: any) {
    try {
      if (data.type === 'data' && data.payload?.data?.pools) {
        for (const pool of data.payload.data.pools) {
          const token0PriceFeed: PriceFeed = {
            source: 'uniswap-v3',
            tokenAddress: pool.token0.id,
            chainId: 1, // Ethereum mainnet
            price: parseFloat(pool.token0Price),
            timestamp: Date.now()
          }

          const token1PriceFeed: PriceFeed = {
            source: 'uniswap-v3',
            tokenAddress: pool.token1.id,
            chainId: 1,
            price: parseFloat(pool.token1Price),
            timestamp: Date.now()
          }

          this.updatePriceCache(token0PriceFeed)
          this.updatePriceCache(token1PriceFeed)

          this.notifySubscribers({
            type: 'price_update',
            chainId: 1,
            data: token0PriceFeed
          })

          this.notifySubscribers({
            type: 'price_update',
            chainId: 1,
            data: token1PriceFeed
          })
        }
      }
    } catch (error) {
      console.error('Error processing Uniswap data:', error)
    }
  }

  // Update price cache
  private updatePriceCache(priceFeed: PriceFeed) {
    const key = `${priceFeed.chainId}-${priceFeed.tokenAddress}`
    this.priceCache.set(key, priceFeed)
  }

  // Notify all subscribers
  private notifySubscribers(update: WebSocketPriceUpdate) {
    for (const subscriber of this.subscribers) {
      try {
        subscriber(update)
      } catch (error) {
        console.error('Error notifying subscriber:', error)
      }
    }
  }

  // Subscribe to price updates
  subscribe(callback: (update: WebSocketPriceUpdate) => void): () => void {
    this.subscribers.add(callback)
    
    // Return unsubscribe function
    return () => {
      this.subscribers.delete(callback)
    }
  }

  // Get cached price for token
  getCachedPrice(chainId: number, tokenAddress: string): PriceFeed | null {
    const key = `${chainId}-${tokenAddress}`
    return this.priceCache.get(key) || null
  }

  // Get all cached prices
  getAllCachedPrices(): PriceFeed[] {
    return Array.from(this.priceCache.values())
  }

  // Convert Uniswap V3 sqrtPriceX96 to readable price
  private sqrtPriceX96ToPrice(sqrtPriceX96: bigint): number {
    try {
      const Q96 = BigInt(2) ** BigInt(96)
      const price = Number((sqrtPriceX96 * sqrtPriceX96) / Q96) / Number(Q96)
      return price
    } catch {
      return 0
    }
  }

  // Get Binance symbol to token mapping
  private getBinanceTokenMapping(): Record<string, {address: string, chainId: number}> {
    return {
      'ETHUSDT': { address: COMMON_TOKENS[1].WETH, chainId: 1 },
      'BTCUSDT': { address: COMMON_TOKENS[1].WBTC, chainId: 1 },
      'BNBUSDT': { address: COMMON_TOKENS[56].WBNB, chainId: 56 },
      'MATICUSDT': { address: COMMON_TOKENS[137].WMATIC, chainId: 137 }
    }
  }

  // Get CoinGecko coin ID to token mapping
  private getCoinGeckoMapping(): Record<string, {address: string, chainId: number}> {
    return {
      'ethereum': { address: COMMON_TOKENS[1].WETH, chainId: 1 },
      'bitcoin': { address: COMMON_TOKENS[1].WBTC, chainId: 1 },
      'binancecoin': { address: COMMON_TOKENS[56].WBNB, chainId: 56 },
      'matic-network': { address: COMMON_TOKENS[137].WMATIC, chainId: 137 }
    }
  }

  // Check if monitoring is running
  isMonitoringActive(): boolean {
    return this.isRunning
  }

  // Get connection status
  getConnectionStatus(): Record<string, boolean> {
    const status: Record<string, boolean> = {}
    
    for (const [name, ws] of this.wsConnections) {
      status[name] = ws.readyState === WebSocket.OPEN
    }
    
    for (const chainId of this.providers.keys()) {
      status[`chain-${chainId}`] = true // RPC connections are always considered "connected" if provider exists
    }
    
    return status
  }
}

export default RealTimePriceMonitor