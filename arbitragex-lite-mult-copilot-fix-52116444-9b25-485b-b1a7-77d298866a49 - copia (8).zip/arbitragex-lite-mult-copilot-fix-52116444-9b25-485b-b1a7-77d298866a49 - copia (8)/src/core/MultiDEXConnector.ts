import { ethers } from 'ethers'
import { DEXConfig, PriceQuote, TokenPair } from './types'

export abstract class BaseDEXConnector {
  protected config: DEXConfig
  protected provider: ethers.Provider
  protected router?: ethers.Contract
  protected factory?: ethers.Contract
  protected quoter?: ethers.Contract

  constructor(config: DEXConfig, provider: ethers.Provider) {
    this.config = config
    this.provider = provider
    this.initializeContracts()
  }

  protected abstract initializeContracts(): void
  abstract getPrice(tokenIn: string, tokenOut: string, amountIn: string): Promise<PriceQuote | null>
  abstract getOptimalPath(tokenIn: string, tokenOut: string): Promise<string[]>
  abstract executeSwap(tokenIn: string, tokenOut: string, amountIn: string, minAmountOut: string, to: string): Promise<ethers.ContractTransaction>
}

export class UniswapV2Connector extends BaseDEXConnector {
  protected initializeContracts(): void {
    const routerAbi = [
      'function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts)',
      'function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) external returns (uint[] memory amounts)',
      'function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline) external payable returns (uint[] memory amounts)',
      'function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) external returns (uint[] memory amounts)'
    ]

    const factoryAbi = [
      'function getPair(address tokenA, address tokenB) external view returns (address pair)',
      'function createPair(address tokenA, address tokenB) external returns (address pair)'
    ]

    this.router = new ethers.Contract(this.config.routerAddress, routerAbi, this.provider)
    this.factory = new ethers.Contract(this.config.factoryAddress, factoryAbi, this.provider)
  }

  async getPrice(tokenIn: string, tokenOut: string, amountIn: string): Promise<PriceQuote | null> {
    try {
      if (!this.router) throw new Error('Router not initialized')

      const path = await this.getOptimalPath(tokenIn, tokenOut)
      if (path.length === 0) return null

      const amounts = await this.router.getAmountsOut(amountIn, path)
      const amountOut = amounts[amounts.length - 1].toString()

      const price = parseFloat(amountOut) / parseFloat(amountIn)
      const priceImpact = this.calculatePriceImpact(amountIn, amountOut)

      const feeData = await this.provider.getFeeData()
      const gasPrice = feeData.gasPrice || ethers.parseUnits('20', 'gwei')
      const txCost = parseFloat(ethers.formatEther(gasPrice * BigInt(this.config.swapGasCost)))

      const currentBlock = await this.provider.getBlockNumber()

      return {
        dex: this.config.name,
        chainId: this.config.chainId,
        tokenIn,
        tokenOut,
        amountIn,
        amountOut,
        price,
        priceImpact,
        gasEstimate: this.config.swapGasCost,
        timestamp: Date.now(),
        blockNumber: currentBlock,
        txCost
      }
    } catch (error) {
      console.error(`Error getting price from ${this.config.name}:`, error)
      return null
    }
  }

  async getOptimalPath(tokenIn: string, tokenOut: string): Promise<string[]> {
    try {
      if (!this.factory) throw new Error('Factory not initialized')

      // Direct path
      const directPair = await this.factory.getPair(tokenIn, tokenOut)
      if (directPair !== ethers.ZeroAddress) {
        return [tokenIn, tokenOut]
      }

      // Try through WETH (most common intermediate token)
      const WETH = this.getWETHAddress()
      if (WETH && tokenIn !== WETH && tokenOut !== WETH) {
        const pair1 = await this.factory.getPair(tokenIn, WETH)
        const pair2 = await this.factory.getPair(WETH, tokenOut)
        
        if (pair1 !== ethers.ZeroAddress && pair2 !== ethers.ZeroAddress) {
          return [tokenIn, WETH, tokenOut]
        }
      }

      // Try through other common tokens (USDC, USDT, DAI)
      const commonTokens = this.getCommonTokens()
      for (const intermediateToken of commonTokens) {
        if (intermediateToken === tokenIn || intermediateToken === tokenOut) continue

        const pair1 = await this.factory.getPair(tokenIn, intermediateToken)
        const pair2 = await this.factory.getPair(intermediateToken, tokenOut)
        
        if (pair1 !== ethers.ZeroAddress && pair2 !== ethers.ZeroAddress) {
          return [tokenIn, intermediateToken, tokenOut]
        }
      }

      return []
    } catch (error) {
      console.error('Error finding optimal path:', error)
      return []
    }
  }

  async executeSwap(
    tokenIn: string, 
    tokenOut: string, 
    amountIn: string, 
    minAmountOut: string, 
    to: string,
    deadline?: number
  ): Promise<ethers.ContractTransaction> {
    if (!this.router) throw new Error('Router not initialized')

    const path = await this.getOptimalPath(tokenIn, tokenOut)
    if (path.length === 0) throw new Error('No valid path found')

    const swapDeadline = deadline || Math.floor(Date.now() / 1000) + 1200 // 20 minutes

    const isETHIn = tokenIn === ethers.ZeroAddress
    const isETHOut = tokenOut === ethers.ZeroAddress

    if (isETHIn) {
      return await this.router.swapExactETHForTokens(
        minAmountOut,
        path,
        to,
        swapDeadline,
        { value: amountIn }
      )
    } else if (isETHOut) {
      return await this.router.swapExactTokensForETH(
        amountIn,
        minAmountOut,
        path,
        to,
        swapDeadline
      )
    } else {
      return await this.router.swapExactTokensForTokens(
        amountIn,
        minAmountOut,
        path,
        to,
        swapDeadline
      )
    }
  }

  private calculatePriceImpact(amountIn: string, amountOut: string): number {
    // Simplified price impact calculation
    const amount = parseFloat(amountIn)
    
    if (amount > 1000000) return 5.0
    if (amount > 100000) return 2.0
    if (amount > 10000) return 1.0
    if (amount > 1000) return 0.5
    return 0.1
  }

  private getWETHAddress(): string | null {
    const wethAddresses: Record<number, string> = {
      1: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
      56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
      137: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
      42161: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
      10: '0x4200000000000000000000000000000000000006'
    }
    return wethAddresses[this.config.chainId] || null
  }

  private getCommonTokens(): string[] {
    const commonTokens: Record<number, string[]> = {
      1: [
        '0xA0b86a33E6441E94AA7e24e16eBb3a1C25C46cC2', // USDC
        '0xdAC17F958D2ee523a2206206994597C13D831ec7', // USDT
        '0x6B175474E89094C44Da98b954EedeAC495271d0F'  // DAI
      ],
      56: [
        '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', // USDC
        '0x55d398326f99059fF775485246999027B3197955', // USDT
        '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56'  // BUSD
      ],
      137: [
        '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', // USDC
        '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', // USDT
        '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063'  // DAI
      ]
    }
    return commonTokens[this.config.chainId] || []
  }
}

export class UniswapV3Connector extends BaseDEXConnector {
  protected initializeContracts(): void {
    const routerAbi = [
      'function exactInputSingle((address tokenIn, address tokenOut, uint24 fee, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum, uint160 sqrtPriceLimitX96)) external returns (uint256 amountOut)',
      'function exactInput((bytes path, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum)) external returns (uint256 amountOut)'
    ]

    const quoterAbi = [
      'function quoteExactInputSingle(address tokenIn, address tokenOut, uint24 fee, uint256 amountIn, uint160 sqrtPriceLimitX96) external returns (uint256 amountOut)',
      'function quoteExactInput(bytes memory path, uint256 amountIn) external returns (uint256 amountOut)'
    ]

    const factoryAbi = [
      'function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool)'
    ]

    this.router = new ethers.Contract(this.config.routerAddress, routerAbi, this.provider)
    this.quoter = new ethers.Contract(this.config.quoterAddress!, quoterAbi, this.provider)
    this.factory = new ethers.Contract(this.config.factoryAddress, factoryAbi, this.provider)
  }

  async getPrice(tokenIn: string, tokenOut: string, amountIn: string): Promise<PriceQuote | null> {
    try {
      if (!this.quoter) throw new Error('Quoter not initialized')

      const feeTiers = [500, 3000, 10000] // 0.05%, 0.3%, 1%
      let bestAmountOut = '0'
      let bestFee = 3000

      // Try different fee tiers and find the best price
      for (const fee of feeTiers) {
        try {
          const amountOut = await this.quoter.quoteExactInputSingle(
            tokenIn,
            tokenOut,
            fee,
            amountIn,
            0
          )
          
          if (amountOut > bestAmountOut) {
            bestAmountOut = amountOut.toString()
            bestFee = fee
          }
        } catch {
          // Fee tier might not exist
          continue
        }
      }

      if (bestAmountOut === '0') return null

      const price = parseFloat(bestAmountOut) / parseFloat(amountIn)
      const priceImpact = this.calculatePriceImpact(amountIn, bestAmountOut)

      const feeData = await this.provider.getFeeData()
      const gasPrice = feeData.gasPrice || ethers.parseUnits('20', 'gwei')
      const txCost = parseFloat(ethers.formatEther(gasPrice * BigInt(this.config.swapGasCost)))

      const currentBlock = await this.provider.getBlockNumber()

      return {
        dex: this.config.name,
        chainId: this.config.chainId,
        tokenIn,
        tokenOut,
        amountIn,
        amountOut: bestAmountOut,
        price,
        priceImpact,
        gasEstimate: this.config.swapGasCost,
        timestamp: Date.now(),
        blockNumber: currentBlock,
        txCost
      }
    } catch (error) {
      console.error(`Error getting price from ${this.config.name}:`, error)
      return null
    }
  }

  async getOptimalPath(tokenIn: string, tokenOut: string): Promise<string[]> {
    try {
      if (!this.factory) throw new Error('Factory not initialized')

      const feeTiers = [500, 3000, 10000]
      
      // Check direct pools
      for (const fee of feeTiers) {
        const pool = await this.factory.getPool(tokenIn, tokenOut, fee)
        if (pool !== ethers.ZeroAddress) {
          return [tokenIn, tokenOut]
        }
      }

      // Try through WETH
      const WETH = this.getWETHAddress()
      if (WETH && tokenIn !== WETH && tokenOut !== WETH) {
        let hasPath1 = false
        let hasPath2 = false

        for (const fee of feeTiers) {
          if (!hasPath1) {
            const pool1 = await this.factory.getPool(tokenIn, WETH, fee)
            if (pool1 !== ethers.ZeroAddress) hasPath1 = true
          }
          
          if (!hasPath2) {
            const pool2 = await this.factory.getPool(WETH, tokenOut, fee)
            if (pool2 !== ethers.ZeroAddress) hasPath2 = true
          }
        }

        if (hasPath1 && hasPath2) {
          return [tokenIn, WETH, tokenOut]
        }
      }

      return []
    } catch (error) {
      console.error('Error finding optimal path:', error)
      return []
    }
  }

  async executeSwap(
    tokenIn: string, 
    tokenOut: string, 
    amountIn: string, 
    minAmountOut: string, 
    to: string,
    deadline?: number,
    fee: number = 3000
  ): Promise<ethers.ContractTransaction> {
    if (!this.router) throw new Error('Router not initialized')

    const swapDeadline = deadline || Math.floor(Date.now() / 1000) + 1200

    const params = {
      tokenIn,
      tokenOut,
      fee,
      recipient: to,
      deadline: swapDeadline,
      amountIn,
      amountOutMinimum: minAmountOut,
      sqrtPriceLimitX96: 0
    }

    return await this.router.exactInputSingle(params)
  }

  private calculatePriceImpact(amountIn: string, amountOut: string): number {
    const amount = parseFloat(amountIn)
    
    if (amount > 1000000) return 3.0
    if (amount > 100000) return 1.5
    if (amount > 10000) return 0.8
    if (amount > 1000) return 0.3
    return 0.05
  }

  private getWETHAddress(): string | null {
    const wethAddresses: Record<number, string> = {
      1: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
      56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
      137: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
      42161: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
      10: '0x4200000000000000000000000000000000000006'
    }
    return wethAddresses[this.config.chainId] || null
  }
}

export class DEXConnectorFactory {
  static createConnector(config: DEXConfig, provider: ethers.Provider): BaseDEXConnector {
    switch (config.version) {
      case 'v2':
        return new UniswapV2Connector(config, provider)
      case 'v3':
        return new UniswapV3Connector(config, provider)
      default:
        throw new Error(`Unsupported DEX version: ${config.version}`)
    }
  }
}

export class MultiDEXConnector {
  private connectors: Map<string, BaseDEXConnector> = new Map()
  private providers: Map<number, ethers.Provider> = new Map()

  constructor(rpcUrls: Record<number, string>) {
    // Initialize providers for each chain
    for (const [chainId, rpcUrl] of Object.entries(rpcUrls)) {
      const provider = new ethers.JsonRpcProvider(rpcUrl)
      this.providers.set(parseInt(chainId), provider)
    }
  }

  // Initialize connectors for specified DEXes
  initializeConnectors(dexConfigs: DEXConfig[]) {
    for (const config of dexConfigs) {
      const provider = this.providers.get(config.chainId)
      if (!provider) {
        console.warn(`No provider found for chain ${config.chainId}`)
        continue
      }

      try {
        const connector = DEXConnectorFactory.createConnector(config, provider)
        const key = `${config.chainId}-${config.name.toLowerCase().replace(/\s+/g, '-')}`
        this.connectors.set(key, connector)
      } catch (error) {
        console.error(`Failed to initialize connector for ${config.name}:`, error)
      }
    }
  }

  // Get price from specific DEX
  async getPrice(dexKey: string, tokenIn: string, tokenOut: string, amountIn: string): Promise<PriceQuote | null> {
    const connector = this.connectors.get(dexKey)
    if (!connector) {
      console.warn(`No connector found for DEX: ${dexKey}`)
      return null
    }

    return await connector.getPrice(tokenIn, tokenOut, amountIn)
  }

  // Get prices from all available DEXes
  async getAllPrices(tokenIn: string, tokenOut: string, amountIn: string): Promise<PriceQuote[]> {
    const pricePromises = Array.from(this.connectors.entries()).map(async ([dexKey, connector]) => {
      try {
        return await connector.getPrice(tokenIn, tokenOut, amountIn)
      } catch (error) {
        console.error(`Error getting price from ${dexKey}:`, error)
        return null
      }
    })

    const results = await Promise.allSettled(pricePromises)
    return results
      .filter((result): result is PromiseFulfilledResult<PriceQuote | null> => result.status === 'fulfilled')
      .map(result => result.value)
      .filter((price): price is PriceQuote => price !== null)
  }

  // Execute swap on specific DEX
  async executeSwap(
    dexKey: string,
    tokenIn: string,
    tokenOut: string,
    amountIn: string,
    minAmountOut: string,
    to: string
  ): Promise<ethers.ContractTransaction> {
    const connector = this.connectors.get(dexKey)
    if (!connector) {
      throw new Error(`No connector found for DEX: ${dexKey}`)
    }

    return await connector.executeSwap(tokenIn, tokenOut, amountIn, minAmountOut, to)
  }

  // Get all available DEX keys
  getAvailableDEXes(): string[] {
    return Array.from(this.connectors.keys())
  }

  // Get connector for specific DEX
  getConnector(dexKey: string): BaseDEXConnector | null {
    return this.connectors.get(dexKey) || null
  }
}

export default MultiDEXConnector