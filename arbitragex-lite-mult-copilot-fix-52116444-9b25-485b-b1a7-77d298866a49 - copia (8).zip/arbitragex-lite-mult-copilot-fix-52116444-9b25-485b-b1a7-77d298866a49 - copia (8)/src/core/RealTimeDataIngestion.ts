import { ethers } from 'ethers';
import { Multicall3 } from '@multicall3/contracts';

interface PoolState {
  address: string;
  token0: string;
  token1: string;
  reserve0: ethers.BigNumber;
  reserve1: ethers.BigNumber;
  fee: number;
  blockNumber: number;
  timestamp: number;
}

interface EdgeData {
  weight: number;
  pool: string;
  dex: string;
  rate: number;
}

interface GasConfig {
  maxFeePerGas: ethers.BigNumber;
  maxPriorityFeePerGas: ethers.BigNumber;
  baseFeePerGas: ethers.BigNumber;
}

// ABI para Multicall3
const MULTICALL3_ABI = [
  'function aggregate3(tuple(address target, bytes callData)[] calls) external view returns (tuple(bool success, bytes returnData)[] returnData)'
];

// ABI para pools Uniswap V2
const UNISWAP_V2_POOL_ABI = [
  'function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)',
  'function token0() external view returns (address)',
  'function token1() external view returns (address)',
  'function fee() external view returns (uint24)'
];

export class RealTimeDataIngestion {
  private providers: Map<number, ethers.providers.WebSocketProvider>;
  private multicalls: Map<number, ethers.Contract>;
  private poolStates: Map<string, PoolState>;
  private eventEmitter: EventTarget;

  constructor(rpcConfigs: { chainId: number; wsUrl: string }[]) {
    this.providers = new Map();
    this.multicalls = new Map();
    this.poolStates = new Map();
    this.eventEmitter = new EventTarget();
    
    this.initializeProviders(rpcConfigs);
  }

  private async initializeProviders(configs: { chainId: number; wsUrl: string }[]): Promise<void> {
    for (const config of configs) {
      try {
        const provider = new ethers.providers.WebSocketProvider(config.wsUrl);
        const multicall = new ethers.Contract(
          this.getMulticallAddress(config.chainId),
          MULTICALL3_ABI,
          provider
        );
        
        this.providers.set(config.chainId, provider);
        this.multicalls.set(config.chainId, multicall);
        
        // Suscripción a nuevos bloques para actualización en tiempo real
        provider.on('block', (blockNumber) => {
          this.updatePoolStates(config.chainId, blockNumber);
        });

        // Inicializar estado de pools
        await this.updatePoolStates(config.chainId, await provider.getBlockNumber());
        
        console.log(`✅ Provider inicializado para chain ${config.chainId}`);
      } catch (error) {
        console.error(`❌ Error inicializando provider para chain ${config.chainId}:`, error);
      }
    }
  }

  private getMulticallAddress(chainId: number): string {
    // Direcciones Multicall3 por chain
    const multicallAddresses: { [key: number]: string } = {
      1: '0xcA11bde05977b3631167028862bE2a173976CA11', // Ethereum
      56: '0xcA11bde05977b3631167028862bE2a173976CA11', // BSC
      137: '0xcA11bde05977b3631167028862bE2a173976CA11', // Polygon
      43114: '0xcA11bde05977b3631167028862bE2a173976CA11', // Avalanche
      250: '0xcA11bde05977b3631167028862bE2a173976CA11', // Fantom
      42161: '0xcA11bde05977b3631167028862bE2a173976CA11', // Arbitrum
      10: '0xcA11bde05977b3631167028862bE2a173976CA11', // Optimism
      8453: '0xcA11bde05977b3631167028862bE2a173976CA11', // Base
    };
    
    return multicallAddresses[chainId] || '0xcA11bde05977b3631167028862bE2a173976CA11';
  }

  private async updatePoolStates(chainId: number, blockNumber: number): Promise<void> {
    const pools = await this.getRegisteredPools(chainId);
    const multicall = this.multicalls.get(chainId);
    
    if (!multicall || !pools.length) return;

    try {
      // Batch call para obtener reserves de todos los pools en un solo RPC call
      const calls = pools.map(pool => ({
        target: pool.address,
        callData: this.encodeGetReserves()
      }));

      const results = await multicall.aggregate3(calls);
      
      results.forEach((result, index) => {
        if (result.success) {
          const [reserve0, reserve1, blockTimestampLast] = ethers.utils.defaultAbiCoder.decode(
            ['uint112', 'uint112', 'uint32'],
            result.returnData
          );
          
          const poolState: PoolState = {
            address: pools[index].address,
            token0: pools[index].token0,
            token1: pools[index].token1,
            reserve0,
            reserve1,
            fee: pools[index].fee,
            blockNumber,
            timestamp: Date.now()
          };
          
          this.poolStates.set(pools[index].address, poolState);
          
          // Emitir evento de actualización
          this.eventEmitter.dispatchEvent(new CustomEvent('pool_state_updated', {
            detail: { poolState, chainId }
          }));
        }
      });
    } catch (error) {
      console.error(`Error actualizando pools para chain ${chainId}:`, error);
    }
  }

  private encodeGetReserves(): string {
    // Encode function call para getReserves()
    const iface = new ethers.utils.Interface(UNISWAP_V2_POOL_ABI);
    return iface.encodeFunctionData('getReserves');
  }

  private async getRegisteredPools(chainId: number): Promise<any[]> {
    // Obtener pools registrados desde el DexRegistryService
    // Esta función se conectará con el backend real
    try {
      const response = await fetch(`/api/dexes/pools?chainId=${chainId}`);
      if (response.ok) {
        return await response.json();
      }
    } catch (error) {
      console.error(`Error obteniendo pools para chain ${chainId}:`, error);
    }
    
    return [];
  }

  public getPoolState(poolAddress: string): PoolState | null {
    return this.poolStates.get(poolAddress) || null;
  }

  public getAllPoolStates(): PoolState[] {
    return Array.from(this.poolStates.values());
  }

  public getPoolStatesByChain(chainId: number): PoolState[] {
    return Array.from(this.poolStates.values()).filter(pool => {
      // Filtrar por chain basado en la dirección del pool
      // Esta lógica se puede mejorar con un mapping más preciso
      return true; // Por ahora retornamos todos
    });
  }

  public onPoolStateUpdate(callback: (event: CustomEvent) => void): void {
    this.eventEmitter.addEventListener('pool_state_updated', callback as EventListener);
  }

  public removePoolStateUpdateListener(callback: (event: CustomEvent) => void): void {
    this.eventEmitter.removeEventListener('pool_state_updated', callback as EventListener);
  }

  public getProvider(chainId: number): ethers.providers.WebSocketProvider | null {
    return this.providers.get(chainId) || null;
  }

  public isConnected(chainId: number): boolean {
    const provider = this.providers.get(chainId);
    return provider ? provider.websocket.readyState === WebSocket.OPEN : false;
  }

  public getConnectionStatus(): { [chainId: number]: boolean } {
    const status: { [chainId: number]: boolean } = {};
    for (const [chainId] of this.providers) {
      status[chainId] = this.isConnected(chainId);
    }
    return status;
  }
}
