import { ethers } from 'ethers'
import { FlashLoanParams, SUPPORTED_CHAINS } from './types'

export interface FlashLoanProvider {
  name: string
  poolAddress: string
  chainId: number
  maxLoanAmount: Record<string, string> // token -> max amount
  flashLoanFee: number // percentage
}

export class AaveV3FlashLoanConnector {
  private provider: ethers.Provider
  private poolContract: ethers.Contract
  private chainConfig: typeof SUPPORTED_CHAINS[keyof typeof SUPPORTED_CHAINS]

  constructor(chainId: number, rpcUrl: string) {
    this.provider = new ethers.JsonRpcProvider(rpcUrl)
    this.chainConfig = SUPPORTED_CHAINS[chainId]
    
    if (!this.chainConfig.flashLoanProvider) {
      throw new Error(`Flash loans not supported on chain ${chainId}`)
    }

    // Aave V3 Pool ABI (simplified)
    const poolAbi = [
      'function flashLoan(address receiverAddress, address[] calldata assets, uint256[] calldata amounts, uint256[] calldata modes, address onBehalfOf, bytes calldata params, uint16 referralCode) external',
      'function getReserveData(address asset) external view returns (uint256 configuration, uint128 liquidityIndex, uint128 currentLiquidityRate, uint128 variableBorrowIndex, uint128 currentVariableBorrowRate, uint128 currentStableBorrowRate, uint40 lastUpdateTimestamp, uint16 id, address aTokenAddress, address stableDebtTokenAddress, address variableDebtTokenAddress, address interestRateStrategyAddress, uint128 accruedToTreasury, uint128 unbacked, uint128 isolationModeTotalDebt)',
      'function FLASHLOAN_PREMIUM_TOTAL() external view returns (uint256)',
      'function MAX_STABLE_RATE_BORROW_SIZE_PERCENT() external view returns (uint256)'
    ]

    this.poolContract = new ethers.Contract(
      this.chainConfig.flashLoanProvider!,
      poolAbi,
      this.provider
    )
  }

  // Get flash loan fee for a specific amount
  async getFlashLoanFee(asset: string, amount: string): Promise<string> {
    try {
      const premium = await this.poolContract.FLASHLOAN_PREMIUM_TOTAL()
      const fee = (BigInt(amount) * premium) / BigInt(10000) // Premium is in basis points
      return fee.toString()
    } catch (error) {
      console.error('Error getting flash loan fee:', error)
      // Default to 0.09% if unable to fetch
      return ((BigInt(amount) * BigInt(9)) / BigInt(10000)).toString()
    }
  }

  // Get maximum available liquidity for flash loan
  async getMaxLoanAmount(asset: string): Promise<string> {
    try {
      const reserveData = await this.poolContract.getReserveData(asset)
      const aTokenAddress = reserveData.aTokenAddress
      
      // Get aToken balance (available liquidity)
      const aTokenAbi = ['function totalSupply() external view returns (uint256)']
      const aToken = new ethers.Contract(aTokenAddress, aTokenAbi, this.provider)
      const totalSupply = await aToken.totalSupply()
      
      return totalSupply.toString()
    } catch (error) {
      console.error('Error getting max loan amount:', error)
      return '0'
    }
  }

  // Check if flash loan is available for given parameters
  async isFlashLoanAvailable(asset: string, amount: string): Promise<boolean> {
    try {
      const maxAmount = await this.getMaxLoanAmount(asset)
      return BigInt(amount) <= BigInt(maxAmount)
    } catch (error) {
      console.error('Error checking flash loan availability:', error)
      return false
    }
  }

  // Generate flash loan transaction data
  async generateFlashLoanTx(
    receiverAddress: string,
    assets: string[],
    amounts: string[],
    params: string,
    signer: ethers.Signer
  ): Promise<ethers.ContractTransaction> {
    const modes = new Array(assets.length).fill(0) // 0 = no debt
    const onBehalfOf = receiverAddress
    const referralCode = 0

    const contract = this.poolContract.connect(signer)
    
    return await contract.flashLoan(
      receiverAddress,
      assets,
      amounts,
      modes,
      onBehalfOf,
      params,
      referralCode
    )
  }

  // Estimate gas for flash loan transaction
  async estimateFlashLoanGas(
    receiverAddress: string,
    assets: string[],
    amounts: string[],
    params: string
  ): Promise<number> {
    try {
      const modes = new Array(assets.length).fill(0)
      const onBehalfOf = receiverAddress
      const referralCode = 0

      const estimatedGas = await this.poolContract.flashLoan.estimateGas(
        receiverAddress,
        assets,
        amounts,
        modes,
        onBehalfOf,
        params,
        referralCode
      )

      return Number(estimatedGas)
    } catch (error) {
      console.error('Error estimating flash loan gas:', error)
      // Return a conservative estimate
      return 500000
    }
  }
}

export class FlashLoanExecutor {
  private flashLoanConnectors: Map<number, AaveV3FlashLoanConnector> = new Map()
  
  constructor(rpcUrls: Record<number, string>) {
    for (const [chainId, rpcUrl] of Object.entries(rpcUrls)) {
      const chainIdNum = parseInt(chainId)
      const chainConfig = SUPPORTED_CHAINS[chainIdNum]
      
      if (chainConfig?.flashLoanProvider) {
        try {
          const connector = new AaveV3FlashLoanConnector(chainIdNum, rpcUrl)
          this.flashLoanConnectors.set(chainIdNum, connector)
        } catch (error) {
          console.error(`Failed to initialize flash loan connector for chain ${chainId}:`, error)
        }
      }
    }
  }

  // Check if flash loans are supported on a chain
  isFlashLoanSupported(chainId: number): boolean {
    return this.flashLoanConnectors.has(chainId)
  }

  // Get flash loan fee for specific chain and asset
  async getFlashLoanFee(chainId: number, asset: string, amount: string): Promise<string | null> {
    const connector = this.flashLoanConnectors.get(chainId)
    if (!connector) return null

    return await connector.getFlashLoanFee(asset, amount)
  }

  // Get maximum loan amount for asset on specific chain
  async getMaxLoanAmount(chainId: number, asset: string): Promise<string | null> {
    const connector = this.flashLoanConnectors.get(chainId)
    if (!connector) return null

    return await connector.getMaxLoanAmount(asset)
  }

  // Check if flash loan is available
  async isFlashLoanAvailable(chainId: number, asset: string, amount: string): Promise<boolean> {
    const connector = this.flashLoanConnectors.get(chainId)
    if (!connector) return false

    return await connector.isFlashLoanAvailable(asset, amount)
  }

  // Execute flash loan
  async executeFlashLoan(
    chainId: number,
    receiverAddress: string,
    assets: string[],
    amounts: string[],
    params: string,
    signer: ethers.Signer
  ): Promise<ethers.ContractTransaction | null> {
    const connector = this.flashLoanConnectors.get(chainId)
    if (!connector) {
      throw new Error(`Flash loan not supported on chain ${chainId}`)
    }

    return await connector.generateFlashLoanTx(receiverAddress, assets, amounts, params, signer)
  }

  // Estimate gas for flash loan
  async estimateFlashLoanGas(
    chainId: number,
    receiverAddress: string,
    assets: string[],
    amounts: string[],
    params: string
  ): Promise<number | null> {
    const connector = this.flashLoanConnectors.get(chainId)
    if (!connector) return null

    return await connector.estimateFlashLoanGas(receiverAddress, assets, amounts, params)
  }

  // Get all supported chains for flash loans
  getSupportedChains(): number[] {
    return Array.from(this.flashLoanConnectors.keys())
  }
}

// Smart contract template for flash loan receiver
export const FLASH_LOAN_RECEIVER_TEMPLATE = `
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.10;

import {FlashLoanSimpleReceiverBase} from '@aave/core-v3/contracts/flashloan/base/FlashLoanSimpleReceiverBase.sol';
import {IPoolAddressesProvider} from '@aave/core-v3/contracts/interfaces/IPoolAddressesProvider.sol';
import {IERC20} from '@aave/core-v3/contracts/dependencies/openzeppelin/contracts/IERC20.sol';

contract ArbitrageFlashLoanReceiver is FlashLoanSimpleReceiverBase {
    address payable owner;

    constructor(address _addressProvider) FlashLoanSimpleReceiverBase(IPoolAddressesProvider(_addressProvider)) {
        owner = payable(msg.sender);
    }

    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address initiator,
        bytes calldata params
    ) external override returns (bool) {
        // Decode parameters
        (
            address[] memory dexRouters,
            bytes[] memory swapCalldata,
            uint256 minProfitAmount
        ) = abi.decode(params, (address[], bytes[], uint256));

        uint256 amountOwed = amount + premium;
        
        // Execute arbitrage logic here
        uint256 profit = executeArbitrageStrategy(asset, amount, dexRouters, swapCalldata);
        
        // Ensure we have enough to repay the loan + minimum profit
        require(profit >= minProfitAmount, "Insufficient profit");
        require(IERC20(asset).balanceOf(address(this)) >= amountOwed, "Cannot repay loan");

        // Approve the Pool contract allowance to *pull* the owed amount
        IERC20(asset).approve(address(POOL), amountOwed);

        return true;
    }

    function executeArbitrageStrategy(
        address asset,
        uint256 amount,
        address[] memory dexRouters,
        bytes[] memory swapCalldata
    ) internal returns (uint256 profit) {
        uint256 initialBalance = IERC20(asset).balanceOf(address(this));
        
        // Execute swaps on different DEXes
        for (uint i = 0; i < dexRouters.length; i++) {
            (bool success,) = dexRouters[i].call(swapCalldata[i]);
            require(success, "Swap failed");
        }
        
        uint256 finalBalance = IERC20(asset).balanceOf(address(this));
        profit = finalBalance > initialBalance ? finalBalance - initialBalance : 0;
        
        return profit;
    }

    function requestFlashLoan(
        address _token,
        uint256 _amount,
        address[] memory dexRouters,
        bytes[] memory swapCalldata,
        uint256 minProfitAmount
    ) public {
        require(msg.sender == owner, "Only owner can request flash loan");
        
        bytes memory params = abi.encode(dexRouters, swapCalldata, minProfitAmount);
        uint16 referralCode = 0;

        POOL.flashLoanSimple(
            address(this),
            _token,
            _amount,
            params,
            referralCode
        );
    }

    function withdraw(address _tokenAddress) external {
        require(msg.sender == owner, "Only owner can withdraw");
        
        IERC20 token = IERC20(_tokenAddress);
        uint256 balance = token.balanceOf(address(this));
        require(balance > 0, "No tokens to withdraw");
        
        token.transfer(owner, balance);
    }

    function withdrawETH() external {
        require(msg.sender == owner, "Only owner can withdraw");
        
        uint256 balance = address(this).balance;
        require(balance > 0, "No ETH to withdraw");
        
        owner.transfer(balance);
    }

    receive() external payable {}
}
`

export default FlashLoanExecutor