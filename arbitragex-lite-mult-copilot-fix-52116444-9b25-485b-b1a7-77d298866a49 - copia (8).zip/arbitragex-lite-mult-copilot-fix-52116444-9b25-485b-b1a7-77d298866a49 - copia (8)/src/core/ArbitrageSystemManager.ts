import { useState, useEffect } from 'react'
import { ArbitrageEngine } from '@/core/ArbitrageEngine'
import { RealTimePriceMonitor } from '@/core/RealTimePriceMonitor'
import { FlashLoanExecutor } from '@/core/FlashLoanExecutor'
import { MultiDEXConnector } from '@/core/MultiDEXConnector'
import { MEVProtectionService2025 } from '@/core/MEVProtectionService2025'
import { FlashLoanService2025 } from '@/core/FlashLoanService2025'
import { CrossChainArbitrageService2025 } from '@/core/CrossChainArbitrageService2025'
import { PerformanceMonitoringService2025 } from '@/core/PerformanceMonitoringService2025'
import { SUPPORTED_DEXES, SUPPORTED_CHAINS, RiskParameters } from '@/core/types'

// Global singleton instances for the arbitrage system
class ArbitrageSystemManager {
  private static instance: ArbitrageSystemManager
  private arbitrageEngine: ArbitrageEngine | null = null
  private priceMonitor: RealTimePriceMonitor | null = null
  private flashLoanExecutor: FlashLoanExecutor | null = null
  private dexConnector: MultiDEXConnector | null = null
  
  // 🆕 NUEVOS SERVICIOS AVANZADOS 2025
  private mevProtectionService: MEVProtectionService2025 | null = null
  private flashLoanService2025: FlashLoanService2025 | null = null
  private crossChainArbitrageService: CrossChainArbitrageService2025 | null = null
  private performanceMonitoringService: PerformanceMonitoringService2025 | null = null
  
  private initialized = false

  private constructor() {}

  static getInstance(): ArbitrageSystemManager {
    if (!ArbitrageSystemManager.instance) {
      ArbitrageSystemManager.instance = new ArbitrageSystemManager
    }
    return ArbitrageSystemManager.instance
  }

  async initialize(environment: 'test' | 'prod'): Promise<void> {
    if (this.initialized) return

    try {
      // Default RPC URLs - in production these should come from environment variables
      const rpcUrls = {
        1: import.meta.env.VITE_ETHEREUM_RPC_URL || 'https://eth-mainnet.g.alchemy.com/v2/demo',
        56: import.meta.env.VITE_BSC_RPC_URL || 'https://bsc-dataseed.binance.org',
        137: import.meta.env.VITE_POLYGON_RPC_URL || 'https://polygon-rpc.com',
        42161: import.meta.env.VITE_ARBITRUM_RPC_URL || 'https://arb1.arbitrum.io/rpc',
        10: import.meta.env.VITE_OPTIMISM_RPC_URL || 'https://mainnet.optimism.io'
      }

      // Default risk parameters
      const riskParams: RiskParameters = {
        maxSlippage: parseFloat(import.meta.env.VITE_MAX_SLIPPAGE) || 2.0,
        maxGasPrice: parseInt(import.meta.env.VITE_MAX_GAS_PRICE) || 100,
        maxPositionSize: import.meta.env.VITE_MAX_POSITION_SIZE || '10000',
        minProfitThreshold: parseFloat(import.meta.env.VITE_MIN_PROFIT_THRESHOLD) || (environment === 'prod' ? 4.0 : 1.0),
        maxPriceImpact: parseFloat(import.meta.env.VITE_MAX_PRICE_IMPACT) || 5.0,
        maxExecutionTime: parseInt(import.meta.env.VITE_MAX_EXECUTION_TIME) || 120,
        enableFlashLoans: import.meta.env.VITE_ENABLE_FLASH_LOANS === 'true' || true,
        maxFlashLoanAmount: import.meta.env.VITE_MAX_FLASH_LOAN_AMOUNT || '100000'
      }

      // Initialize core systems
      this.arbitrageEngine = new ArbitrageEngine(riskParams)
      this.priceMonitor = new RealTimePriceMonitor(rpcUrls)
      this.flashLoanExecutor = new FlashLoanExecutor(rpcUrls)
      this.dexConnector = new MultiDEXConnector(rpcUrls)

      // 🆕 INICIALIZAR NUEVOS SERVICIOS AVANZADOS 2025
      this.mevProtectionService = new MEVProtectionService2025(rpcUrls, environment)
      this.flashLoanService2025 = new FlashLoanService2025(rpcUrls, environment)
      this.crossChainArbitrageService = new CrossChainArbitrageService2025(rpcUrls, environment)
      this.performanceMonitoringService = new PerformanceMonitoringService2025(environment)

      // Initialize DEX connectors
      const dexConfigs = Object.values(SUPPORTED_DEXES)
      this.dexConnector.initializeConnectors(dexConfigs)

      // 🆕 INICIALIZAR SERVICIOS AVANZADOS
      await this.mevProtectionService.initialize()
      await this.flashLoanService2025.initialize()
      await this.crossChainArbitrageService.initialize()
      await this.performanceMonitoringService.initialize()

      // Start monitoring systems
      await this.priceMonitor.startMonitoring()
      
      // Start arbitrage scanning with appropriate intervals
      const scanInterval = environment === 'prod' 
        ? parseInt(import.meta.env.VITE_SCAN_INTERVAL_PROD) || 5000
        : parseInt(import.meta.env.VITE_SCAN_INTERVAL_TEST) || 10000
      
      await this.arbitrageEngine.startScanning(scanInterval)

      this.initialized = true
      console.log(`🚀 ArbitrageX Pro 2025 AVANZADO inicializado exitosamente en modo ${environment}`)
      console.log(`🛡️ MEV Protection Service activado`)
      console.log(`💰 Flash Loan Service 2025 activado`)
      console.log(`🌐 Cross-Chain Arbitrage Service activado`)
      console.log(`⚡ Performance Monitoring Service activado`)

    } catch (error) {
      console.error('Failed to initialize ArbitrageX system:', error)
      throw error
    }
  }

  async shutdown(): Promise<void> {
    try {
      await this.priceMonitor?.stopMonitoring()
      this.arbitrageEngine?.stopScanning()
      
      // 🆕 APAGAR SERVICIOS AVANZADOS
      await this.performanceMonitoringService?.stop()
      
      this.initialized = false
      console.log('ArbitrageX system shutdown complete')
    } catch (error) {
      console.error('Error during system shutdown:', error)
    }
  }

  getArbitrageEngine(): ArbitrageEngine | null {
    return this.arbitrageEngine
  }

  getPriceMonitor(): RealTimePriceMonitor | null {
    return this.priceMonitor
  }

  getFlashLoanExecutor(): FlashLoanExecutor | null {
    return this.flashLoanExecutor
  }

  getDEXConnector(): MultiDEXConnector | null {
    return this.dexConnector
  }

  // 🆕 GETTERS PARA NUEVOS SERVICIOS AVANZADOS
  getMEVProtectionService(): MEVProtectionService2025 | null {
    return this.mevProtectionService
  }

  getFlashLoanService2025(): FlashLoanService2025 | null {
    return this.flashLoanService2025
  }

  getCrossChainArbitrageService(): CrossChainArbitrageService2025 | null {
    return this.crossChainArbitrageService
  }

  getPerformanceMonitoringService(): PerformanceMonitoringService2025 | null {
    return this.performanceMonitoringService
  }

  isInitialized(): boolean {
    return this.initialized
  }
}

// React hook for using the arbitrage system
export function useArbitrageSystem(environment: 'test' | 'prod') {
  const [systemManager] = useState(() => ArbitrageSystemManager.getInstance())
  const [isInitialized, setIsInitialized] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const initializeSystem = async () => {
      try {
        setIsLoading(true)
        setError(null)
        
        if (!systemManager.isInitialized()) {
          await systemManager.initialize(environment)
        }
        
        setIsInitialized(true)
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred'
        setError(errorMessage)
        console.error('Failed to initialize arbitrage system:', err)
      } finally {
        setIsLoading(false)
      }
    }

    initializeSystem()

    // Cleanup on unmount
    return () => {
      // Note: We don't shut down here as the system should persist across component mounts
      // Only shut down when the entire app is closing
    }
  }, [environment, systemManager])

  // Cleanup on app exit
  useEffect(() => {
    const handleBeforeUnload = async () => {
      await systemManager.shutdown()
    }

    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload)
    }
  }, [systemManager])

  return {
    arbitrageEngine: systemManager.getArbitrageEngine(),
    priceMonitor: systemManager.getPriceMonitor(),
    flashLoanExecutor: systemManager.getFlashLoanExecutor(),
    dexConnector: systemManager.getDEXConnector(),
    // 🆕 NUEVOS SERVICIOS AVANZADOS
    mevProtectionService: systemManager.getMEVProtectionService(),
    flashLoanService2025: systemManager.getFlashLoanService2025(),
    crossChainArbitrageService: systemManager.getCrossChainArbitrageService(),
    performanceMonitoringService: systemManager.getPerformanceMonitoringService(),
    isInitialized,
    isLoading,
    error,
    systemManager
  }
}

// Performance monitoring
export function usePerformanceMonitoring() {
  const [metrics, setMetrics] = useState({
    totalOpportunities: 0,
    avgResponseTime: 0,
    successRate: 0,
    totalProfit: 0,
    systemUptime: 0
  })

  useEffect(() => {
    const startTime = Date.now()
    
    const updateMetrics = () => {
      const uptime = Date.now() - startTime
      setMetrics(prev => ({
        ...prev,
        systemUptime: uptime
      }))
    }

    const interval = setInterval(updateMetrics, 1000)
    return () => clearInterval(interval)
  }, [])

  return metrics
}

// Circuit breaker for error handling
export function useCircuitBreaker() {
  const [isOpen, setIsOpen] = useState(false)
  const [failureCount, setFailureCount] = useState(0)
  const [lastFailureTime, setLastFailureTime] = useState<number | null>(null)

  const threshold = parseInt(import.meta.env.VITE_CIRCUIT_BREAKER_THRESHOLD) || 10
  const timeout = parseInt(import.meta.env.VITE_CIRCUIT_BREAKER_TIMEOUT) || 30000

  const recordFailure = () => {
    const newCount = failureCount + 1
    setFailureCount(newCount)
    setLastFailureTime(Date.now())

    if (newCount >= threshold) {
      setIsOpen(true)
      console.warn('Circuit breaker opened due to repeated failures')
    }
  }

  const recordSuccess = () => {
    setFailureCount(0)
    setIsOpen(false)
  }

  const canExecute = () => {
    if (!isOpen) return true
    
    if (lastFailureTime && Date.now() - lastFailureTime > timeout) {
      setIsOpen(false)
      setFailureCount(0)
      return true
    }
    
    return false
  }

  return {
    isOpen,
    canExecute,
    recordFailure,
    recordSuccess,
    failureCount
  }
}

export default ArbitrageSystemManager