import { ethers } from 'ethers'

// Core types for multi-DEX arbitrage system
export interface DEXConfig {
  name: string
  chainId: number
  routerAddress: string
  factoryAddress: string
  quoterAddress?: string // For Uniswap V3
  version: 'v2' | 'v3'
  baseGasCost: number
  swapGasCost: number
}

export interface TokenPair {
  token0: string
  token1: string
  dex: string
  chainId: number
  pairAddress?: string
  poolFee?: number // For Uniswap V3
}

export interface PriceQuote {
  dex: string
  chainId: number
  tokenIn: string
  tokenOut: string
  amountIn: string
  amountOut: string
  price: number
  priceImpact: number
  gasEstimate: number
  timestamp: number
  blockNumber: number
  txCost: number
}

export interface ArbitrageOpportunity {
  id: string
  type: 'simple' | 'triangular' | 'cross-chain'
  tokenPath: string[]
  dexPath: string[]
  chainPath: number[]
  amountIn: string
  expectedAmountOut: string
  profit: string
  profitPercentage: number
  gasEstimate: number
  netProfit: string
  netProfitPercentage: number
  priceImpact: number
  confidence: number // 0-1
  riskScore: number // 0-100
  timestamp: number
  executionDeadline: number
  flashLoanRequired: boolean
  flashLoanAmount?: string
  flashLoanFee?: string
}

export interface FlashLoanParams {
  asset: string
  amount: string
  premium: string
  initiator: string
  params: string
}

export interface ExecutionResult {
  success: boolean
  transactionHash?: string
  gasUsed?: number
  actualProfit?: string
  error?: string
  timestamp: number
}

export interface ChainConfig {
  chainId: number
  name: string
  rpcUrl: string
  explorerUrl: string
  nativeCurrency: {
    name: string
    symbol: string
    decimals: number
  }
  maxGasPrice: string // in gwei
  maxPriorityFee: string // in gwei
  flashLoanProvider?: string // Aave V3 pool address
}

export interface RiskParameters {
  maxSlippage: number // percentage
  maxGasPrice: number // gwei
  maxPositionSize: string // in USD
  minProfitThreshold: number // percentage
  maxPriceImpact: number // percentage
  maxExecutionTime: number // seconds
  enableFlashLoans: boolean
  maxFlashLoanAmount: string // in USD
}

// Nuevas interfaces para cálculo de viabilidad real
export interface GasMetrics {
  gasPrice: number // en gwei
  gasPriceUSD: number // precio del gas en USD
  gasUsed: number // gas estimado para la transacción
  gasFeeUSD: number // costo total del gas en USD
  priorityFee: number // priority fee en gwei
  maxFeePerGas: number // max fee per gas en gwei
  blockTime: number // tiempo promedio de bloque en segundos
}

export interface SlippageAnalysis {
  expectedSlippage: number // slippage esperado en %
  actualSlippage: number // slippage real después de simulación
  slippageTolerance: number // tolerancia máxima permitida
  priceImpact: number // impacto en precio de la operación
}

export interface ProfitabilityMetrics {
  grossProfit: number // ganancia bruta antes de fees
  netProfit: number // ganancia neta después de todos los costos
  netProfitPercentage: number // ROI neto en %
  gasCostPercentage: number // % del costo de gas sobre la ganancia
  slippageCost: number // costo del slippage en USD
  dexFees: number // fees de los DEXs
  crossChainCosts: number // costos de bridge si aplica
  minimumViableProfit: number // ganancia mínima para ser viable
  profitMargin: number // margen de seguridad (ganancia neta / gas cost)
}

export interface ExecutionViability {
  isViable: boolean // si la operación es viable
  viabilityScore: number // score de 0-100
  executionProbability: number // % de éxito en ejecución
  riskFactors: string[] // factores de riesgo identificados
  recommendations: string[] // recomendaciones de ejecución
  optimalExecutionWindow: number // ventana óptima de ejecución en segundos
}

export interface BlockchainGasProfile {
  chainId: number
  chainName: string
  nativeToken: string
  averageGasPrice: number // gwei
  averageGasPriceUSD: number // USD
  gasPriceRange: {
    min: number
    max: number
    optimal: number
  }
  blockTime: number // segundos
  gasEfficiency: 'high' | 'medium' | 'low'
  recommendedStrategies: string[]
  gasCostMultiplier: number // multiplicador de costo vs Ethereum
}

export interface RealTimeOpportunity extends ArbitrageOpportunity {
  gasMetrics: GasMetrics
  slippageAnalysis: SlippageAnalysis
  profitabilityMetrics: ProfitabilityMetrics
  executionViability: ExecutionViability
  blockchainProfile: BlockchainGasProfile
  lastUpdated: number
  priceVolatility: number // volatilidad del precio en las últimas 24h
  mempoolCompetition: number // nivel de competencia en mempool (0-100)
}

// Supported DEX configurations
export const SUPPORTED_DEXES: Record<string, DEXConfig> = {
  // Ethereum Mainnet
  'uniswap-v2-eth': {
    name: 'Uniswap V2',
    chainId: 1,
    routerAddress: '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D',
    factoryAddress: '0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f',
    version: 'v2',
    baseGasCost: 21000,
    swapGasCost: 125000
  },
  'uniswap-v3-eth': {
    name: 'Uniswap V3',
    chainId: 1,
    routerAddress: '0xE592427A0AEce92De3Edee1F18E0157C05861564',
    factoryAddress: '0x1F98431c8aD98523631AE4a59f267346ea31F984',
    quoterAddress: '0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6',
    version: 'v3',
    baseGasCost: 21000,
    swapGasCost: 150000
  },
  'sushiswap-eth': {
    name: 'SushiSwap',
    chainId: 1,
    routerAddress: '0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F',
    factoryAddress: '0xC0AEe478e3658e2610c5F7A4A2E1777cE9e4f2Ac',
    version: 'v2',
    baseGasCost: 21000,
    swapGasCost: 125000
  },
  
  // BSC
  'pancakeswap-v2-bsc': {
    name: 'PancakeSwap V2',
    chainId: 56,
    routerAddress: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
    factoryAddress: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',
    version: 'v2',
    baseGasCost: 21000,
    swapGasCost: 125000
  },
  'pancakeswap-v3-bsc': {
    name: 'PancakeSwap V3',
    chainId: 56,
    routerAddress: '0x13f4EA83D0bd40E75C8222255bc855a974568Dd4',
    factoryAddress: '0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865',
    quoterAddress: '0xB048Bbc1Ee6b733FFfCFb9e9CeF7375518e25997',
    version: 'v3',
    baseGasCost: 21000,
    swapGasCost: 150000
  },
  
  // Polygon
  'quickswap-polygon': {
    name: 'QuickSwap',
    chainId: 137,
    routerAddress: '0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff',
    factoryAddress: '0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32',
    version: 'v2',
    baseGasCost: 21000,
    swapGasCost: 125000
  },
  'uniswap-v3-polygon': {
    name: 'Uniswap V3 Polygon',
    chainId: 137,
    routerAddress: '0xE592427A0AEce92De3Edee1F18E0157C05861564',
    factoryAddress: '0x1F98431c8aD98523631AE4a59f267346ea31F984',
    quoterAddress: '0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6',
    version: 'v3',
    baseGasCost: 21000,
    swapGasCost: 150000
  },
  
  // Arbitrum
  'uniswap-v3-arbitrum': {
    name: 'Uniswap V3 Arbitrum',
    chainId: 42161,
    routerAddress: '0xE592427A0AEce92De3Edee1F18E0157C05861564',
    factoryAddress: '0x1F98431c8aD98523631AE4a59f267346ea31F984',
    quoterAddress: '0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6',
    version: 'v3',
    baseGasCost: 21000,
    swapGasCost: 150000
  },
  'sushiswap-arbitrum': {
    name: 'SushiSwap Arbitrum',
    chainId: 42161,
    routerAddress: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506',
    factoryAddress: '0xc35DADB65012eC5796536bD9864eD8773aBc74C4',
    version: 'v2',
    baseGasCost: 21000,
    swapGasCost: 125000
  },
  
  // Optimism
  'uniswap-v3-optimism': {
    name: 'Uniswap V3 Optimism',
    chainId: 10,
    routerAddress: '0xE592427A0AEce92De3Edee1F18E0157C05861564',
    factoryAddress: '0x1F98431c8aD98523631AE4a59f267346ea31F984',
    quoterAddress: '0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6',
    version: 'v3',
    baseGasCost: 21000,
    swapGasCost: 150000
  }
}

// Supported chain configurations
export const SUPPORTED_CHAINS: Record<number, ChainConfig> = {
  1: {
    chainId: 1,
    name: 'Ethereum',
    rpcUrl: process.env.VITE_ETHEREUM_RPC_URL || 'https://eth-mainnet.g.alchemy.com/v2/your-api-key',
    explorerUrl: 'https://etherscan.io',
    nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    maxGasPrice: '100',
    maxPriorityFee: '2',
    flashLoanProvider: '0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2' // Aave V3 Pool
  },
  56: {
    chainId: 56,
    name: 'BSC',
    rpcUrl: process.env.VITE_BSC_RPC_URL || 'https://bsc-dataseed.binance.org',
    explorerUrl: 'https://bscscan.com',
    nativeCurrency: { name: 'Binance Coin', symbol: 'BNB', decimals: 18 },
    maxGasPrice: '20',
    maxPriorityFee: '1'
  },
  137: {
    chainId: 137,
    name: 'Polygon',
    rpcUrl: process.env.VITE_POLYGON_RPC_URL || 'https://polygon-rpc.com',
    explorerUrl: 'https://polygonscan.com',
    nativeCurrency: { name: 'Matic', symbol: 'MATIC', decimals: 18 },
    maxGasPrice: '500',
    maxPriorityFee: '50',
    flashLoanProvider: '0x794a61358D6845594F94dc1DB02A252b5b4814aD' // Aave V3 Pool
  },
  42161: {
    chainId: 42161,
    name: 'Arbitrum',
    rpcUrl: process.env.VITE_ARBITRUM_RPC_URL || 'https://arb1.arbitrum.io/rpc',
    explorerUrl: 'https://arbiscan.io',
    nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    maxGasPrice: '1',
    maxPriorityFee: '0.1',
    flashLoanProvider: '0x794a61358D6845594F94dc1DB02A252b5b4814aD' // Aave V3 Pool
  },
  10: {
    chainId: 10,
    name: 'Optimism',
    rpcUrl: process.env.VITE_OPTIMISM_RPC_URL || 'https://mainnet.optimism.io',
    explorerUrl: 'https://optimistic.etherscan.io',
    nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    maxGasPrice: '0.1',
    maxPriorityFee: '0.01',
    flashLoanProvider: '0x794a61358D6845594F94dc1DB02A252b5b4814aD' // Aave V3 Pool
  }
}

// Common token addresses across chains
export const COMMON_TOKENS: Record<number, Record<string, string>> = {
  1: { // Ethereum
    ETH: '0x0000000000000000000000000000000000000000',
    WETH: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    USDC: '0xA0b86a33E6441E94AA7e24e16eBb3a1C25C46cC2',
    USDT: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    DAI: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
    WBTC: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599'
  },
  56: { // BSC
    BNB: '0x0000000000000000000000000000000000000000',
    WBNB: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    USDC: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
    USDT: '0x55d398326f99059fF775485246999027B3197955',
    BUSD: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
    BTCB: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c'
  },
  137: { // Polygon
    MATIC: '0x0000000000000000000000000000000000000000',
    WMATIC: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
    USDC: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
    USDT: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
    DAI: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
    WETH: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619'
  },
  42161: { // Arbitrum
    ETH: '0x0000000000000000000000000000000000000000',
    WETH: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
    USDC: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
    USDT: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
    DAI: '0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1',
    WBTC: '0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f'
  },
  10: { // Optimism
    ETH: '0x0000000000000000000000000000000000000000',
    WETH: '0x4200000000000000000000000000000000000006',
    USDC: '0x7F5c764cBc14f9669B88837ca1490cCa17c31607',
    USDT: '0x94b008aA00579c1307B0EF2c499aD98a8ce58e58',
    DAI: '0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1',
    WBTC: '0x68f180fcCe6836688e9084f035309E29Bf0A2095'
  }
}

export default {
  DEXConfig,
  TokenPair,
  PriceQuote,
  ArbitrageOpportunity,
  FlashLoanParams,
  ExecutionResult,
  ChainConfig,
  RiskParameters,
  SUPPORTED_DEXES,
  SUPPORTED_CHAINS,
  COMMON_TOKENS
}