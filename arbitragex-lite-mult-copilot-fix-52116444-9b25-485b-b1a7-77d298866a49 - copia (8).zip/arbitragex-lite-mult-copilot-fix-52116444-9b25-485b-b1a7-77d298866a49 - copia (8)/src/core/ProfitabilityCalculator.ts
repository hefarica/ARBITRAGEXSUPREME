import { ethers } from 'ethers'
import { 
  GasMetrics, 
  SlippageAnalysis, 
  ProfitabilityMetrics, 
  ExecutionViability,
  BlockchainGasProfile,
  RealTimeOpportunity,
  ArbitrageOpportunity,
  DEXConfig
} from './types'

/**
 * Motor principal de cálculo de rentabilidad real para arbitrajes
 * Integra costos de gas, slippage, fees de DEX y viabilidad de ejecución
 */
export class ProfitabilityCalculator {
  private gasProfiles: Map<number, BlockchainGasProfile>
  private dexConfigs: Map<string, DEXConfig>
  private gasPriceCache: Map<number, { price: number; timestamp: number }>
  private readonly CACHE_TTL = 30000 // 30 segundos

  constructor() {
    this.gasProfiles = new Map()
    this.dexConfigs = new Map()
    this.gasPriceCache = new Map()
    this.initializeGasProfiles()
  }

  /**
   * Inicializa los perfiles de gas para cada blockchain
   * Basado en datos reales de mercado
   */
  private initializeGasProfiles(): void {
    const profiles: BlockchainGasProfile[] = [
      {
        chainId: 1,
        chainName: 'Ethereum Mainnet',
        nativeToken: 'ETH',
        averageGasPrice: 32.5, // 25-40 gwei promedio
        averageGasPriceUSD: 13.0, // $8-$18 promedio
        gasPriceRange: { min: 25, max: 40, optimal: 30 },
        blockTime: 12,
        gasEfficiency: 'low',
        recommendedStrategies: ['flash-loan', 'large-capital'],
        gasCostMultiplier: 1.0
      },
      {
        chainId: 56,
        chainName: 'BSC',
        nativeToken: 'BNB',
        averageGasPrice: 4.5, // 3-6 gwei promedio
        averageGasPriceUSD: 0.175, // $0.10-$0.25 promedio
        gasPriceRange: { min: 3, max: 6, optimal: 4 },
        blockTime: 3,
        gasEfficiency: 'high',
        recommendedStrategies: ['triangular', 'cross-dex', 'small-capital'],
        gasCostMultiplier: 0.013
      },
      {
        chainId: 137,
        chainName: 'Polygon',
        nativeToken: 'MATIC',
        averageGasPrice: 40.0, // 30-50 gwei promedio
        averageGasPriceUSD: 0.085, // $0.05-$0.12 promedio
        gasPriceRange: { min: 30, max: 50, optimal: 35 },
        blockTime: 2,
        gasEfficiency: 'high',
        recommendedStrategies: ['triangular', 'cross-dex', 'nft-arbitrage'],
        gasCostMultiplier: 0.006
      },
      {
        chainId: 42161,
        chainName: 'Arbitrum',
        nativeToken: 'ETH',
        averageGasPrice: 0.2, // 0.1-0.3 gwei equivalente
        averageGasPriceUSD: 0.065, // $0.03-$0.10 promedio
        gasPriceRange: { min: 0.1, max: 0.3, optimal: 0.2 },
        blockTime: 0.25,
        gasEfficiency: 'very-high',
        recommendedStrategies: ['mev-liquidation', 'flash-loan', 'high-frequency'],
        gasCostMultiplier: 0.005
      },
      {
        chainId: 10,
        chainName: 'Optimism',
        nativeToken: 'ETH',
        averageGasPrice: 0.2, // 0.1-0.3 gwei equivalente
        averageGasPriceUSD: 0.065, // $0.03-$0.10 promedio
        gasPriceRange: { min: 0.1, max: 0.3, optimal: 0.2 },
        blockTime: 0.25,
        gasEfficiency: 'very-high',
        recommendedStrategies: ['mev-liquidation', 'flash-loan', 'high-frequency'],
        gasCostMultiplier: 0.005
      },
      {
        chainId: 43114,
        chainName: 'Avalanche',
        nativeToken: 'AVAX',
        averageGasPrice: 30.0, // 25-35 gwei promedio
        averageGasPriceUSD: 0.225, // $0.15-$0.30 promedio
        gasPriceRange: { min: 25, max: 35, optimal: 30 },
        blockTime: 2,
        gasEfficiency: 'medium',
        recommendedStrategies: ['triangular', 'cross-dex'],
        gasCostMultiplier: 0.017
      },
      {
        chainId: 250,
        chainName: 'Fantom',
        nativeToken: 'FTM',
        averageGasPrice: 2.0, // 1-3 gwei promedio
        averageGasPriceUSD: 0.006, // $0.002-$0.01 promedio
        gasPriceRange: { min: 1, max: 3, optimal: 2 },
        blockTime: 1,
        gasEfficiency: 'very-high',
        recommendedStrategies: ['triangular', 'cross-dex', 'small-capital'],
        gasCostMultiplier: 0.0005
      },
      {
        chainId: 8453,
        chainName: 'Base',
        nativeToken: 'ETH',
        averageGasPrice: 0.2, // 0.1-0.3 gwei
        averageGasPriceUSD: 0.065, // $0.03-$0.10 promedio
        gasPriceRange: { min: 0.1, max: 0.3, optimal: 0.2 },
        blockTime: 0.25,
        gasEfficiency: 'very-high',
        recommendedStrategies: ['mev-liquidation', 'flash-loan', 'high-frequency'],
        gasCostMultiplier: 0.005
      }
    ]

    profiles.forEach(profile => {
      this.gasProfiles.set(profile.chainId, profile)
    })
  }

  /**
   * Calcula la viabilidad completa de una oportunidad de arbitraje
   */
  public async calculateOpportunityViability(
    opportunity: ArbitrageOpportunity,
    provider: ethers.providers.Provider
  ): Promise<RealTimeOpportunity> {
    const chainId = opportunity.chainPath[0]
    const gasProfile = this.gasProfiles.get(chainId)
    
    if (!gasProfile) {
      throw new Error(`Chain ID ${chainId} no soportado`)
    }

    // 1. Obtener métricas de gas en tiempo real
    const gasMetrics = await this.calculateGasMetrics(chainId, provider, opportunity)
    
    // 2. Analizar slippage y price impact
    const slippageAnalysis = await this.analyzeSlippage(opportunity, provider)
    
    // 3. Calcular métricas de rentabilidad
    const profitabilityMetrics = this.calculateProfitabilityMetrics(
      opportunity, 
      gasMetrics, 
      slippageAnalysis
    )
    
    // 4. Evaluar viabilidad de ejecución
    const executionViability = this.evaluateExecutionViability(
      opportunity,
      gasMetrics,
      profitabilityMetrics,
      gasProfile
    )

    return {
      ...opportunity,
      gasMetrics,
      slippageAnalysis,
      profitabilityMetrics,
      executionViability,
      blockchainProfile: gasProfile,
      lastUpdated: Date.now(),
      priceVolatility: await this.calculatePriceVolatility(opportunity),
      mempoolCompetition: await this.assessMempoolCompetition(chainId, provider)
    }
  }

  /**
   * Calcula métricas de gas en tiempo real
   */
  private async calculateGasMetrics(
    chainId: number,
    provider: ethers.providers.Provider,
    opportunity: ArbitrageOpportunity
  ): Promise<GasMetrics> {
    const gasProfile = this.gasProfiles.get(chainId)!
    
    // Obtener gas price actual del nodo
    const gasPrice = await this.getCurrentGasPrice(chainId, provider)
    
    // Estimar gas usado basado en la estrategia
    const gasUsed = this.estimateGasUsage(opportunity, chainId)
    
    // Calcular costo en USD
    const gasPriceUSD = gasProfile.averageGasPriceUSD
    const gasFeeUSD = (gasPrice * gasUsed * gasPriceUSD) / 1e9
    
    // Calcular priority fee óptimo
    const priorityFee = this.calculateOptimalPriorityFee(gasPrice, gasProfile)
    
    return {
      gasPrice,
      gasPriceUSD,
      gasUsed,
      gasFeeUSD,
      priorityFee,
      maxFeePerGas: gasPrice + priorityFee,
      blockTime: gasProfile.blockTime
    }
  }

  /**
   * Obtiene el gas price actual del nodo
   */
  private async getCurrentGasPrice(
    chainId: number, 
    provider: ethers.providers.Provider
  ): Promise<number> {
    const cacheKey = chainId
    const cached = this.gasPriceCache.get(cacheKey)
    
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      return cached.price
    }

    try {
      const gasPrice = await provider.getGasPrice()
      const gasPriceGwei = ethers.utils.formatUnits(gasPrice, 'gwei')
      
      this.gasPriceCache.set(cacheKey, {
        price: parseFloat(gasPriceGwei),
        timestamp: Date.now()
      })
      
      return parseFloat(gasPriceGwei)
    } catch (error) {
      // Fallback a perfil predefinido
      const profile = this.gasProfiles.get(chainId)!
      return profile.averageGasPrice
    }
  }

  /**
   * Estima el gas usado basado en la estrategia y blockchain
   */
  private estimateGasUsage(opportunity: ArbitrageOpportunity, chainId: number): number {
    const baseGas = 21000
    let strategyGas = 0
    
    switch (opportunity.type) {
      case 'simple':
        strategyGas = 125000 // swap simple
        break
      case 'triangular':
        strategyGas = 350000 // 3 swaps
        break
      case 'cross-chain':
        strategyGas = 450000 // swap + bridge
        break
    }
    
    // Ajustar por complejidad de la operación
    if (opportunity.flashLoanRequired) {
      strategyGas += 200000 // flash loan overhead
    }
    
    // Ajustar por número de DEXs
    strategyGas += opportunity.dexPath.length * 25000
    
    // Ajustar por blockchain (L2s son más eficientes)
    const profile = this.gasProfiles.get(chainId)!
    if (profile.gasEfficiency === 'very-high') {
      strategyGas = Math.floor(strategyGas * 0.7)
    } else if (profile.gasEfficiency === 'high') {
      strategyGas = Math.floor(strategyGas * 0.85)
    }
    
    return baseGas + strategyGas
  }

  /**
   * Calcula priority fee óptimo para la ejecución
   */
  private calculateOptimalPriorityFee(
    baseGasPrice: number, 
    profile: BlockchainGasProfile
  ): number {
    // Priority fee del 10-20% del gas price base
    const priorityFeeRatio = profile.gasEfficiency === 'very-high' ? 0.15 : 0.20
    return Math.max(baseGasPrice * priorityFeeRatio, 0.1)
  }

  /**
   * Analiza slippage y price impact
   */
  private async analyzeSlippage(
    opportunity: ArbitrageOpportunity,
    provider: ethers.providers.Provider
  ): Promise<SlippageAnalysis> {
    // Simular la transacción para obtener slippage real
    const expectedSlippage = opportunity.priceImpact
    const actualSlippage = await this.simulateTransaction(opportunity, provider)
    
    const slippageTolerance = this.calculateSlippageTolerance(opportunity)
    
    return {
      expectedSlippage,
      actualSlippage,
      slippageTolerance,
      priceImpact: opportunity.priceImpact
    }
  }

  /**
   * Simula la transacción para obtener slippage real
   */
  private async simulateTransaction(
    opportunity: ArbitrageOpportunity,
    provider: ethers.providers.Provider
  ): Promise<number> {
    try {
      // Aquí se implementaría la simulación real usando eth_call
      // Por ahora retornamos una estimación basada en el price impact
      return Math.min(opportunity.priceImpact * 1.2, 5.0) // máximo 5%
    } catch (error) {
      return opportunity.priceImpact
    }
  }

  /**
   * Calcula tolerancia de slippage basada en la estrategia
   */
  private calculateSlippageTolerance(opportunity: ArbitrageOpportunity): number {
    switch (opportunity.type) {
      case 'simple':
        return 1.0 // 1%
      case 'triangular':
        return 2.0 // 2%
      case 'cross-chain':
        return 3.0 // 3%
      default:
        return 1.5
    }
  }

  /**
   * Calcula métricas de rentabilidad neta
   */
  private calculateProfitabilityMetrics(
    opportunity: ArbitrageOpportunity,
    gasMetrics: GasMetrics,
    slippageAnalysis: SlippageAnalysis
  ): ProfitabilityMetrics {
    const grossProfit = parseFloat(opportunity.profit)
    const gasCost = gasMetrics.gasFeeUSD
    
    // Calcular costos de slippage
    const slippageCost = (grossProfit * slippageAnalysis.actualSlippage) / 100
    
    // Calcular fees de DEX (estimado 0.3% por swap)
    const dexFees = (grossProfit * opportunity.dexPath.length * 0.003)
    
    // Costos cross-chain si aplica
    const crossChainCosts = opportunity.type === 'cross-chain' ? 5.0 : 0 // $5 estimado
    
    // Ganancia neta
    const netProfit = grossProfit - gasCost - slippageCost - dexFees - crossChainCosts
    
    // ROI neto
    const investmentAmount = parseFloat(opportunity.amountIn)
    const netProfitPercentage = (netProfit / investmentAmount) * 100
    
    // Margen de seguridad
    const profitMargin = netProfit / gasCost
    
    return {
      grossProfit,
      netProfit,
      netProfitPercentage,
      gasCostPercentage: (gasCost / grossProfit) * 100,
      slippageCost,
      dexFees,
      crossChainCosts,
      minimumViableProfit: gasCost * 1.5, // mínimo 1.5x el costo de gas
      profitMargin
    }
  }

  /**
   * Evalúa la viabilidad de ejecución
   */
  private evaluateExecutionViability(
    opportunity: ArbitrageOpportunity,
    gasMetrics: GasMetrics,
    profitabilityMetrics: ProfitabilityMetrics,
    gasProfile: BlockchainGasProfile
  ): ExecutionViability {
    const riskFactors: string[] = []
    const recommendations: string[] = []
    let viabilityScore = 100
    
    // Verificar ganancia mínima viable
    if (profitabilityMetrics.netProfit < profitabilityMetrics.minimumViableProfit) {
      riskFactors.push('Ganancia neta insuficiente para cubrir costos de gas')
      viabilityScore -= 30
      recommendations.push('Aumentar tamaño de operación o esperar mejor oportunidad')
    }
    
    // Verificar margen de seguridad
    if (profitabilityMetrics.profitMargin < 1.5) {
      riskFactors.push('Margen de seguridad insuficiente')
      viabilityScore -= 20
      recommendations.push('Ejecutar solo si ROI neto > 150% del costo de gas')
    }
    
    // Verificar competencia en mempool
    if (gasProfile.gasEfficiency === 'low' && profitabilityMetrics.netProfitPercentage < 200) {
      riskFactors.push('ROI bajo en blockchain de alto costo de gas')
      viabilityScore -= 25
      recommendations.push('Considerar L2s o sidechains para operaciones pequeñas')
    }
    
    // Verificar velocidad de ejecución
    if (gasProfile.blockTime > 10 && opportunity.type === 'cross-chain') {
      riskFactors.push('Blockchain lenta para arbitrajes cross-chain')
      viabilityScore -= 15
      recommendations.push('Usar blockchains más rápidas para operaciones time-sensitive')
    }
    
    // Calcular probabilidad de ejecución
    const executionProbability = this.calculateExecutionProbability(
      opportunity, 
      gasMetrics, 
      gasProfile
    )
    
    // Ventana óptima de ejecución
    const optimalExecutionWindow = this.calculateOptimalExecutionWindow(
      gasProfile, 
      profitabilityMetrics
    )
    
    return {
      isViable: viabilityScore >= 70,
      viabilityScore: Math.max(0, viabilityScore),
      executionProbability,
      riskFactors,
      recommendations,
      optimalExecutionWindow
    }
  }

  /**
   * Calcula probabilidad de ejecución exitosa
   */
  private calculateExecutionProbability(
    opportunity: ArbitrageOpportunity,
    gasMetrics: GasMetrics,
    gasProfile: BlockchainGasProfile
  ): number {
    let probability = 90 // base 90%
    
    // Reducir por competencia en mempool
    if (gasProfile.gasEfficiency === 'low') {
      probability -= 15
    }
    
    // Reducir por complejidad de la operación
    if (opportunity.type === 'cross-chain') {
      probability -= 10
    }
    
    // Reducir si requiere flash loan
    if (opportunity.flashLoanRequired) {
      probability -= 5
    }
    
    // Aumentar si es L2 rápido
    if (gasProfile.gasEfficiency === 'very-high') {
      probability += 5
    }
    
    return Math.max(50, Math.min(95, probability))
  }

  /**
   * Calcula ventana óptima de ejecución
   */
  private calculateOptimalExecutionWindow(
    gasProfile: BlockchainGasProfile,
    profitabilityMetrics: ProfitabilityMetrics
  ): number {
    // Base: 2 bloques
    let window = gasProfile.blockTime * 2
    
    // Ajustar por margen de ganancia
    if (profitabilityMetrics.profitMargin > 3) {
      window *= 0.5 // ejecutar más rápido si margen alto
    } else if (profitabilityMetrics.profitMargin < 2) {
      window *= 1.5 // más tiempo si margen bajo
    }
    
    return Math.max(1, Math.min(60, window)) // entre 1 y 60 segundos
  }

  /**
   * Calcula volatilidad del precio (placeholder)
   */
  private async calculatePriceVolatility(opportunity: ArbitrageOpportunity): Promise<number> {
    // Implementar cálculo real de volatilidad
    return 2.5 // 2.5% por defecto
  }

  /**
   * Evalúa competencia en mempool (placeholder)
   */
  private async assessMempoolCompetition(
    chainId: number, 
    provider: ethers.providers.Provider
  ): Promise<number> {
    // Implementar evaluación real del mempool
    const profile = this.gasProfiles.get(chainId)!
    return profile.gasEfficiency === 'low' ? 75 : 25 // alto en mainnet, bajo en L2s
  }

  /**
   * Obtiene recomendaciones de estrategia por blockchain
   */
  public getStrategyRecommendations(chainId: number): string[] {
    const profile = this.gasProfiles.get(chainId)
    return profile?.recommendedStrategies || []
  }

  /**
   * Obtiene perfil de gas de una blockchain
   */
  public getGasProfile(chainId: number): BlockchainGasProfile | undefined {
    return this.gasProfiles.get(chainId)
  }

  /**
   * Calcula ROI mínimo viable por blockchain
   */
  public calculateMinimumViableROI(chainId: number, operationType: string): number {
    const profile = this.gasProfiles.get(chainId)
    if (!profile) return 500 // 500% por defecto
    
    let baseROI = 150 // 150% base
    
    // Ajustar por tipo de operación
    switch (operationType) {
      case 'simple':
        baseROI += 50
        break
      case 'triangular':
        baseROI += 100
        break
      case 'cross-chain':
        baseROI += 200
        break
    }
    
    // Ajustar por eficiencia de gas
    switch (profile.gasEfficiency) {
      case 'very-high':
        baseROI -= 50
        break
      case 'high':
        baseROI -= 25
        break
      case 'low':
        baseROI += 100
        break
    }
    
    return Math.max(100, baseROI)
  }
}
