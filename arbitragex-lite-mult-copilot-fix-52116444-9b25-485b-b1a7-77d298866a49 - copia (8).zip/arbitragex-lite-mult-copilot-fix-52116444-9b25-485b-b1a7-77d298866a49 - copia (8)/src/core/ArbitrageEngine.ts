import { ethers } from 'ethers'
import { 
  ArbitrageOpportunity, 
  PriceQuote, 
  DEXConfig, 
  SUPPORTED_DEXES, 
  SUPPORTED_CHAINS,
  COMMON_TOKENS,
  RiskParameters,
  ExecutionResult
} from './types'

export class ArbitrageEngine {
  private providers: Map<number, ethers.Provider> = new Map()
  private riskParams: RiskParameters
  private isRunning: boolean = false
  private opportunities: ArbitrageOpportunity[] = []
  private priceCache: Map<string, PriceQuote> = new Map()
  private lastUpdate: number = 0

  constructor(riskParams: RiskParameters) {
    this.riskParams = riskParams
    this.initializeProviders()
  }

  private initializeProviders() {
    for (const [chainId, config] of Object.entries(SUPPORTED_CHAINS)) {
      const provider = new ethers.JsonRpcProvider(config.rpcUrl)
      this.providers.set(parseInt(chainId), provider)
    }
  }

  // Main arbitrage scanning function
  async scanForOpportunities(tokensToScan?: string[]): Promise<ArbitrageOpportunity[]> {
    const opportunities: ArbitrageOpportunity[] = []
    const currentTime = Date.now()

    try {
      // Get current prices from all DEXes
      const prices = await this.getAllPrices(tokensToScan)
      
      // Find simple arbitrage opportunities (same token pair, different DEXes)
      const simpleOpps = await this.findSimpleArbitrage(prices)
      opportunities.push(...simpleOpps)

      // Find triangular arbitrage opportunities
      const triangularOpps = await this.findTriangularArbitrage(prices)
      opportunities.push(...triangularOpps)

      // Find cross-chain arbitrage opportunities
      const crossChainOpps = await this.findCrossChainArbitrage(prices)
      opportunities.push(...crossChainOpps)

      // Filter and rank opportunities
      const validOpportunities = opportunities
        .filter(opp => this.isOpportunityValid(opp))
        .sort((a, b) => b.netProfitPercentage - a.netProfitPercentage)
        .slice(0, 50) // Limit to top 50 opportunities

      this.opportunities = validOpportunities
      this.lastUpdate = currentTime

      return validOpportunities

    } catch (error) {
      console.error('Error scanning for arbitrage opportunities:', error)
      return []
    }
  }

  // Get current price quotes from all DEXes
  private async getAllPrices(tokensToScan?: string[]): Promise<PriceQuote[]> {
    const prices: PriceQuote[] = []
    const tokenPairs = this.generateTokenPairs(tokensToScan)

    const pricePromises = tokenPairs.map(async (pair) => {
      try {
        const quote = await this.getPrice(pair.token0, pair.token1, pair.dex, pair.chainId)
        if (quote) {
          prices.push(quote)
          // Cache the price
          const cacheKey = `${pair.chainId}-${pair.dex}-${pair.token0}-${pair.token1}`
          this.priceCache.set(cacheKey, quote)
        }
      } catch (error) {
        console.error(`Error getting price for ${pair.token0}/${pair.token1} on ${pair.dex}:`, error)
      }
    })

    await Promise.allSettled(pricePromises)
    return prices
  }

  // Get price quote from specific DEX
  private async getPrice(
    tokenIn: string, 
    tokenOut: string, 
    dexKey: string, 
    chainId: number,
    amountIn: string = ethers.parseEther('1').toString()
  ): Promise<PriceQuote | null> {
    try {
      const dex = SUPPORTED_DEXES[dexKey]
      if (!dex || dex.chainId !== chainId) return null

      const provider = this.providers.get(chainId)
      if (!provider) return null

      let amountOut: string
      let gasEstimate: number

      if (dex.version === 'v3') {
        // Use Uniswap V3 quoter
        const quoterAbi = [
          'function quoteExactInputSingle(address tokenIn, address tokenOut, uint24 fee, uint256 amountIn, uint160 sqrtPriceLimitX96) external returns (uint256 amountOut)'
        ]
        const quoter = new ethers.Contract(dex.quoterAddress!, quoterAbi, provider)
        
        // Try different fee tiers for V3
        const feeTiers = [500, 3000, 10000] // 0.05%, 0.3%, 1%
        let bestAmountOut = '0'
        
        for (const fee of feeTiers) {
          try {
            const result = await quoter.quoteExactInputSingle(
              tokenIn,
              tokenOut,
              fee,
              amountIn,
              0 // sqrtPriceLimitX96
            )
            if (result > bestAmountOut) {
              bestAmountOut = result.toString()
            }
          } catch {
            // Fee tier might not exist
            continue
          }
        }
        
        amountOut = bestAmountOut
        gasEstimate = dex.swapGasCost
        
      } else {
        // Use Uniswap V2 style router
        const routerAbi = [
          'function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts)'
        ]
        const router = new ethers.Contract(dex.routerAddress, routerAbi, provider)
        const path = [tokenIn, tokenOut]
        
        const amounts = await router.getAmountsOut(amountIn, path)
        amountOut = amounts[1].toString()
        gasEstimate = dex.swapGasCost
      }

      // Calculate price and price impact
      const price = parseFloat(amountOut) / parseFloat(amountIn)
      const priceImpact = this.calculatePriceImpact(amountIn, amountOut, tokenIn, tokenOut)

      // Get current gas price
      const feeData = await provider.getFeeData()
      const gasPrice = feeData.gasPrice || ethers.parseUnits('20', 'gwei')
      const txCost = parseFloat(ethers.formatEther(gasPrice * BigInt(gasEstimate)))

      const currentBlock = await provider.getBlockNumber()

      return {
        dex: dexKey,
        chainId,
        tokenIn,
        tokenOut,
        amountIn,
        amountOut,
        price,
        priceImpact,
        gasEstimate,
        timestamp: Date.now(),
        blockNumber: currentBlock,
        txCost
      }

    } catch (error) {
      console.error(`Error getting price from ${dexKey}:`, error)
      return null
    }
  }

  // Find simple arbitrage opportunities (same pair, different DEXes)
  private async findSimpleArbitrage(prices: PriceQuote[]): Promise<ArbitrageOpportunity[]> {
    const opportunities: ArbitrageOpportunity[] = []
    const pairGroups = new Map<string, PriceQuote[]>()

    // Group prices by token pair
    prices.forEach(price => {
      const pairKey = `${price.tokenIn}-${price.tokenOut}`
      if (!pairGroups.has(pairKey)) {
        pairGroups.set(pairKey, [])
      }
      pairGroups.get(pairKey)!.push(price)
    })

    // Find arbitrage opportunities within each pair
    for (const [pairKey, pairPrices] of pairGroups) {
      if (pairPrices.length < 2) continue

      // Sort by price (highest output for same input)
      pairPrices.sort((a, b) => parseFloat(b.amountOut) - parseFloat(a.amountOut))

      const buyDex = pairPrices[pairPrices.length - 1] // Cheapest (buy here)
      const sellDex = pairPrices[0] // Most expensive (sell here)

      const profit = parseFloat(sellDex.amountOut) - parseFloat(buyDex.amountOut)
      const profitPercentage = (profit / parseFloat(buyDex.amountOut)) * 100

      const totalGasCost = buyDex.txCost + sellDex.txCost
      const netProfit = profit - totalGasCost
      const netProfitPercentage = (netProfit / parseFloat(buyDex.amountOut)) * 100

      if (netProfitPercentage >= this.riskParams.minProfitThreshold) {
        const opportunity: ArbitrageOpportunity = {
          id: `simple-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          type: 'simple',
          tokenPath: [buyDex.tokenIn, buyDex.tokenOut],
          dexPath: [buyDex.dex, sellDex.dex],
          chainPath: [buyDex.chainId, sellDex.chainId],
          amountIn: buyDex.amountIn,
          expectedAmountOut: sellDex.amountOut,
          profit: profit.toString(),
          profitPercentage,
          gasEstimate: buyDex.gasEstimate + sellDex.gasEstimate,
          netProfit: netProfit.toString(),
          netProfitPercentage,
          priceImpact: Math.max(buyDex.priceImpact, sellDex.priceImpact),
          confidence: this.calculateConfidence(buyDex, sellDex),
          riskScore: this.calculateRiskScore(buyDex, sellDex),
          timestamp: Date.now(),
          executionDeadline: Date.now() + 60000, // 1 minute
          flashLoanRequired: buyDex.chainId !== sellDex.chainId,
          flashLoanAmount: buyDex.chainId !== sellDex.chainId ? buyDex.amountIn : undefined
        }

        opportunities.push(opportunity)
      }
    }

    return opportunities
  }

  // Find triangular arbitrage opportunities
  private async findTriangularArbitrage(prices: PriceQuote[]): Promise<ArbitrageOpportunity[]> {
    const opportunities: ArbitrageOpportunity[] = []
    
    // Group prices by chain and DEX
    const pricesByChainDex = new Map<string, PriceQuote[]>()
    prices.forEach(price => {
      const key = `${price.chainId}-${price.dex}`
      if (!pricesByChainDex.has(key)) {
        pricesByChainDex.set(key, [])
      }
      pricesByChainDex.get(key)!.push(price)
    })

    // For each chain/DEX combination, look for triangular arbitrage
    for (const [chainDexKey, chainPrices] of pricesByChainDex) {
      const tokens = this.getUniqueTokens(chainPrices)
      
      // Try all possible triangular paths
      for (let i = 0; i < tokens.length; i++) {
        for (let j = 0; j < tokens.length; j++) {
          for (let k = 0; k < tokens.length; k++) {
            if (i === j || j === k || i === k) continue

            const tokenA = tokens[i]
            const tokenB = tokens[j]
            const tokenC = tokens[k]

            const path = [tokenA, tokenB, tokenC, tokenA]
            const triangularOpp = await this.calculateTriangularArbitrage(path, chainPrices)
            
            if (triangularOpp && triangularOpp.netProfitPercentage >= this.riskParams.minProfitThreshold) {
              opportunities.push(triangularOpp)
            }
          }
        }
      }
    }

    return opportunities
  }

  // Find cross-chain arbitrage opportunities
  private async findCrossChainArbitrage(prices: PriceQuote[]): Promise<ArbitrageOpportunity[]> {
    const opportunities: ArbitrageOpportunity[] = []
    
    // Group prices by token pair across different chains
    const crossChainPairs = new Map<string, PriceQuote[]>()
    
    prices.forEach(price => {
      const pairKey = `${price.tokenIn}-${price.tokenOut}`
      if (!crossChainPairs.has(pairKey)) {
        crossChainPairs.set(pairKey, [])
      }
      crossChainPairs.get(pairKey)!.push(price)
    })

    // Find cross-chain opportunities
    for (const [pairKey, pairPrices] of crossChainPairs) {
      // Group by chain
      const chainGroups = new Map<number, PriceQuote[]>()
      pairPrices.forEach(price => {
        if (!chainGroups.has(price.chainId)) {
          chainGroups.set(price.chainId, [])
        }
        chainGroups.get(price.chainId)!.push(price)
      })

      if (chainGroups.size < 2) continue

      // Find best price on each chain
      const chainBestPrices = new Map<number, PriceQuote>()
      for (const [chainId, chainPrices] of chainGroups) {
        const bestPrice = chainPrices.reduce((best, current) => 
          parseFloat(current.amountOut) > parseFloat(best.amountOut) ? current : best
        )
        chainBestPrices.set(chainId, bestPrice)
      }

      // Compare across chains
      const chainIds = Array.from(chainBestPrices.keys())
      for (let i = 0; i < chainIds.length; i++) {
        for (let j = i + 1; j < chainIds.length; j++) {
          const price1 = chainBestPrices.get(chainIds[i])!
          const price2 = chainBestPrices.get(chainIds[j])!

          const profit1to2 = parseFloat(price2.amountOut) - parseFloat(price1.amountOut)
          const profit2to1 = parseFloat(price1.amountOut) - parseFloat(price2.amountOut)

          // Estimate bridge costs (simplified)
          const bridgeCost = 0.001 // 0.1% bridge fee
          const bridgeCostAmount = parseFloat(price1.amountIn) * bridgeCost

          if (profit1to2 > bridgeCostAmount) {
            const netProfit = profit1to2 - bridgeCostAmount
            const netProfitPercentage = (netProfit / parseFloat(price1.amountOut)) * 100

            if (netProfitPercentage >= this.riskParams.minProfitThreshold) {
              const opportunity: ArbitrageOpportunity = {
                id: `cross-chain-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                type: 'cross-chain',
                tokenPath: [price1.tokenIn, price1.tokenOut],
                dexPath: [price1.dex, price2.dex],
                chainPath: [price1.chainId, price2.chainId],
                amountIn: price1.amountIn,
                expectedAmountOut: price2.amountOut,
                profit: profit1to2.toString(),
                profitPercentage: (profit1to2 / parseFloat(price1.amountOut)) * 100,
                gasEstimate: price1.gasEstimate + price2.gasEstimate + 50000, // Bridge gas
                netProfit: netProfit.toString(),
                netProfitPercentage,
                priceImpact: Math.max(price1.priceImpact, price2.priceImpact),
                confidence: this.calculateConfidence(price1, price2) * 0.8, // Lower confidence for cross-chain
                riskScore: this.calculateRiskScore(price1, price2) + 20, // Higher risk for cross-chain
                timestamp: Date.now(),
                executionDeadline: Date.now() + 300000, // 5 minutes for cross-chain
                flashLoanRequired: true,
                flashLoanAmount: price1.amountIn
              }

              opportunities.push(opportunity)
            }
          }
        }
      }
    }

    return opportunities
  }

  // Calculate triangular arbitrage opportunity
  private async calculateTriangularArbitrage(
    tokenPath: string[], 
    prices: PriceQuote[]
  ): Promise<ArbitrageOpportunity | null> {
    if (tokenPath.length !== 4 || tokenPath[0] !== tokenPath[3]) return null

    // Find prices for each leg
    const leg1 = prices.find(p => p.tokenIn === tokenPath[0] && p.tokenOut === tokenPath[1])
    const leg2 = prices.find(p => p.tokenIn === tokenPath[1] && p.tokenOut === tokenPath[2])
    const leg3 = prices.find(p => p.tokenIn === tokenPath[2] && p.tokenOut === tokenPath[3])

    if (!leg1 || !leg2 || !leg3) return null

    // Calculate final amount
    const amount1 = parseFloat(leg1.amountOut)
    const amount2 = amount1 * leg2.price
    const finalAmount = amount2 * leg3.price
    const initialAmount = parseFloat(leg1.amountIn)

    const profit = finalAmount - initialAmount
    const profitPercentage = (profit / initialAmount) * 100

    const totalGasCost = leg1.txCost + leg2.txCost + leg3.txCost
    const netProfit = profit - totalGasCost
    const netProfitPercentage = (netProfit / initialAmount) * 100

    if (netProfitPercentage < this.riskParams.minProfitThreshold) return null

    return {
      id: `triangular-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'triangular',
      tokenPath: tokenPath.slice(0, 3),
      dexPath: [leg1.dex, leg2.dex, leg3.dex],
      chainPath: [leg1.chainId, leg2.chainId, leg3.chainId],
      amountIn: leg1.amountIn,
      expectedAmountOut: finalAmount.toString(),
      profit: profit.toString(),
      profitPercentage,
      gasEstimate: leg1.gasEstimate + leg2.gasEstimate + leg3.gasEstimate,
      netProfit: netProfit.toString(),
      netProfitPercentage,
      priceImpact: Math.max(leg1.priceImpact, leg2.priceImpact, leg3.priceImpact),
      confidence: this.calculateConfidence(leg1, leg2, leg3),
      riskScore: this.calculateRiskScore(leg1, leg2, leg3),
      timestamp: Date.now(),
      executionDeadline: Date.now() + 120000, // 2 minutes
      flashLoanRequired: this.riskParams.enableFlashLoans,
      flashLoanAmount: this.riskParams.enableFlashLoans ? leg1.amountIn : undefined
    }
  }

  // Validate opportunity against risk parameters
  private isOpportunityValid(opportunity: ArbitrageOpportunity): boolean {
    // Check minimum profit threshold
    if (opportunity.netProfitPercentage < this.riskParams.minProfitThreshold) {
      return false
    }

    // Check maximum price impact
    if (opportunity.priceImpact > this.riskParams.maxPriceImpact) {
      return false
    }

    // Check execution deadline
    if (opportunity.executionDeadline < Date.now()) {
      return false
    }

    // Check flash loan requirements
    if (opportunity.flashLoanRequired && !this.riskParams.enableFlashLoans) {
      return false
    }

    // Check flash loan amount limit
    if (opportunity.flashLoanAmount && 
        parseFloat(opportunity.flashLoanAmount) > parseFloat(this.riskParams.maxFlashLoanAmount)) {
      return false
    }

    return true
  }

  // Calculate confidence score (0-1)
  private calculateConfidence(...quotes: PriceQuote[]): number {
    const avgAge = quotes.reduce((sum, q) => sum + (Date.now() - q.timestamp), 0) / quotes.length
    const maxAge = 30000 // 30 seconds
    
    const ageScore = Math.max(0, 1 - (avgAge / maxAge))
    const priceImpactScore = quotes.reduce((min, q) => Math.min(min, 1 - q.priceImpact / 100), 1)
    
    return (ageScore + priceImpactScore) / 2
  }

  // Calculate risk score (0-100)
  private calculateRiskScore(...quotes: PriceQuote[]): number {
    const maxPriceImpact = Math.max(...quotes.map(q => q.priceImpact))
    const chainDiversity = new Set(quotes.map(q => q.chainId)).size
    const dexDiversity = new Set(quotes.map(q => q.dex)).size
    
    let riskScore = 0
    
    // Price impact risk
    riskScore += maxPriceImpact * 2
    
    // Chain risk (more chains = more risk)
    riskScore += (chainDiversity - 1) * 10
    
    // DEX risk (more DEXes = slightly more risk)
    riskScore += (dexDiversity - 1) * 5
    
    return Math.min(100, Math.max(0, riskScore))
  }

  // Calculate price impact (simplified)
  private calculatePriceImpact(amountIn: string, amountOut: string, tokenIn: string, tokenOut: string): number {
    // This is a simplified calculation
    // In practice, you'd want to compare against a reference price
    const amount = parseFloat(amountIn)
    
    // Assume larger amounts have higher price impact
    if (amount > 1000000) return 5.0      // > 1M = 5%
    if (amount > 100000) return 2.0       // > 100K = 2%
    if (amount > 10000) return 1.0        // > 10K = 1%
    if (amount > 1000) return 0.5         // > 1K = 0.5%
    return 0.1                            // Small amounts = 0.1%
  }

  // Generate token pairs for scanning
  private generateTokenPairs(tokensToScan?: string[]): Array<{token0: string, token1: string, dex: string, chainId: number}> {
    const pairs: Array<{token0: string, token1: string, dex: string, chainId: number}> = []
    
    for (const [chainId, tokens] of Object.entries(COMMON_TOKENS)) {
      const chainIdNum = parseInt(chainId)
      const tokenList = tokensToScan || Object.values(tokens)
      
      // Get DEXes for this chain
      const chainDexes = Object.values(SUPPORTED_DEXES).filter(dex => dex.chainId === chainIdNum)
      
      for (const dex of chainDexes) {
        for (let i = 0; i < tokenList.length; i++) {
          for (let j = i + 1; j < tokenList.length; j++) {
            pairs.push({
              token0: tokenList[i],
              token1: tokenList[j],
              dex: Object.keys(SUPPORTED_DEXES).find(key => SUPPORTED_DEXES[key] === dex)!,
              chainId: chainIdNum
            })
          }
        }
      }
    }
    
    return pairs
  }

  // Get unique tokens from price quotes
  private getUniqueTokens(prices: PriceQuote[]): string[] {
    const tokens = new Set<string>()
    prices.forEach(price => {
      tokens.add(price.tokenIn)
      tokens.add(price.tokenOut)
    })
    return Array.from(tokens)
  }

  // Execute arbitrage opportunity
  async executeOpportunity(opportunity: ArbitrageOpportunity): Promise<ExecutionResult> {
    try {
      // Validate opportunity is still valid
      if (!this.isOpportunityValid(opportunity)) {
        return {
          success: false,
          error: 'Opportunity is no longer valid',
          timestamp: Date.now()
        }
      }

      // For now, return a simulation result
      // In production, this would execute actual blockchain transactions
      const simulationResult = this.simulateExecution(opportunity)
      
      return {
        success: simulationResult.success,
        transactionHash: simulationResult.success ? `0x${Math.random().toString(16).slice(2, 66)}` : undefined,
        gasUsed: opportunity.gasEstimate,
        actualProfit: simulationResult.success ? opportunity.netProfit : undefined,
        error: simulationResult.success ? undefined : simulationResult.error,
        timestamp: Date.now()
      }

    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown execution error',
        timestamp: Date.now()
      }
    }
  }

  // Simulate execution (for testing)
  private simulateExecution(opportunity: ArbitrageOpportunity): {success: boolean, error?: string} {
    // Simulate a 90% success rate with various failure modes
    const random = Math.random()
    
    if (random < 0.1) {
      const errors = [
        'Insufficient liquidity',
        'Price slippage too high',
        'Transaction reverted',
        'Gas price too high',
        'MEV sandwich attack detected'
      ]
      return {
        success: false,
        error: errors[Math.floor(Math.random() * errors.length)]
      }
    }
    
    return { success: true }
  }

  // Start continuous scanning
  async startScanning(intervalMs: number = 5000) {
    if (this.isRunning) return
    
    this.isRunning = true
    
    const scan = async () => {
      if (!this.isRunning) return
      
      try {
        await this.scanForOpportunities()
      } catch (error) {
        console.error('Scanning error:', error)
      }
      
      if (this.isRunning) {
        setTimeout(scan, intervalMs)
      }
    }
    
    scan()
  }

  // Stop scanning
  stopScanning() {
    this.isRunning = false
  }

  // Get current opportunities
  getOpportunities(): ArbitrageOpportunity[] {
    return [...this.opportunities]
  }

  // Get cached prices
  getCachedPrices(): PriceQuote[] {
    return Array.from(this.priceCache.values())
  }

  // Update risk parameters
  updateRiskParameters(newParams: Partial<RiskParameters>) {
    this.riskParams = { ...this.riskParams, ...newParams }
  }

  // Get current risk parameters
  getRiskParameters(): RiskParameters {
    return { ...this.riskParams }
  }
}

export default ArbitrageEngine