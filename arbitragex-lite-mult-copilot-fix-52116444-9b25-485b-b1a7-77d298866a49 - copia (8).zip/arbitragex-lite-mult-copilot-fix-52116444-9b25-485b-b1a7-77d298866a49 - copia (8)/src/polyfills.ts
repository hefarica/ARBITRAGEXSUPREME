/**
 * Browser polyfills for Node.js compatibility
 * This file provides minimal polyfills for Node.js APIs when running in browser
 */

// Import browser-safe utilities
import { getBrowserMemoryUsage, getBrowserCPUUsage } from './utils/browserCompat'

// Polyfill for process object
if (typeof global === 'undefined') {
  (window as any).global = globalThis;
}

if (typeof process === 'undefined') {
  (window as any).process = {
    env: {},
    platform: 'browser',
    version: 'v18.0.0',
    nextTick: (callback: Function) => setTimeout(callback, 0),
    browser: true,
    cwd: () => '/',
    memoryUsage: getBrowserMemoryUsage,
    cpuUsage: getBrowserCPUUsage,
    hrtime: {
      bigint: () => BigInt(Date.now() * 1000000)
    }
  };
}

// Buffer polyfill (minimal)
if (typeof Buffer === 'undefined') {
  (window as any).Buffer = {
    from: (data: any) => new Uint8Array(data),
    isBuffer: () => false
  };
}

export {};