use clap::Parser;
use anyhow::Result;
use tokio::time::{sleep, Duration};
use std::sync::Arc;
use tokio::sync::RwLock;
use serde::{Deserialize, Serialize};
use tracing::{info, warn, error, Level};
use tracing_subscriber;

mod config;
mod ethereum;
mod gap_engine;
mod database;
mod monitoring;
mod utils;

use config::Config;
use ethereum::EthereumClient;
use gap_engine::GapEngine;
use database::ClickHouseClient;
use monitoring::GrafanaClient;

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    #[arg(short, long, default_value = "config/auditor-config.toml")]
    config: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GapEvent {
    pub id: String,
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub gap_score: f64,
    pub price_gap: f64,
    pub depth_gap: f64,
    pub latency_gap: f64,
    pub risk_gap: f64,
    pub roi_net: f64,
    pub collision_prob: f64,
    pub status: String,
    pub route: Vec<String>,
    pub blockchains: Vec<String>,
    pub estimated_profit: f64,
    pub gas_cost: f64,
    pub mempool_status: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeStatus {
    pub name: String,
    pub url: String,
    pub status: String,
    pub block_number: u64,
    pub gas_price: u64,
    pub pending_txs: u32,
    pub last_update: chrono::DateTime<chrono::Utc>,
}

#[tokio::main]
async fn main() -> Result<()> {
    // Configurar logging
    tracing_subscriber::fmt()
        .with_max_level(Level::INFO)
        .with_target(false)
        .with_thread_ids(true)
        .with_thread_names(true)
        .init();

    info!("🚀 Iniciando GAP Auditor Keyless Edition...");

    // Parsear argumentos
    let args = Args::parse();
    
    // Cargar configuración
    let config = Config::from_file(&args.config)?;
    info!("✅ Configuración cargada desde: {}", args.config);

    // Inicializar clientes
    let ethereum_client = Arc::new(EthereumClient::new(&config).await?);
    let clickhouse_client = Arc::new(ClickHouseClient::new(&config).await?);
    let grafana_client = Arc::new(GrafanaClient::new(&config).await?);
    
    // Inicializar GAP Engine
    let gap_engine = Arc::new(GapEngine::new(
        ethereum_client.clone(),
        clickhouse_client.clone(),
        grafana_client.clone(),
        config.clone(),
    ).await?);

    info!("✅ Todos los componentes inicializados");

    // Ejecutar auditor
    run_auditor(gap_engine, config).await?;

    Ok(())
}

async fn run_auditor(gap_engine: Arc<GapEngine>, config: Config) -> Result<()> {
    info!("🎯 Iniciando bucle principal del auditor...");
    
    let mut interval = tokio::time::interval(Duration::from_millis(config.execution.collection_interval_ms));
    
    loop {
        interval.tick().await;
        
        // Verificar si estamos en modo "Observe"
        if !gap_engine.is_mempool_synchronized().await {
            warn!("⚠️ Mempool desincronizado - Cambiando a modo Observe");
            continue;
        }

        // Recolectar datos blockchain
        match gap_engine.collect_blockchain_data().await {
            Ok(data) => {
                info!("📊 Datos blockchain recolectados: bloque {}", data.block_number);
            }
            Err(e) => {
                error!("❌ Error recolectando datos blockchain: {}", e);
                continue;
            }
        }

        // Recolectar precios DEX
        match gap_engine.collect_dex_prices().await {
            Ok(prices) => {
                info!("💰 Precios DEX recolectados: {} pares", prices.len());
            }
            Err(e) => {
                error!("❌ Error recolectando precios DEX: {}", e);
                continue;
            }
        }

        // Calcular métricas GAP
        match gap_engine.calculate_gap_metrics().await {
            Ok(metrics) => {
                info!("📈 Métricas GAP calculadas - Score: {:.2}", metrics.gap_score);
                
                // Verificar si debemos ejecutar
                if metrics.gap_score >= config.execution.min_gap_score as f64 
                   && metrics.roi_net >= config.execution.min_roi_net as f64 {
                    
                    info!("🎯 Oportunidad detectada! GapScore: {:.2}, ROI: {:.2}%", 
                          metrics.gap_score, metrics.roi_net);
                    
                    // Simular en Anvil
                    match gap_engine.simulate_opportunity(&metrics).await {
                        Ok(simulation) => {
                            if simulation.success {
                                info!("✅ Simulación exitosa - Profit: ${:.2}", simulation.estimated_profit);
                                
                                // Verificar probabilidad de colisión
                                if simulation.collision_probability <= config.execution.max_collision_prob as f64 {
                                    info!("🚀 Ejecutando oportunidad...");
                                    
                                    // Crear y enviar bundle a Flashbots
                                    match gap_engine.execute_opportunity(&metrics, &simulation).await {
                                        Ok(execution) => {
                                            info!("✅ Ejecución completada - Bundle ID: {}", execution.bundle_id);
                                        }
                                        Err(e) => {
                                            error!("❌ Error en ejecución: {}", e);
                                        }
                                    }
                                } else {
                                    warn!("⚠️ Probabilidad de colisión alta: {:.2}%", 
                                          simulation.collision_probability * 100.0);
                                }
                            } else {
                                warn!("⚠️ Simulación fallida: {}", simulation.error_message);
                            }
                        }
                        Err(e) => {
                            error!("❌ Error en simulación: {}", e);
                        }
                    }
                }
            }
            Err(e) => {
                error!("❌ Error calculando métricas GAP: {}", e);
                continue;
            }
        }

        // Guardar evento en ClickHouse
        let event = GapEvent {
            id: uuid::Uuid::new_v4().to_string(),
            timestamp: chrono::Utc::now(),
            gap_score: 0.0, // Se actualizará con el valor real
            price_gap: 0.0,
            depth_gap: 0.0,
            latency_gap: 0.0,
            risk_gap: 0.0,
            roi_net: 0.0,
            collision_prob: 0.0,
            status: "monitoring".to_string(),
            route: vec![],
            blockchains: vec![],
            estimated_profit: 0.0,
            gas_cost: 0.0,
            mempool_status: "synchronized".to_string(),
        };

        if let Err(e) = gap_engine.save_event(&event).await {
            error!("❌ Error guardando evento: {}", e);
        }

        // Verificar latencia de decisión
        if gap_engine.get_decision_latency().await > config.execution.decision_latency_ms {
            warn!("⚠️ Latencia de decisión alta: {}ms", gap_engine.get_decision_latency().await);
        }
    }
} 