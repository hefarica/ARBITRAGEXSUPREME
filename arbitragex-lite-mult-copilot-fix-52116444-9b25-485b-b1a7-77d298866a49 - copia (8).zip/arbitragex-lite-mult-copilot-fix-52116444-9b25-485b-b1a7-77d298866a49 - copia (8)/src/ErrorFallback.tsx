import React from 'react'

interface ErrorFallbackProps {
  error: Error
  resetErrorBoundary: () => void
}

export const ErrorFallback: React.FC<ErrorFallbackProps> = ({ 
  error, 
  resetErrorBoundary 
}) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-4 p-8 max-w-md mx-auto">
        <div className="text-6xl mb-4">⚠️</div>
        <h1 className="text-2xl font-bold text-foreground">
          Oops! Algo salió mal
        </h1>
        <p className="text-muted-foreground">
          Ha ocurrido un error inesperado en la aplicación.
        </p>
        <details className="text-left bg-muted p-4 rounded-lg text-xs">
          <summary className="cursor-pointer mb-2 font-semibold">
            Detalles del error
          </summary>
          <pre className="whitespace-pre-wrap text-destructive">
            {error.message}
          </pre>
        </details>
        <button
          onClick={resetErrorBoundary}
          className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
        >
          Intentar de nuevo
        </button>
      </div>
    </div>
  )
}