// Test file to verify MOAD panel works
import { MOADPanel } from './components/panels/MOADPanel'

export const TestMOAD = () => {
  return (
    <div className="p-4">
      <h1>Testing MOAD Panel</h1>
      <MOADPanel environment="test" />
    </div>
  )
}