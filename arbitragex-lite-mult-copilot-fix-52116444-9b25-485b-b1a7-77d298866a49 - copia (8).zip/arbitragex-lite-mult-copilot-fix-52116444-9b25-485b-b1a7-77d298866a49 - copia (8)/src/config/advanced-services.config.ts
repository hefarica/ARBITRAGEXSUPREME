/**
 * 🚀 Configuración de Servicios Avanzados 2025 - ArbitrageX Pro
 * Configuración centralizada para todos los servicios avanzados implementados
 */

export interface AdvancedServicesConfig {
  mevProtection: MEVProtectionConfig
  flashLoans: FlashLoansConfig
  crossChain: CrossChainConfig
  performance: PerformanceConfig
}

export interface MEVProtectionConfig {
  enabled: boolean
  defaultLevel: 'basic' | 'advanced' | 'military'
  flashbotsEnabled: boolean
  privateMempoolEnabled: boolean
  bundleExecutionEnabled: boolean
  maxGasPrice: number
  maxSlippage: number
  riskThresholds: {
    low: number
    medium: number
    high: number
  }
}

export interface FlashLoansConfig {
  enabled: boolean
  providers: {
    aaveV3: {
      enabled: boolean
      maxAmount: string
      referralCode: string
    }
    dydx: {
      enabled: boolean
      maxAmount: string
    }
    compound: {
      enabled: boolean
      maxAmount: string
    }
  }
  riskManagement: {
    maxLoanAmount: string
    minProfitThreshold: number
    maxExecutionTime: number
  }
}

export interface CrossChainConfig {
  enabled: boolean
  supportedChains: number[]
  bridges: {
    enabled: boolean
    providers: string[]
    maxBridgeAmount: string
  }
  arbitrage: {
    minProfitThreshold: number
    maxExecutionSteps: number
    gasOptimization: boolean
  }
}

export interface PerformanceConfig {
  enabled: boolean
  monitoringInterval: number
  metrics: {
    latency: boolean
    gasEfficiency: boolean
    successRate: boolean
    mevProtection: boolean
    crossChainEfficiency: boolean
  }
  alerts: {
    enabled: boolean
    thresholds: {
      latency: number
      gasPrice: number
      failureRate: number
    }
  }
}

export const DEFAULT_ADVANCED_SERVICES_CONFIG: AdvancedServicesConfig = {
  mevProtection: {
    enabled: true,
    defaultLevel: 'advanced',
    flashbotsEnabled: true,
    privateMempoolEnabled: true,
    bundleExecutionEnabled: true,
    maxGasPrice: 100,
    maxSlippage: 2.0,
    riskThresholds: {
      low: 0.5,
      medium: 2.0,
      high: 5.0
    }
  },
  flashLoans: {
    enabled: true,
    providers: {
      aaveV3: {
        enabled: true,
        maxAmount: '1000000',
        referralCode: 'ARBITRAGEX_PRO_2025'
      },
      dydx: {
        enabled: true,
        maxAmount: '500000'
      },
      compound: {
        enabled: false,
        maxAmount: '100000'
      }
    },
    riskManagement: {
      maxLoanAmount: '1000000',
      minProfitThreshold: 1.5,
      maxExecutionTime: 120
    }
  },
  crossChain: {
    enabled: true,
    supportedChains: [1, 56, 137, 42161, 10, 43114], // ETH, BSC, POLYGON, ARBITRUM, OPTIMISM, AVALANCHE
    bridges: {
      enabled: true,
      providers: ['multichain', 'stargate', 'hop'],
      maxBridgeAmount: '1000000'
    },
    arbitrage: {
      minProfitThreshold: 2.0,
      maxExecutionSteps: 5,
      gasOptimization: true
    }
  },
  performance: {
    enabled: true,
    monitoringInterval: 5000,
    metrics: {
      latency: true,
      gasEfficiency: true,
      successRate: true,
      mevProtection: true,
      crossChainEfficiency: true
    },
    alerts: {
      enabled: true,
      thresholds: {
        latency: 1000,
        gasPrice: 150,
        failureRate: 5.0
      }
    }
  }
}

export const ENVIRONMENT_CONFIGS = {
  test: {
    ...DEFAULT_ADVANCED_SERVICES_CONFIG,
    mevProtection: {
      ...DEFAULT_ADVANCED_SERVICES_CONFIG.mevProtection,
      defaultLevel: 'basic',
      flashbotsEnabled: false
    },
    flashLoans: {
      ...DEFAULT_ADVANCED_SERVICES_CONFIG.flashLoans,
      riskManagement: {
        ...DEFAULT_ADVANCED_SERVICES_CONFIG.flashLoans.riskManagement,
        maxLoanAmount: '10000'
      }
    },
    crossChain: {
      ...DEFAULT_ADVANCED_SERVICES_CONFIG.crossChain,
      supportedChains: [1, 137] // Solo ETH y POLYGON para testing
    }
  },
  prod: {
    ...DEFAULT_ADVANCED_SERVICES_CONFIG,
    mevProtection: {
      ...DEFAULT_ADVANCED_SERVICES_CONFIG.mevProtection,
      defaultLevel: 'military',
      flashbotsEnabled: true,
      privateMempoolEnabled: true
    },
    flashLoans: {
      ...DEFAULT_ADVANCED_SERVICES_CONFIG.flashLoans,
      riskManagement: {
        ...DEFAULT_ADVANCED_SERVICES_CONFIG.flashLoans.riskManagement,
        maxLoanAmount: '10000000'
      }
    }
  }
}

export function getAdvancedServicesConfig(environment: 'test' | 'prod'): AdvancedServicesConfig {
  return ENVIRONMENT_CONFIGS[environment]
}

export function validateAdvancedServicesConfig(config: AdvancedServicesConfig): string[] {
  const errors: string[] = []

  if (config.mevProtection.enabled && config.mevProtection.maxGasPrice <= 0) {
    errors.push('MEV Protection maxGasPrice must be greater than 0')
  }

  if (config.flashLoans.enabled && parseFloat(config.flashLoans.riskManagement.maxLoanAmount) <= 0) {
    errors.push('Flash Loans maxLoanAmount must be greater than 0')
  }

  if (config.crossChain.enabled && config.crossChain.supportedChains.length === 0) {
    errors.push('Cross-Chain must have at least one supported chain')
  }

  if (config.performance.enabled && config.performance.monitoringInterval < 1000) {
    errors.push('Performance monitoring interval must be at least 1000ms')
  }

  return errors
}

export default DEFAULT_ADVANCED_SERVICES_CONFIG
