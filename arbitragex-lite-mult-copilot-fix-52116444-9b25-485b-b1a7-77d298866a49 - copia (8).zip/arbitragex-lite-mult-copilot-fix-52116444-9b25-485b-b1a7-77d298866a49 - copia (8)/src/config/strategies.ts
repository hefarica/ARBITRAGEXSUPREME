// 📊 ESTRATEGIAS DE ARBITRAJE ORDENADAS POR ROI 2025
// Basado en análisis de mejores prácticas de repositorios DeFi líderes

import { StrategyInfo } from '../types/strategy.types'

export const strategies: StrategyInfo[] = [
  // 🥇 Estrategias de Máximo ROI (90-100% anual esperado)
  {
    id: 'cross-chain-multi-hop-flash-loan',
    label: 'Cross-Chain Multi-Hop Flash-Loan',
    description: 'Arbitraje complejo que combina flash loans con rutas multi-hop entre diferentes blockchains para maximizar oportunidades',
    roi2025: 10,
    riskLevel: 'extreme',
    complexity: 'expert',
    requirements: {
      minCapital: 50000,  // $50k USD mínimo
      maxGasPrice: 200,   // 200 Gwei máximo
      blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc'],
      timeframe: '30s'
    },
    metrics: {
      avgProfit: 2.5,     // 2.5% promedio por trade
      successRate: 65,    // 65% éxito
      avgExecutionTime: 45, // 45 segundos
      gasEfficiency: 6    // 6/10 eficiencia
    },
    enabled: true,
    category: 'flash-loan'
  },
  
  {
    id: 'cross-chain-cross-dex',
    label: 'Cross-Chain Cross-DEX Arbitrage',
    description: 'Arbitraje entre diferentes DEXs en múltiples blockchains aprovechando diferencias de precio',
    roi2025: 9,
    riskLevel: 'high',
    complexity: 'expert',
    requirements: {
      minCapital: 25000,
      maxGasPrice: 150,
      blockchains: ['ethereum', 'polygon', 'arbitrum', 'bsc'],
      timeframe: '1m'
    },
    metrics: {
      avgProfit: 1.8,
      successRate: 75,
      avgExecutionTime: 60,
      gasEfficiency: 7
    },
    enabled: true,
    category: 'cross-chain'
  },

  // 🥈 Estrategias de Alto ROI (70-90% anual esperado)
  {
    id: 'flash-loan-triangular-cross-dex',
    label: 'Flash-Loan Triangular Cross-DEX',
    description: 'Arbitraje triangular mejorado con flash loans entre múltiples DEXs en la misma blockchain',
    roi2025: 8,
    riskLevel: 'high',
    complexity: 'advanced',
    requirements: {
      minCapital: 15000,
      maxGasPrice: 120,
      blockchains: ['ethereum', 'polygon', 'arbitrum'],
      timeframe: '2m'
    },
    metrics: {
      avgProfit: 1.5,
      successRate: 80,
      avgExecutionTime: 30,
      gasEfficiency: 8
    },
    enabled: true,
    category: 'flash-loan'
  },

  {
    id: 'multi-hop-cross-dex',
    label: 'Multi-Hop Cross-DEX Arbitrage',
    description: 'Rutas de arbitraje de múltiples saltos entre diferentes DEXs optimizando la ruta más rentable',
    roi2025: 7,
    riskLevel: 'medium',
    complexity: 'advanced',
    requirements: {
      minCapital: 10000,
      maxGasPrice: 100,
      blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism'],
      timeframe: '3m'
    },
    metrics: {
      avgProfit: 1.2,
      successRate: 85,
      avgExecutionTime: 25,
      gasEfficiency: 8
    },
    enabled: true,
    category: 'cross-dex'
  },

  {
    id: 'jit-liquidity-arbitrage',
    label: 'JIT Liquidity Arbitrage',
    description: 'Arbitraje usando Just-In-Time Liquidity para capturar MEV de forma ética',
    roi2025: 6,
    riskLevel: 'high',
    complexity: 'expert',
    requirements: {
      minCapital: 20000,
      maxGasPrice: 150,
      blockchains: ['ethereum'],
      timeframe: '10s'
    },
    metrics: {
      avgProfit: 2.0,
      successRate: 70,
      avgExecutionTime: 15,
      gasEfficiency: 5
    },
    enabled: false, // Experimental
    category: 'mev-protection'
  },

  // 🥉 Estrategias de ROI Medio (50-70% anual esperado)
  {
    id: 'flash-loan-cross-dex',
    label: 'Flash-Loan Cross-DEX Arbitrage',
    description: 'Arbitraje básico con flash loans entre dos DEXs diferentes en la misma blockchain',
    roi2025: 5,
    riskLevel: 'medium',
    complexity: 'intermediate',
    requirements: {
      minCapital: 5000,
      maxGasPrice: 80,
      blockchains: ['ethereum', 'polygon', 'bsc'],
      timeframe: '5m'
    },
    metrics: {
      avgProfit: 0.8,
      successRate: 90,
      avgExecutionTime: 20,
      gasEfficiency: 9
    },
    enabled: true,
    category: 'flash-loan'
  },

  {
    id: 'triangular-inter-dex',
    label: 'Triangular Inter-DEX',
    description: 'Arbitraje triangular clásico entre diferentes DEXs en la misma blockchain',
    roi2025: 4,
    riskLevel: 'medium',
    complexity: 'intermediate',
    requirements: {
      minCapital: 3000,
      maxGasPrice: 60,
      blockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum'],
      timeframe: '5m'
    },
    metrics: {
      avgProfit: 0.6,
      successRate: 92,
      avgExecutionTime: 18,
      gasEfficiency: 9
    },
    enabled: true,
    category: 'cross-dex'
  },

  {
    id: 'atomic-swap-cross-dex',
    label: 'Atomic Swap Cross-DEX',
    description: 'Swaps atómicos entre DEXs para arbitraje sin riesgo de contraparte',
    roi2025: 3,
    riskLevel: 'low',
    complexity: 'intermediate',
    requirements: {
      minCapital: 2000,
      maxGasPrice: 50,
      blockchains: ['ethereum', 'polygon', 'arbitrum'],
      timeframe: '10m'
    },
    metrics: {
      avgProfit: 0.4,
      successRate: 95,
      avgExecutionTime: 15,
      gasEfficiency: 10
    },
    enabled: true,
    category: 'cross-dex'
  },

  // 🏅 Estrategias de ROI Estándar (30-50% anual esperado)
  {
    id: 'triangular-intra-dex',
    label: 'Triangular Intra-DEX',
    description: 'Arbitraje triangular dentro del mismo DEX aprovechando ineficiencias temporales',
    roi2025: 2,
    riskLevel: 'low',
      complexity: 'simple',
      requirements: {
        minCapital: 1000,
        maxGasPrice: 40,
        blockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism'],
        timeframe: '15m'
    },
    metrics: {
      avgProfit: 0.3,
      successRate: 96,
      avgExecutionTime: 12,
      gasEfficiency: 10
    },
    enabled: true,
    category: 'intra-dex'
  },

  {
    id: 'basic-cross-dex',
    label: 'Basic Cross-DEX Arbitrage',
    description: 'Arbitraje básico entre dos DEXs diferentes para el mismo par de tokens',
    roi2025: 1,
    riskLevel: 'low',
    complexity: 'simple',
    requirements: {
      minCapital: 500,
      maxGasPrice: 30,
      blockchains: ['polygon', 'bsc', 'arbitrum', 'optimism'],
      timeframe: '20m'
    },
    metrics: {
      avgProfit: 0.2,
      successRate: 98,
      avgExecutionTime: 10,
      gasEfficiency: 10
    },
    enabled: true,
    category: 'cross-dex'
  },

  {
    id: 'basic-flash-loan',
    label: 'Basic Flash-Loan Arbitrage',
    description: 'Flash loan básico para arbitraje simple sin capital inicial',
    roi2025: 0,
    riskLevel: 'low',
    complexity: 'simple',
    requirements: {
      minCapital: 0,  // No requiere capital inicial
      maxGasPrice: 25,
      blockchains: ['polygon', 'bsc', 'arbitrum'],
      timeframe: '30m'
    },
    metrics: {
      avgProfit: 0.1,
      successRate: 99,
      avgExecutionTime: 8,
      gasEfficiency: 10
    },
    enabled: true,
    category: 'flash-loan'
  }
]

// Funciones de utilidad para estrategias
export const getStrategyById = (id: string): StrategyInfo | undefined => {
  return strategies.find(strategy => strategy.id === id)
}

export const getStrategiesByCategory = (category: StrategyInfo['category']): StrategyInfo[] => {
  return strategies.filter(strategy => strategy.category === category)
}

export const getEnabledStrategies = (): StrategyInfo[] => {
  return strategies.filter(strategy => strategy.enabled)
}

export const getStrategiesByRiskLevel = (riskLevel: StrategyInfo['riskLevel']): StrategyInfo[] => {
  return strategies.filter(strategy => strategy.riskLevel === riskLevel)
}

export const getTopStrategiesByROI = (limit: number = 5): StrategyInfo[] => {
  return [...strategies]
    .sort((a, b) => b.roi2025 - a.roi2025)
    .slice(0, limit)
}

export const getStrategyCategories = (): string[] => {
  return [...new Set(strategies.map(s => s.category))]
}

export const getRiskLevels = (): string[] => {
  return ['low', 'medium', 'high', 'extreme']
}

export const getComplexityLevels = (): string[] => {
  return ['simple', 'intermediate', 'advanced', 'expert']
}