// src/config/serviceConfigs.ts

/**
 * Configuración centralizada de todos los servicios DEX y blockchains
 * Permite habilitar/deshabilitar integraciones dinámicamente
 */

export interface ServiceConfig {
  name: string
  enabled: boolean
  endpoint: string
  timeout: number
  retries: number
  fallbackEnabled: boolean
  healthCheckInterval: number
  priority: number // 1-10, mayor número = mayor prioridad
}

export interface BlockchainConfig {
  chainId: number
  name: string
  shortName: string
  rpcUrl: string
  explorerUrl: string
  nativeCurrency: string
  enabled: boolean
  gasMultiplier: number // Multiplicador para estimaciones de gas
  confirmations: number // Confirmaciones requeridas
}

// Configuración de DEXs con prioridades basadas en TVL y confiabilidad
export const DEX_SERVICE_CONFIGS: Record<string, ServiceConfig> = {
  'uniswap-v3': {
    name: 'Uniswap V3',
    enabled: true,
    endpoint: 'https://api.uniswap.org/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000,
    priority: 10 // Más alta prioridad
  },
  'sushiswap': {
    name: 'SushiSwap',
    enabled: true,
    endpoint: 'https://api.sushi.com/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000,
    priority: 8
  },
  'pancakeswap': {
    name: 'PancakeSwap',
    enabled: true,
    endpoint: 'https://api.pancakeswap.com/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000,
    priority: 9 // Alta prioridad en BSC
  },
  'quickswap': {
    name: 'QuickSwap',
    enabled: true,
    endpoint: 'https://api.quickswap.exchange/v1',
    timeout: 4000,
    retries: 2,
    fallbackEnabled: true,
    healthCheckInterval: 30000,
    priority: 7 // Específico para Polygon
  },
  '1inch': {
    name: '1inch',
    enabled: true,
    endpoint: 'https://api.1inch.io/v5.0',
    timeout: 3000,
    retries: 2,
    fallbackEnabled: true,
    healthCheckInterval: 15000,
    priority: 9 // Excelente para agregación
  },
  'balancer': {
    name: 'Balancer',
    enabled: true,
    endpoint: 'https://api.balancer.fi/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000,
    priority: 6
  },
  'trader-joe': {
    name: 'Trader Joe',
    enabled: true,
    endpoint: 'https://api.traderjoexyz.com/v1',
    timeout: 4000,
    retries: 2,
    fallbackEnabled: true,
    healthCheckInterval: 30000,
    priority: 7 // Para Avalanche principalmente
  },
  'raydium': {
    name: 'Raydium',
    enabled: false, // Solana no soportado inicialmente
    endpoint: 'https://api.raydium.io/v1',
    timeout: 4000,
    retries: 2,
    fallbackEnabled: false,
    healthCheckInterval: 30000,
    priority: 5
  }
}

// Configuración de blockchains soportadas
export const BLOCKCHAIN_CONFIGS: Record<string, BlockchainConfig> = {
  ethereum: {
    chainId: 1,
    name: 'Ethereum',
    shortName: 'ETH',
    rpcUrl: import.meta.env.VITE_ETHEREUM_RPC_URL || 'https://mainnet.infura.io/v3/YOUR_KEY',
    explorerUrl: 'https://etherscan.io',
    nativeCurrency: 'ETH',
    enabled: true,
    gasMultiplier: 1.2,
    confirmations: 2
  },
  polygon: {
    chainId: 137,
    name: 'Polygon',
    shortName: 'MATIC',
    rpcUrl: import.meta.env.VITE_POLYGON_RPC_URL || 'https://polygon-mainnet.infura.io/v3/YOUR_KEY',
    explorerUrl: 'https://polygonscan.com',
    nativeCurrency: 'MATIC',
    enabled: true,
    gasMultiplier: 1.1,
    confirmations: 3
  },
  arbitrum: {
    chainId: 42161,
    name: 'Arbitrum One',
    shortName: 'ARB',
    rpcUrl: import.meta.env.VITE_ARBITRUM_RPC_URL || 'https://arbitrum-mainnet.infura.io/v3/YOUR_KEY',
    explorerUrl: 'https://arbiscan.io',
    nativeCurrency: 'ETH',
    enabled: true,
    gasMultiplier: 1.0,
    confirmations: 1
  },
  bsc: {
    chainId: 56,
    name: 'BNB Smart Chain',
    shortName: 'BSC',
    rpcUrl: import.meta.env.VITE_BSC_RPC_URL || 'https://bsc-dataseed.binance.org',
    explorerUrl: 'https://bscscan.com',
    nativeCurrency: 'BNB',
    enabled: true,
    gasMultiplier: 1.1,
    confirmations: 3
  },
  optimism: {
    chainId: 10,
    name: 'Optimism',
    shortName: 'OP',
    rpcUrl: import.meta.env.VITE_OPTIMISM_RPC_URL || 'https://optimism-mainnet.infura.io/v3/YOUR_KEY',
    explorerUrl: 'https://optimistic.etherscan.io',
    nativeCurrency: 'ETH',
    enabled: true,
    gasMultiplier: 1.0,
    confirmations: 1
  },
  avalanche: {
    chainId: 43114,
    name: 'Avalanche C-Chain',
    shortName: 'AVAX',
    rpcUrl: import.meta.env.VITE_AVALANCHE_RPC_URL || 'https://api.avax.network/ext/bc/C/rpc',
    explorerUrl: 'https://snowtrace.io',
    nativeCurrency: 'AVAX',
    enabled: false, // Habilitado en fases futuras
    gasMultiplier: 1.1,
    confirmations: 2
  }
}

// Lista de activos principales por blockchain
export const MAJOR_ASSETS = {
  ethereum: [
    { symbol: 'ETH', address: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2', decimals: 18, isStable: false },
    { symbol: 'USDC', address: '0xA0b86a33E6417C31334b06c12aA63Ca04b9fa45', decimals: 6, isStable: true },
    { symbol: 'USDT', address: '0xdAC17F958D2ee523a2206206994597C13D831ec7', decimals: 6, isStable: true },
    { symbol: 'DAI', address: '0x6B175474E89094C44Da98b954EedeAC495271d0F', decimals: 18, isStable: true },
    { symbol: 'WBTC', address: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599', decimals: 8, isStable: false },
    { symbol: 'UNI', address: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984', decimals: 18, isStable: false },
    { symbol: 'LINK', address: '0x514910771AF9Ca656af840dff83E8264EcF986CA', decimals: 18, isStable: false },
    { symbol: 'AAVE', address: '0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9', decimals: 18, isStable: false },
  ],
  polygon: [
    { symbol: 'MATIC', address: '0x0000000000000000000000000000000000001010', decimals: 18, isStable: false },
    { symbol: 'USDC', address: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', decimals: 6, isStable: true },
    { symbol: 'USDT', address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', decimals: 6, isStable: true },
    { symbol: 'DAI', address: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063', decimals: 18, isStable: true },
    { symbol: 'WETH', address: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619', decimals: 18, isStable: false },
    { symbol: 'WBTC', address: '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6', decimals: 8, isStable: false },
  ],
  bsc: [
    { symbol: 'BNB', address: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', decimals: 18, isStable: false },
    { symbol: 'USDT', address: '0x55d398326f99059fF775485246999027B3197955', decimals: 18, isStable: true },
    { symbol: 'BUSD', address: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56', decimals: 18, isStable: true },
    { symbol: 'ETH', address: '0x2170Ed0880ac9A755fd29B2688956BD959F933F8', decimals: 18, isStable: false },
    { symbol: 'BTCB', address: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c', decimals: 18, isStable: false },
  ]
}

// Utilidades para configuración
export class ServiceConfigManager {
  static getEnabledDexes(): ServiceConfig[] {
    return Object.values(DEX_SERVICE_CONFIGS).filter(config => config.enabled)
  }

  static getEnabledBlockchains(): BlockchainConfig[] {
    return Object.values(BLOCKCHAIN_CONFIGS).filter(config => config.enabled)
  }

  static getDexesForChain(chainId: number): ServiceConfig[] {
    // Lógica para determinar qué DEXs están disponibles en cada chain
    const chainDexMap: Record<number, string[]> = {
      1: ['uniswap-v3', 'sushiswap', '1inch', 'balancer'], // Ethereum
      137: ['uniswap-v3', 'sushiswap', 'quickswap', '1inch'], // Polygon
      56: ['pancakeswap', 'sushiswap', '1inch'], // BSC
      42161: ['uniswap-v3', 'sushiswap', '1inch'], // Arbitrum
      10: ['uniswap-v3', '1inch'], // Optimism
    }

    const dexIds = chainDexMap[chainId] || []
    return dexIds
      .map(id => DEX_SERVICE_CONFIGS[id])
      .filter(config => config?.enabled)
      .sort((a, b) => b.priority - a.priority)
  }

  static getBlockchainConfig(chainId: number): BlockchainConfig | null {
    return Object.values(BLOCKCHAIN_CONFIGS).find(config => config.chainId === chainId) || null
  }

  static updateServiceStatus(serviceName: string, enabled: boolean): void {
    if (DEX_SERVICE_CONFIGS[serviceName]) {
      DEX_SERVICE_CONFIGS[serviceName].enabled = enabled
      // En un entorno real, esto persistiría la configuración
      console.log(`Service ${serviceName} ${enabled ? 'enabled' : 'disabled'}`)
    }
  }

  static getAssetsByChain(chainId: number): any[] {
    const chainKey = Object.keys(BLOCKCHAIN_CONFIGS).find(
      key => BLOCKCHAIN_CONFIGS[key].chainId === chainId
    )
    
    if (!chainKey || !MAJOR_ASSETS[chainKey as keyof typeof MAJOR_ASSETS]) {
      return []
    }
    
    return MAJOR_ASSETS[chainKey as keyof typeof MAJOR_ASSETS]
  }

  static validateConfiguration(): { valid: boolean; errors: string[] } {
    const errors: string[] = []
    
    // Verificar que al menos un DEX esté habilitado
    const enabledDexes = this.getEnabledDexes()
    if (enabledDexes.length === 0) {
      errors.push('No DEX services are enabled')
    }
    
    // Verificar que al menos una blockchain esté habilitada
    const enabledChains = this.getEnabledBlockchains()
    if (enabledChains.length === 0) {
      errors.push('No blockchain networks are enabled')
    }
    
    // Verificar que cada blockchain habilitada tenga al menos un DEX
    enabledChains.forEach(chain => {
      const chainDexes = this.getDexesForChain(chain.chainId)
      if (chainDexes.length === 0) {
        errors.push(`Chain ${chain.name} has no enabled DEX services`)
      }
    })
    
    return {
      valid: errors.length === 0,
      errors
    }
  }
}

// Hook React para usar configuraciones de servicio
export const useServiceConfigs = () => {
  const [configs, setConfigs] = useState({
    dexes: ServiceConfigManager.getEnabledDexes(),
    blockchains: ServiceConfigManager.getEnabledBlockchains()
  })
  
  const [validation, setValidation] = useState(ServiceConfigManager.validateConfiguration())

  const refreshConfigs = () => {
    setConfigs({
      dexes: ServiceConfigManager.getEnabledDexes(),
      blockchains: ServiceConfigManager.getEnabledBlockchains()
    })
    setValidation(ServiceConfigManager.validateConfiguration())
  }

  const toggleService = (serviceName: string, enabled: boolean) => {
    ServiceConfigManager.updateServiceStatus(serviceName, enabled)
    refreshConfigs()
  }

  return {
    ...configs,
    validation,
    refreshConfigs,
    toggleService,
    getDexesForChain: ServiceConfigManager.getDexesForChain,
    getAssetsByChain: ServiceConfigManager.getAssetsByChain
  }
}