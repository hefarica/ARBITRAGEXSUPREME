# Backend API Endpoints Configuration

## Endpoints requeridos para el Panel de Oportunidades

### GET /api/opportunities
Retorna todas las oportunidades detectadas para las estrategias activas.

**Query Parameters:**
- `env`: 'test' | 'prod'
- `strategy`: string (optional) - Filtrar por ID de estrategia
- `chain`: string (optional) - Filtrar por blockchain
- `minProfit`: number (optional) - Profit mínimo en USD
- `maxRisk`: number (optional) - Risk score máximo

**Response Format:**
```typescript
interface OpportunityResponse {
  opportunities: Opportunity[]
  totalCount: number
  lastUpdate: string
  nextUpdate: string
}

interface Opportunity {
  id: string
  strategy: string
  strategyName: string
  assets: string[]
  dex: string
  chain: string
  chainId: number
  estimatedProfit: number
  profitUSD: number
  riskScore: number
  executionTime: number
  confidence: number
  gasEstimate: number
  slippage: number
  minCapital: number
  lastDetected: Date
  expiresAt: Date
  liquidityDepth: number
  competitorCount: number
}
```

### POST /api/opportunities/:id/execute
Ejecuta una oportunidad específica.

**Request Body:**
```typescript
{
  environment: 'test' | 'prod'
  slippageTolerance?: number // Optional override
  gasPrice?: number // Optional override
}
```

**Response Format:**
```typescript
interface ExecutionResponse {
  success: boolean
  actualProfit: number
  executionTime: number
  gasUsed: number
  transactionHash: string
  slippage: number
  priceImpact: number
  route: string[]
}
```

### GET /api/assets
Retorna lista de todos los activos (tokens y LP tokens) disponibles.

**Query Parameters:**
- `chain`: string (optional) - Filtrar por blockchain

**Response Format:**
```typescript
interface AssetResponse {
  assets: Asset[]
  lpTokens: LPToken[]
}

interface Asset {
  address: string
  symbol: string
  name: string
  decimals: number
  chainId: number
  logoUrl?: string
  coingeckoId?: string
  isStable: boolean
  marketCap?: number
  dailyVolume?: number
}

interface LPToken {
  address: string
  symbol: string
  token0: Asset
  token1: Asset
  dex: string
  fee: number
  totalSupply: string
  reserve0: string
  reserve1: string
  apr?: number
}
```

### GET /api/dexes
Retorna configuración de DEXs disponibles.

**Query Parameters:**
- `chain`: string (optional) - Filtrar por blockchain

**Response Format:**
```typescript
interface DexResponse {
  dexes: DexInfo[]
}

interface DexInfo {
  name: string
  chainId: number
  routerAddress: string
  factoryAddress: string
  quoterAddress?: string
  supportedFeatures: string[]
  tvl: number
  dailyVolume: number
  isEnabled: boolean
  healthStatus: 'healthy' | 'degraded' | 'down'
  lastHealthCheck: string
}
```

## Configuración de Service Configs

### src/config/service_configs.ts
```typescript
export interface ServiceConfig {
  name: string
  enabled: boolean
  endpoint: string
  timeout: number
  retries: number
  fallbackEnabled: boolean
  healthCheckInterval: number
}

export const DEX_SERVICE_CONFIGS: Record<string, ServiceConfig> = {
  'uniswap-v3': {
    name: 'Uniswap V3',
    enabled: true,
    endpoint: 'https://api.uniswap.org/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000
  },
  'sushiswap': {
    name: 'SushiSwap',
    enabled: true,
    endpoint: 'https://api.sushi.com/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000
  },
  'pancakeswap': {
    name: 'PancakeSwap',
    enabled: true,
    endpoint: 'https://api.pancakeswap.com/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000
  },
  'quickswap': {
    name: 'QuickSwap',
    enabled: true,
    endpoint: 'https://api.quickswap.exchange/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000
  },
  '1inch': {
    name: '1inch',
    enabled: true,
    endpoint: 'https://api.1inch.io/v5.0',
    timeout: 3000,
    retries: 2,
    fallbackEnabled: true,
    healthCheckInterval: 15000
  },
  'balancer': {
    name: 'Balancer',
    enabled: true,
    endpoint: 'https://api.balancer.fi/v1',
    timeout: 5000,
    retries: 3,
    fallbackEnabled: true,
    healthCheckInterval: 30000
  }
}

export const BLOCKCHAIN_CONFIGS: Record<string, any> = {
  ethereum: {
    chainId: 1,
    name: 'Ethereum',
    rpcUrl: 'https://mainnet.infura.io/v3/YOUR_KEY',
    explorerUrl: 'https://etherscan.io',
    nativeCurrency: 'ETH',
    enabled: true
  },
  polygon: {
    chainId: 137,
    name: 'Polygon',
    rpcUrl: 'https://polygon-mainnet.infura.io/v3/YOUR_KEY',
    explorerUrl: 'https://polygonscan.com',
    nativeCurrency: 'MATIC',
    enabled: true
  },
  arbitrum: {
    chainId: 42161,
    name: 'Arbitrum',
    rpcUrl: 'https://arbitrum-mainnet.infura.io/v3/YOUR_KEY',
    explorerUrl: 'https://arbiscan.io',
    nativeCurrency: 'ETH',
    enabled: true
  },
  bsc: {
    chainId: 56,
    name: 'BSC',
    rpcUrl: 'https://bsc-dataseed.binance.org',
    explorerUrl: 'https://bscscan.com',
    nativeCurrency: 'BNB',
    enabled: true
  },
  optimism: {
    chainId: 10,
    name: 'Optimism',
    rpcUrl: 'https://optimism-mainnet.infura.io/v3/YOUR_KEY',
    explorerUrl: 'https://optimistic.etherscan.io',
    nativeCurrency: 'ETH',
    enabled: true
  }
}
```

## WebSocket Endpoints (Opcional para Real-Time)

### WS /ws/opportunities
Stream en tiempo real de nuevas oportunidades detectadas.

**Message Format:**
```typescript
interface OpportunityUpdate {
  type: 'opportunity_detected' | 'opportunity_expired' | 'opportunity_executed'
  opportunity: Opportunity
  timestamp: string
}
```

### WS /ws/metrics
Stream de métricas de sistema en tiempo real.

**Message Format:**
```typescript
interface MetricsUpdate {
  type: 'arbitrage_metrics' | 'hft_metrics' | 'system_health'
  data: any
  timestamp: string
}
```

## Implementación Progressiva

1. **Fase 1:** Implementar endpoints básicos con datos mock
2. **Fase 2:** Integrar conectores DEX reales
3. **Fase 3:** Añadir WebSocket para updates en tiempo real
4. **Fase 4:** Optimizar con caching y rate limiting

## Rate Limiting y Caching

```typescript
// Configuración recomendada
const API_RATE_LIMITS = {
  'GET /api/opportunities': '100/minute',
  'POST /api/opportunities/*/execute': '10/minute',
  'GET /api/assets': '20/minute',
  'GET /api/dexes': '10/minute'
}

const CACHE_STRATEGIES = {
  opportunities: 'TTL 5 seconds',
  assets: 'TTL 5 minutes',
  dexes: 'TTL 1 hour'
}
```