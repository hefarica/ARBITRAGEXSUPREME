import { ethers } from 'ethers'
import { StrategyViabilityService } from '../services/StrategyViabilityService'
import { ProfitabilityCalculator } from '../core/ProfitabilityCalculator'

/**
 * Ejemplo de uso del sistema de viabilidad de estrategias de arbitraje
 * Muestra cómo evaluar la rentabilidad real considerando costos de gas y slippage
 */
export class StrategyViabilityExample {
  
  /**
   * Ejemplo principal: Evaluar todas las estrategias
   */
  static async runFullAnalysis() {
    console.log('🚀 Iniciando análisis completo de viabilidad de estrategias...\n')
    
    try {
      // 1. Crear provider (en producción usar providers reales)
      const provider = new ethers.providers.JsonRpcProvider('https://eth-mainnet.alchemyapi.io/v2/demo')
      
      // 2. Inicializar servicio de viabilidad
      const service = new StrategyViabilityService()
      
      // 3. Evaluar todas las estrategias
      console.log('📊 Evaluando 8 estrategias de arbitraje...')
      const reports = await service.evaluateAllStrategies(provider)
      
      // 4. Mostrar resumen general
      this.displayGeneralSummary(reports)
      
      // 5. Mostrar análisis detallado por estrategia
      this.displayDetailedAnalysis(reports)
      
      // 6. Mostrar recomendaciones por blockchain
      this.displayBlockchainRecommendations(reports)
      
      // 7. Ejemplo de cálculo individual
      await this.runIndividualCalculationExample(provider)
      
    } catch (error) {
      console.error('❌ Error en el análisis:', error)
    }
  }
  
  /**
   * Muestra resumen general de todas las estrategias
   */
  private static displayGeneralSummary(reports: any[]) {
    console.log('\n📈 RESUMEN GENERAL DE VIABILIDAD')
    console.log('=====================================')
    
    const viableStrategies = reports.filter(r => r.overallViabilityScore >= 70)
    const avgScore = Math.round(reports.reduce((sum, r) => sum + r.overallViabilityScore, 0) / reports.length)
    
    console.log(`✅ Estrategias Viables: ${viableStrategies.length}/${reports.length}`)
    console.log(`📊 Score Promedio: ${avgScore}/100`)
    console.log(`🏆 Mejor Estrategia: ${reports[0]?.strategy.name} (${reports[0]?.overallViabilityScore}/100)`)
    console.log(`⚠️  Estrategias de Alto Riesgo: ${reports.filter(r => r.riskAssessment.level === 'high' || r.riskAssessment.level === 'extreme').length}`)
  }
  
  /**
   * Muestra análisis detallado por estrategia
   */
  private static displayDetailedAnalysis(reports: any[]) {
    console.log('\n🔍 ANÁLISIS DETALLADO POR ESTRATEGIA')
    console.log('=======================================')
    
    reports.forEach((report, index) => {
      console.log(`\n${index + 1}. ${report.strategy.name}`)
      console.log(`   📊 Score: ${report.overallViabilityScore}/100`)
      console.log(`   ⚠️  Riesgo: ${report.riskAssessment.level.toUpperCase()}`)
      console.log(`   💰 Capital Mín: $${report.strategy.minCapital}`)
      console.log(`   🌐 Blockchains Viables: ${report.blockchainReports.filter(r => r.isViable).length}/${report.blockchainReports.length}`)
      
      // Mostrar mejores blockchains
      const bestBlockchains = report.blockchainReports
        .filter(r => r.isViable)
        .sort((a, b) => b.viabilityScore - a.viabilityScore)
        .slice(0, 2)
      
      if (bestBlockchains.length > 0) {
        console.log(`   🏆 Mejores Blockchains:`)
        bestBlockchains.forEach(bc => {
          console.log(`      • ${bc.chainName}: ${bc.viabilityScore}/100`)
        })
      }
      
      // Mostrar recomendación principal
      if (report.recommendations.length > 0) {
        console.log(`   💡 Recomendación: ${report.recommendations[0]}`)
      }
    })
  }
  
  /**
   * Muestra recomendaciones por blockchain
   */
  private static displayBlockchainRecommendations(reports: any[]) {
    console.log('\n🌐 RECOMENDACIONES POR BLOCKCHAIN')
    console.log('==================================')
    
    const blockchainMap = new Map()
    
    // Agrupar por blockchain
    reports.forEach(report => {
      report.blockchainReports.forEach(bc => {
        if (!blockchainMap.has(bc.chainId)) {
          blockchainMap.set(bc.chainId, {
            name: bc.chainName,
            strategies: [],
            avgScore: 0,
            gasProfile: bc.gasProfile
          })
        }
        
        const blockchain = blockchainMap.get(bc.chainId)
        if (bc.isViable) {
          blockchain.strategies.push({
            name: report.strategy.name,
            score: bc.viabilityScore
          })
        }
      })
    })
    
    // Mostrar análisis por blockchain
    blockchainMap.forEach((blockchain, chainId) => {
      if (blockchain.strategies.length === 0) return
      
      const avgScore = Math.round(
        blockchain.strategies.reduce((sum, s) => sum + s.score, 0) / blockchain.strategies.length
      )
      
      console.log(`\n🔗 ${blockchain.name}`)
      console.log(`   📊 Score Promedio: ${avgScore}/100`)
      console.log(`   ⚡ Eficiencia Gas: ${blockchain.gasProfile.gasEfficiency.toUpperCase()}`)
      console.log(`   💸 Costo Gas: $${blockchain.gasProfile.averageGasPriceUSD}`)
      console.log(`   🕐 Block Time: ${blockchain.gasProfile.blockTime}s`)
      console.log(`   🎯 Estrategias Recomendadas:`)
      
      blockchain.strategies
        .sort((a, b) => b.score - a.score)
        .slice(0, 3)
        .forEach(strategy => {
          console.log(`      • ${strategy.name}: ${strategy.score}/100`)
        })
    })
  }
  
  /**
   * Ejemplo de cálculo individual de viabilidad
   */
  private static async runIndividualCalculationExample(provider: ethers.providers.Provider) {
    console.log('\n🧮 EJEMPLO DE CÁLCULO INDIVIDUAL')
    console.log('==================================')
    
    try {
      const calculator = new ProfitabilityCalculator()
      
      // Crear oportunidad de ejemplo
      const sampleOpportunity = {
        id: 'example-1',
        type: 'triangular',
        tokenPath: ['USDC', 'ETH', 'USDC'],
        dexPath: ['Uniswap', 'SushiSwap', 'Uniswap'],
        chainPath: [137], // Polygon
        amountIn: '1000',
        expectedAmountOut: '1020',
        profit: '20',
        profitPercentage: 2.0,
        gasEstimate: 150000,
        netProfit: '0',
        netProfitPercentage: 0,
        priceImpact: 0.5,
        confidence: 0.8,
        riskScore: 30,
        timestamp: Date.now(),
        executionDeadline: Date.now() + 300000,
        flashLoanRequired: false
      }
      
      console.log('📋 Analizando oportunidad de ejemplo:')
      console.log(`   💰 Capital: $${sampleOpportunity.amountIn}`)
      console.log(`   📈 Ganancia Esperada: $${sampleOpportunity.profit} (${sampleOpportunity.profitPercentage}%)`)
      console.log(`   🌐 Blockchain: Polygon (Chain ID: ${sampleOpportunity.chainPath[0]})`)
      
      // Calcular viabilidad
      const viability = await calculator.calculateOpportunityViability(sampleOpportunity, provider)
      
      console.log('\n📊 RESULTADOS DEL ANÁLISIS:')
      console.log(`   ⛽ Costo Gas: $${viability.gasMetrics.gasFeeUSD.toFixed(3)}`)
      console.log(`   📉 Slippage Real: ${viability.slippageAnalysis.actualSlippage.toFixed(2)}%`)
      console.log(`   💵 Ganancia Bruta: $${viability.profitabilityMetrics.grossProfit.toFixed(2)}`)
      console.log(`   💸 Ganancia Neta: $${viability.profitabilityMetrics.netProfit.toFixed(2)}`)
      console.log(`   📊 ROI Neto: ${viability.profitabilityMetrics.netProfitPercentage.toFixed(2)}%`)
      console.log(`   🎯 Viabilidad: ${viability.executionViability.isViable ? '✅ VIABLE' : '❌ NO VIABLE'}`)
      console.log(`   📈 Score: ${viability.executionViability.viabilityScore}/100`)
      
      if (viability.executionViability.recommendations.length > 0) {
        console.log(`   💡 Recomendación: ${viability.executionViability.recommendations[0]}`)
      }
      
      // Mostrar ROI mínimo viable
      const minROI = calculator.calculateMinimumViableROI(137, 'triangular')
      console.log(`   🎯 ROI Mínimo Viable: ${minROI}%`)
      
    } catch (error) {
      console.error('❌ Error en cálculo individual:', error)
    }
  }
  
  /**
   * Ejemplo de comparación entre blockchains
   */
  static async compareBlockchains() {
    console.log('\n🔄 COMPARACIÓN ENTRE BLOCKCHAINS')
    console.log('==================================')
    
    const calculator = new ProfitabilityCalculator()
    const blockchains = [1, 56, 137, 42161, 10] // ETH, BSC, Polygon, Arbitrum, Optimism
    
    console.log('📊 Comparando eficiencia de gas y ROI mínimo:')
    
    blockchains.forEach(chainId => {
      const profile = calculator.getGasProfile(chainId)
      if (!profile) return
      
      const simpleROI = calculator.calculateMinimumViableROI(chainId, 'simple')
      const triangularROI = calculator.calculateMinimumViableROI(chainId, 'triangular')
      const crossChainROI = calculator.calculateMinimumViableROI(chainId, 'cross-chain')
      
      console.log(`\n🔗 ${profile.chainName}:`)
      console.log(`   ⚡ Eficiencia: ${profile.gasEfficiency.toUpperCase()}`)
      console.log(`   💸 Costo Gas: $${profile.averageGasPriceUSD}`)
      console.log(`   🕐 Block Time: ${profile.blockTime}s`)
      console.log(`   📈 ROI Mínimo:`)
      console.log(`      • Simple: ${simpleROI}%`)
      console.log(`      • Triangular: ${triangularROI}%`)
      console.log(`      • Cross-Chain: ${crossChainROI}%`)
    })
  }
}

// Ejecutar ejemplo si se llama directamente
if (require.main === module) {
  StrategyViabilityExample.runFullAnalysis()
    .then(() => {
      console.log('\n✅ Análisis completado exitosamente!')
      process.exit(0)
    })
    .catch((error) => {
      console.error('\n❌ Error en el análisis:', error)
      process.exit(1)
    })
}
