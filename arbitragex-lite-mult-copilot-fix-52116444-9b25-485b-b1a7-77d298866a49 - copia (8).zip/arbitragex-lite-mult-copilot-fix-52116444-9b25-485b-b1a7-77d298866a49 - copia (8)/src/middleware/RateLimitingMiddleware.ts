/**
 * 🛡️ RATE LIMITING MIDDLEWARE - ArbitrageX Pro 2025
 * Sistema avanzado de rate limiting con múltiples estrategias
 */

export interface RateLimitConfig {
  windowMs: number; // Ventana de tiempo en ms
  maxRequests: number; // Máximo requests por ventana
  strategy: 'sliding-window' | 'fixed-window' | 'token-bucket' | 'adaptive';
  skipSuccessfulRequests?: boolean;
  skipFailedRequests?: boolean;
  keyGenerator?: (req: any) => string;
  onLimitReached?: (req: any, info: RateLimitInfo) => void;
  whitelist?: string[];
  blacklist?: string[];
  adaptiveConfig?: {
    baseLimit: number;
    maxLimit: number;
    increaseRate: number;
    decreaseRate: number;
    errorThreshold: number;
  };
}

export interface RateLimitInfo {
  totalHits: number;
  totalHitsInWindow: number;
  resetTime: Date;
  remainingRequests: number;
  isLimited: boolean;
  strategy: string;
}

export interface RequestInfo {
  ip: string;
  userId?: string;
  endpoint: string;
  method: string;
  timestamp: number;
  success: boolean;
  responseTime: number;
}

/**
 * Rate Limiter usando Sliding Window
 */
export class SlidingWindowRateLimiter {
  private requests: Map<string, number[]> = new Map();
  private config: RateLimitConfig;

  constructor(config: RateLimitConfig) {
    this.config = config;
  }

  async checkLimit(key: string): Promise<RateLimitInfo> {
    const now = Date.now();
    const windowStart = now - this.config.windowMs;
    
    // Obtener requests actuales para esta key
    const currentRequests = this.requests.get(key) || [];
    
    // Filtrar requests dentro de la ventana
    const requestsInWindow = currentRequests.filter(timestamp => timestamp > windowStart);
    
    // Actualizar almacenamiento
    this.requests.set(key, requestsInWindow);
    
    const isLimited = requestsInWindow.length >= this.config.maxRequests;
    
    if (!isLimited) {
      // Agregar request actual
      requestsInWindow.push(now);
      this.requests.set(key, requestsInWindow);
    }

    return {
      totalHits: currentRequests.length,
      totalHitsInWindow: requestsInWindow.length,
      resetTime: new Date(now + this.config.windowMs),
      remainingRequests: Math.max(0, this.config.maxRequests - requestsInWindow.length),
      isLimited,
      strategy: 'sliding-window'
    };
  }

  cleanup(): void {
    const now = Date.now();
    const windowStart = now - this.config.windowMs;
    
    for (const [key, requests] of this.requests) {
      const validRequests = requests.filter(timestamp => timestamp > windowStart);
      if (validRequests.length === 0) {
        this.requests.delete(key);
      } else {
        this.requests.set(key, validRequests);
      }
    }
  }
}

/**
 * Rate Limiter usando Token Bucket
 */
export class TokenBucketRateLimiter {
  private buckets: Map<string, { tokens: number; lastRefill: number }> = new Map();
  private config: RateLimitConfig;

  constructor(config: RateLimitConfig) {
    this.config = config;
  }

  async checkLimit(key: string): Promise<RateLimitInfo> {
    const now = Date.now();
    
    // Obtener o crear bucket
    let bucket = this.buckets.get(key);
    if (!bucket) {
      bucket = {
        tokens: this.config.maxRequests,
        lastRefill: now
      };
      this.buckets.set(key, bucket);
    }

    // Calcular tokens a agregar basado en tiempo transcurrido
    const timePassed = now - bucket.lastRefill;
    const tokensToAdd = Math.floor((timePassed / this.config.windowMs) * this.config.maxRequests);
    
    if (tokensToAdd > 0) {
      bucket.tokens = Math.min(this.config.maxRequests, bucket.tokens + tokensToAdd);
      bucket.lastRefill = now;
    }

    const isLimited = bucket.tokens <= 0;
    
    if (!isLimited) {
      bucket.tokens--;
    }

    return {
      totalHits: this.config.maxRequests - bucket.tokens,
      totalHitsInWindow: this.config.maxRequests - bucket.tokens,
      resetTime: new Date(bucket.lastRefill + this.config.windowMs),
      remainingRequests: bucket.tokens,
      isLimited,
      strategy: 'token-bucket'
    };
  }

  cleanup(): void {
    const now = Date.now();
    const cutoff = now - (this.config.windowMs * 2); // Limpiar buckets viejos
    
    for (const [key, bucket] of this.buckets) {
      if (bucket.lastRefill < cutoff) {
        this.buckets.delete(key);
      }
    }
  }
}

/**
 * Rate Limiter Adaptivo
 */
export class AdaptiveRateLimiter {
  private limits: Map<string, number> = new Map();
  private requests: Map<string, RequestInfo[]> = new Map();
  private config: RateLimitConfig;

  constructor(config: RateLimitConfig) {
    this.config = config;
  }

  async checkLimit(key: string, requestInfo?: Partial<RequestInfo>): Promise<RateLimitInfo> {
    const now = Date.now();
    const windowStart = now - this.config.windowMs;
    
    // Obtener límite actual para esta key
    let currentLimit = this.limits.get(key) || this.config.adaptiveConfig!.baseLimit;
    
    // Obtener historial de requests
    const requestHistory = this.requests.get(key) || [];
    const recentRequests = requestHistory.filter(req => req.timestamp > windowStart);
    
    // Analizar performance reciente
    const analysis = this.analyzePerformance(recentRequests);
    
    // Ajustar límite basado en análisis
    currentLimit = this.adjustLimit(currentLimit, analysis);
    this.limits.set(key, currentLimit);
    
    const isLimited = recentRequests.length >= currentLimit;
    
    // Agregar request actual al historial si no está limitado
    if (!isLimited && requestInfo) {
      recentRequests.push({
        ip: requestInfo.ip || '',
        endpoint: requestInfo.endpoint || '',
        method: requestInfo.method || 'GET',
        timestamp: now,
        success: requestInfo.success !== false,
        responseTime: requestInfo.responseTime || 0
      });
      this.requests.set(key, recentRequests);
    }

    return {
      totalHits: requestHistory.length,
      totalHitsInWindow: recentRequests.length,
      resetTime: new Date(now + this.config.windowMs),
      remainingRequests: Math.max(0, currentLimit - recentRequests.length),
      isLimited,
      strategy: 'adaptive'
    };
  }

  private analyzePerformance(requests: RequestInfo[]) {
    if (requests.length === 0) {
      return { errorRate: 0, avgResponseTime: 0, requestRate: 0 };
    }

    const errors = requests.filter(req => !req.success).length;
    const errorRate = errors / requests.length;
    
    const totalResponseTime = requests.reduce((sum, req) => sum + req.responseTime, 0);
    const avgResponseTime = totalResponseTime / requests.length;
    
    const timeSpan = Math.max(1, (Date.now() - requests[0].timestamp) / 1000);
    const requestRate = requests.length / timeSpan;

    return { errorRate, avgResponseTime, requestRate };
  }

  private adjustLimit(currentLimit: number, analysis: any): number {
    const config = this.config.adaptiveConfig!;
    
    // Reducir límite si hay muchos errores o alta latencia
    if (analysis.errorRate > config.errorThreshold || analysis.avgResponseTime > 1000) {
      return Math.max(
        config.baseLimit,
        Math.floor(currentLimit * (1 - config.decreaseRate))
      );
    }
    
    // Aumentar límite si performance es buena
    if (analysis.errorRate < 0.01 && analysis.avgResponseTime < 200) {
      return Math.min(
        config.maxLimit,
        Math.floor(currentLimit * (1 + config.increaseRate))
      );
    }
    
    return currentLimit;
  }

  cleanup(): void {
    const now = Date.now();
    const cutoff = now - (this.config.windowMs * 2);
    
    for (const [key, requests] of this.requests) {
      const validRequests = requests.filter(req => req.timestamp > cutoff);
      if (validRequests.length === 0) {
        this.requests.delete(key);
      } else {
        this.requests.set(key, validRequests);
      }
    }
  }
}

/**
 * Middleware principal de Rate Limiting
 */
export class RateLimitingMiddleware {
  private limiters: Map<string, any> = new Map();
  private configs: Map<string, RateLimitConfig> = new Map();
  private cleanupInterval: NodeJS.Timeout;

  constructor() {
    // Cleanup periódico cada 5 minutos
    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, 5 * 60 * 1000);
  }

  /**
   * Crear rate limiter para endpoint específico
   */
  createLimiter(endpointPattern: string, config: RateLimitConfig): void {
    let limiter: any;

    switch (config.strategy) {
      case 'sliding-window':
        limiter = new SlidingWindowRateLimiter(config);
        break;
      case 'token-bucket':
        limiter = new TokenBucketRateLimiter(config);
        break;
      case 'adaptive':
        limiter = new AdaptiveRateLimiter(config);
        break;
      default:
        limiter = new SlidingWindowRateLimiter(config);
    }

    this.limiters.set(endpointPattern, limiter);
    this.configs.set(endpointPattern, config);
    
    console.log(`🛡️ Rate limiter creado para ${endpointPattern}: ${config.maxRequests} req/${config.windowMs}ms`);
  }

  /**
   * Middleware principal
   */
  middleware() {
    return async (req: any, res: any, next: any) => {
      try {
        const endpoint = req.path;
        const method = req.method;
        const ip = req.ip || req.connection.remoteAddress;
        const userId = req.user?.id;
        
        // Buscar configuración para este endpoint
        const { limiter, config } = this.findLimiterForEndpoint(endpoint);
        
        if (!limiter || !config) {
          return next(); // Sin rate limiting para este endpoint
        }

        // Verificar whitelist
        if (config.whitelist && config.whitelist.includes(ip)) {
          return next();
        }

        // Verificar blacklist
        if (config.blacklist && config.blacklist.includes(ip)) {
          return res.status(403).json({
            error: {
              code: 'BLACKLISTED',
              message: 'IP address is blacklisted',
              timestamp: new Date().toISOString()
            }
          });
        }

        // Generar key para rate limiting
        const key = config.keyGenerator 
          ? config.keyGenerator(req)
          : this.generateKey(ip, userId, endpoint);

        // Verificar límite
        const startTime = Date.now();
        const limitInfo = await limiter.checkLimit(key, {
          ip,
          endpoint,
          method,
          timestamp: startTime
        });

        // Agregar headers de rate limiting
        res.set({
          'X-RateLimit-Limit': config.maxRequests.toString(),
          'X-RateLimit-Remaining': limitInfo.remainingRequests.toString(),
          'X-RateLimit-Reset': limitInfo.resetTime.getTime().toString(),
          'X-RateLimit-Strategy': limitInfo.strategy
        });

        if (limitInfo.isLimited) {
          // Ejecutar callback si está configurado
          if (config.onLimitReached) {
            config.onLimitReached(req, limitInfo);
          }

          console.warn(`🚫 Rate limit excedido para ${key}: ${limitInfo.totalHitsInWindow}/${config.maxRequests}`);
          
          return res.status(429).json({
            error: {
              code: 'RATE_LIMIT_EXCEEDED',
              message: 'Too many requests',
              details: `Limit: ${config.maxRequests} requests per ${config.windowMs}ms`,
              retryAfter: Math.ceil(config.windowMs / 1000),
              timestamp: new Date().toISOString()
            }
          });
        }

        // Hook para registrar respuesta si es rate limiter adaptivo
        if (config.strategy === 'adaptive') {
          const originalSend = res.send;
          res.send = function(data: any) {
            const responseTime = Date.now() - startTime;
            const success = res.statusCode < 400;
            
            // Actualizar información en el limiter adaptivo
            limiter.requests.get(key)?.pop(); // Remover entrada temporal
            limiter.checkLimit(key, {
              ip,
              endpoint,
              method,
              timestamp: startTime,
              success,
              responseTime
            });
            
            return originalSend.call(this, data);
          };
        }

        next();

      } catch (error) {
        console.error('Error en rate limiting middleware:', error);
        next(); // En caso de error, permitir la request
      }
    };
  }

  /**
   * Configurar rate limiters para endpoints comunes
   */
  setupCommonLimiters(): void {
    // Health endpoint - sin límite
    // (no crear limiter)

    // API general - límite moderado
    this.createLimiter('/api/*', {
      windowMs: 60 * 1000, // 1 minuto
      maxRequests: 100,
      strategy: 'sliding-window'
    });

    // Métricas - límite alto para tiempo real
    this.createLimiter('/api/metrics', {
      windowMs: 60 * 1000, // 1 minuto
      maxRequests: 500,
      strategy: 'token-bucket'
    });

    // Oportunidades - límite moderado
    this.createLimiter('/api/opportunities', {
      windowMs: 60 * 1000,
      maxRequests: 200,
      strategy: 'sliding-window'
    });

    // Ejecución - límite bajo y crítico
    this.createLimiter('/api/execute', {
      windowMs: 60 * 1000,
      maxRequests: 10,
      strategy: 'adaptive',
      adaptiveConfig: {
        baseLimit: 5,
        maxLimit: 20,
        increaseRate: 0.1,
        decreaseRate: 0.2,
        errorThreshold: 0.1
      },
      onLimitReached: (req, info) => {
        console.error(`🚨 Rate limit crítico excedido en /api/execute: ${info.totalHitsInWindow}/${info.remainingRequests + info.totalHitsInWindow}`);
      }
    });

    // Control del sistema - límite muy bajo
    this.createLimiter('/api/start', {
      windowMs: 5 * 60 * 1000, // 5 minutos
      maxRequests: 5,
      strategy: 'sliding-window'
    });

    this.createLimiter('/api/stop', {
      windowMs: 5 * 60 * 1000,
      maxRequests: 5,
      strategy: 'sliding-window'
    });

    // Stream SSE - límite especial
    this.createLimiter('/api/stream', {
      windowMs: 60 * 1000,
      maxRequests: 10, // Máximo 10 conexiones SSE simultáneas por IP
      strategy: 'sliding-window'
    });

    console.log('🛡️ Rate limiters configurados para todos los endpoints');
  }

  /**
   * Buscar limiter para endpoint
   */
  private findLimiterForEndpoint(endpoint: string): { limiter: any; config: RateLimitConfig | undefined } {
    // Buscar coincidencia exacta primero
    for (const [pattern, limiter] of this.limiters) {
      if (this.matchesPattern(endpoint, pattern)) {
        return { limiter, config: this.configs.get(pattern) };
      }
    }
    
    return { limiter: null, config: undefined };
  }

  /**
   * Verificar si endpoint coincide con patrón
   */
  private matchesPattern(endpoint: string, pattern: string): boolean {
    // Convertir patrón con * a regex
    const regexPattern = pattern
      .replace(/\*/g, '.*')
      .replace(/\//g, '\\/');
    
    const regex = new RegExp(`^${regexPattern}$`);
    return regex.test(endpoint);
  }

  /**
   * Generar key para rate limiting
   */
  private generateKey(ip: string, userId?: string, endpoint?: string): string {
    // Usar userId si está disponible, sino IP
    const identifier = userId || ip;
    return `${identifier}:${endpoint || 'global'}`;
  }

  /**
   * Cleanup periódico
   */
  private cleanup(): void {
    console.log('🧹 Iniciando cleanup de rate limiters...');
    
    let totalCleaned = 0;
    for (const limiter of this.limiters.values()) {
      if (limiter.cleanup) {
        const beforeSize = limiter.requests?.size || limiter.buckets?.size || 0;
        limiter.cleanup();
        const afterSize = limiter.requests?.size || limiter.buckets?.size || 0;
        totalCleaned += beforeSize - afterSize;
      }
    }
    
    console.log(`🧹 Cleanup completado: ${totalCleaned} entradas limpiadas`);
  }

  /**
   * Obtener estadísticas de rate limiting
   */
  getStats(): Record<string, any> {
    const stats: Record<string, any> = {};
    
    for (const [pattern, limiter] of this.limiters) {
      const config = this.configs.get(pattern);
      stats[pattern] = {
        strategy: config?.strategy,
        maxRequests: config?.maxRequests,
        windowMs: config?.windowMs,
        activeKeys: limiter.requests?.size || limiter.buckets?.size || 0
      };
    }
    
    return stats;
  }

  /**
   * Reset de todos los limiters
   */
  resetAll(): void {
    for (const limiter of this.limiters.values()) {
      if (limiter.requests) limiter.requests.clear();
      if (limiter.buckets) limiter.buckets.clear();
      if (limiter.limits) limiter.limits.clear();
    }
    console.log('🔄 Todos los rate limiters reseteados');
  }

  /**
   * Destruir middleware
   */
  destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    this.limiters.clear();
    this.configs.clear();
  }
}

// Export singleton instance
export const rateLimitingMiddleware = new RateLimitingMiddleware();
export default RateLimitingMiddleware;
