/**
 * ✅ INPUT VALIDATION MIDDLEWARE - ArbitrageX Pro 2025
 * Validación exhaustiva de entrada para todos los endpoints críticos
 */

import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { SecurityUtils } from '../utils/SecurityUtils';

export interface ValidationRule {
  field: string;
  type: 'string' | 'number' | 'boolean' | 'object' | 'array' | 'ethereum_address' | 'transaction_hash' | 'private_key';
  required: boolean;
  min?: number;
  max?: number;
  pattern?: RegExp;
  allowedValues?: any[];
  customValidator?: (value: any) => boolean;
  sanitize?: boolean;
}

export interface EndpointValidation {
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  queryParams?: ValidationRule[];
  bodyParams?: ValidationRule[];
  headers?: ValidationRule[];
}

export class InputValidationMiddleware {
  private static instance: InputValidationMiddleware;
  private validationRules: Map<string, EndpointValidation> = new Map();
  private schemas: Map<string, Joi.ObjectSchema> = new Map();

  private constructor() {
    this.initializeValidationRules();
    this.compileSchemas();
  }

  public static getInstance(): InputValidationMiddleware {
    if (!InputValidationMiddleware.instance) {
      InputValidationMiddleware.instance = new InputValidationMiddleware();
    }
    return InputValidationMiddleware.instance;
  }

  /**
   * Inicializar reglas de validación para endpoints críticos
   */
  private initializeValidationRules(): void {
    // Validación para ejecución de arbitraje
    this.addValidationRule('/api/execute', 'POST', {
      bodyParams: [
        {
          field: 'opportunityId',
          type: 'string',
          required: true,
          min: 10,
          max: 50,
          pattern: /^[a-zA-Z0-9_-]+$/,
          sanitize: true
        },
        {
          field: 'maxSlippage',
          type: 'number',
          required: false,
          min: 0.1,
          max: 10.0
        },
        {
          field: 'gasPrice',
          type: 'number',
          required: false,
          min: 1000000000, // 1 gwei mínimo
          max: 500000000000 // 500 gwei máximo
        },
        {
          field: 'deadline',
          type: 'number',
          required: false,
          min: Date.now(),
          max: Date.now() + 24 * 60 * 60 * 1000 // Máximo 24 horas
        }
      ],
      headers: [
        {
          field: 'authorization',
          type: 'string',
          required: true,
          pattern: /^Bearer\s[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_.+/=]*$/
        }
      ]
    });

    // Validación para obtener oportunidades
    this.addValidationRule('/api/opportunities', 'GET', {
      queryParams: [
        {
          field: 'status',
          type: 'string',
          required: false,
          allowedValues: ['pending', 'executing', 'executed', 'failed', 'expired'],
          sanitize: true
        },
        {
          field: 'type',
          type: 'string',
          required: false,
          allowedValues: ['simple', 'triangular', 'cross-chain', 'flash-loan'],
          sanitize: true
        },
        {
          field: 'limit',
          type: 'number',
          required: false,
          min: 1,
          max: 100
        },
        {
          field: 'minProfit',
          type: 'number',
          required: false,
          min: 0,
          max: 10000
        }
      ]
    });

    // Validación para configuración del sistema
    this.addValidationRule('/api/config', 'POST', {
      bodyParams: [
        {
          field: 'riskLevel',
          type: 'string',
          required: false,
          allowedValues: ['conservative', 'moderate', 'aggressive'],
          sanitize: true
        },
        {
          field: 'maxPositionSize',
          type: 'number',
          required: false,
          min: 0,
          max: 1000000
        },
        {
          field: 'enabledStrategies',
          type: 'array',
          required: false,
          customValidator: (value: string[]) => {
            const allowedStrategies = ['simple', 'triangular', 'cross-chain', 'flash-loan'];
            return Array.isArray(value) && value.every(s => allowedStrategies.includes(s));
          }
        },
        {
          field: 'slippageTolerance',
          type: 'number',
          required: false,
          min: 0.1,
          max: 5.0
        }
      ]
    });

    // Validación para transacciones blockchain
    this.addValidationRule('/api/transactions', 'POST', {
      bodyParams: [
        {
          field: 'to',
          type: 'ethereum_address',
          required: true,
          sanitize: true
        },
        {
          field: 'value',
          type: 'string',
          required: true,
          pattern: /^[0-9]+$/,
          customValidator: (value: string) => {
            const num = BigInt(value);
            return num >= BigInt(0) && num <= BigInt('10000000000000000000'); // Máximo 10 ETH
          }
        },
        {
          field: 'data',
          type: 'string',
          required: false,
          pattern: /^0x[a-fA-F0-9]*$/,
          max: 10000 // Máximo 10KB de data
        },
        {
          field: 'gasLimit',
          type: 'number',
          required: true,
          min: 21000,
          max: 8000000
        }
      ]
    });

    // Validación para wallet management
    this.addValidationRule('/api/wallet/connect', 'POST', {
      bodyParams: [
        {
          field: 'walletType',
          type: 'string',
          required: true,
          allowedValues: ['metamask', 'ledger', 'trezor', 'walletconnect'],
          sanitize: true
        },
        {
          field: 'address',
          type: 'ethereum_address',
          required: true,
          sanitize: true
        },
        {
          field: 'chainId',
          type: 'number',
          required: true,
          allowedValues: [1, 56, 137, 42161, 10, 250, 43114, 25] // Mainnet chains
        }
      ]
    });

    console.log('✅ Reglas de validación inicializadas para endpoints críticos');
  }

  /**
   * Agregar regla de validación
   */
  private addValidationRule(
    path: string, 
    method: EndpointValidation['method'], 
    validation: Omit<EndpointValidation, 'path' | 'method'>
  ): void {
    const key = `${method}:${path}`;
    this.validationRules.set(key, {
      path,
      method,
      ...validation
    });
  }

  /**
   * Compilar esquemas Joi para mejor performance
   */
  private compileSchemas(): void {
    for (const [key, validation] of this.validationRules) {
      const schema: any = {};

      // Compilar query params
      if (validation.queryParams) {
        schema.query = this.buildJoiSchema(validation.queryParams);
      }

      // Compilar body params
      if (validation.bodyParams) {
        schema.body = this.buildJoiSchema(validation.bodyParams);
      }

      // Compilar headers
      if (validation.headers) {
        schema.headers = this.buildJoiSchema(validation.headers);
      }

      this.schemas.set(key, Joi.object(schema));
    }

    console.log('✅ Esquemas de validación compilados');
  }

  /**
   * Construir esquema Joi desde reglas
   */
  private buildJoiSchema(rules: ValidationRule[]): Joi.ObjectSchema {
    const schemaObj: any = {};

    for (const rule of rules) {
      let validator: any;

      switch (rule.type) {
        case 'string':
          validator = Joi.string();
          if (rule.min) validator = validator.min(rule.min);
          if (rule.max) validator = validator.max(rule.max);
          if (rule.pattern) validator = validator.pattern(rule.pattern);
          if (rule.allowedValues) validator = validator.valid(...rule.allowedValues);
          break;

        case 'number':
          validator = Joi.number();
          if (rule.min !== undefined) validator = validator.min(rule.min);
          if (rule.max !== undefined) validator = validator.max(rule.max);
          if (rule.allowedValues) validator = validator.valid(...rule.allowedValues);
          break;

        case 'boolean':
          validator = Joi.boolean();
          break;

        case 'array':
          validator = Joi.array();
          if (rule.min) validator = validator.min(rule.min);
          if (rule.max) validator = validator.max(rule.max);
          break;

        case 'object':
          validator = Joi.object();
          break;

        case 'ethereum_address':
          validator = Joi.string().pattern(/^0x[a-fA-F0-9]{40}$/);
          break;

        case 'transaction_hash':
          validator = Joi.string().pattern(/^0x[a-fA-F0-9]{64}$/);
          break;

        case 'private_key':
          validator = Joi.string().pattern(/^0x[a-fA-F0-9]{64}$/);
          break;

        default:
          validator = Joi.any();
      }

      // Aplicar requerimiento
      if (rule.required) {
        validator = validator.required();
      } else {
        validator = validator.optional();
      }

      // Aplicar validador personalizado
      if (rule.customValidator) {
        validator = validator.custom((value: any, helpers: any) => {
          if (!rule.customValidator!(value)) {
            return helpers.error('any.invalid');
          }
          return value;
        });
      }

      schemaObj[rule.field] = validator;
    }

    return Joi.object(schemaObj);
  }

  /**
   * Middleware principal de validación
   */
  validate() {
    return async (req: Request, res: Response, next: NextFunction) => {
      try {
        const key = `${req.method}:${req.route?.path || req.path}`;
        const schema = this.schemas.get(key);

        if (!schema) {
          // No hay validación específica para este endpoint
          return next();
        }

        // Preparar datos para validación
        const dataToValidate: any = {};

        if (req.query && Object.keys(req.query).length > 0) {
          dataToValidate.query = req.query;
        }

        if (req.body && Object.keys(req.body).length > 0) {
          dataToValidate.body = req.body;
        }

        if (req.headers) {
          // Solo incluir headers relevantes para validación
          const relevantHeaders: any = {};
          const validation = this.validationRules.get(key);
          
          if (validation?.headers) {
            for (const headerRule of validation.headers) {
              if (req.headers[headerRule.field.toLowerCase()]) {
                relevantHeaders[headerRule.field] = req.headers[headerRule.field.toLowerCase()];
              }
            }
            if (Object.keys(relevantHeaders).length > 0) {
              dataToValidate.headers = relevantHeaders;
            }
          }
        }

        // Validar con Joi
        const { error, value } = schema.validate(dataToValidate, {
          abortEarly: false,
          stripUnknown: true,
          convert: true
        });

        if (error) {
          const validationErrors = error.details.map(detail => ({
            field: detail.path.join('.'),
            message: detail.message,
            value: detail.context?.value
          }));

          console.warn(`⚠️ Validación fallida en ${req.method} ${req.path}:`, validationErrors);

          return res.status(400).json({
            error: {
              code: 'VALIDATION_ERROR',
              message: 'Datos de entrada inválidos',
              details: validationErrors,
              timestamp: new Date().toISOString()
            }
          });
        }

        // Sanitizar datos si está habilitado
        const validation = this.validationRules.get(key);
        if (validation) {
          await this.sanitizeRequest(req, validation);
        }

        // Aplicar valores validados
        if (value.query) req.query = value.query;
        if (value.body) req.body = value.body;

        next();

      } catch (error) {
        console.error('Error en middleware de validación:', error);
        
        return res.status(500).json({
          error: {
            code: 'VALIDATION_MIDDLEWARE_ERROR',
            message: 'Error interno de validación',
            timestamp: new Date().toISOString()
          }
        });
      }
    };
  }

  /**
   * Sanitizar request según reglas
   */
  private async sanitizeRequest(req: Request, validation: EndpointValidation): Promise<void> {
    // Sanitizar query params
    if (validation.queryParams && req.query) {
      for (const rule of validation.queryParams) {
        if (rule.sanitize && req.query[rule.field]) {
          req.query[rule.field] = SecurityUtils.sanitizeInput(req.query[rule.field] as string);
        }
      }
    }

    // Sanitizar body params
    if (validation.bodyParams && req.body) {
      for (const rule of validation.bodyParams) {
        if (rule.sanitize && req.body[rule.field] !== undefined) {
          if (typeof req.body[rule.field] === 'string') {
            req.body[rule.field] = SecurityUtils.sanitizeInput(req.body[rule.field]);
          } else if (typeof req.body[rule.field] === 'object') {
            req.body[rule.field] = SecurityUtils.deepSanitizeObject(req.body[rule.field]);
          }
        }
      }
    }
  }

  /**
   * Validar dirección Ethereum
   */
  static validateEthereumAddress(address: string): boolean {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  }

  /**
   * Validar hash de transacción
   */
  static validateTransactionHash(hash: string): boolean {
    return /^0x[a-fA-F0-9]{64}$/.test(hash);
  }

  /**
   * Validar cantidad de token (string numérico)
   */
  static validateTokenAmount(amount: string): boolean {
    try {
      const num = BigInt(amount);
      return num >= BigInt(0);
    } catch {
      return false;
    }
  }

  /**
   * Validar gas price
   */
  static validateGasPrice(gasPrice: number): boolean {
    return gasPrice >= 1000000000 && gasPrice <= 1000000000000; // 1 gwei a 1000 gwei
  }

  /**
   * Validar slippage
   */
  static validateSlippage(slippage: number): boolean {
    return slippage >= 0.1 && slippage <= 10.0; // 0.1% a 10%
  }

  /**
   * Middleware específico para endpoints de arbitraje
   */
  arbitrageValidation() {
    return this.validate();
  }

  /**
   * Middleware específico para endpoints de wallet
   */
  walletValidation() {
    return this.validate();
  }

  /**
   * Middleware específico para endpoints de configuración
   */
  configValidation() {
    return this.validate();
  }

  /**
   * Obtener estadísticas de validación
   */
  getValidationStats(): {
    totalRules: number;
    endpointsProtected: number;
    validationRules: string[];
  } {
    return {
      totalRules: this.validationRules.size,
      endpointsProtected: this.schemas.size,
      validationRules: Array.from(this.validationRules.keys())
    };
  }
}

// Export singleton instance
export const inputValidationMiddleware = InputValidationMiddleware.getInstance();
export default InputValidationMiddleware;
