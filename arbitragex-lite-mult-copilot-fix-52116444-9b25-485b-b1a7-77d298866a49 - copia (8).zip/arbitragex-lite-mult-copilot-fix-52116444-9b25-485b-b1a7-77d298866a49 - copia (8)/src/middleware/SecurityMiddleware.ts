import { Request, Response, NextFunction } from 'express'
import { SecurityUtils } from '../utils/SecurityUtils'

/**
 * @title SecurityMiddleware
 * @description Middleware de seguridad para rate limiting, CSRF y otras protecciones
 * @author ArbitrageX Security Team 2025
 */
export interface RateLimitConfig {
  windowMs: number
  maxRequests: number
  message: string
  statusCode: number
}

export interface CSRFConfig {
  secret: string
  tokenLength: number
  cookieName: string
  headerName: string
}

export class SecurityMiddleware {
  private static instance: SecurityMiddleware
  private rateLimitStore: Map<string, { count: number; resetTime: number }> = new Map()
  private csrfTokens: Map<string, { token: string; expires: number }> = new Map()

  private constructor() {}

  /**
   * Obtener instancia singleton
   */
  public static getInstance(): SecurityMiddleware {
    if (!SecurityMiddleware.instance) {
      SecurityMiddleware.instance = new SecurityMiddleware()
    }
    return SecurityMiddleware.instance
  }

  /**
   * Rate Limiting Middleware
   */
  public rateLimit(config: RateLimitConfig = {
    windowMs: 15 * 60 * 1000, // 15 minutos
    maxRequests: 100,
    message: 'Demasiadas solicitudes, intente más tarde',
    statusCode: 429
  }) {
    return (req: Request, res: Response, next: NextFunction) => {
      const key = this.getClientKey(req)
      const now = Date.now()
      
      // Limpiar entradas expiradas
      this.cleanupRateLimitStore(now)
      
      const clientData = this.rateLimitStore.get(key)
      
      if (!clientData || now > clientData.resetTime) {
        // Primera solicitud o ventana expirada
        this.rateLimitStore.set(key, {
          count: 1,
          resetTime: now + config.windowMs
        })
        next()
      } else if (clientData.count < config.maxRequests) {
        // Incrementar contador
        clientData.count++
        next()
      } else {
        // Límite excedido
        res.status(config.statusCode).json({
          error: 'Rate Limit Exceeded',
          message: config.message,
          retryAfter: Math.ceil((clientData.resetTime - now) / 1000)
        })
      }
    }
  }

  /**
   * CSRF Protection Middleware
   */
  public csrfProtection(config: CSRFConfig = {
    secret: process.env.CSRF_SECRET || 'arbitragex-csrf-secret-2025',
    tokenLength: 32,
    cookieName: 'csrf-token',
    headerName: 'x-csrf-token'
  }) {
    return (req: Request, res: Response, next: NextFunction) => {
      // Solo aplicar a métodos que modifican datos
      if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
        return next()
      }

      const sessionId = this.getSessionId(req)
      const token = req.headers[config.headerName] as string || req.body._csrf
      const storedToken = this.getStoredCSRFToken(sessionId)

      if (!token || !storedToken || token !== storedToken.token) {
        return res.status(403).json({
          error: 'CSRF Token Invalid',
          message: 'Token CSRF inválido o faltante'
        })
      }

      // Token válido, continuar
      next()
    }
  }

  /**
   * Generar token CSRF
   */
  public generateCSRFToken(sessionId: string, expiresIn: number = 3600000): string {
    const token = SecurityUtils.generateCSRFToken()
    const expires = Date.now() + expiresIn

    this.csrfTokens.set(sessionId, { token, expires })

    return token
  }

  /**
   * Input Sanitization Middleware
   */
  public sanitizeInput() {
    return (req: Request, res: Response, next: NextFunction) => {
      // Sanitizar query parameters
      if (req.query) {
        req.query = SecurityUtils.sanitizeURLParams(req.query as Record<string, string>)
      }

      // Sanitizar body
      if (req.body) {
        req.body = SecurityUtils.deepSanitizeObject(req.body)
      }

      // Sanitizar headers
      if (req.headers) {
        req.headers = SecurityUtils.sanitizeHeaders(req.headers as Record<string, string>)
      }

      next()
    }
  }

  /**
   * Security Headers Middleware
   */
  public securityHeaders() {
    return (req: Request, res: Response, next: NextFunction) => {
      const isProduction = process.env.NODE_ENV === 'production';
      
      // Content Security Policy - MÁS RESTRICTIVO
      const cspDirectives = [
        "default-src 'self'",
        // Scripts: Solo mismo origen y CDNs específicos confiables
        "script-src 'self' 'nonce-" + this.generateNonce() + "' https://cdn.jsdelivr.net",
        // Estilos: Solo mismo origen y Google Fonts
        "style-src 'self' 'nonce-" + this.generateNonce() + "' https://fonts.googleapis.com",
        // Imágenes: Mismo origen, data URIs y HTTPS confiables
        "img-src 'self' data: https://cdn.jsdelivr.net https://images.unsplash.com",
        // Fuentes: Solo mismo origen y Google Fonts
        "font-src 'self' https://fonts.gstatic.com data:",
        // Conexiones: Solo HTTPS y WebSockets seguros
        "connect-src 'self' https: wss:",
        // Objetos y embeds: Ninguno
        "object-src 'none'",
        "embed-src 'none'",
        // Media: Solo mismo origen
        "media-src 'self'",
        // Workers: Solo mismo origen
        "worker-src 'self'",
        "child-src 'self'",
        // Frames: Ninguno
        "frame-src 'none'",
        "frame-ancestors 'none'",
        // Base URI: Solo mismo origen
        "base-uri 'self'",
        // Forms: Solo mismo origen
        "form-action 'self'",
        // Manifesto: Solo mismo origen
        "manifest-src 'self'"
      ];

      // Agregar directivas adicionales en producción
      if (isProduction) {
        cspDirectives.push("upgrade-insecure-requests");
        cspDirectives.push("block-all-mixed-content");
        cspDirectives.push("require-trusted-types-for 'script'");
      }

      res.setHeader('Content-Security-Policy', cspDirectives.join('; '));

      // XSS Protection (aunque es legacy, algunos navegadores lo respetan)
      res.setHeader('X-XSS-Protection', '0'); // Deshabilitado para evitar bypasses

      // Prevent MIME type sniffing
      res.setHeader('X-Content-Type-Options', 'nosniff')

      // Prevent clickjacking
      res.setHeader('X-Frame-Options', 'DENY')

      // Referrer Policy - MÁS RESTRICTIVO
      res.setHeader('Referrer-Policy', 'no-referrer')

      // Permissions Policy - MÁS COMPLETO
      res.setHeader('Permissions-Policy', [
        'accelerometer=()',
        'ambient-light-sensor=()',
        'autoplay=()',
        'battery=()',
        'camera=()',
        'cross-origin-isolated=()',
        'display-capture=()',
        'document-domain=()',
        'encrypted-media=()',
        'execution-while-not-rendered=()',
        'execution-while-out-of-viewport=()',
        'fullscreen=(self)',
        'geolocation=()',
        'gyroscope=()',
        'keyboard-map=()',
        'magnetometer=()',
        'microphone=()',
        'midi=()',
        'navigation-override=()',
        'payment=()',
        'picture-in-picture=()',
        'publickey-credentials-get=()',
        'screen-wake-lock=()',
        'sync-xhr=()',
        'usb=()',
        'web-share=()',
        'xr-spatial-tracking=()'
      ].join(', '))

      // Cross-Origin Policies
      res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp')
      res.setHeader('Cross-Origin-Opener-Policy', 'same-origin')
      res.setHeader('Cross-Origin-Resource-Policy', 'same-origin')

      // HSTS (solo en producción)
      if (isProduction) {
        res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload')
      }

      // Ocultar información del servidor
      res.removeHeader('X-Powered-By')
      res.setHeader('Server', 'ArbitrageX-Secure')

      // Cache Control para contenido sensible
      if (req.path.includes('/api/')) {
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private')
        res.setHeader('Pragma', 'no-cache')
        res.setHeader('Expires', '0')
      }

      next()
    }
  }

  /**
   * Generar nonce para CSP
   */
  private generateNonce(): string {
    return require('crypto').randomBytes(16).toString('base64')
  }

  /**
   * SQL Injection Protection Middleware
   */
  public sqlInjectionProtection() {
    return (req: Request, res: Response, next: NextFunction) => {
      const sqlPatterns = [
        /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT)\b)/i,
        /(\b(OR|AND)\b\s+\d+\s*=\s*\d+)/i,
        /(\b(OR|AND)\b\s+['"]?\w+['"]?\s*=\s*['"]?\w+['"]?)/i,
        /(--|\/\*|\*\/|;)/,
        /(\b(WAITFOR|DELAY)\b)/i
      ]

      const checkValue = (value: any): boolean => {
        if (typeof value === 'string') {
          return sqlPatterns.some(pattern => pattern.test(value))
        }
        if (typeof value === 'object' && value !== null) {
          return Object.values(value).some(checkValue)
        }
        return false
      }

      const hasSQLInjection = checkValue(req.query) || checkValue(req.body) || checkValue(req.params)

      if (hasSQLInjection) {
        SecurityUtils.logSecurityEvent('sql_injection_attempt', {
          ip: req.ip,
          userAgent: req.get('User-Agent'),
          url: req.url,
          method: req.method
        })

        return res.status(403).json({
          error: 'SQL Injection Detected',
          message: 'Intento de inyección SQL detectado'
        })
      }

      next()
    }
  }

  /**
   * File Upload Security Middleware
   */
  public fileUploadSecurity() {
    return (req: Request, res: Response, next: NextFunction) => {
      if (!req.files) {
        return next()
      }

      const files = Array.isArray(req.files) ? req.files : Object.values(req.files)
      
      for (const file of files) {
        const validation = SecurityUtils.validateFile(file)
        
        if (!validation.isValid) {
          SecurityUtils.logSecurityEvent('invalid_file_upload', {
            ip: req.ip,
            fileName: file.name,
            fileSize: file.size,
            fileType: file.type,
            reason: validation.reason
          })

          return res.status(400).json({
            error: 'Invalid File',
            message: validation.reason
          })
        }
      }

      next()
    }
  }

  /**
   * Authentication Check Middleware
   */
  public requireAuth() {
    return (req: Request, res: Response, next: NextFunction) => {
      const token = req.headers.authorization?.replace('Bearer ', '')
      
      if (!token) {
        return res.status(401).json({
          error: 'Authentication Required',
          message: 'Token de autenticación requerido'
        })
      }

      // Aquí se validaría el token JWT
      // Por ahora solo verificamos que existe
      try {
        // validateJWT(token)
        next()
      } catch (error) {
        return res.status(401).json({
          error: 'Invalid Token',
          message: 'Token de autenticación inválido'
        })
      }
    }
  }

  /**
   * Role-based Access Control Middleware
   */
  public requireRole(roles: string[]) {
    return (req: Request, res: Response, next: NextFunction) => {
      const userRole = req.headers['x-user-role'] as string
      
      if (!userRole || !roles.includes(userRole)) {
        return res.status(403).json({
          error: 'Insufficient Permissions',
          message: 'Permisos insuficientes para acceder a este recurso'
        })
      }

      next()
    }
  }

  /**
   * Request Logging Middleware
   */
  public requestLogging() {
    return (req: Request, res: Response, next: NextFunction) => {
      const startTime = Date.now()
      
      res.on('finish', () => {
        const duration = Date.now() - startTime
        const logData = {
          timestamp: new Date().toISOString(),
          method: req.method,
          url: req.url,
          statusCode: res.statusCode,
          duration,
          ip: req.ip,
          userAgent: req.get('User-Agent'),
          contentLength: res.get('Content-Length')
        }

        // Log según el status code
        if (res.statusCode >= 400) {
          console.error('Request Error:', logData)
        } else {
          console.log('Request:', logData)
        }
      })

      next()
    }
  }

  /**
   * Error Handling Middleware
   */
  public errorHandler() {
    return (err: Error, req: Request, res: Response, next: NextFunction) => {
      console.error('Error:', err)

      // Log del error
      SecurityUtils.logSecurityEvent('application_error', {
        error: err.message,
        stack: err.stack,
        ip: req.ip,
        url: req.url,
        method: req.method
      })

      // No exponer detalles del error en producción
      const message = process.env.NODE_ENV === 'production' 
        ? 'Error interno del servidor'
        : err.message

      res.status(500).json({
        error: 'Internal Server Error',
        message
      })
    }
  }

  /**
   * Obtener clave del cliente para rate limiting
   */
  private getClientKey(req: Request): string {
    return req.ip || req.connection.remoteAddress || 'unknown'
  }

  /**
   * Obtener ID de sesión
   */
  private getSessionId(req: Request): string {
    return req.session?.id || req.ip || 'anonymous'
  }

  /**
   * Limpiar store de rate limiting
   */
  private cleanupRateLimitStore(now: number): void {
    for (const [key, data] of this.rateLimitStore.entries()) {
      if (now > data.resetTime) {
        this.rateLimitStore.delete(key)
      }
    }
  }

  /**
   * Obtener token CSRF almacenado
   */
  private getStoredCSRFToken(sessionId: string): { token: string; expires: number } | undefined {
    const stored = this.csrfTokens.get(sessionId)
    
    if (stored && Date.now() < stored.expires) {
      return stored
    }
    
    if (stored) {
      this.csrfTokens.delete(sessionId)
    }
    
    return undefined
  }

  /**
   * Limpiar tokens CSRF expirados
   */
  public cleanupExpiredCSRFTokens(): void {
    const now = Date.now()
    
    for (const [sessionId, data] of this.csrfTokens.entries()) {
      if (now > data.expires) {
        this.csrfTokens.delete(sessionId)
      }
    }
  }

  /**
   * Obtener estadísticas de seguridad
   */
  public getSecurityStats(): {
    rateLimitEntries: number
    csrfTokens: number
    activeSessions: number
  } {
    return {
      rateLimitEntries: this.rateLimitStore.size,
      csrfTokens: this.csrfTokens.size,
      activeSessions: this.csrfTokens.size
    }
  }
} 