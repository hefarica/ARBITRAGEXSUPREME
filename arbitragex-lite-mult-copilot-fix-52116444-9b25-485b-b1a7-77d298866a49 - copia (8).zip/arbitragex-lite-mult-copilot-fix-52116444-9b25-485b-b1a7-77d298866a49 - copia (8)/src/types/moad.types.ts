/**
 * MOAD (Módulo de Oportunidades de Arbitraje DeFi) - Types
 * Sistema completo de tipos para detección y ejecución de arbitraje
 */

// ============================================================================
// CORE TYPES - Tipos fundamentales del sistema
// ============================================================================

export interface Opportunity {
  id: string
  strategyId: string
  timestamp: number
  
  // Información de tokens
  tokens: {
    tokenIn: string
    tokenOut: string
    amountIn: number
    amountOut: number
    decimalsIn?: number
    decimalsOut?: number
  }
  
  // Información de ruta de ejecución
  path: {
    dexs: string[]
    pools: string[]
    fees: number[]
    route?: string[]
  }
  
  // Información de blockchain y red
  blockchain: string
  chainId?: number
  
  // Métricas financieras
  estimatedProfit: number
  estimatedGas: number
  profitMargin: number
  netProfitUSD: number
  roi: number
  
  // Evaluación de riesgos
  riskScore: number
  confidence: number
  liquidityRisk: number
  slippageRisk: number
  gasRisk: number
  
  // Información de ejecución
  executionTime: number
  maxSlippage: number
  gasLimit: number
  gasPrice: number
  
  // Estado y características
  status: OpportunityStatus
  mevProtection: boolean
  flashLoanRequired: boolean
  crossChain: boolean
  atomicExecution: boolean
  
  // Metadata adicional
  detectedAt: number
  expiresAt: number
  priority: OpportunityPriority
  tags: string[]
}

export type OpportunityStatus = 
  | 'pending'
  | 'validated'
  | 'executing'
  | 'completed'
  | 'failed'
  | 'expired'
  | 'cancelled'

export type OpportunityPriority = 'low' | 'medium' | 'high' | 'critical'

// ============================================================================
// STRATEGY TYPES - Tipos de estrategias de arbitraje
// ============================================================================

export interface StrategyInfo {
  id: string
  label: string
  description: string
  category: StrategyCategory
  roi2025: number
  complexity: StrategyComplexity
  riskLevel: StrategyRiskLevel
  
  // Métricas de performance
  avgProfitPercentage: number
  executionTimeMs: number
  capitalRequirement: number
  successRate: number
  
  // Requerimientos técnicos
  requirements: StrategyRequirements
  supportedBlockchains: string[]
  technicalDetails: TechnicalDetails
  
  // Configuración específica
  parameters: StrategyParameters
  constraints: StrategyConstraints
}

export type StrategyCategory = 
  | 'cross-chain'
  | 'flash-loan'
  | 'cross-dex'
  | 'intra-dex'
  | 'multi-hop'
  | 'basic'
  | 'mev-protection'

export type StrategyComplexity = 'low' | 'medium' | 'high' | 'expert'
export type StrategyRiskLevel = 'low' | 'medium' | 'high'

export interface StrategyRequirements {
  flashLoanAvailable?: boolean
  crossChain?: boolean
  multiDex?: boolean
  atomicSwap?: boolean
  advancedRouting?: boolean
  mevProtection?: boolean
  minLiquidity?: number
  maxSlippage?: number
}

export interface TechnicalDetails {
  gasUsage: 'low' | 'medium' | 'high'
  mevVulnerability: 'low' | 'medium' | 'high'
  liquidityDependency: 'low' | 'medium' | 'high'
  latencyRequirement: 'low' | 'medium' | 'high'
  complexityScore: number
}

export interface StrategyParameters {
  maxGasPrice: number
  minProfitUSD: number
  maxSlippage: number
  timeoutMs: number
  retryAttempts: number
  priorityFee: number
}

export interface StrategyConstraints {
  minLiquidityUSD: number
  maxPositionSize: number
  blacklistedTokens: string[]
  allowedDEXs: string[]
  timeRestrictions?: TimeRestriction[]
}

export interface TimeRestriction {
  start: string // HH:MM format
  end: string   // HH:MM format
  timezone: string
  reason: string
}

// ============================================================================
// EXECUTION TYPES - Tipos para ejecución de operaciones
// ============================================================================

export interface ExecutionRequest {
  opportunityId: string
  mode: ExecutionMode
  parameters: ExecutionParameters
  approvals: ExecutionApproval[]
  constraints: ExecutionConstraints
}

export type ExecutionMode = 'manual' | 'semi-automatic' | 'automatic'

export interface ExecutionParameters {
  slippageLimit: number
  gasLimit: number
  gasPrice: number
  deadline: number
  mevProtection: boolean
  flashLoanProvider?: string
  bridgeProvider?: string
}

export interface ExecutionApproval {
  step: string
  approved: boolean
  approvedBy: string
  timestamp: number
  signature?: string
}

export interface ExecutionConstraints {
  maxLossPercent: number
  timeoutSeconds: number
  requireConfirmation: boolean
  allowPartialExecution: boolean
}

export interface ExecutionResult {
  opportunityId: string
  success: boolean
  txHash?: string
  actualProfit?: number
  actualGasUsed?: number
  executionTime: number
  errors?: ExecutionError[]
  metadata: ExecutionMetadata
}

export interface ExecutionError {
  code: string
  message: string
  severity: 'low' | 'medium' | 'high'
  step: string
  timestamp: number
}

export interface ExecutionMetadata {
  startTime: number
  endTime: number
  steps: ExecutionStep[]
  gasTracker: GasTracker
  slippageTracker: SlippageTracker
}

export interface ExecutionStep {
  name: string
  status: 'pending' | 'executing' | 'completed' | 'failed'
  startTime: number
  endTime?: number
  txHash?: string
  gasUsed?: number
  result?: any
}

export interface GasTracker {
  estimated: number
  actual: number
  savedAmount: number
  optimizationUsed: boolean
}

export interface SlippageTracker {
  expected: number
  actual: number
  tolerance: number
  withinLimits: boolean
}

// ============================================================================
// RISK ASSESSMENT TYPES - Tipos para evaluación de riesgos
// ============================================================================

export interface RiskAssessment {
  opportunityId: string
  overallScore: number
  riskFactors: RiskFactor[]
  recommendations: RiskRecommendation[]
  limits: RiskLimits
  timestamp: number
}

export interface RiskFactor {
  type: RiskType
  score: number
  weight: number
  description: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  mitigation?: string
}

export type RiskType = 
  | 'liquidity'
  | 'slippage'
  | 'gas'
  | 'mev'
  | 'bridge'
  | 'smart-contract'
  | 'market'
  | 'timing'
  | 'counterparty'

export interface RiskRecommendation {
  type: 'reduce' | 'avoid' | 'monitor' | 'approve'
  reason: string
  action: string
  priority: 'low' | 'medium' | 'high'
}

export interface RiskLimits {
  maxRiskScore: number
  maxPositionSize: number
  maxSlippage: number
  maxGasPrice: number
  stopLossPercent: number
}

// ============================================================================
// LLM AGENT TYPES - Tipos para el agente de IA
// ============================================================================

export interface LLMAgent {
  id: string
  name: string
  version: string
  objective: ObjectiveFunction
  capabilities: AgentCapability[]
  constraints: AgentConstraint[]
  learningData: LearningData
}

export interface ObjectiveFunction {
  targetDailyProfitUSD: number
  maxDailyLossUSD: number
  riskTolerance: number
  timeHorizon: 'short' | 'medium' | 'long'
  priorities: ObjectivePriority[]
}

export interface ObjectivePriority {
  metric: 'profit' | 'risk' | 'volume' | 'success-rate'
  weight: number
  target: number
}

export interface AgentCapability {
  name: string
  description: string
  enabled: boolean
  confidence: number
  lastUsed?: number
}

export interface AgentConstraint {
  type: 'financial' | 'time' | 'risk' | 'regulatory'
  description: string
  value: any
  enforced: boolean
}

export interface LearningData {
  totalOperations: number
  successfulOperations: number
  totalProfitUSD: number
  averageROI: number
  bestStrategy: string
  learningRate: number
  lastUpdate: number
}

// ============================================================================
// MONITORING TYPES - Tipos para monitoreo y métricas
// ============================================================================

export interface SystemMetrics {
  timestamp: number
  uptime: number
  
  // Performance metrics
  performance: {
    avgResponseTime: number
    throughput: number
    errorRate: number
    latency: LatencyMetrics
  }
  
  // Financial metrics
  financial: {
    dailyProfit: number
    weeklyProfit: number
    monthlyProfit: number
    totalROI: number
    successRate: number
    avgProfitPerTrade: number
  }
  
  // System health
  health: {
    rpcConnections: ConnectionStatus[]
    databaseStatus: 'healthy' | 'degraded' | 'down'
    llmAgentStatus: 'active' | 'idle' | 'error'
    opportunityDetection: 'active' | 'degraded' | 'stopped'
  }
}

export interface LatencyMetrics {
  opportunityDetection: number
  riskAssessment: number
  execution: number
  blockchainRPC: number
}

export interface ConnectionStatus {
  blockchain: string
  status: 'connected' | 'degraded' | 'disconnected'
  latency: number
  errorRate: number
  lastCheck: number
}

// ============================================================================
// CONFIGURATION TYPES - Tipos para configuración del sistema
// ============================================================================

export interface MOADConfig {
  scanner: ScannerConfig
  execution: ExecutionConfig
  risk: RiskConfig
  llm: LLMConfig
  monitoring: DesktopingConfig
}

export interface ScannerConfig {
  enabledBlockchains: string[]
  enabledDEXs: string[]
  scanIntervalMs: number
  maxOpportunities: number
  minProfitUSD: number
  enabledStrategies: string[]
}

export interface ExecutionConfig {
  defaultMode: ExecutionMode
  autoExecutionLimits: {
    maxDailySpeakerHigh: number
    maxPositionSize: number
    maxRiskScore: number
  }
  mevProtection: {
    enabled: boolean
    provider: 'flashbots' | 'eden' | 'custom'
    maxPriorityFee: number
  }
}

export interface RiskConfig {
  globalLimits: RiskLimits
  strategyLimits: Record<string, RiskLimits>
  alertThresholds: {
    dailyLoss: number
    consecutiveFailures: number
    highRiskScore: number
  }
}

export interface LLMConfig {
  provider: 'openai' | 'anthropic' | 'local'
  model: string
  apiKey: string
  maxTokens: number
  temperature: number
  objective: ObjectiveFunction
}

export interface DesktopingConfig {
  metricsInterval: number
  alertChannels: AlertChannel[]
  retention: {
    metricsData: number // days
    opportunityData: number // days
    executionLogs: number // days
  }
}

export interface AlertChannel {
  type: 'email' | 'telegram' | 'discord' | 'webhook'
  config: Record<string, any>
  enabled: boolean
  severity: 'low' | 'medium' | 'high' | 'critical'
}

// ============================================================================
// API TYPES - Tipos para APIs y comunicación
// ============================================================================

export interface APIResponse<T = any> {
  success: boolean
  data?: T
  error?: APIError
  timestamp: number
  requestId: string
}

export interface APIError {
  code: string
  message: string
  details?: any
  stack?: string
}

// Query parameters for opportunities endpoint
export interface OpportunityQuery {
  strategy?: string
  blockchain?: string
  minProfit?: number
  maxRisk?: number
  status?: OpportunityStatus
  limit?: number
  offset?: number
  sortBy?: 'profit' | 'risk' | 'time'
  sortOrder?: 'asc' | 'desc'
}

// Batch execution request
export interface BatchExecutionRequest {
  opportunityIds: string[]
  mode: ExecutionMode
  parameters: ExecutionParameters
}

// ============================================================================
// EVENTS TYPES - Tipos para eventos del sistema
// ============================================================================

export interface SystemEvent {
  id: string
  type: EventType
  timestamp: number
  source: string
  data: any
  severity: 'info' | 'warning' | 'error' | 'critical'
}

export type EventType = 
  | 'opportunity-detected'
  | 'opportunity-executed'
  | 'execution-failed'
  | 'risk-limit-exceeded'
  | 'system-error'
  | 'llm-decision'
  | 'strategy-updated'
  | 'config-changed'

// ============================================================================
// UTILITY TYPES - Tipos de utilidad
// ============================================================================

export type Timestamp = number
export type Address = string
export type TxHash = string
export type ChainId = number

export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  pageSize: number
  hasNext: boolean
  hasPrev: boolean
}

export interface TimeRange {
  start: Timestamp
  end: Timestamp
}

export interface FunnelOptions {
  strategies: string[]
  blockchains: string[]
  riskLevels: StrategyRiskLevel[]
  complexities: StrategyComplexity[]
}

// ============================================================================
// VALIDATION SCHEMAS - Esquemas de validación
// ============================================================================

export interface ValidationSchema {
  opportunity: OpportunityValidation
  execution: ExecutionValidation
  risk: RiskValidation
}

export interface OpportunityValidation {
  minProfitUSD: number
  maxRiskScore: number
  maxExecutionTime: number
  requiredConfidence: number
}

export interface ExecutionValidation {
  maxSlippage: number
  maxGasPrice: number
  timeoutSeconds: number
  requireApproval: boolean
}

export interface RiskValidation {
  maxRiskScore: number
  maxPositionSize: number
  maxDailyLoss: number
  stopLossPercent: number
}