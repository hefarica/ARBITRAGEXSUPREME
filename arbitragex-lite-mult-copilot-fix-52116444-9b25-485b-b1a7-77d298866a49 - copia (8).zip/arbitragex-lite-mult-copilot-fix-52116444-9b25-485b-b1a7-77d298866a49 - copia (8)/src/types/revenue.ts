// Tipos para el sistema de generación de ingresos

export interface RevenueStrategy {
  id: string;
  label: string;
  description: string;
  roi2025: number; // Score para ordenamiento por rentabilidad
  riskLevel: 'low' | 'medium' | 'high' | 'extreme';
  estimatedLatency: number; // ms
  dexes: string[];
}

export interface ArbitrageOpportunity {
  id: string;
  tokenIn: string;
  tokenOut: string;
  amountIn: string;
  expectedProfit: number; // USD
  profitPercentage: number;
  gasEstimate: number;
  riskScore: number; // 0-100
  dexPath: string[];
  chains: string[];
  estimatedDuration: number; // ms
  liquidity: number;
  priceImpact: number;
  confidence: number; // 0-1
  timestamp: number;
}

export interface HFTMetrics {
  averageLatency: number;
  orderbookDepth: number;
  activeStrategies: string[];
  averageProfit: number;
}

export interface ExecutionResult {
  success: boolean;
  transactionHash?: string;
  error?: string;
  gasUsed?: number;
  actualProfit?: number;
}

export type LEDStatus = 'success' | 'error' | 'warning' | 'idle';

export interface NotificationData {
  type: 'profit' | 'error' | 'warning' | 'info';
  message: string;
  timestamp: number;
  data?: any;
}
 




























