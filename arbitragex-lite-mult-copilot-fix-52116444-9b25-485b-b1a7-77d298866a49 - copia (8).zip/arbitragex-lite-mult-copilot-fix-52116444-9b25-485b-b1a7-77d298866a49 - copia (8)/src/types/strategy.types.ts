// 🏗️ TIPOS DE ESTRATEGIAS - Inspirado en Uniswap V4 + Balancer V2
// Definición completa de tipos para estrategias de arbitraje

export interface StrategyInfo {
  id: string
  label: string
  description: string
  roi2025: number  // Score para ordenar por ROI estimado 2025
  riskLevel: 'low' | 'medium' | 'high' | 'extreme'
  complexity: 'simple' | 'intermediate' | 'advanced' | 'expert'
  requirements: {
    minCapital: number  // USD
    maxGasPrice: number  // Gwei
    blockchains: string[]
    timeframe: string  // '1m', '5m', '1h', etc.
  }
  metrics: {
    avgProfit: number  // %
    successRate: number  // %
    avgExecutionTime: number  // seconds
    gasEfficiency: number  // score 1-10
  }
  enabled: boolean
  category: 'flash-loan' | 'cross-chain' | 'cross-dex' | 'intra-dex' | 'mev-protection'
}

export interface Opportunity {
  id: string
  strategyId: string
  timestamp: number
  tokens: {
    tokenIn: string
    tokenOut: string
    amountIn: number
    amountOut: number
  }
  path: {
    dexs: string[]
    pools: string[]
    fees: number[]
  }
  blockchain: string
  estimatedProfit: number  // USD
  estimatedGas: number     // Gwei
  profitMargin: number     // %
  riskScore: number        // 1-10 (1 = low risk, 10 = extreme risk)
  confidence: number       // 0-1 (0 = low confidence, 1 = high confidence)
  executionTime: number    // estimated seconds
  status: 'pending' | 'executing' | 'completed' | 'failed' | 'expired'
  mevProtection: boolean
  flashLoanRequired: boolean
  crossChain: boolean
}

export interface ExecutionResult {
  opportunityId: string
  txHash?: string
  status: 'success' | 'failed' | 'pending'
  actualProfit?: number
  actualGas?: number
  executionTime?: number
  error?: string
  blockNumber?: number
  timestamp: number
}

export interface StrategyConfig {
  strategyId: string
  enabled: boolean
  autoExecute: boolean
  parameters: {
    minProfitUSD: number
    maxRiskScore: number
    maxGasPrice: number
    maxSlippage: number
    minConfidence: number
    maxExecutionTime: number
  }
  limits: {
    dailyLimit: number
    maxConcurrentTrades: number
    cooldownPeriod: number  // seconds
  }
  notifications: {
    telegram: boolean
    discord: boolean
    email: boolean
    webhook: boolean
  }
}

export interface EngineStatus {
  isRunning: boolean
  mode: 'manual' | 'auto' | 'simulation'
  totalOpportunities: number
  executedTrades: number
  totalProfit: number
  successRate: number
  currentLatency: number  // milliseconds
  lastUpdate: number
  errors: string[]
  warnings: string[]
}

// HFT Engine specific types
export interface HFTMetrics {
  latency: {
    orderToExecution: number  // microseconds
    priceUpdate: number       // microseconds
    networkRoundTrip: number  // microseconds
  }
  throughput: {
    ordersPerSecond: number
    updatesPerSecond: number
    executionsPerSecond: number
  }
  performance: {
    fillRate: number          // %
    slippage: number          // %
    rejectionRate: number     // %
  }
  hardware: {
    cpuUsage: number          // %
    memoryUsage: number       // %
    networkBandwidth: number  // Mbps
  }
}

export interface ArbitrageMetrics {
  opportunities: {
    total: number
    profitable: number
    executed: number
    missed: number
  }
  profitability: {
    totalProfit: number       // USD
    avgProfitPerTrade: number // USD
    maxProfit: number         // USD
    minProfit: number         // USD
    profitMargin: number      // %
  }
  risk: {
    maxDrawdown: number       // %
    volatility: number        // %
    sharpeRatio: number
    sortinoRatio: number
  }
  execution: {
    avgExecutionTime: number  // seconds
    successRate: number       // %
    gasEfficiency: number     // score 1-10
    mevProtection: number     // %
  }
}

// Real-time data subscription types
export interface PriceUpdate {
  symbol: string
  price: number
  change24h: number
  volume24h: number
  timestamp: number
  source: string
}

export interface MarketDepth {
  symbol: string
  bids: Array<[number, number]>  // [price, quantity]
  asks: Array<[number, number]>  // [price, quantity]
  timestamp: number
}

export interface GasTracker {
  network: string
  gasPrice: {
    slow: number
    standard: number
    fast: number
    instant: number
  }
  timestamp: number
}