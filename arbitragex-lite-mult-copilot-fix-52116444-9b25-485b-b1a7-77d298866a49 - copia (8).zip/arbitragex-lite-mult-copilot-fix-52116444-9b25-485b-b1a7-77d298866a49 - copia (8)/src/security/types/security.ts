// Security types and interfaces for ArbitrageX Pro 2 Zero-Trust Architecture

export interface SecurityModule {
  initialize(config: any): Promise<void>
  performSelfAudit(): Promise<ModuleAuditResult>
  validateModule(): Promise<boolean>
  getModuleName(): string
  getModuleVersion(): string
  isHealthy(): Promise<boolean>
}

export interface ModuleAuditResult {
  moduleName: string
  timestamp: number
  passed: boolean
  failures: SecurityFailure[]
  warnings: SecurityWarning[]
  recommendations: SecurityRecommendation[]
  performance: {
    responseTime: number
    memoryUsage: number
    cpuUsage: number
  }
}

export interface SecurityAuditResult {
  timestamp: number
  passed: boolean
  criticalFailures: SecurityFailure[]
  warnings: SecurityWarning[]
  recommendations: SecurityRecommendation[]
  moduleResults: Map<string, ModuleAuditResult>
}

export interface SecurityFailure {
  module: string
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  message: string
  details: any
  remediation?: string
}

export interface SecurityWarning {
  module: string
  message: string
  details: any
  severity: 'LOW' | 'MEDIUM' | 'HIGH'
}

export interface SecurityRecommendation {
  module: string
  message: string
  priority: 'LOW' | 'MEDIUM' | 'HIGH'
  implementation: string
}

export class SecurityError extends Error {
  public readonly code: string
  public readonly originalError?: Error

  constructor(code: string, message: string, originalError?: Error) {
    super(message)
    this.name = 'SecurityError'
    this.code = code
    this.originalError = originalError
  }
}

// JWT Interfaces
export interface JWTPayload {
  sub: string // subject (user ID)
  aud: string // audience
  iss: string // issuer
  exp: number // expiration time
  iat: number // issued at
  jti: string // JWT ID
  scope: string[] // permissions/scopes
  sessionId: string
  deviceId?: string
  ipAddress?: string
  userAgent?: string
  integrity?: string // payload integrity hash
}

export interface JWTConfig {
  algorithm: 'RS256'
  keyRotationInterval: number
  tokenLifetime: number
  issuer: string
  audience: string
  hsmEnabled?: boolean
}

// MFA Interfaces
export interface MFAConfig {
  enabled: boolean
  mandatory: boolean
  methods: ('TOTP' | 'SMS' | 'Email' | 'Hardware')[]
  backupCodes: boolean
  maxAttempts: number
  lockoutDuration: number
}

export interface TOTPSetupResult {
  secret: string
  qrCode: string
  backupCodes: string[]
  setupComplete: boolean
}

export interface MFASession {
  userId: string
  sessionId: string
  challenges: MFAChallenge[]
  completedMethods: string[]
  requiredMethods: string[]
  isComplete: boolean
  expiresAt: number
}

export interface MFAChallenge {
  id: string
  method: 'TOTP' | 'SMS' | 'Email' | 'Hardware'
  challenge: string
  expiresAt: number
  attempts: number
  maxAttempts: number
}

// Encryption Interfaces
export interface EncryptionConfig {
  enabled: boolean
  algorithm: 'AES-256-GCM'
  keySize: 256
  ivLength: 12
  tagLength: 16
  keyDerivationFunction: 'PBKDF2' | 'scrypt' | 'Argon2'
}

export interface EncryptedData {
  encrypted: string // base64 encoded
  iv: string // base64 encoded
  tag: string // base64 encoded
  context: string
  timestamp: number
  algorithm: string
  keyId?: string
}

export interface KeyRotationConfig {
  enabled: boolean
  intervalDays: number
  automaticRotation: boolean
  retentionCount: number
  notificationThreshold: number // days before rotation
}

// HSM Interfaces
export interface HSMConfig {
  enabled: boolean
  provider: 'AWS_CloudHSM' | 'Azure_HSM' | 'Hardware_HSM'
  keyGeneration: boolean
  signOperations: boolean
  encryptionOperations: boolean
  connectionConfig: {
    endpoint?: string
    region?: string
    credentials?: any
    timeout: number
    retryAttempts: number
  }
}

export interface HSMClient {
  connect(): Promise<void>
  disconnect(): Promise<void>
  generateKey(options: HSMKeyGenerationOptions): Promise<string>
  sign(options: HSMSignOptions): Promise<Buffer>
  encrypt(options: HSMEncryptOptions): Promise<Buffer>
  decrypt(options: HSMDecryptOptions): Promise<Buffer>
  healthCheck(): Promise<HSMHealthCheck>
}

export interface HSMKeyGenerationOptions {
  keyId: string
  keyType: 'AES' | 'RSA' | 'ECDSA'
  keySize: number
  exportable: boolean
  usage: string[]
}

export interface HSMSignOptions {
  keyHandle: string
  data: Buffer
  algorithm: string
}

export interface HSMEncryptOptions {
  keyHandle: string
  data: Buffer
  algorithm: string
}

export interface HSMDecryptOptions {
  keyHandle: string
  encryptedData: Buffer
  algorithm: string
}

export interface HSMHealthCheck {
  healthy: boolean
  latency: number
  lastCheck: number
  errors: string[]
}

// Hardware Key Interfaces
export interface HardwareKeyConfig {
  enabled: boolean
  fido2Support: boolean
  requiredDevices: string[]
  fallbackAllowed: boolean
  attestation: 'none' | 'indirect' | 'direct'
  userVerification: 'required' | 'preferred' | 'discouraged'
}

export interface WebAuthnCredential {
  id: string
  publicKey: ArrayBuffer
  algorithm: number
  counter: number
  deviceType: string
  attestationObject?: ArrayBuffer
}

// Biometric Interfaces
export interface BiometricConfig {
  enabled: boolean
  methods: ('fingerprint' | 'faceId' | 'voiceprint' | 'retina')[]
  threshold: number // confidence level 0-1
  fallbackTimeout: number // seconds
  maxAttempts: number
  deviceRequirements: {
    minSecurityLevel: number
    requiresSecureElement: boolean
    allowsEmulator: boolean
  }
}

// Session Management Interfaces
export interface SessionConfig {
  enabled: boolean
  maxSessions: number
  timeoutMinutes: number
  ipWhitelist: boolean
  geoRestrictions: boolean
  concurrentSessionHandling: 'allow' | 'terminate_oldest' | 'deny_new'
}

export interface UserSession {
  id: string
  userId: string
  deviceId: string
  ipAddress: string
  userAgent: string
  location?: {
    country: string
    city: string
    timezone: string
  }
  createdAt: number
  lastActivity: number
  expiresAt: number
  isActive: boolean
  securityLevel: number
}

// Zero Knowledge Proof Interfaces
export interface ZKProofConfig {
  enabled: boolean
  protocol: 'zk-SNARKs' | 'zk-STARKs' | 'Bulletproofs'
  proofGeneration: boolean
  verification: boolean
  circuitPath?: string
  provingKeyPath?: string
  verifyingKeyPath?: string
}

export interface ZKProof {
  proof: string
  publicSignals: string[]
  protocol: string
  circuitHash: string
  timestamp: number
}

// Security Event Interfaces
export interface SecurityEvent {
  id: string
  timestamp: number
  event: string
  userId?: string
  sessionId?: string
  deviceId?: string
  ipAddress?: string
  userAgent?: string
  details: any
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  handled: boolean
  handledAt?: number
  handledBy?: string
}

// Risk Assessment Interfaces
export interface RiskAssessment {
  sessionId: string
  userId: string
  riskScore: number // 0-100
  factors: RiskFactor[]
  recommendation: 'ALLOW' | 'CHALLENGE' | 'DENY'
  timestamp: number
}

export interface RiskFactor {
  type: string
  score: number
  weight: number
  description: string
  details: any
}

// Compliance Interfaces
export interface ComplianceConfig {
  gdprCompliant: boolean
  ccpaCompliant: boolean
  soc2Compliant: boolean
  iso27001Compliant: boolean
  dataRetentionPeriod: number // days
  auditLogRetention: number // days
  automaticDataDeletion: boolean
}

export interface ComplianceAudit {
  timestamp: number
  complianceFramework: string
  passed: boolean
  violations: ComplianceViolation[]
  recommendations: string[]
  nextAuditDue: number
}

export interface ComplianceViolation {
  rule: string
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  description: string
  remediation: string
  deadline?: number
}

// API Security Interfaces
export interface APISecurityConfig {
  rateLimiting: {
    enabled: boolean
    requestsPerMinute: number
    burstLimit: number
    bypassRoles: string[]
  }
  authentication: {
    required: boolean
    allowedMethods: ('bearer' | 'apikey' | 'oauth2')[]
  }
  encryption: {
    requireHTTPS: boolean
    minTLSVersion: '1.2' | '1.3'
    cipherSuites: string[]
  }
  cors: {
    enabled: boolean
    allowedOrigins: string[]
    allowedMethods: string[]
    allowedHeaders: string[]
  }
}

// Desktoping Interfaces
export interface SecurityMetrics {
  timestamp: number
  authenticationAttempts: {
    successful: number
    failed: number
    suspicious: number
  }
  sessionMetrics: {
    active: number
    created: number
    terminated: number
  }
  securityEvents: {
    total: number
    critical: number
    high: number
    medium: number
    low: number
  }
  performance: {
    avgAuthTime: number
    avgEncryptionTime: number
    avgDecryptionTime: number
  }
}

export interface SecurityDashboardData {
  overallSecurityScore: number
  activeThreats: number
  mitigatedThreats: number
  systemHealth: 'HEALTHY' | 'WARNING' | 'CRITICAL'
  lastAudit: SecurityAuditResult
  metrics: SecurityMetrics
  recentEvents: SecurityEvent[]
}

// Export all types
export type {
  SecurityModule,
  ModuleAuditResult,
  SecurityAuditResult,
  SecurityFailure,
  SecurityWarning,
  SecurityRecommendation,
  JWTPayload,
  JWTConfig,
  MFAConfig,
  TOTPSetupResult,
  MFASession,
  MFAChallenge,
  EncryptionConfig,
  EncryptedData,
  KeyRotationConfig,
  HSMConfig,
  HSMClient,
  HSMKeyGenerationOptions,
  HSMSignOptions,
  HSMEncryptOptions,
  HSMDecryptOptions,
  HSMHealthCheck,
  HardwareKeyConfig,
  WebAuthnCredential,
  BiometricConfig,
  SessionConfig,
  UserSession,
  ZKProofConfig,
  ZKProof,
  SecurityEvent,
  RiskAssessment,
  RiskFactor,
  ComplianceConfig,
  ComplianceAudit,
  ComplianceViolation,
  APISecurityConfig,
  SecurityMetrics,
  SecurityDashboardData
}