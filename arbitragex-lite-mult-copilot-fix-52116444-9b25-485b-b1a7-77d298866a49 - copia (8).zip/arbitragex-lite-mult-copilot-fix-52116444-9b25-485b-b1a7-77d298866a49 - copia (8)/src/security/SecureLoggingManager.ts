/**
 * 📝 SECURE LOGGING MANAGER - ArbitrageX Pro 2025
 * Sistema de logging seguro que previene exposición de datos sensibles
 */

export interface LogEntry {
  timestamp: string;
  level: 'debug' | 'info' | 'warn' | 'error' | 'critical';
  message: string;
  context?: Record<string, any>;
  source: string;
  userId?: string;
  sessionId?: string;
  requestId?: string;
  sanitized: boolean;
}

export interface LoggingConfig {
  level: 'debug' | 'info' | 'warn' | 'error';
  enableConsole: boolean;
  enableFile: boolean;
  enableRemote: boolean;
  sanitizeSecrets: boolean;
  maxLogSize: number;
  rotationInterval: number;
  remoteEndpoint?: string;
}

export class SecureLoggingManager {
  private static instance: SecureLoggingManager;
  private config: LoggingConfig;
  private sensitivePatterns: RegExp[];
  private logBuffer: LogEntry[] = [];
  private rotationTimer?: NodeJS.Timeout;

  private constructor() {
    this.config = {
      level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
      enableConsole: process.env.NODE_ENV !== 'production',
      enableFile: true,
      enableRemote: process.env.NODE_ENV === 'production',
      sanitizeSecrets: true,
      maxLogSize: 10000, // 10k logs
      rotationInterval: 24 * 60 * 60 * 1000, // 24 horas
      remoteEndpoint: process.env.LOG_ENDPOINT
    };

    this.initializeSensitivePatterns();
    this.startLogRotation();
  }

  public static getInstance(): SecureLoggingManager {
    if (!SecureLoggingManager.instance) {
      SecureLoggingManager.instance = new SecureLoggingManager();
    }
    return SecureLoggingManager.instance;
  }

  /**
   * Inicializar patrones de datos sensibles
   */
  private initializeSensitivePatterns(): void {
    this.sensitivePatterns = [
      // Claves privadas y secretos
      /private.*key/gi,
      /secret.*key/gi,
      /api.*key/gi,
      /access.*token/gi,
      /refresh.*token/gi,
      /bearer\s+[\w-]+/gi,
      
      // Credenciales
      /password/gi,
      /passphrase/gi,
      /credentials/gi,
      
      // Direcciones blockchain específicas
      /0x[a-fA-F0-9]{40}/g, // Ethereum addresses
      /0x[a-fA-F0-9]{64}/g, // Private keys
      
      // Seeds y mnemonics
      /seed.*phrase/gi,
      /mnemonic/gi,
      
      // JWT tokens
      /eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_.+/=]*/g,
      
      // Números de tarjetas de crédito
      /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
      
      // Emails sensibles
      /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
      
      // URLs con credenciales
      /https?:\/\/[^:\/\s]+:[^@\/\s]+@[^\s]+/g,
      
      // Variables de entorno sensibles
      /VITE_.*SECRET/gi,
      /VITE_.*KEY/gi,
      /VITE_.*TOKEN/gi,
      /VITE_.*PASSWORD/gi
    ];
  }

  /**
   * Sanitizar datos sensibles
   */
  private sanitizeData(data: any): any {
    if (!this.config.sanitizeSecrets) {
      return data;
    }

    const dataStr = JSON.stringify(data);
    let sanitized = dataStr;

    for (const pattern of this.sensitivePatterns) {
      sanitized = sanitized.replace(pattern, (match) => {
        // Mantener primeros 4 y últimos 4 caracteres para debugging
        if (match.length > 8) {
          return match.substring(0, 4) + '*'.repeat(match.length - 8) + match.substring(match.length - 4);
        } else {
          return '*'.repeat(match.length);
        }
      });
    }

    try {
      return JSON.parse(sanitized);
    } catch {
      return sanitized;
    }
  }

  /**
   * Crear entrada de log
   */
  private createLogEntry(
    level: LogEntry['level'],
    message: string,
    context?: Record<string, any>,
    source: string = 'unknown'
  ): LogEntry {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message: this.sanitizeData(message),
      context: context ? this.sanitizeData(context) : undefined,
      source,
      sanitized: this.config.sanitizeSecrets
    };

    // Agregar metadatos de request si están disponibles
    if (typeof window !== 'undefined') {
      entry.sessionId = sessionStorage.getItem('sessionId') || undefined;
    }

    return entry;
  }

  /**
   * Verificar si el nivel de log está habilitado
   */
  private isLevelEnabled(level: LogEntry['level']): boolean {
    const levels = ['debug', 'info', 'warn', 'error', 'critical'];
    const configLevelIndex = levels.indexOf(this.config.level);
    const messageLevelIndex = levels.indexOf(level);
    return messageLevelIndex >= configLevelIndex;
  }

  /**
   * Escribir log
   */
  private writeLog(entry: LogEntry): void {
    // Agregar a buffer
    this.logBuffer.push(entry);

    // Mantener tamaño del buffer
    if (this.logBuffer.length > this.config.maxLogSize) {
      this.logBuffer = this.logBuffer.slice(-this.config.maxLogSize);
    }

    // Console logging (solo desarrollo)
    if (this.config.enableConsole) {
      const logFunction = entry.level === 'error' || entry.level === 'critical' 
        ? console.error 
        : entry.level === 'warn' 
        ? console.warn 
        : console.log;

      logFunction(`[${entry.timestamp}] [${entry.level.toUpperCase()}] [${entry.source}] ${entry.message}`, 
        entry.context || '');
    }

    // File logging
    if (this.config.enableFile && typeof window === 'undefined') {
      this.writeToFile(entry);
    }

    // Remote logging
    if (this.config.enableRemote && this.config.remoteEndpoint) {
      this.sendToRemote(entry);
    }
  }

  /**
   * Escribir a archivo (solo Node.js)
   */
  private async writeToFile(entry: LogEntry): Promise<void> {
    try {
      const fs = await import('fs');
      const path = await import('path');
      
      const logDir = path.join(process.cwd(), 'logs');
      if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
      }

      const filename = `arbitragex-${new Date().toISOString().split('T')[0]}.log`;
      const filepath = path.join(logDir, filename);
      
      const logLine = JSON.stringify(entry) + '\n';
      fs.appendFileSync(filepath, logLine);
      
    } catch (error) {
      console.error('Error escribiendo log a archivo:', error);
    }
  }

  /**
   * Enviar a sistema remoto de logs
   */
  private async sendToRemote(entry: LogEntry): Promise<void> {
    if (!this.config.remoteEndpoint) return;

    try {
      await fetch(this.config.remoteEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.LOG_API_KEY || ''}`
        },
        body: JSON.stringify({
          service: 'arbitragex-pro',
          environment: process.env.NODE_ENV,
          entry
        })
      });
    } catch (error) {
      // No usar console.error aquí para evitar recursión
      this.writeToFile(this.createLogEntry('error', 'Failed to send log to remote endpoint', { error: error.message }, 'SecureLoggingManager'));
    }
  }

  /**
   * Métodos públicos de logging
   */
  debug(message: string, context?: Record<string, any>, source: string = 'app'): void {
    if (this.isLevelEnabled('debug')) {
      this.writeLog(this.createLogEntry('debug', message, context, source));
    }
  }

  info(message: string, context?: Record<string, any>, source: string = 'app'): void {
    if (this.isLevelEnabled('info')) {
      this.writeLog(this.createLogEntry('info', message, context, source));
    }
  }

  warn(message: string, context?: Record<string, any>, source: string = 'app'): void {
    if (this.isLevelEnabled('warn')) {
      this.writeLog(this.createLogEntry('warn', message, context, source));
    }
  }

  error(message: string, context?: Record<string, any>, source: string = 'app'): void {
    if (this.isLevelEnabled('error')) {
      this.writeLog(this.createLogEntry('error', message, context, source));
    }
  }

  critical(message: string, context?: Record<string, any>, source: string = 'app'): void {
    // Los logs críticos siempre se escriben
    this.writeLog(this.createLogEntry('critical', message, context, source));
    
    // Enviar alerta inmediata
    this.sendCriticalAlert(message, context);
  }

  /**
   * Logging especializado para arbitraje
   */
  logOpportunity(opportunity: any, source: string = 'arbitrage'): void {
    this.info('Oportunidad detectada', {
      id: opportunity.id,
      type: opportunity.type,
      profit: opportunity.profit,
      probability: opportunity.probability,
      dexes: opportunity.dexes
    }, source);
  }

  logExecution(execution: any, source: string = 'execution'): void {
    this.info('Ejecución completada', {
      id: execution.id,
      success: execution.success,
      profit: execution.actualProfit,
      gasUsed: execution.gasUsed,
      executionTime: execution.executionTime
    }, source);
  }

  logSecurityEvent(event: string, details: any, source: string = 'security'): void {
    this.warn(`Evento de seguridad: ${event}`, details, source);
  }

  logTransactionFailure(tx: any, error: string, source: string = 'blockchain'): void {
    this.error('Transacción falló', {
      hash: tx.hash,
      to: tx.to,
      value: tx.value,
      error,
      gasUsed: tx.gasUsed
    }, source);
  }

  /**
   * Enviar alerta crítica
   */
  private async sendCriticalAlert(message: string, context?: Record<string, any>): Promise<void> {
    // Implementar integración con sistemas de alertas (Slack, Discord, email, etc.)
    const alertData = {
      timestamp: new Date().toISOString(),
      service: 'ArbitrageX Pro 2025',
      severity: 'CRITICAL',
      message,
      context,
      environment: process.env.NODE_ENV
    };

    // Discord webhook
    if (process.env.DISCORD_WEBHOOK_URL) {
      try {
        await fetch(process.env.DISCORD_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            content: `🚨 **ALERTA CRÍTICA** - ArbitrageX Pro 2025\n\`\`\`${message}\`\`\``,
            embeds: [{
              title: 'Detalles del Evento',
              description: JSON.stringify(context, null, 2),
              color: 15158332, // Rojo
              timestamp: new Date().toISOString()
            }]
          })
        });
      } catch (error) {
        // Silenciosamente fallar para evitar recursión
      }
    }

    // Telegram bot
    if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
      try {
        await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: process.env.TELEGRAM_CHAT_ID,
            text: `🚨 ALERTA CRÍTICA - ArbitrageX Pro 2025\n\n${message}\n\nEntorno: ${process.env.NODE_ENV}`,
            parse_mode: 'Markdown'
          })
        });
      } catch (error) {
        // Silenciosamente fallar
      }
    }
  }

  /**
   * Rotación de logs
   */
  private startLogRotation(): void {
    this.rotationTimer = setInterval(() => {
      this.rotateLogs();
    }, this.config.rotationInterval);
  }

  private rotateLogs(): void {
    // Limpiar buffer
    this.logBuffer = [];
    
    // Comprimir logs antiguos si estamos en Node.js
    if (typeof window === 'undefined') {
      this.archiveOldLogs();
    }

    this.info('Log rotation completed', undefined, 'SecureLoggingManager');
  }

  private async archiveOldLogs(): Promise<void> {
    try {
      const fs = await import('fs');
      const path = await import('path');
      const zlib = await import('zlib');
      
      const logDir = path.join(process.cwd(), 'logs');
      if (!fs.existsSync(logDir)) return;

      const files = fs.readdirSync(logDir);
      const logFiles = files.filter(f => f.endsWith('.log') && !f.includes('archived'));

      for (const file of logFiles) {
        const filePath = path.join(logDir, file);
        const stats = fs.statSync(filePath);
        
        // Archivar logs más antiguos de 7 días
        const ageInDays = (Date.now() - stats.mtime.getTime()) / (1000 * 60 * 60 * 24);
        if (ageInDays > 7) {
          const archivedPath = path.join(logDir, `archived-${file}.gz`);
          const readStream = fs.createReadStream(filePath);
          const writeStream = fs.createWriteStream(archivedPath);
          const gzip = zlib.createGzip();
          
          readStream.pipe(gzip).pipe(writeStream);
          
          writeStream.on('finish', () => {
            fs.unlinkSync(filePath); // Eliminar original
          });
        }
      }
    } catch (error) {
      // Error silencioso en archivado
    }
  }

  /**
   * Obtener logs recientes
   */
  getRecentLogs(count: number = 100): LogEntry[] {
    return this.logBuffer.slice(-count);
  }

  /**
   * Obtener estadísticas de logging
   */
  getLoggingStats(): {
    totalLogs: number;
    logsByLevel: Record<string, number>;
    recentErrors: LogEntry[];
    configStatus: LoggingConfig;
  } {
    const logsByLevel: Record<string, number> = {};
    
    for (const entry of this.logBuffer) {
      logsByLevel[entry.level] = (logsByLevel[entry.level] || 0) + 1;
    }

    const recentErrors = this.logBuffer
      .filter(log => log.level === 'error' || log.level === 'critical')
      .slice(-10);

    return {
      totalLogs: this.logBuffer.length,
      logsByLevel,
      recentErrors,
      configStatus: { ...this.config }
    };
  }

  /**
   * Destruir logger
   */
  destroy(): void {
    if (this.rotationTimer) {
      clearInterval(this.rotationTimer);
    }
    this.logBuffer = [];
  }
}

// Export singleton instance
export const secureLogger = SecureLoggingManager.getInstance();
export default SecureLoggingManager;
