/**
 * 🛡️ SECURE TRANSACTION MANAGER - ArbitrageX Pro 2025
 * Gestión segura de transacciones usando hardware wallets
 */

import { ethers } from 'ethers';
import { hardwareWalletManager, HardwareWalletManager } from './HardwareWalletManager';

export interface TransactionRequest {
  id: string;
  type: 'arbitrage' | 'approval' | 'emergency' | 'configuration';
  to: string;
  value: string;
  data: string;
  gasLimit: string;
  gasPrice: string;
  chainId: number;
  priority: 'low' | 'medium' | 'high' | 'critical';
  deadline: number;
  requiresConfirmation: boolean;
  metadata: {
    opportunityId?: string;
    strategy?: string;
    estimatedProfit?: number;
    riskLevel?: number;
  };
}

export interface TransactionResult {
  success: boolean;
  transactionHash?: string;
  error?: string;
  gasUsed?: number;
  actualProfit?: number;
  executionTime: number;
}

export interface SecurityPolicy {
  maxTransactionValue: string; // en ETH
  maxDailyVolume: string; // en ETH
  requiresConfirmationAbove: string; // en ETH
  allowedContracts: string[];
  emergencyStopEnabled: boolean;
  multiSigRequired: boolean;
  timelock: number; // segundos
}

export class SecureTransactionManager {
  private static instance: SecureTransactionManager;
  private pendingTransactions: Map<string, TransactionRequest> = new Map();
  private dailyVolume: number = 0;
  private dailyVolumeResetTime: number = 0;
  private isEmergencyStop: boolean = false;
  
  private securityPolicy: SecurityPolicy = {
    maxTransactionValue: '10.0', // 10 ETH máximo por transacción
    maxDailyVolume: '100.0', // 100 ETH máximo por día
    requiresConfirmationAbove: '1.0', // Confirmación manual arriba de 1 ETH
    allowedContracts: [], // Solo contratos whitelist
    emergencyStopEnabled: true,
    multiSigRequired: false,
    timelock: 0 // Sin timelock por defecto
  };

  private constructor() {
    this.resetDailyVolumeIfNeeded();
  }

  public static getInstance(): SecureTransactionManager {
    if (!SecureTransactionManager.instance) {
      SecureTransactionManager.instance = new SecureTransactionManager();
    }
    return SecureTransactionManager.instance;
  }

  /**
   * Configurar política de seguridad
   */
  setSecurityPolicy(policy: Partial<SecurityPolicy>): void {
    this.securityPolicy = { ...this.securityPolicy, ...policy };
    console.log('🔐 Política de seguridad actualizada');
  }

  /**
   * Obtener política de seguridad actual
   */
  getSecurityPolicy(): SecurityPolicy {
    return { ...this.securityPolicy };
  }

  /**
   * Preparar transacción de arbitraje
   */
  async prepareArbitrageTransaction(params: {
    opportunityId: string;
    strategy: string;
    contractAddress: string;
    calldata: string;
    value: string;
    gasLimit: string;
    gasPrice: string;
    chainId: number;
    estimatedProfit: number;
    riskLevel: number;
  }): Promise<string> {
    
    // Verificar emergency stop
    if (this.isEmergencyStop) {
      throw new Error('🚨 EMERGENCY STOP: Sistema en modo de emergencia');
    }

    // Validar contrato permitido
    if (!this.isContractAllowed(params.contractAddress)) {
      throw new Error(`❌ Contrato no autorizado: ${params.contractAddress}`);
    }

    // Validar límites de transacción
    this.validateTransactionLimits(params.value);

    // Calcular prioridad basada en profit y riesgo
    const priority = this.calculatePriority(params.estimatedProfit, params.riskLevel);

    // Crear request de transacción
    const transactionRequest: TransactionRequest = {
      id: this.generateTransactionId(),
      type: 'arbitrage',
      to: params.contractAddress,
      value: params.value,
      data: params.calldata,
      gasLimit: params.gasLimit,
      gasPrice: params.gasPrice,
      chainId: params.chainId,
      priority,
      deadline: Date.now() + (priority === 'critical' ? 30000 : 60000), // 30s o 60s deadline
      requiresConfirmation: this.requiresManualConfirmation(params.value),
      metadata: {
        opportunityId: params.opportunityId,
        strategy: params.strategy,
        estimatedProfit: params.estimatedProfit,
        riskLevel: params.riskLevel
      }
    };

    // Guardar transacción pendiente
    this.pendingTransactions.set(transactionRequest.id, transactionRequest);

    console.log(`📝 Transacción preparada: ${transactionRequest.id}`);
    console.log(`   💰 Valor: ${ethers.formatEther(params.value)} ETH`);
    console.log(`   📊 Profit estimado: $${params.estimatedProfit.toFixed(2)}`);
    console.log(`   ⚠️ Riesgo: ${params.riskLevel}/10`);
    console.log(`   🔥 Prioridad: ${priority}`);

    return transactionRequest.id;
  }

  /**
   * Ejecutar transacción usando hardware wallet
   */
  async executeTransaction(
    transactionId: string,
    provider: ethers.Provider
  ): Promise<TransactionResult> {
    const startTime = Date.now();
    
    // Obtener transacción pendiente
    const txRequest = this.pendingTransactions.get(transactionId);
    if (!txRequest) {
      throw new Error('Transacción no encontrada');
    }

    // Verificar deadline
    if (Date.now() > txRequest.deadline) {
      this.pendingTransactions.delete(transactionId);
      throw new Error('Transacción expirada');
    }

    // Verificar emergency stop
    if (this.isEmergencyStop) {
      throw new Error('🚨 EMERGENCY STOP activado');
    }

    try {
      // Verificar wallet conectado
      if (!hardwareWalletManager.isConnected()) {
        throw new Error('Hardware wallet no conectado');
      }

      // Preparar transacción para firma
      const transaction = {
        to: txRequest.to,
        value: txRequest.value,
        data: txRequest.data,
        gasLimit: txRequest.gasLimit,
        gasPrice: txRequest.gasPrice,
        chainId: txRequest.chainId,
        nonce: await provider.getTransactionCount(
          hardwareWalletManager.getActiveWallet()!.address
        )
      };

      console.log(`🔐 Firmando transacción ${transactionId} con hardware wallet...`);

      // Firmar con hardware wallet
      const signedTx = await hardwareWalletManager.signTransaction(transaction);

      console.log(`📤 Enviando transacción firmada...`);

      // Enviar transacción
      const txResponse = await provider.broadcastTransaction(signedTx);
      
      console.log(`⏳ Esperando confirmación: ${txResponse.hash}`);

      // Esperar confirmación
      const receipt = await txResponse.wait();

      // Calcular profit real si es arbitraje
      let actualProfit = 0;
      if (txRequest.type === 'arbitrage' && receipt && receipt.status === 1) {
        actualProfit = await this.calculateActualProfit(receipt, txRequest);
      }

      // Actualizar volumen diario
      this.updateDailyVolume(parseFloat(ethers.formatEther(txRequest.value)));

      // Limpiar transacción pendiente
      this.pendingTransactions.delete(transactionId);

      const executionTime = Date.now() - startTime;

      const result: TransactionResult = {
        success: receipt?.status === 1,
        transactionHash: txResponse.hash,
        gasUsed: receipt?.gasUsed ? Number(receipt.gasUsed) : undefined,
        actualProfit,
        executionTime
      };

      console.log(`✅ Transacción completada: ${txResponse.hash}`);
      console.log(`   ⛽ Gas usado: ${result.gasUsed?.toLocaleString()}`);
      console.log(`   💰 Profit real: $${actualProfit.toFixed(2)}`);
      console.log(`   ⏱️ Tiempo: ${executionTime}ms`);

      return result;

    } catch (error) {
      console.error(`❌ Error ejecutando transacción ${transactionId}:`, error);
      
      // Limpiar transacción pendiente
      this.pendingTransactions.delete(transactionId);

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido',
        executionTime: Date.now() - startTime
      };
    }
  }

  /**
   * Obtener transacciones pendientes
   */
  getPendingTransactions(): TransactionRequest[] {
    // Limpiar transacciones expiradas
    const now = Date.now();
    for (const [id, tx] of this.pendingTransactions) {
      if (now > tx.deadline) {
        this.pendingTransactions.delete(id);
      }
    }

    return Array.from(this.pendingTransactions.values())
      .sort((a, b) => this.getPriorityValue(b.priority) - this.getPriorityValue(a.priority));
  }

  /**
   * Cancelar transacción pendiente
   */
  cancelTransaction(transactionId: string): boolean {
    return this.pendingTransactions.delete(transactionId);
  }

  /**
   * Activar emergency stop
   */
  activateEmergencyStop(reason: string): void {
    this.isEmergencyStop = true;
    console.log(`🚨 EMERGENCY STOP ACTIVADO: ${reason}`);
    
    // Cancelar todas las transacciones pendientes
    this.pendingTransactions.clear();
  }

  /**
   * Desactivar emergency stop
   */
  deactivateEmergencyStop(): void {
    this.isEmergencyStop = false;
    console.log('✅ Emergency stop desactivado');
  }

  /**
   * Verificar si está en emergency stop
   */
  isInEmergencyStop(): boolean {
    return this.isEmergencyStop;
  }

  /**
   * Obtener volumen diario actual
   */
  getDailyVolume(): number {
    this.resetDailyVolumeIfNeeded();
    return this.dailyVolume;
  }

  // Métodos privados

  private validateTransactionLimits(value: string): void {
    const ethValue = parseFloat(ethers.formatEther(value));
    const maxValue = parseFloat(this.securityPolicy.maxTransactionValue);
    
    if (ethValue > maxValue) {
      throw new Error(
        `❌ Valor de transacción (${ethValue} ETH) excede el límite (${maxValue} ETH)`
      );
    }

    this.resetDailyVolumeIfNeeded();
    const maxDaily = parseFloat(this.securityPolicy.maxDailyVolume);
    
    if (this.dailyVolume + ethValue > maxDaily) {
      throw new Error(
        `❌ Volumen diario excedería el límite. Actual: ${this.dailyVolume.toFixed(2)} ETH, Límite: ${maxDaily} ETH`
      );
    }
  }

  private isContractAllowed(contractAddress: string): boolean {
    if (this.securityPolicy.allowedContracts.length === 0) {
      return true; // Sin whitelist = todos permitidos
    }
    return this.securityPolicy.allowedContracts.includes(contractAddress.toLowerCase());
  }

  private requiresManualConfirmation(value: string): boolean {
    const ethValue = parseFloat(ethers.formatEther(value));
    const threshold = parseFloat(this.securityPolicy.requiresConfirmationAbove);
    return ethValue > threshold;
  }

  private calculatePriority(estimatedProfit: number, riskLevel: number): 'low' | 'medium' | 'high' | 'critical' {
    // Prioridad basada en profit/riesgo ratio
    const profitRiskRatio = estimatedProfit / (riskLevel + 1);
    
    if (profitRiskRatio > 100) return 'critical';
    if (profitRiskRatio > 50) return 'high';
    if (profitRiskRatio > 20) return 'medium';
    return 'low';
  }

  private getPriorityValue(priority: string): number {
    switch (priority) {
      case 'critical': return 4;
      case 'high': return 3;
      case 'medium': return 2;
      case 'low': return 1;
      default: return 0;
    }
  }

  private async calculateActualProfit(
    receipt: ethers.TransactionReceipt, 
    txRequest: TransactionRequest
  ): Promise<number> {
    // Implementar cálculo de profit real basado en logs de eventos
    // Por ahora retorna el estimado
    return txRequest.metadata.estimatedProfit || 0;
  }

  private updateDailyVolume(ethValue: number): void {
    this.resetDailyVolumeIfNeeded();
    this.dailyVolume += ethValue;
  }

  private resetDailyVolumeIfNeeded(): void {
    const now = Date.now();
    const oneDayMs = 24 * 60 * 60 * 1000;
    
    if (now - this.dailyVolumeResetTime > oneDayMs) {
      this.dailyVolume = 0;
      this.dailyVolumeResetTime = now;
    }
  }

  private generateTransactionId(): string {
    return 'tx_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }
}

// Export singleton instance
export const secureTransactionManager = SecureTransactionManager.getInstance();
export default SecureTransactionManager;
