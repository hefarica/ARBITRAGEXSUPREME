/**
 * 🔐 CREDENTIALS SEPARATION MANAGER - ArbitrageX Pro 2025
 * Separación segura de credenciales entre frontend y backend
 */

export interface CredentialPolicy {
  name: string;
  type: 'public' | 'private' | 'sensitive';
  allowedEnvironments: ('development' | 'staging' | 'production')[];
  exposureRisk: 'none' | 'low' | 'medium' | 'high' | 'critical';
  requiresEncryption: boolean;
}

export interface CredentialVault {
  publicConfig: Record<string, any>;
  serverOnlySecrets: Record<string, any>;
  encryptedSecrets: Record<string, any>;
}

export class CredentialsSeparationManager {
  private static instance: CredentialsSeparationManager;
  private vault: CredentialVault;
  private policies: Map<string, CredentialPolicy> = new Map();

  private constructor() {
    this.vault = {
      publicConfig: {},
      serverOnlySecrets: {},
      encryptedSecrets: {}
    };
    this.initializePolicies();
  }

  public static getInstance(): CredentialsSeparationManager {
    if (!CredentialsSeparationManager.instance) {
      CredentialsSeparationManager.instance = new CredentialsSeparationManager();
    }
    return CredentialsSeparationManager.instance;
  }

  /**
   * Inicializar políticas de credenciales
   */
  private initializePolicies(): void {
    // 🟢 CREDENCIALES PÚBLICAS - Seguras para frontend
    this.addPolicy('OPERATION_MODE', {
      name: 'OPERATION_MODE',
      type: 'public',
      allowedEnvironments: ['development', 'staging', 'production'],
      exposureRisk: 'none',
      requiresEncryption: false
    });

    this.addPolicy('LOG_LEVEL', {
      name: 'LOG_LEVEL',
      type: 'public',
      allowedEnvironments: ['development', 'staging', 'production'],
      exposureRisk: 'none',
      requiresEncryption: false
    });

    this.addPolicy('API_BASE_URL', {
      name: 'API_BASE_URL',
      type: 'public',
      allowedEnvironments: ['development', 'staging', 'production'],
      exposureRisk: 'none',
      requiresEncryption: false
    });

    // 🟡 CREDENCIALES PRIVADAS - Solo backend
    this.addPolicy('JWT_SECRET', {
      name: 'JWT_SECRET',
      type: 'sensitive',
      allowedEnvironments: ['development', 'staging', 'production'],
      exposureRisk: 'critical',
      requiresEncryption: true
    });

    this.addPolicy('ENCRYPTION_KEY', {
      name: 'ENCRYPTION_KEY',
      type: 'sensitive',
      allowedEnvironments: ['development', 'staging', 'production'],
      exposureRisk: 'critical',
      requiresEncryption: true
    });

    // 🔴 CREDENCIALES CRÍTICAS - Solo backend cifradas
    this.addPolicy('BINANCE_API_KEY', {
      name: 'BINANCE_API_KEY',
      type: 'sensitive',
      allowedEnvironments: ['production'],
      exposureRisk: 'critical',
      requiresEncryption: true
    });

    this.addPolicy('BINANCE_SECRET_KEY', {
      name: 'BINANCE_SECRET_KEY',
      type: 'sensitive',
      allowedEnvironments: ['production'],
      exposureRisk: 'critical',
      requiresEncryption: true
    });

    this.addPolicy('ETHEREUM_RPC_URL', {
      name: 'ETHEREUM_RPC_URL',
      type: 'private',
      allowedEnvironments: ['development', 'staging', 'production'],
      exposureRisk: 'medium',
      requiresEncryption: false
    });

    // Todas las claves privadas son CRÍTICAS
    this.addPolicy('WALLET_PRIVATE_KEY', {
      name: 'WALLET_PRIVATE_KEY',
      type: 'sensitive',
      allowedEnvironments: [],
      exposureRisk: 'critical',
      requiresEncryption: true
    });

    console.log('🔐 Políticas de credenciales inicializadas');
  }

  /**
   * Agregar política de credencial
   */
  private addPolicy(key: string, policy: CredentialPolicy): void {
    this.policies.set(key, policy);
  }

  /**
   * Separar credenciales según política
   */
  async separateCredentials(envVars: Record<string, string>): Promise<CredentialVault> {
    console.log('🔐 Iniciando separación de credenciales...');

    const separatedVault: CredentialVault = {
      publicConfig: {},
      serverOnlySecrets: {},
      encryptedSecrets: {}
    };

    const violations: string[] = [];

    for (const [key, value] of Object.entries(envVars)) {
      const policy = this.policies.get(key);
      
      if (!policy) {
        // Variable no definida en política - asumir privada por seguridad
        separatedVault.serverOnlySecrets[key] = value;
        console.warn(`⚠️ Variable sin política definida: ${key} - clasificada como privada`);
        continue;
      }

      // Verificar exposición en frontend (variables VITE_)
      if (key.startsWith('VITE_') && policy.type !== 'public') {
        violations.push(`🚨 VIOLACIÓN CRÍTICA: ${key} marcada como ${policy.type} pero expuesta con VITE_ prefix`);
      }

      // Clasificar según política
      switch (policy.type) {
        case 'public':
          separatedVault.publicConfig[key] = value;
          break;
        
        case 'private':
          separatedVault.serverOnlySecrets[key] = value;
          break;
        
        case 'sensitive':
          if (policy.requiresEncryption) {
            const encrypted = await this.encryptValue(value);
            separatedVault.encryptedSecrets[key] = encrypted;
          } else {
            separatedVault.serverOnlySecrets[key] = value;
          }
          break;
      }
    }

    // Reportar violaciones
    if (violations.length > 0) {
      console.error('🚨 VIOLACIONES DE SEGURIDAD DETECTADAS:');
      violations.forEach(violation => console.error(violation));
      
      if (process.env.NODE_ENV === 'production') {
        throw new Error(`${violations.length} violaciones críticas de credenciales detectadas`);
      }
    }

    this.vault = separatedVault;
    
    console.log('✅ Separación de credenciales completada:');
    console.log(`   🟢 Públicas: ${Object.keys(separatedVault.publicConfig).length}`);
    console.log(`   🟡 Privadas: ${Object.keys(separatedVault.serverOnlySecrets).length}`);
    console.log(`   🔴 Cifradas: ${Object.keys(separatedVault.encryptedSecrets).length}`);

    return separatedVault;
  }

  /**
   * Generar configuración segura para frontend
   */
  generateFrontendConfig(): Record<string, any> {
    const frontendConfig = {
      ...this.vault.publicConfig,
      // Agregar configuraciones calculadas de forma segura
      isProduction: process.env.NODE_ENV === 'production',
      apiBaseUrl: this.vault.publicConfig.API_BASE_URL || '/api',
      environment: process.env.NODE_ENV || 'development'
    };

    // Verificar que no hay credenciales sensibles
    const sensitivePatterns = [
      /secret/i,
      /key/i,
      /password/i,
      /token/i,
      /private/i
    ];

    for (const [key, value] of Object.entries(frontendConfig)) {
      const isSensitive = sensitivePatterns.some(pattern => 
        pattern.test(key) || pattern.test(String(value))
      );
      
      if (isSensitive && key !== 'isProduction') {
        console.warn(`⚠️ Posible credencial sensible en frontend config: ${key}`);
      }
    }

    return frontendConfig;
  }

  /**
   * Generar configuración segura para backend
   */
  generateBackendConfig(): Record<string, any> {
    const backendConfig = {
      ...this.vault.publicConfig,
      ...this.vault.serverOnlySecrets
    };

    // Desencriptar secretos sensibles
    for (const [key, encryptedValue] of Object.entries(this.vault.encryptedSecrets)) {
      try {
        backendConfig[key] = this.decryptValue(encryptedValue);
      } catch (error) {
        console.error(`❌ Error desencriptando ${key}:`, error);
      }
    }

    return backendConfig;
  }

  /**
   * Validar configuración actual
   */
  validateCurrentConfiguration(): {
    isValid: boolean;
    violations: string[];
    recommendations: string[];
  } {
    const violations: string[] = [];
    const recommendations: string[] = [];

    // Verificar variables VITE_ peligrosas
    const dangerousViteVars = Object.keys(process.env)
      .filter(key => key.startsWith('VITE_'))
      .filter(key => {
        const policy = this.policies.get(key);
        return policy && policy.type !== 'public';
      });

    if (dangerousViteVars.length > 0) {
      violations.push(`Variables VITE_ sensibles encontradas: ${dangerousViteVars.join(', ')}`);
      recommendations.push('Remover prefijo VITE_ de variables sensibles y manejarlas solo en backend');
    }

    // Verificar claves privadas en variables de entorno
    const privateKeyVars = Object.keys(process.env)
      .filter(key => /private.*key|wallet.*key|secret.*key/i.test(key));

    if (privateKeyVars.length > 0) {
      violations.push(`Claves privadas en variables de entorno: ${privateKeyVars.join(', ')}`);
      recommendations.push('Migrar claves privadas a hardware wallets o HSM');
    }

    // Verificar secretos JWT débiles
    const jwtSecret = process.env.JWT_SECRET || process.env.VITE_JWT_SECRET;
    if (jwtSecret && jwtSecret.length < 32) {
      violations.push('JWT Secret demasiado corto (mínimo 32 caracteres)');
      recommendations.push('Generar JWT secret más largo: openssl rand -hex 32');
    }

    return {
      isValid: violations.length === 0,
      violations,
      recommendations
    };
  }

  /**
   * Encriptar valor sensible
   */
  private async encryptValue(value: string): Promise<string> {
    // Implementación simplificada - en producción usar HSM o Azure Key Vault
    try {
      const crypto = await import('crypto');
      const algorithm = 'aes-256-gcm';
      const key = crypto.scryptSync(process.env.MASTER_KEY || 'default-key', 'salt', 32);
      const iv = crypto.randomBytes(16);
      
      const cipher = crypto.createCipher(algorithm, key);
      let encrypted = cipher.update(value, 'utf8', 'hex');
      encrypted += cipher.final('hex');
      
      return `encrypted:${iv.toString('hex')}:${encrypted}`;
    } catch (error) {
      console.error('Error encriptando valor:', error);
      return value; // Fallback - en producción esto debería fallar
    }
  }

  /**
   * Desencriptar valor
   */
  private decryptValue(encryptedValue: string): string {
    if (!encryptedValue.startsWith('encrypted:')) {
      return encryptedValue; // No está encriptado
    }

    try {
      const crypto = require('crypto');
      const parts = encryptedValue.split(':');
      const iv = Buffer.from(parts[1], 'hex');
      const encrypted = parts[2];
      
      const algorithm = 'aes-256-gcm';
      const key = crypto.scryptSync(process.env.MASTER_KEY || 'default-key', 'salt', 32);
      
      const decipher = crypto.createDecipher(algorithm, key);
      let decrypted = decipher.update(encrypted, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      
      return decrypted;
    } catch (error) {
      console.error('Error desencriptando valor:', error);
      return encryptedValue; // Fallback
    }
  }

  /**
   * Generar archivo .env seguro para producción
   */
  generateSecureEnvFile(): string {
    const validation = this.validateCurrentConfiguration();
    
    let envContent = `# 🔐 ArbitrageX Pro 2025 - Configuración Segura de Producción
# Generado automáticamente por CredentialsSeparationManager
# Fecha: ${new Date().toISOString()}

# ================================================
# ⚠️ IMPORTANTE - LEER ANTES DE USAR
# ================================================

# ✅ SOLO VARIABLES PÚBLICAS van con prefijo VITE_
# ❌ NUNCA usar VITE_ para credenciales sensibles
# 🔐 Variables sensibles van SIN prefijo (solo backend)

# ================================================
# 🟢 CONFIGURACIÓN PÚBLICA (Frontend + Backend)
# ================================================

`;

    // Agregar variables públicas con VITE_
    for (const [key, value] of Object.entries(this.vault.publicConfig)) {
      envContent += `VITE_${key}=${value}\n`;
    }

    envContent += `
# ================================================
# 🟡 CONFIGURACIÓN PRIVADA (Solo Backend)
# ================================================

`;

    // Agregar variables privadas sin VITE_
    for (const [key, value] of Object.entries(this.vault.serverOnlySecrets)) {
      envContent += `${key}=${value}\n`;
    }

    envContent += `
# ================================================
# 🔴 SECRETOS CRÍTICOS (Cifrados)
# ================================================
# NOTA: Estos valores deben configurarse en producción
# usando Azure Key Vault, AWS Secrets Manager o similar

`;

    // Agregar placeholders para secretos críticos
    for (const key of Object.keys(this.vault.encryptedSecrets)) {
      envContent += `${key}=CONFIGURAR_EN_PRODUCCION_CON_HSM\n`;
    }

    if (validation.violations.length > 0) {
      envContent += `
# ================================================
# 🚨 VIOLACIONES DE SEGURIDAD DETECTADAS
# ================================================

${validation.violations.map(v => `# VIOLACIÓN: ${v}`).join('\n')}

# ================================================
# 💡 RECOMENDACIONES
# ================================================

${validation.recommendations.map(r => `# RECOMENDACIÓN: ${r}`).join('\n')}
`;
    }

    return envContent;
  }
}

// Export singleton instance
export const credentialsSeparationManager = CredentialsSeparationManager.getInstance();
export default CredentialsSeparationManager;
