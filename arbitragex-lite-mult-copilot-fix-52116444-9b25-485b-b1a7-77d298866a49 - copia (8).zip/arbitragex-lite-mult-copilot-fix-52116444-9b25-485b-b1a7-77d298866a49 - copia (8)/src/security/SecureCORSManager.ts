/**
 * 🔒 SECURE CORS MANAGER - ArbitrageX Pro 2025
 * Configuración segura de CORS con whitelist estricta
 */

export interface CORSConfig {
  allowedOrigins: string[];
  allowedMethods: string[];
  allowedHeaders: string[];
  exposedHeaders: string[];
  credentials: boolean;
  maxAge: number;
  preflightContinue: boolean;
  optionsSuccessStatus: number;
}

export interface OriginValidation {
  domain: string;
  environment: 'development' | 'staging' | 'production';
  secure: boolean;
  trusted: boolean;
}

export class SecureCORSManager {
  private static instance: SecureCORSManager;
  private trustedOrigins: Map<string, OriginValidation> = new Map();
  private corsConfig: CORSConfig;

  private constructor() {
    this.initializeTrustedOrigins();
    this.corsConfig = this.generateSecureCORSConfig();
  }

  public static getInstance(): SecureCORSManager {
    if (!SecureCORSManager.instance) {
      SecureCORSManager.instance = new SecureCORSManager();
    }
    return SecureCORSManager.instance;
  }

  /**
   * Inicializar orígenes de confianza
   */
  private initializeTrustedOrigins(): void {
    // 🟢 DESARROLLO - Solo localhost
    if (process.env.NODE_ENV === 'development') {
      this.addTrustedOrigin('http://localhost:3000', 'development', false);
      this.addTrustedOrigin('http://127.0.0.1:3000', 'development', false);
      this.addTrustedOrigin('http://localhost:3001', 'development', false);
      this.addTrustedOrigin('http://localhost:5173', 'development', false); // Vite dev
    }

    // 🟡 STAGING - Dominios de staging
    if (process.env.NODE_ENV === 'staging') {
      this.addTrustedOrigin('https://staging.arbitragex.pro', 'staging', true);
      this.addTrustedOrigin('https://test.arbitragex.pro', 'staging', true);
    }

    // 🔴 PRODUCCIÓN - Solo dominios oficiales
    if (process.env.NODE_ENV === 'production') {
      this.addTrustedOrigin('https://arbitragex.pro', 'production', true);
      this.addTrustedOrigin('https://www.arbitragex.pro', 'production', true);
      this.addTrustedOrigin('https://app.arbitragex.pro', 'production', true);
      
      // Dominios de CDN si es necesario
      if (process.env.CDN_DOMAIN) {
        this.addTrustedOrigin(process.env.CDN_DOMAIN, 'production', true);
      }
    }

    console.log(`🔒 CORS: ${this.trustedOrigins.size} orígenes de confianza configurados para ${process.env.NODE_ENV}`);
  }

  /**
   * Agregar origen de confianza
   */
  private addTrustedOrigin(
    domain: string, 
    environment: OriginValidation['environment'], 
    secure: boolean
  ): void {
    this.trustedOrigins.set(domain, {
      domain,
      environment,
      secure,
      trusted: true
    });
  }

  /**
   * Generar configuración CORS segura
   */
  private generateSecureCORSConfig(): CORSConfig {
    const allowedOrigins = Array.from(this.trustedOrigins.keys());

    return {
      allowedOrigins,
      allowedMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: [
        'Content-Type',
        'Authorization',
        'X-Requested-With',
        'X-API-Key',
        'X-Request-ID',
        'Cache-Control'
      ],
      exposedHeaders: [
        'X-RateLimit-Limit',
        'X-RateLimit-Remaining',
        'X-RateLimit-Reset',
        'X-Request-ID'
      ],
      credentials: true, // Permitir cookies y headers de auth
      maxAge: 86400, // 24 horas cache preflight
      preflightContinue: false,
      optionsSuccessStatus: 204
    };
  }

  /**
   * Middleware de CORS seguro para Express
   */
  getSecureCORSMiddleware() {
    return (req: any, res: any, next: any) => {
      const origin = req.headers.origin;
      const requestedWith = req.headers['x-requested-with'];

      // 1. Verificar origen
      if (origin) {
        const isAllowed = this.isOriginAllowed(origin);
        
        if (isAllowed) {
          res.setHeader('Access-Control-Allow-Origin', origin);
          console.log(`✅ CORS: Origen permitido: ${origin}`);
        } else {
          console.warn(`🚫 CORS: Origen rechazado: ${origin}`);
          
          // Log security event
          this.logSecurityEvent('cors_violation', {
            origin,
            ip: req.ip,
            userAgent: req.headers['user-agent'],
            requestedPath: req.path
          });

          return res.status(403).json({
            error: {
              code: 'CORS_VIOLATION',
              message: 'Origen no autorizado',
              timestamp: new Date().toISOString()
            }
          });
        }
      } else {
        // Sin origen - puede ser request desde herramientas como curl
        // Solo permitir en desarrollo
        if (process.env.NODE_ENV === 'development') {
          res.setHeader('Access-Control-Allow-Origin', '*');
        } else {
          console.warn('🚫 CORS: Request sin origen en producción');
          return res.status(403).json({
            error: {
              code: 'MISSING_ORIGIN',
              message: 'Origen requerido',
              timestamp: new Date().toISOString()
            }
          });
        }
      }

      // 2. Configurar headers CORS
      res.setHeader('Access-Control-Allow-Methods', this.corsConfig.allowedMethods.join(', '));
      res.setHeader('Access-Control-Allow-Headers', this.corsConfig.allowedHeaders.join(', '));
      res.setHeader('Access-Control-Expose-Headers', this.corsConfig.exposedHeaders.join(', '));
      res.setHeader('Access-Control-Allow-Credentials', this.corsConfig.credentials.toString());
      res.setHeader('Access-Control-Max-Age', this.corsConfig.maxAge.toString());

      // 3. Verificaciones adicionales de seguridad
      if (req.method === 'OPTIONS') {
        // Preflight request
        return res.status(this.corsConfig.optionsSuccessStatus).end();
      }

      // 4. Verificar headers de seguridad adicionales
      if (process.env.NODE_ENV === 'production') {
        // Verificar X-Requested-With para AJAX requests
        if (!requestedWith && ['POST', 'PUT', 'DELETE'].includes(req.method)) {
          console.warn('🚫 CORS: Request sin X-Requested-With en producción');
          return res.status(403).json({
            error: {
              code: 'MISSING_SECURITY_HEADER',
              message: 'Header de seguridad requerido',
              timestamp: new Date().toISOString()
            }
          });
        }
      }

      next();
    };
  }

  /**
   * Verificar si un origen está permitido
   */
  private isOriginAllowed(origin: string): boolean {
    // Verificación exacta
    if (this.trustedOrigins.has(origin)) {
      return true;
    }

    // Verificación de subdominios en producción (si está configurado)
    if (process.env.NODE_ENV === 'production' && process.env.ALLOW_SUBDOMAINS === 'true') {
      const allowedDomains = ['arbitragex.pro'];
      
      try {
        const url = new URL(origin);
        const hostname = url.hostname;
        
        for (const domain of allowedDomains) {
          if (hostname === domain || hostname.endsWith(`.${domain}`)) {
            // Verificar que sea HTTPS en producción
            if (url.protocol === 'https:') {
              return true;
            }
          }
        }
      } catch (error) {
        console.error('Error parsing origin URL:', error);
      }
    }

    return false;
  }

  /**
   * Agregar origen dinámicamente (solo desarrollo)
   */
  addDynamicOrigin(origin: string): boolean {
    if (process.env.NODE_ENV !== 'development') {
      console.warn('🚫 CORS: No se pueden agregar orígenes dinámicos en producción');
      return false;
    }

    try {
      const url = new URL(origin);
      
      // Solo localhost en desarrollo
      if (url.hostname === 'localhost' || url.hostname === '127.0.0.1') {
        this.addTrustedOrigin(origin, 'development', false);
        console.log(`✅ CORS: Origen dinámico agregado: ${origin}`);
        return true;
      }
    } catch (error) {
      console.error('Error adding dynamic origin:', error);
    }

    return false;
  }

  /**
   * Obtener configuración actual
   */
  getConfiguration(): {
    allowedOrigins: string[];
    corsConfig: CORSConfig;
    environment: string;
    securityLevel: 'strict' | 'moderate' | 'permissive';
  } {
    let securityLevel: 'strict' | 'moderate' | 'permissive' = 'strict';
    
    if (process.env.NODE_ENV === 'development') {
      securityLevel = 'moderate';
    } else if (process.env.NODE_ENV === 'staging') {
      securityLevel = 'strict';
    }

    return {
      allowedOrigins: Array.from(this.trustedOrigins.keys()),
      corsConfig: this.corsConfig,
      environment: process.env.NODE_ENV || 'unknown',
      securityLevel
    };
  }

  /**
   * Validar configuración CORS
   */
  validateConfiguration(): {
    isSecure: boolean;
    violations: string[];
    recommendations: string[];
  } {
    const violations: string[] = [];
    const recommendations: string[] = [];

    // Verificar número de orígenes
    if (this.trustedOrigins.size === 0) {
      violations.push('No hay orígenes de confianza configurados');
    }

    if (this.trustedOrigins.size > 10) {
      recommendations.push('Considerar reducir el número de orígenes de confianza');
    }

    // Verificar HTTPS en producción
    if (process.env.NODE_ENV === 'production') {
      for (const [origin, validation] of this.trustedOrigins) {
        if (!validation.secure && !origin.startsWith('https://')) {
          violations.push(`Origen sin HTTPS en producción: ${origin}`);
        }
      }
    }

    // Verificar wildcard
    const hasWildcard = Array.from(this.trustedOrigins.keys()).some(origin => 
      origin.includes('*') || origin === 'null'
    );

    if (hasWildcard) {
      violations.push('Uso de wildcards en orígenes de confianza');
    }

    return {
      isSecure: violations.length === 0,
      violations,
      recommendations
    };
  }

  /**
   * Log de eventos de seguridad
   */
  private logSecurityEvent(event: string, details: any): void {
    const securityEvent = {
      timestamp: new Date().toISOString(),
      event,
      details,
      source: 'SecureCORSManager'
    };

    console.warn('🚨 CORS Security Event:', securityEvent);

    // Integrar con sistema de alertas si existe
    if (typeof window === 'undefined') {
      // En servidor - enviar a sistema de logging
      try {
        // Integrar con SecurityAlertingSystem si está disponible
        const { securityAlertingSystem } = require('./SecurityAlertingSystem');
        securityAlertingSystem.processSecurityEvent({
          type: 'cors_violation',
          ...details,
          source: 'SecureCORSManager'
        });
      } catch (error) {
        // Sistema de alertas no disponible
      }
    }
  }

  /**
   * Generar configuración para diferentes entornos
   */
  generateEnvironmentConfig(environment: 'development' | 'staging' | 'production'): string {
    const envOrigins = Array.from(this.trustedOrigins.entries())
      .filter(([, validation]) => validation.environment === environment)
      .map(([origin]) => origin);

    return `# CORS Configuration for ${environment.toUpperCase()}
# Generated by SecureCORSManager

CORS_ALLOWED_ORIGINS=${envOrigins.join(',')}
CORS_ALLOW_CREDENTIALS=true
CORS_MAX_AGE=86400
CORS_STRICT_MODE=${environment === 'production'}

# Security Headers
X_FRAME_OPTIONS=DENY
X_CONTENT_TYPE_OPTIONS=nosniff
X_XSS_PROTECTION=1; mode=block
REFERRER_POLICY=strict-origin-when-cross-origin

# HTTPS Configuration (Production)
${environment === 'production' ? 'FORCE_HTTPS=true\nHSTS_MAX_AGE=31536000' : '# HTTPS not enforced in development'}
`;
  }
}

// Export singleton instance
export const secureCORSManager = SecureCORSManager.getInstance();
export default SecureCORSManager;
