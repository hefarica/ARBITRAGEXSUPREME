/**
 * 📦 DEPENDENCY SECURITY MANAGER - ArbitrageX Pro 2025
 * Gestión de seguridad de dependencias NPM y actualizaciones
 */

export interface DependencyVulnerability {
  name: string;
  currentVersion: string;
  vulnerableVersions: string;
  patchedVersion: string;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  cve: string;
  description: string;
  recommendation: string;
}

export interface OutdatedDependency {
  name: string;
  currentVersion: string;
  wantedVersion: string;
  latestVersion: string;
  isBreaking: boolean;
  securityRisk: 'none' | 'low' | 'medium' | 'high';
  updatePriority: 'low' | 'medium' | 'high' | 'critical';
}

export class DependencySecurityManager {
  private static instance: DependencySecurityManager;
  private vulnerabilities: Map<string, DependencyVulnerability> = new Map();
  private outdatedDeps: Map<string, OutdatedDependency> = new Map();
  private trustedPackages: Set<string> = new Set();
  private blockedPackages: Set<string> = new Set();

  private constructor() {
    this.initializeTrustedPackages();
    this.initializeBlockedPackages();
  }

  public static getInstance(): DependencySecurityManager {
    if (!DependencySecurityManager.instance) {
      DependencySecurityManager.instance = new DependencySecurityManager();
    }
    return DependencySecurityManager.instance;
  }

  /**
   * Inicializar paquetes de confianza
   */
  private initializeTrustedPackages(): void {
    // Core React ecosystem
    this.trustedPackages.add('react');
    this.trustedPackages.add('react-dom');
    this.trustedPackages.add('typescript');

    // Build tools
    this.trustedPackages.add('vite');
    this.trustedPackages.add('@vitejs/plugin-react');
    this.trustedPackages.add('tailwindcss');

    // Security libraries
    this.trustedPackages.add('jsonwebtoken');
    this.trustedPackages.add('bcrypt');
    this.trustedPackages.add('helmet');

    // Blockchain
    this.trustedPackages.add('ethers');
    this.trustedPackages.add('web3');

    // Utilities
    this.trustedPackages.add('axios');
    this.trustedPackages.add('lodash');
    this.trustedPackages.add('date-fns');

    console.log(`🔐 ${this.trustedPackages.size} paquetes de confianza configurados`);
  }

  /**
   * Inicializar paquetes bloqueados
   */
  private initializeBlockedPackages(): void {
    // Paquetes con historial de vulnerabilidades
    this.blockedPackages.add('node-sass'); // Usar sass en su lugar
    this.blockedPackages.add('event-stream'); // Comprometido en 2018
    this.blockedPackages.add('eslint-scope'); // Comprometido en 2018
    this.blockedPackages.add('getcookies'); // Malware
    this.blockedPackages.add('electron-native-notify'); // Malware

    // Paquetes obsoletos
    this.blockedPackages.add('request'); // Deprecado, usar axios
    this.blockedPackages.add('bower'); // Obsoleto
    this.blockedPackages.add('gulp'); // Preferir scripts npm

    console.log(`🚫 ${this.blockedPackages.size} paquetes bloqueados configurados`);
  }

  /**
   * Auditar todas las dependencias
   */
  async auditDependencies(): Promise<{
    vulnerabilities: DependencyVulnerability[];
    outdated: OutdatedDependency[];
    blocked: string[];
    score: number;
    recommendations: string[];
  }> {
    console.log('📦 Iniciando auditoría de dependencias...');

    const results = {
      vulnerabilities: await this.scanVulnerabilities(),
      outdated: await this.scanOutdatedDependencies(),
      blocked: await this.scanBlockedPackages(),
      score: 0,
      recommendations: [] as string[]
    };

    // Calcular puntuación de seguridad
    results.score = this.calculateSecurityScore(results);

    // Generar recomendaciones
    results.recommendations = this.generateRecommendations(results);

    console.log(`📊 Auditoría completada. Puntuación: ${results.score}/100`);

    return results;
  }

  /**
   * Escanear vulnerabilidades conocidas
   */
  private async scanVulnerabilities(): Promise<DependencyVulnerability[]> {
    const vulnerabilities: DependencyVulnerability[] = [];

    try {
      const { execSync } = require('child_process');
      
      // Ejecutar npm audit
      const auditResult = execSync('npm audit --json', { 
        encoding: 'utf8',
        cwd: process.cwd()
      });

      const auditData = JSON.parse(auditResult);

      if (auditData.vulnerabilities) {
        for (const [name, vuln] of Object.entries(auditData.vulnerabilities)) {
          const vulnerability: DependencyVulnerability = {
            name,
            currentVersion: (vuln as any).via[0]?.range || 'unknown',
            vulnerableVersions: (vuln as any).via[0]?.range || 'unknown',
            patchedVersion: (vuln as any).fixAvailable || 'No disponible',
            severity: (vuln as any).severity,
            cve: (vuln as any).via[0]?.source || 'N/A',
            description: (vuln as any).via[0]?.title || 'Sin descripción',
            recommendation: this.getVulnerabilityRecommendation(vuln as any)
          };

          vulnerabilities.push(vulnerability);
          this.vulnerabilities.set(name, vulnerability);
        }
      }

    } catch (error) {
      console.warn('⚠️ Error ejecutando npm audit:', error.message);
    }

    return vulnerabilities;
  }

  /**
   * Escanear dependencias desactualizadas
   */
  private async scanOutdatedDependencies(): Promise<OutdatedDependency[]> {
    const outdated: OutdatedDependency[] = [];

    try {
      const { execSync } = require('child_process');
      
      // Ejecutar npm outdated
      const outdatedResult = execSync('npm outdated --json', { 
        encoding: 'utf8',
        cwd: process.cwd()
      });

      const outdatedData = JSON.parse(outdatedResult);

      for (const [name, info] of Object.entries(outdatedData)) {
        const dep: OutdatedDependency = {
          name,
          currentVersion: (info as any).current,
          wantedVersion: (info as any).wanted,
          latestVersion: (info as any).latest,
          isBreaking: this.isBreakingChange((info as any).current, (info as any).latest),
          securityRisk: this.assessSecurityRisk(name, (info as any).current, (info as any).latest),
          updatePriority: this.getUpdatePriority(name, (info as any))
        };

        outdated.push(dep);
        this.outdatedDeps.set(name, dep);
      }

    } catch (error) {
      // npm outdated retorna exit code 1 cuando hay dependencias desactualizadas
      if (error.status === 1 && error.stdout) {
        try {
          const outdatedData = JSON.parse(error.stdout);
          // Procesar datos como arriba
          for (const [name, info] of Object.entries(outdatedData)) {
            const dep: OutdatedDependency = {
              name,
              currentVersion: (info as any).current,
              wantedVersion: (info as any).wanted,
              latestVersion: (info as any).latest,
              isBreaking: this.isBreakingChange((info as any).current, (info as any).latest),
              securityRisk: this.assessSecurityRisk(name, (info as any).current, (info as any).latest),
              updatePriority: this.getUpdatePriority(name, (info as any))
            };

            outdated.push(dep);
            this.outdatedDeps.set(name, dep);
          }
        } catch (parseError) {
          console.warn('⚠️ Error parseando npm outdated:', parseError.message);
        }
      } else {
        console.warn('⚠️ Error ejecutando npm outdated:', error.message);
      }
    }

    return outdated;
  }

  /**
   * Escanear paquetes bloqueados
   */
  private async scanBlockedPackages(): Promise<string[]> {
    const blocked: string[] = [];

    try {
      const packageJson = require(process.cwd() + '/package.json');
      const allDeps = {
        ...packageJson.dependencies,
        ...packageJson.devDependencies
      };

      for (const pkgName of Object.keys(allDeps)) {
        if (this.blockedPackages.has(pkgName)) {
          blocked.push(pkgName);
          console.warn(`🚫 Paquete bloqueado detectado: ${pkgName}`);
        }
      }

    } catch (error) {
      console.error('Error leyendo package.json:', error);
    }

    return blocked;
  }

  /**
   * Verificar si es un cambio breaking
   */
  private isBreakingChange(current: string, latest: string): boolean {
    try {
      const currentMajor = parseInt(current.split('.')[0]);
      const latestMajor = parseInt(latest.split('.')[0]);
      return latestMajor > currentMajor;
    } catch {
      return false;
    }
  }

  /**
   * Evaluar riesgo de seguridad
   */
  private assessSecurityRisk(name: string, current: string, latest: string): OutdatedDependency['securityRisk'] {
    // Paquetes críticos de seguridad
    const securityCritical = ['jsonwebtoken', 'bcrypt', 'helmet', 'cors', 'express'];
    
    if (securityCritical.includes(name)) {
      return this.isBreakingChange(current, latest) ? 'high' : 'medium';
    }

    // Verificar si hay muchas versiones de diferencia
    const versionDiff = this.getVersionDifference(current, latest);
    
    if (versionDiff.major > 2) return 'high';
    if (versionDiff.major > 1) return 'medium';
    if (versionDiff.minor > 10) return 'medium';
    if (versionDiff.minor > 5) return 'low';
    
    return 'none';
  }

  /**
   * Obtener prioridad de actualización
   */
  private getUpdatePriority(name: string, info: any): OutdatedDependency['updatePriority'] {
    // Prioridad crítica para dependencias con vulnerabilidades conocidas
    if (this.vulnerabilities.has(name)) {
      const vuln = this.vulnerabilities.get(name)!;
      if (vuln.severity === 'critical' || vuln.severity === 'high') {
        return 'critical';
      }
      return 'high';
    }

    // Prioridad alta para herramientas de build
    const buildTools = ['vite', 'typescript', 'tailwindcss', '@vitejs/plugin-react'];
    if (buildTools.includes(name)) {
      return 'medium';
    }

    // Prioridad alta para dependencias de seguridad
    const securityDeps = ['jsonwebtoken', 'bcrypt', 'helmet', 'cors'];
    if (securityDeps.includes(name)) {
      return 'high';
    }

    return 'low';
  }

  /**
   * Calcular diferencia de versiones
   */
  private getVersionDifference(current: string, latest: string): {
    major: number;
    minor: number;
    patch: number;
  } {
    try {
      const currentParts = current.split('.').map(n => parseInt(n));
      const latestParts = latest.split('.').map(n => parseInt(n));

      return {
        major: latestParts[0] - currentParts[0],
        minor: latestParts[1] - currentParts[1],
        patch: latestParts[2] - currentParts[2]
      };
    } catch {
      return { major: 0, minor: 0, patch: 0 };
    }
  }

  /**
   * Obtener recomendación para vulnerabilidad
   */
  private getVulnerabilityRecommendation(vuln: any): string {
    if (vuln.fixAvailable) {
      return `Actualizar a versión ${vuln.fixAvailable}`;
    }
    
    if (vuln.severity === 'critical') {
      return 'CRÍTICO: Considerar reemplazo inmediato del paquete';
    }
    
    return 'Monitorear para parches futuros';
  }

  /**
   * Calcular puntuación de seguridad
   */
  private calculateSecurityScore(results: any): number {
    let score = 100;

    // Penalizar por vulnerabilidades
    for (const vuln of results.vulnerabilities) {
      switch (vuln.severity) {
        case 'critical': score -= 25; break;
        case 'high': score -= 15; break;
        case 'moderate': score -= 10; break;
        case 'low': score -= 5; break;
      }
    }

    // Penalizar por paquetes bloqueados
    score -= results.blocked.length * 20;

    // Penalizar por dependencias muy desactualizadas
    for (const dep of results.outdated) {
      if (dep.securityRisk === 'high') score -= 10;
      if (dep.securityRisk === 'medium') score -= 5;
    }

    return Math.max(0, score);
  }

  /**
   * Generar recomendaciones
   */
  private generateRecommendations(results: any): string[] {
    const recommendations: string[] = [];

    // Vulnerabilidades críticas
    const criticalVulns = results.vulnerabilities.filter((v: any) => v.severity === 'critical');
    if (criticalVulns.length > 0) {
      recommendations.push(`🚨 CRÍTICO: Resolver ${criticalVulns.length} vulnerabilidades críticas inmediatamente`);
    }

    // Paquetes bloqueados
    if (results.blocked.length > 0) {
      recommendations.push(`🚫 Remover ${results.blocked.length} paquetes bloqueados: ${results.blocked.join(', ')}`);
    }

    // Actualizaciones de seguridad
    const securityUpdates = results.outdated.filter((d: any) => d.updatePriority === 'critical' || d.updatePriority === 'high');
    if (securityUpdates.length > 0) {
      recommendations.push(`🔒 Actualizar ${securityUpdates.length} dependencias críticas de seguridad`);
    }

    // Actualizaciones menores
    const minorUpdates = results.outdated.filter((d: any) => !d.isBreaking);
    if (minorUpdates.length > 5) {
      recommendations.push(`⬆️ Considerar actualizar ${minorUpdates.length} dependencias menores`);
    }

    // Automatización
    if (results.outdated.length > 10) {
      recommendations.push('🤖 Configurar Dependabot para actualizaciones automáticas');
    }

    return recommendations;
  }

  /**
   * Generar comando de actualización segura
   */
  generateUpdateCommands(): {
    critical: string[];
    safe: string[];
    risky: string[];
  } {
    const commands = {
      critical: [] as string[],
      safe: [] as string[],
      risky: [] as string[]
    };

    for (const [name, dep] of this.outdatedDeps) {
      if (dep.updatePriority === 'critical') {
        commands.critical.push(`npm install ${name}@${dep.latestVersion}`);
      } else if (!dep.isBreaking && dep.securityRisk === 'none') {
        commands.safe.push(`npm update ${name}`);
      } else {
        commands.risky.push(`npm install ${name}@${dep.latestVersion} # ⚠️ Breaking change`);
      }
    }

    return commands;
  }

  /**
   * Generar reporte de seguridad
   */
  generateSecurityReport(): string {
    const report = `# 📦 Reporte de Seguridad de Dependencias - ArbitrageX Pro 2025

## 📊 Resumen Ejecutivo

| Métrica | Valor |
|---------|-------|
| **Puntuación de Seguridad** | ${this.calculateSecurityScore({ vulnerabilities: Array.from(this.vulnerabilities.values()), outdated: Array.from(this.outdatedDeps.values()), blocked: [] })}/100 |
| **Vulnerabilidades Críticas** | ${Array.from(this.vulnerabilities.values()).filter(v => v.severity === 'critical').length} |
| **Vulnerabilidades Altas** | ${Array.from(this.vulnerabilities.values()).filter(v => v.severity === 'high').length} |
| **Dependencias Desactualizadas** | ${this.outdatedDeps.size} |
| **Paquetes de Confianza** | ${this.trustedPackages.size} |

## 🚨 Vulnerabilidades Detectadas

${Array.from(this.vulnerabilities.values()).map(v => `
### ${v.name}
- **Severidad**: ${v.severity.toUpperCase()}
- **Versión Actual**: ${v.currentVersion}
- **Versión Corregida**: ${v.patchedVersion}
- **CVE**: ${v.cve}
- **Descripción**: ${v.description}
- **Recomendación**: ${v.recommendation}
`).join('\n')}

## ⬆️ Actualizaciones Recomendadas

### Críticas (Actualizar Inmediatamente)
${Array.from(this.outdatedDeps.values()).filter(d => d.updatePriority === 'critical').map(d => `
- **${d.name}**: ${d.currentVersion} → ${d.latestVersion}
`).join('\n')}

### Seguridad (Actualizar Pronto)
${Array.from(this.outdatedDeps.values()).filter(d => d.updatePriority === 'high').map(d => `
- **${d.name}**: ${d.currentVersion} → ${d.latestVersion}
`).join('\n')}

## 🛠️ Comandos de Actualización

\`\`\`bash
# Actualizaciones críticas
${this.generateUpdateCommands().critical.join('\n')}

# Actualizaciones seguras
${this.generateUpdateCommands().safe.join('\n')}
\`\`\`

---
*Reporte generado el ${new Date().toISOString()} por DependencySecurityManager*
`;

    return report;
  }
}

// Export singleton instance
export const dependencySecurityManager = DependencySecurityManager.getInstance();
export default DependencySecurityManager;
