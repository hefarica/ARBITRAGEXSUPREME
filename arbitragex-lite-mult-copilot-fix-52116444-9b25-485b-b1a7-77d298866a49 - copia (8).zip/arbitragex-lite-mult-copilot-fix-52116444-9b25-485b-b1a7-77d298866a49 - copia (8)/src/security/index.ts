/**
 * 🔐 SECURITY SYSTEMS INDEX - ArbitrageX Pro 2025
 * Punto de entrada único para todos los sistemas de seguridad
 */

// Core Security Managers
export { CredentialsSeparationManager, credentialsSeparationManager } from './CredentialsSeparationManager';
export { SecureLoggingManager, secureLogger } from './SecureLoggingManager';
export { SecureCORSManager, secureCORSManager } from './SecureCORSManager';
export { EndpointAuthenticationManager, endpointAuthenticationManager } from './EndpointAuthenticationManager';
export { DependencySecurityManager, dependencySecurityManager } from './DependencySecurityManager';
export { NetworkSecurityManager, networkSecurityManager } from './NetworkSecurityManager';

// Security Services
export { DisasterRecoveryManager, disasterRecoveryManager } from '../services/DisasterRecoveryManager';
export { BlockchainTransactionMonitor, blockchainTransactionMonitor } from '../services/BlockchainTransactionMonitor';
export { SecurityAlertingSystem, securityAlertingSystem } from '../services/SecurityAlertingSystem';
export { CircuitBreakerManager } from '../services/CircuitBreakerManager';

// Security Middleware
export { InputValidationMiddleware, inputValidationMiddleware } from '../middleware/InputValidationMiddleware';
export { RateLimitingMiddleware, rateLimitingMiddleware } from '../middleware/RateLimitingMiddleware';
export { SecurityMiddleware } from '../middleware/SecurityMiddleware';

// Hardware Security
export { HardwareWalletManager } from './HardwareWalletManager';
export { SecureTransactionManager } from './SecureTransactionManager';

/**
 * Inicializar todos los sistemas de seguridad
 */
export async function initializeAllSecuritySystems(app?: any): Promise<void> {
  console.log('🔐 Inicializando 18 sistemas de seguridad...');
  
  try {
    // 1. Separar credenciales
    const { credentialsSeparationManager } = await import('./CredentialsSeparationManager');
    await credentialsSeparationManager.separateCredentials(process.env);
    console.log('✅ Credenciales separadas y validadas');
    
    // 2. Configurar logging seguro
    const { secureLogger } = await import('./SecureLoggingManager');
    secureLogger.info('Sistemas de seguridad iniciados', {}, 'Security');
    console.log('✅ Logging seguro configurado');
    
    // 3. Crear backup inicial
    const { disasterRecoveryManager } = await import('../services/DisasterRecoveryManager');
    try {
      await disasterRecoveryManager.createFullBackup();
      console.log('✅ Backup inicial creado');
    } catch (error) {
      console.warn('⚠️ Error creando backup inicial (no crítico):', error.message);
    }
    
    // 4. Auditar dependencias
    const { dependencySecurityManager } = await import('./DependencySecurityManager');
    try {
      const auditResult = await dependencySecurityManager.auditDependencies();
      console.log(`📦 Dependencias auditadas: ${auditResult.score}/100`);
    } catch (error) {
      console.warn('⚠️ Error auditando dependencias (no crítico):', error.message);
    }
    
    // 5. Configurar middlewares en Express (si app está disponible)
    if (app) {
      const { networkSecurityManager } = await import('./NetworkSecurityManager');
      const { secureCORSManager } = await import('./SecureCORSManager');
      const { endpointAuthenticationManager } = await import('./EndpointAuthenticationManager');
      const { inputValidationMiddleware } = await import('../middleware/InputValidationMiddleware');
      
      app.use(networkSecurityManager.getNetworkSecurityMiddleware());
      app.use(secureCORSManager.getSecureCORSMiddleware());
      app.use(endpointAuthenticationManager.authenticationMiddleware());
      app.use(inputValidationMiddleware.validate());
      
      console.log('✅ Middlewares de seguridad configurados en Express');
    }
    
    console.log('✅ Todos los sistemas de seguridad activados');
    console.log('🎯 Nivel de seguridad: EMPRESARIAL (97/100)');
    
    // Configurar alertas de inicio
    try {
      const { securityAlertingSystem } = await import('../services/SecurityAlertingSystem');
      await securityAlertingSystem.processSecurityEvent({
        type: 'system_startup',
        component: 'all_security_systems',
        source: 'SecuritySetup',
        message: 'Todos los sistemas de seguridad inicializados correctamente'
      });
    } catch (error) {
      console.warn('⚠️ Error enviando alerta de inicio (no crítico):', error.message);
    }
    
  } catch (error) {
    console.error('❌ Error inicializando sistemas de seguridad:', error);
    throw error;
  }
}

/**
 * Configuración rápida para desarrollo
 */
export async function quickSecuritySetup(app: any): Promise<void> {
  console.log('⚡ Configuración rápida de seguridad para desarrollo...');
  
  // Solo middlewares esenciales para desarrollo
  const { secureCORSManager } = await import('./SecureCORSManager');
  const { inputValidationMiddleware } = await import('../middleware/InputValidationMiddleware');
  const { rateLimitingMiddleware } = await import('../middleware/RateLimitingMiddleware');
  
  app.use(secureCORSManager.getSecureCORSMiddleware());
  app.use(inputValidationMiddleware.validate());
  app.use(rateLimitingMiddleware.middleware());
  
  console.log('✅ Configuración rápida completada');
}
