import { SecurityModule, ModuleAuditResult, SecurityError, JWTConfig, JWTPayload } from '../types/security'
import crypto from 'crypto'

/**
 * JWT Security Module with RS256 - IMMUTABLE SECURITY CORE
 * ⚠️ CRITICAL: Only RS256 algorithm is permitted for security compliance
 * ALL OPERATIONS ARE AUDITED AND LOGGED
 */
export class JWTSecurityModule implements SecurityModule {
  private config: JWTConfig
  private privateKey: string
  private publicKey: string
  private keyRotationTimer?: NodeJS.Timer
  private initialized: boolean = false
  private auditLog: any[] = []

  constructor() {
    // Initialize with secure defaults
  }

  async initialize(config: JWTConfig): Promise<void> {
    try {
      // VERIFICACIÓN CRÍTICA: Solo RS256 permitido
      if (config.algorithm !== 'RS256') {
        throw new SecurityError('CRITICAL_JWT_ALGORITHM_VIOLATION', 
          'Only RS256 algorithm is permitted for JWT signing')
      }

      this.config = {
        ...config,
        issuer: config.issuer || 'arbitragex-pro-2',
        audience: config.audience || 'arbitragex-trading-platform'
      }

      // Generar par de claves RSA-4096
      await this.generateRSAKeyPair()

      // Configurar rotación automática de claves
      this.setupKeyRotation(config.keyRotationInterval)

      // Verificar integridad del módulo
      await this.verifySelfIntegrity()

      this.initialized = true

      await this.logSecurityEvent('JWT_MODULE_INITIALIZED', {
        algorithm: config.algorithm,
        keyRotationInterval: config.keyRotationInterval,
        tokenLifetime: config.tokenLifetime
      })

    } catch (error) {
      await this.logSecurityEvent('JWT_INITIALIZATION_FAILED', { error: error.message })
      throw new SecurityError('JWT_INIT_FAILED', 'Failed to initialize JWT module', error)
    }
  }

  async performSelfAudit(): Promise<ModuleAuditResult> {
    const startTime = performance.now()
    const memoryBefore = process.memoryUsage()

    const auditResult: ModuleAuditResult = {
      moduleName: 'JWTSecurityModule',
      timestamp: Date.now(),
      passed: true,
      failures: [],
      warnings: [],
      recommendations: [],
      performance: {
        responseTime: 0,
        memoryUsage: 0,
        cpuUsage: 0
      }
    }

    try {
      // Verificar algoritmo correcto
      if (this.config.algorithm !== 'RS256') {
        auditResult.passed = false
        auditResult.failures.push({
          module: 'JWT',
          severity: 'CRITICAL',
          message: 'Invalid JWT algorithm detected',
          details: { algorithm: this.config.algorithm }
        })
      }

      // Verificar existencia de claves
      if (!this.privateKey || !this.publicKey) {
        auditResult.passed = false
        auditResult.failures.push({
          module: 'JWT',
          severity: 'CRITICAL',
          message: 'Missing RSA key pair',
          details: { hasPrivateKey: !!this.privateKey, hasPublicKey: !!this.publicKey }
        })
      }

      // Verificar tamaño de clave
      const keySize = await this.getKeySize()
      if (keySize < 4096) {
        auditResult.warnings.push({
          module: 'JWT',
          message: 'RSA key size below recommended 4096 bits',
          details: { keySize },
          severity: 'HIGH'
        })
      }

      // Verificar configuración de rotación
      if (!this.keyRotationTimer) {
        auditResult.warnings.push({
          module: 'JWT',
          message: 'Key rotation not configured',
          details: {},
          severity: 'MEDIUM'
        })
      }

      // Test de generación/verificación de token
      await this.performTokenTest()

    } catch (error) {
      auditResult.passed = false
      auditResult.failures.push({
        module: 'JWT',
        severity: 'CRITICAL',
        message: 'JWT audit test failed',
        details: { error: error.message }
      })
    }

    // Calcular métricas de performance
    const endTime = performance.now()
    const memoryAfter = process.memoryUsage()

    auditResult.performance = {
      responseTime: endTime - startTime,
      memoryUsage: memoryAfter.heapUsed - memoryBefore.heapUsed,
      cpuUsage: process.cpuUsage().user / 1000000 // Convert to ms
    }

    return auditResult
  }

  async validateModule(): Promise<boolean> {
    try {
      return this.initialized && 
             !!this.privateKey && 
             !!this.publicKey && 
             this.config.algorithm === 'RS256'
    } catch {
      return false
    }
  }

  getModuleName(): string {
    return 'JWTSecurityModule'
  }

  getModuleVersion(): string {
    return '2.0.0'
  }

  async isHealthy(): Promise<boolean> {
    try {
      // Realizar test rápido de funcionalidad
      const testPayload = { test: true, timestamp: Date.now() }
      const token = await this.signToken(testPayload as any)
      const verified = await this.verifyToken(token)
      return !!verified
    } catch {
      return false
    }
  }

  /**
   * GENERACIÓN DE PAR DE CLAVES RSA-4096
   */
  private async generateRSAKeyPair(): Promise<void> {
    try {
      const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
        modulusLength: 4096,
        publicKeyEncoding: {
          type: 'spki',
          format: 'pem'
        },
        privateKeyEncoding: {
          type: 'pkcs8',
          format: 'pem'
        }
      })

      this.privateKey = privateKey
      this.publicKey = publicKey

      await this.logSecurityEvent('RSA_KEYPAIR_GENERATED', {
        keySize: 4096,
        algorithm: 'RSA',
        format: 'PEM'
      })

    } catch (error) {
      throw new SecurityError('RSA_KEYGEN_FAILED', 'Failed to generate RSA key pair', error)
    }
  }

  /**
   * FIRMADO DE TOKEN JWT CON RS256
   */
  async signToken(payload: JWTPayload): Promise<string> {
    if (!this.initialized) {
      throw new SecurityError('JWT_NOT_INITIALIZED', 'JWT module not initialized')
    }

    try {
      // Validar payload
      this.validatePayload(payload)

      // Agregar claims de seguridad obligatorios
      const securePayload = {
        ...payload,
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + (this.config.tokenLifetime * 60),
        jti: crypto.randomUUID(),
        aud: this.config.audience,
        iss: this.config.issuer,
        // Claim de integridad
        integrity: await this.calculatePayloadIntegrity(payload)
      }

      // Crear header JWT
      const header = {
        alg: 'RS256',
        typ: 'JWT',
        kid: await this.getKeyId()
      }

      // Encode header and payload
      const encodedHeader = Buffer.from(JSON.stringify(header)).toString('base64url')
      const encodedPayload = Buffer.from(JSON.stringify(securePayload)).toString('base64url')
      
      // Create signature
      const signingInput = `${encodedHeader}.${encodedPayload}`
      const signature = crypto.sign('RSA-SHA256', Buffer.from(signingInput), this.privateKey)
      const encodedSignature = signature.toString('base64url')

      const jwt = `${encodedHeader}.${encodedPayload}.${encodedSignature}`

      await this.logSecurityEvent('JWT_TOKEN_SIGNED', {
        userId: payload.sub,
        sessionId: payload.sessionId,
        expiresIn: this.config.tokenLifetime
      })

      return jwt

    } catch (error) {
      await this.logSecurityEvent('JWT_SIGNING_FAILED', { error: error.message })
      throw new SecurityError('JWT_SIGNING_FAILED', 'Failed to sign JWT token', error)
    }
  }

  /**
   * VERIFICACIÓN DE TOKEN JWT
   */
  async verifyToken(token: string): Promise<JWTPayload> {
    if (!this.initialized) {
      throw new SecurityError('JWT_NOT_INITIALIZED', 'JWT module not initialized')
    }

    try {
      const parts = token.split('.')
      if (parts.length !== 3) {
        throw new SecurityError('INVALID_JWT_FORMAT', 'Invalid JWT format')
      }

      const [encodedHeader, encodedPayload, encodedSignature] = parts

      // Decode header
      const header = JSON.parse(Buffer.from(encodedHeader, 'base64url').toString())
      
      // Verificar algoritmo
      if (header.alg !== 'RS256') {
        throw new SecurityError('INVALID_JWT_ALGORITHM', 'Invalid JWT algorithm')
      }

      // Verificar firma
      const signingInput = `${encodedHeader}.${encodedPayload}`
      const signature = Buffer.from(encodedSignature, 'base64url')
      
      const isValid = crypto.verify('RSA-SHA256', Buffer.from(signingInput), this.publicKey, signature)
      
      if (!isValid) {
        throw new SecurityError('INVALID_JWT_SIGNATURE', 'Invalid JWT signature')
      }

      // Decode payload
      const payload = JSON.parse(Buffer.from(encodedPayload, 'base64url').toString())

      // Verificar claims obligatorios
      await this.verifyClaims(payload)

      // Verificar integridad del payload
      await this.verifyPayloadIntegrity(payload)

      await this.logSecurityEvent('JWT_TOKEN_VERIFIED', {
        userId: payload.sub,
        sessionId: payload.sessionId
      })

      return payload as JWTPayload

    } catch (error) {
      await this.logSecurityEvent('JWT_VERIFICATION_FAILED', { 
        error: error.message,
        token: token.substring(0, 50) + '...' // Log solo parte del token por seguridad
      })
      throw new SecurityError('JWT_VERIFICATION_FAILED', 'JWT verification failed', error)
    }
  }

  /**
   * ROTACIÓN DE CLAVES AUTOMÁTICA
   */
  private setupKeyRotation(intervalHours: number): void {
    if (intervalHours <= 0) return

    this.keyRotationTimer = setInterval(async () => {
      try {
        await this.rotateKeys()
        await this.logSecurityEvent('KEY_ROTATION_SUCCESS', { intervalHours })
      } catch (error) {
        await this.logSecurityEvent('KEY_ROTATION_FAILED', { error: error.message })
        // Enviar alerta crítica
        console.error('🚨 CRITICAL: JWT Key rotation failed', error)
      }
    }, intervalHours * 60 * 60 * 1000)
  }

  private async rotateKeys(): Promise<void> {
    const oldPublicKey = this.publicKey
    
    // Generar nuevo par de claves
    await this.generateRSAKeyPair()
    
    // TODO: Notificar a otros servicios sobre nueva clave pública
    // En producción, esto debería actualizar el key store distribuido
    
    await this.logSecurityEvent('KEY_ROTATION_COMPLETED', {
      oldKeyId: await this.calculateKeyId(oldPublicKey),
      newKeyId: await this.getKeyId()
    })
  }

  /**
   * VALIDACIONES Y UTILIDADES
   */
  private validatePayload(payload: any): void {
    if (!payload.sub) {
      throw new SecurityError('MISSING_JWT_SUBJECT', 'JWT payload missing subject (sub)')
    }
    if (!payload.sessionId) {
      throw new SecurityError('MISSING_SESSION_ID', 'JWT payload missing session ID')
    }
  }

  private async verifyClaims(payload: any): Promise<void> {
    const now = Math.floor(Date.now() / 1000)

    // Verificar expiración
    if (payload.exp && payload.exp < now) {
      throw new SecurityError('JWT_EXPIRED', 'JWT token has expired')
    }

    // Verificar issued at
    if (payload.iat && payload.iat > now + 300) { // 5 min tolerance
      throw new SecurityError('JWT_FUTURE_ISSUED', 'JWT issued in the future')
    }

    // Verificar audience
    if (payload.aud !== this.config.audience) {
      throw new SecurityError('INVALID_JWT_AUDIENCE', 'Invalid JWT audience')
    }

    // Verificar issuer
    if (payload.iss !== this.config.issuer) {
      throw new SecurityError('INVALID_JWT_ISSUER', 'Invalid JWT issuer')
    }
  }

  private async calculatePayloadIntegrity(payload: any): Promise<string> {
    const payloadString = JSON.stringify(payload, Object.keys(payload).sort())
    return crypto.createHash('sha256').update(payloadString).digest('hex')
  }

  private async verifyPayloadIntegrity(payload: any): Promise<void> {
    if (!payload.integrity) return // Optional integrity check

    const expectedIntegrity = await this.calculatePayloadIntegrity(
      Object.fromEntries(Object.entries(payload).filter(([key]) => key !== 'integrity'))
    )

    if (payload.integrity !== expectedIntegrity) {
      throw new SecurityError('JWT_INTEGRITY_VIOLATION', 'JWT payload integrity check failed')
    }
  }

  private async getKeyId(): Promise<string> {
    return this.calculateKeyId(this.publicKey)
  }

  private async calculateKeyId(publicKey: string): Promise<string> {
    return crypto.createHash('sha256').update(publicKey).digest('hex').substring(0, 16)
  }

  private async getKeySize(): Promise<number> {
    // Estimar tamaño de clave basado en la longitud del PEM
    const keyContent = this.publicKey.replace(/-----[^-]+-----/g, '').replace(/\s/g, '')
    const keyBytes = Buffer.from(keyContent, 'base64').length
    return Math.floor(keyBytes * 8 / 1.25) // Aproximación
  }

  private async performTokenTest(): Promise<void> {
    const testPayload: JWTPayload = {
      sub: 'test-user',
      aud: this.config.audience,
      iss: this.config.issuer,
      exp: Math.floor(Date.now() / 1000) + 3600,
      iat: Math.floor(Date.now() / 1000),
      jti: crypto.randomUUID(),
      scope: ['read'],
      sessionId: 'test-session'
    }

    const token = await this.signToken(testPayload)
    const verified = await this.verifyToken(token)

    if (verified.sub !== testPayload.sub) {
      throw new Error('Token test failed: subject mismatch')
    }
  }

  private async verifySelfIntegrity(): Promise<void> {
    // Verificar que el módulo no ha sido comprometido
    const expectedMethods = ['signToken', 'verifyToken', 'generateRSAKeyPair']
    for (const method of expectedMethods) {
      if (typeof (this as any)[method] !== 'function') {
        throw new SecurityError('MODULE_INTEGRITY_VIOLATION', `Missing critical method: ${method}`)
      }
    }
  }

  private async logSecurityEvent(event: string, details: any): Promise<void> {
    const logEntry = {
      timestamp: Date.now(),
      module: 'JWTSecurityModule',
      event,
      details
    }

    this.auditLog.push(logEntry)

    // Mantener solo los últimos 1000 eventos
    if (this.auditLog.length > 1000) {
      this.auditLog = this.auditLog.slice(-1000)
    }

    // En desarrollo, log a consola
    if (process.env.NODE_ENV === 'development') {
      console.log(`🔑 JWT Event: ${event}`, details)
    }
  }

  // Limpiar recursos al destruir
  destroy(): void {
    if (this.keyRotationTimer) {
      clearInterval(this.keyRotationTimer)
      this.keyRotationTimer = undefined
    }
    
    // Secure delete de claves (simulado)
    this.privateKey = ''
    this.publicKey = ''
    this.initialized = false
  }
}

export default JWTSecurityModule