/**
 * 🔐 HARDWARE WALLET MANAGER - ArbitrageX Pro 2025
 * Gestión segura de claves privadas usando hardware wallets
 */

import { ethers } from 'ethers';

export interface HardwareWalletConfig {
  type: 'ledger' | 'trezor' | 'metamask' | 'walletconnect';
  derivationPath: string;
  chainId: number;
  requireConfirmation: boolean;
  timeout: number;
}

export interface WalletInfo {
  address: string;
  type: string;
  connected: boolean;
  chainId: number;
  balance?: string;
}

export interface SigningRequest {
  id: string;
  type: 'transaction' | 'message';
  data: any;
  timestamp: number;
  approved?: boolean;
}

export class HardwareWalletManager {
  private static instance: HardwareWalletManager;
  private wallets: Map<string, any> = new Map();
  private activeWallet: string | null = null;
  private signingRequests: Map<string, SigningRequest> = new Map();

  private constructor() {}

  public static getInstance(): HardwareWalletManager {
    if (!HardwareWalletManager.instance) {
      HardwareWalletManager.instance = new HardwareWalletManager();
    }
    return HardwareWalletManager.instance;
  }

  /**
   * Detectar hardware wallets disponibles
   */
  async detectAvailableWallets(): Promise<string[]> {
    const available: string[] = [];

    try {
      // Detectar MetaMask
      if (typeof window !== 'undefined' && (window as any).ethereum) {
        if ((window as any).ethereum.isMetaMask) {
          available.push('metamask');
        }
      }

      // Detectar Ledger (requiere @ledgerhq/hw-transport-webusb)
      try {
        const { default: TransportWebUSB } = await import('@ledgerhq/hw-transport-webusb');
        const transport = await TransportWebUSB.create();
        await transport.close();
        available.push('ledger');
      } catch (error) {
        console.log('Ledger no disponible:', error.message);
      }

      // Detectar Trezor
      try {
        if (typeof window !== 'undefined' && (window as any).TrezorConnect) {
          available.push('trezor');
        }
      } catch (error) {
        console.log('Trezor no disponible:', error.message);
      }

      // Detectar WalletConnect
      try {
        const { default: WalletConnect } = await import('@walletconnect/client');
        available.push('walletconnect');
      } catch (error) {
        console.log('WalletConnect no disponible:', error.message);
      }

    } catch (error) {
      console.error('Error detectando wallets:', error);
    }

    return available;
  }

  /**
   * Conectar con MetaMask
   */
  async connectMetaMask(): Promise<WalletInfo> {
    if (typeof window === 'undefined' || !(window as any).ethereum) {
      throw new Error('MetaMask no está instalado');
    }

    try {
      const provider = new ethers.BrowserProvider((window as any).ethereum);
      
      // Solicitar conexión
      await (window as any).ethereum.request({ method: 'eth_requestAccounts' });
      
      const signer = await provider.getSigner();
      const address = await signer.getAddress();
      const network = await provider.getNetwork();
      const balance = await provider.getBalance(address);

      const walletInfo: WalletInfo = {
        address,
        type: 'metamask',
        connected: true,
        chainId: Number(network.chainId),
        balance: ethers.formatEther(balance)
      };

      this.wallets.set('metamask', {
        provider,
        signer,
        info: walletInfo
      });

      this.activeWallet = 'metamask';

      console.log('✅ MetaMask conectado:', address);
      return walletInfo;

    } catch (error) {
      console.error('❌ Error conectando MetaMask:', error);
      throw error;
    }
  }

  /**
   * Conectar con Ledger
   */
  async connectLedger(derivationPath: string = "m/44'/60'/0'/0/0"): Promise<WalletInfo> {
    try {
      const { default: TransportWebUSB } = await import('@ledgerhq/hw-transport-webusb');
      const { default: AppEth } = await import('@ledgerhq/hw-app-eth');
      
      const transport = await TransportWebUSB.create();
      const eth = new AppEth(transport);
      
      // Obtener dirección
      const result = await eth.getAddress(derivationPath);
      const address = result.address;

      // Crear provider personalizado para Ledger
      const ledgerProvider = new LedgerProvider(eth, derivationPath);

      const walletInfo: WalletInfo = {
        address,
        type: 'ledger',
        connected: true,
        chainId: 1, // Default to Ethereum
      };

      this.wallets.set('ledger', {
        transport,
        eth,
        provider: ledgerProvider,
        info: walletInfo,
        derivationPath
      });

      this.activeWallet = 'ledger';

      console.log('✅ Ledger conectado:', address);
      return walletInfo;

    } catch (error) {
      console.error('❌ Error conectando Ledger:', error);
      throw error;
    }
  }

  /**
   * Conectar con Trezor
   */
  async connectTrezor(derivationPath: string = "m/44'/60'/0'/0/0"): Promise<WalletInfo> {
    try {
      // Cargar Trezor Connect
      if (typeof window === 'undefined') {
        throw new Error('Trezor solo funciona en el navegador');
      }

      const TrezorConnect = (window as any).TrezorConnect;
      if (!TrezorConnect) {
        throw new Error('Trezor Connect no está cargado');
      }

      // Inicializar Trezor Connect
      await TrezorConnect.init({
        lazyLoad: true,
        manifest: {
          email: 'dev@arbitragex.pro',
          appUrl: 'https://arbitragex.pro'
        }
      });

      // Obtener dirección
      const result = await TrezorConnect.ethereumGetAddress({
        path: derivationPath,
        showOnTrezor: true
      });

      if (!result.success) {
        throw new Error(result.payload.error);
      }

      const address = result.payload.address;

      const walletInfo: WalletInfo = {
        address,
        type: 'trezor',
        connected: true,
        chainId: 1,
      };

      this.wallets.set('trezor', {
        trezorConnect: TrezorConnect,
        info: walletInfo,
        derivationPath
      });

      this.activeWallet = 'trezor';

      console.log('✅ Trezor conectado:', address);
      return walletInfo;

    } catch (error) {
      console.error('❌ Error conectando Trezor:', error);
      throw error;
    }
  }

  /**
   * Conectar con WalletConnect
   */
  async connectWalletConnect(): Promise<WalletInfo> {
    try {
      const { default: WalletConnect } = await import('@walletconnect/client');
      const { default: QRCodeModal } = await import('@walletconnect/qrcode-modal');

      const connector = new WalletConnect({
        bridge: "https://bridge.walletconnect.org",
        qrcodeModal: QRCodeModal,
      });

      if (!connector.connected) {
        await connector.createSession();
      }

      return new Promise((resolve, reject) => {
        connector.on("connect", (error, payload) => {
          if (error) {
            reject(error);
            return;
          }

          const { accounts, chainId } = payload.params[0];
          const address = accounts[0];

          const walletInfo: WalletInfo = {
            address,
            type: 'walletconnect',
            connected: true,
            chainId,
          };

          this.wallets.set('walletconnect', {
            connector,
            info: walletInfo
          });

          this.activeWallet = 'walletconnect';

          console.log('✅ WalletConnect conectado:', address);
          resolve(walletInfo);
        });

        connector.on("session_request", (error, payload) => {
          if (error) {
            reject(error);
          }
        });
      });

    } catch (error) {
      console.error('❌ Error conectando WalletConnect:', error);
      throw error;
    }
  }

  /**
   * Firmar transacción con hardware wallet
   */
  async signTransaction(transaction: any): Promise<string> {
    if (!this.activeWallet) {
      throw new Error('No hay wallet conectado');
    }

    const wallet = this.wallets.get(this.activeWallet);
    if (!wallet) {
      throw new Error('Wallet no encontrado');
    }

    // Crear request de firma
    const requestId = this.generateRequestId();
    const signingRequest: SigningRequest = {
      id: requestId,
      type: 'transaction',
      data: transaction,
      timestamp: Date.now()
    };

    this.signingRequests.set(requestId, signingRequest);

    try {
      let signedTx: string;

      switch (this.activeWallet) {
        case 'metamask':
          signedTx = await this.signWithMetaMask(transaction, wallet);
          break;
        
        case 'ledger':
          signedTx = await this.signWithLedger(transaction, wallet);
          break;
        
        case 'trezor':
          signedTx = await this.signWithTrezor(transaction, wallet);
          break;
        
        case 'walletconnect':
          signedTx = await this.signWithWalletConnect(transaction, wallet);
          break;
        
        default:
          throw new Error(`Wallet type ${this.activeWallet} no soportado`);
      }

      // Marcar request como aprobado
      signingRequest.approved = true;
      
      console.log('✅ Transacción firmada con', this.activeWallet);
      return signedTx;

    } catch (error) {
      console.error('❌ Error firmando transacción:', error);
      throw error;
    } finally {
      this.signingRequests.delete(requestId);
    }
  }

  private async signWithMetaMask(transaction: any, wallet: any): Promise<string> {
    const signer = wallet.signer;
    const signedTx = await signer.signTransaction(transaction);
    return signedTx;
  }

  private async signWithLedger(transaction: any, wallet: any): Promise<string> {
    const eth = wallet.eth;
    const derivationPath = wallet.derivationPath;

    // Serializar transacción para Ledger
    const serializedTx = ethers.Transaction.from(transaction).serialized;
    
    const signature = await eth.signTransaction(
      derivationPath,
      serializedTx
    );

    // Combinar transacción con firma
    const tx = ethers.Transaction.from(transaction);
    tx.signature = {
      r: '0x' + signature.r,
      s: '0x' + signature.s,
      v: signature.v
    };

    return tx.serialized;
  }

  private async signWithTrezor(transaction: any, wallet: any): Promise<string> {
    const TrezorConnect = wallet.trezorConnect;
    const derivationPath = wallet.derivationPath;

    const result = await TrezorConnect.ethereumSignTransaction({
      path: derivationPath,
      transaction: {
        to: transaction.to,
        value: transaction.value || '0x0',
        data: transaction.data || '0x',
        chainId: transaction.chainId,
        nonce: transaction.nonce,
        gasLimit: transaction.gasLimit,
        gasPrice: transaction.gasPrice
      }
    });

    if (!result.success) {
      throw new Error(result.payload.error);
    }

    return result.payload.serializedTx;
  }

  private async signWithWalletConnect(transaction: any, wallet: any): Promise<string> {
    const connector = wallet.connector;

    const result = await connector.sendTransaction(transaction);
    return result;
  }

  /**
   * Obtener wallet activo
   */
  getActiveWallet(): WalletInfo | null {
    if (!this.activeWallet) return null;
    
    const wallet = this.wallets.get(this.activeWallet);
    return wallet ? wallet.info : null;
  }

  /**
   * Desconectar wallet
   */
  async disconnectWallet(type?: string): Promise<void> {
    const walletType = type || this.activeWallet;
    if (!walletType) return;

    const wallet = this.wallets.get(walletType);
    if (!wallet) return;

    try {
      switch (walletType) {
        case 'ledger':
          if (wallet.transport) {
            await wallet.transport.close();
          }
          break;
        
        case 'walletconnect':
          if (wallet.connector) {
            await wallet.connector.killSession();
          }
          break;
      }

      this.wallets.delete(walletType);
      
      if (this.activeWallet === walletType) {
        this.activeWallet = null;
      }

      console.log('✅ Wallet desconectado:', walletType);

    } catch (error) {
      console.error('❌ Error desconectando wallet:', error);
    }
  }

  /**
   * Verificar si hay wallet conectado
   */
  isConnected(): boolean {
    return this.activeWallet !== null && this.wallets.has(this.activeWallet);
  }

  /**
   * Cambiar de wallet activo
   */
  switchWallet(type: string): boolean {
    if (this.wallets.has(type)) {
      this.activeWallet = type;
      console.log('🔄 Cambiado a wallet:', type);
      return true;
    }
    return false;
  }

  /**
   * Obtener balance del wallet activo
   */
  async getBalance(provider: ethers.Provider): Promise<string> {
    const walletInfo = this.getActiveWallet();
    if (!walletInfo) {
      throw new Error('No hay wallet conectado');
    }

    const balance = await provider.getBalance(walletInfo.address);
    return ethers.formatEther(balance);
  }

  private generateRequestId(): string {
    return 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }
}

/**
 * Provider personalizado para Ledger
 */
class LedgerProvider extends ethers.AbstractProvider {
  private ledgerApp: any;
  private derivationPath: string;

  constructor(ledgerApp: any, derivationPath: string) {
    super();
    this.ledgerApp = ledgerApp;
    this.derivationPath = derivationPath;
  }

  async getAddress(): Promise<string> {
    const result = await this.ledgerApp.getAddress(this.derivationPath);
    return result.address;
  }

  // Implementar métodos requeridos por AbstractProvider
  _detectNetwork(): Promise<ethers.Network> {
    throw new Error('Method not implemented.');
  }

  _perform(req: ethers.PerformActionRequest): Promise<any> {
    throw new Error('Method not implemented.');
  }
}

// Export singleton instance
export const hardwareWalletManager = HardwareWalletManager.getInstance();
export default HardwareWalletManager;
