/**
 * 🚨 ENVIRONMENT CONFIGURATION AUDITOR - ArbitrageX Pro 2025
 * Auditor crítico para detectar exposición de credenciales en configuraciones
 */

import fs from 'fs';
import path from 'path';

export interface EnvironmentViolation {
  type: 'VITE_EXPOSURE' | 'HARDCODED_SECRET' | 'INSECURE_PATTERN' | 'PRODUCTION_EXPOSURE';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  variable: string;
  file: string;
  line?: number;
  description: string;
  impact: string;
  recommendation: string;
}

export interface AuditResult {
  totalVariables: number;
  violations: EnvironmentViolation[];
  criticalCount: number;
  highCount: number;
  score: number;
  isProdReady: boolean;
}

export class EnvironmentConfigurationAuditor {
  private static instance: EnvironmentConfigurationAuditor;
  
  // Patrones que NUNCA deben estar en variables VITE_
  private readonly CRITICAL_PATTERNS = [
    'SECRET', 'KEY', 'TOKEN', 'PASSWORD', 'PRIVATE', 'JWT', 'API_KEY',
    'WEBHOOK', 'SIGNING', 'ENCRYPTION', 'CREDENTIAL', 'PRIV', 'PK_',
    'MNEMONIC', 'SEED', 'PHRASE', 'SALT', 'HASH'
  ];

  // Patrones que indican hardcoding inseguro
  private readonly HARDCODED_PATTERNS = [
    /0x[a-fA-F0-9]{64}/, // Private keys
    /[A-Za-z0-9]{32,}/, // API keys largos
    /sk_[a-zA-Z0-9]+/, // Stripe secret keys
    /pk_test_[a-zA-Z0-9]+/, // Test keys
    /[a-zA-Z0-9_-]{20,}\.apps\.googleusercontent\.com/, // Google OAuth
    /xapp-[a-fA-F0-9-]+/, // Binance API
    /Bearer\s+[a-zA-Z0-9_-]+/ // Bearer tokens
  ];

  public static getInstance(): EnvironmentConfigurationAuditor {
    if (!EnvironmentConfigurationAuditor.instance) {
      EnvironmentConfigurationAuditor.instance = new EnvironmentConfigurationAuditor();
    }
    return EnvironmentConfigurationAuditor.instance;
  }

  /**
   * Auditar todas las configuraciones de entorno
   */
  async auditAllEnvironmentConfigurations(): Promise<AuditResult> {
    console.log('🔍 Iniciando auditoría crítica de configuraciones de entorno...');

    const violations: EnvironmentViolation[] = [];
    let totalVariables = 0;

    // Archivos de configuración a auditar
    const configFiles = [
      'config/production.env',
      '.env',
      '.env.example',
      '.env.local',
      '.env.production',
      '.env.development',
      'src/config/serviceConfigs.ts',
      'package.json'
    ];

    for (const file of configFiles) {
      const filePath = path.join(process.cwd(), file);
      if (fs.existsSync(filePath)) {
        const fileViolations = await this.auditConfigFile(filePath, file);
        violations.push(...fileViolations);
        totalVariables += this.countVariablesInFile(filePath);
      }
    }

    // Auditar también archivos TypeScript con configuraciones
    const tsConfigViolations = await this.auditTypeScriptConfigs();
    violations.push(...tsConfigViolations);

    const criticalCount = violations.filter(v => v.severity === 'CRITICAL').length;
    const highCount = violations.filter(v => v.severity === 'HIGH').length;

    const score = this.calculateSecurityScore(violations, totalVariables);
    const isProdReady = criticalCount === 0 && highCount <= 2;

    return {
      totalVariables,
      violations,
      criticalCount,
      highCount,
      score,
      isProdReady
    };
  }

  /**
   * Auditar archivo de configuración específico
   */
  private async auditConfigFile(filePath: string, fileName: string): Promise<EnvironmentViolation[]> {
    const violations: EnvironmentViolation[] = [];
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n');

    lines.forEach((line, index) => {
      const lineNumber = index + 1;
      const trimmedLine = line.trim();

      // Ignorar comentarios y líneas vacías
      if (trimmedLine.startsWith('#') || !trimmedLine.includes('=')) {
        return;
      }

      const [key, value] = trimmedLine.split('=', 2);
      if (!key || !value) return;

      // 🚨 CRÍTICO: Variables VITE_ con contenido sensible
      if (key.startsWith('VITE_')) {
        const isSensitive = this.CRITICAL_PATTERNS.some(pattern => 
          key.toUpperCase().includes(pattern)
        );

        if (isSensitive) {
          violations.push({
            type: 'VITE_EXPOSURE',
            severity: 'CRITICAL',
            variable: key,
            file: fileName,
            line: lineNumber,
            description: `Variable sensible expuesta en frontend con prefijo VITE_`,
            impact: 'Credenciales sensibles accesibles desde el navegador, exposición total',
            recommendation: 'Remover prefijo VITE_ y usar solo en backend'
          });
        }
      }

      // 🔥 CRÍTICO: Hardcoded secrets
      const isHardcoded = this.HARDCODED_PATTERNS.some(pattern => 
        pattern.test(value)
      );

      if (isHardcoded && !value.includes('your_') && !value.includes('tu_')) {
        violations.push({
          type: 'HARDCODED_SECRET',
          severity: 'CRITICAL',
          variable: key,
          file: fileName,
          line: lineNumber,
          description: 'Credencial real hardcodeada en archivo de configuración',
          impact: 'Exposición directa de credenciales, compromiso total si se filtra',
          recommendation: 'Usar placeholders y configurar en producción via HSM/Key Vault'
        });
      }

      // 🟡 ALTO: Patrones inseguros
      if (value.includes('test_') || value.includes('demo_') || value.includes('localhost')) {
        violations.push({
          type: 'INSECURE_PATTERN',
          severity: 'HIGH',
          variable: key,
          file: fileName,
          line: lineNumber,
          description: 'Configuración de desarrollo en archivo de producción',
          impact: 'Posible fuga de datos a servicios de prueba',
          recommendation: 'Configurar endpoints de producción reales'
        });
      }
    });

    return violations;
  }

  /**
   * Auditar configuraciones en archivos TypeScript
   */
  private async auditTypeScriptConfigs(): Promise<EnvironmentViolation[]> {
    const violations: EnvironmentViolation[] = [];
    const configFiles = [
      'src/config/serviceConfigs.ts',
      'src/config/strategies.ts',
      'vite.config.ts'
    ];

    for (const file of configFiles) {
      const filePath = path.join(process.cwd(), file);
      if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, 'utf8');
        
        // Buscar process.env.VITE_ con patrones sensibles
        const viteMatches = content.match(/process\.env\.VITE_[A-Z_]*(SECRET|KEY|TOKEN|PASSWORD|PRIVATE|JWT)[A-Z_]*/g);
        
        if (viteMatches) {
          viteMatches.forEach(match => {
            violations.push({
              type: 'VITE_EXPOSURE',
              severity: 'CRITICAL',
              variable: match,
              file,
              description: 'Variable sensible accedida con VITE_ en código TypeScript',
              impact: 'Credencial expuesta en bundle del frontend',
              recommendation: 'Cambiar a variable sin VITE_ y usar solo en backend'
            });
          });
        }
      }
    }

    return violations;
  }

  /**
   * Contar variables en archivo
   */
  private countVariablesInFile(filePath: string): number {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n');
    return lines.filter(line => {
      const trimmed = line.trim();
      return trimmed.includes('=') && !trimmed.startsWith('#');
    }).length;
  }

  /**
   * Calcular puntuación de seguridad
   */
  private calculateSecurityScore(violations: EnvironmentViolation[], totalVariables: number): number {
    let score = 100;
    
    violations.forEach(violation => {
      switch (violation.severity) {
        case 'CRITICAL':
          score -= 25;
          break;
        case 'HIGH':
          score -= 10;
          break;
        case 'MEDIUM':
          score -= 5;
          break;
        case 'LOW':
          score -= 2;
          break;
      }
    });

    return Math.max(0, score);
  }

  /**
   * Generar reporte de auditoría
   */
  generateAuditReport(result: AuditResult): string {
    const { violations, criticalCount, highCount, score, isProdReady } = result;

    let report = `
# 🚨 AUDITORÍA CRÍTICA DE CONFIGURACIONES - ArbitrageX Pro 2025

## 📊 RESUMEN EJECUTIVO
- **Puntuación de Seguridad**: ${score}/100
- **Listo para Producción**: ${isProdReady ? '✅ SÍ' : '❌ NO'}
- **Violaciones Críticas**: ${criticalCount}
- **Violaciones Altas**: ${highCount}
- **Total Variables**: ${result.totalVariables}

## 🚨 VIOLACIONES CRÍTICAS (${criticalCount})

`;

    const criticalViolations = violations.filter(v => v.severity === 'CRITICAL');
    criticalViolations.forEach((violation, index) => {
      report += `### ${index + 1}. ${violation.variable}
- **Archivo**: ${violation.file}${violation.line ? ` (línea ${violation.line})` : ''}
- **Tipo**: ${violation.type}
- **Descripción**: ${violation.description}
- **Impacto**: ${violation.impact}
- **Recomendación**: ${violation.recommendation}

`;
    });

    report += `
## 🔥 ACCIONES INMEDIATAS REQUERIDAS

`;

    if (criticalCount > 0) {
      report += `
### ❌ DETENER PRODUCCIÓN - ${criticalCount} VIOLACIONES CRÍTICAS

1. **Variables VITE_ con credenciales sensibles**: ${violations.filter(v => v.type === 'VITE_EXPOSURE').length}
   - IMPACTO: Credenciales expuestas en el frontend
   - ACCIÓN: Remover prefijo VITE_ de todas las variables sensibles

2. **Credenciales hardcodeadas**: ${violations.filter(v => v.type === 'HARDCODED_SECRET').length}
   - IMPACTO: Exposición directa de secrets
   - ACCIÓN: Reemplazar con placeholders y usar Key Vault

`;
    }

    report += `
## 🛠️ PLAN DE CORRECCIÓN

### Paso 1: Corregir Variables VITE_
\`\`\`bash
# Variables que DEBEN ser sin VITE_ (solo backend):
ETHEREUM_RPC_URL=...
BINANCE_SECRET_KEY=...
JWT_SECRET=...
TELEGRAM_BOT_TOKEN=...

# Variables que SÍ pueden ser VITE_ (frontend):
VITE_APP_NAME=ArbitrageX
VITE_VERSION=2025.1
VITE_ENVIRONMENT=production
\`\`\`

### Paso 2: Implementar Key Vault
\`\`\`bash
# Usar Azure Key Vault, AWS Secrets Manager o HashiCorp Vault
JWT_SECRET={{KEY_VAULT.JWT_SECRET}}
ENCRYPTION_KEY={{KEY_VAULT.ENCRYPTION_KEY}}
\`\`\`

### Paso 3: Separar Configuraciones
\`\`\`bash
# Crear archivos separados:
.env.frontend    # Solo variables VITE_
.env.backend     # Solo variables sensibles
.env.production  # Referencias a Key Vault
\`\`\`

## 🎯 VERIFICACIÓN DE CORRECCIÓN

Ejecutar después de aplicar correcciones:
\`\`\`bash
npm run security:audit-env
\`\`\`

Debe mostrar: **0 violaciones críticas, 0 violaciones altas**
`;

    return report;
  }

  /**
   * Generar configuración corregida
   */
  generateSecureConfiguration(): string {
    return `# ================================================
# CONFIGURACIÓN SEGURA - ArbitrageX Pro 2025
# ================================================

# ================================================
# 🟢 VARIABLES PÚBLICAS (Frontend - VITE_)
# ================================================
VITE_APP_NAME=ArbitrageX Pro 2025
VITE_VERSION=2025.1
VITE_ENVIRONMENT=production
VITE_API_URL=https://api.arbitragex.pro
VITE_FRONTEND_URL=https://arbitragex.pro

# ================================================
# 🔴 VARIABLES PRIVADAS (Backend - SIN VITE_)
# ================================================

# Blockchain RPC (SIN VITE_)
ETHEREUM_RPC_URL={{KEY_VAULT.ETHEREUM_RPC_URL}}
BINANCE_SECRET_KEY={{KEY_VAULT.BINANCE_SECRET_KEY}}
POLYGON_RPC_URL={{KEY_VAULT.POLYGON_RPC_URL}}

# JWT y Encryption (SIN VITE_)
JWT_SECRET={{KEY_VAULT.JWT_SECRET}}
ENCRYPTION_KEY={{KEY_VAULT.ENCRYPTION_KEY}}

# APIs Externas (SIN VITE_)
COINGECKO_API_KEY={{KEY_VAULT.COINGECKO_API_KEY}}
TELEGRAM_BOT_TOKEN={{KEY_VAULT.TELEGRAM_BOT_TOKEN}}
DISCORD_WEBHOOK_URL={{KEY_VAULT.DISCORD_WEBHOOK_URL}}

# Wallets (SIN VITE_) - Usar Hardware Wallets en producción
TRADING_WALLET_ADDRESS={{HARDWARE_WALLET.ADDRESS}}
# NUNCA hardcodear private keys

# ================================================
# 🔧 CONFIGURACIÓN DEL SISTEMA
# ================================================
NODE_ENV=production
PORT=3002
CORS_ALLOWED_ORIGINS=https://arbitragex.pro,https://www.arbitragex.pro

# ================================================
# 📝 COMANDOS DE CONFIGURACIÓN
# ================================================
# 1. Configurar Key Vault:
#    Azure: az keyvault secret set --vault-name "arbitragex-vault" --name "JWT_SECRET" --value "..."
#    AWS: aws secretsmanager create-secret --name "arbitragex/JWT_SECRET" --secret-string "..."
#
# 2. Verificar configuración:
#    npm run security:audit-env
#
# 3. Probar conectividad:
#    npm run security:test-connections
`;
  }
}

export const environmentConfigurationAuditor = EnvironmentConfigurationAuditor.getInstance();
