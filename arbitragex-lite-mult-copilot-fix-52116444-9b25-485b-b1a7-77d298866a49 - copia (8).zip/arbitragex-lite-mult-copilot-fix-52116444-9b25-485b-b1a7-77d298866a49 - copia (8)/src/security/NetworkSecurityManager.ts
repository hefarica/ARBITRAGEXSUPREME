/**
 * 🌐 NETWORK SECURITY MANAGER - ArbitrageX Pro 2025
 * Gestión completa de seguridad de red y comunicaciones
 */

export interface NetworkSecurityConfig {
  https: {
    enforced: boolean;
    redirectHttp: boolean;
    hstsMaxAge: number;
    hstsIncludeSubdomains: boolean;
    hstsPreload: boolean;
  };
  tls: {
    minVersion: '1.2' | '1.3';
    cipherSuites: string[];
    preferServerCiphers: boolean;
    certificateTransparency: boolean;
  };
  firewall: {
    enabled: boolean;
    allowedPorts: number[];
    blockedIPs: string[];
    allowedIPs: string[];
    geoBlocking: string[];
  };
  ddos: {
    protection: boolean;
    maxConnections: number;
    connectionTimeout: number;
    slowLorisProtection: boolean;
  };
  proxy: {
    trustProxy: boolean;
    trustedProxies: string[];
    forwardedHeaders: string[];
  };
}

export interface SecurityHeaders {
  'Strict-Transport-Security': string;
  'Content-Security-Policy': string;
  'X-Frame-Options': string;
  'X-Content-Type-Options': string;
  'X-XSS-Protection': string;
  'Referrer-Policy': string;
  'Permissions-Policy': string;
  'Cross-Origin-Embedder-Policy': string;
  'Cross-Origin-Opener-Policy': string;
  'Cross-Origin-Resource-Policy': string;
}

export class NetworkSecurityManager {
  private static instance: NetworkSecurityManager;
  private config: NetworkSecurityConfig;
  private securityHeaders: SecurityHeaders;
  private blockedIPs: Set<string> = new Set();
  private connectionCounts: Map<string, number> = new Map();

  private constructor() {
    this.config = this.generateSecureNetworkConfig();
    this.securityHeaders = this.generateSecurityHeaders();
    this.initializeFirewallRules();
    this.startConnectionMonitoring();
  }

  public static getInstance(): NetworkSecurityManager {
    if (!NetworkSecurityManager.instance) {
      NetworkSecurityManager.instance = new NetworkSecurityManager();
    }
    return NetworkSecurityManager.instance;
  }

  /**
   * Generar configuración de red segura
   */
  private generateSecureNetworkConfig(): NetworkSecurityConfig {
    const isProduction = process.env.NODE_ENV === 'production';

    return {
      https: {
        enforced: isProduction,
        redirectHttp: isProduction,
        hstsMaxAge: 31536000, // 1 año
        hstsIncludeSubdomains: true,
        hstsPreload: isProduction
      },
      tls: {
        minVersion: '1.3',
        cipherSuites: [
          'TLS_AES_256_GCM_SHA384',
          'TLS_CHACHA20_POLY1305_SHA256',
          'TLS_AES_128_GCM_SHA256',
          'ECDHE-RSA-AES256-GCM-SHA384',
          'ECDHE-RSA-AES128-GCM-SHA256'
        ],
        preferServerCiphers: true,
        certificateTransparency: isProduction
      },
      firewall: {
        enabled: true,
        allowedPorts: [80, 443, 3000, 3002], // HTTP, HTTPS, Frontend, Backend
        blockedIPs: [],
        allowedIPs: [],
        geoBlocking: isProduction ? ['CN', 'RU', 'KP'] : [] // Bloquear países de alto riesgo en producción
      },
      ddos: {
        protection: true,
        maxConnections: isProduction ? 1000 : 100,
        connectionTimeout: 30000,
        slowLorisProtection: true
      },
      proxy: {
        trustProxy: isProduction,
        trustedProxies: [
          '127.0.0.1',
          '::1',
          '10.0.0.0/8',
          '172.16.0.0/12',
          '192.168.0.0/16'
        ],
        forwardedHeaders: ['X-Forwarded-For', 'X-Real-IP', 'X-Forwarded-Proto']
      }
    };
  }

  /**
   * Generar headers de seguridad
   */
  private generateSecurityHeaders(): SecurityHeaders {
    const isProduction = process.env.NODE_ENV === 'production';

    return {
      'Strict-Transport-Security': `max-age=${this.config.https.hstsMaxAge}; includeSubDomains${this.config.https.hstsPreload ? '; preload' : ''}`,
      
      'Content-Security-Policy': [
        "default-src 'self'",
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://unpkg.com",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        "font-src 'self' https://fonts.gstatic.com data:",
        "img-src 'self' data: https: blob:",
        "connect-src 'self' https: wss: ws:",
        "frame-ancestors 'none'",
        "base-uri 'self'",
        "form-action 'self'",
        "upgrade-insecure-requests",
        ...(isProduction ? ["block-all-mixed-content"] : [])
      ].join('; '),

      'X-Frame-Options': 'DENY',
      'X-Content-Type-Options': 'nosniff',
      'X-XSS-Protection': '1; mode=block',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      
      'Permissions-Policy': [
        'geolocation=()',
        'microphone=()',
        'camera=()',
        'payment=()',
        'usb=()',
        'magnetometer=()',
        'gyroscope=()',
        'speaker=()',
        'vibrate=()',
        'fullscreen=(self)',
        'sync-xhr=()'
      ].join(', '),

      'Cross-Origin-Embedder-Policy': 'require-corp',
      'Cross-Origin-Opener-Policy': 'same-origin',
      'Cross-Origin-Resource-Policy': 'same-origin'
    };
  }

  /**
   * Inicializar reglas de firewall
   */
  private initializeFirewallRules(): void {
    // IPs conocidas maliciosas (ejemplos)
    const knownMaliciousIPs = [
      '0.0.0.0',
      '127.0.0.1/8', // Evitar localhost en producción
      '169.254.0.0/16', // Link-local
      '224.0.0.0/4' // Multicast
    ];

    if (process.env.NODE_ENV === 'production') {
      knownMaliciousIPs.forEach(ip => this.blockIP(ip, 'Known malicious IP'));
    }

    // IPs de administración permitidas
    const adminIPs = process.env.ADMIN_IP_WHITELIST?.split(',') || [];
    adminIPs.forEach(ip => this.config.firewall.allowedIPs.push(ip.trim()));

    console.log(`🔥 Firewall configurado: ${this.config.firewall.allowedIPs.length} IPs permitidas, ${this.blockedIPs.size} IPs bloqueadas`);
  }

  /**
   * Middleware de seguridad de red
   */
  getNetworkSecurityMiddleware() {
    return (req: any, res: any, next: any) => {
      try {
        // 1. Aplicar headers de seguridad
        this.applySecurityHeaders(res);

        // 2. Verificar HTTPS en producción
        if (!this.verifyHTTPS(req, res)) return;

        // 3. Verificar firewall
        if (!this.checkFirewall(req, res)) return;

        // 4. Protección DDoS
        if (!this.checkDDoSProtection(req, res)) return;

        // 5. Verificar proxy confiable
        if (!this.verifyTrustedProxy(req, res)) return;

        // 6. Log de conexión segura
        this.logSecureConnection(req);

        next();

      } catch (error) {
        console.error('Error en middleware de seguridad de red:', error);
        res.status(500).json({
          error: {
            code: 'NETWORK_SECURITY_ERROR',
            message: 'Error de seguridad de red',
            timestamp: new Date().toISOString()
          }
        });
      }
    };
  }

  /**
   * Aplicar headers de seguridad
   */
  private applySecurityHeaders(res: any): void {
    for (const [header, value] of Object.entries(this.securityHeaders)) {
      res.setHeader(header, value);
    }

    // Headers adicionales
    res.setHeader('Server', 'ArbitrageX-Pro-2025'); // Ocultar versión del servidor
    res.setHeader('X-Powered-By', ''); // Remover X-Powered-By
    res.removeHeader('X-Powered-By');
  }

  /**
   * Verificar HTTPS
   */
  private verifyHTTPS(req: any, res: any): boolean {
    if (!this.config.https.enforced) return true;

    const isHTTPS = req.secure || 
                   req.headers['x-forwarded-proto'] === 'https' ||
                   req.connection.encrypted;

    if (!isHTTPS && this.config.https.redirectHttp) {
      const httpsUrl = `https://${req.headers.host}${req.url}`;
      res.redirect(301, httpsUrl);
      console.log(`🔒 Redirigiendo HTTP a HTTPS: ${req.url}`);
      return false;
    }

    if (!isHTTPS) {
      res.status(426).json({
        error: {
          code: 'HTTPS_REQUIRED',
          message: 'HTTPS requerido',
          timestamp: new Date().toISOString()
        }
      });
      return false;
    }

    return true;
  }

  /**
   * Verificar firewall
   */
  private checkFirewall(req: any, res: any): boolean {
    if (!this.config.firewall.enabled) return true;

    const clientIP = this.getClientIP(req);

    // Verificar IP bloqueada
    if (this.isIPBlocked(clientIP)) {
      console.warn(`🚫 IP bloqueada intentando acceder: ${clientIP}`);
      res.status(403).json({
        error: {
          code: 'IP_BLOCKED',
          message: 'Acceso denegado',
          timestamp: new Date().toISOString()
        }
      });
      return false;
    }

    // Verificar whitelist (si existe)
    if (this.config.firewall.allowedIPs.length > 0) {
      if (!this.isIPAllowed(clientIP)) {
        console.warn(`🚫 IP no autorizada: ${clientIP}`);
        res.status(403).json({
          error: {
            code: 'IP_NOT_ALLOWED',
            message: 'IP no autorizada',
            timestamp: new Date().toISOString()
          }
        });
        return false;
      }
    }

    // Verificar geoblocking
    if (this.config.firewall.geoBlocking.length > 0) {
      const country = this.getCountryFromIP(clientIP);
      if (country && this.config.firewall.geoBlocking.includes(country)) {
        console.warn(`🌍 País bloqueado: ${country} (${clientIP})`);
        res.status(403).json({
          error: {
            code: 'COUNTRY_BLOCKED',
            message: 'Acceso no disponible en tu región',
            timestamp: new Date().toISOString()
          }
        });
        return false;
      }
    }

    return true;
  }

  /**
   * Protección DDoS
   */
  private checkDDoSProtection(req: any, res: any): boolean {
    if (!this.config.ddos.protection) return true;

    const clientIP = this.getClientIP(req);
    const connections = this.connectionCounts.get(clientIP) || 0;

    // Verificar límite de conexiones
    if (connections >= this.config.ddos.maxConnections) {
      console.warn(`🚨 DDoS detectado: ${clientIP} (${connections} conexiones)`);
      
      // Bloquear IP temporalmente
      this.blockIP(clientIP, 'DDoS attack detected', 3600000); // 1 hora
      
      res.status(429).json({
        error: {
          code: 'TOO_MANY_CONNECTIONS',
          message: 'Demasiadas conexiones simultáneas',
          retryAfter: 3600,
          timestamp: new Date().toISOString()
        }
      });
      return false;
    }

    // Incrementar contador
    this.connectionCounts.set(clientIP, connections + 1);

    // Configurar timeout para limpiar contador
    setTimeout(() => {
      const current = this.connectionCounts.get(clientIP) || 0;
      if (current > 0) {
        this.connectionCounts.set(clientIP, current - 1);
      }
    }, this.config.ddos.connectionTimeout);

    return true;
  }

  /**
   * Verificar proxy confiable
   */
  private verifyTrustedProxy(req: any, res: any): boolean {
    if (!this.config.proxy.trustProxy) return true;

    // Verificar headers de proxy
    const forwardedFor = req.headers['x-forwarded-for'];
    const realIP = req.headers['x-real-ip'];

    if (forwardedFor || realIP) {
      // Verificar que el proxy esté en la lista de confianza
      const proxyIP = req.connection.remoteAddress;
      
      if (!this.isTrustedProxy(proxyIP)) {
        console.warn(`🚫 Proxy no confiable: ${proxyIP}`);
        res.status(403).json({
          error: {
            code: 'UNTRUSTED_PROXY',
            message: 'Proxy no autorizado',
            timestamp: new Date().toISOString()
          }
        });
        return false;
      }
    }

    return true;
  }

  /**
   * Obtener IP del cliente
   */
  private getClientIP(req: any): string {
    if (this.config.proxy.trustProxy) {
      return req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
             req.headers['x-real-ip'] ||
             req.connection.remoteAddress ||
             req.socket.remoteAddress ||
             '127.0.0.1';
    }
    
    return req.connection.remoteAddress || req.socket.remoteAddress || '127.0.0.1';
  }

  /**
   * Verificar si IP está bloqueada
   */
  private isIPBlocked(ip: string): boolean {
    return this.blockedIPs.has(ip) || 
           this.config.firewall.blockedIPs.includes(ip);
  }

  /**
   * Verificar si IP está permitida
   */
  private isIPAllowed(ip: string): boolean {
    if (this.config.firewall.allowedIPs.length === 0) return true;
    
    return this.config.firewall.allowedIPs.some(allowedIP => {
      if (allowedIP.includes('/')) {
        // CIDR notation
        return this.isIPInCIDR(ip, allowedIP);
      }
      return ip === allowedIP;
    });
  }

  /**
   * Verificar si proxy es confiable
   */
  private isTrustedProxy(proxyIP: string): boolean {
    return this.config.proxy.trustedProxies.some(trustedIP => {
      if (trustedIP.includes('/')) {
        return this.isIPInCIDR(proxyIP, trustedIP);
      }
      return proxyIP === trustedIP;
    });
  }

  /**
   * Verificar si IP está en rango CIDR
   */
  private isIPInCIDR(ip: string, cidr: string): boolean {
    // Implementación simplificada - en producción usar librería especializada
    try {
      const [network, bits] = cidr.split('/');
      const mask = -1 << (32 - parseInt(bits));
      
      const ipInt = this.ipToInt(ip);
      const networkInt = this.ipToInt(network);
      
      return (ipInt & mask) === (networkInt & mask);
    } catch {
      return false;
    }
  }

  /**
   * Convertir IP a entero
   */
  private ipToInt(ip: string): number {
    return ip.split('.').reduce((acc, octet) => acc * 256 + parseInt(octet), 0);
  }

  /**
   * Obtener país desde IP (placeholder)
   */
  private getCountryFromIP(ip: string): string | null {
    // En producción integrar con servicio de geolocalización
    // MaxMind GeoIP2, IP2Location, etc.
    return null;
  }

  /**
   * Bloquear IP
   */
  blockIP(ip: string, reason: string, duration?: number): void {
    this.blockedIPs.add(ip);
    console.log(`🚫 IP bloqueada: ${ip} - Razón: ${reason}`);

    if (duration) {
      setTimeout(() => {
        this.unblockIP(ip);
      }, duration);
    }

    // Log evento de seguridad
    this.logSecurityEvent('ip_blocked', {
      ip,
      reason,
      duration,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Desbloquear IP
   */
  unblockIP(ip: string): void {
    this.blockedIPs.delete(ip);
    console.log(`✅ IP desbloqueada: ${ip}`);
  }

  /**
   * Iniciar monitoreo de conexiones
   */
  private startConnectionMonitoring(): void {
    // Limpiar contadores cada minuto
    setInterval(() => {
      // Limpiar conexiones antiguas
      const now = Date.now();
      for (const [ip, count] of this.connectionCounts) {
        if (count === 0) {
          this.connectionCounts.delete(ip);
        }
      }
    }, 60000);

    console.log('🔍 Monitoreo de conexiones de red iniciado');
  }

  /**
   * Log de conexión segura
   */
  private logSecureConnection(req: any): void {
    const clientIP = this.getClientIP(req);
    const userAgent = req.headers['user-agent'] || 'unknown';
    const secure = req.secure || req.headers['x-forwarded-proto'] === 'https';

    console.log(`🔒 Conexión ${secure ? 'segura' : 'insegura'}: ${clientIP} → ${req.method} ${req.path}`);
  }

  /**
   * Log de evento de seguridad
   */
  private logSecurityEvent(event: string, details: any): void {
    try {
      // Integrar con SecurityAlertingSystem si está disponible
      const { securityAlertingSystem } = require('./SecurityAlertingSystem');
      securityAlertingSystem.processSecurityEvent({
        type: event,
        ...details,
        source: 'NetworkSecurityManager'
      });
    } catch (error) {
      // Sistema de alertas no disponible
      console.warn('🚨 Evento de seguridad:', event, details);
    }
  }

  /**
   * Obtener estadísticas de red
   */
  getNetworkStats(): {
    blockedIPs: number;
    allowedIPs: number;
    activeConnections: number;
    securityHeaders: number;
    httpsEnforced: boolean;
    firewallEnabled: boolean;
  } {
    let activeConnections = 0;
    for (const count of this.connectionCounts.values()) {
      activeConnections += count;
    }

    return {
      blockedIPs: this.blockedIPs.size,
      allowedIPs: this.config.firewall.allowedIPs.length,
      activeConnections,
      securityHeaders: Object.keys(this.securityHeaders).length,
      httpsEnforced: this.config.https.enforced,
      firewallEnabled: this.config.firewall.enabled
    };
  }

  /**
   * Generar configuración para servidor web
   */
  generateWebServerConfig(): {
    nginx: string;
    apache: string;
    caddy: string;
  } {
    return {
      nginx: this.generateNginxConfig(),
      apache: this.generateApacheConfig(),
      caddy: this.generateCaddyConfig()
    };
  }

  /**
   * Generar configuración Nginx
   */
  private generateNginxConfig(): string {
    return `# ArbitrageX Pro 2025 - Nginx Security Configuration

server {
    listen 80;
    server_name arbitragex.pro www.arbitragex.pro;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name arbitragex.pro www.arbitragex.pro;

    # SSL Configuration
    ssl_certificate /path/to/certificate.pem;
    ssl_certificate_key /path/to/private.key;
    ssl_protocols TLSv1.3 TLSv1.2;
    ssl_ciphers ${this.config.tls.cipherSuites.join(':')};
    ssl_prefer_server_ciphers on;

    # Security Headers
${Object.entries(this.securityHeaders).map(([header, value]) => 
    `    add_header ${header} "${value}" always;`
).join('\n')}

    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req zone=api burst=20 nodelay;

    # Proxy to Node.js backend
    location /api {
        proxy_pass http://localhost:3002;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Serve static files
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}`;
  }

  /**
   * Generar configuración Apache
   */
  private generateApacheConfig(): string {
    return `# ArbitrageX Pro 2025 - Apache Security Configuration

<VirtualHost *:80>
    ServerName arbitragex.pro
    Redirect permanent / https://arbitragex.pro/
</VirtualHost>

<VirtualHost *:443>
    ServerName arbitragex.pro
    
    # SSL Configuration
    SSLEngine on
    SSLCertificateFile /path/to/certificate.pem
    SSLCertificateKeyFile /path/to/private.key
    SSLProtocol all -SSLv3 -TLSv1 -TLSv1.1
    SSLCipherSuite ${this.config.tls.cipherSuites.join(':')}

    # Security Headers
${Object.entries(this.securityHeaders).map(([header, value]) => 
    `    Header always set ${header} "${value}"`
).join('\n')}

    # Proxy Configuration
    ProxyPreserveHost On
    ProxyPass /api http://localhost:3002/
    ProxyPassReverse /api http://localhost:3002/
    ProxyPass / http://localhost:3000/
    ProxyPassReverse / http://localhost:3000/
</VirtualHost>`;
  }

  /**
   * Generar configuración Caddy
   */
  private generateCaddyConfig(): string {
    return `# ArbitrageX Pro 2025 - Caddy Security Configuration

arbitragex.pro {
    # Automatic HTTPS
    tls {
        protocols tls1.2 tls1.3
        ciphers ${this.config.tls.cipherSuites.join(' ')}
    }

    # Security Headers
${Object.entries(this.securityHeaders).map(([header, value]) => 
    `    header ${header} "${value}"`
).join('\n')}

    # Rate Limiting
    rate_limit {
        zone dynamic {
            key {remote_host}
            events 10
            window 1s
        }
    }

    # Reverse Proxy
    handle /api* {
        reverse_proxy localhost:3002
    }

    handle {
        reverse_proxy localhost:3000
    }
}`;
  }
}

// Export singleton instance
export const networkSecurityManager = NetworkSecurityManager.getInstance();
export default NetworkSecurityManager;
