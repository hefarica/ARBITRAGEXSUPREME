/**
 * 🔐 ENDPOINT AUTHENTICATION MANAGER - ArbitrageX Pro 2025
 * Gestión centralizada de autenticación por endpoint
 */

export interface EndpointRule {
  pattern: string;
  methods: string[];
  authRequired: boolean;
  roles: string[];
  rateLimit: {
    requests: number;
    windowMs: number;
  };
  ipWhitelist?: string[];
  additionalChecks?: string[];
}

export interface UserSession {
  userId: string;
  roles: string[];
  permissions: string[];
  ipAddress: string;
  userAgent: string;
  createdAt: number;
  lastActivity: number;
  isValid: boolean;
}

export class EndpointAuthenticationManager {
  private static instance: EndpointAuthenticationManager;
  private endpointRules: Map<string, EndpointRule> = new Map();
  private activeSessions: Map<string, UserSession> = new Map();
  private jwtSecret: string;

  private constructor() {
    this.jwtSecret = process.env.JWT_SECRET || 'development-secret-key';
    this.initializeEndpointRules();
    this.startSessionCleanup();
  }

  public static getInstance(): EndpointAuthenticationManager {
    if (!EndpointAuthenticationManager.instance) {
      EndpointAuthenticationManager.instance = new EndpointAuthenticationManager();
    }
    return EndpointAuthenticationManager.instance;
  }

  /**
   * Inicializar reglas de autenticación por endpoint
   */
  private initializeEndpointRules(): void {
    // 🟢 ENDPOINTS PÚBLICOS - Sin autenticación
    this.addEndpointRule('/health', {
      pattern: '/health',
      methods: ['GET'],
      authRequired: false,
      roles: [],
      rateLimit: { requests: 1000, windowMs: 60000 }
    });

    this.addEndpointRule('/api/status', {
      pattern: '/api/status',
      methods: ['GET'],
      authRequired: false,
      roles: [],
      rateLimit: { requests: 100, windowMs: 60000 }
    });

    // 🟡 ENDPOINTS DE DATOS - Autenticación básica
    this.addEndpointRule('/api/metrics', {
      pattern: '/api/metrics',
      methods: ['GET'],
      authRequired: true,
      roles: ['user', 'admin'],
      rateLimit: { requests: 500, windowMs: 60000 }
    });

    this.addEndpointRule('/api/events', {
      pattern: '/api/events',
      methods: ['GET'],
      authRequired: true,
      roles: ['user', 'admin'],
      rateLimit: { requests: 200, windowMs: 60000 }
    });

    this.addEndpointRule('/api/nodes', {
      pattern: '/api/nodes',
      methods: ['GET'],
      authRequired: true,
      roles: ['user', 'admin'],
      rateLimit: { requests: 100, windowMs: 60000 }
    });

    this.addEndpointRule('/api/opportunities', {
      pattern: '/api/opportunities',
      methods: ['GET'],
      authRequired: true,
      roles: ['user', 'admin'],
      rateLimit: { requests: 200, windowMs: 60000 }
    });

    // 🔴 ENDPOINTS CRÍTICOS - Solo administradores
    this.addEndpointRule('/api/config', {
      pattern: '/api/config',
      methods: ['GET', 'POST'],
      authRequired: true,
      roles: ['admin'],
      rateLimit: { requests: 10, windowMs: 60000 },
      additionalChecks: ['mfa_required', 'ip_whitelist']
    });

    this.addEndpointRule('/api/start', {
      pattern: '/api/start',
      methods: ['POST'],
      authRequired: true,
      roles: ['admin'],
      rateLimit: { requests: 5, windowMs: 300000 }, // 5 requests per 5 minutes
      additionalChecks: ['mfa_required', 'confirmation_required']
    });

    this.addEndpointRule('/api/stop', {
      pattern: '/api/stop',
      methods: ['POST'],
      authRequired: true,
      roles: ['admin'],
      rateLimit: { requests: 5, windowMs: 300000 },
      additionalChecks: ['mfa_required', 'confirmation_required']
    });

    this.addEndpointRule('/api/execute', {
      pattern: '/api/execute',
      methods: ['POST'],
      authRequired: true,
      roles: ['trader', 'admin'],
      rateLimit: { requests: 10, windowMs: 60000 },
      additionalChecks: ['hardware_wallet_required', 'transaction_limit_check']
    });

    // 🟣 ENDPOINTS DE STREAMING - Autenticación especial
    this.addEndpointRule('/api/stream', {
      pattern: '/api/stream',
      methods: ['GET'],
      authRequired: true,
      roles: ['user', 'admin'],
      rateLimit: { requests: 10, windowMs: 60000 } // Máximo 10 conexiones SSE
    });

    console.log(`🔐 ${this.endpointRules.size} reglas de autenticación configuradas`);
  }

  /**
   * Agregar regla de endpoint
   */
  private addEndpointRule(key: string, rule: EndpointRule): void {
    this.endpointRules.set(key, rule);
  }

  /**
   * Middleware de autenticación principal
   */
  authenticationMiddleware() {
    return async (req: any, res: any, next: any) => {
      try {
        const path = req.path;
        const method = req.method;

        // Encontrar regla aplicable
        const rule = this.findMatchingRule(path, method);
        
        if (!rule) {
          // Sin regla específica - requerir autenticación por defecto en producción
          if (process.env.NODE_ENV === 'production') {
            return this.sendAuthError(res, 'ENDPOINT_NOT_CONFIGURED', 'Endpoint no configurado');
          }
          return next(); // Permitir en desarrollo
        }

        // Si no requiere autenticación, continuar
        if (!rule.authRequired) {
          return next();
        }

        // Extraer y validar token
        const token = this.extractToken(req);
        if (!token) {
          return this.sendAuthError(res, 'MISSING_TOKEN', 'Token de autenticación requerido');
        }

        // Validar token JWT
        const payload = await this.validateJWT(token);
        if (!payload) {
          return this.sendAuthError(res, 'INVALID_TOKEN', 'Token de autenticación inválido');
        }

        // Verificar sesión activa
        const session = this.activeSessions.get(payload.sessionId);
        if (!session || !session.isValid) {
          return this.sendAuthError(res, 'SESSION_EXPIRED', 'Sesión expirada');
        }

        // Verificar roles
        if (rule.roles.length > 0) {
          const hasRole = rule.roles.some(role => session.roles.includes(role));
          if (!hasRole) {
            return this.sendAuthError(res, 'INSUFFICIENT_PERMISSIONS', 'Permisos insuficientes');
          }
        }

        // Verificar IP whitelist si está configurada
        if (rule.ipWhitelist && rule.ipWhitelist.length > 0) {
          const clientIP = req.ip || req.connection.remoteAddress;
          if (!rule.ipWhitelist.includes(clientIP)) {
            return this.sendAuthError(res, 'IP_NOT_WHITELISTED', 'IP no autorizada');
          }
        }

        // Verificaciones adicionales
        if (rule.additionalChecks) {
          for (const check of rule.additionalChecks) {
            const passed = await this.performAdditionalCheck(check, req, session);
            if (!passed) {
              return this.sendAuthError(res, 'ADDITIONAL_CHECK_FAILED', `Verificación adicional falló: ${check}`);
            }
          }
        }

        // Actualizar última actividad
        session.lastActivity = Date.now();
        
        // Agregar información de usuario al request
        req.user = {
          userId: session.userId,
          roles: session.roles,
          permissions: session.permissions,
          sessionId: payload.sessionId
        };

        // Log de acceso autorizado
        console.log(`✅ Acceso autorizado: ${session.userId} → ${method} ${path}`);

        next();

      } catch (error) {
        console.error('Error en middleware de autenticación:', error);
        return this.sendAuthError(res, 'AUTH_ERROR', 'Error interno de autenticación');
      }
    };
  }

  /**
   * Encontrar regla que coincida con el endpoint
   */
  private findMatchingRule(path: string, method: string): EndpointRule | null {
    for (const rule of this.endpointRules.values()) {
      if (this.pathMatches(path, rule.pattern) && rule.methods.includes(method)) {
        return rule;
      }
    }
    return null;
  }

  /**
   * Verificar si un path coincide con un patrón
   */
  private pathMatches(path: string, pattern: string): boolean {
    // Convertir patrón con wildcards a regex
    const regexPattern = pattern
      .replace(/\*/g, '.*')
      .replace(/\//g, '\\/');
    
    const regex = new RegExp(`^${regexPattern}$`);
    return regex.test(path);
  }

  /**
   * Extraer token del request
   */
  private extractToken(req: any): string | null {
    // Bearer token en header
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      return authHeader.substring(7);
    }

    // Token en query parameter (solo para SSE)
    if (req.query && req.query.token) {
      return req.query.token;
    }

    // Token en cookie (si está configurado)
    if (req.cookies && req.cookies.authToken) {
      return req.cookies.authToken;
    }

    return null;
  }

  /**
   * Validar token JWT
   */
  private async validateJWT(token: string): Promise<any | null> {
    try {
      // Importar jwt dinámicamente
      const jwt = require('jsonwebtoken');
      
      const payload = jwt.verify(token, this.jwtSecret);
      
      // Verificar campos requeridos
      if (!payload.userId || !payload.sessionId) {
        return null;
      }

      // Verificar expiración
      if (payload.exp && Date.now() >= payload.exp * 1000) {
        return null;
      }

      return payload;

    } catch (error) {
      console.warn('Error validando JWT:', error.message);
      return null;
    }
  }

  /**
   * Realizar verificaciones adicionales
   */
  private async performAdditionalCheck(check: string, req: any, session: UserSession): Promise<boolean> {
    switch (check) {
      case 'mfa_required':
        // Verificar que la sesión tenga MFA confirmado
        return session.permissions.includes('mfa_verified');

      case 'ip_whitelist':
        // Verificar IP en whitelist administrativa
        const adminIPs = process.env.ADMIN_IP_WHITELIST?.split(',') || [];
        const clientIP = req.ip || req.connection.remoteAddress;
        return adminIPs.includes(clientIP);

      case 'confirmation_required':
        // Verificar header de confirmación para acciones críticas
        return req.headers['x-confirm-action'] === 'true';

      case 'hardware_wallet_required':
        // Verificar que haya hardware wallet conectado
        return session.permissions.includes('hardware_wallet_connected');

      case 'transaction_limit_check':
        // Verificar límites de transacción
        return await this.checkTransactionLimits(session.userId);

      default:
        console.warn(`Verificación adicional no reconocida: ${check}`);
        return false;
    }
  }

  /**
   * Verificar límites de transacción
   */
  private async checkTransactionLimits(userId: string): Promise<boolean> {
    // Implementar lógica de límites de transacción
    // Por ahora retorna true
    return true;
  }

  /**
   * Enviar error de autenticación
   */
  private sendAuthError(res: any, code: string, message: string): void {
    res.status(401).json({
      error: {
        code,
        message,
        timestamp: new Date().toISOString()
      }
    });
  }

  /**
   * Crear nueva sesión
   */
  createSession(userId: string, roles: string[], permissions: string[], req: any): string {
    const sessionId = this.generateSessionId();
    
    const session: UserSession = {
      userId,
      roles,
      permissions,
      ipAddress: req.ip || req.connection.remoteAddress,
      userAgent: req.headers['user-agent'] || '',
      createdAt: Date.now(),
      lastActivity: Date.now(),
      isValid: true
    };

    this.activeSessions.set(sessionId, session);
    
    console.log(`✅ Nueva sesión creada: ${userId} (${sessionId})`);
    
    return sessionId;
  }

  /**
   * Generar JWT token
   */
  generateJWT(userId: string, sessionId: string, roles: string[]): string {
    const jwt = require('jsonwebtoken');
    
    const payload = {
      userId,
      sessionId,
      roles,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + (60 * 60), // 1 hora
      iss: 'arbitragex-pro-2025'
    };

    return jwt.sign(payload, this.jwtSecret);
  }

  /**
   * Invalidar sesión
   */
  invalidateSession(sessionId: string): boolean {
    const session = this.activeSessions.get(sessionId);
    if (session) {
      session.isValid = false;
      this.activeSessions.delete(sessionId);
      console.log(`🔒 Sesión invalidada: ${sessionId}`);
      return true;
    }
    return false;
  }

  /**
   * Obtener sesiones activas
   */
  getActiveSessions(): UserSession[] {
    return Array.from(this.activeSessions.values()).filter(s => s.isValid);
  }

  /**
   * Limpiar sesiones expiradas
   */
  private startSessionCleanup(): void {
    setInterval(() => {
      const now = Date.now();
      const maxAge = 24 * 60 * 60 * 1000; // 24 horas
      
      for (const [sessionId, session] of this.activeSessions) {
        if (now - session.lastActivity > maxAge) {
          this.invalidateSession(sessionId);
        }
      }
    }, 60 * 60 * 1000); // Cada hora
  }

  /**
   * Generar ID de sesión
   */
  private generateSessionId(): string {
    return 'sess_' + Date.now() + '_' + Math.random().toString(36).substr(2, 16);
  }

  /**
   * Obtener estadísticas de autenticación
   */
  getAuthStats(): {
    activeSessions: number;
    endpointRules: number;
    protectedEndpoints: number;
    publicEndpoints: number;
  } {
    const protectedEndpoints = Array.from(this.endpointRules.values())
      .filter(rule => rule.authRequired).length;
    
    const publicEndpoints = Array.from(this.endpointRules.values())
      .filter(rule => !rule.authRequired).length;

    return {
      activeSessions: this.getActiveSessions().length,
      endpointRules: this.endpointRules.size,
      protectedEndpoints,
      publicEndpoints
    };
  }
}

// Export singleton instance
export const endpointAuthenticationManager = EndpointAuthenticationManager.getInstance();
export default EndpointAuthenticationManager;
