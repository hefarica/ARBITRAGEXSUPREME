#!/usr/bin/env node

/**
 * 📚 GENERADOR DE DOCUMENTACIÓN OPENAPI - ArbitrageX Pro 2025
 * Genera documentación automática de todas las APIs del proyecto
 */

import fs from 'fs';
import path from 'path';
import swaggerJsdoc from 'swagger-jsdoc';
import { glob } from 'glob';

class OpenAPIGenerator {
  constructor() {
    this.apiDefinition = {
      openapi: '3.0.0',
      info: {
        title: 'ArbitrageX Pro 2025 API',
        version: '1.0.0',
        description: `
# 🚀 ArbitrageX Pro 2025 API Documentation

API completa para el sistema de arbitraje de criptomonedas más avanzado.

## 🌟 Características

- **11 estrategias de arbitraje** completamente automatizadas
- **Multi-blockchain** (Ethereum, BSC, Polygon, Arbitrum, etc.)
- **Tiempo real** con WebSockets y Server-Sent Events
- **MEV Protection** con integración Flashbots
- **Flash Loans** para maximizar oportunidades
- **Gestión de riesgos** avanzada

## 🔐 Autenticación

Todas las APIs requieren autenticación JWT. Incluye el token en el header:

\`\`\`
Authorization: Bearer <tu_jwt_token>
\`\`\`

## 📊 Rate Limiting

- **100 requests por minuto** para endpoints básicos
- **500 requests por minuto** para datos en tiempo real
- **10 requests por minuto** para ejecución de trades

## 🚨 Manejo de Errores

Todos los errores siguen el formato estándar:

\`\`\`json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Descripción del error",
    "details": "Información adicional",
    "timestamp": "2025-01-01T00:00:00Z"
  }
}
\`\`\`
        `,
        contact: {
          name: 'ArbitrageX Pro Support',
          email: 'support@arbitragex.pro',
          url: 'https://arbitragex.pro/docs'
        },
        license: {
          name: 'MIT',
          url: 'https://opensource.org/licenses/MIT'
        }
      },
      servers: [
        {
          url: 'http://localhost:3002',
          description: 'Desarrollo Local'
        },
        {
          url: 'https://api.arbitragex.pro',
          description: 'Producción'
        },
        {
          url: 'https://staging.arbitragex.pro',
          description: 'Staging'
        }
      ],
      components: {
        securitySchemes: {
          bearerAuth: {
            type: 'http',
            scheme: 'bearer',
            bearerFormat: 'JWT'
          }
        },
        schemas: {
          GapMetrics: {
            type: 'object',
            description: 'Métricas del GAP Auditor',
            properties: {
              gapScore: {
                type: 'number',
                minimum: 0,
                maximum: 100,
                description: 'Puntuación GAP (0-100)',
                example: 87.5
              },
              priceGap: {
                type: 'number',
                description: 'Diferencia de precios entre DEXs (%)',
                example: 2.3
              },
              depthGap: {
                type: 'number',
                description: 'Diferencia de liquidez entre DEXs',
                example: 1500000
              },
              latencyGap: {
                type: 'number',
                description: 'Latencia promedio (ms)',
                example: 142
              },
              riskGap: {
                type: 'number',
                description: 'Nivel de riesgo (0-10)',
                example: 3.2
              },
              roiNet: {
                type: 'number',
                description: 'ROI neto esperado (%)',
                example: 0.42
              },
              collisionProb: {
                type: 'number',
                description: 'Probabilidad de colisión MEV (0-1)',
                example: 0.15
              },
              decisionLatency: {
                type: 'number',
                description: 'Latencia de decisión (ms)',
                example: 89
              }
            },
            required: ['gapScore', 'roiNet', 'decisionLatency']
          },
          ArbitrageOpportunity: {
            type: 'object',
            description: 'Oportunidad de arbitraje detectada',
            properties: {
              id: {
                type: 'string',
                description: 'ID único de la oportunidad',
                example: 'arb_eth_usd_12345'
              },
              type: {
                type: 'string',
                enum: ['simple', 'triangular', 'cross-chain', 'flash-loan'],
                description: 'Tipo de arbitraje',
                example: 'triangular'
              },
              pair: {
                type: 'string',
                description: 'Par de trading',
                example: 'ETH/USDC'
              },
              profit: {
                type: 'number',
                description: 'Profit estimado (USD)',
                example: 156.78
              },
              probability: {
                type: 'number',
                minimum: 0,
                maximum: 100,
                description: 'Probabilidad de éxito (%)',
                example: 89.5
              },
              risk: {
                type: 'string',
                enum: ['low', 'medium', 'high'],
                description: 'Nivel de riesgo',
                example: 'medium'
              },
              status: {
                type: 'string',
                enum: ['pending', 'executing', 'executed', 'failed', 'expired'],
                description: 'Estado actual',
                example: 'pending'
              },
              dexes: {
                type: 'array',
                items: { type: 'string' },
                description: 'DEXs involucrados',
                example: ['Uniswap V3', 'SushiSwap']
              },
              blockchains: {
                type: 'array',
                items: { type: 'string' },
                description: 'Blockchains involucradas',
                example: ['ethereum', 'polygon']
              },
              estimatedGas: {
                type: 'number',
                description: 'Gas estimado (wei)',
                example: 150000
              },
              deadline: {
                type: 'string',
                format: 'date-time',
                description: 'Deadline para ejecución',
                example: '2025-01-01T12:00:00Z'
              }
            },
            required: ['id', 'type', 'pair', 'profit', 'probability', 'status']
          },
          ExecutionResult: {
            type: 'object',
            description: 'Resultado de ejecución de arbitraje',
            properties: {
              opportunityId: {
                type: 'string',
                description: 'ID de la oportunidad ejecutada'
              },
              success: {
                type: 'boolean',
                description: 'Si la ejecución fue exitosa'
              },
              transactionHash: {
                type: 'string',
                description: 'Hash de la transacción'
              },
              actualProfit: {
                type: 'number',
                description: 'Profit real obtenido (USD)'
              },
              gasUsed: {
                type: 'number',
                description: 'Gas utilizado'
              },
              executionTime: {
                type: 'number',
                description: 'Tiempo de ejecución (ms)'
              },
              error: {
                type: 'string',
                description: 'Mensaje de error (si falló)'
              }
            },
            required: ['opportunityId', 'success']
          },
          SystemStatus: {
            type: 'object',
            description: 'Estado del sistema',
            properties: {
              isRunning: {
                type: 'boolean',
                description: 'Si el sistema está corriendo'
              },
              uptime: {
                type: 'number',
                description: 'Tiempo activo (ms)'
              },
              version: {
                type: 'string',
                description: 'Versión del sistema'
              },
              environment: {
                type: 'string',
                enum: ['development', 'staging', 'production'],
                description: 'Entorno actual'
              },
              features: {
                type: 'object',
                description: 'Características habilitadas',
                properties: {
                  flashLoans: { type: 'boolean' },
                  mevProtection: { type: 'boolean' },
                  multiChain: { type: 'boolean' },
                  realTimeData: { type: 'boolean' }
                }
              }
            }
          },
          Error: {
            type: 'object',
            description: 'Formato estándar de error',
            properties: {
              error: {
                type: 'object',
                properties: {
                  code: {
                    type: 'string',
                    description: 'Código de error',
                    example: 'OPPORTUNITY_NOT_FOUND'
                  },
                  message: {
                    type: 'string',
                    description: 'Mensaje del error',
                    example: 'La oportunidad especificada no existe'
                  },
                  details: {
                    type: 'string',
                    description: 'Detalles adicionales'
                  },
                  timestamp: {
                    type: 'string',
                    format: 'date-time',
                    description: 'Timestamp del error'
                  }
                },
                required: ['code', 'message', 'timestamp']
              }
            }
          }
        }
      },
      security: [{ bearerAuth: [] }],
      tags: [
        {
          name: 'Health',
          description: 'Endpoints de salud del sistema'
        },
        {
          name: 'Metrics',
          description: 'Métricas del GAP Auditor'
        },
        {
          name: 'Opportunities',
          description: 'Gestión de oportunidades de arbitraje'
        },
        {
          name: 'Execution',
          description: 'Ejecución de trades'
        },
        {
          name: 'System',
          description: 'Control del sistema'
        },
        {
          name: 'Configuration',
          description: 'Configuración del sistema'
        },
        {
          name: 'Real-time',
          description: 'Datos en tiempo real'
        }
      ]
    };
  }

  async generateDocumentation() {
    console.log('📚 Generando documentación OpenAPI...\n');

    // 1. Analizar archivos del backend
    await this.analyzeBackendFiles();

    // 2. Generar documentación completa
    const spec = await this.generateOpenAPISpec();

    // 3. Crear archivos de documentación
    await this.createDocumentationFiles(spec);

    // 4. Generar cliente TypeScript
    await this.generateTypeScriptClient(spec);

    console.log('✅ Documentación generada exitosamente!');
  }

  async analyzeBackendFiles() {
    console.log('🔍 Analizando archivos del backend...');

    // Analizar gap-auditor-server.js
    const serverFile = 'src/backend/gap-auditor-server.js';
    if (fs.existsSync(serverFile)) {
      const content = fs.readFileSync(serverFile, 'utf8');
      this.extractEndpointsFromServer(content);
    }

    // Analizar servicios
    const serviceFiles = await glob('src/services/*.ts');
    for (const file of serviceFiles) {
      this.analyzeServiceFile(file);
    }

    console.log('   ✅ Análisis completado');
  }

  extractEndpointsFromServer(content) {
    // Extraer endpoints del servidor Express
    const endpointRegex = /app\.(get|post|put|delete)\(['"`]([^'"`]+)['"`]/g;
    let match;

    while ((match = endpointRegex.exec(content)) !== null) {
      const [, method, path] = match;
      this.addEndpointToSpec(method.toUpperCase(), path);
    }
  }

  addEndpointToSpec(method, path) {
    if (!this.apiDefinition.paths) {
      this.apiDefinition.paths = {};
    }

    if (!this.apiDefinition.paths[path]) {
      this.apiDefinition.paths[path] = {};
    }

    // Definir endpoints basados en el análisis del código
    switch (path) {
      case '/health':
        this.apiDefinition.paths[path] = {
          get: {
            tags: ['Health'],
            summary: 'Health Check',
            description: 'Verifica el estado de salud del servidor',
            responses: {
              '200': {
                description: 'Servidor funcionando correctamente',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        status: { type: 'string', example: 'ok' },
                        timestamp: { type: 'string', format: 'date-time' }
                      }
                    }
                  }
                }
              }
            }
          }
        };
        break;

      case '/api/metrics':
        this.apiDefinition.paths[path] = {
          get: {
            tags: ['Metrics'],
            summary: 'Obtener Métricas GAP',
            description: 'Obtiene las métricas actuales del GAP Auditor',
            responses: {
              '200': {
                description: 'Métricas obtenidas exitosamente',
                content: {
                  'application/json': {
                    schema: { $ref: '#/components/schemas/GapMetrics' }
                  }
                }
              },
              '500': {
                description: 'Error del servidor',
                content: {
                  'application/json': {
                    schema: { $ref: '#/components/schemas/Error' }
                  }
                }
              }
            }
          }
        };
        break;

      case '/api/opportunities':
        this.apiDefinition.paths[path] = {
          get: {
            tags: ['Opportunities'],
            summary: 'Listar Oportunidades',
            description: 'Obtiene todas las oportunidades de arbitraje detectadas',
            parameters: [
              {
                name: 'status',
                in: 'query',
                description: 'Filtrar por estado',
                schema: {
                  type: 'string',
                  enum: ['pending', 'executing', 'executed', 'failed', 'expired']
                }
              },
              {
                name: 'type',
                in: 'query',
                description: 'Filtrar por tipo',
                schema: {
                  type: 'string',
                  enum: ['simple', 'triangular', 'cross-chain', 'flash-loan']
                }
              },
              {
                name: 'limit',
                in: 'query',
                description: 'Número máximo de resultados',
                schema: { type: 'integer', minimum: 1, maximum: 100, default: 50 }
              }
            ],
            responses: {
              '200': {
                description: 'Oportunidades obtenidas exitosamente',
                content: {
                  'application/json': {
                    schema: {
                      type: 'array',
                      items: { $ref: '#/components/schemas/ArbitrageOpportunity' }
                    }
                  }
                }
              }
            }
          }
        };
        break;

      case '/api/execute':
        this.apiDefinition.paths[path] = {
          post: {
            tags: ['Execution'],
            summary: 'Ejecutar Oportunidad',
            description: 'Ejecuta una oportunidad de arbitraje específica',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      opportunityId: {
                        type: 'string',
                        description: 'ID de la oportunidad a ejecutar'
                      },
                      maxSlippage: {
                        type: 'number',
                        description: 'Slippage máximo permitido (%)',
                        default: 2.0
                      },
                      gasPrice: {
                        type: 'number',
                        description: 'Precio del gas (gwei)'
                      }
                    },
                    required: ['opportunityId']
                  }
                }
              }
            },
            responses: {
              '200': {
                description: 'Ejecución completada',
                content: {
                  'application/json': {
                    schema: { $ref: '#/components/schemas/ExecutionResult' }
                  }
                }
              },
              '400': {
                description: 'Parámetros inválidos',
                content: {
                  'application/json': {
                    schema: { $ref: '#/components/schemas/Error' }
                  }
                }
              },
              '404': {
                description: 'Oportunidad no encontrada',
                content: {
                  'application/json': {
                    schema: { $ref: '#/components/schemas/Error' }
                  }
                }
              }
            }
          }
        };
        break;

      case '/api/start':
        this.apiDefinition.paths[path] = {
          post: {
            tags: ['System'],
            summary: 'Iniciar Sistema',
            description: 'Inicia el motor de arbitraje',
            responses: {
              '200': {
                description: 'Sistema iniciado exitosamente',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        success: { type: 'boolean' },
                        message: { type: 'string' }
                      }
                    }
                  }
                }
              }
            }
          }
        };
        break;

      case '/api/stop':
        this.apiDefinition.paths[path] = {
          post: {
            tags: ['System'],
            summary: 'Detener Sistema',
            description: 'Detiene el motor de arbitraje',
            responses: {
              '200': {
                description: 'Sistema detenido exitosamente',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        success: { type: 'boolean' },
                        message: { type: 'string' }
                      }
                    }
                  }
                }
              }
            }
          }
        };
        break;

      case '/api/status':
        this.apiDefinition.paths[path] = {
          get: {
            tags: ['System'],
            summary: 'Estado del Sistema',
            description: 'Obtiene el estado actual del sistema',
            responses: {
              '200': {
                description: 'Estado obtenido exitosamente',
                content: {
                  'application/json': {
                    schema: { $ref: '#/components/schemas/SystemStatus' }
                  }
                }
              }
            }
          }
        };
        break;

      case '/api/stream':
        this.apiDefinition.paths[path] = {
          get: {
            tags: ['Real-time'],
            summary: 'Stream de Datos en Tiempo Real',
            description: 'Conexión Server-Sent Events para datos en tiempo real',
            responses: {
              '200': {
                description: 'Stream establecido',
                content: {
                  'text/event-stream': {
                    schema: {
                      type: 'string',
                      description: 'Stream de eventos en tiempo real'
                    }
                  }
                }
              }
            }
          }
        };
        break;
    }
  }

  analyzeServiceFile(filePath) {
    // Analizar archivos de servicios para encontrar más endpoints
    console.log(`   📄 Analizando: ${filePath}`);
  }

  async generateOpenAPISpec() {
    console.log('📝 Generando especificación OpenAPI...');

    const options = {
      definition: this.apiDefinition,
      apis: ['src/backend/*.js', 'src/services/*.ts'],
    };

    const specs = swaggerJsdoc(options);
    return specs;
  }

  async createDocumentationFiles(spec) {
    console.log('📁 Creando archivos de documentación...');

    // Crear directorio de documentación
    if (!fs.existsSync('docs/api')) {
      fs.mkdirSync('docs/api', { recursive: true });
    }

    // 1. Guardar especificación OpenAPI
    fs.writeFileSync('docs/api/openapi.json', JSON.stringify(spec, null, 2));
    console.log('   ✅ docs/api/openapi.json');

    // 2. Crear página HTML interactiva con Swagger UI
    const swaggerHTML = this.generateSwaggerHTML();
    fs.writeFileSync('docs/api/index.html', swaggerHTML);
    console.log('   ✅ docs/api/index.html');

    // 3. Crear README de la API
    const apiReadme = this.generateAPIReadme();
    fs.writeFileSync('docs/api/README.md', apiReadme);
    console.log('   ✅ docs/api/README.md');

    // 4. Crear ejemplos de uso
    const examples = this.generateAPIExamples();
    fs.writeFileSync('docs/api/examples.md', examples);
    console.log('   ✅ docs/api/examples.md');
  }

  generateSwaggerHTML() {
    return `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ArbitrageX Pro 2025 - API Documentation</title>
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@4.15.5/swagger-ui.css" />
    <style>
        html { box-sizing: border-box; overflow: -moz-scrollbars-vertical; overflow-y: scroll; }
        *, *:before, *:after { box-sizing: inherit; }
        body { margin:0; background: #fafafa; }
        .swagger-ui .topbar { background-color: #0087ff; }
        .swagger-ui .topbar .download-url-wrapper { display: none; }
    </style>
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://unpkg.com/swagger-ui-dist@4.15.5/swagger-ui-bundle.js"></script>
    <script src="https://unpkg.com/swagger-ui-dist@4.15.5/swagger-ui-standalone-preset.js"></script>
    <script>
    window.onload = function() {
        const ui = SwaggerUIBundle({
            url: './openapi.json',
            dom_id: '#swagger-ui',
            deepLinking: true,
            presets: [
                SwaggerUIBundle.presets.apis,
                SwaggerUIStandalonePreset
            ],
            plugins: [
                SwaggerUIBundle.plugins.DownloadUrl
            ],
            layout: "StandaloneLayout",
            tryItOutEnabled: true,
            requestInterceptor: (req) => {
                req.headers['X-API-Version'] = '1.0.0';
                return req;
            }
        });
    };
    </script>
</body>
</html>`;
  }

  generateAPIReadme() {
    return `# 🚀 ArbitrageX Pro 2025 - API Documentation

## 📖 Descripción

API REST completa para el sistema de arbitraje de criptomonedas más avanzado del mercado.

## 🌐 Entornos

- **Desarrollo**: http://localhost:3002
- **Staging**: https://staging.arbitragex.pro
- **Producción**: https://api.arbitragex.pro

## 🔑 Autenticación

Todas las APIs requieren autenticación JWT:

\`\`\`bash
curl -H "Authorization: Bearer <tu_jwt_token>" \\
     http://localhost:3002/api/metrics
\`\`\`

## 📊 Rate Limiting

| Endpoint | Límite |
|----------|--------|
| \`/api/metrics\` | 500/min |
| \`/api/opportunities\` | 100/min |
| \`/api/execute\` | 10/min |
| \`/health\` | Sin límite |

## 🚀 Quick Start

### 1. Health Check
\`\`\`bash
curl http://localhost:3002/health
\`\`\`

### 2. Obtener Métricas
\`\`\`bash
curl -H "Authorization: Bearer <token>" \\
     http://localhost:3002/api/metrics
\`\`\`

### 3. Listar Oportunidades
\`\`\`bash
curl -H "Authorization: Bearer <token>" \\
     http://localhost:3002/api/opportunities?status=pending&limit=10
\`\`\`

### 4. Ejecutar Arbitraje
\`\`\`bash
curl -X POST \\
     -H "Authorization: Bearer <token>" \\
     -H "Content-Type: application/json" \\
     -d '{"opportunityId": "arb_eth_usdc_12345", "maxSlippage": 2.0}' \\
     http://localhost:3002/api/execute
\`\`\`

## 📡 Tiempo Real

### Server-Sent Events
\`\`\`javascript
const eventSource = new EventSource('/api/stream');
eventSource.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Nueva métrica:', data);
};
\`\`\`

## 🛠️ SDKs y Clientes

- [Cliente TypeScript](./typescript-client/)
- [Cliente Python](./python-client/)
- [Cliente JavaScript](./javascript-client/)

## 📚 Documentación Interactiva

Visita [/docs/api/](./index.html) para explorar la API de forma interactiva con Swagger UI.

## 🆘 Soporte

- 📧 Email: support@arbitragex.pro
- 🐛 Issues: [GitHub Issues](https://github.com/arbitragex/issues)
- 💬 Discord: [ArbitrageX Community](https://discord.gg/arbitragex)
`;
  }

  generateAPIExamples() {
    return `# 📝 Ejemplos de Uso - ArbitrageX Pro API

## 🎯 Casos de Uso Comunes

### 1. Monitoreo Básico del Sistema

\`\`\`javascript
// Verificar salud del sistema
const checkHealth = async () => {
  const response = await fetch('/health');
  const data = await response.json();
  console.log('Sistema:', data.status);
};

// Obtener métricas actuales
const getMetrics = async () => {
  const response = await fetch('/api/metrics', {
    headers: { 'Authorization': 'Bearer ' + token }
  });
  const metrics = await response.json();
  console.log('GAP Score:', metrics.gapScore);
  console.log('ROI Net:', metrics.roiNet + '%');
};
\`\`\`

### 2. Gestión de Oportunidades

\`\`\`javascript
// Buscar oportunidades de alta rentabilidad
const findHighProfitOpportunities = async () => {
  const response = await fetch('/api/opportunities?status=pending&limit=10', {
    headers: { 'Authorization': 'Bearer ' + token }
  });
  const opportunities = await response.json();
  
  return opportunities.filter(opp => 
    opp.profit > 100 && opp.probability > 85
  );
};

// Ejecutar la mejor oportunidad
const executeBestOpportunity = async () => {
  const opportunities = await findHighProfitOpportunities();
  
  if (opportunities.length > 0) {
    const best = opportunities[0];
    
    const result = await fetch('/api/execute', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        opportunityId: best.id,
        maxSlippage: 2.0
      })
    });
    
    const execution = await result.json();
    console.log('Ejecutado:', execution.success);
    console.log('Profit real:', execution.actualProfit);
  }
};
\`\`\`

### 3. Control del Sistema

\`\`\`javascript
// Iniciar el motor de arbitraje
const startSystem = async () => {
  const response = await fetch('/api/start', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + token }
  });
  const result = await response.json();
  console.log('Sistema iniciado:', result.success);
};

// Detener el sistema
const stopSystem = async () => {
  const response = await fetch('/api/stop', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + token }
  });
  const result = await response.json();
  console.log('Sistema detenido:', result.success);
};

// Obtener estado del sistema
const getSystemStatus = async () => {
  const response = await fetch('/api/status', {
    headers: { 'Authorization': 'Bearer ' + token }
  });
  const status = await response.json();
  console.log('Sistema corriendo:', status.isRunning);
  console.log('Uptime:', status.uptime + 'ms');
};
\`\`\`

### 4. Datos en Tiempo Real

\`\`\`javascript
// Configurar stream de datos en tiempo real
const setupRealTimeData = () => {
  const eventSource = new EventSource('/api/stream');
  
  eventSource.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    if (data.gapScore !== undefined) {
      updateMetricsUI(data);
    }
    
    if (data.opportunity) {
      handleNewOpportunity(data.opportunity);
    }
  };
  
  eventSource.onerror = (error) => {
    console.error('Error en stream:', error);
    // Implementar reconexión automática
    setTimeout(setupRealTimeData, 5000);
  };
  
  return eventSource;
};

// Funciones de manejo de datos
const updateMetricsUI = (metrics) => {
  document.getElementById('gap-score').textContent = metrics.gapScore.toFixed(1);
  document.getElementById('roi-net').textContent = metrics.roiNet.toFixed(2) + '%';
  document.getElementById('latency').textContent = metrics.decisionLatency.toFixed(0) + 'ms';
};

const handleNewOpportunity = (opportunity) => {
  if (opportunity.profit > 50 && opportunity.probability > 80) {
    showNotification(\`Nueva oportunidad: $\${opportunity.profit.toFixed(2)}\`);
  }
};
\`\`\`

### 5. Manejo de Errores

\`\`\`javascript
// Wrapper para manejo de errores de API
const apiCall = async (url, options = {}) => {
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
        ...options.headers
      }
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(\`API Error: \${error.error.message}\`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error en API call:', error);
    throw error;
  }
};

// Uso del wrapper
const safeGetMetrics = async () => {
  try {
    const metrics = await apiCall('/api/metrics');
    return metrics;
  } catch (error) {
    console.error('No se pudieron obtener las métricas:', error.message);
    return null;
  }
};
\`\`\`

### 6. Integración con React

\`\`\`jsx
import { useState, useEffect } from 'react';

const ArbitrageMonitor = () => {
  const [metrics, setMetrics] = useState(null);
  const [opportunities, setOpportunities] = useState([]);
  const [isSystemRunning, setIsSystemRunning] = useState(false);
  
  useEffect(() => {
    // Cargar datos iniciales
    loadInitialData();
    
    // Configurar actualizaciones en tiempo real
    const eventSource = new EventSource('/api/stream');
    eventSource.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.gapScore !== undefined) {
        setMetrics(data);
      }
    };
    
    return () => eventSource.close();
  }, []);
  
  const loadInitialData = async () => {
    try {
      const [metricsRes, oppsRes, statusRes] = await Promise.all([
        apiCall('/api/metrics'),
        apiCall('/api/opportunities?limit=10'),
        apiCall('/api/status')
      ]);
      
      setMetrics(metricsRes);
      setOpportunities(oppsRes);
      setIsSystemRunning(statusRes.isRunning);
    } catch (error) {
      console.error('Error cargando datos:', error);
    }
  };
  
  const toggleSystem = async () => {
    try {
      const endpoint = isSystemRunning ? '/api/stop' : '/api/start';
      await apiCall(endpoint, { method: 'POST' });
      setIsSystemRunning(!isSystemRunning);
    } catch (error) {
      console.error('Error controlando sistema:', error);
    }
  };
  
  return (
    <div>
      <h1>ArbitrageX Monitor</h1>
      <button onClick={toggleSystem}>
        {isSystemRunning ? 'Detener' : 'Iniciar'} Sistema
      </button>
      
      {metrics && (
        <div>
          <p>GAP Score: {metrics.gapScore.toFixed(1)}</p>
          <p>ROI Net: {metrics.roiNet.toFixed(2)}%</p>
          <p>Latencia: {metrics.decisionLatency.toFixed(0)}ms</p>
        </div>
      )}
      
      <h2>Oportunidades ({opportunities.length})</h2>
      {opportunities.map(opp => (
        <div key={opp.id}>
          <strong>{opp.pair}</strong> - ${opp.profit.toFixed(2)}
          <button onClick={() => executeOpportunity(opp.id)}>
            Ejecutar
          </button>
        </div>
      ))}
    </div>
  );
};
\`\`\`

## 🔧 Utilidades

### Rate Limiting Helper

\`\`\`javascript
class RateLimiter {
  constructor(maxRequests = 100, windowMs = 60000) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
    this.requests = [];
  }
  
  canMakeRequest() {
    const now = Date.now();
    this.requests = this.requests.filter(time => now - time < this.windowMs);
    return this.requests.length < this.maxRequests;
  }
  
  recordRequest() {
    this.requests.push(Date.now());
  }
}

const rateLimiter = new RateLimiter(100, 60000);
\`\`\`

### JWT Token Manager

\`\`\`javascript
class TokenManager {
  constructor() {
    this.token = localStorage.getItem('arbitragex_token');
  }
  
  setToken(token) {
    this.token = token;
    localStorage.setItem('arbitragex_token', token);
  }
  
  getToken() {
    return this.token;
  }
  
  clearToken() {
    this.token = null;
    localStorage.removeItem('arbitragex_token');
  }
  
  isTokenExpired() {
    if (!this.token) return true;
    try {
      const payload = JSON.parse(atob(this.token.split('.')[1]));
      return Date.now() >= payload.exp * 1000;
    } catch {
      return true;
    }
  }
}

const tokenManager = new TokenManager();
\`\`\`
`;
  }

  async generateTypeScriptClient(spec) {
    console.log('🔷 Generando cliente TypeScript...');

    const clientCode = `/**
 * 🔷 ArbitrageX Pro 2025 - TypeScript Client
 * Cliente generado automáticamente para la API
 */

export interface GapMetrics {
  gapScore: number;
  priceGap: number;
  depthGap: number;
  latencyGap: number;
  riskGap: number;
  roiNet: number;
  collisionProb: number;
  decisionLatency: number;
}

export interface ArbitrageOpportunity {
  id: string;
  type: 'simple' | 'triangular' | 'cross-chain' | 'flash-loan';
  pair: string;
  profit: number;
  probability: number;
  risk: 'low' | 'medium' | 'high';
  status: 'pending' | 'executing' | 'executed' | 'failed' | 'expired';
  dexes: string[];
  blockchains: string[];
  estimatedGas: number;
  deadline: string;
}

export interface ExecutionResult {
  opportunityId: string;
  success: boolean;
  transactionHash?: string;
  actualProfit?: number;
  gasUsed?: number;
  executionTime?: number;
  error?: string;
}

export interface SystemStatus {
  isRunning: boolean;
  uptime: number;
  version: string;
  environment: 'development' | 'staging' | 'production';
  features: {
    flashLoans: boolean;
    mevProtection: boolean;
    multiChain: boolean;
    realTimeData: boolean;
  };
}

export class ArbitrageXClient {
  private baseUrl: string;
  private token: string | null = null;

  constructor(baseUrl: string = 'http://localhost:3002') {
    this.baseUrl = baseUrl;
  }

  setToken(token: string) {
    this.token = token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = \`\${this.baseUrl}\${endpoint}\`;
    
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...options.headers as Record<string, string>
    };

    if (this.token) {
      headers['Authorization'] = \`Bearer \${this.token}\`;
    }

    const response = await fetch(url, {
      ...options,
      headers
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(\`API Error: \${error.error?.message || response.statusText}\`);
    }

    return response.json();
  }

  // Health Check
  async health(): Promise<{ status: string; timestamp: string }> {
    return this.request('/health');
  }

  // Metrics
  async getMetrics(): Promise<GapMetrics> {
    return this.request('/api/metrics');
  }

  // Opportunities
  async getOpportunities(params?: {
    status?: string;
    type?: string;
    limit?: number;
  }): Promise<ArbitrageOpportunity[]> {
    const query = new URLSearchParams(params as any).toString();
    return this.request(\`/api/opportunities?\${query}\`);
  }

  // Execution
  async executeOpportunity(data: {
    opportunityId: string;
    maxSlippage?: number;
    gasPrice?: number;
  }): Promise<ExecutionResult> {
    return this.request('/api/execute', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  // System Control
  async startSystem(): Promise<{ success: boolean; message: string }> {
    return this.request('/api/start', { method: 'POST' });
  }

  async stopSystem(): Promise<{ success: boolean; message: string }> {
    return this.request('/api/stop', { method: 'POST' });
  }

  async getSystemStatus(): Promise<SystemStatus> {
    return this.request('/api/status');
  }

  // Real-time Stream
  createEventStream(onMessage: (data: any) => void): EventSource {
    const eventSource = new EventSource(\`\${this.baseUrl}/api/stream\`);
    
    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        onMessage(data);
      } catch (error) {
        console.error('Error parsing SSE data:', error);
      }
    };

    return eventSource;
  }
}

// Export default instance
export const arbitrageClient = new ArbitrageXClient();
`;

    fs.writeFileSync('docs/api/typescript-client.ts', clientCode);
    console.log('   ✅ docs/api/typescript-client.ts');
  }
}

// Ejecutar generador
const generator = new OpenAPIGenerator();
generator.generateDocumentation().catch(console.error);

export { OpenAPIGenerator };
