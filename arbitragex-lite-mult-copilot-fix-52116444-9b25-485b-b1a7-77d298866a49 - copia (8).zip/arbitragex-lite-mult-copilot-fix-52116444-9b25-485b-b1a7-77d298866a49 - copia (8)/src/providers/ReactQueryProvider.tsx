import React, { Suspense } from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

// Lazy load devtools para evitar errores en producción
const ReactQueryDevtools = React.lazy(() =>
  import('@tanstack/react-query-devtools').then(
    (mod) => ({ default: mod.ReactQueryDevtools }),
    () => ({ default: () => null }) // Fallback si falla la importación
  )
)

// Configuración del QueryClient
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutos
      refetchOnWindowFocus: false,
      retry: (failureCount, error) => {
        // No reintentar en errores 404 o 403
        if (error instanceof Error) {
          const errorMessage = error.message.toLowerCase()
          if (errorMessage.includes('404') || errorMessage.includes('403')) {
            return false
          }
        }
        return failureCount < 3
      },
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    },
    mutations: {
      retry: 1,
    },
  },
})

interface ReactQueryProviderProps {
  children: React.ReactNode
}

// Componente de DevTools con error boundary
const DevToolsWrapper: React.FC = () => {
  // Use import.meta.env instead of process.env for Vite
  if (import.meta.env.MODE !== 'development') {
    return null
  }

  return (
    <Suspense fallback={null}>
      <ReactQueryDevtools initialIsOpen={false} />
    </Suspense>
  )
}

export const ReactQueryProvider: React.FC<ReactQueryProviderProps> = ({ children }) => {
  return (
    <QueryClientProvider client={queryClient}>
      {children}
      <DevToolsWrapper />
    </QueryClientProvider>
  )
}

export { queryClient }