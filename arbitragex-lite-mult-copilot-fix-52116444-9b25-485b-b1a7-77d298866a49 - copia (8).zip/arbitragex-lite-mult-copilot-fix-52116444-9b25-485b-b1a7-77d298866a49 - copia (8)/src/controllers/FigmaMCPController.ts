import { FigmaAssetService, FigmaAsset, FigmaDesign } from '../services/FigmaAssetService';

export class FigmaMCPController {
  private figmaService: FigmaAssetService;

  constructor(accessToken: string) {
    this.figmaService = new FigmaAssetService(accessToken);
  }

  /**
   * Obtiene información de un archivo de Figma
   */
  async getFileInfo(fileId: string): Promise<FigmaDesign> {
    return await this.figmaService.getFileInfo(fileId);
  }

  /**
   * Lista todos los componentes de un archivo
   */
  async listComponents(fileId: string): Promise<any[]> {
    return await this.figmaService.getComponents(fileId);
  }

  /**
   * Obtiene assets específicos de un archivo
   */
  async getAssets(fileId: string, nodeIds: string[], format: 'png' | 'jpg' | 'svg' | 'pdf' = 'png', scale: number = 1): Promise<FigmaAsset[]> {
    return await this.figmaService.getAssets(fileId, nodeIds, format, scale);
  }

  /**
   * Sincroniza assets completos desde Figma
   */
  async syncAssets(fileId: string, outputDir: string): Promise<{ success: boolean; message: string; assetsCount: number }> {
    try {
      await this.figmaService.syncAssetsToProject(fileId, outputDir);
      return {
        success: true,
        message: 'Sincronización completada exitosamente',
        assetsCount: 0 // Se actualizará después
      };
    } catch (error) {
      return {
        success: false,
        message: `Error en sincronización: ${error}`,
        assetsCount: 0
      };
    }
  }

  /**
   * Busca componentes por nombre
   */
  async searchComponents(fileId: string, searchTerm: string): Promise<any[]> {
    const components = await this.figmaService.getComponents(fileId);
    return components.filter(component => 
      component.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  /**
   * Obtiene estadísticas del archivo
   */
  async getFileStats(fileId: string): Promise<{
    totalComponents: number;
    totalPages: number;
    lastModified: string;
    fileSize: string;
  }> {
    try {
      const fileInfo = await this.figmaService.getFileInfo(fileId);
      const components = await this.figmaService.getComponents(fileId);
      
      return {
        totalComponents: components.length,
        totalPages: 1, // Se puede implementar lógica más compleja
        lastModified: fileInfo.lastModified,
        fileSize: 'N/A' // Figma no proporciona tamaño de archivo
      };
    } catch (error) {
      throw new Error(`Error obteniendo estadísticas: ${error}`);
    }
  }
}
