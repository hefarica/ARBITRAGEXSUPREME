// audit/MockDataDetector.ts
/**
 * SISTEMA DE AUDITORÍA ZERO MOCK DATA
 * TOLERANCIA CERO para datos ficticios en cualquier entorno
 */

export interface MockDataFinding {
  timestamp: string;
  audit_session_id: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  mock_data_detected: {
    type: 'HARDCODED_DATA' | 'MOCK_API' | 'FAKE_DATABASE' | 'SAMPLE_FILE';
    location: string;
    content: string;
    scope: 'FRONTEND' | 'BACKEND' | 'DATABASE' | 'CONFIG';
    affected_functionality: string;
  };
  real_source_required: {
    recommended_source: string;
    integration_type: 'API' | 'DATABASE' | 'SERVICE' | 'FILE';
    authentication_needed: boolean;
    estimated_integration_time: string;
    business_criticality: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  };
  missing_credentials: {
    required_for_integration: string[];
    where_to_obtain: string;
    responsible_team: string;
    escalation_contact: string;
  };
  impact_assessment: {
    functionality_broken_without_real_data: boolean;
    user_experience_impact: string;
    business_process_impact: string;
    security_implications: string;
    compliance_issues: string;
  };
  remediation_plan: {
    immediate_actions: string[];
    integration_steps: string[];
    testing_requirements: string[];
    rollback_plan: string[];
    success_criteria: string[];
  };
}

export class MockDataDetector {
  private static readonly MOCK_PATTERNS = [
    // Texto identificadores críticos
    /mock/gi, /fake/gi, /dummy/gi, /sample/gi, /test/gi, /demo/gi, 
    /example/gi, /placeholder/gi, /lorem/gi, /ipsum/gi, /temp/gi, 
    /temporal/gi, /prueba/gi, /ejemplo/gi, /ficticio/gi, /simulado/gi,
    
    // Emails falsos
    /test@[\w.-]+/gi, /demo@[\w.-]+/gi, /example@[\w.-]+/gi, 
    /mock@[\w.-]+/gi, /fake@[\w.-]+/gi, /admin@test[\w.-]*/gi,
    
    // Teléfonos falsos
    /000-000-\d{4}/g, /111-111-\d{4}/g, /123-456-\d{4}/g, 
    /555-555-\d{4}/g, /999-999-\d{4}/g,
    
    // Nombres falsos
    /John Doe/gi, /Jane Smith/gi, /Test User/gi, /Demo User/gi, 
    /Usuario Prueba/gi, /Usuario Test/gi,
    
    // Direcciones falsas
    /123 Main St/gi, /Test Address/gi, /Sample Street/gi, 
    /Fake Avenue/gi, /Demo Street/gi,
    
    // IDs secuenciales obvios
    /test-id-\d+/gi, /sample-uuid-[\w-]+/gi, /demo-\d+/gi,
    
    // Fechas estáticas sospechosas
    /2023-01-01/g, /2024-01-01/g, /1970-01-01/g,
    
    // Montos redondos repetitivos
    /\$?100\.00/g, /\$?999\.99/g, /\$?1000\.00/g, /\$?0\.00/g
  ];

  private static readonly CORRECTIONS = [
    {
      pattern: /test@[\w.-]+/gi,
      suggestion: 'user.email (Fuente: Azure AD/LDAP)',
      integration: 'Microsoft Graph API / LDAP connector',
      credentials: ['Azure AD Client ID', 'Client Secret', 'Tenant ID']
    },
    {
      pattern: /demo@[\w.-]+/gi,
      suggestion: 'user.email (Fuente: OAuth Provider)',
      integration: 'OAuth 2.0 / OpenID Connect',
      credentials: ['OAuth Client ID', 'Client Secret', 'Provider URL']
    },
    {
      pattern: /John Doe|Jane Smith|Test User/gi,
      suggestion: 'user.displayName (Fuente: Directorio Empresarial)',
      integration: 'Active Directory / LDAP',
      credentials: ['LDAP Server URL', 'Bind DN', 'Password']
    },
    {
      pattern: /123 Main St|Sample Street/gi,
      suggestion: 'address.formatted (Fuente: Google Maps API)',
      integration: 'Google Geocoding API',
      credentials: ['Google Maps API Key', 'Service Account']
    },
    {
      pattern: /\$?100\.00|\$?999\.99/g,
      suggestion: 'amount (Fuente: Sistema Contable)',
      integration: 'QuickBooks API / SAP Finance',
      credentials: ['API Token', 'Company ID', 'OAuth Credentials']
    },
    {
      pattern: /000-000-\d{4}|555-555-\d{4}/g,
      suggestion: 'phone.number (Fuente: CRM)',
      integration: 'Salesforce / HubSpot API',
      credentials: ['CRM API Key', 'Organization ID']
    }
  ];

  private auditSessionId: string;
  private findings: MockDataFinding[] = [];

  constructor() {
    this.auditSessionId = `audit-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Escanea directorio completo buscando datos mock
   */
  async scanProject(rootPath: string = '/workspaces/spark-template/src'): Promise<MockDataFinding[]> {
    console.log('🔍 INICIANDO AUDITORÍA ZERO MOCK DATA');
    console.log(`📂 Escaneando: ${rootPath}`);
    console.log(`🆔 Session ID: ${this.auditSessionId}`);

    try {
      await this.scanDirectory(rootPath);
      
      // Generar reporte final
      await this.generateAuditReport();
      
      return this.findings;
    } catch (error) {
      console.error('❌ Error durante auditoría:', error);
      throw error;
    }
  }

  /**
   * Escanea recursivamente un directorio
   */
  private async scanDirectory(dirPath: string): Promise<void> {
    const fs = await import('fs');
    const path = await import('path');
    
    if (!fs.existsSync(dirPath)) {
      console.warn(`⚠️ Directorio no existe: ${dirPath}`);
      return;
    }

    const items = fs.readdirSync(dirPath);
    
    for (const item of items) {
      const fullPath = path.join(dirPath, item);
      const stat = fs.statSync(fullPath);

      if (stat.isDirectory()) {
        // Saltar node_modules y otras carpetas irrelevantes
        if (!this.shouldSkipDirectory(item)) {
          await this.scanDirectory(fullPath);
        }
      } else if (this.shouldScanFile(item)) {
        await this.scanFile(fullPath);
      }
    }
  }

  /**
   * Determina si debe saltar un directorio
   */
  private shouldSkipDirectory(dirName: string): boolean {
    const skipDirs = [
      'node_modules', '.git', '.vscode', 'dist', 'build', 
      'coverage', '.nyc_output', 'logs', 'tmp', 'temp'
    ];
    return skipDirs.includes(dirName) || dirName.startsWith('.');
  }

  /**
   * Determina si debe escanear un archivo
   */
  private shouldScanFile(fileName: string): boolean {
    const extensions = [
      '.js', '.jsx', '.ts', '.tsx', '.vue', '.py', '.java', 
      '.cs', '.php', '.json', '.xml', '.yml', '.yaml', 
      '.html', '.css', '.scss', '.less'
    ];
    return extensions.some(ext => fileName.toLowerCase().endsWith(ext));
  }

  /**
   * Escanea un archivo individual
   */
  private async scanFile(filePath: string): Promise<void> {
    const fs = await import('fs');
    
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const lines = content.split('\n');

      lines.forEach((line, index) => {
        this.scanLine(line, filePath, index + 1);
      });

    } catch (error) {
      console.warn(`⚠️ No se pudo leer archivo: ${filePath}`, error);
    }
  }

  /**
   * Escanea una línea individual
   */
  private scanLine(line: string, filePath: string, lineNumber: number): void {
    MockDataDetector.MOCK_PATTERNS.forEach(pattern => {
      const matches = line.match(pattern);
      if (matches) {
        matches.forEach(match => {
          const finding = this.createFinding(match, filePath, lineNumber, line);
          this.findings.push(finding);
          
          // Log inmediato para cada hallazgo
          console.log('🚨 MOCK DATA DETECTADO:', {
            file: filePath,
            line: lineNumber,
            content: match,
            severity: finding.severity
          });
        });
      }
    });
  }

  /**
   * Crea un hallazgo detallado
   */
  private createFinding(
    mockData: string, 
    filePath: string, 
    lineNumber: number, 
    fullLine: string
  ): MockDataFinding {
    const correction = this.findCorrection(mockData);
    const severity = this.calculateSeverity(mockData, filePath);
    
    return {
      timestamp: new Date().toISOString(),
      audit_session_id: this.auditSessionId,
      severity,
      mock_data_detected: {
        type: this.detectType(mockData, filePath),
        location: `${filePath}:${lineNumber}`,
        content: fullLine.trim(),
        scope: this.detectScope(filePath),
        affected_functionality: this.analyzeAffectedFunctionality(mockData, filePath)
      },
      real_source_required: {
        recommended_source: correction?.suggestion || 'Fuente real no identificada',
        integration_type: correction?.integration.includes('API') ? 'API' : 'SERVICE',
        authentication_needed: true,
        estimated_integration_time: this.estimateIntegrationTime(severity),
        business_criticality: severity
      },
      missing_credentials: {
        required_for_integration: correction?.credentials || ['Credenciales no especificadas'],
        where_to_obtain: 'Consultar con arquitecto de soluciones',
        responsible_team: 'Equipo de Desarrollo + DevOps',
        escalation_contact: 'CTO / Arquitecto Principal'
      },
      impact_assessment: {
        functionality_broken_without_real_data: severity === 'CRITICAL' || severity === 'HIGH',
        user_experience_impact: this.assessUXImpact(severity),
        business_process_impact: this.assessBusinessImpact(severity),
        security_implications: 'Datos no auditables, potencial fuga de información',
        compliance_issues: 'Incumplimiento de políticas de datos empresariales'
      },
      remediation_plan: {
        immediate_actions: [
          'Marcar código como MOCK_DATA_DETECTED',
          'Bloquear deploy si es crítico',
          'Notificar a responsables'
        ],
        integration_steps: [
          'Identificar fuente real de datos',
          'Obtener credenciales necesarias',
          'Implementar integración',
          'Realizar pruebas de conectividad',
          'Validar datos reales'
        ],
        testing_requirements: [
          'Test unitario de integración',
          'Test de conectividad',
          'Validación de formato de datos',
          'Test de performance'
        ],
        rollback_plan: [
          'Mantener código anterior como backup',
          'Plan de rollback automatizado',
          'Verificación post-rollback'
        ],
        success_criteria: [
          'Zero mock data detectado',
          'Integración funcionando',
          'Datos reales validados',
          'Performance aceptable'
        ]
      }
    };
  }

  /**
   * Encuentra la corrección apropiada para un dato mock
   */
  private findCorrection(mockData: string) {
    return MockDataDetector.CORRECTIONS.find(correction => 
      correction.pattern.test(mockData)
    );
  }

  /**
   * Calcula la severidad del hallazgo
   */
  private calculateSeverity(mockData: string, filePath: string): 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' {
    // Crítico: autenticación, pagos, datos sensibles
    if (filePath.includes('auth') || filePath.includes('payment') || filePath.includes('security')) {
      return 'CRITICAL';
    }
    
    // Alto: funcionalidad core de negocio
    if (filePath.includes('api') || filePath.includes('service') || filePath.includes('core')) {
      return 'HIGH';
    }
    
    // Medio: UI y componentes
    if (filePath.includes('component') || filePath.includes('ui')) {
      return 'MEDIUM';
    }
    
    // Bajo: testing y desarrollo
    if (filePath.includes('test') || filePath.includes('dev')) {
      return 'LOW';
    }
    
    return 'MEDIUM';
  }

  /**
   * Detecta el tipo de mock data
   */
  private detectType(mockData: string, filePath: string): 'HARDCODED_DATA' | 'MOCK_API' | 'FAKE_DATABASE' | 'SAMPLE_FILE' {
    if (filePath.includes('api')) return 'MOCK_API';
    if (filePath.includes('db') || filePath.includes('database')) return 'FAKE_DATABASE';
    if (filePath.includes('sample') || filePath.includes('example')) return 'SAMPLE_FILE';
    return 'HARDCODED_DATA';
  }

  /**
   * Detecta el scope del archivo
   */
  private detectScope(filePath: string): 'FRONTEND' | 'BACKEND' | 'DATABASE' | 'CONFIG' {
    if (filePath.includes('component') || filePath.includes('ui') || filePath.includes('frontend')) {
      return 'FRONTEND';
    }
    if (filePath.includes('api') || filePath.includes('service') || filePath.includes('backend')) {
      return 'BACKEND';
    }
    if (filePath.includes('db') || filePath.includes('database') || filePath.includes('migration')) {
      return 'DATABASE';
    }
    if (filePath.includes('config') || filePath.includes('env')) {
      return 'CONFIG';
    }
    return 'FRONTEND';
  }

  /**
   * Analiza funcionalidad afectada
   */
  private analyzeAffectedFunctionality(mockData: string, filePath: string): string {
    if (mockData.includes('@')) return 'Sistema de autenticación y usuarios';
    if (mockData.includes('$') || mockData.includes('amount')) return 'Sistema financiero y pagos';
    if (mockData.includes('phone') || /\d{3}-\d{3}-\d{4}/.test(mockData)) return 'Sistema de contactos';
    if (mockData.includes('address') || mockData.includes('street')) return 'Sistema de direcciones';
    return 'Funcionalidad no identificada';
  }

  /**
   * Estima tiempo de integración
   */
  private estimateIntegrationTime(severity: string): string {
    switch (severity) {
      case 'CRITICAL': return '2-4 horas';
      case 'HIGH': return '4-8 horas';
      case 'MEDIUM': return '1-2 días';
      case 'LOW': return '2-5 días';
      default: return '1-3 días';
    }
  }

  /**
   * Evalúa impacto en UX
   */
  private assessUXImpact(severity: string): string {
    switch (severity) {
      case 'CRITICAL': return 'Funcionalidad completamente rota';
      case 'HIGH': return 'Experiencia significativamente degradada';
      case 'MEDIUM': return 'Confusión del usuario con datos falsos';
      case 'LOW': return 'Impacto mínimo en desarrollo';
      default: return 'Impacto no evaluado';
    }
  }

  /**
   * Evalúa impacto en negocio
   */
  private assessBusinessImpact(severity: string): string {
    switch (severity) {
      case 'CRITICAL': return 'Pérdida de confianza, imposibilidad de operar';
      case 'HIGH': return 'Decisiones basadas en datos incorrectos';
      case 'MEDIUM': return 'Procesos de negocio con datos inconsistentes';
      case 'LOW': return 'Impacto limitado a desarrollo';
      default: return 'Impacto no evaluado';
    }
  }

  /**
   * Genera reporte final de auditoría
   */
  private async generateAuditReport(): Promise<void> {
    const report = {
      audit_summary: {
        session_id: this.auditSessionId,
        timestamp: new Date().toISOString(),
        total_findings: this.findings.length,
        critical_findings: this.findings.filter(f => f.severity === 'CRITICAL').length,
        high_findings: this.findings.filter(f => f.severity === 'HIGH').length,
        medium_findings: this.findings.filter(f => f.severity === 'MEDIUM').length,
        low_findings: this.findings.filter(f => f.severity === 'LOW').length,
        mock_data_ratio: this.findings.length > 0 ? 'FAIL - MOCK DATA DETECTED' : 'PASS - ZERO MOCK DATA',
        deployment_blocked: this.findings.some(f => f.severity === 'CRITICAL' || f.severity === 'HIGH')
      },
      findings: this.findings,
      next_actions: this.generateNextActions()
    };

    console.log('\n📊 REPORTE DE AUDITORÍA FINAL:');
    console.log(JSON.stringify(report.audit_summary, null, 2));

    if (this.findings.length > 0) {
      console.log('\n🚨 ACCIÓN REQUERIDA:');
      console.log('❌ MOCK DATA DETECTADO - DESPLIEGUE BLOQUEADO');
      console.log(`📝 Total hallazgos: ${this.findings.length}`);
      console.log(`🔴 Críticos: ${report.audit_summary.critical_findings}`);
      console.log(`🟠 Altos: ${report.audit_summary.high_findings}`);
    } else {
      console.log('\n✅ AUDITORÍA EXITOSA:');
      console.log('🎉 ZERO MOCK DATA DETECTADO');
      console.log('✅ SISTEMA LISTO PARA DESPLIEGUE');
    }
  }

  /**
   * Genera acciones siguientes recomendadas
   */
  private generateNextActions(): string[] {
    if (this.findings.length === 0) {
      return ['Sistema limpio - continuar con despliegue normal'];
    }

    const actions = [];
    const criticalCount = this.findings.filter(f => f.severity === 'CRITICAL').length;
    const highCount = this.findings.filter(f => f.severity === 'HIGH').length;

    if (criticalCount > 0) {
      actions.push(`INMEDIATO: Remediar ${criticalCount} hallazgos CRÍTICOS antes de cualquier deploy`);
    }

    if (highCount > 0) {
      actions.push(`URGENTE: Remediar ${highCount} hallazgos de prioridad ALTA`);
    }

    actions.push('Implementar integraciones reales según plan de remediación');
    actions.push('Re-ejecutar auditoría después de cada corrección');
    actions.push('Configurar pipeline CI/CD para prevenir futuros mock data');

    return actions;
  }

  /**
   * Ejecuta auditoría y bloquea deploy si es necesario
   */
  async auditAndBlock(): Promise<boolean> {
    const findings = await this.scanProject();
    const hasBlockingIssues = findings.some(f => 
      f.severity === 'CRITICAL' || f.severity === 'HIGH'
    );

    if (hasBlockingIssues) {
      console.log('\n🚫 DEPLOY BLOQUEADO POR MOCK DATA');
      console.log('🔧 Corrija todos los hallazgos críticos y de alta prioridad');
      return false;
    }

    console.log('\n✅ AUDITORÍA PASADA - DEPLOY PERMITIDO');
    return true;
  }
}

// Exportar instancia singleton
export const mockDataDetector = new MockDataDetector();