export enum ThreatType {
  FRONTRUNNER = 'FRONTRUNNER',
  SANDWICH_ATTACKER = 'SANDWICH_ATTACKER',
  COPYCAT = 'COPYCAT',
  MEMPOOL_SNIFFER = 'MEMPOOL_SNIFFER',
  VALIDATOR_CORRUPTION = 'VALIDATOR_CORRUPTION'
}

export enum ThreatLevel {
  MINOR = 'MINOR',
  MODERATE = 'MODERATE',
  MAJOR = 'MAJOR',
  NUCLEAR = 'NUCLEAR'
}

export interface MEVDefenseConfig {
  autoResponse: boolean;
  escalationEnabled: boolean;
  coalitionMode: boolean;
  nuclearApprovalRequired: boolean;
  maxConcurrentThreats: number;
  threatMemoryDuration: number;
  responseCooldown: number;
}

export interface Threat {
  id: string;
  type: ThreatType;
  level: ThreatLevel;
  address: string;
  confidence: number;
  timestamp: number;
  evidence: any;
  status: 'ACTIVE' | 'RESOLVED' | 'ESCALATED';
  responseCount: number;
  lastResponse?: DefenseResponse;
}

export interface DefenseResponse {
  id: string;
  threatId: string;
  type: ThreatType;
  level: ThreatLevel;
  success: boolean;
  timestamp: number;
  actions: string[];
  executionTime: number;
  error?: string;
  details?: any;
}

export interface AttackPattern {
  attacker: string;
  type: ThreatType;
  severity: ThreatLevel;
  evidence: any;
  timestamp: number;
  confidence: number;
}

export interface CoalitionMember {
  id: string;
  address: string;
  reputation: number;
  joinDate: number;
  lastActive: number;
  threatReports: number;
  successfulDefenses: number;
}

export interface CoordinatedAttack {
  id: string;
  target: string;
  type: ThreatType;
  participants: string[];
  startTime: number;
  endTime?: number;
  success: boolean;
  actions: string[];
}

export interface ThreatIntelligence {
  threatId: string;
  type: ThreatType;
  level: ThreatLevel;
  source: string;
  confidence: number;
  timestamp: number;
  evidence: any;
  recommendations: string[];
}

export interface DefenseModule {
  name: string;
  type: ThreatType;
  enabled: boolean;
  config: any;
  lastUsed: number;
  successRate: number;
  totalUses: number;
}

export interface EmergencyMode {
  type: 'NUCLEAR_DEFENSE' | 'PERSISTENT_THREAT' | 'COALITION_WAR';
  active: boolean;
  startTime: number;
  endTime?: number;
  reason: string;
  actions: string[];
  participants: string[];
}

export interface PayloadConfig {
  defense_system: {
    auto_response: boolean;
    escalation_enabled: boolean;
    coalition_mode: boolean;
    nuclear_approval_required: boolean;
    max_concurrent_threats: number;
    threat_memory_duration: number;
    response_cooldown: number;
  };
  escalation_thresholds: {
    minor_to_moderate: number;
    moderate_to_major: number;
    major_to_nuclear: number;
  };
  payloads: {
    [key in ThreatType]: {
      minor: any;
      moderate: any;
      major: any;
      nuclear: any;
    };
  };
  coalition_defense: {
    max_members: number;
    min_response_time: number;
    threat_sharing: boolean;
    coordinated_counterattacks: boolean;
    reputation_system: boolean;
    auto_blacklist: boolean;
    attack_strategies: any;
  };
  automated_responses: {
    threat_classification: any;
    response_execution: any;
  };
  emergency_modes: {
    nuclear_defense: any;
    persistent_threat: any;
    coalition_war: any;
  };
}

export interface HoneyTrapConfig {
  bait_value_range: [string, string];
  gas_price_multiplier: number;
  trap_timeout: number;
  max_traps_per_address: number;
}

export interface StrategyPoisonConfig {
  poison_types: string[];
  poison_success_rate: number;
  max_poison_per_address: number;
  poison_timeout: number;
  coalition_mode: boolean;
}

export interface EconomicWarfareConfig {
  max_gas_spend_eth: number;
  boycott_threshold: number;
  mev_manipulation_enabled: boolean;
  exposure_campaigns: boolean;
  coalition_mode: boolean;
  persistent_economic_damage: boolean;
}

export interface CoalitionDefenseConfig {
  max_members: number;
  min_response_time: number;
  threat_sharing: boolean;
  coordinated_counterattacks: boolean;
  reputation_system: boolean;
  auto_blacklist: boolean;
}

export interface AutomatedDefenseConfig {
  auto_response: boolean;
  escalation_enabled: boolean;
  coalition_mode: boolean;
  nuclear_approval_required: boolean;
  max_concurrent_threats: number;
  threat_memory_duration: number;
  response_cooldown: number;
}

export interface ThreatClassifier {
  indicators: string[];
  confidence_threshold: number;
  pattern_type: string;
  response_strategy: string;
}

export interface ResponseExecution {
  modules: string[];
  execution_timeout: number;
  escalation_factor: number;
  coalition_required: boolean;
}

export interface EmergencyModeConfig {
  activation_threshold: number;
  max_duration: number;
  auto_deactivation: boolean;
  coalition_alert: boolean;
  manual_deactivation_required?: boolean;
  coordinated_response?: boolean;
}
