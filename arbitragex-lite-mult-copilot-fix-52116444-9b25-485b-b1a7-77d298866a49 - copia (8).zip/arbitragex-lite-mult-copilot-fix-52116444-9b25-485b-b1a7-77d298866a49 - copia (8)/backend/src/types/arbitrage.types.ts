export interface RiskParameters {
  maxSlippage: number;
  maxGasPrice: number;
  maxPositionSize: string;
  minProfitThreshold: number;
  maxPriceImpact: number;
  maxExecutionTime: number;
  enableFlashLoans: boolean;
  maxFlashLoanAmount: string;
}

export interface ArbitrageOpportunity {
  id: string;
  path: string[];
  dexes: string[];
  pools: string[];
  amountIn: string;
  expectedAmountOut: string;
  netProfit: string;
  confidence: number;
  executionDeadline: number;
  chainId: number;
  timestamp: number;
}

export interface ArbitrageResult {
  success: boolean;
  transactionHash: string;
  gasUsed: number;
  profit: number;
  executionTime: number;
  status: string;
}

export interface ArbitrageStatus {
  isActive: boolean;
  lastExecution: string;
  totalExecutions: number;
  successRate: number;
  averageProfit: number;
  activeOpportunities: number;
}

export interface ArbitrageMetrics {
  totalVolume: string;
  totalProfit: string;
  averageROI: string;
  gasEfficiency: string;
  executionSpeed: string;
  successRate: string;
}
