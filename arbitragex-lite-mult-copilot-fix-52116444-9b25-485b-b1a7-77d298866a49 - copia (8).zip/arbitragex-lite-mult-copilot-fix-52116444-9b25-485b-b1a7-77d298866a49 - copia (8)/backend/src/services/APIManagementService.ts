import axios, { AxiosResponse } from 'axios';
import { ethers } from 'ethers';
import { logger } from '../utils/logger';

export interface APIKey {
    id: string;
    name: string;
    key: string;
    isActive: boolean;
    lastTested?: Date;
    status: 'active' | 'inactive' | 'error';
    rateLimit?: {
        remaining: number;
        reset: Date;
    };
}

export interface APIConfig {
    coingecko: {
        apiKey: string;
        baseUrl: string;
        isPro: boolean;
    };
    dexscreener: {
        apiKey: string;
        baseUrl: string;
    };
    ethereum: {
        rpcUrl: string;
        provider: ethers.providers.JsonRpcProvider | null;
    };
    polygon: {
        rpcUrl: string;
        provider: ethers.providers.JsonRpcProvider | null;
    };
    etherscan: {
        apiKey: string;
        baseUrl: string;
    };
    uniswap: {
        subgraphKey: string;
        baseUrl: string;
    };
    aave: {
        apiKey: string;
        baseUrl: string;
    };
}

export interface APIStatus {
    service: string;
    status: 'connected' | 'disconnected' | 'error';
    latency?: number;
    lastChecked: Date;
    error?: string;
    rateLimit?: {
        remaining: number;
        reset: Date;
    };
}

export class APIManagementService {
    private config: APIConfig;
    private apiStatuses: Map<string, APIStatus> = new Map();
    private isInitialized: boolean = false;

    constructor() {
        this.config = this.loadDefaultConfig();
        this.initializeProviders();
    }

    private loadDefaultConfig(): APIConfig {
        return {
            coingecko: {
                apiKey: process.env.COINGECKO_API_KEY || '',
                baseUrl: 'https://api.coingecko.com/api/v3',
                isPro: false
            },
            dexscreener: {
                apiKey: process.env.DEXSCREENER_API_KEY || '',
                baseUrl: 'https://api.dexscreener.com/latest'
            },
            ethereum: {
                rpcUrl: process.env.ETHEREUM_RPC_URL || '',
                provider: null
            },
            polygon: {
                rpcUrl: process.env.POLYGON_RPC_URL || '',
                provider: null
            },
            etherscan: {
                apiKey: process.env.ETHERSCAN_API_KEY || '',
                baseUrl: 'https://api.etherscan.io/api'
            },
            uniswap: {
                subgraphKey: process.env.UNISWAP_SUBGRAPH_KEY || '',
                baseUrl: 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3'
            },
            aave: {
                apiKey: process.env.AAVE_API_KEY || '',
                baseUrl: 'https://api.aave.com'
            }
        };
    }

    private initializeProviders(): void {
        try {
            if (this.config.ethereum.rpcUrl) {
                this.config.ethereum.provider = new ethers.providers.JsonRpcProvider(this.config.ethereum.rpcUrl);
            }
            if (this.config.polygon.rpcUrl) {
                this.config.polygon.provider = new ethers.providers.JsonRpcProvider(this.config.polygon.rpcUrl);
            }
        } catch (error) {
            logger.error('Error initializing providers:', error);
        }
    }

    public async updateConfig(newConfig: Partial<APIConfig>): Promise<void> {
        this.config = { ...this.config, ...newConfig };
        this.initializeProviders();
        await this.testAllAPIs();
    }

    public getConfig(): APIConfig {
        return { ...this.config };
    }

    public async testCoinGeckoAPI(): Promise<APIStatus> {
        const startTime = Date.now();
        try {
            const url = this.config.coingecko.isPro 
                ? `${this.config.coingecko.baseUrl}/ping`
                : `${this.config.coingecko.baseUrl}/ping`;

            const headers: any = {};
            if (this.config.coingecko.apiKey) {
                headers['X-CG-Pro-API-Key'] = this.config.coingecko.apiKey;
            }

            const response = await axios.get(url, { 
                headers,
                timeout: 10000 
            });

            const latency = Date.now() - startTime;
            const status: APIStatus = {
                service: 'coingecko',
                status: 'connected',
                latency,
                lastChecked: new Date()
            };

            // Check rate limits from headers
            if (response.headers['x-ratelimit-remaining']) {
                status.rateLimit = {
                    remaining: parseInt(response.headers['x-ratelimit-remaining']),
                    reset: new Date(Date.now() + parseInt(response.headers['x-ratelimit-reset']) * 1000)
                };
            }

            this.apiStatuses.set('coingecko', status);
            return status;

        } catch (error: any) {
            const status: APIStatus = {
                service: 'coingecko',
                status: 'error',
                lastChecked: new Date(),
                error: error.message
            };
            this.apiStatuses.set('coingecko', status);
            return status;
        }
    }

    public async testDexScreenerAPI(): Promise<APIStatus> {
        const startTime = Date.now();
        try {
            const url = `${this.config.dexscreener.baseUrl}/dex/search?q=ethereum`;
            const headers: any = {};
            if (this.config.dexscreener.apiKey) {
                headers['Authorization'] = `Bearer ${this.config.dexscreener.apiKey}`;
            }

            const response = await axios.get(url, { 
                headers,
                timeout: 10000 
            });

            const latency = Date.now() - startTime;
            const status: APIStatus = {
                service: 'dexscreener',
                status: 'connected',
                latency,
                lastChecked: new Date()
            };

            this.apiStatuses.set('dexscreener', status);
            return status;

        } catch (error: any) {
            const status: APIStatus = {
                service: 'dexscreener',
                status: 'error',
                lastChecked: new Date(),
                error: error.message
            };
            this.apiStatuses.set('dexscreener', status);
            return status;
        }
    }

    public async testEthereumRPC(): Promise<APIStatus> {
        const startTime = Date.now();
        try {
            if (!this.config.ethereum.provider) {
                throw new Error('Ethereum provider not configured');
            }

            const blockNumber = await this.config.ethereum.provider.getBlockNumber();
            const latency = Date.now() - startTime;

            const status: APIStatus = {
                service: 'ethereum',
                status: 'connected',
                latency,
                lastChecked: new Date()
            };

            this.apiStatuses.set('ethereum', status);
            return status;

        } catch (error: any) {
            const status: APIStatus = {
                service: 'ethereum',
                status: 'error',
                lastChecked: new Date(),
                error: error.message
            };
            this.apiStatuses.set('ethereum', status);
            return status;
        }
    }

    public async testPolygonRPC(): Promise<APIStatus> {
        const startTime = Date.now();
        try {
            if (!this.config.polygon.provider) {
                throw new Error('Polygon provider not configured');
            }

            const blockNumber = await this.config.polygon.provider.getBlockNumber();
            const latency = Date.now() - startTime;

            const status: APIStatus = {
                service: 'polygon',
                status: 'connected',
                latency,
                lastChecked: new Date()
            };

            this.apiStatuses.set('polygon', status);
            return status;

        } catch (error: any) {
            const status: APIStatus = {
                service: 'polygon',
                status: 'error',
                lastChecked: new Date(),
                error: error.message
            };
            this.apiStatuses.set('polygon', status);
            return status;
        }
    }

    public async testEtherscanAPI(): Promise<APIStatus> {
        const startTime = Date.now();
        try {
            const url = `${this.config.etherscan.baseUrl}?module=proxy&action=eth_blockNumber&apikey=${this.config.etherscan.apiKey}`;
            
            const response = await axios.get(url, { timeout: 10000 });
            const latency = Date.now() - startTime;

            if (response.data.status === '1') {
                const status: APIStatus = {
                    service: 'etherscan',
                    status: 'connected',
                    latency,
                    lastChecked: new Date()
                };

                // Check rate limits
                if (response.headers['x-ratelimit-remaining']) {
                    status.rateLimit = {
                        remaining: parseInt(response.headers['x-ratelimit-remaining']),
                        reset: new Date(Date.now() + parseInt(response.headers['x-ratelimit-reset']) * 1000)
                    };
                }

                this.apiStatuses.set('etherscan', status);
                return status;
            } else {
                throw new Error(response.data.message || 'Etherscan API error');
            }

        } catch (error: any) {
            const status: APIStatus = {
                service: 'etherscan',
                status: 'error',
                lastChecked: new Date(),
                error: error.message
            };
            this.apiStatuses.set('etherscan', status);
            return status;
        }
    }

    public async testUniswapSubgraph(): Promise<APIStatus> {
        const startTime = Date.now();
        try {
            const query = `
                query {
                    factories(first: 1) {
                        id
                        poolCount
                    }
                }
            `;

            const url = this.config.uniswap.baseUrl;
            const headers: any = {};
            if (this.config.uniswap.subgraphKey) {
                headers['Authorization'] = `Bearer ${this.config.uniswap.subgraphKey}`;
            }

            const response = await axios.post(url, { query }, { 
                headers,
                timeout: 10000 
            });

            const latency = Date.now() - startTime;
            const status: APIStatus = {
                service: 'uniswap',
                status: 'connected',
                latency,
                lastChecked: new Date()
            };

            this.apiStatuses.set('uniswap', status);
            return status;

        } catch (error: any) {
            const status: APIStatus = {
                service: 'uniswap',
                status: 'error',
                lastChecked: new Date(),
                error: error.message
            };
            this.apiStatuses.set('uniswap', status);
            return status;
        }
    }

    public async testAaveAPI(): Promise<APIStatus> {
        const startTime = Date.now();
        try {
            const url = `${this.config.aave.baseUrl}/v3/markets`;
            const headers: any = {};
            if (this.config.aave.apiKey) {
                headers['Authorization'] = `Bearer ${this.config.aave.apiKey}`;
            }

            const response = await axios.get(url, { 
                headers,
                timeout: 10000 
            });

            const latency = Date.now() - startTime;
            const status: APIStatus = {
                service: 'aave',
                status: 'connected',
                latency,
                lastChecked: new Date()
            };

            this.apiStatuses.set('aave', status);
            return status;

        } catch (error: any) {
            const status: APIStatus = {
                service: 'aave',
                status: 'error',
                lastChecked: new Date(),
                error: error.message
            };
            this.apiStatuses.set('aave', status);
            return status;
        }
    }

    public async testAllAPIs(): Promise<Map<string, APIStatus>> {
        logger.info('Testing all APIs...');

        const promises = [
            this.testCoinGeckoAPI(),
            this.testDexScreenerAPI(),
            this.testEthereumRPC(),
            this.testPolygonRPC(),
            this.testEtherscanAPI(),
            this.testUniswapSubgraph(),
            this.testAaveAPI()
        ];

        await Promise.allSettled(promises);
        
        logger.info('All APIs tested');
        return this.apiStatuses;
    }

    public getAPIStatuses(): Map<string, APIStatus> {
        return new Map(this.apiStatuses);
    }

    public getAPIStatus(service: string): APIStatus | undefined {
        return this.apiStatuses.get(service);
    }

    public async getCoinGeckoPrices(coins: string[]): Promise<any> {
        try {
            const url = `${this.config.coingecko.baseUrl}/simple/price`;
            const params = {
                ids: coins.join(','),
                vs_currencies: 'usd,eur,btc',
                include_24hr_change: true,
                include_market_cap: true
            };

            const headers: any = {};
            if (this.config.coingecko.apiKey) {
                headers['X-CG-Pro-API-Key'] = this.config.coingecko.apiKey;
            }

            const response = await axios.get(url, { params, headers });
            return response.data;

        } catch (error) {
            logger.error('Error fetching CoinGecko prices:', error);
            throw error;
        }
    }

    public async getDexScreenerData(pair: string): Promise<any> {
        try {
            const url = `${this.config.dexscreener.baseUrl}/dex/pairs/${pair}`;
            const headers: any = {};
            if (this.config.dexscreener.apiKey) {
                headers['Authorization'] = `Bearer ${this.config.dexscreener.apiKey}`;
            }

            const response = await axios.get(url, { headers });
            return response.data;

        } catch (error) {
            logger.error('Error fetching DexScreener data:', error);
            throw error;
        }
    }

    public async getEthereumGasPrice(): Promise<any> {
        try {
            if (!this.config.ethereum.provider) {
                throw new Error('Ethereum provider not configured');
            }

            const gasPrice = await this.config.ethereum.provider.getGasPrice();
            const feeData = await this.config.ethereum.provider.getFeeData();

            return {
                gasPrice: ethers.utils.formatUnits(gasPrice, 'gwei'),
                maxFeePerGas: feeData.maxFeePerGas ? ethers.utils.formatUnits(feeData.maxFeePerGas, 'gwei') : null,
                maxPriorityFeePerGas: feeData.maxPriorityFeePerGas ? ethers.utils.formatUnits(feeData.maxPriorityFeePerGas, 'gwei') : null
            };

        } catch (error) {
            logger.error('Error fetching Ethereum gas price:', error);
            throw error;
        }
    }

    public async getPolygonGasPrice(): Promise<any> {
        try {
            if (!this.config.polygon.provider) {
                throw new Error('Polygon provider not configured');
            }

            const gasPrice = await this.config.polygon.provider.getGasPrice();
            const feeData = await this.config.polygon.provider.getFeeData();

            return {
                gasPrice: ethers.utils.formatUnits(gasPrice, 'gwei'),
                maxFeePerGas: feeData.maxFeePerGas ? ethers.utils.formatUnits(feeData.maxFeePerGas, 'gwei') : null,
                maxPriorityFeePerGas: feeData.maxPriorityFeePerGas ? ethers.utils.formatUnits(feeData.maxPriorityFeePerGas, 'gwei') : null
            };

        } catch (error) {
            logger.error('Error fetching Polygon gas price:', error);
            throw error;
        }
    }

    public async getEtherscanTransaction(txHash: string): Promise<any> {
        try {
            const url = `${this.config.etherscan.baseUrl}`;
            const params = {
                module: 'proxy',
                action: 'eth_getTransactionByHash',
                txhash: txHash,
                apikey: this.config.etherscan.apiKey
            };

            const response = await axios.get(url, { params });
            return response.data;

        } catch (error) {
            logger.error('Error fetching Etherscan transaction:', error);
            throw error;
        }
    }

    public async getUniswapPoolData(poolAddress: string): Promise<any> {
        try {
            const query = `
                query {
                    pool(id: "${poolAddress}") {
                        id
                        token0Price
                        token1Price
                        liquidity
                        volumeUSD
                        feesUSD
                    }
                }
            `;

            const url = this.config.uniswap.baseUrl;
            const headers: any = {};
            if (this.config.uniswap.subgraphKey) {
                headers['Authorization'] = `Bearer ${this.config.uniswap.subgraphKey}`;
            }

            const response = await axios.post(url, { query }, { headers });
            return response.data;

        } catch (error) {
            logger.error('Error fetching Uniswap pool data:', error);
            throw error;
        }
    }

    public async getAaveReserveData(asset: string): Promise<any> {
        try {
            const url = `${this.config.aave.baseUrl}/v3/reserves/${asset}`;
            const headers: any = {};
            if (this.config.aave.apiKey) {
                headers['Authorization'] = `Bearer ${this.config.aave.apiKey}`;
            }

            const response = await axios.get(url, { headers });
            return response.data;

        } catch (error) {
            logger.error('Error fetching Aave reserve data:', error);
            throw error;
        }
    }

    public isInitialized(): boolean {
        return this.isInitialized;
    }

    public async initialize(): Promise<void> {
        try {
            await this.testAllAPIs();
            this.isInitialized = true;
            logger.info('APIManagementService initialized successfully');
        } catch (error) {
            logger.error('Error initializing APIManagementService:', error);
            throw error;
        }
    }
}
