import * as fs from 'fs';
import * as path from 'path';

/**
 * Interfaz para una entrada individual de DEX
 */
export interface DexEntry {
  name: string;
  source: string;
  enabled: boolean;
  last_validated: number;
  validation_note: string;
  tvl?: number;
  change_1h?: number;
  change_1d?: number;
  change_7d?: number;
  trust_score?: number;
  volume_24h?: number;
  pair_count?: number;
  factory_address?: string;
}

/**
 * Interfaz para el registro completo de DEX
 */
export interface DexRegistry {
  metadata: {
    version: string;
    last_updated: number;
    total_chains: number;
    total_dexes: number;
    discovery_sources: string[];
    validation_method: string;
  };
  chains: {
    [chain: string]: {
      [dexId: string]: DexEntry;
    };
  };
}

/**
 * Ruta al archivo de registro de DEX
 */
const REG_PATH = path.resolve(process.cwd(), 'backend/src/config/dex_registry.json');

/**
 * Carga el registro de DEX desde el archivo JSON
 */
export function loadDexRegistry(): DexRegistry {
  try {
    if (!fs.existsSync(REG_PATH)) {
      console.warn(`⚠️  Archivo de registro de DEX no encontrado en ${REG_PATH}`);
      return {
        metadata: {
          version: "0.0.0",
          last_updated: 0,
          total_chains: 0,
          total_dexes: 0,
          discovery_sources: [],
          validation_method: "none"
        },
        chains: {}
      };
    }

    const data = fs.readFileSync(REG_PATH, 'utf8');
    const registry: DexRegistry = JSON.parse(data);
    
    console.log(`✅ Registro de DEX cargado: ${registry.metadata.total_dexes} DEX en ${registry.metadata.total_chains} chains`);
    return registry;
    
  } catch (error) {
    console.error(`❌ Error cargando registro de DEX: ${error}`);
    throw new Error(`No se pudo cargar el registro de DEX: ${error}`);
  }
}

/**
 * Lista DEX para una blockchain específica con opciones de filtrado
 */
export function listDexes(
  chain: string, 
  options: { 
    onlyEnabled?: boolean; 
    includeMetrics?: boolean 
  } = {}
): Array<{
  id: string;
  name: string;
  enabled: boolean;
  pairCount?: number;
  lastValidated?: number;
  tvl?: number;
  source?: string;
}> {
  try {
    const registry = loadDexRegistry();
    
    if (!registry.chains[chain]) {
      console.warn(`⚠️  Blockchain ${chain} no encontrada en el registro`);
      return [];
    }

    const dexes = registry.chains[chain];
    const results = [];

    for (const [dexId, dex] of Object.entries(dexes)) {
      // Aplicar filtro de habilitados si se solicita
      if (options.onlyEnabled && !dex.enabled) {
        continue;
      }

      const result: any = {
        id: dexId,
        name: dex.name,
        enabled: dex.enabled,
        source: dex.source
      };

      // Incluir métricas si se solicita
      if (options.includeMetrics) {
        if (dex.pair_count !== undefined) result.pairCount = dex.pair_count;
        if (dex.tvl !== undefined) result.tvl = dex.tvl;
        if (dex.last_validated !== undefined) result.lastValidated = dex.last_validated;
      }

      results.push(result);
    }

    // Ordenar por nombre
    results.sort((a, b) => a.name.localeCompare(b.name));
    
    return results;
    
  } catch (error) {
    console.error(`❌ Error listando DEX para ${chain}: ${error}`);
    return [];
  }
}

/**
 * Habilita o deshabilita un DEX específico en una blockchain
 */
export function setDexEnabled(
  chain: string, 
  dexId: string, 
  enabled: boolean, 
  note?: string
): { ok: boolean; error?: string } {
  try {
    const registry = loadDexRegistry();
    
    if (!registry.chains[chain]) {
      return { ok: false, error: `Blockchain ${chain} no encontrada` };
    }

    if (!registry.chains[chain][dexId]) {
      return { ok: false, error: `DEX ${dexId} no encontrado en ${chain}` };
    }

    // Actualizar estado
    registry.chains[chain][dexId].enabled = enabled;
    
    if (note) {
      registry.chains[chain][dexId].validation_note = note;
    }
    
    registry.chains[chain][dexId].last_validated = Date.now();

    // Guardar cambios
    fs.writeFileSync(REG_PATH, JSON.stringify(registry, null, 2), 'utf8');
    
    console.log(`✅ DEX ${dexId} en ${chain} ${enabled ? 'habilitado' : 'deshabilitado'}`);
    
    return { ok: true };
    
  } catch (error) {
    const errorMsg = `Error actualizando DEX ${dexId} en ${chain}: ${error}`;
    console.error(`❌ ${errorMsg}`);
    return { ok: false, error: errorMsg };
  }
}

/**
 * Obtiene estadísticas generales del registro de DEX
 */
export function getDexStats(chain?: string): {
  totalDexes: number;
  enabledDexes: number;
  disabledDexes: number;
  chains: number;
  lastUpdated: number;
  chainBreakdown?: Array<{
    chain: string;
    total: number;
    enabled: number;
    disabled: number;
  }>;
} {
  try {
    const registry = loadDexRegistry();
    
    let totalDexes = 0;
    let enabledDexes = 0;
    let disabledDexes = 0;
    const chainBreakdown: Array<{
      chain: string;
      total: number;
      enabled: number;
      disabled: number;
    }> = [];

    // Calcular estadísticas por blockchain
    for (const [chainName, dexes] of Object.entries(registry.chains)) {
      if (chain && chain !== chainName) {
        continue;
      }

      const chainTotal = Object.keys(dexes).length;
      const chainEnabled = Object.values(dexes).filter(d => d.enabled).length;
      const chainDisabled = chainTotal - chainEnabled;

      totalDexes += chainTotal;
      enabledDexes += chainEnabled;
      disabledDexes += chainDisabled;

      chainBreakdown.push({
        chain: chainName,
        total: chainTotal,
        enabled: chainEnabled,
        disabled: chainDisabled
      });
    }

    return {
      totalDexes,
      enabledDexes,
      disabledDexes,
      chains: chainBreakdown.length,
      lastUpdated: registry.metadata.last_updated,
      chainBreakdown: chain ? undefined : chainBreakdown
    };
    
  } catch (error) {
    console.error(`❌ Error obteniendo estadísticas de DEX: ${error}`);
    return {
      totalDexes: 0,
      enabledDexes: 0,
      disabledDexes: 0,
      chains: 0,
      lastUpdated: 0
    };
  }
}

/**
 * Busca DEX por nombre o ID
 */
export function searchDexes(
  query: string, 
  chain?: string
): Array<{
  chain: string;
  dexId: string;
  name: string;
  enabled: boolean;
  source: string;
}> {
  try {
    const registry = loadDexRegistry();
    const results = [];
    const queryLower = query.toLowerCase();

    for (const [chainName, dexes] of Object.entries(registry.chains)) {
      if (chain && chain !== chainName) {
        continue;
      }

      for (const [dexId, dex] of Object.entries(dexes)) {
        if (
          dexId.toLowerCase().includes(queryLower) ||
          dex.name.toLowerCase().includes(queryLower)
        ) {
          results.push({
            chain: chainName,
            dexId,
            name: dex.name,
            enabled: dex.enabled,
            source: dex.source
          });
        }
      }
    }

    // Ordenar por relevancia (nombre exacto primero)
    results.sort((a, b) => {
      const aExact = a.name.toLowerCase() === queryLower || a.dexId.toLowerCase() === queryLower;
      const bExact = b.name.toLowerCase() === queryLower || b.dexId.toLowerCase() === queryLower;
      
      if (aExact && !bExact) return -1;
      if (!aExact && bExact) return 1;
      
      return a.name.localeCompare(b.name);
    });

    return results;
    
  } catch (error) {
    console.error(`❌ Error buscando DEX: ${error}`);
    return [];
  }
}

/**
 * Obtiene información detallada de un DEX específico
 */
export function getDexDetails(chain: string, dexId: string): DexEntry | null {
  try {
    const registry = loadDexRegistry();
    
    if (!registry.chains[chain] || !registry.chains[chain][dexId]) {
      return null;
    }

    return registry.chains[chain][dexId];
    
  } catch (error) {
    console.error(`❌ Error obteniendo detalles de DEX ${dexId} en ${chain}: ${error}`);
    return null;
  }
}

/**
 * Valida la integridad del registro de DEX
 */
export function validateRegistry(): {
  ok: boolean;
  errors: string[];
  warnings: string[];
} {
  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    const registry = loadDexRegistry();
    
    // Validar estructura básica
    if (!registry.metadata || !registry.chains) {
      errors.push("Estructura del registro inválida");
      return { ok: false, errors, warnings };
    }

    // Validar metadatos
    if (!registry.metadata.version || !registry.metadata.last_updated) {
      warnings.push("Metadatos incompletos en el registro");
    }

    // Validar cada blockchain
    for (const [chainName, dexes] of Object.entries(registry.chains)) {
      if (Object.keys(dexes).length === 0) {
        warnings.push(`Blockchain ${chainName} no tiene DEX registrados`);
        continue;
      }

      for (const [dexId, dex] of Object.entries(dexes)) {
        // Validar campos requeridos
        if (!dex.name || !dex.source) {
          errors.push(`DEX ${dexId} en ${chainName} tiene campos requeridos faltantes`);
        }

        // Validar timestamp de validación
        if (dex.last_validated && dex.last_validated > Date.now()) {
          warnings.push(`DEX ${dexId} en ${chainName} tiene timestamp de validación futuro`);
        }

        // Validar que DEX habilitados tengan validación reciente
        if (dex.enabled && dex.last_validated) {
          const daysSinceValidation = (Date.now() - dex.last_validated) / (1000 * 60 * 60 * 24);
          if (daysSinceValidation > 30) {
            warnings.push(`DEX ${dexId} en ${chainName} no ha sido validado en ${Math.floor(daysSinceValidation)} días`);
          }
        }
      }
    }

    return {
      ok: errors.length === 0,
      errors,
      warnings
    };
    
  } catch (error) {
    errors.push(`Error validando registro: ${error}`);
    return { ok: false, errors, warnings };
  }
}
