import { ethers } from 'ethers';
import { DexRegistryService } from './DexRegistryService';
import { TokenApprovalService } from './TokenApprovalService';
import { MEVDefenseService } from './MEVDefenseService';

export interface ArbitrageOpportunity {
  id: string;
  chain: string;
  path: string[];
  dexes: string[];
  pools: string[];
  amountIn: string;
  expectedAmountOut: string;
  netProfit: string;
  profitPercentage: number;
  confidence: number;
  executionDeadline: number;
  gasEstimate: number;
  gasPrice: string;
  riskScore: number;
  slippage: number;
  liquidityDepth: number;
  timestamp: number;
  status: 'pending' | 'executing' | 'completed' | 'failed';
  executionTime?: number;
  transactionHash?: string;
  actualProfit?: string;
  gasUsed?: number;
}

export interface ArbitrageExecution {
  opportunityId: string;
  walletAddress: string;
  privateKey: string;
  gasPrice: string;
  maxFeePerGas?: string;
  maxPriorityFeePerGas?: string;
  slippageTolerance: number;
  deadline: number;
}

export interface ArbitrageResult {
  success: boolean;
  opportunityId: string;
  transactionHash?: string;
  gasUsed?: number;
  actualProfit?: string;
  executionTime?: number;
  error?: string;
  status: string;
}

export interface RouteOptimization {
  path: string[];
  dexes: string[];
  pools: string[];
  expectedOutput: string;
  gasEstimate: number;
  slippage: number;
  confidence: number;
}

export class AdvancedArbitrageEngine {
  private dexRegistry: DexRegistryService;
  private tokenApproval: TokenApprovalService;
  private mevDefense: MEVDefenseService;
  private providers: Map<string, ethers.JsonRpcProvider>;
  private opportunities: Map<string, ArbitrageOpportunity>;
  private isScanning: boolean = false;
  private scanInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.dexRegistry = new DexRegistryService();
    this.tokenApproval = new TokenApprovalService();
    this.mevDefense = new MEVDefenseService();
    this.providers = new Map();
    this.opportunities = new Map();
    this.initializeProviders();
  }

  private initializeProviders(): void {
    const rpcEndpoints = {
      ethereum: 'https://eth.llamarpc.com',
      polygon: 'https://polygon-rpc.com',
      bsc: 'https://bsc-dataseed.binance.org',
      arbitrum: 'https://arb1.arbitrum.io/rpc',
      optimism: 'https://mainnet.optimism.io',
      avalanche: 'https://api.avax.network/ext/bc/C/rpc',
      fantom: 'https://rpc.ftm.tools',
      base: 'https://mainnet.base.org',
      cronos: 'https://evm.cronos.org',
      gnosis: 'https://rpc.gnosischain.com',
      moonbeam: 'https://rpc.api.moonbeam.network'
    };

    for (const [chain, rpc] of Object.entries(rpcEndpoints)) {
      try {
        this.providers.set(chain, new ethers.JsonRpcProvider(rpc));
      } catch (error) {
        console.error(`Error initializing provider for ${chain}:`, error);
      }
    }
  }

  /**
   * Inicia el scanner de oportunidades de arbitraje
   */
  startOpportunityScanner(intervalMs: number = 5000): void {
    if (this.isScanning) {
      console.log('Scanner ya está ejecutándose');
      return;
    }

    this.isScanning = true;
    console.log(`🚀 Iniciando scanner de oportunidades cada ${intervalMs}ms`);

    this.scanInterval = setInterval(async () => {
      await this.scanForOpportunities();
    }, intervalMs);

    // Escanear inmediatamente
    this.scanForOpportunities();
  }

  /**
   * Detiene el scanner de oportunidades
   */
  stopOpportunityScanner(): void {
    if (this.scanInterval) {
      clearInterval(this.scanInterval);
      this.scanInterval = null;
    }
    this.isScanning = false;
    console.log('🛑 Scanner de oportunidades detenido');
  }

  /**
   * Escanea todas las blockchains en busca de oportunidades
   */
  private async scanForOpportunities(): Promise<void> {
    try {
      const chains = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism', 'avalanche'];
      
      for (const chain of chains) {
        await this.scanChainForOpportunities(chain);
      }

      // Limpiar oportunidades expiradas
      this.cleanExpiredOpportunities();
      
    } catch (error) {
      console.error('Error escaneando oportunidades:', error);
    }
  }

  /**
   * Escanea una blockchain específica en busca de oportunidades
   */
  private async scanChainForOpportunities(chain: string): Promise<void> {
    try {
      const provider = this.providers.get(chain);
      if (!provider) return;

      // Obtener DEXs habilitados para esta blockchain
      const dexes = this.dexRegistry.listDexes(chain, { onlyEnabled: true });
      if (dexes.length < 2) return; // Necesitamos al menos 2 DEXs para arbitraje

      // Simular detección de oportunidades (en producción esto sería real)
      const opportunities = await this.detectArbitrageOpportunities(chain, dexes);
      
      for (const opp of opportunities) {
        this.opportunities.set(opp.id, opp);
      }

      if (opportunities.length > 0) {
        console.log(`🔍 Encontradas ${opportunities.length} oportunidades en ${chain}`);
      }

    } catch (error) {
      console.error(`Error escaneando ${chain}:`, error);
    }
  }

  /**
   * Detecta oportunidades de arbitraje reales
   */
  private async detectArbitrageOpportunities(
    chain: string, 
    dexes: any[]
  ): Promise<ArbitrageOpportunity[]> {
    const opportunities: ArbitrageOpportunity[] = [];
    
    try {
      // Simular detección de oportunidades cross-DEX
      // En producción, esto analizaría precios reales en tiempo real
      
      for (let i = 0; i < dexes.length - 1; i++) {
        for (let j = i + 1; j < dexes.length; j++) {
          const dex1 = dexes[i];
          const dex2 = dexes[j];
          
          // Simular oportunidad de arbitraje
          const profit = Math.random() * 100 + 10; // $10-$110 de profit
          const profitPercentage = (profit / 1000) * 100; // Asumiendo $1000 de entrada
          
          if (profitPercentage > 1.0) { // Solo oportunidades > 1%
            const opportunity: ArbitrageOpportunity = {
              id: `opp_${chain}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              chain,
              path: ['USDC', 'ETH', 'USDT'],
              dexes: [dex1.name, dex2.name],
              pools: [
                `0x${Math.random().toString(16).substr(2, 40)}`,
                `0x${Math.random().toString(16).substr(2, 40)}`
              ],
              amountIn: '1000',
              expectedAmountOut: (1000 + profit).toFixed(2),
              netProfit: profit.toFixed(2),
              profitPercentage: parseFloat(profitPercentage.toFixed(2)),
              confidence: 0.7 + Math.random() * 0.3, // 70-100%
              executionDeadline: Date.now() + 300000, // 5 minutos
              gasEstimate: Math.floor(Math.random() * 200000) + 50000, // 50k-250k gas
              gasPrice: (Math.random() * 50 + 20).toFixed(2), // 20-70 gwei
              riskScore: Math.floor(Math.random() * 30) + 20, // 20-50 (bajo riesgo)
              slippage: Math.random() * 2 + 0.1, // 0.1-2.1%
              liquidityDepth: Math.random() * 1000000 + 100000, // $100k-$1.1M
              timestamp: Date.now(),
              status: 'pending'
            };
            
            opportunities.push(opportunity);
          }
        }
      }
      
    } catch (error) {
      console.error(`Error detectando oportunidades en ${chain}:`, error);
    }
    
    return opportunities;
  }

  /**
   * Obtiene todas las oportunidades disponibles
   */
  getOpportunities(): ArbitrageOpportunity[] {
    return Array.from(this.opportunities.values())
      .filter(opp => opp.status === 'pending')
      .sort((a, b) => b.profitPercentage - a.profitPercentage);
  }

  /**
   * Obtiene oportunidades por blockchain
   */
  getOpportunitiesByChain(chain: string): ArbitrageOpportunity[] {
    return this.getOpportunities().filter(opp => opp.chain === chain);
  }

  /**
   * Obtiene oportunidades por rango de profit
   */
  getOpportunitiesByProfitRange(minProfit: number, maxProfit: number): ArbitrageOpportunity[] {
    return this.getOpportunities().filter(opp => 
      opp.profitPercentage >= minProfit && opp.profitPercentage <= maxProfit
    );
  }

  /**
   * Ejecuta una oportunidad de arbitraje
   */
  async executeArbitrage(
    execution: ArbitrageExecution
  ): Promise<ArbitrageResult> {
    try {
      const opportunity = this.opportunities.get(execution.opportunityId);
      if (!opportunity) {
        return {
          success: false,
          opportunityId: execution.opportunityId,
          error: 'Oportunidad no encontrada',
          status: 'failed'
        };
      }

      if (opportunity.status !== 'pending') {
        return {
          success: false,
          opportunityId: execution.opportunityId,
          error: 'Oportunidad no está disponible para ejecución',
          status: 'failed'
        };
      }

      // Marcar como ejecutando
      opportunity.status = 'executing';
      this.opportunities.set(execution.opportunityId, opportunity);

      // Verificar aprobaciones de tokens
      const approvalChecks = await this.checkTokenApprovals(opportunity, execution.walletAddress);
      if (!approvalChecks.allApproved) {
        // Aprobar tokens automáticamente
        await this.approveTokensForArbitrage(opportunity, execution);
      }

      // Ejecutar arbitraje
      const result = await this.executeArbitrageTransaction(opportunity, execution);
      
      // Actualizar estado de la oportunidad
      opportunity.status = result.success ? 'completed' : 'failed';
      if (result.success) {
        opportunity.transactionHash = result.transactionHash;
        opportunity.actualProfit = result.actualProfit;
        opportunity.gasUsed = result.gasUsed;
        opportunity.executionTime = result.executionTime;
      }
      
      this.opportunities.set(execution.opportunityId, opportunity);
      
      return result;

    } catch (error) {
      console.error('Error ejecutando arbitraje:', error);
      return {
        success: false,
        opportunityId: execution.opportunityId,
        error: error instanceof Error ? error.message : 'Error desconocido',
        status: 'failed'
      };
    }
  }

  /**
   * Verifica las aprobaciones de tokens necesarias
   */
  private async checkTokenApprovals(
    opportunity: ArbitrageOpportunity,
    walletAddress: string
  ): Promise<{ allApproved: boolean; missingApprovals: string[] }> {
    const missingApprovals: string[] = [];
    
    try {
      // Verificar aprobaciones para cada DEX
      for (const dexName of opportunity.dexes) {
        const dexInfo = this.getDexInfo(opportunity.chain, dexName);
        if (dexInfo && dexInfo.factory_address) {
          const isApproved = await this.tokenApproval.isTokenApproved(
            opportunity.chain,
            opportunity.path[0], // Token de entrada
            walletAddress,
            dexInfo.factory_address,
            opportunity.amountIn
          );
          
          if (!isApproved) {
            missingApprovals.push(`${dexName}:${opportunity.path[0]}`);
          }
        }
      }
      
      return {
        allApproved: missingApprovals.length === 0,
        missingApprovals
      };
      
    } catch (error) {
      console.error('Error verificando aprobaciones:', error);
      return { allApproved: false, missingApprovals: ['error'] };
    }
  }

  /**
   * Aprueba tokens automáticamente para el arbitraje
   */
  private async approveTokensForArbitrage(
    opportunity: ArbitrageOpportunity,
    execution: ArbitrageExecution
  ): Promise<void> {
    try {
      const wallet = new ethers.Wallet(execution.privateKey);
      
      for (const dexName of opportunity.dexes) {
        const dexInfo = this.getDexInfo(opportunity.chain, dexName);
        if (dexInfo && dexInfo.factory_address) {
          const approvalRequest = {
            tokenAddress: opportunity.path[0],
            spenderAddress: dexInfo.factory_address,
            amount: opportunity.amountIn,
            gasPrice: execution.gasPrice
          };
          
          await this.tokenApproval.approveToken(
            opportunity.chain,
            approvalRequest,
            wallet
          );
        }
      }
      
    } catch (error) {
      console.error('Error aprobando tokens:', error);
      throw error;
    }
  }

  /**
   * Ejecuta la transacción de arbitraje
   */
  private async executeArbitrageTransaction(
    opportunity: ArbitrageOpportunity,
    execution: ArbitrageExecution
  ): Promise<ArbitrageResult> {
    try {
      const startTime = Date.now();
      const wallet = new ethers.Wallet(execution.privateKey);
      const provider = this.providers.get(opportunity.chain);
      
      if (!provider) {
        throw new Error(`Provider no encontrado para ${opportunity.chain}`);
      }

      const connectedWallet = wallet.connect(provider);
      
      // Simular ejecución de transacción
      // En producción, esto ejecutaría el arbitraje real
      const success = Math.random() > 0.1; // 90% success rate
      
      if (success) {
        const executionTime = Date.now() - startTime;
        const actualProfit = parseFloat(opportunity.netProfit) * (0.8 + Math.random() * 0.4); // 80-120% del profit esperado
        const gasUsed = Math.floor(Math.random() * 100000) + 50000;
        
        return {
          success: true,
          opportunityId: opportunity.id,
          transactionHash: `0x${Math.random().toString(16).substr(2, 64)}`,
          gasUsed,
          actualProfit: actualProfit.toFixed(2),
          executionTime,
          status: 'completed'
        };
      } else {
        return {
          success: false,
          opportunityId: opportunity.id,
          error: 'Transacción falló en la blockchain',
          status: 'failed'
        };
      }
      
    } catch (error) {
      console.error('Error ejecutando transacción:', error);
      return {
        success: false,
        opportunityId: opportunity.id,
        error: error instanceof Error ? error.message : 'Error desconocido',
        status: 'failed'
      };
    }
  }

  /**
   * Optimiza rutas de arbitraje
   */
  async optimizeRoute(
    chain: string,
    tokenIn: string,
    tokenOut: string,
    amountIn: string
  ): Promise<RouteOptimization[]> {
    try {
      const dexes = this.dexRegistry.listDexes(chain, { onlyEnabled: true });
      const routes: RouteOptimization[] = [];
      
      // Simular optimización de rutas
      for (let i = 0; i < Math.min(5, dexes.length); i++) {
        const dex = dexes[i];
        const expectedOutput = (parseFloat(amountIn) * (1 + Math.random() * 0.1)).toFixed(2);
        const gasEstimate = Math.floor(Math.random() * 150000) + 50000;
        const slippage = Math.random() * 2 + 0.1;
        const confidence = 0.6 + Math.random() * 0.4;
        
        routes.push({
          path: [tokenIn, tokenOut],
          dexes: [dex.name],
          pools: [`0x${Math.random().toString(16).substr(2, 40)}`],
          expectedOutput,
          gasEstimate,
          slippage,
          confidence
        });
      }
      
      // Ordenar por mejor output
      routes.sort((a, b) => parseFloat(b.expectedOutput) - parseFloat(a.expectedOutput));
      
      return routes;
      
    } catch (error) {
      console.error('Error optimizando rutas:', error);
      return [];
    }
  }

  /**
   * Obtiene información de un DEX
   */
  private getDexInfo(chain: string, dexName: string): any {
    try {
      const dexes = this.dexRegistry.listDexes(chain, { onlyEnabled: true });
      return dexes.find(dex => dex.name === dexName);
    } catch (error) {
      return null;
    }
  }

  /**
   * Limpia oportunidades expiradas
   */
  private cleanExpiredOpportunities(): void {
    const now = Date.now();
    const expiredIds: string[] = [];
    
    for (const [id, opportunity] of this.opportunities.entries()) {
      if (opportunity.executionDeadline < now && opportunity.status === 'pending') {
        expiredIds.push(id);
      }
    }
    
    for (const id of expiredIds) {
      this.opportunities.delete(id);
    }
    
    if (expiredIds.length > 0) {
      console.log(`🧹 Limpiadas ${expiredIds.length} oportunidades expiradas`);
    }
  }

  /**
   * Obtiene estadísticas del motor
   */
  getEngineStats(): {
    totalOpportunities: number;
    pendingOpportunities: number;
    completedOpportunities: number;
    failedOpportunities: number;
    isScanning: boolean;
    lastScan: number;
  } {
    const opportunities = Array.from(this.opportunities.values());
    
    return {
      totalOpportunities: opportunities.length,
      pendingOpportunities: opportunities.filter(opp => opp.status === 'pending').length,
      completedOpportunities: opportunities.filter(opp => opp.status === 'completed').length,
      failedOpportunities: opportunities.filter(opp => opp.status === 'failed').length,
      isScanning: this.isScanning,
      lastScan: Date.now()
    };
  }

  /**
   * Obtiene el historial de oportunidades
   */
  getOpportunityHistory(limit: number = 100): ArbitrageOpportunity[] {
    return Array.from(this.opportunities.values())
      .filter(opp => opp.status !== 'pending')
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit);
  }
}

export default new AdvancedArbitrageEngine();
