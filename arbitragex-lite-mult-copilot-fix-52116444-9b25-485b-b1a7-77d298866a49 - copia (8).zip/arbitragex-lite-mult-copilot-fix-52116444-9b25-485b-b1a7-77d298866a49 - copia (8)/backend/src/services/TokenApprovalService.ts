import { ethers } from 'ethers';
import { DexRegistryService } from './DexRegistryService';

export interface TokenApproval {
  tokenAddress: string;
  spenderAddress: string;
  amount: string;
  allowance: string;
  isApproved: boolean;
  lastUpdated: number;
  transactionHash?: string;
}

export interface ApprovalRequest {
  tokenAddress: string;
  spenderAddress: string;
  amount: string;
  gasPrice?: string;
  maxFeePerGas?: string;
  maxPriorityFeePerGas?: string;
}

export interface ApprovalResult {
  success: boolean;
  transactionHash?: string;
  gasUsed?: number;
  error?: string;
  allowance?: string;
}

export class TokenApprovalService {
  private dexRegistry: DexRegistryService;
  private providers: Map<string, ethers.JsonRpcProvider>;
  private tokenContracts: Map<string, ethers.Contract>;

  constructor() {
    this.dexRegistry = new DexRegistryService();
    this.providers = new Map();
    this.tokenContracts = new Map();
    this.initializeProviders();
  }

  private initializeProviders(): void {
    const rpcEndpoints = {
      ethereum: 'https://eth.llamarpc.com',
      polygon: 'https://polygon-rpc.com',
      bsc: 'https://bsc-dataseed.binance.org',
      arbitrum: 'https://arb1.arbitrum.io/rpc',
      optimism: 'https://mainnet.optimism.io',
      avalanche: 'https://api.avax.network/ext/bc/C/rpc',
      fantom: 'https://rpc.ftm.tools',
      base: 'https://mainnet.base.org',
      cronos: 'https://evm.cronos.org',
      gnosis: 'https://rpc.gnosischain.com',
      moonbeam: 'https://rpc.api.moonbeam.network'
    };

    for (const [chain, rpc] of Object.entries(rpcEndpoints)) {
      try {
        this.providers.set(chain, new ethers.JsonRpcProvider(rpc));
      } catch (error) {
        console.error(`Error initializing provider for ${chain}:`, error);
      }
    }
  }

  /**
   * Verifica el allowance actual de un token
   */
  async checkAllowance(
    chain: string,
    tokenAddress: string,
    ownerAddress: string,
    spenderAddress: string
  ): Promise<string> {
    try {
      const provider = this.providers.get(chain);
      if (!provider) {
        throw new Error(`Provider not found for chain: ${chain}`);
      }

      const tokenContract = this.getTokenContract(chain, tokenAddress);
      const allowance = await tokenContract.allowance(ownerAddress, spenderAddress);
      
      return allowance.toString();
    } catch (error) {
      console.error(`Error checking allowance:`, error);
      throw error;
    }
  }

  /**
   * Verifica si un token está aprobado para un spender
   */
  async isTokenApproved(
    chain: string,
    tokenAddress: string,
    ownerAddress: string,
    spenderAddress: string,
    requiredAmount: string
  ): Promise<boolean> {
    try {
      const allowance = await this.checkAllowance(chain, tokenAddress, ownerAddress, spenderAddress);
      const required = ethers.parseUnits(requiredAmount, 18);
      return ethers.parseUnits(allowance, 18).gte(required);
    } catch (error) {
      console.error(`Error checking if token is approved:`, error);
      return false;
    }
  }

  /**
   * Aprueba un token para un spender
   */
  async approveToken(
    chain: string,
    approvalRequest: ApprovalRequest,
    wallet: ethers.Wallet
  ): Promise<ApprovalResult> {
    try {
      const provider = this.providers.get(chain);
      if (!provider) {
        throw new Error(`Provider not found for chain: ${chain}`);
      }

      const connectedWallet = wallet.connect(provider);
      const tokenContract = this.getTokenContract(chain, approvalRequest.tokenAddress);
      const connectedTokenContract = tokenContract.connect(connectedWallet);

      // Configurar gas
      const gasOptions: any = {};
      if (approvalRequest.gasPrice) {
        gasOptions.gasPrice = ethers.parseUnits(approvalRequest.gasPrice, 'gwei');
      } else if (approvalRequest.maxFeePerGas && approvalRequest.maxPriorityFeePerGas) {
        gasOptions.maxFeePerGas = ethers.parseUnits(approvalRequest.maxFeePerGas, 'gwei');
        gasOptions.maxPriorityFeePerGas = ethers.parseUnits(approvalRequest.maxPriorityFeePerGas, 'gwei');
      }

      // Aprobar con amount infinito para evitar múltiples aprobaciones
      const maxApproval = ethers.MaxUint256;
      
      const tx = await connectedTokenContract.approve(
        approvalRequest.spenderAddress,
        maxApproval,
        gasOptions
      );

      const receipt = await tx.wait();
      
      return {
        success: true,
        transactionHash: tx.hash,
        gasUsed: Number(receipt.gasUsed),
        allowance: maxApproval.toString()
      };

    } catch (error) {
      console.error(`Error approving token:`, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Revoca la aprobación de un token
   */
  async revokeApproval(
    chain: string,
    tokenAddress: string,
    spenderAddress: string,
    wallet: ethers.Wallet
  ): Promise<ApprovalResult> {
    try {
      const provider = this.providers.get(chain);
      if (!provider) {
        throw new Error(`Provider not found for chain: ${chain}`);
      }

      const connectedWallet = wallet.connect(provider);
      const tokenContract = this.getTokenContract(chain, tokenAddress);
      const connectedTokenContract = tokenContract.connect(connectedWallet);

      const tx = await connectedTokenContract.approve(spenderAddress, 0);
      const receipt = await tx.wait();

      return {
        success: true,
        transactionHash: tx.hash,
        gasUsed: Number(receipt.gasUsed),
        allowance: '0'
      };

    } catch (error) {
      console.error(`Error revoking approval:`, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Aproba múltiples tokens en batch
   */
  async batchApproveTokens(
    chain: string,
    approvals: ApprovalRequest[],
    wallet: ethers.Wallet
  ): Promise<ApprovalResult[]> {
    const results: ApprovalResult[] = [];

    for (const approval of approvals) {
      try {
        const result = await this.approveToken(chain, approval, wallet);
        results.push(result);
        
        // Esperar un poco entre transacciones para evitar nonce issues
        await new Promise(resolve => setTimeout(resolve, 1000));
        
      } catch (error) {
        results.push({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    return results;
  }

  /**
   * Verifica allowances para múltiples tokens
   */
  async batchCheckAllowances(
    chain: string,
    checks: Array<{
      tokenAddress: string;
      ownerAddress: string;
      spenderAddress: string;
    }>
  ): Promise<Array<{
    tokenAddress: string;
    spenderAddress: string;
    allowance: string;
    isApproved: boolean;
  }>> {
    const results = [];

    for (const check of checks) {
      try {
        const allowance = await this.checkAllowance(
          chain,
          check.tokenAddress,
          check.ownerAddress,
          check.spenderAddress
        );

        results.push({
          tokenAddress: check.tokenAddress,
          spenderAddress: check.spenderAddress,
          allowance,
          isApproved: ethers.parseUnits(allowance, 18).gt(0)
        });

      } catch (error) {
        results.push({
          tokenAddress: check.tokenAddress,
          spenderAddress: check.spenderAddress,
          allowance: '0',
          isApproved: false
        });
      }
    }

    return results;
  }

  /**
   * Obtiene el contrato de token para una blockchain específica
   */
  private getTokenContract(chain: string, tokenAddress: string): ethers.Contract {
    const key = `${chain}:${tokenAddress}`;
    
    if (this.tokenContracts.has(key)) {
      return this.tokenContracts.get(key)!;
    }

    const provider = this.providers.get(chain);
    if (!provider) {
      throw new Error(`Provider not found for chain: ${chain}`);
    }

    // ABI mínimo para ERC20
    const abi = [
      'function allowance(address owner, address spender) view returns (uint256)',
      'function approve(address spender, uint256 amount) returns (bool)',
      'function balanceOf(address account) view returns (uint256)',
      'function decimals() view returns (uint8)',
      'function symbol() view returns (string)',
      'function name() view returns (string)'
    ];

    const contract = new ethers.Contract(tokenAddress, abi, provider);
    this.tokenContracts.set(key, contract);
    
    return contract;
  }

  /**
   * Obtiene información del token
   */
  async getTokenInfo(
    chain: string,
    tokenAddress: string
  ): Promise<{
    name: string;
    symbol: string;
    decimals: number;
    totalSupply: string;
  } | null> {
    try {
      const tokenContract = this.getTokenContract(chain, tokenAddress);
      
      const [name, symbol, decimals, totalSupply] = await Promise.all([
        tokenContract.name(),
        tokenContract.symbol(),
        tokenContract.decimals(),
        tokenContract.totalSupply()
      ]);

      return {
        name,
        symbol,
        decimals: Number(decimals),
        totalSupply: totalSupply.toString()
      };

    } catch (error) {
      console.error(`Error getting token info:`, error);
      return null;
    }
  }

  /**
   * Obtiene el balance de un token para una dirección
   */
  async getTokenBalance(
    chain: string,
    tokenAddress: string,
    ownerAddress: string
  ): Promise<string> {
    try {
      const tokenContract = this.getTokenContract(chain, tokenAddress);
      const balance = await tokenContract.balanceOf(ownerAddress);
      return balance.toString();
    } catch (error) {
      console.error(`Error getting token balance:`, error);
      return '0';
    }
  }

  /**
   * Verifica si una dirección es un contrato
   */
  async isContract(chain: string, address: string): Promise<boolean> {
    try {
      const provider = this.providers.get(chain);
      if (!provider) {
        return false;
      }

      const code = await provider.getCode(address);
      return code !== '0x';
    } catch (error) {
      return false;
    }
  }
}

export default new TokenApprovalService();
