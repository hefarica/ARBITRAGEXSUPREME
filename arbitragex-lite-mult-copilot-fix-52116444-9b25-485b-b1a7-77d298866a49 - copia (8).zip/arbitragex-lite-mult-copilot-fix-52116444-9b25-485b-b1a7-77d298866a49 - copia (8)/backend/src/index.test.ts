import { describe, it, expect } from 'vitest';
import { STRATEGIES_41, EXISTING_STRATEGIES } from './config/strategies';

describe('Backend Configuration', () => {
  it('should have exactly 41 strategies', () => {
    expect(STRATEGIES_41).toHaveLength(41);
  });

  it('should have 11 existing strategies', () => {
    expect(EXISTING_STRATEGIES).toHaveLength(11);
  });

  it('should have all strategies with valid properties', () => {
    STRATEGIES_41.forEach(strategy => {
      expect(strategy).toHaveProperty('id');
      expect(strategy).toHaveProperty('name');
      expect(strategy).toHaveProperty('description');
      expect(strategy).toHaveProperty('category');
      expect(strategy).toHaveProperty('risk_level');
      expect(strategy).toHaveProperty('min_capital');
      expect(strategy).toHaveProperty('max_capital');
      expect(strategy).toHaveProperty('expected_roi');
      expect(strategy).toHaveProperty('success_rate');
      expect(strategy).toHaveProperty('blockchains');
      expect(strategy).toHaveProperty('execution_mode');
      expect(strategy).toHaveProperty('cooldown');
      expect(strategy).toHaveProperty('enabled');
    });
  });

  it('should have unique strategy IDs', () => {
    const ids = STRATEGIES_41.map(s => s.id);
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size).toBe(ids.length);
  });

  it('should have all strategies enabled by default', () => {
    const enabledStrategies = STRATEGIES_41.filter(s => s.enabled);
    expect(enabledStrategies).toHaveLength(41);
  });
});
