import { Router } from 'express';
import configController from '../controllers/ConfigController';

const router = Router();

// Rutas de configuración de blockchain
router.get('/blockchain', configController.getBlockchainConfig);
router.put('/blockchain/:id', configController.updateBlockchainConfig);

// Rutas de configuración de DEX
router.get('/dex', configController.getDEXConfig);
router.put('/dex/:id', configController.updateDEXConfig);

// Rutas de configuración de estrategias
router.get('/strategy', configController.getStrategyConfig);
router.put('/strategy/:id', configController.updateStrategyConfig);

export default router;
