import { Router } from 'express';
import poolsController from '../controllers/PoolsController';

const router = Router();

// GET /api/pools/states - Get all pool states
router.get('/states', poolsController.getPoolStates);

// GET /api/pools/states/:address - Get specific pool state
router.get('/states/:address', poolsController.getPoolState);

// GET /api/pools/analytics - Get pool analytics
router.get('/analytics', poolsController.getPoolAnalytics);

// POST /api/pools/validate - Validate pool
router.post('/validate', poolsController.validatePool);

export default router;
