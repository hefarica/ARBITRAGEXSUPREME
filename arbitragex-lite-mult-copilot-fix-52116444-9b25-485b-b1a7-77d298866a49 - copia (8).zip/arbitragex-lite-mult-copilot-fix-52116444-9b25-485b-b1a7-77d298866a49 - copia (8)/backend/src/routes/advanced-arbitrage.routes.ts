import { Router } from 'express';
import AdvancedArbitrageController from '../controllers/AdvancedArbitrageController';

const router = Router();
const controller = new AdvancedArbitrageController();

// ===== OPORTUNIDADES DE ARBITRAJE =====

/**
 * GET /api/arbitrage/opportunities
 * Obtiene todas las oportunidades de arbitraje disponibles
 */
router.get('/opportunities', controller.getOpportunities.bind(controller));

/**
 * GET /api/arbitrage/opportunities/:chain
 * Obtiene oportunidades de arbitraje por blockchain
 */
router.get('/opportunities/:chain', controller.getOpportunitiesByChain.bind(controller));

/**
 * POST /api/arbitrage/execute
 * Ejecuta una oportunidad de arbitraje
 */
router.post('/execute', controller.executeOpportunity.bind(controller));

// ===== SCANNER DE OPORTUNIDADES =====

/**
 * POST /api/arbitrage/scanner/start
 * Inicia el scanner de oportunidades
 */
router.post('/scanner/start', controller.startScanner.bind(controller));

/**
 * POST /api/arbitrage/scanner/stop
 * Detiene el scanner de oportunidades
 */
router.post('/scanner/stop', controller.stopScanner.bind(controller));

/**
 * GET /api/arbitrage/scanner/status
 * Obtiene el estado del scanner
 */
router.get('/scanner/status', controller.getScannerStatus.bind(controller));

// ===== OPTIMIZACIÓN DE RUTAS =====

/**
 * POST /api/arbitrage/optimize-route
 * Optimiza rutas de arbitraje
 */
router.post('/optimize-route', controller.optimizeRoute.bind(controller));

// ===== FLASH LOANS =====

/**
 * GET /api/arbitrage/flash-loans/pools
 * Obtiene pools de flash loans disponibles
 */
router.get('/flash-loans/pools', controller.getFlashLoanPools.bind(controller));

/**
 * POST /api/arbitrage/flash-loans/check-availability
 * Verifica disponibilidad de flash loans
 */
router.post('/flash-loans/check-availability', controller.checkFlashLoanAvailability.bind(controller));

/**
 * POST /api/arbitrage/flash-loans/execute
 * Ejecuta arbitraje con flash loan
 */
router.post('/flash-loans/execute', controller.executeFlashLoanArbitrage.bind(controller));

/**
 * GET /api/arbitrage/flash-loans/opportunities
 * Obtiene oportunidades de arbitraje con flash loans
 */
router.get('/flash-loans/opportunities', controller.getFlashLoanOpportunities.bind(controller));

// ===== APROBACIÓN DE TOKENS =====

/**
 * POST /api/arbitrage/tokens/check-allowance
 * Verifica el allowance de un token
 */
router.post('/tokens/check-allowance', controller.checkTokenAllowance.bind(controller));

/**
 * POST /api/arbitrage/tokens/approve
 * Aprueba un token para un spender
 */
router.post('/tokens/approve', controller.approveToken.bind(controller));

// ===== ESTADÍSTICAS Y MÉTRICAS =====

/**
 * GET /api/arbitrage/stats
 * Obtiene estadísticas generales del sistema
 */
router.get('/stats', controller.getArbitrageStats.bind(controller));

/**
 * GET /api/arbitrage/history
 * Obtiene historial de arbitrajes
 */
router.get('/history', controller.getArbitrageHistory.bind(controller));

// ===== CONFIGURACIÓN DE DEXs =====

/**
 * GET /api/arbitrage/dexes
 * Obtiene lista de DEXs configurados
 */
router.get('/dexes', controller.getDexes.bind(controller));

/**
 * POST /api/arbitrage/dexes/toggle
 * Habilita/deshabilita un DEX
 */
router.post('/dexes/toggle', controller.toggleDex.bind(controller));

export default router;
