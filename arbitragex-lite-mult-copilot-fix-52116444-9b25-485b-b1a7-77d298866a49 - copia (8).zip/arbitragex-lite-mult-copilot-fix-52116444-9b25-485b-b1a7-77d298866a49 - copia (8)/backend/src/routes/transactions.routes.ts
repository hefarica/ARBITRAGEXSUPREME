import { Router } from 'express';
import transactionsController from '../controllers/TransactionsController';

const router = Router();

// GET /api/transactions - Get all transactions
router.get('/', transactionsController.getTransactions);

// POST /api/transactions/execute - Execute transaction
router.post('/execute', transactionsController.executeTransaction);

// GET /api/transactions/:id/status - Get transaction status
router.get('/:id/status', transactionsController.getTransactionStatus);

// GET /api/transactions/:id/receipt - Get transaction receipt
router.get('/:id/receipt', transactionsController.getTransactionReceipt);

export default router;
