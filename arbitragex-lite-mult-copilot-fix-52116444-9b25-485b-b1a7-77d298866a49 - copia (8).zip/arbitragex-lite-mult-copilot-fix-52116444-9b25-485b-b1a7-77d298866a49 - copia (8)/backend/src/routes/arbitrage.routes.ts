import { Router } from 'express';
import arbitrageController from '../controllers/ArbitrageController';

const router = Router();

// Rutas de arbitraje
router.get('/opportunities', arbitrageController.getOpportunities);
router.post('/execute', arbitrageController.executeOpportunity);
router.get('/status', arbitrageController.getStatus);
router.get('/metrics', arbitrageController.getMetrics);

export default router;
