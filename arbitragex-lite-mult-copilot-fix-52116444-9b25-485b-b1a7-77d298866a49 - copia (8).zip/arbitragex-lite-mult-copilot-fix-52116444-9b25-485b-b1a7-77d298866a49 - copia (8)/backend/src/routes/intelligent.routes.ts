import { Router } from 'express';
import intelligentController from '../controllers/IntelligentController';

const router = Router();

// GET /api/intelligent/analysis - Get intelligent analysis
router.get('/analysis', intelligentController.getIntelligentAnalysis);

// GET /api/intelligent/decisions - Get intelligent decisions
router.get('/decisions', intelligentController.getIntelligentDecisions);

// GET /api/intelligent/insights - Get predictive insights
router.get('/insights', intelligentController.getPredictiveInsights);

export default router;
