import { Router } from 'express';
import { APIManagementController } from '../controllers/APIManagementController';

const router = Router();
const apiController = new APIManagementController();

// Rutas de configuración de APIs
router.get('/config', apiController.getAPIConfig.bind(apiController));
router.put('/config', apiController.updateAPIConfig.bind(apiController));

// Rutas de prueba de APIs
router.get('/test/all', apiController.testAllAPIs.bind(apiController));
router.get('/test/:service', apiController.testSingleAPI.bind(apiController));

// Rutas de estado de APIs
router.get('/status', apiController.getAPIStatuses.bind(apiController));
router.get('/status/:service', apiController.getAPIStatus.bind(apiController));

// Rutas de datos de APIs
router.get('/coingecko/prices', apiController.getCoinGeckoPrices.bind(apiController));
router.get('/dexscreener/pair/:pair', apiController.getDexScreenerData.bind(apiController));
router.get('/ethereum/gas', apiController.getEthereumGasPrice.bind(apiController));
router.get('/polygon/gas', apiController.getPolygonGasPrice.bind(apiController));
router.get('/etherscan/tx/:txHash', apiController.getEtherscanTransaction.bind(apiController));
router.get('/uniswap/pool/:poolAddress', apiController.getUniswapPoolData.bind(apiController));
router.get('/aave/reserve/:asset', apiController.getAaveReserveData.bind(apiController));

// Rutas de inicialización
router.post('/initialize', apiController.initializeAPIService.bind(apiController));
router.get('/initialize/status', apiController.getInitializationStatus.bind(apiController));

export default router;
