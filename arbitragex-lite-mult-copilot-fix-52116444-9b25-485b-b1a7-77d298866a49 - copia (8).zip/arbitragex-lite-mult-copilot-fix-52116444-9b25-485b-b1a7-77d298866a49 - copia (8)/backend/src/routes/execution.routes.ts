import { Router } from 'express';
import executionController from '../controllers/ExecutionController';

const router = Router();

// GET /api/execution/strategies - Get execution strategies
router.get('/strategies', executionController.getExecutionStrategies);

// POST /api/execution/strategies - Create execution strategy
router.post('/strategies', executionController.createExecutionStrategy);

// PUT /api/execution/strategies/:id - Update execution strategy
router.put('/strategies/:id', executionController.updateExecutionStrategy);

// GET /api/execution/status - Get execution status
router.get('/status', executionController.getExecutionStatus);

export default router;
