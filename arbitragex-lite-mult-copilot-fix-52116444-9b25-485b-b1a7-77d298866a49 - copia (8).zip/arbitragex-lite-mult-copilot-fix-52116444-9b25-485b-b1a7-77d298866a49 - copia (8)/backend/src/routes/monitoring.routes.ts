import { Router } from 'express';
import monitoringController from '../controllers/MonitoringController';

const router = Router();

// Rutas de monitoreo
router.get('/real-time', monitoringController.getRealTimeData);
router.get('/metrics', monitoringController.getMetrics);
router.get('/alerts', monitoringController.getAlerts);
router.post('/alerts', monitoringController.createAlert);
router.get('/health', monitoringController.getSystemHealth);

export default router;
