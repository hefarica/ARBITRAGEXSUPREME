import { Router } from 'express';
import mevAdvancedController from '../controllers/MEVAdvancedController';

const router = Router();

// GET /api/mev/protection - Get MEV protection status
router.get('/protection', mevAdvancedController.getMEVProtection);

// GET /api/mev/analysis - Get MEV analysis
router.get('/analysis', mevAdvancedController.getMEVAnalysis);

// GET /api/mev/strategies - Get MEV strategies
router.get('/strategies', mevAdvancedController.getMEVStrategies);

export default router;
