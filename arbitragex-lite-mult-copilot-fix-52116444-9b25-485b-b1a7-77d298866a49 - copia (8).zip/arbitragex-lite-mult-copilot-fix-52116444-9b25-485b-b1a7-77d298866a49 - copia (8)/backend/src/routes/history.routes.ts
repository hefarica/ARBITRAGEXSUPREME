import { Router } from 'express';
import historyController from '../controllers/HistoryController';

const router = Router();

// GET /api/history/transactions - Get transaction history
router.get('/transactions', historyController.getTransactionHistory);

// GET /api/history/opportunities - Get opportunity history
router.get('/opportunities', historyController.getOpportunityHistory);

// GET /api/history/profits - Get profit history
router.get('/profits', historyController.getProfitHistory);

// GET /api/history/analytics - Get historical analytics
router.get('/analytics', historyController.getHistoricalAnalytics);

export default router;
