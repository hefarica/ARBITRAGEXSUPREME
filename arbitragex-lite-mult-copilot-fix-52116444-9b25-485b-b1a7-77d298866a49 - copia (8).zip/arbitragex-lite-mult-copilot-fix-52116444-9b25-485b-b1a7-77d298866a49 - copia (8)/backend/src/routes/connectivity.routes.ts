import { Router } from 'express';
import connectivityController from '../controllers/ConnectivityController';

const router = Router();

// GET /api/connectivity/status - Get connectivity status
router.get('/status', connectivityController.getConnectivityStatus);

// POST /api/connectivity/test - Test connectivity
router.post('/test', connectivityController.testConnectivity);

// GET /api/connectivity/health - Get network health
router.get('/health', connectivityController.getNetworkHealth);

export default router;
