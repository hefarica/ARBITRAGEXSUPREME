import { Router } from 'express';
import saasController from '../controllers/SaaSController';

const router = Router();

// GET /api/saas/metrics - Get SaaS metrics
router.get('/metrics', saasController.getSaaSMetrics);

// GET /api/saas/users - Get SaaS users
router.get('/users', saasController.getSaaSUsers);

// GET /api/saas/subscriptions - Get SaaS subscriptions
router.get('/subscriptions', saasController.getSaaSSubscriptions);

export default router;
