import { Router } from 'express';
import { MEVDefenseController } from '../controllers/MEVDefenseController';

const router = Router();
const defenseController = new MEVDefenseController();

// Rutas principales del sistema de defensa MEV
router.get('/status', defenseController.getDefenseStatus.bind(defenseController));
router.get('/stats', defenseController.getDefenseStats.bind(defenseController));

// Escaneo y detección de amenazas
router.post('/scan', defenseController.scanThreats.bind(defenseController));
router.get('/threats', defenseController.getThreatHistory.bind(defenseController));
router.get('/history', defenseController.getDefenseHistory.bind(defenseController));

// Ejecución de defensa
router.post('/execute', defenseController.executeDefense.bind(defenseController));
router.post('/execute-specific', defenseController.executeSpecificDefense.bind(defenseController));

// Gestión de coaliciones
router.post('/coalition/join', defenseController.joinCoalition.bind(defenseController));
router.post('/coalition/report', defenseController.reportThreatToCoalition.bind(defenseController));

// Configuración del sistema
router.put('/config', defenseController.updateDefenseConfig.bind(defenseController));

// Modos de emergencia
router.post('/emergency/activate', defenseController.activateEmergencyMode.bind(defenseController));
router.post('/emergency/deactivate', defenseController.deactivateEmergencyMode.bind(defenseController));

export default router;
