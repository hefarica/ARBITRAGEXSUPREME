import 'express-async-errors';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import slowDown from 'express-slow-down';
import morgan from 'morgan';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import dotenv from 'dotenv';

// Configuración de entorno
dotenv.config();

// Importaciones de configuración
import { STRATEGIES_41 } from './config/strategies-simple';

// Importar nuevas rutas
import arbitrageRoutes from './routes/arbitrage.routes';
import configRoutes from './routes/config.routes';
import monitoringRoutes from './routes/monitoring.routes';
import poolsRoutes from './routes/pools.routes';
import transactionsRoutes from './routes/transactions.routes';
import historyRoutes from './routes/history.routes';
import executionRoutes from './routes/execution.routes';
import connectivityRoutes from './routes/connectivity.routes';
import saasRoutes from './routes/saas.routes';
import mevAdvancedRoutes from './routes/mev-advanced.routes';
import intelligentRoutes from './routes/intelligent.routes';
import advancedArbitrageRoutes from './routes/advanced-arbitrage.routes';

class ArbitrageXBackend {
    private app: express.Application;
    private server: any;
    private wss: WebSocketServer;
    private port: number;

    constructor() {
        this.port = parseInt(process.env.PORT || '3002');
        this.app = express();
        this.server = createServer(this.app);
        this.wss = new WebSocketServer({ server: this.server });
        
        this.initializeMiddleware();
        this.initializeRoutes();
        this.initializeWebSocket();
        this.initializeErrorHandling();
    }

    private initializeMiddleware(): void {
        // Middleware de seguridad básica
        this.app.use(helmet({
            contentSecurityPolicy: {
                directives: {
                    defaultSrc: ["'self'"],
                    styleSrc: ["'self'", "'unsafe-inline'"],
                    scriptSrc: ["'self'"],
                    imgSrc: ["'self'", "data:", "https:"],
                    connectSrc: ["'self'", "wss:", "https:"],
                    frameSrc: ["'none'"],
                    objectSrc: ["'none'"],
                    upgradeInsecureRequests: []
                }
            }
        }));

        // CORS configurado para seguridad
        this.app.use(cors({
            origin: process.env.FRONTEND_URL || 'http://localhost:3000',
            credentials: true,
            methods: ['GET', 'POST', 'PUT', 'DELETE'],
            allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
        }));

        // Compresión para mejor rendimiento
        this.app.use(compression());

        // Rate limiting para prevenir ataques
        const limiter = rateLimit({
            windowMs: 15 * 60 * 1000, // 15 minutos
            max: 100, // máximo 100 requests por ventana
            message: 'Demasiadas requests desde esta IP, intenta de nuevo más tarde.',
            standardHeaders: true,
            legacyHeaders: false
        });
        this.app.use('/api/', limiter);

        // Slow down para prevenir spam
        const speedLimiter = slowDown({
            windowMs: 15 * 60 * 1000, // 15 minutos
            delayAfter: 50, // permitir 50 requests sin delay
            delayMs: 500 // agregar 500ms de delay por request después del límite
        });
        this.app.use('/api/', speedLimiter);

        // Logging
        this.app.use(morgan('combined'));

        // Parsing de JSON con límites de seguridad
        this.app.use(express.json({ limit: '10mb' }));
        this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));
    }

    private initializeRoutes(): void {
        // Health check público
        this.app.get('/health', (req, res) => {
            res.json({
                status: 'healthy',
                timestamp: new Date().toISOString(),
                version: '2.0.0',
                environment: process.env.NODE_ENV || 'development'
            });
        });

        // Ruta de estado del sistema
        this.app.get('/api/status', (req, res) => {
            res.json({
                status: 'operational',
                timestamp: new Date().toISOString(),
                strategies_count: STRATEGIES_41.length,
                version: '2.0.0',
                security_level: 'enterprise',
                features: [
                    'multi-chain-support',
                    'hunter-mode',
                    'real-time-monitoring',
                    'advanced-security',
                    'transaction-signing',
                    'metamask-integration'
                ]
            });
        });

        // Ruta de estrategias
        this.app.get('/api/strategies', (req, res) => {
            res.json({
                strategies: STRATEGIES_41,
                count: STRATEGIES_41.length,
                timestamp: new Date().toISOString()
            });
        });

        // Ruta de blockchains
        this.app.get('/api/blockchains', (req, res) => {
            res.json({
                blockchains: [
                    'ethereum', 'bsc', 'polygon', 'avalanche', 'fantom',
                    'arbitrum', 'optimism', 'solana', 'cronos', 'gnosis',
                    'moonbeam', 'base'
                ],
                count: 12,
                timestamp: new Date().toISOString()
            });
        });

        // 🆕 NUEVAS RUTAS IMPLEMENTADAS
        // Rutas de arbitraje
        this.app.use('/api/arbitrage', arbitrageRoutes);
        
        // Rutas de configuración
        this.app.use('/api/config', configRoutes);
        
        // Rutas de monitoreo
        this.app.use('/api/monitoring', monitoringRoutes);
        
        // 🆕 FASE 2: RUTAS COMPLETAS IMPLEMENTADAS
        // Rutas de pools
        this.app.use('/api/pools', poolsRoutes);
        
        // Rutas de transacciones
        this.app.use('/api/transactions', transactionsRoutes);
        
        // Rutas de historia
        this.app.use('/api/history', historyRoutes);
        
        // Rutas de ejecución
        this.app.use('/api/execution', executionRoutes);
        
        // Rutas de conectividad
        this.app.use('/api/connectivity', connectivityRoutes);
        
        // Rutas de SaaS
        this.app.use('/api/saas', saasRoutes);
        
        // Rutas de MEV avanzado
        this.app.use('/api/mev', mevAdvancedRoutes);
        
        // Rutas de inteligencia unificada
        this.app.use('/api/intelligent', intelligentRoutes);

        // Rutas de arbitraje avanzado
        this.app.use('/api/advanced-arbitrage', advancedArbitrageRoutes);

        // Ruta 404 para rutas no encontradas
        this.app.use('*', (req, res) => {
            res.status(404).json({
                error: 'Endpoint no encontrado',
                path: req.originalUrl,
                timestamp: new Date().toISOString()
            });
        });
    }

    private initializeWebSocket(): void {
        // WebSocket para actualizaciones en tiempo real
        this.wss.on('connection', (ws, req) => {
            console.log(`Nueva conexión WebSocket desde ${req.socket.remoteAddress}`);
            
            // Autenticación WebSocket
            ws.on('message', (message) => {
                try {
                    const data = JSON.parse(message.toString());
                    if (data.type === 'auth' && data.token) {
                        // Validar token JWT
                        // Implementar lógica de autenticación WebSocket
                    }
                } catch (error) {
                    console.error('Error en mensaje WebSocket:', error);
                }
            });

            ws.on('close', () => {
                console.log('Conexión WebSocket cerrada');
            });
        });

        // Broadcast a todos los clientes conectados
        setInterval(() => {
            this.wss.clients.forEach((client) => {
                if (client.readyState === 1) { // WebSocket.OPEN
                    client.send(JSON.stringify({
                        type: 'heartbeat',
                        timestamp: new Date().toISOString()
                    }));
                }
            });
        }, 30000); // Cada 30 segundos
    }

    private initializeErrorHandling(): void {
        // Middleware de manejo de errores básico
        this.app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
            console.error('Error:', err);
            res.status(500).json({
                error: 'Error interno del servidor',
                message: err.message,
                timestamp: new Date().toISOString()
            });
        });
    }

    public async start(): Promise<void> {
        try {
            this.server.listen(this.port, () => {
                console.log(`🚀 ArbitrageX Backend v2.0 iniciado en puerto ${this.port}`);
                console.log(`🔒 Nivel de seguridad: ENTERPRISE`);
                console.log(`🌐 WebSocket activo en puerto ${this.port}`);
                console.log(`📊 Total de estrategias: ${STRATEGIES_41.length}`);
                console.log(`🔗 Endpoints disponibles:`);
                console.log(`   GET  /health`);
                console.log(`   GET  /api/status`);
                console.log(`   GET  /api/strategies`);
                console.log(`   GET  /api/blockchains`);
                console.log(`   🆕 GET  /api/arbitrage/opportunities`);
                console.log(`   🆕 POST /api/arbitrage/execute`);
                console.log(`   🆕 GET  /api/arbitrage/status`);
                console.log(`   🆕 GET  /api/arbitrage/metrics`);
                console.log(`   🆕 GET  /api/config/blockchain`);
                console.log(`   🆕 GET  /api/config/dex`);
                console.log(`   🆕 GET  /api/config/strategy`);
                console.log(`   🆕 GET  /api/monitoring/real-time`);
                console.log(`   🆕 GET  /api/monitoring/metrics`);
                console.log(`   🆕 GET  /api/monitoring/alerts`);
                console.log(`   🆕 GET  /api/monitoring/health`);
                console.log(`   🆕 FASE 2 COMPLETADA:`);
                console.log(`   🆕 GET  /api/pools/states`);
                console.log(`   🆕 GET  /api/pools/analytics`);
                console.log(`   🆕 GET  /api/transactions`);
                console.log(`   🆕 POST /api/transactions/execute`);
                console.log(`   🆕 GET  /api/history/transactions`);
                console.log(`   🆕 GET  /api/history/analytics`);
                console.log(`   🆕 GET  /api/execution/strategies`);
                console.log(`   🆕 GET  /api/execution/status`);
                console.log(`   🆕 GET  /api/connectivity/status`);
                console.log(`   🆕 GET  /api/connectivity/health`);
                console.log(`   🆕 GET  /api/saas/metrics`);
                console.log(`   🆕 GET  /api/saas/users`);
                console.log(`   🆕 GET  /api/mev/protection`);
                console.log(`   🆕 GET  /api/mev/analysis`);
                console.log(`   🆕 GET  /api/intelligent/analysis`);
                console.log(`   🆕 GET  /api/intelligent/decisions`);
                console.log(`   🆕 GET  /api/advanced-arbitrage/opportunities`);
                console.log(`   🆕 POST /api/advanced-arbitrage/execute`);
                console.log(`   �� GET  /api/advanced-arbitrage/status`);
                console.log(`   🆕 GET  /api/advanced-arbitrage/metrics`);
            });
        } catch (error) {
            console.error('❌ Error iniciando servidor:', error);
            process.exit(1);
        }
    }

    public async stop(): Promise<void> {
        try {
            this.server.close();
            this.wss.close();
            console.log('🛑 Servidor detenido correctamente');
        } catch (error) {
            console.error('❌ Error deteniendo servidor:', error);
        }
    }
}

// Manejo de señales de terminación
process.on('SIGTERM', async () => {
    console.log('SIGTERM recibido, cerrando servidor...');
    await backend.stop();
    process.exit(0);
});

process.on('SIGINT', async () => {
    console.log('SIGINT recibido, cerrando servidor...');
    await backend.stop();
    process.exit(0);
});

// Manejo de errores no capturados
process.on('uncaughtException', (error) => {
    console.error('❌ Error no capturado:', error);
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Promesa rechazada no manejada:', reason);
    process.exit(1);
});

// Iniciar aplicación
const backend = new ArbitrageXBackend();
backend.start().catch((error) => {
    console.error('❌ Error fatal iniciando aplicación:', error);
    process.exit(1);
});

export default backend;
