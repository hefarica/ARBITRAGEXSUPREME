import { Request, Response, NextFunction } from 'express';
import { logSecurityEvent } from '../utils/logger';
import { config } from '../config';

// Middleware de seguridad principal
export const securityMiddleware = (req: Request, res: Response, next: NextFunction): void => {
    // Agregar headers de seguridad
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    
    // Validar IP
    const clientIP = req.ip || req.connection.remoteAddress || req.socket.remoteAddress;
    if (clientIP) {
        req.clientIP = clientIP;
        
        // Log de conexión para auditoría
        logSecurityEvent('connection_attempt', {
            ip: clientIP,
            userAgent: req.get('User-Agent'),
            method: req.method,
            url: req.originalUrl,
            timestamp: new Date().toISOString()
        });
    }

    // Validar User-Agent
    const userAgent = req.get('User-Agent');
    if (!userAgent || userAgent.length > 500) {
        logSecurityEvent('suspicious_user_agent', {
            ip: clientIP,
            userAgent,
            method: req.method,
            url: req.originalUrl
        });
        return res.status(400).json({
            error: 'User-Agent inválido',
            code: 'INVALID_USER_AGENT'
        });
    }

    // Validar tamaño del request
    const contentLength = parseInt(req.get('Content-Length') || '0');
    if (contentLength > 10 * 1024 * 1024) { // 10MB
        logSecurityEvent('request_too_large', {
            ip: clientIP,
            contentLength,
            method: req.method,
            url: req.originalUrl
        });
        return res.status(413).json({
            error: 'Request demasiado grande',
            code: 'REQUEST_TOO_LARGE'
        });
    }

    // Validar método HTTP
    const allowedMethods = ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'];
    if (!allowedMethods.includes(req.method)) {
        logSecurityEvent('invalid_method', {
            ip: clientIP,
            method: req.method,
            url: req.originalUrl
        });
        return res.status(405).json({
            error: 'Método HTTP no permitido',
            code: 'METHOD_NOT_ALLOWED'
        });
    }

    // Validar URL
    if (req.originalUrl.length > 2048) {
        logSecurityEvent('url_too_long', {
            ip: clientIP,
            url: req.originalUrl,
            length: req.originalUrl.length
        });
        return res.status(414).json({
            error: 'URL demasiado larga',
            code: 'URL_TOO_LONG'
        });
    }

    // Validar headers maliciosos
    const suspiciousHeaders = ['x-forwarded-for', 'x-real-ip', 'x-forwarded-proto'];
    suspiciousHeaders.forEach(header => {
        if (req.get(header)) {
            logSecurityEvent('suspicious_header', {
                ip: clientIP,
                header,
                value: req.get(header),
                method: req.method,
                url: req.originalUrl
            });
        }
    });

    // Validar Content-Type para requests POST/PUT
    if (['POST', 'PUT'].includes(req.method)) {
        const contentType = req.get('Content-Type');
        if (!contentType || !contentType.includes('application/json')) {
            logSecurityEvent('invalid_content_type', {
                ip: clientIP,
                contentType,
                method: req.method,
                url: req.originalUrl
            });
            return res.status(400).json({
                error: 'Content-Type debe ser application/json',
                code: 'INVALID_CONTENT_TYPE'
            });
        }
    }

    // Agregar timestamp para auditoría
    req.requestTimestamp = new Date();

    next();
};

// Middleware para prevenir ataques de timing
export const timingAttackProtection = (req: Request, res: Response, next: NextFunction): void => {
    const start = Date.now();
    
    res.on('finish', () => {
        const duration = Date.now() - start;
        
        // Agregar delay aleatorio para prevenir timing attacks
        const randomDelay = Math.random() * 100; // 0-100ms
        setTimeout(() => {
            // Log de duración para auditoría
            if (duration > 5000) { // Más de 5 segundos
                logSecurityEvent('slow_request', {
                    ip: req.clientIP,
                    duration,
                    method: req.method,
                    url: req.originalUrl,
                    statusCode: res.statusCode
                });
            }
        }, randomDelay);
    });

    next();
};

// Middleware para validar tokens CSRF
export const csrfProtection = (req: Request, res: Response, next: NextFunction): void => {
    if (['POST', 'PUT', 'DELETE'].includes(req.method)) {
        const csrfToken = req.get('X-CSRF-Token');
        const sessionToken = req.session?.csrfToken;
        
        if (!csrfToken || !sessionToken || csrfToken !== sessionToken) {
            logSecurityEvent('csrf_attack', {
                ip: req.clientIP,
                method: req.method,
                url: req.originalUrl,
                providedToken: csrfToken,
                expectedToken: sessionToken
            });
            
            return res.status(403).json({
                error: 'Token CSRF inválido',
                code: 'CSRF_TOKEN_INVALID'
            });
        }
    }
    
    next();
};

// Middleware para prevenir ataques de inyección
export const injectionProtection = (req: Request, res: Response, next: NextFunction): void => {
    const body = req.body;
    const query = req.query;
    const params = req.params;
    
    // Función para detectar patrones sospechosos
    const detectInjection = (value: any): boolean => {
        if (typeof value !== 'string') return false;
        
        const suspiciousPatterns = [
            /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
            /javascript:/gi,
            /on\w+\s*=/gi,
            /<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi,
            /<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi,
            /<embed\b[^<]*(?:(?!<\/embed>)<[^<]*)*<\/embed>/gi,
            /union\s+select/gi,
            /drop\s+table/gi,
            /insert\s+into/gi,
            /delete\s+from/gi,
            /update\s+set/gi,
            /exec\s*\(/gi,
            /eval\s*\(/gi,
            /document\./gi,
            /window\./gi,
            /localStorage/gi,
            /sessionStorage/gi
        ];
        
        return suspiciousPatterns.some(pattern => pattern.test(value));
    };
    
    // Verificar body
    if (body && typeof body === 'object') {
        const checkObject = (obj: any, path: string = ''): boolean => {
            for (const [key, value] of Object.entries(obj)) {
                const currentPath = path ? `${path}.${key}` : key;
                
                if (detectInjection(value)) {
                    logSecurityEvent('injection_attempt', {
                        ip: req.clientIP,
                        type: 'body',
                        path: currentPath,
                        value: String(value),
                        method: req.method,
                        url: req.originalUrl
                    });
                    return true;
                }
                
                if (typeof value === 'object' && value !== null) {
                    if (checkObject(value, currentPath)) return true;
                }
            }
            return false;
        };
        
        if (checkObject(body)) {
            return res.status(400).json({
                error: 'Contenido sospechoso detectado',
                code: 'SUSPICIOUS_CONTENT'
            });
        }
    }
    
    // Verificar query parameters
    if (query && typeof query === 'object') {
        for (const [key, value] of Object.entries(query)) {
            if (detectInjection(value)) {
                logSecurityEvent('injection_attempt', {
                    ip: req.clientIP,
                    type: 'query',
                    key,
                    value: String(value),
                    method: req.method,
                    url: req.originalUrl
                });
                
                return res.status(400).json({
                    error: 'Parámetros de consulta sospechosos',
                    code: 'SUSPICIOUS_QUERY_PARAMS'
                });
            }
        }
    }
    
    // Verificar route parameters
    if (params && typeof params === 'object') {
        for (const [key, value] of Object.entries(params)) {
            if (detectInjection(value)) {
                logSecurityEvent('injection_attempt', {
                    ip: req.clientIP,
                    type: 'params',
                    key,
                    value: String(value),
                    method: req.method,
                    url: req.originalUrl
                });
                
                return res.status(400).json({
                    error: 'Parámetros de ruta sospechosos',
                    code: 'SUSPICIOUS_ROUTE_PARAMS'
                });
            }
        }
    }
    
    next();
};

// Middleware para validar límites de rate por IP
export const ipRateLimit = (req: Request, res: Response, next: NextFunction): void => {
    const clientIP = req.clientIP;
    
    if (!req.ipRateLimit) {
        req.ipRateLimit = {
            count: 0,
            resetTime: Date.now() + (15 * 60 * 1000) // 15 minutos
        };
    }
    
    // Resetear contador si ha pasado el tiempo
    if (Date.now() > req.ipRateLimit.resetTime) {
        req.ipRateLimit.count = 0;
        req.ipRateLimit.resetTime = Date.now() + (15 * 60 * 1000);
    }
    
    // Incrementar contador
    req.ipRateLimit.count++;
    
    // Verificar límite
    if (req.ipRateLimit.count > 100) { // 100 requests por 15 minutos
        logSecurityEvent('rate_limit_exceeded', {
            ip: clientIP,
            count: req.ipRateLimit.count,
            method: req.method,
            url: req.originalUrl
        });
        
        return res.status(429).json({
            error: 'Límite de rate excedido',
            code: 'RATE_LIMIT_EXCEEDED',
            retryAfter: Math.ceil((req.ipRateLimit.resetTime - Date.now()) / 1000)
        });
    }
    
    next();
};

// Middleware para validar autenticación de WebSocket
export const websocketAuth = (ws: any, req: any, next: any): void => {
    const token = req.url.split('token=')[1];
    
    if (!token) {
        logSecurityEvent('websocket_auth_failed', {
            ip: req.socket.remoteAddress,
            reason: 'no_token_provided'
        });
        ws.close(1008, 'Token de autenticación requerido');
        return;
    }
    
    // Aquí se validaría el token JWT
    // Por ahora solo logueamos el intento
    logSecurityEvent('websocket_auth_attempt', {
        ip: req.socket.remoteAddress,
        hasToken: !!token
    });
    
    next();
};

// Middleware para logging de seguridad
export const securityLogging = (req: Request, res: Response, next: NextFunction): void => {
    // Log de inicio de request
    logSecurityEvent('request_started', {
        ip: req.clientIP,
        method: req.method,
        url: req.originalUrl,
        userAgent: req.get('User-Agent'),
        timestamp: req.requestTimestamp
    });
    
    // Log de fin de request
    res.on('finish', () => {
        logSecurityEvent('request_completed', {
            ip: req.clientIP,
            method: req.method,
            url: req.originalUrl,
            statusCode: res.statusCode,
            duration: Date.now() - req.requestTimestamp.getTime()
        });
    });
    
    next();
};

// Exportar todos los middlewares de seguridad
export const securityMiddlewares = [
    securityMiddleware,
    timingAttackProtection,
    injectionProtection,
    ipRateLimit,
    securityLogging
];
