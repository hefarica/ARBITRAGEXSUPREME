import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { logSecurityEvent } from '../utils/logger';
import { config } from '../config';

// Extender la interfaz Request para incluir el usuario
declare global {
    namespace Express {
        interface Request {
            user?: {
                id: string;
                email: string;
                role: string;
                permissions: string[];
                blockchainWallets: string[];
            };
            clientIP?: string;
            requestTimestamp?: Date;
        }
    }
}

// Middleware de autenticación principal
export const authMiddleware = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const authHeader = req.get('Authorization');
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            logSecurityEvent('auth_failed', {
                ip: req.clientIP,
                reason: 'no_auth_header',
                method: req.method,
                url: req.originalUrl
            });
            
            return res.status(401).json({
                error: 'Token de autenticación requerido',
                code: 'AUTH_TOKEN_REQUIRED'
            });
        }

        const token = authHeader.substring(7); // Remover 'Bearer '
        
        if (!token) {
            logSecurityEvent('auth_failed', {
                ip: req.clientIP,
                reason: 'empty_token',
                method: req.method,
                url: req.originalUrl
            });
            
            return res.status(401).json({
                error: 'Token vacío',
                code: 'EMPTY_TOKEN'
            });
        }

        // Verificar y decodificar el token JWT
        const decoded = jwt.verify(token, config.security.jwt.secret) as any;
        
        if (!decoded || !decoded.userId) {
            logSecurityEvent('auth_failed', {
                ip: req.clientIP,
                reason: 'invalid_token_structure',
                method: req.method,
                url: req.originalUrl
            });
            
            return res.status(401).json({
                error: 'Token inválido',
                code: 'INVALID_TOKEN_STRUCTURE'
            });
        }

        // Verificar si el token ha expirado
        if (decoded.exp && Date.now() >= decoded.exp * 1000) {
            logSecurityEvent('auth_failed', {
                ip: req.clientIP,
                reason: 'token_expired',
                method: req.method,
                url: req.originalUrl,
                userId: decoded.userId
            });
            
            return res.status(401).json({
                error: 'Token expirado',
                code: 'TOKEN_EXPIRED'
            });
        }

        // Verificar si el token ha sido revocado (blacklist)
        if (await isTokenRevoked(token)) {
            logSecurityEvent('auth_failed', {
                ip: req.clientIP,
                reason: 'token_revoked',
                method: req.method,
                url: req.originalUrl,
                userId: decoded.userId
            });
            
            return res.status(401).json({
                error: 'Token revocado',
                code: 'TOKEN_REVOKED'
            });
        }

        // Agregar información del usuario al request
        req.user = {
            id: decoded.userId,
            email: decoded.email,
            role: decoded.role || 'user',
            permissions: decoded.permissions || [],
            blockchainWallets: decoded.blockchainWallets || []
        };

        // Log de autenticación exitosa
        logSecurityEvent('auth_success', {
            ip: req.clientIP,
            userId: decoded.userId,
            method: req.method,
            url: req.originalUrl,
            role: decoded.role
        });

        next();
        
    } catch (error) {
        logSecurityEvent('auth_error', {
            ip: req.clientIP,
            error: error.message,
            method: req.method,
            url: req.originalUrl
        });
        
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                error: 'Token malformado',
                code: 'MALFORMED_TOKEN'
            });
        }
        
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                error: 'Token expirado',
                code: 'TOKEN_EXPIRED'
            });
        }
        
        return res.status(500).json({
            error: 'Error interno de autenticación',
            code: 'AUTH_INTERNAL_ERROR'
        });
    }
};

// Middleware para roles específicos
export const requireRole = (roles: string[]) => {
    return (req: Request, res: Response, next: NextFunction): void => {
        if (!req.user) {
            return res.status(401).json({
                error: 'Usuario no autenticado',
                code: 'USER_NOT_AUTHENTICATED'
            });
        }

        if (!roles.includes(req.user.role)) {
            logSecurityEvent('unauthorized_access', {
                ip: req.clientIP,
                userId: req.user.id,
                userRole: req.user.role,
                requiredRoles: roles,
                method: req.method,
                url: req.originalUrl
            });
            
            return res.status(403).json({
                error: 'Acceso denegado',
                code: 'ACCESS_DENIED',
                requiredRoles: roles,
                userRole: req.user.role
            });
        }

        next();
    };
};

// Middleware para permisos específicos
export const requirePermission = (permissions: string[]) => {
    return (req: Request, res: Response, next: NextFunction): void => {
        if (!req.user) {
            return res.status(401).json({
                error: 'Usuario no autenticado',
                code: 'USER_NOT_AUTHENTICATED'
            });
        }

        const hasAllPermissions = permissions.every(permission => 
            req.user!.permissions.includes(permission)
        );

        if (!hasAllPermissions) {
            logSecurityEvent('insufficient_permissions', {
                ip: req.clientIP,
                userId: req.user.id,
                userPermissions: req.user.permissions,
                requiredPermissions: permissions,
                method: req.method,
                url: req.originalUrl
            });
            
            return res.status(403).json({
                error: 'Permisos insuficientes',
                code: 'INSUFFICIENT_PERMISSIONS',
                requiredPermissions: permissions,
                userPermissions: req.user.permissions
            });
        }

        next();
    };
};

// Middleware para validar wallet de blockchain
export const requireBlockchainWallet = (blockchain: string) => {
    return (req: Request, res: Response, next: NextFunction): void => {
        if (!req.user) {
            return res.status(401).json({
                error: 'Usuario no autenticado',
                code: 'USER_NOT_AUTHENTICATED'
            });
        }

        if (!req.user.blockchainWallets.includes(blockchain)) {
            logSecurityEvent('blockchain_wallet_required', {
                ip: req.clientIP,
                userId: req.user.id,
                requiredBlockchain: blockchain,
                userWallets: req.user.blockchainWallets,
                method: req.method,
                url: req.originalUrl
            });
            
            return res.status(403).json({
                error: `Wallet de ${blockchain} requerida`,
                code: 'BLOCKCHAIN_WALLET_REQUIRED',
                requiredBlockchain: blockchain,
                userWallets: req.user.blockchainWallets
            });
        }

        next();
    };
};

// Middleware para validar límites de rate por usuario
export const userRateLimit = (maxRequests: number, windowMs: number) => {
    const userRequests = new Map<string, { count: number; resetTime: number }>();
    
    return (req: Request, res: Response, next: NextFunction): void => {
        if (!req.user) {
            return next();
        }

        const userId = req.user.id;
        const now = Date.now();
        
        if (!userRequests.has(userId)) {
            userRequests.set(userId, {
                count: 0,
                resetTime: now + windowMs
            });
        }

        const userData = userRequests.get(userId)!;
        
        // Resetear contador si ha pasado el tiempo
        if (now > userData.resetTime) {
            userData.count = 0;
            userData.resetTime = now + windowMs;
        }

        // Incrementar contador
        userData.count++;

        // Verificar límite
        if (userData.count > maxRequests) {
            logSecurityEvent('user_rate_limit_exceeded', {
                ip: req.clientIP,
                userId,
                count: userData.count,
                maxRequests,
                method: req.method,
                url: req.originalUrl
            });
            
            return res.status(429).json({
                error: 'Límite de rate excedido para este usuario',
                code: 'USER_RATE_LIMIT_EXCEEDED',
                retryAfter: Math.ceil((userData.resetTime - now) / 1000)
            });
        }

        next();
    };
};

// Middleware para validar sesión activa
export const requireActiveSession = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    if (!req.user) {
        return res.status(401).json({
            error: 'Usuario no autenticado',
            code: 'USER_NOT_AUTHENTICATED'
        });
    }

    // Verificar si la sesión del usuario está activa
    const isSessionActive = await checkUserSessionActive(req.user.id);
    
    if (!isSessionActive) {
        logSecurityEvent('inactive_session', {
            ip: req.clientIP,
            userId: req.user.id,
            method: req.method,
            url: req.originalUrl
        });
        
        return res.status(401).json({
            error: 'Sesión inactiva',
            code: 'INACTIVE_SESSION'
        });
    }

    next();
};

// Middleware para validar 2FA si está habilitado
export const require2FA = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    if (!req.user) {
        return res.status(401).json({
            error: 'Usuario no autenticado',
            code: 'USER_NOT_AUTHENTICATED'
        });
    }

    // Verificar si el usuario tiene 2FA habilitado
    const has2FAEnabled = await checkUser2FAEnabled(req.user.id);
    
    if (has2FAEnabled) {
        const twoFactorToken = req.get('X-2FA-Token');
        
        if (!twoFactorToken) {
            return res.status(401).json({
                error: 'Token 2FA requerido',
                code: '2FA_TOKEN_REQUIRED'
            });
        }

        // Verificar token 2FA
        const isValid2FA = await validate2FAToken(req.user.id, twoFactorToken);
        
        if (!isValid2FA) {
            logSecurityEvent('2fa_failed', {
                ip: req.clientIP,
                userId: req.user.id,
                method: req.method,
                url: req.originalUrl
            });
            
            return res.status(401).json({
                error: 'Token 2FA inválido',
                code: 'INVALID_2FA_TOKEN'
            });
        }
    }

    next();
};

// Funciones auxiliares (implementar según la base de datos)
async function isTokenRevoked(token: string): Promise<boolean> {
    // Implementar verificación en base de datos
    return false;
}

async function checkUserSessionActive(userId: string): Promise<boolean> {
    // Implementar verificación en base de datos
    return true;
}

async function checkUser2FAEnabled(userId: string): Promise<boolean> {
    // Implementar verificación en base de datos
    return false;
}

async function validate2FAToken(userId: string, token: string): Promise<boolean> {
    // Implementar validación 2FA
    return true;
}

// Función para generar token JWT
export function generateToken(user: any): string {
    const payload = {
        userId: user.id,
        email: user.email,
        role: user.role,
        permissions: user.permissions || [],
        blockchainWallets: user.blockchainWallets || [],
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 horas
    };

    return jwt.sign(payload, config.security.jwt.secret);
}

// Función para generar token de refresh
export function generateRefreshToken(user: any): string {
    const payload = {
        userId: user.id,
        type: 'refresh',
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + (7 * 24 * 60 * 60) // 7 días
    };

    return jwt.sign(payload, config.security.jwt.secret);
}

// Función para hashear contraseñas
export async function hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, config.security.bcrypt.saltRounds);
}

// Función para verificar contraseñas
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
}

// Exportar middlewares de autenticación
export const authMiddlewares = {
    auth: authMiddleware,
    requireRole,
    requirePermission,
    requireBlockchainWallet,
    userRateLimit,
    requireActiveSession,
    require2FA
};
