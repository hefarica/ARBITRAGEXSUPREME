import dotenv from 'dotenv';

// Cargar variables de entorno
dotenv.config();

export const config = {
    // Configuración del servidor
    server: {
        port: parseInt(process.env.PORT || '3001'),
        host: process.env.HOST || 'localhost',
        environment: process.env.NODE_ENV || 'development',
        cors: {
            origin: process.env.FRONTEND_URL || 'http://localhost:3000',
            credentials: true
        }
    },

    // Configuración de seguridad
    security: {
        jwt: {
            secret: process.env.JWT_SECRET || 'arbitragex-super-secret-key-change-in-production',
            expiresIn: process.env.JWT_EXPIRES_IN || '24h',
            refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
        },
        bcrypt: {
            saltRounds: parseInt(process.env.BCRYPT_SALT_ROUNDS || '12')
        },
        rateLimit: {
            windowMs: 15 * 60 * 1000, // 15 minutos
            max: parseInt(process.env.RATE_LIMIT_MAX || '100'),
            message: 'Demasiadas requests desde esta IP'
        },
        slowDown: {
            windowMs: 15 * 60 * 1000, // 15 minutos
            delayAfter: parseInt(process.env.SLOW_DOWN_DELAY_AFTER || '50'),
            delayMs: parseInt(process.env.SLOW_DOWN_DELAY_MS || '500')
        }
    },

    // Configuración de base de datos
    database: {
        type: process.env.DB_TYPE || 'sqlite',
        sqlite: {
            path: process.env.SQLITE_PATH || './data/arbitragex.db'
        },
        postgres: {
            host: process.env.POSTGRES_HOST || 'localhost',
            port: parseInt(process.env.POSTGRES_PORT || '5432'),
            username: process.env.POSTGRES_USER || 'arbitragex',
            password: process.env.POSTGRES_PASSWORD || 'password',
            database: process.env.POSTGRES_DB || 'arbitragex'
        },
        redis: {
            host: process.env.REDIS_HOST || 'localhost',
            port: parseInt(process.env.REDIS_PORT || '6379'),
            password: process.env.REDIS_PASSWORD || undefined,
            db: parseInt(process.env.REDIS_DB || '0')
        }
    },

    // Configuración de blockchain
    blockchain: {
        ethereum: {
            rpc: process.env.ETHEREUM_RPC || 'https://mainnet.infura.io/v3/your-project-id',
            chainId: 1,
            name: 'Ethereum Mainnet',
            explorer: 'https://etherscan.io',
            gasLimit: 300000,
            maxFeePerGas: '50', // gwei
            maxPriorityFeePerGas: '2' // gwei
        },
        polygon: {
            rpc: process.env.POLYGON_RPC || 'https://polygon-rpc.com',
            chainId: 137,
            name: 'Polygon Mainnet',
            explorer: 'https://polygonscan.com',
            gasLimit: 500000,
            maxFeePerGas: '30', // gwei
            maxPriorityFeePerGas: '1' // gwei
        },
        arbitrum: {
            rpc: process.env.ARBITRUM_RPC || 'https://arb1.arbitrum.io/rpc',
            chainId: 42161,
            name: 'Arbitrum One',
            explorer: 'https://arbiscan.io',
            gasLimit: 1000000,
            maxFeePerGas: '0.1', // gwei
            maxPriorityFeePerGas: '0.01' // gwei
        },
        optimism: {
            rpc: process.env.OPTIMISM_RPC || 'https://mainnet.optimism.io',
            chainId: 10,
            name: 'Optimism',
            explorer: 'https://optimistic.etherscan.io',
            gasLimit: 500000,
            maxFeePerGas: '0.001', // gwei
            maxPriorityFeePerGas: '0.0001' // gwei
        },
        bsc: {
            rpc: process.env.BSC_RPC || 'https://bsc-dataseed.binance.org',
            chainId: 56,
            name: 'BNB Smart Chain',
            explorer: 'https://bscscan.com',
            gasLimit: 500000,
            maxFeePerGas: '5', // gwei
            maxPriorityFeePerGas: '1.5' // gwei
        },
        avalanche: {
            rpc: process.env.AVALANCHE_RPC || 'https://api.avax.network/ext/bc/C/rpc',
            chainId: 43114,
            name: 'Avalanche C-Chain',
            explorer: 'https://snowtrace.io',
            gasLimit: 800000,
            maxFeePerGas: '25', // gwei
            maxPriorityFeePerGas: '1.5' // gwei
        },
        fantom: {
            rpc: process.env.FANTOM_RPC || 'https://rpc.ftm.tools',
            chainId: 250,
            name: 'Fantom Opera',
            explorer: 'https://ftmscan.com',
            gasLimit: 400000,
            maxFeePerGas: '100', // gwei
            maxPriorityFeePerGas: '1' // gwei
        },
        cronos: {
            rpc: process.env.CRONOS_RPC || 'https://evm.cronos.org',
            chainId: 25,
            name: 'Cronos',
            explorer: 'https://cronoscan.com',
            gasLimit: 500000,
            maxFeePerGas: '5000', // gwei
            maxPriorityFeePerGas: '1000' // gwei
        }
    },

    // Configuración de APIs externas
    apis: {
        coingecko: {
            baseUrl: 'https://api.coingecko.com/api/v3',
            apiKey: process.env.COINGECKO_API_KEY || undefined
        },
        etherscan: {
            baseUrl: 'https://api.etherscan.io/api',
            apiKey: process.env.ETHERSCAN_API_KEY || undefined
        },
        polygonscan: {
            baseUrl: 'https://api.polygonscan.com/api',
            apiKey: process.env.POLYGONSCAN_API_KEY || undefined
        },
        arbiscan: {
            baseUrl: 'https://api.arbiscan.io/api',
            apiKey: process.env.ARBISCAN_API_KEY || undefined
        }
    },

    // Configuración de estrategias
    strategies: {
        defaultRiskLevel: 'medium',
        defaultMinCapital: 1000,
        defaultMaxCapital: 100000,
        maxConcurrentStrategies: 5,
        executionTimeout: 300000, // 5 minutos
        cooldownPeriod: 60000 // 1 minuto
    },

    // Configuración de monitoreo
    monitoring: {
        logLevel: process.env.LOG_LEVEL || 'info',
        enableMetrics: process.env.ENABLE_METRICS === 'true',
        metricsPort: parseInt(process.env.METRICS_PORT || '9090'),
        healthCheckInterval: 30000, // 30 segundos
        performanceMonitoring: process.env.ENABLE_PERFORMANCE_MONITORING === 'true'
    },

    // Configuración de WebSocket
    websocket: {
        heartbeatInterval: 30000, // 30 segundos
        maxConnections: 1000,
        enableCompression: true
    },

    // Configuración de transacciones
    transactions: {
        maxPendingTransactions: 10,
        transactionTimeout: 300000, // 5 minutos
        enableAutoRetry: true,
        maxRetries: 3,
        retryDelay: 5000 // 5 segundos
    },

    // Configuración de Hunter Mode
    hunterMode: {
        enabled: true,
        maxActiveHunters: 10,
        scanInterval: 10000, // 10 segundos
        profitThreshold: 0.5, // 0.5%
        maxSlippage: 2.0, // 2%
        enableAutoExecution: false
    }
};

// Validar configuración crítica
export function validateConfig(): void {
    const requiredEnvVars = [
        'JWT_SECRET',
        'NODE_ENV'
    ];

    const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
    
    if (missingVars.length > 0) {
        console.warn(`⚠️  Variables de entorno faltantes: ${missingVars.join(', ')}`);
        console.warn('⚠️  Usando valores por defecto. En producción, configura todas las variables requeridas.');
    }

    // Validar configuración de blockchain
    Object.entries(config.blockchain).forEach(([chain, config]) => {
        if (!config.rpc) {
            console.warn(`⚠️  RPC no configurado para ${chain}`);
        }
    });

    // Validar configuración de seguridad en producción
    if (config.server.environment === 'production') {
        if (config.security.jwt.secret === 'arbitragex-super-secret-key-change-in-production') {
            throw new Error('❌ JWT_SECRET debe ser configurado en producción');
        }
        
        if (config.database.type === 'sqlite') {
            console.warn('⚠️  SQLite no es recomendado para producción. Considera usar PostgreSQL.');
        }
    }
}

// Exportar configuración validada
export default config;
