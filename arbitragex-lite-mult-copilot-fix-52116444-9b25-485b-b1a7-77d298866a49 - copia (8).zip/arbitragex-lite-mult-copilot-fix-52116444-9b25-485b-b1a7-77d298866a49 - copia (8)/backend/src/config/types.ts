export type Blockchain = 
  | "ethereum" 
  | "polygon" 
  | "bsc" 
  | "arbitrum" 
  | "optimism" 
  | "avalanche" 
  | "fantom" 
  | "solana"
  | "cronos"
  | "gnosis"
  | "moonbeam";

export type RiskLevel = "low" | "medium" | "high" | "extreme";
export type ExecutionMode = "cascade" | "simultaneous" | "continuous";
export type StrategyCategory = "arbitrage" | "yield" | "derivatives" | "protection" | "governance";

export const ALL_CHAINS: Blockchain[] = [
  "ethereum", "polygon", "bsc", "arbitrum", "optimism", "avalanche", "fantom", "solana", "cronos", "gnosis", "moonbeam"
];

export interface Strategy {
  id: string;
  name: string;
  description: string;
  category: StrategyCategory;
  risk_level: RiskLevel;
  min_capital: number;
  max_capital: number;
  expected_roi: number;
  success_rate: number;
  blockchains: Blockchain[];
  execution_mode: ExecutionMode;
  cooldown: number;
  enabled: boolean;
}

export interface HunterModeConfig {
  gate: {
    min_roi: number;
    min_success_rate: number;
    max_risk: RiskLevel;
    min_capital: number;
  };
  sizing: {
    position_size_percent: number;
    max_positions: number;
    risk_per_trade: number;
  };
  mode: "cascade" | "simultaneous";
  coverage: {
    target_blockchains: Blockchain[];
    target_categories: StrategyCategory[];
    max_strategies_per_chain: number;
  };
}

export interface StrategyRanking {
  strategy: Strategy;
  score: number;
  viability: number;
  execution_priority: number;
  risk_adjusted_return: number;
  market_conditions: {
    volatility: number;
    liquidity: number;
    gas_fees: number;
  };
}

export interface HunterRanking {
  strategy: Strategy;
  hunter_score: number;
  gate_passed: boolean;
  sizing_recommendation: {
    position_size: number;
    max_positions: number;
    risk_allocation: number;
  };
  execution_timing: {
    immediate: boolean;
    wait_time: number;
    reason: string;
  };
  coverage_impact: {
    blockchain_diversity: number;
    category_diversity: number;
    portfolio_balance: number;
  };
}
