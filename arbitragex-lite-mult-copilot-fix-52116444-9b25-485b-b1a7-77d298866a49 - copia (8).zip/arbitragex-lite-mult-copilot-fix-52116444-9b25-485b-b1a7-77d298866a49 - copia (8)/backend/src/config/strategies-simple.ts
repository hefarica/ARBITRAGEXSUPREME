// Configuración simplificada de estrategias para evitar problemas de import
export const STRATEGIES_41 = [
  {
    id: "impermanent_loss_arbitrage",
    name: "Arbitraje de Pérdida Impermanente",
    description: "Arbitraje aprovechando pérdidas impermanentes en pools AMM",
    category: "arbitrage",
    risk_level: "medium",
    min_capital: 2000,
    max_capital: 100000,
    expected_roi: 0.9,
    success_rate: 0.75,
    enabled: true
  },
  {
    id: "cross_chain_arbitrage",
    name: "Arbitraje Cross-Chain",
    description: "Arbitraje entre diferentes blockchains",
    category: "arbitrage",
    risk_level: "high",
    min_capital: 5000,
    max_capital: 200000,
    expected_roi: 1.5,
    success_rate: 0.80,
    enabled: true
  }
];

// Estrategias básicas para evitar errores
export const BASIC_STRATEGIES = STRATEGIES_41;