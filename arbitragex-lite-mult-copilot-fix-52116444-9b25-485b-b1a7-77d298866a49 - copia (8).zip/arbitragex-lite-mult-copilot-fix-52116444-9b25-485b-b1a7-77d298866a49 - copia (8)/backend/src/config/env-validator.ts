import { z } from 'zod';
import dotenv from 'dotenv';

// Cargar variables de entorno
dotenv.config();

// Esquema de validación de variables de entorno
const envSchema = z.object({
  // Configuración del servidor
  PORT: z.string().transform(Number).default('3002'),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  FRONTEND_URL: z.string().url().default('http://localhost:3000'),

  // Base de datos
  DATABASE_URL: z.string().default('sqlite:./data/arbitragex.db'),
  REDIS_URL: z.string().default('redis://localhost:6379'),

  // Seguridad
  JWT_SECRET: z.string().min(32, 'JWT_SECRET debe tener al menos 32 caracteres'),
  BCRYPT_ROUNDS: z.string().transform(Number).default('12'),
  SESSION_SECRET: z.string().min(32, 'SESSION_SECRET debe tener al menos 32 caracteres'),

  // APIs externas (opcionales en desarrollo)
  COINGECKO_API_KEY: z.string().optional(),
  ETHERSCAN_API_KEY: z.string().optional(),
  INFURA_PROJECT_ID: z.string().optional(),
  INFURA_PROJECT_SECRET: z.string().optional(),
  ALCHEMY_API_KEY: z.string().optional(),
  QUICKNODE_URL: z.string().optional(),
  QUICKNODE_API_KEY: z.string().optional(),

  // Blockchain RPCs (opcionales en desarrollo)
  ETHEREUM_RPC_URL: z.string().url().optional(),
  BSC_RPC_URL: z.string().url().optional(),
  POLYGON_RPC_URL: z.string().url().optional(),
  AVALANCHE_RPC_URL: z.string().url().optional(),
  ARBITRUM_RPC_URL: z.string().url().optional(),
  OPTIMISM_RPC_URL: z.string().url().optional(),

  // Flashbots (opcional)
  FLASHBOTS_RELAY_URL: z.string().url().optional(),
  FLASHBOTS_PRIVATE_KEY: z.string().optional(),

  // Monitoreo
  LOG_LEVEL: z.enum(['error', 'warn', 'info', 'debug']).default('info'),
  ENABLE_METRICS: z.string().transform(val => val === 'true').default('true'),
  METRICS_PORT: z.string().transform(Number).default('9090'),

  // Desarrollo
  ENABLE_SWAGGER: z.string().transform(val => val === 'true').default('true'),
  ENABLE_DEBUG: z.string().transform(val => val === 'true').default('true'),
  CORS_ORIGINS: z.string().default('http://localhost:3000,http://localhost:3001'),
});

// Validar y exportar variables de entorno
export const env = envSchema.parse(process.env);

// Función para validar configuración crítica
export function validateCriticalConfig(): void {
  const criticalErrors: string[] = [];

  // Verificar variables críticas para producción
  if (process.env.NODE_ENV === 'production') {
    if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
      criticalErrors.push('JWT_SECRET es requerido y debe tener al menos 32 caracteres en producción');
    }
    
    if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
      criticalErrors.push('SESSION_SECRET es requerido y debe tener al menos 32 caracteres en producción');
    }
  }

  // Verificar al menos un RPC configurado
  const rpcUrls = [
    process.env.ETHEREUM_RPC_URL,
    process.env.BSC_RPC_URL,
    process.env.POLYGON_RPC_URL,
    process.env.AVALANCHE_RPC_URL,
    process.env.ARBITRUM_RPC_URL,
    process.env.OPTIMISM_RPC_URL,
  ].filter(Boolean);

  if (rpcUrls.length === 0) {
    criticalErrors.push('Al menos un RPC de blockchain debe estar configurado');
  }

  if (criticalErrors.length > 0) {
    throw new Error(`Configuración crítica inválida:\n${criticalErrors.join('\n')}`);
  }
}

// Función para mostrar configuración actual
export function logCurrentConfig(): void {
  console.log('🔧 Configuración actual:');
  console.log(`   Puerto: ${env.PORT}`);
  console.log(`   Entorno: ${env.NODE_ENV}`);
  console.log(`   Frontend URL: ${env.FRONTEND_URL}`);
  console.log(`   Log Level: ${env.LOG_LEVEL}`);
  console.log(`   Métricas: ${env.ENABLE_METRICS ? 'Habilitadas' : 'Deshabilitadas'}`);
  console.log(`   Debug: ${env.ENABLE_DEBUG ? 'Habilitado' : 'Deshabilitado'}`);
}

export default env;