import { z } from 'zod';

// =============================================================================
// 🔍 VALIDADOR DE VARIABLES DE ENTORNO - ARBITRAGEX 2025
// =============================================================================

// Esquema de validación para variables de entorno
const envSchema = z.object({
  // =============================================================================
  // 🔌 CONFIGURACIÓN DE API
  // =============================================================================
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.string().transform(Number).default('8000'),
  
  // =============================================================================
  // ⛓️ CONFIGURACIÓN DE BLOCKCHAINS - WEBSOCKET
  // =============================================================================
  REACT_APP_ETH_WS_URL: z.string().url('URL de WebSocket de Ethereum debe ser válida'),
  REACT_APP_BSC_WS_URL: z.string().url('URL de WebSocket de BSC debe ser válida'),
  REACT_APP_POLYGON_WS_URL: z.string().url('URL de WebSocket de Polygon debe ser válida'),
  REACT_APP_AVALANCHE_WS_URL: z.string().url('URL de WebSocket de Avalanche debe ser válida'),
  REACT_APP_FANTOM_WS_URL: z.string().url('URL de WebSocket de Fantom debe ser válida'),
  REACT_APP_ARBITRUM_WS_URL: z.string().url('URL de WebSocket de Arbitrum debe ser válida'),
  REACT_APP_OPTIMISM_WS_URL: z.string().url('URL de WebSocket de Optimism debe ser válida'),
  REACT_APP_POLYGON_ZKEVM_WS_URL: z.string().url('URL de WebSocket de Polygon zkEVM debe ser válida'),
  REACT_APP_CRONOS_WS_URL: z.string().url('URL de WebSocket de Cronos debe ser válida'),
  REACT_APP_GNOSIS_WS_URL: z.string().url('URL de WebSocket de Gnosis debe ser válida'),
  REACT_APP_MOONBEAM_WS_URL: z.string().url('URL de WebSocket de Moonbeam debe ser válida'),
  REACT_APP_BASE_WS_URL: z.string().url('URL de WebSocket de Base debe ser válida'),
  
  // =============================================================================
  // 🔑 CLAVES DE API EXTERNAS
  // =============================================================================
  REACT_APP_INFURA_PROJECT_ID: z.string().min(1, 'Infura Project ID es requerido'),
  REACT_APP_INFURA_PROJECT_SECRET: z.string().min(1, 'Infura Project Secret es requerido'),
  REACT_APP_ALCHEMY_API_KEY: z.string().min(1, 'Alchemy API Key es requerido'),
  REACT_APP_GETBLOCK_API_KEY: z.string().min(1, 'GetBlock API Key es requerido'),
  REACT_APP_BLASTAPI_API_KEY: z.string().min(1, 'BlastAPI Key es requerido'),
  
  // =============================================================================
  // 📊 SUBGRAFOS Y PROTOCOLOS
  // =============================================================================
  REACT_APP_THEGRAPH_API_KEY: z.string().min(1, 'The Graph API Key es requerido'),
  REACT_APP_AAVE_SUBGRAPH_URL: z.string().url('URL del subgrafo de Aave debe ser válida'),
  REACT_APP_UNISWAP_SUBGRAPH_URL: z.string().url('URL del subgrafo de Uniswap debe ser válida'),
  
  // =============================================================================
  // 🛡️ CONFIGURACIÓN DE SEGURIDAD
  // =============================================================================
  JWT_SECRET: z.string().min(32, 'JWT Secret debe tener al menos 32 caracteres'),
  RATE_LIMIT_WINDOW_MS: z.string().transform(Number).default('900000'),
  RATE_LIMIT_MAX_REQUESTS: z.string().transform(Number).default('100'),
  CORS_ORIGINS: z.string().default('http://localhost:3000,http://localhost:8000'),
  
  // =============================================================================
  // 🗄️ BASE DE DATOS
  // =============================================================================
  DATABASE_URL: z.string().url('URL de base de datos debe ser válida'),
  REDIS_URL: z.string().url('URL de Redis debe ser válida'),
  MONGODB_URL: z.string().url('URL de MongoDB debe ser válida'),
  
  // =============================================================================
  // ☁️ SERVICIOS EN LA NUBE
  // =============================================================================
  AWS_ACCESS_KEY_ID: z.string().min(1, 'AWS Access Key ID es requerido'),
  AWS_SECRET_ACCESS_KEY: z.string().min(1, 'AWS Secret Access Key es requerido'),
  AWS_REGION: z.string().default('us-east-1'),
  AWS_S3_BUCKET: z.string().min(1, 'AWS S3 Bucket es requerido'),
  
  // =============================================================================
  // 💰 CONFIGURACIÓN DE ARBITRAJE
  // =============================================================================
  MAX_GAS_PRICE_GWEI: z.string().transform(Number).default('100'),
  MAX_SLIPPAGE_PERCENT: z.string().transform(Number).default('2.5'),
  MIN_OPPORTUNITY_SIZE_USD: z.string().transform(Number).default('10'),
  MAX_EXECUTION_TIME_SECONDS: z.string().transform(Number).default('30'),
});

// Tipo TypeScript derivado del esquema
export type EnvConfig = z.infer<typeof envSchema>;

// Clase para validar y gestionar variables de entorno
export class EnvironmentValidator {
  private config: EnvConfig;
  private errors: string[] = [];

  constructor() {
    this.config = {} as EnvConfig;
  }

  // Validar todas las variables de entorno
  validate(): { success: boolean; config?: EnvConfig; errors: string[] } {
    try {
      // Obtener variables de entorno del proceso
      const envVars = process.env;
      
      // Validar usando Zod
      this.config = envSchema.parse(envVars);
      
      return {
        success: true,
        config: this.config,
        errors: []
      };
    } catch (error) {
      if (error instanceof z.ZodError) {
        this.errors = error.errors.map(err => {
          const path = err.path.join('.');
          return `${path}: ${err.message}`;
        });
      } else {
        this.errors = [`Error de validación: ${error}`];
      }
      
      return {
        success: false,
        errors: this.errors
      };
    }
  }

  // Validar variables críticas para el funcionamiento básico
  validateCritical(): { success: boolean; errors: string[] } {
    const criticalVars = [
      'REACT_APP_ETH_WS_URL',
      'REACT_APP_BSC_WS_URL',
      'JWT_SECRET',
      'DATABASE_URL'
    ];

    const missingVars: string[] = [];
    
    for (const varName of criticalVars) {
      if (!process.env[varName]) {
        missingVars.push(varName);
      }
    }

    if (missingVars.length > 0) {
      this.errors = [
        '❌ VARIABLES CRÍTICAS FALTANTES:',
        ...missingVars.map(varName => `   - ${varName}`),
        '',
        '🔧 ACCIONES REQUERIDAS:',
        '   1. Copiar .env.example a .env',
        '   2. Configurar variables críticas',
        '   3. Reiniciar la aplicación'
      ];
      
      return {
        success: false,
        errors: this.errors
      };
    }

    return {
      success: true,
      errors: []
    };
  }

  // Obtener configuración validada
  getConfig(): EnvConfig {
    if (!this.config || Object.keys(this.config).length === 0) {
      throw new Error('Configuración no validada. Llama a validate() primero.');
    }
    return this.config;
  }

  // Verificar si una variable específica está configurada
  hasVariable(varName: keyof EnvConfig): boolean {
    return process.env[varName] !== undefined;
  }

  // Obtener valor de una variable específica
  getVariable(varName: keyof EnvConfig): string | undefined {
    return process.env[varName];
  }

  // Generar reporte de configuración
  generateConfigReport(): string {
    const config = this.getConfig();
    
    let report = '📋 REPORTE DE CONFIGURACIÓN - ARBITRAGEX 2025\n';
    report += '='.repeat(50) + '\n\n';
    
    // Configuración básica
    report += '🔌 CONFIGURACIÓN BÁSICA:\n';
    report += `   NODE_ENV: ${config.NODE_ENV}\n`;
    report += `   PORT: ${config.PORT}\n\n`;
    
    // Blockchains
    report += '⛓️ BLOCKCHAINS CONFIGURADAS:\n';
    report += `   Ethereum: ${this.hasVariable('REACT_APP_ETH_WS_URL') ? '✅' : '❌'}\n`;
    report += `   BSC: ${this.hasVariable('REACT_APP_BSC_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Polygon: ${this.hasVariable('REACT_APP_POLYGON_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Avalanche: ${this.hasVariable('REACT_APP_AVALANCHE_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Fantom: ${this.hasVariable('REACT_APP_FANTOM_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Arbitrum: ${this.hasVariable('REACT_APP_ARBITRUM_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Optimism: ${this.hasVariable('REACT_APP_OPTIMISM_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Polygon zkEVM: ${this.hasVariable('REACT_APP_POLYGON_ZKEVM_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Cronos: ${this.hasVariable('REACT_APP_CRONOS_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Gnosis: ${this.hasVariable('REACT_APP_GNOSIS_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Moonbeam: ${this.hasVariable('REACT_APP_MOONBEAM_WS_URL') ? '✅' : '❌'}\n`;
    report += `   Base: ${this.hasVariable('REACT_APP_BASE_WS_URL') ? '✅' : '❌'}\n\n`;
    
    // APIs externas
    report += '🔑 APIS EXTERNAS:\n';
    report += `   Infura: ${this.hasVariable('REACT_APP_INFURA_PROJECT_ID') ? '✅' : '❌'}\n`;
    report += `   Alchemy: ${this.hasVariable('REACT_APP_ALCHEMY_API_KEY') ? '✅' : '❌'}\n`;
    report += `   GetBlock: ${this.hasVariable('REACT_APP_GETBLOCK_API_KEY') ? '✅' : '❌'}\n`;
    report += `   BlastAPI: ${this.hasVariable('REACT_APP_BLASTAPI_API_KEY') ? '✅' : '❌'}\n\n`;
    
    // Subgrafos
    report += '📊 SUBGRAFOS:\n';
    report += `   The Graph: ${this.hasVariable('REACT_APP_THEGRAPH_API_KEY') ? '✅' : '❌'}\n`;
    report += `   Aave: ${this.hasVariable('REACT_APP_AAVE_SUBGRAPH_URL') ? '✅' : '❌'}\n`;
    report += `   Uniswap: ${this.hasVariable('REACT_APP_UNISWAP_SUBGRAPH_URL') ? '✅' : '❌'}\n\n`;
    
    // Seguridad
    report += '🛡️ SEGURIDAD:\n';
    report += `   JWT Secret: ${this.hasVariable('JWT_SECRET') ? '✅' : '❌'}\n`;
    report += `   Rate Limiting: ${config.RATE_LIMIT_MAX_REQUESTS} req/${config.RATE_LIMIT_WINDOW_MS}ms\n\n`;
    
    // Base de datos
    report += '🗄️ BASE DE DATOS:\n';
    report += `   PostgreSQL: ${this.hasVariable('DATABASE_URL') ? '✅' : '❌'}\n`;
    report += `   Redis: ${this.hasVariable('REDIS_URL') ? '✅' : '❌'}\n`;
    report += `   MongoDB: ${this.hasVariable('MONGODB_URL') ? '✅' : '❌'}\n\n`;
    
    // Cloud services
    report += '☁️ SERVICIOS EN LA NUBE:\n';
    report += `   AWS S3: ${this.hasVariable('AWS_ACCESS_KEY_ID') ? '✅' : '❌'}\n`;
    report += `   Cloudflare: ${this.hasVariable('CLOUDFLARE_API_TOKEN') ? '✅' : '❌'}\n\n`;
    
    // Arbitraje
    report += '💰 CONFIGURACIÓN DE ARBITRAJE:\n';
    report += `   Max Gas Price: ${config.MAX_GAS_PRICE_GWEI} Gwei\n`;
    report += `   Max Slippage: ${config.MAX_SLIPPAGE_PERCENT}%\n`;
    report += `   Min Opportunity: $${config.MIN_OPPORTUNITY_SIZE_USD}\n`;
    report += `   Max Execution Time: ${config.MAX_EXECUTION_TIME_SECONDS}s\n\n`;
    
    return report;
  }
}

// Instancia singleton del validador
export const envValidator = new EnvironmentValidator();

// Función de conveniencia para validación rápida
export function validateEnvironment(): { success: boolean; config?: EnvConfig; errors: string[] } {
  return envValidator.validate();
}

// Función para validación crítica
export function validateCriticalEnvironment(): { success: boolean; errors: string[] } {
  return envValidator.validateCritical();
}

// Función para obtener configuración
export function getEnvironmentConfig(): EnvConfig {
  return envValidator.getConfig();
}

// Función para generar reporte
export function generateEnvironmentReport(): string {
  return envValidator.generateConfigReport();
}