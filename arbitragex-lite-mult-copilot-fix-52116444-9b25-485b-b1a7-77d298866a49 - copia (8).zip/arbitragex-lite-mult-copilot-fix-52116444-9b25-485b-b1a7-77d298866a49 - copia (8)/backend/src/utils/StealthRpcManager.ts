import { Web3 } from 'web3';
import { ethers } from 'ethers';

interface RpcEndpoint {
  url: string;
  chainId: number;
  type: 'public' | 'private' | 'flashbots';
  priority: number;
  health: number;
  lastCheck: number;
  isHealthy: boolean;
}

interface ChainConfig {
  chainId: number;
  name: string;
  publicRpc: string[];
  privateRpc: string[];
  flashbotsRpc: string[];
  blockTime: number;
  maxGasPrice: string;
}

export class StealthRpcManager {
  private endpoints: Map<number, RpcEndpoint[]> = new Map();
  private chainConfigs: Map<number, ChainConfig> = new Map();
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private currentEndpointIndex: Map<number, number> = new Map();

  constructor() {
    this.initializeChainConfigs();
    this.startHealthCheck();
  }

  private initializeChainConfigs(): void {
    // Ethereum Mainnet
    this.chainConfigs.set(1, {
      chainId: 1,
      name: 'Ethereum',
      publicRpc: [
        'https://eth.llamarpc.com',
        'https://rpc.ankr.com/eth',
        'https://ethereum.publicnode.com'
      ],
      privateRpc: [
        'https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY',
        'https://mainnet.infura.io/v3/YOUR_KEY'
      ],
      flashbotsRpc: [
        'https://relay.flashbots.net',
        'https://builder0x69.io',
        'https://rsync-builder.xyz'
      ],
      blockTime: 12,
      maxGasPrice: '100000000000' // 100 gwei
    });

    // BSC
    this.chainConfigs.set(56, {
      chainId: 56,
      name: 'BSC',
      publicRpc: [
        'https://bsc-dataseed1.binance.org',
        'https://bsc-dataseed2.binance.org'
      ],
      privateRpc: [
        'https://bsc-mainnet.nodereal.io/v1/YOUR_KEY'
      ],
      flashbotsRpc: [],
      blockTime: 3,
      maxGasPrice: '5000000000' // 5 gwei
    });

    // Polygon
    this.chainConfigs.set(137, {
      chainId: 137,
      name: 'Polygon',
      publicRpc: [
        'https://polygon-rpc.com',
        'https://rpc-mainnet.matic.network'
      ],
      privateRpc: [
        'https://polygon-mainnet.g.alchemy.com/v2/YOUR_KEY'
      ],
      flashbotsRpc: [],
      blockTime: 2,
      maxGasPrice: '30000000000' // 30 gwei
    });

    // Optimism
    this.chainConfigs.set(10, {
      chainId: 10,
      name: 'Optimism',
      publicRpc: [
        'https://mainnet.optimism.io',
        'https://optimism.publicnode.com'
      ],
      privateRpc: [
        'https://opt-mainnet.g.alchemy.com/v2/YOUR_KEY'
      ],
      flashbotsRpc: [],
      blockTime: 2,
      maxGasPrice: '1000000' // 0.001 gwei
    });

    // Base
    this.chainConfigs.set(8453, {
      chainId: 8453,
      name: 'Base',
      publicRpc: [
        'https://mainnet.base.org',
        'https://base.blockpi.network/v1/rpc/public'
      ],
      privateRpc: [
        'https://base-mainnet.g.alchemy.com/v2/YOUR_KEY'
      ],
      flashbotsRpc: [],
      blockTime: 2,
      maxGasPrice: '1000000' // 0.001 gwei
    });

    // Solana (EVM compatible)
    this.chainConfigs.set(1399811149, {
      chainId: 1399811149,
      name: 'Solana',
      publicRpc: [
        'https://api.mainnet-beta.solana.com',
        'https://solana-api.projectserum.com'
      ],
      privateRpc: [
        'https://solana-mainnet.g.alchemy.com/v2/YOUR_KEY'
      ],
      flashbotsRpc: [],
      blockTime: 0.4,
      maxGasPrice: '1000' // 0.000001 gwei
    });

    // Fantom
    this.chainConfigs.set(250, {
      chainId: 250,
      name: 'Fantom',
      publicRpc: [
        'https://rpc.ftm.tools',
        'https://rpcapi.fantom.network'
      ],
      privateRpc: [],
      flashbotsRpc: [],
      blockTime: 1,
      maxGasPrice: '100000000000' // 100 gwei
    });

    // Cronos
    this.chainConfigs.set(25, {
      chainId: 25,
      name: 'Cronos',
      publicRpc: [
        'https://evm.cronos.org',
        'https://cronos.blockpi.network/v1/rpc/public'
      ],
      privateRpc: [],
      flashbotsRpc: [],
      blockTime: 6,
      maxGasPrice: '5000000000000' // 5000 gwei
    });

    // Harmony
    this.chainConfigs.set(1666600000, {
      chainId: 1666600000,
      name: 'Harmony',
      publicRpc: [
        'https://api.harmony.one',
        'https://a.api.s0.t.hmny.io'
      ],
      privateRpc: [],
      flashbotsRpc: [],
      blockTime: 2,
      maxGasPrice: '1000000000' // 1 gwei
    });

    // Celo
    this.chainConfigs.set(42220, {
      chainId: 42220,
      name: 'Celo',
      publicRpc: [
        'https://forno.celo.org',
        'https://rpc.ankr.com/celo'
      ],
      privateRpc: [],
      flashbotsRpc: [],
      blockTime: 5,
      maxGasPrice: '100000000' // 0.1 gwei
    });
  }

  async addEndpoint(chainId: number, url: string, type: 'public' | 'private' | 'flashbots'): Promise<void> {
    const priority = type === 'flashbots' ? 1 : type === 'private' ? 2 : 3;
    
    const endpoint: RpcEndpoint = {
      url,
      chainId,
      type,
      priority,
      health: 100,
      lastCheck: Date.now(),
      isHealthy: true
    };

    if (!this.endpoints.has(chainId)) {
      this.endpoints.set(chainId, []);
    }

    this.endpoints.get(chainId)!.push(endpoint);
    this.endpoints.get(chainId)!.sort((a, b) => a.priority - b.priority);
  }

  async getOptimalEndpoint(chainId: number, strategy: string): Promise<RpcEndpoint> {
    const chainEndpoints = this.endpoints.get(chainId);
    if (!chainEndpoints || chainEndpoints.length === 0) {
      throw new Error(`No endpoints available for chain ${chainId}`);
    }

    // Filtrar endpoints saludables
    const healthyEndpoints = chainEndpoints.filter(ep => ep.isHealthy);
    if (healthyEndpoints.length === 0) {
      throw new Error(`No healthy endpoints available for chain ${chainId}`);
    }

    // Para estrategias de alto riesgo, priorizar Flashbots
    if (this.isHighRiskStrategy(strategy)) {
      const flashbotsEndpoint = healthyEndpoints.find(ep => ep.type === 'flashbots');
      if (flashbotsEndpoint) {
        return flashbotsEndpoint;
      }
    }

    // Rotación inteligente entre endpoints
    const currentIndex = this.currentEndpointIndex.get(chainId) || 0;
    const selectedEndpoint = healthyEndpoints[currentIndex % healthyEndpoints.length];
    
    // Actualizar índice para próxima selección
    this.currentEndpointIndex.set(chainId, (currentIndex + 1) % healthyEndpoints.length);
    
    return selectedEndpoint;
  }

  private isHighRiskStrategy(strategy: string): boolean {
    const highRiskStrategies = [
      'mev_sandwich',
      'front_running',
      'liquidation_hunting',
      'arbitrage_triangular',
      'arbitrage_cross_dex'
    ];
    return highRiskStrategies.includes(strategy);
  }

  async createWeb3Instance(chainId: number, strategy: string): Promise<Web3> {
    const endpoint = await this.getOptimalEndpoint(chainId, strategy);
    return new Web3(endpoint.url);
  }

  async createEthersProvider(chainId: number, strategy: string): Promise<ethers.JsonRpcProvider> {
    const endpoint = await this.getOptimalEndpoint(chainId, strategy);
    return new ethers.JsonRpcProvider(endpoint.url);
  }

  private async checkEndpointHealth(endpoint: RpcEndpoint): Promise<void> {
    try {
      const web3 = new Web3(endpoint.url);
      const startTime = Date.now();
      
      // Verificar conectividad básica
      const blockNumber = await web3.eth.getBlockNumber();
      const responseTime = Date.now() - startTime;
      
      if (responseTime < 5000) { // Menos de 5 segundos
        endpoint.health = Math.min(100, endpoint.health + 10);
        endpoint.isHealthy = true;
      } else if (responseTime < 10000) { // Entre 5-10 segundos
        endpoint.health = Math.max(0, endpoint.health - 5);
        endpoint.isHealthy = endpoint.health > 50;
      } else { // Más de 10 segundos
        endpoint.health = Math.max(0, endpoint.health - 20);
        endpoint.isHealthy = false;
      }
      
      endpoint.lastCheck = Date.now();
      
    } catch (error) {
      endpoint.health = Math.max(0, endpoint.health - 30);
      endpoint.isHealthy = false;
      endpoint.lastCheck = Date.now();
    }
  }

  private startHealthCheck(): void {
    this.healthCheckInterval = setInterval(async () => {
      for (const [chainId, endpoints] of this.endpoints) {
        for (const endpoint of endpoints) {
          await this.checkEndpointHealth(endpoint);
        }
      }
    }, 30000); // Cada 30 segundos
  }

  async getEndpointStats(chainId: number): Promise<any> {
    const chainEndpoints = this.endpoints.get(chainId);
    if (!chainEndpoints) {
      return { error: 'Chain not found' };
    }

    return {
      chainId,
      totalEndpoints: chainEndpoints.length,
      healthyEndpoints: chainEndpoints.filter(ep => ep.isHealthy).length,
      endpoints: chainEndpoints.map(ep => ({
        url: ep.url,
        type: ep.type,
        priority: ep.priority,
        health: ep.health,
        isHealthy: ep.isHealthy,
        lastCheck: ep.lastCheck
      }))
    };
  }

  async emergencySwitchToPublic(chainId: number): Promise<void> {
    const chainEndpoints = this.endpoints.get(chainId);
    if (!chainEndpoints) return;

    // Marcar todos los endpoints privados/Flashbots como no saludables
    for (const endpoint of chainEndpoints) {
      if (endpoint.type !== 'public') {
        endpoint.isHealthy = false;
        endpoint.health = 0;
      }
    }
  }

  destroy(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
    }
  }
}
