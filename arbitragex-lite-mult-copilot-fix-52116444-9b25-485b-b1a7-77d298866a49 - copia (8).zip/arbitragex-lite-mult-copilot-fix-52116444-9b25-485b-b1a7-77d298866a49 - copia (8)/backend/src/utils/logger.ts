import winston from 'winston';
import path from 'path';
import { config } from '../config';

// Crear directorio de logs si no existe
import fs from 'fs';
const logDir = path.join(process.cwd(), 'logs');
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
}

// Formato personalizado para logs
const logFormat = winston.format.combine(
    winston.format.timestamp({
        format: 'YYYY-MM-DD HH:mm:ss'
    }),
    winston.format.errors({ stack: true }),
    winston.format.json(),
    winston.format.printf(({ timestamp, level, message, stack, ...meta }) => {
        let log = `${timestamp} [${level.toUpperCase()}]: ${message}`;
        
        if (Object.keys(meta).length > 0) {
            log += ` ${JSON.stringify(meta)}`;
        }
        
        if (stack) {
            log += `\n${stack}`;
        }
        
        return log;
    })
);

// Configuración de transportes
const transports: winston.transport[] = [
    // Console transport para desarrollo
    new winston.transports.Console({
        format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
        )
    })
];

// Agregar transportes de archivo en producción
if (config.server.environment === 'production') {
    // Log de errores
    transports.push(
        new winston.transports.File({
            filename: path.join(logDir, 'error.log'),
            level: 'error',
            maxsize: 5242880, // 5MB
            maxFiles: 5,
            format: logFormat
        })
    );

    // Log combinado
    transports.push(
        new winston.transports.File({
            filename: path.join(logDir, 'combined.log'),
            maxsize: 5242880, // 5MB
            maxFiles: 5,
            format: logFormat
        })
    );

    // Log de auditoría de seguridad
    transports.push(
        new winston.transports.File({
            filename: path.join(logDir, 'security.log'),
            level: 'info',
            maxsize: 5242880, // 5MB
            maxFiles: 10,
            format: logFormat
        })
    );

    // Log de transacciones
    transports.push(
        new winston.transports.File({
            filename: path.join(logDir, 'transactions.log'),
            level: 'info',
            maxsize: 10485760, // 10MB
            maxFiles: 10,
            format: logFormat
        })
    );
}

// Crear logger principal
export const logger = winston.createLogger({
    level: config.monitoring.logLevel,
    format: logFormat,
    defaultMeta: {
        service: 'arbitragex-backend',
        version: '2.0.0',
        environment: config.server.environment
    },
    transports,
    exitOnError: false
});

// Logger especializado para seguridad
export const securityLogger = winston.createLogger({
    level: 'info',
    format: logFormat,
    defaultMeta: {
        service: 'arbitragex-security',
        category: 'security'
    },
    transports: [
        new winston.transports.File({
            filename: path.join(logDir, 'security.log'),
            maxsize: 5242880, // 5MB
            maxFiles: 10
        })
    ]
});

// Logger especializado para transacciones
export const transactionLogger = winston.createLogger({
    level: 'info',
    format: logFormat,
    defaultMeta: {
        service: 'arbitragex-transactions',
        category: 'transactions'
    },
    transports: [
        new winston.transports.File({
            filename: path.join(logDir, 'transactions.log'),
            maxsize: 10485760, // 10MB
            maxFiles: 10
        })
    ]
});

// Logger especializado para blockchain
export const blockchainLogger = winston.createLogger({
    level: 'info',
    format: logFormat,
    defaultMeta: {
        service: 'arbitragex-blockchain',
        category: 'blockchain'
    },
    transports: [
        new winston.transports.File({
            filename: path.join(logDir, 'blockchain.log'),
            maxsize: 5242880, // 5MB
            maxFiles: 5
        })
    ]
});

// Logger especializado para estrategias
export const strategyLogger = winston.createLogger({
    level: 'info',
    format: logFormat,
    defaultMeta: {
        service: 'arbitragex-strategies',
        category: 'strategies'
    },
    transports: [
        new winston.transports.File({
            filename: path.join(logDir, 'strategies.log'),
            maxsize: 5242880, // 5MB
            maxFiles: 5
        })
    ]
});

// Funciones de logging especializadas
export const logSecurityEvent = (event: string, details: any, userId?: string, ip?: string) => {
    securityLogger.info('Security Event', {
        event,
        details,
        userId,
        ip,
        timestamp: new Date().toISOString(),
        userAgent: details.userAgent || 'unknown'
    });
};

export const logTransaction = (transaction: any, strategy: string, userId: string) => {
    transactionLogger.info('Transaction Executed', {
        transactionId: transaction.id,
        strategy,
        userId,
        blockchain: transaction.blockchain,
        amount: transaction.amount,
        gasUsed: transaction.gasUsed,
        status: transaction.status,
        timestamp: new Date().toISOString()
    });
};

export const logBlockchainEvent = (event: string, blockchain: string, details: any) => {
    blockchainLogger.info('Blockchain Event', {
        event,
        blockchain,
        details,
        timestamp: new Date().toISOString()
    });
};

export const logStrategyExecution = (strategyId: string, userId: string, result: any) => {
    strategyLogger.info('Strategy Executed', {
        strategyId,
        userId,
        result,
        timestamp: new Date().toISOString()
    });
};

// Middleware para logging de requests HTTP
export const requestLogger = (req: any, res: any, next: any) => {
    const start = Date.now();
    
    res.on('finish', () => {
        const duration = Date.now() - start;
        const logData = {
            method: req.method,
            url: req.originalUrl,
            statusCode: res.statusCode,
            duration: `${duration}ms`,
            ip: req.ip || req.connection.remoteAddress,
            userAgent: req.get('User-Agent'),
            userId: req.user?.id || 'anonymous'
        };

        if (res.statusCode >= 400) {
            logger.warn('HTTP Request', logData);
        } else {
            logger.info('HTTP Request', logData);
        }
    });

    next();
};

// Función para limpiar logs antiguos
export const cleanupOldLogs = () => {
    const maxAge = 30 * 24 * 60 * 60 * 1000; // 30 días
    const logFiles = fs.readdirSync(logDir);
    
    logFiles.forEach(file => {
        const filePath = path.join(logDir, file);
        const stats = fs.statSync(filePath);
        
        if (Date.now() - stats.mtime.getTime() > maxAge) {
            fs.unlinkSync(filePath);
            logger.info(`Log file cleaned up: ${file}`);
        }
    });
};

// Limpiar logs cada día
setInterval(cleanupOldLogs, 24 * 60 * 60 * 1000);

export default logger;
