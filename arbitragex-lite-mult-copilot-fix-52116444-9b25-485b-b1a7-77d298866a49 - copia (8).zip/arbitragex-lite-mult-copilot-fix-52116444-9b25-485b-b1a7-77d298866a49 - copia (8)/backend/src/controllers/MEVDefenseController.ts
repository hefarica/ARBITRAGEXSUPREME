import { Request, Response } from 'express';
import { MEVDefenseService } from '../services/MEVDefenseService';
import { ethers } from 'ethers';
import { ThreatType, ThreatLevel, MEVDefenseConfig } from '../types/mev-defense.types';

export class MEVDefenseController {
  private defenseService: MEVDefenseService;

  constructor() {
    // En producción, esto vendría de configuración
    const provider = new ethers.providers.JsonRpcProvider(process.env.ETHEREUM_RPC_URL || 'http://localhost:8545');
    const privateKey = process.env.DEFENSE_PRIVATE_KEY || '0x0000000000000000000000000000000000000000000000000000000000000000';
    const flashbotsUrl = process.env.FLASHBOTS_URL;

    this.defenseService = new MEVDefenseService(provider, privateKey, flashbotsUrl);
  }

  // Escanear amenazas
  async scanThreats(req: Request, res: Response): Promise<void> {
    try {
      console.log('🔍 Iniciando escaneo de amenazas...');
      
      const threats = await this.defenseService.scanForThreats();
      
      res.json({
        success: true,
        data: {
          threats,
          count: threats.length,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error escaneando amenazas:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Ejecutar respuesta de defensa
  async executeDefense(req: Request, res: Response): Promise<void> {
    try {
      const { threatId, threatType, threatAddress, confidence, evidence } = req.body;

      if (!threatAddress || !threatType) {
        res.status(400).json({
          success: false,
          error: 'Dirección de amenaza y tipo son requeridos'
        });
        return;
      }

      const threat = {
        id: threatId || Date.now().toString(),
        type: threatType,
        address: threatAddress,
        confidence: confidence || 0.8,
        evidence: evidence || {},
        timestamp: Date.now()
      };

      console.log(`🛡️ Ejecutando defensa para amenaza: ${threatType} en ${threatAddress}`);
      
      const response = await this.defenseService.executeDefenseResponse(threat);
      
      res.json({
        success: true,
        data: {
          threat,
          response,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error ejecutando defensa:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Obtener estado del sistema de defensa
  async getDefenseStatus(req: Request, res: Response): Promise<void> {
    try {
      const status = await this.defenseService.getDefenseStatus();
      
      res.json({
        success: true,
        data: status
      });
    } catch (error) {
      console.error('Error obteniendo estado de defensa:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Obtener historial de amenazas
  async getThreatHistory(req: Request, res: Response): Promise<void> {
    try {
      const threats = await this.defenseService.getThreatHistory();
      
      res.json({
        success: true,
        data: {
          threats,
          count: threats.length,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error obteniendo historial de amenazas:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Obtener historial de defensa
  async getDefenseHistory(req: Request, res: Response): Promise<void> {
    try {
      const history = await this.defenseService.getDefenseHistory();
      
      res.json({
        success: true,
        data: {
          history,
          count: history.length,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error obteniendo historial de defensa:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Unirse a coalición
  async joinCoalition(req: Request, res: Response): Promise<void> {
    try {
      const { coalitionId } = req.body;

      if (!coalitionId) {
        res.status(400).json({
          success: false,
          error: 'ID de coalición es requerido'
        });
        return;
      }

      console.log(`🤝 Uniéndose a coalición: ${coalitionId}`);
      
      const success = await this.defenseService.joinCoalition(coalitionId);
      
      res.json({
        success,
        data: {
          coalitionId,
          joined: success,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error uniéndose a coalición:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Reportar amenaza a coalición
  async reportThreatToCoalition(req: Request, res: Response): Promise<void> {
    try {
      const { threat } = req.body;

      if (!threat) {
        res.status(400).json({
          success: false,
          error: 'Datos de amenaza son requeridos'
        });
        return;
      }

      console.log(`📡 Reportando amenaza a coalición: ${threat.type}`);
      
      const success = await this.defenseService.reportThreatToCoalition(threat);
      
      res.json({
        success,
        data: {
          threat,
          reported: success,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error reportando amenaza a coalición:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Actualizar configuración de defensa
  async updateDefenseConfig(req: Request, res: Response): Promise<void> {
    try {
      const config: Partial<MEVDefenseConfig> = req.body;

      if (!config || Object.keys(config).length === 0) {
        res.status(400).json({
          success: false,
          error: 'Configuración es requerida'
        });
        return;
      }

      console.log('⚙️ Actualizando configuración de defensa...');
      
      const success = await this.defenseService.updateDefenseConfig(config);
      
      res.json({
        success,
        data: {
          config,
          updated: success,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error actualizando configuración de defensa:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Activar modo de emergencia
  async activateEmergencyMode(req: Request, res: Response): Promise<void> {
    try {
      const { mode } = req.body;

      if (!mode || !['NUCLEAR_DEFENSE', 'PERSISTENT_THREAT', 'COALITION_WAR'].includes(mode)) {
        res.status(400).json({
          success: false,
          error: 'Modo de emergencia válido es requerido'
        });
        return;
      }

      console.log(`🚨 Activando modo de emergencia: ${mode}`);
      
      const success = await this.defenseService.activateEmergencyMode(mode);
      
      res.json({
        success,
        data: {
          mode,
          activated: success,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error activando modo de emergencia:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Desactivar modo de emergencia
  async deactivateEmergencyMode(req: Request, res: Response): Promise<void> {
    try {
      console.log('🔄 Desactivando modo de emergencia...');
      
      const success = await this.defenseService.deactivateEmergencyMode();
      
      res.json({
        success,
        data: {
          deactivated: success,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error desactivando modo de emergencia:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Ejecutar defensa específica por tipo
  async executeSpecificDefense(req: Request, res: Response): Promise<void> {
    try {
      const { defenseType, targetAddress, params } = req.body;

      if (!defenseType || !targetAddress) {
        res.status(400).json({
          success: false,
          error: 'Tipo de defensa y dirección objetivo son requeridos'
        });
        return;
      }

      console.log(`🎯 Ejecutando defensa específica: ${defenseType} contra ${targetAddress}`);
      
      let success = false;
      let actions: string[] = [];

      switch (defenseType) {
        case 'HONEY_TRAP':
          // En implementación completa, esto llamaría al módulo de honey trap
          actions = ['honey_trap_deployed', 'bait_transaction_sent'];
          success = true;
          break;
        
        case 'REVERSE_SANDWICH':
          // En implementación completa, esto llamaría al módulo de reverse sandwich
          actions = ['reverse_sandwich_executed', 'profit_drained'];
          success = true;
          break;
        
        case 'STRATEGY_POISONING':
          // En implementación completa, esto llamaría al módulo de strategy poisoning
          actions = ['poison_strategy_deployed', 'copycat_trap_set'];
          success = true;
          break;
        
        case 'INFORMATION_WARFARE':
          // En implementación completa, esto llamaría al módulo de information warfare
          actions = ['decoy_transactions_sent', 'temporal_confusion_activated'];
          success = true;
          break;
        
        case 'ECONOMIC_WARFARE':
          // En implementación completa, esto llamaría al módulo de economic warfare
          actions = ['boycott_initiated', 'mev_manipulation_started'];
          success = true;
          break;
        
        default:
          res.status(400).json({
            success: false,
            error: 'Tipo de defensa no soportado'
          });
          return;
      }
      
      res.json({
        success: true,
        data: {
          defenseType,
          targetAddress,
          success,
          actions,
          params,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error ejecutando defensa específica:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  // Obtener estadísticas de defensa
  async getDefenseStats(req: Request, res: Response): Promise<void> {
    try {
      const status = await this.defenseService.getDefenseStatus();
      const threats = await this.defenseService.getThreatHistory();
      const history = await this.defenseService.getDefenseHistory();

      // Calcular estadísticas
      const stats = {
        totalThreats: threats.length,
        activeThreats: status?.activeThreats || 0,
        totalResponses: history.length,
        successfulResponses: history.filter(r => r.success).length,
        responseSuccessRate: history.length > 0 ? 
          (history.filter(r => r.success).length / history.length) * 100 : 0,
        threatsByType: this.groupThreatsByType(threats),
        responsesByLevel: this.groupResponsesByLevel(history),
        averageResponseTime: this.calculateAverageResponseTime(history),
        last24Hours: this.getLast24HoursStats(threats, history)
      };

      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      console.error('Error obteniendo estadísticas de defensa:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        details: error.message
      });
    }
  }

  private groupThreatsByType(threats: any[]): Record<string, number> {
    const grouped: Record<string, number> = {};
    threats.forEach(threat => {
      const type = threat.type || 'UNKNOWN';
      grouped[type] = (grouped[type] || 0) + 1;
    });
    return grouped;
  }

  private groupResponsesByLevel(responses: any[]): Record<string, number> {
    const grouped: Record<string, number> = {};
    responses.forEach(response => {
      const level = response.level || 'UNKNOWN';
      grouped[level] = (grouped[level] || 0) + 1;
    });
    return grouped;
  }

  private calculateAverageResponseTime(responses: any[]): number {
    if (responses.length === 0) return 0;
    const totalTime = responses.reduce((sum, r) => sum + (r.executionTime || 0), 0);
    return totalTime / responses.length;
  }

  private getLast24HoursStats(threats: any[], responses: any[]): any {
    const now = Date.now();
    const oneDayAgo = now - (24 * 60 * 60 * 1000);

    const recentThreats = threats.filter(t => t.timestamp >= oneDayAgo);
    const recentResponses = responses.filter(r => r.timestamp >= oneDayAgo);

    return {
      threats: recentThreats.length,
      responses: recentResponses.length,
      successfulResponses: recentResponses.filter(r => r.success).length
    };
  }
}
