import { Request, Response } from 'express';
import { AdvancedArbitrageEngine } from '../services/AdvancedArbitrageEngine';
import { TokenApprovalService } from '../services/TokenApprovalService';
import { FlashLoanManager } from '../services/FlashLoanManager';
import { DexRegistryService } from '../services/DexRegistryService';

export class AdvancedArbitrageController {
  private arbitrageEngine: AdvancedArbitrageEngine;
  private tokenApproval: TokenApprovalService;
  private flashLoanManager: FlashLoanManager;
  private dexRegistry: DexRegistryService;

  constructor() {
    this.arbitrageEngine = new AdvancedArbitrageEngine();
    this.tokenApproval = new TokenApprovalService();
    this.flashLoanManager = new FlashLoanManager();
    this.dexRegistry = new DexRegistryService();
  }

  // ===== OPORTUNIDADES DE ARBITRAJE =====

  /**
   * GET /api/arbitrage/opportunities
   * Obtiene todas las oportunidades de arbitraje disponibles
   */
  async getOpportunities(req: Request, res: Response): Promise<void> {
    try {
      const { chain, minProfit, maxProfit, limit } = req.query;
      
      let opportunities = this.arbitrageEngine.getOpportunities();
      
      // Filtrar por blockchain si se especifica
      if (chain && typeof chain === 'string') {
        opportunities = opportunities.filter(opp => opp.chain === chain);
      }
      
      // Filtrar por rango de profit si se especifica
      if (minProfit && maxProfit) {
        const min = parseFloat(minProfit as string);
        const max = parseFloat(maxProfit as string);
        opportunities = opportunities.filter(opp => 
          opp.profitPercentage >= min && opp.profitPercentage <= max
        );
      }
      
      // Limitar resultados si se especifica
      if (limit) {
        const limitNum = parseInt(limit as string);
        opportunities = opportunities.slice(0, limitNum);
      }
      
      res.json({
        success: true,
        data: opportunities,
        count: opportunities.length,
        filters: { chain, minProfit, maxProfit, limit },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error getting opportunities:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * GET /api/arbitrage/opportunities/:chain
   * Obtiene oportunidades de arbitraje por blockchain
   */
  async getOpportunitiesByChain(req: Request, res: Response): Promise<void> {
    try {
      const { chain } = req.params;
      const opportunities = this.arbitrageEngine.getOpportunitiesByChain(chain);
      
      res.json({
        success: true,
        data: opportunities,
        count: opportunities.length,
        chain,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error(`Error getting opportunities for ${req.params.chain}:`, error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * POST /api/arbitrage/execute
   * Ejecuta una oportunidad de arbitraje
   */
  async executeOpportunity(req: Request, res: Response): Promise<void> {
    try {
      const {
        opportunityId,
        walletAddress,
        privateKey,
        gasPrice,
        maxFeePerGas,
        maxPriorityFeePerGas,
        slippageTolerance,
        deadline
      } = req.body;

      if (!opportunityId || !walletAddress || !privateKey) {
        res.status(400).json({
          success: false,
          error: 'Faltan campos requeridos: opportunityId, walletAddress, privateKey',
          timestamp: new Date().toISOString()
        });
        return;
      }

      const execution = {
        opportunityId,
        walletAddress,
        privateKey,
        gasPrice: gasPrice || '30',
        maxFeePerGas,
        maxPriorityFeePerGas,
        slippageTolerance: slippageTolerance || 1.0,
        deadline: deadline || Date.now() + 300000 // 5 minutos por defecto
      };

      const result = await this.arbitrageEngine.executeArbitrage(execution);
      
      res.json({
        success: true,
        data: result,
        message: result.success ? 'Arbitraje ejecutado exitosamente' : 'Error ejecutando arbitraje',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error executing arbitrage:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  // ===== SCANNER DE OPORTUNIDADES =====

  /**
   * POST /api/arbitrage/scanner/start
   * Inicia el scanner de oportunidades
   */
  async startScanner(req: Request, res: Response): Promise<void> {
    try {
      const { intervalMs } = req.body;
      const interval = intervalMs || 5000;
      
      this.arbitrageEngine.startOpportunityScanner(interval);
      
      res.json({
        success: true,
        message: `Scanner iniciado con intervalo de ${interval}ms`,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error starting scanner:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * POST /api/arbitrage/scanner/stop
   * Detiene el scanner de oportunidades
   */
  async stopScanner(req: Request, res: Response): Promise<void> {
    try {
      this.arbitrageEngine.stopOpportunityScanner();
      
      res.json({
        success: true,
        message: 'Scanner detenido',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error stopping scanner:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * GET /api/arbitrage/scanner/status
   * Obtiene el estado del scanner
   */
  async getScannerStatus(req: Request, res: Response): Promise<void> {
    try {
      const stats = this.arbitrageEngine.getEngineStats();
      
      res.json({
        success: true,
        data: stats,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error getting scanner status:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  // ===== OPTIMIZACIÓN DE RUTAS =====

  /**
   * POST /api/arbitrage/optimize-route
   * Optimiza rutas de arbitraje
   */
  async optimizeRoute(req: Request, res: Response): Promise<void> {
    try {
      const { chain, tokenIn, tokenOut, amountIn } = req.body;

      if (!chain || !tokenIn || !tokenOut || !amountIn) {
        res.status(400).json({
          success: false,
          error: 'Faltan campos requeridos: chain, tokenIn, tokenOut, amountIn',
          timestamp: new Date().toISOString()
        });
        return;
      }

      const routes = await this.arbitrageEngine.optimizeRoute(chain, tokenIn, tokenOut, amountIn);
      
      res.json({
        success: true,
        data: routes,
        count: routes.length,
        request: { chain, tokenIn, tokenOut, amountIn },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error optimizing route:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  // ===== FLASH LOANS =====

  /**
   * GET /api/arbitrage/flash-loans/pools
   * Obtiene pools de flash loans disponibles
   */
  async getFlashLoanPools(req: Request, res: Response): Promise<void> {
    try {
      const { chain } = req.query;
      
      let pools;
      if (chain && typeof chain === 'string') {
        pools = this.flashLoanManager.getFlashLoanPools(chain);
      } else {
        pools = this.flashLoanManager.getAllFlashLoanPools();
      }
      
      res.json({
        success: true,
        data: pools,
        count: pools.length,
        filter: { chain },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error getting flash loan pools:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * POST /api/arbitrage/flash-loans/check-availability
   * Verifica disponibilidad de flash loans
   */
  async checkFlashLoanAvailability(req: Request, res: Response): Promise<void> {
    try {
      const { tokenAddress, amount, chain } = req.body;

      if (!tokenAddress || !amount || !chain) {
        res.status(400).json({
          success: false,
          error: 'Faltan campos requeridos: tokenAddress, amount, chain',
          timestamp: new Date().toISOString()
        });
        return;
      }

      const availability = this.flashLoanManager.calculateFlashLoanAvailability(
        tokenAddress,
        amount,
        chain
      );
      
      res.json({
        success: true,
        data: availability,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error checking flash loan availability:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * POST /api/arbitrage/flash-loans/execute
   * Ejecuta arbitraje con flash loan
   */
  async executeFlashLoanArbitrage(req: Request, res: Response): Promise<void> {
    try {
      const { opportunityId, privateKey, gasPrice } = req.body;

      if (!opportunityId || !privateKey) {
        res.status(400).json({
          success: false,
          error: 'Faltan campos requeridos: opportunityId, privateKey',
          timestamp: new Date().toISOString()
        });
        return;
      }

      const wallet = new (require('ethers')).Wallet(privateKey);
      const result = await this.flashLoanManager.executeFlashLoanArbitrage(
        opportunityId,
        wallet,
        gasPrice || '30'
      );
      
      res.json({
        success: true,
        data: result,
        message: result.success ? 'Flash loan ejecutado exitosamente' : 'Error ejecutando flash loan',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error executing flash loan arbitrage:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * GET /api/arbitrage/flash-loans/opportunities
   * Obtiene oportunidades de arbitraje con flash loans
   */
  async getFlashLoanOpportunities(req: Request, res: Response): Promise<void> {
    try {
      const { chain, minProfit } = req.query;
      const chainStr = chain as string || 'ethereum';
      const minProfitNum = minProfit ? parseFloat(minProfit as string) : 0.5;

      const opportunities = await this.flashLoanManager.detectFlashLoanArbitrageOpportunities(
        chainStr,
        minProfitNum
      );
      
      res.json({
        success: true,
        data: opportunities,
        count: opportunities.length,
        filters: { chain: chainStr, minProfit: minProfitNum },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error getting flash loan opportunities:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  // ===== APROBACIÓN DE TOKENS =====

  /**
   * POST /api/arbitrage/tokens/check-allowance
   * Verifica el allowance de un token
   */
  async checkTokenAllowance(req: Request, res: Response): Promise<void> {
    try {
      const { chain, tokenAddress, ownerAddress, spenderAddress } = req.body;

      if (!chain || !tokenAddress || !ownerAddress || !spenderAddress) {
        res.status(400).json({
          success: false,
          error: 'Faltan campos requeridos: chain, tokenAddress, ownerAddress, spenderAddress',
          timestamp: new Date().toISOString()
        });
        return;
      }

      const allowance = await this.tokenApproval.checkAllowance(
        chain,
        tokenAddress,
        ownerAddress,
        spenderAddress
      );
      
      res.json({
        success: true,
        data: { allowance },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error checking token allowance:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * POST /api/arbitrage/tokens/approve
   * Aprueba un token para un spender
   */
  async approveToken(req: Request, res: Response): Promise<void> {
    try {
      const {
        chain,
        tokenAddress,
        spenderAddress,
        amount,
        privateKey,
        gasPrice,
        maxFeePerGas,
        maxPriorityFeePerGas
      } = req.body;

      if (!chain || !tokenAddress || !spenderAddress || !amount || !privateKey) {
        res.status(400).json({
          success: false,
          error: 'Faltan campos requeridos: chain, tokenAddress, spenderAddress, amount, privateKey',
          timestamp: new Date().toISOString()
        });
        return;
      }

      const wallet = new (require('ethers')).Wallet(privateKey);
      const approvalRequest = {
        tokenAddress,
        spenderAddress,
        amount,
        gasPrice,
        maxFeePerGas,
        maxPriorityFeePerGas
      };

      const result = await this.tokenApproval.approveToken(chain, approvalRequest, wallet);
      
      res.json({
        success: true,
        data: result,
        message: result.success ? 'Token aprobado exitosamente' : 'Error aprobando token',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error approving token:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  // ===== ESTADÍSTICAS Y MÉTRICAS =====

  /**
   * GET /api/arbitrage/stats
   * Obtiene estadísticas generales del sistema
   */
  async getArbitrageStats(req: Request, res: Response): Promise<void> {
    try {
      const engineStats = this.arbitrageEngine.getEngineStats();
      const flashLoanStats = this.flashLoanManager.getFlashLoanStats();
      const dexStats = this.dexRegistry.getDexStats();
      
      const stats = {
        engine: engineStats,
        flashLoans: flashLoanStats,
        dexes: dexStats,
        summary: {
          totalOpportunities: engineStats.totalOpportunities,
          totalDexes: dexStats.totalDexes,
          totalFlashLoanPools: flashLoanStats.totalPools,
          isScanning: engineStats.isScanning
        }
      };
      
      res.json({
        success: true,
        data: stats,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error getting arbitrage stats:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * GET /api/arbitrage/history
   * Obtiene historial de arbitrajes
   */
  async getArbitrageHistory(req: Request, res: Response): Promise<void> {
    try {
      const { limit, type } = req.query;
      const limitNum = limit ? parseInt(limit as string) : 100;
      
      let history;
      if (type === 'flash-loan') {
        history = this.flashLoanManager.getFlashLoanHistory(limitNum);
      } else {
        history = this.arbitrageEngine.getOpportunityHistory(limitNum);
      }
      
      res.json({
        success: true,
        data: history,
        count: history.length,
        type: type || 'regular',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error getting arbitrage history:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  // ===== CONFIGURACIÓN DE DEXs =====

  /**
   * GET /api/arbitrage/dexes
   * Obtiene lista de DEXs configurados
   */
  async getDexes(req: Request, res: Response): Promise<void> {
    try {
      const { chain, onlyEnabled } = req.query;
      
      let dexes;
      if (chain && typeof chain === 'string') {
        dexes = this.dexRegistry.listDexes(chain, { 
          onlyEnabled: onlyEnabled === 'true',
          includeMetrics: true 
        });
      } else {
        // Obtener DEXs de todas las blockchains
        const allChains = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism', 'avalanche'];
        dexes = [];
        
        for (const chainName of allChains) {
          const chainDexes = this.dexRegistry.listDexes(chainName, { 
            onlyEnabled: onlyEnabled === 'true',
            includeMetrics: true 
          });
          dexes.push(...chainDexes.map(dex => ({ ...dex, chain: chainName })));
        }
      }
      
      res.json({
        success: true,
        data: dexes,
        count: dexes.length,
        filters: { chain, onlyEnabled },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error getting dexes:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * POST /api/arbitrage/dexes/toggle
   * Habilita/deshabilita un DEX
   */
  async toggleDex(req: Request, res: Response): Promise<void> {
    try {
      const { chain, dexId, enabled, note } = req.body;

      if (!chain || !dexId || enabled === undefined) {
        res.status(400).json({
          success: false,
          error: 'Faltan campos requeridos: chain, dexId, enabled',
          timestamp: new Date().toISOString()
        });
        return;
      }

      const result = this.dexRegistry.setDexEnabled(chain, dexId, enabled, note);
      
      if (result.ok) {
        res.json({
          success: true,
          data: result,
          message: `DEX ${dexId} en ${chain} ${enabled ? 'habilitado' : 'deshabilitado'} exitosamente`,
          timestamp: new Date().toISOString()
        });
      } else {
        res.status(400).json({
          success: false,
          error: result.error,
          timestamp: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error('Error toggling dex:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
        timestamp: new Date().toISOString()
      });
    }
  }
}

export default new AdvancedArbitrageController();
