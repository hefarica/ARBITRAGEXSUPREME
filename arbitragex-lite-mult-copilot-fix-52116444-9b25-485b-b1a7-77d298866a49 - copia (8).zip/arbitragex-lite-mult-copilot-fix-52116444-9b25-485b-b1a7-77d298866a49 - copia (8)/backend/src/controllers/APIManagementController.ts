import { Request, Response } from 'express';
import { APIManagementService, APIConfig, APIStatus } from '../services/APIManagementService';
import { logger } from '../utils/logger';

export class APIManagementController {
    private apiService: APIManagementService;

    constructor() {
        this.apiService = new APIManagementService();
    }

    /**
     * Obtener la configuración actual de todas las APIs
     */
    public async getAPIConfig(req: Request, res: Response): Promise<void> {
        try {
            const config = this.apiService.getConfig();
            
            // Ocultar las claves API por seguridad
            const safeConfig = {
                coingecko: {
                    apiKey: config.coingecko.apiKey ? '***' + config.coingecko.apiKey.slice(-4) : '',
                    baseUrl: config.coingecko.baseUrl,
                    isPro: config.coingecko.isPro
                },
                dexscreener: {
                    apiKey: config.dexscreener.apiKey ? '***' + config.dexscreener.apiKey.slice(-4) : '',
                    baseUrl: config.dexscreener.baseUrl
                },
                ethereum: {
                    rpcUrl: config.ethereum.rpcUrl ? '***' + config.ethereum.rpcUrl.slice(-20) : '',
                    isConfigured: !!config.ethereum.rpcUrl
                },
                polygon: {
                    rpcUrl: config.polygon.rpcUrl ? '***' + config.polygon.rpcUrl.slice(-20) : '',
                    isConfigured: !!config.polygon.rpcUrl
                },
                etherscan: {
                    apiKey: config.etherscan.apiKey ? '***' + config.etherscan.apiKey.slice(-4) : '',
                    baseUrl: config.etherscan.baseUrl
                },
                uniswap: {
                    subgraphKey: config.uniswap.subgraphKey ? '***' + config.uniswap.subgraphKey.slice(-4) : '',
                    baseUrl: config.uniswap.baseUrl
                },
                aave: {
                    apiKey: config.aave.apiKey ? '***' + config.aave.apiKey.slice(-4) : '',
                    baseUrl: config.aave.baseUrl
                }
            };

            res.json({
                success: true,
                data: safeConfig,
                message: 'Configuración de APIs obtenida exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting API config:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Actualizar la configuración de las APIs
     */
    public async updateAPIConfig(req: Request, res: Response): Promise<void> {
        try {
            const { coingecko, dexscreener, ethereum, polygon, etherscan, uniswap, aave } = req.body;

            const newConfig: Partial<APIConfig> = {};

            if (coingecko) {
                newConfig.coingecko = {
                    apiKey: coingecko.apiKey || '',
                    baseUrl: coingecko.baseUrl || 'https://api.coingecko.com/api/v3',
                    isPro: coingecko.isPro || false
                };
            }

            if (dexscreener) {
                newConfig.dexscreener = {
                    apiKey: dexscreener.apiKey || '',
                    baseUrl: dexscreener.baseUrl || 'https://api.dexscreener.com/latest'
                };
            }

            if (ethereum) {
                newConfig.ethereum = {
                    rpcUrl: ethereum.rpcUrl || '',
                    provider: null
                };
            }

            if (polygon) {
                newConfig.polygon = {
                    rpcUrl: polygon.rpcUrl || '',
                    provider: null
                };
            }

            if (etherscan) {
                newConfig.etherscan = {
                    apiKey: etherscan.apiKey || '',
                    baseUrl: etherscan.baseUrl || 'https://api.etherscan.io/api'
                };
            }

            if (uniswap) {
                newConfig.uniswap = {
                    subgraphKey: uniswap.subgraphKey || '',
                    baseUrl: uniswap.baseUrl || 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3'
                };
            }

            if (aave) {
                newConfig.aave = {
                    apiKey: aave.apiKey || '',
                    baseUrl: aave.baseUrl || 'https://api.aave.com'
                };
            }

            await this.apiService.updateConfig(newConfig);

            res.json({
                success: true,
                message: 'Configuración de APIs actualizada exitosamente'
            });

        } catch (error: any) {
            logger.error('Error updating API config:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Probar una API específica
     */
    public async testSingleAPI(req: Request, res: Response): Promise<void> {
        try {
            const { service } = req.params;

            let status: APIStatus;

            switch (service.toLowerCase()) {
                case 'coingecko':
                    status = await this.apiService.testCoinGeckoAPI();
                    break;
                case 'dexscreener':
                    status = await this.apiService.testDexScreenerAPI();
                    break;
                case 'ethereum':
                    status = await this.apiService.testEthereumRPC();
                    break;
                case 'polygon':
                    status = await this.apiService.testPolygonRPC();
                    break;
                case 'etherscan':
                    status = await this.apiService.testEtherscanAPI();
                    break;
                case 'uniswap':
                    status = await this.apiService.testUniswapSubgraph();
                    break;
                case 'aave':
                    status = await this.apiService.testAaveAPI();
                    break;
                default:
                    res.status(400).json({
                        success: false,
                        error: 'Servicio no válido',
                        message: `Servicio '${service}' no reconocido`
                    });
                    return;
            }

            res.json({
                success: true,
                data: status,
                message: `API ${service} probada exitosamente`
            });

        } catch (error: any) {
            logger.error(`Error testing API ${req.params.service}:`, error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Probar todas las APIs
     */
    public async testAllAPIs(req: Request, res: Response): Promise<void> {
        try {
            const statuses = await this.apiService.testAllAPIs();
            
            const statusArray = Array.from(statuses.values());

            res.json({
                success: true,
                data: statusArray,
                message: 'Todas las APIs probadas exitosamente',
                summary: {
                    total: statusArray.length,
                    connected: statusArray.filter(s => s.status === 'connected').length,
                    error: statusArray.filter(s => s.status === 'error').length,
                    disconnected: statusArray.filter(s => s.status === 'disconnected').length
                }
            });

        } catch (error: any) {
            logger.error('Error testing all APIs:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener el estado de todas las APIs
     */
    public async getAPIStatuses(req: Request, res: Response): Promise<void> {
        try {
            const statuses = this.apiService.getAPIStatuses();
            const statusArray = Array.from(statuses.values());

            res.json({
                success: true,
                data: statusArray,
                message: 'Estados de APIs obtenidos exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting API statuses:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener el estado de una API específica
     */
    public async getAPIStatus(req: Request, res: Response): Promise<void> {
        try {
            const { service } = req.params;
            const status = this.apiService.getAPIStatus(service);

            if (!status) {
                res.status(404).json({
                    success: false,
                    error: 'API no encontrada',
                    message: `Estado de API '${service}' no encontrado`
                });
                return;
            }

            res.json({
                success: true,
                data: status,
                message: `Estado de API ${service} obtenido exitosamente`
            });

        } catch (error: any) {
            logger.error(`Error getting API status ${req.params.service}:`, error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener precios de CoinGecko
     */
    public async getCoinGeckoPrices(req: Request, res: Response): Promise<void> {
        try {
            const { coins } = req.query;
            
            if (!coins || typeof coins !== 'string') {
                res.status(400).json({
                    success: false,
                    error: 'Parámetros inválidos',
                    message: 'Se requiere el parámetro "coins" como string separado por comas'
                });
                return;
            }

            const coinList = coins.split(',').map(c => c.trim());
            const prices = await this.apiService.getCoinGeckoPrices(coinList);

            res.json({
                success: true,
                data: prices,
                message: 'Precios obtenidos exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting CoinGecko prices:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener datos de DexScreener
     */
    public async getDexScreenerData(req: Request, res: Response): Promise<void> {
        try {
            const { pair } = req.params;
            
            if (!pair) {
                res.status(400).json({
                    success: false,
                    error: 'Parámetros inválidos',
                    message: 'Se requiere el parámetro "pair"'
                });
                return;
            }

            const data = await this.apiService.getDexScreenerData(pair);

            res.json({
                success: true,
                data: data,
                message: 'Datos de DexScreener obtenidos exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting DexScreener data:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener precio de gas de Ethereum
     */
    public async getEthereumGasPrice(req: Request, res: Response): Promise<void> {
        try {
            const gasData = await this.apiService.getEthereumGasPrice();

            res.json({
                success: true,
                data: gasData,
                message: 'Precio de gas de Ethereum obtenido exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting Ethereum gas price:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener precio de gas de Polygon
     */
    public async getPolygonGasPrice(req: Request, res: Response): Promise<void> {
        try {
            const gasData = await this.apiService.getPolygonGasPrice();

            res.json({
                success: true,
                data: gasData,
                message: 'Precio de gas de Polygon obtenido exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting Polygon gas price:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener datos de transacción de Etherscan
     */
    public async getEtherscanTransaction(req: Request, res: Response): Promise<void> {
        try {
            const { txHash } = req.params;
            
            if (!txHash) {
                res.status(400).json({
                    success: false,
                    error: 'Parámetros inválidos',
                    message: 'Se requiere el parámetro "txHash"'
                });
                return;
            }

            const txData = await this.apiService.getEtherscanTransaction(txHash);

            res.json({
                success: true,
                data: txData,
                message: 'Datos de transacción obtenidos exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting Etherscan transaction:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener datos de pool de Uniswap
     */
    public async getUniswapPoolData(req: Request, res: Response): Promise<void> {
        try {
            const { poolAddress } = req.params;
            
            if (!poolAddress) {
                res.status(400).json({
                    success: false,
                    error: 'Parámetros inválidos',
                    message: 'Se requiere el parámetro "poolAddress"'
                });
                return;
            }

            const poolData = await this.apiService.getUniswapPoolData(poolAddress);

            res.json({
                success: true,
                data: poolData,
                message: 'Datos de pool de Uniswap obtenidos exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting Uniswap pool data:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Obtener datos de reserva de Aave
     */
    public async getAaveReserveData(req: Request, res: Response): Promise<void> {
        try {
            const { asset } = req.params;
            
            if (!asset) {
                res.status(400).json({
                    success: false,
                    error: 'Parámetros inválidos',
                    message: 'Se requiere el parámetro "asset"'
                });
                return;
            }

            const reserveData = await this.apiService.getAaveReserveData(asset);

            res.json({
                success: true,
                data: reserveData,
                message: 'Datos de reserva de Aave obtenidos exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting Aave reserve data:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Inicializar el servicio de APIs
     */
    public async initializeAPIService(req: Request, res: Response): Promise<void> {
        try {
            await this.apiService.initialize();

            res.json({
                success: true,
                message: 'Servicio de APIs inicializado exitosamente'
            });

        } catch (error: any) {
            logger.error('Error initializing API service:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }

    /**
     * Verificar el estado de inicialización
     */
    public async getInitializationStatus(req: Request, res: Response): Promise<void> {
        try {
            const isInitialized = this.apiService.isInitialized();

            res.json({
                success: true,
                data: { isInitialized },
                message: 'Estado de inicialización obtenido exitosamente'
            });

        } catch (error: any) {
            logger.error('Error getting initialization status:', error);
            res.status(500).json({
                success: false,
                error: 'Error interno del servidor',
                message: error.message
            });
        }
    }
}
