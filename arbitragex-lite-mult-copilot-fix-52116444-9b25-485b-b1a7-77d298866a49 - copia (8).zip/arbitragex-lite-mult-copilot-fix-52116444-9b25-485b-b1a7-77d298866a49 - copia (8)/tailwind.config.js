/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./public/**/*.html",
    "./public/**/*.js",
    "./src/**/*.{html,js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        // Colores de los hubs
        'cfg': '#1e88e5',      // Configuración - Azul
        'mon': '#43a047',      // Monitoreo - Verde
        'exe': '#fbc02d',      // Ejecución - Amarillo
        'txn': '#fb8c00',      // Transacciones - Naranja
        'his': '#8e24aa',      // Historiales - Púrpura
        'con': '#e53935',      // Conectividad - Rojo
        'def': '#ff6b35',      // Defensa MEV - Naranja
      },
      fontFamily: {
        'inter': ['Inter', 'sans-serif'],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
      },
      boxShadow: {
        'glow': '0 0 20px rgba(59, 130, 246, 0.5)',
        'subtle': '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
      }
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
  ],
}