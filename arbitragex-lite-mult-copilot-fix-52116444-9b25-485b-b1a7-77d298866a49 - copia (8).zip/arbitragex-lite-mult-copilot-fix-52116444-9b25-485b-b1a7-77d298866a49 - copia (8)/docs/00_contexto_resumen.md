# 00_contexto_resumen

Este documento resume los requisitos y decisiones: 41 estrategias, árbol de decisión (DecisionTree + RandomForest), Hunter Mode (gate/sizing/coverage/mode) y multi-chain total.
