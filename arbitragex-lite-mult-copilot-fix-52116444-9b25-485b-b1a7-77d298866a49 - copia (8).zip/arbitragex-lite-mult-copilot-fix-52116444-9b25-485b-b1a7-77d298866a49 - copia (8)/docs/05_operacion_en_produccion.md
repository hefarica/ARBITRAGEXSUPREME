# 05_operacion_en_produccion

- Re-train programado, validaciones offline, canary.
- Observabilidad: PnL, acierto, gas real, latencia, colas bundles.
- Seguridad de claves y uso responsable de MEV.
