# Integración MCP + Figma para ArbitrageX

## 🎨 Descripción
Este sistema permite integrar Figma con tu proyecto ArbitrageX usando un servidor MCP (Model Context Protocol) personalizado. Conecta directamente con la API de Figma para sincronizar assets, componentes y diseños.

## ✨ Características
- ✅ **Conexión directa** con la API oficial de Figma
- ✅ **Descarga automática** de assets en múltiples formatos
- ✅ **Sincronización completa** de componentes y diseños
- ✅ **Interfaz web integrada** con React
- ✅ **Gestión segura** de tokens de acceso
- ✅ **Servidor MCP personalizado** para máxima flexibilidad
- ✅ **Soporte multi-formato**: PNG, JPG, SVG, PDF
- ✅ **Escalado automático**: 1x, 2x, 3x, 4x

## 🚀 Instalación y Configuración

### 1. Dependencias
```bash
npm install figma-api
```

### 2. Obtener Access Token de Figma
1. Ve a [Figma Settings](https://www.figma.com/settings)
2. Navega a "Personal access tokens"
3. Crea un nuevo token con permisos de lectura
4. Copia el token generado

### 3. Configurar Variables de Entorno
Edita el archivo `figma.env`:
```env
FIGMA_ACCESS_TOKEN=figd_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
FIGMA_TEAM_ID=tu_team_id_aqui
MCP_FIGMA_SERVER_PORT=3001
FIGMA_ASSETS_DIR=frontend/images/figma-assets
FIGMA_EXPORT_FORMAT=png
FIGMA_EXPORT_SCALE=2
```

### 4. Iniciar Servidor MCP
```bash
# Iniciar servidor
node start-mcp-figma.js

# O probar la integración
node test-figma-integration.js
```

## 📁 Estructura de Archivos

```
src/
├── mcp/
│   └── FigmaMCPServer.ts         # Servidor MCP personalizado
├── services/
│   └── FigmaAssetService.ts      # Servicio de Figma
├── controllers/
│   └── FigmaMCPController.ts     # Controlador MCP
├── routes/
│   └── figma.routes.ts           # Rutas API REST
└── components/
    └── figma/
        └── FigmaIntegrationPanel.tsx  # Panel de integración React

# Archivos de configuración
figma.env                          # Variables de entorno
start-mcp-figma.js                 # Script de inicio
test-figma-integration.js          # Script de pruebas
```

## 🔌 API Endpoints

### Información del Archivo
```http
GET /api/figma/file/:fileId
Authorization: Bearer {token}
```

### Listar Componentes
```http
GET /api/figma/components/:fileId
Authorization: Bearer {token}
```

### Obtener Assets
```http
POST /api/figma/assets
Content-Type: application/json
Authorization: Bearer {token}

{
  "fileId": "abc123",
  "nodeIds": ["node1", "node2"],
  "format": "png",
  "scale": 2
}
```

### Sincronizar Todo
```http
POST /api/figma/sync
Content-Type: application/json
Authorization: Bearer {token}

{
  "fileId": "abc123",
  "outputDir": "frontend/images/figma-assets"
}
```

### Buscar Componentes
```http
GET /api/figma/search/:fileId?q=button
Authorization: Bearer {token}
```

### Estadísticas del Archivo
```http
GET /api/figma/stats/:fileId
Authorization: Bearer {token}
```

## 🎯 Uso en React

### Importar Componente
```tsx
import { FigmaIntegrationPanel } from './components/figma/FigmaIntegrationPanel';

// En tu aplicación
function App() {
  return (
    <div>
      <h1>ArbitrageX + Figma</h1>
      <FigmaIntegrationPanel />
    </div>
  );
}
```

### Características del Panel
- **Configuración de tokens** con almacenamiento local
- **Gestión de archivos** de Figma
- **Selección de componentes** con búsqueda
- **Configuración de exportación** (formato, escala)
- **Descarga individual** de assets
- **Sincronización automática** completa
- **Interfaz responsive** y moderna

## 🔧 Servidor MCP Personalizado

### Clase FigmaMCPServer
```typescript
const server = new FigmaMCPServer({
  accessToken: 'tu_token',
  port: 3001,
  assetsDir: 'frontend/images/figma-assets'
});

// Iniciar servidor
await server.start();

// Obtener información de archivo
const fileInfo = await server.getFileInfo('file_id');

// Sincronizar assets
const result = await server.syncAssets('file_id');
```

### Métodos Disponibles
- `start()` - Inicia el servidor MCP
- `stop()` - Detiene el servidor
- `getFileInfo(fileId)` - Información del archivo
- `getComponents(fileId)` - Lista de componentes
- `getAssets(fileId, nodeIds, format, scale)` - Obtiene assets
- `downloadAsset(asset, outputPath)` - Descarga asset individual
- `syncAssets(fileId)` - Sincronización completa
- `searchComponents(fileId, searchTerm)` - Búsqueda de componentes
- `getFileStats(fileId)` - Estadísticas del archivo

## 📊 Ejemplos de Uso

### Sincronizar Assets de un Diseño
```typescript
import { FigmaMCPServer } from './src/mcp/FigmaMCPServer';

async function syncDesignAssets() {
  const server = new FigmaMCPServer({
    accessToken: process.env.FIGMA_ACCESS_TOKEN,
    assetsDir: 'frontend/images/design-system'
  });
  
  try {
    // Sincronizar assets del archivo
    const result = await server.syncAssets('abc123');
    
    if (result.success) {
      console.log(`✅ ${result.assetsCount} assets sincronizados`);
    } else {
      console.error('❌ Error:', result.message);
    }
  } catch (error) {
    console.error('Error:', error);
  }
}
```

### Obtener Componentes Específicos
```typescript
async function getButtonComponents() {
  const components = await server.getComponents('abc123');
  const buttons = components.filter(c => c.name.includes('Button'));
  
  // Obtener assets de los botones
  const nodeIds = buttons.map(b => b.id);
  const assets = await server.getAssets('abc123', nodeIds, 'svg', 1);
  
  return assets;
}
```

## 🧪 Pruebas

### Script de Prueba
```bash
node test-figma-integration.js
```

### Verificaciones Automáticas
- ✅ Configuración de variables de entorno
- ✅ Creación de instancia del servidor
- ✅ Inicio y parada del servidor
- ✅ Métodos básicos de Figma
- ✅ Gestión de directorios

## 🚨 Solución de Problemas

### Error: "Access Token inválido"
```bash
# Verificar token en figma.env
FIGMA_ACCESS_TOKEN=figd_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Regenerar token en Figma si es necesario
```

### Error: "File ID no encontrado"
- Verifica que el File ID sea correcto
- Asegúrate de que tengas acceso al archivo
- El File ID está en la URL de Figma: `figma.com/file/abc123/...`

### Error: "Servidor MCP no responde"
```bash
# Verificar que el servidor esté ejecutándose
node start-mcp-figma.js

# Verificar puerto en figma.env
MCP_FIGMA_SERVER_PORT=3001
```

### Error: "Directorio de assets no existe"
```bash
# El servidor crea automáticamente el directorio
# Verificar configuración en figma.env
FIGMA_ASSETS_DIR=frontend/images/figma-assets
```

## 🔒 Seguridad

### Tokens de Acceso
- **Nunca** commits tokens en Git
- Usa archivos `.env` locales
- Regenera tokens regularmente
- Permisos mínimos necesarios

### Variables de Entorno
```bash
# .gitignore
.env
.env.figma
figma.env
```

## 📈 Monitoreo y Logs

### Logs del Servidor
```bash
# Iniciar con logs detallados
NODE_ENV=development node start-mcp-figma.js
```

### Métricas Disponibles
- Número de componentes por archivo
- Assets descargados por sesión
- Tiempo de sincronización
- Errores y reintentos

## 🔄 Actualizaciones y Mantenimiento

### Actualizar Dependencias
```bash
npm update figma-api
```

### Verificar API de Figma
- [Figma API Documentation](https://www.figma.com/developers/api)
- [Changelog de la API](https://www.figma.com/developers/api#changelog)

## 🤝 Contribución

### Reportar Issues
1. Verifica la documentación
2. Revisa logs del servidor
3. Proporciona ejemplos de reproducción
4. Incluye información del entorno

### Mejoras Sugeridas
- Soporte para más formatos de exportación
- Integración con sistemas de CI/CD
- Cache de assets para mejor rendimiento
- Sincronización automática programada

## 📚 Recursos Adicionales

### Documentación Oficial
- [Figma API](https://www.figma.com/developers/api)
- [Figma Design Tokens](https://www.figma.com/developers/design-tokens)
- [Figma Plugin API](https://www.figma.com/plugin-docs/)

### Comunidad
- [Figma Community](https://www.figma.com/community)
- [Figma Developers Forum](https://forum.figma.com/)

## 📄 Licencia
Este código es parte del proyecto ArbitrageX y sigue la misma licencia.

---

**¡Tu proyecto ArbitrageX ahora tiene integración completa con Figma usando MCP! 🎉**
