# 02_datasets_y_features

Esquema mínimo (CSV):
- roi_net_pct, gas_fee_usd, latency_ms, vol_5m, vol_15m, vol_1h, liquidity_usd, competition, success_hist, chain (o chain_id)

Recomendado: añadir ATR/σ (ta-lib/ta), spreads, slippage simulado, colas mempool.
