# 01_superruta_implementacion

1. **Config**: cargar `STRATEGIES_41` con `ALL_CHAINS`.
2. **Engine**: invocar `scanAndHuntOnce` o tu loop concurrente.
3. **FastAPI**: iniciar servicio, `/train` con tu dataset, luego `/decide`, `/rank`, `/tick`.
4. **Frontend**: filtros por rubros y ranking en vivo (usar `/rank` y `/rank/full`).
5. **Operación**: tareas de reentrenamiento, métricas, circuit breakers.
