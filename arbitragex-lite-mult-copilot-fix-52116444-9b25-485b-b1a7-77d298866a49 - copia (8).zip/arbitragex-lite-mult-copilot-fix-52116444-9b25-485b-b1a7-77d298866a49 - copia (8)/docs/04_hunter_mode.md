# 04_hunter_mode

- Gate: net > gas * 1.8 && successProb * net >= gas * 0.8
- Sizing: penalización por volatilidad, bonus por successProb.
- Modes: cascade / parallel / single
- Cobertura: 10–25% del neto.
