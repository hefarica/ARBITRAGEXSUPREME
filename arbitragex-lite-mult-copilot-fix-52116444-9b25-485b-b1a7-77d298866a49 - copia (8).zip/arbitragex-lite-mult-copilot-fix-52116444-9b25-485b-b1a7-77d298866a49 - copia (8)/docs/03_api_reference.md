# 03_api_reference

## /status
## /train
## /decide
## /rank
## /rank/full
## /tick

Ejemplos cURL en README_FASTAPI.md del servicio.
