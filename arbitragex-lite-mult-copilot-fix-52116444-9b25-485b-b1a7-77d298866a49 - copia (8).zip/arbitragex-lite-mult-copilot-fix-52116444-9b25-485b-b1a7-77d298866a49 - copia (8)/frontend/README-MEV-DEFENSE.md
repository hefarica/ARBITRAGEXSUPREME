# 🛡️ MEV DEFENSE SYSTEM - Frontend

## Descripción General

El Sistema de Defensa MEV del Frontend es la interfaz de usuario completa para el "SISTEMA DE DEFENSA ACTIVA Y CONTRAATAQUE MEV" de ArbitrageX Pro. Este sistema proporciona una interfaz intuitiva y poderosa para monitorear, gestionar y ejecutar contramedidas defensivas contra ataques MEV.

## 🚀 Características Principales

### 1. **Panel de Control Central**
- Dashboard en tiempo real del estado del sistema
- Métricas de amenazas activas y respuestas ejecutadas
- Indicadores visuales de estado del sistema

### 2. **Detección Automática de Amenazas**
- Escaneo continuo de patrones de ataque
- Clasificación automática de amenazas por tipo y nivel
- Alertas en tiempo real para amenazas críticas

### 3. **Sistema de Respuesta Automática**
- Ejecución automática de contramedidas según el nivel de amenaza
- Escalación automática de respuestas
- Modos de emergencia configurables

### 4. **Gestión de Coaliciones**
- Red de defensa coordinada entre múltiples "hunters"
- Compartir inteligencia de amenazas
- Ataques coordinados contra amenazas persistentes

### 5. **Modos de Emergencia**
- **NUCLEAR_DEFENSE**: Respuesta máxima contra amenazas críticas
- **PERSISTENT_THREAT**: Modo de amenaza persistente
- **COALITION_WAR**: Guerra coordinada contra amenazas masivas

## 🏗️ Arquitectura del Frontend

### Archivos Principales

```
frontend/
├── mev-defense.html          # Página principal del sistema de defensa
├── js/
│   └── mev-defense.js        # Lógica principal del sistema de defensa
├── css/
│   └── mev-defense.css       # Estilos personalizados
├── config/
│   └── mev-defense-config.json # Configuración del frontend
└── README-MEV-DEFENSE.md     # Este archivo
```

### Integración con el Dashboard Principal

- **Sidebar**: Enlace directo al sistema de defensa
- **Métricas**: Tarjeta de estado del sistema de defensa
- **Sección de Estado**: Panel completo de monitoreo
- **Navegación**: Acceso rápido desde cualquier parte del dashboard

## 🎯 Funcionalidades Implementadas

### 1. **Monitoreo en Tiempo Real**
- Estado del sistema de defensa
- Contador de amenazas activas
- Modo de emergencia actual
- Historial de respuestas ejecutadas

### 2. **Controles de Defensa**
- Botón de escaneo manual de amenazas
- Prueba del sistema de defensa
- Activación/desactivación de modos de emergencia
- Configuración de parámetros de defensa

### 3. **Visualización de Amenazas**
- Lista de amenazas activas con clasificación
- Indicadores visuales por nivel de amenaza
- Detalles de cada amenaza detectada
- Historial de amenazas y respuestas

### 4. **Configuración del Sistema**
- Parámetros de escaneo automático
- Configuración de respuestas automáticas
- Umbrales de escalación
- Configuración de coaliciones

## 🔧 Configuración

### Archivo de Configuración (`mev-defense-config.json`)

```json
{
  "frontend": {
    "defense_system": {
      "auto_scan_interval": 30000,
      "status_update_interval": 30000,
      "emergency_mode_timeout": 3000,
      "max_displayed_threats": 50,
      "notification_duration": 5000
    },
    "ui": {
      "theme": "dark",
      "animations": true,
      "auto_refresh": true,
      "compact_mode": false
    }
  },
  "integration": {
    "backend_url": "http://localhost:3001",
    "websocket_enabled": true,
    "real_time_updates": true
  }
}
```

### Variables de Entorno

```bash
# URL del backend del sistema de defensa
MEV_DEFENSE_BACKEND_URL=http://localhost:3001

# Habilitar modo demo
MEV_DEFENSE_DEMO_MODE=true

# Intervalo de escaneo automático (ms)
MEV_DEFENSE_SCAN_INTERVAL=30000
```

## 🚀 Uso del Sistema

### 1. **Acceso al Sistema**
- Desde el dashboard principal: Click en el ícono de escudo en el sidebar
- URL directa: `http://localhost:3000/mev-defense.html`

### 2. **Monitoreo Básico**
- El sistema inicia automáticamente en modo de monitoreo
- Las métricas se actualizan en tiempo real
- Las amenazas se detectan automáticamente

### 3. **Escaneo Manual**
- Click en "Escanear Amenazas" para ejecutar escaneo manual
- El sistema mostrará el progreso del escaneo
- Los resultados se actualizan en tiempo real

### 4. **Prueba del Sistema**
- Click en "Probar Sistema" para verificar funcionamiento
- Se activa modo de emergencia temporal
- Se ejecutan pruebas de todos los módulos

### 5. **Configuración**
- Panel de configuración accesible desde la página principal
- Parámetros configurables en tiempo real
- Cambios se aplican inmediatamente

## 🎨 Personalización de la UI

### Temas Disponibles
- **Claro**: Interfaz clara y limpia
- **Oscuro**: Modo oscuro para uso nocturno
- **Automático**: Se adapta al tema del sistema

### Animaciones
- Efectos de hover en tarjetas
- Animaciones de estado del sistema
- Transiciones suaves entre modos

### Responsive Design
- Adaptable a dispositivos móviles
- Grid responsivo para diferentes tamaños de pantalla
- Navegación optimizada para touch

## 🔌 Integración con Backend

### Endpoints Utilizados
- `GET /api/mev-defense/status` - Estado del sistema
- `POST /api/mev-defense/scan` - Escanear amenazas
- `GET /api/mev-defense/threats` - Lista de amenazas
- `POST /api/mev-defense/execute` - Ejecutar defensa
- `GET /api/mev-defense/stats` - Estadísticas del sistema

### WebSocket (Opcional)
- Actualizaciones en tiempo real
- Notificaciones instantáneas
- Sincronización de estado

## 🧪 Modo Demo

El sistema incluye un modo demo completo que permite:

- **Amenazas Simuladas**: Generación automática de amenazas de prueba
- **Respuestas Simuladas**: Ejecución de contramedidas sin afectar la red real
- **Configuración de Prueba**: Parámetros seguros para desarrollo

### Activar Modo Demo
```javascript
// En la consola del navegador
window.mevDefense.activateDemoMode();
```

## 🚨 Solución de Problemas

### Problemas Comunes

1. **Sistema no responde**
   - Verificar conexión al backend
   - Revisar consola del navegador
   - Verificar archivos de configuración

2. **Amenazas no se detectan**
   - Verificar configuración de escaneo
   - Revisar logs del backend
   - Verificar conectividad de red

3. **Interfaz no se carga**
   - Verificar archivos CSS y JS
   - Limpiar caché del navegador
   - Verificar permisos de archivos

### Logs y Debugging

```javascript
// Habilitar logs detallados
localStorage.setItem('mev-defense-debug', 'true');

// Ver logs en consola
console.log('MEV Defense Debug:', window.mevDefense.getDebugInfo());
```

## 🔒 Seguridad

### Características de Seguridad
- Validación de entrada en todos los campos
- Sanitización de datos antes de enviar al backend
- Verificación de permisos para acciones críticas
- Logs de auditoría para todas las acciones

### Recomendaciones
- Usar HTTPS en producción
- Implementar autenticación de usuarios
- Limitar acceso a funciones críticas
- Monitorear logs de seguridad

## 📈 Métricas y Analytics

### Métricas Disponibles
- Tiempo de respuesta del sistema
- Tasa de detección de amenazas
- Efectividad de contramedidas
- Uso de recursos del sistema

### Exportación de Datos
- Reportes en formato JSON
- Exportación a CSV
- Integración con herramientas de analytics

## 🔮 Roadmap Futuro

### Próximas Funcionalidades
- [ ] Dashboard de analytics avanzado
- [ ] Integración con múltiples blockchains
- [ ] Sistema de alertas por email/SMS
- [ ] API pública para integraciones
- [ ] Machine Learning para detección de amenazas

### Mejoras de UI/UX
- [ ] Modo oscuro automático
- [ ] Personalización de temas
- [ ] Widgets configurables
- [ ] Notificaciones push

## 🤝 Contribución

### Cómo Contribuir
1. Fork del repositorio
2. Crear rama para nueva funcionalidad
3. Implementar cambios
4. Crear Pull Request

### Estándares de Código
- Usar ESLint para JavaScript
- Seguir convenciones de CSS
- Documentar nuevas funcionalidades
- Incluir tests para cambios críticos

## 📞 Soporte

### Canales de Soporte
- **Issues**: GitHub Issues
- **Documentación**: Este README
- **Comunidad**: Discord/Slack del proyecto

### Recursos Adicionales
- [Documentación del Backend](../backend/README-MEV-DEFENSE.md)
- [API Reference](../backend/docs/API.md)
- [Guía de Despliegue](../docs/DEPLOYMENT.md)

---

**🛡️ Sistema de Defensa MEV - ArbitrageX Pro 2025**

*"La mejor defensa es un buen contraataque"*
