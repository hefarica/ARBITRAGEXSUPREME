// Configuración de logos de blockchains para ArbitrageX
const BLOCKCHAIN_LOGOS = {
    // Ethereum y compatibles
    'ethereum': {
        logo: 'images/blockchain-logos/ethereum.png',
        name: 'Ethereum',
        color: '#627EEA',
        chainId: 1
    },
    'polygon': {
        logo: 'images/blockchain-logos/polygon.png',
        name: 'Polygon',
        color: '#8247E5',
        chainId: 137
    },
    'bsc': {
        logo: 'images/blockchain-logos/bsc.png',
        name: 'BNB Smart Chain',
        color: '#F3BA2F',
        chainId: 56
    },
    'arbitrum': {
        logo: 'images/blockchain-logos/arbitrum.png',
        name: 'Arbitrum',
        color: '#28A0F0',
        chainId: 42161
    },
    'optimism': {
        logo: 'images/blockchain-logos/optimism.png',
        name: 'Optimism',
        color: '#FF0420',
        chainId: 10
    },
    'avalanche': {
        logo: 'images/blockchain-logos/avalanche.png',
        name: 'Avalanche',
        color: '#E84142',
        chainId: 43114
    },
    'fantom': {
        logo: 'images/blockchain-logos/fantom.png',
        name: 'Fantom',
        color: '#1969FF',
        chainId: 250
    },
    'cronos': {
        logo: 'images/blockchain-logos/cronos.png',
        name: 'Cronos',
        color: '#25C5A7',
        chainId: 25
    },
    'base': {
        logo: 'images/blockchain-logos/base.png',
        name: 'Base',
        color: '#0052FF',
        chainId: 8453
    },
    'gnosis': {
        logo: 'images/blockchain-logos/gnosis.png',
        name: 'Gnosis Chain',
        color: '#00A6C4',
        chainId: 100
    },
    'moonbeam': {
        logo: 'images/blockchain-logos/moonbeam.png',
        name: 'Moonbeam',
        color: '#E1147B',
        chainId: 1284
    }
};

// Función para obtener el logo de una blockchain
function getBlockchainLogo(blockchainName) {
    const config = BLOCKCHAIN_LOGOS[blockchainName.toLowerCase()];
    return config ? config.logo : null;
}

// Función para obtener la configuración completa de una blockchain
function getBlockchainConfig(blockchainName) {
    return BLOCKCHAIN_LOGOS[blockchainName.toLowerCase()] || null;
}

// Función para obtener todos los logos disponibles
function getAllBlockchainLogos() {
    return Object.values(BLOCKCHAIN_LOGOS).map(config => config.logo);
}

// Función para renderizar un logo de blockchain en HTML
function renderBlockchainLogo(blockchainName, size = 'w-6 h-6', showName = false) {
    const config = getBlockchainConfig(blockchainName);
    if (!config) {
        return `<div class="${size} bg-gray-300 rounded-full flex items-center justify-center">
                    <span class="text-xs text-gray-600">?</span>
                </div>`;
    }
    
    let html = `<img src="${config.logo}" alt="${config.name}" class="${size} rounded-full object-cover" title="${config.name}">`;
    
    if (showName) {
        html += `<span class="ml-2 text-sm font-medium" style="color: ${config.color}">${config.name}</span>`;
    }
    
    return html;
}

// Función para crear un badge de blockchain con logo
function createBlockchainBadge(blockchainName, showChainId = true) {
    const config = getBlockchainConfig(blockchainName);
    if (!config) {
        return `<span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-800">
                    <span class="w-3 h-3 bg-gray-400 rounded-full mr-1"></span>
                    Unknown
                </span>`;
    }
    
    let html = `<span class="inline-flex items-center px-2 py-1 rounded-full text-xs" style="background-color: ${config.color}20; color: ${config.color}; border: 1px solid ${config.color}30">
                    <img src="${config.logo}" alt="${config.name}" class="w-3 h-3 rounded-full mr-1 object-cover">
                    ${config.name}`;
    
    if (showChainId) {
        html += ` <span class="ml-1 opacity-75">(${config.chainId})</span>`;
    }
    
    html += `</span>`;
    return html;
}

// Exportar para uso en otros módulos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        BLOCKCHAIN_LOGOS,
        getBlockchainLogo,
        getBlockchainConfig,
        getAllBlockchainLogos,
        renderBlockchainLogo,
        createBlockchainBadge
    };
}
