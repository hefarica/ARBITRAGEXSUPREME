/**
 * 📊 Charts.js - Sistema de Gráficos para ArbitrageX Pro 2025
 * 
 * Este módulo maneja todos los gráficos de rendimiento, incluyendo:
 * - Gráfico de ganancias/pérdidas en el tiempo
 * - Distribución de estrategias por blockchain
 * - Rendimiento por categoría de estrategia
 * - Métricas de latencia y conectividad
 * - Historial de trades y ROI
 */

class ArbitrageXCharts {
    constructor() {
        this.charts = {};
        this.chartColors = {
            primary: '#3b82f6',
            secondary: '#10b981',
            accent: '#f59e0b',
            danger: '#ef4444',
            warning: '#f97316',
            info: '#06b6d4',
            success: '#22c55e',
            dark: '#1f2937'
        };
        
        this.gradientColors = {
            profit: ['rgba(34, 197, 94, 0.8)', 'rgba(34, 197, 94, 0.2)'],
            loss: ['rgba(239, 68, 68, 0.8)', 'rgba(239, 68, 68, 0.2)'],
            neutral: ['rgba(59, 130, 246, 0.8)', 'rgba(59, 130, 246, 0.2)']
        };
        
        this.init();
    }

    init() {
        this.setupChartDefaults();
        this.createCharts();
        this.setupEventListeners();
    }

    setupChartDefaults() {
        // Configuración global de Chart.js
        Chart.defaults.font.family = 'Inter, system-ui, sans-serif';
        Chart.defaults.font.size = 12;
        Chart.defaults.color = '#9ca3af';
        Chart.defaults.plugins.legend.labels.usePointStyle = true;
        Chart.defaults.plugins.legend.labels.padding = 20;
        Chart.defaults.plugins.tooltip.backgroundColor = '#1f2937';
        Chart.defaults.plugins.tooltip.titleColor = '#f9fafb';
        Chart.defaults.plugins.tooltip.bodyColor = '#d1d5db';
        Chart.defaults.plugins.tooltip.borderColor = '#374151';
        Chart.defaults.plugins.tooltip.borderWidth = 1;
        Chart.defaults.plugins.tooltip.cornerRadius = 8;
        Chart.defaults.plugins.tooltip.displayColors = false;
    }

    createCharts() {
        this.createProfitLossChart();
        this.createStrategyDistributionChart();
        this.createBlockchainPerformanceChart();
        this.createROIChart();
        this.createLatencyChart();
        this.createTradeHistoryChart();
    }

    createProfitLossChart() {
        const ctx = document.getElementById('profit-loss-chart');
        if (!ctx) return;

        const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, this.gradientColors.profit[0]);
        gradient.addColorStop(1, this.gradientColors.profit[1]);

        this.charts.profitLoss = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.generateTimeLabels(30),
                datasets: [{
                    label: 'Ganancias/Pérdidas (%)',
                    data: this.generateMockProfitLossData(30),
                    borderColor: this.chartColors.success,
                    backgroundColor: gradient,
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointHoverRadius: 8,
                    pointBackgroundColor: this.chartColors.success,
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Rendimiento de Arbitraje (Últimos 30 días)',
                        color: '#f9fafb',
                        font: { size: 16, weight: '600' }
                    },
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => `ROI: ${context.parsed.y.toFixed(2)}%`,
                            title: (tooltipItems) => `Día ${tooltipItems[0].label}`
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: '#374151',
                            borderColor: '#4b5563'
                        },
                        ticks: {
                            color: '#9ca3af',
                            maxTicksLimit: 10
                        }
                    },
                    y: {
                        grid: {
                            color: '#374151',
                            borderColor: '#4b5563'
                        },
                        ticks: {
                            color: '#9ca3af',
                            callback: (value) => `${value.toFixed(1)}%`
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    createStrategyDistributionChart() {
        const ctx = document.getElementById('strategy-distribution-chart');
        if (!ctx) return;

        this.charts.strategyDistribution = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Flash-Loan', 'Cross-Chain', 'MEV-Protection', 'Atomic-Swap'],
                datasets: [{
                    data: [35, 28, 22, 15],
                    backgroundColor: [
                        this.chartColors.primary,
                        this.chartColors.secondary,
                        this.chartColors.accent,
                        this.chartColors.info
                    ],
                    borderColor: '#1f2937',
                    borderWidth: 2,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Distribución de Estrategias',
                        color: '#f9fafb',
                        font: { size: 16, weight: '600' }
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#f9fafb',
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => `${context.label}: ${context.parsed}%`
                        }
                    }
                }
            }
        });
    }

    createBlockchainPerformanceChart() {
        const ctx = document.getElementById('blockchain-performance-chart');
        if (!ctx) return;

        this.charts.blockchainPerformance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Ethereum', 'Polygon', 'BSC', 'Arbitrum', 'Optimism', 'Avalanche'],
                datasets: [{
                    label: 'ROI Promedio (%)',
                    data: [2.8, 3.2, 2.5, 3.8, 2.9, 3.1],
                    backgroundColor: [
                        this.chartColors.primary,
                        this.chartColors.secondary,
                        this.chartColors.accent,
                        this.chartColors.success,
                        this.chartColors.warning,
                        this.chartColors.info
                    ],
                    borderColor: '#1f2937',
                    borderWidth: 1,
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Rendimiento por Blockchain',
                        color: '#f9fafb',
                        font: { size: 16, weight: '600' }
                    },
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => `ROI: ${context.parsed.y.toFixed(1)}%`
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#9ca3af'
                        }
                    },
                    y: {
                        grid: {
                            color: '#374151',
                            borderColor: '#4b5563'
                        },
                        ticks: {
                            color: '#9ca3af',
                            callback: (value) => `${value.toFixed(1)}%`
                        }
                    }
                }
            }
        });
    }

    createROIChart() {
        const ctx = document.getElementById('roi-chart');
        if (!ctx) return;

        this.charts.roi = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.generateTimeLabels(24),
                datasets: [{
                    label: 'ROI Acumulado',
                    data: this.generateMockROIData(24),
                    borderColor: this.chartColors.success,
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    borderWidth: 2,
                    fill: false,
                    tension: 0.3,
                    pointRadius: 3,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'ROI Acumulado (Últimas 24 horas)',
                        color: '#f9fafb',
                        font: { size: 16, weight: '600' }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: '#374151'
                        },
                        ticks: {
                            color: '#9ca3af',
                            maxTicksLimit: 12
                        }
                    },
                    y: {
                        grid: {
                            color: '#374151'
                        },
                        ticks: {
                            color: '#9ca3af',
                            callback: (value) => `${value.toFixed(2)}%`
                        }
                    }
                }
            }
        });
    }

    createLatencyChart() {
        const ctx = document.getElementById('latency-chart');
        if (!ctx) return;

        this.charts.latency = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: ['Ethereum', 'Polygon', 'BSC', 'Arbitrum', 'Optimism', 'Avalanche'],
                datasets: [{
                    label: 'Latencia (ms)',
                    data: [45, 32, 28, 38, 42, 35],
                    backgroundColor: 'rgba(59, 130, 246, 0.2)',
                    borderColor: this.chartColors.primary,
                    borderWidth: 2,
                    pointBackgroundColor: this.chartColors.primary,
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Latencia por Blockchain',
                        color: '#f9fafb',
                        font: { size: 16, weight: '600' }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    r: {
                        grid: {
                            color: '#374151'
                        },
                        ticks: {
                            color: '#9ca3af',
                            callback: (value) => `${value}ms`
                        },
                        pointLabels: {
                            color: '#f9fafb'
                        }
                    }
                }
            }
        });
    }

    createTradeHistoryChart() {
        const ctx = document.getElementById('trade-history-chart');
        if (!ctx) return;

        this.charts.tradeHistory = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: this.generateTimeLabels(7),
                datasets: [{
                    label: 'Trades Exitosos',
                    data: this.generateMockTradeData(7),
                    backgroundColor: this.chartColors.success,
                    borderColor: '#1f2937',
                    borderWidth: 1,
                    borderRadius: 4
                }, {
                    label: 'Trades Fallidos',
                    data: this.generateMockTradeData(7, false),
                    backgroundColor: this.chartColors.danger,
                    borderColor: '#1f2937',
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Historial de Trades (Última semana)',
                        color: '#f9fafb',
                        font: { size: 16, weight: '600' }
                    },
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#f9fafb',
                            usePointStyle: true
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#9ca3af'
                        }
                    },
                    y: {
                        grid: {
                            color: '#374151'
                        },
                        ticks: {
                            color: '#9ca3af'
                        }
                    }
                }
            }
        });
    }

    generateTimeLabels(period) {
        const labels = [];
        const now = new Date();
        
        for (let i = period - 1; i >= 0; i--) {
            const date = new Date(now);
            date.setDate(date.getDate() - i);
            
            if (period <= 7) {
                labels.push(date.toLocaleDateString('es-ES', { weekday: 'short' }));
            } else if (period <= 30) {
                labels.push(date.getDate().toString());
            } else {
                labels.push(date.toLocaleDateString('es-ES', { month: 'short', day: 'numeric' }));
            }
        }
        
        return labels;
    }

    generateMockProfitLossData(period) {
        console.warn('⚠️ generateMockProfitLossData() está deprecado. Use fetchRealProfitLossData() en su lugar.');
        
        // TODO: Conectar con backend para obtener datos reales de P&L
        // TODO: Implementar API calls a exchanges y DEXs
        // TODO: Calcular ganancias/pérdidas reales de arbitraje
        
        // Placeholder temporal - array de ceros hasta implementar datos reales
        return new Array(period).fill(0);
    }

    generateMockROIData(period) {
        console.warn('⚠️ generateMockROIData() está deprecado. Use fetchRealROIData() en su lugar.');
        
        // TODO: Conectar con backend para obtener datos reales de ROI
        // TODO: Calcular ROI real basado en trades ejecutados
        // TODO: Integrar con sistema de contabilidad y tracking
        
        // Placeholder temporal - array de ceros hasta implementar datos reales
        return new Array(period).fill(0);
    }

    generateMockTradeData(period, successful = true) {
        console.warn('⚠️ generateMockTradeData() está deprecado. Use fetchRealTradeData() en su lugar.');
        
        // TODO: Conectar con backend para obtener datos reales de trades
        // TODO: Integrar con blockchain para verificar transacciones
        // TODO: Calcular métricas reales de éxito/fallo
        
        // Placeholder temporal - array de ceros hasta implementar datos reales
        return new Array(period).fill(0);
    }

    updateChartsWithRealData(realData) {
        // Actualizar gráficos con datos reales del backend
        if (realData.profitLoss && this.charts.profitLoss) {
            this.charts.profitLoss.data.datasets[0].data = realData.profitLoss;
            this.charts.profitLoss.update('none');
        }
        
        if (realData.strategyDistribution && this.charts.strategyDistribution) {
            this.charts.strategyDistribution.data.datasets[0].data = realData.strategyDistribution;
            this.charts.strategyDistribution.update('none');
        }
        
        if (realData.blockchainPerformance && this.charts.blockchainPerformance) {
            this.charts.blockchainPerformance.data.datasets[0].data = realData.blockchainPerformance;
            this.charts.blockchainPerformance.update('none');
        }
    }

    refreshAllCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.update === 'function') {
                chart.update('none');
            }
        });
    }

    destroyAllCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.destroy === 'function') {
                chart.destroy();
            }
        });
        this.charts = {};
    }

    setupEventListeners() {
        // Event listener para actualizar gráficos cuando cambie el tema
        document.addEventListener('themeChanged', () => {
            this.refreshAllCharts();
        });
        
        // Event listener para datos en tiempo real
        document.addEventListener('realTimeDataUpdate', (event) => {
            this.updateChartsWithRealData(event.detail);
        });
    }

    // Métodos públicos para integración con la aplicación principal
    getChartInstance(chartName) {
        return this.charts[chartName];
    }

    exportChartAsImage(chartName) {
        const chart = this.charts[chartName];
        if (chart) {
            return chart.toBase64Image();
        }
        return null;
    }

    resizeCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    }
}

// Exportar la clase para uso global
window.ArbitrageXCharts = ArbitrageXCharts;

// Auto-inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    if (typeof Chart !== 'undefined') {
        window.arbitrageXCharts = new ArbitrageXCharts();
    } else {
        console.warn('Chart.js no está cargado. Los gráficos no estarán disponibles.');
    }
});

