class APIManagementSystem {
    constructor() {
        this.baseURL = 'http://localhost:3001/api/management';
        this.autoRefreshInterval = null;
        this.isAutoRefreshActive = false;
        this.apiStatuses = new Map();
        
        this.initialize();
    }

    async initialize() {
        this.setupEventListeners();
        this.loadCurrentConfig();
        await this.initializeAPIService();
        await this.refreshAllData();
        this.startAutoRefresh();
        this.log('Sistema de gestión de APIs inicializado');
    }

    setupEventListeners() {
        // Botones de configuración
        document.getElementById('saveConfig').addEventListener('click', () => this.saveConfiguration());
        document.getElementById('refreshAll').addEventListener('click', () => this.refreshAllData());
        document.getElementById('testAllAPIs').addEventListener('click', () => this.testAllAPIs());
        document.getElementById('autoRefresh').addEventListener('click', () => this.toggleAutoRefresh());

        // Botones de prueba individual
        document.getElementById('test-coingecko').addEventListener('click', () => this.testSingleAPI('coingecko'));
        document.getElementById('test-dexscreener').addEventListener('click', () => this.testSingleAPI('dexscreener'));
        document.getElementById('test-ethereum').addEventListener('click', () => this.testSingleAPI('ethereum'));
        document.getElementById('test-polygon').addEventListener('click', () => this.testSingleAPI('polygon'));
        document.getElementById('test-etherscan').addEventListener('click', () => this.testSingleAPI('etherscan'));
        document.getElementById('test-uniswap').addEventListener('click', () => this.testSingleAPI('uniswap'));

        // Botones de prueba de datos
        document.getElementById('test-coingecko-data').addEventListener('click', () => this.testCoinGeckoData());
        document.getElementById('test-ethereum-gas').addEventListener('click', () => this.testEthereumGas());
        document.getElementById('test-polygon-gas').addEventListener('click', () => this.testPolygonGas());
        document.getElementById('test-dexscreener-data').addEventListener('click', () => this.testDexScreenerData());
        document.getElementById('test-etherscan-data').addEventListener('click', () => this.testEtherscanData());

        // Botones de logs
        document.getElementById('clearLogs').addEventListener('click', () => this.clearLogs());
        document.getElementById('exportLogs').addEventListener('click', () => this.exportLogs());
    }

    async loadCurrentConfig() {
        try {
            const response = await fetch(`${this.baseURL}/config`);
            const data = await response.json();
            
            if (data.success) {
                this.populateConfigForm(data.data);
                this.log('Configuración actual cargada');
            }
        } catch (error) {
            this.log(`Error cargando configuración: ${error.message}`, 'error');
        }
    }

    populateConfigForm(config) {
        // CoinGecko
        if (config.coingecko) {
            document.getElementById('coingecko-key').value = config.coingecko.apiKey;
            document.getElementById('coingecko-pro').checked = config.coingecko.isPro;
        }

        // DexScreener
        if (config.dexscreener) {
            document.getElementById('dexscreener-key').value = config.dexscreener.apiKey;
        }

        // Ethereum
        if (config.ethereum) {
            document.getElementById('ethereum-rpc').value = config.ethereum.rpcUrl;
        }

        // Polygon
        if (config.polygon) {
            document.getElementById('polygon-rpc').value = config.polygon.rpcUrl;
        }

        // Etherscan
        if (config.etherscan) {
            document.getElementById('etherscan-key').value = config.etherscan.apiKey;
        }

        // Uniswap
        if (config.uniswap) {
            document.getElementById('uniswap-key').value = config.uniswap.subgraphKey;
        }
    }

    async saveConfiguration() {
        this.showLoading(true);
        
        try {
            const config = {
                coingecko: {
                    apiKey: document.getElementById('coingecko-key').value,
                    isPro: document.getElementById('coingecko-pro').checked
                },
                dexscreener: {
                    apiKey: document.getElementById('dexscreener-key').value
                },
                ethereum: {
                    rpcUrl: document.getElementById('ethereum-rpc').value
                },
                polygon: {
                    rpcUrl: document.getElementById('polygon-rpc').value
                },
                etherscan: {
                    apiKey: document.getElementById('etherscan-key').value
                },
                uniswap: {
                    subgraphKey: document.getElementById('uniswap-key').value
                }
            };

            const response = await fetch(`${this.baseURL}/config`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(config)
            });

            const data = await response.json();
            
            if (data.success) {
                this.showNotification('Configuración guardada exitosamente');
                this.log('Configuración actualizada');
                await this.refreshAllData();
            } else {
                throw new Error(data.message || 'Error guardando configuración');
            }
        } catch (error) {
            this.showNotification(`Error: ${error.message}`, 'error');
            this.log(`Error guardando configuración: ${error.message}`, 'error');
        } finally {
            this.showLoading(false);
        }
    }

    async initializeAPIService() {
        try {
            const response = await fetch(`${this.baseURL}/initialize`, {
                method: 'POST'
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.log('Servicio de APIs inicializado');
                document.getElementById('systemStatus').textContent = 'Operacional';
                document.getElementById('systemStatus').className = 'text-2xl font-bold text-green-600';
            } else {
                throw new Error(data.message || 'Error inicializando servicio');
            }
        } catch (error) {
            this.log(`Error inicializando servicio: ${error.message}`, 'error');
            document.getElementById('systemStatus').textContent = 'Error';
            document.getElementById('systemStatus').className = 'text-2xl font-bold text-red-600';
        }
    }

    async refreshAllData() {
        await Promise.all([
            this.getAPIStatuses(),
            this.getInitializationStatus()
        ]);
    }

    async getAPIStatuses() {
        try {
            const response = await fetch(`${this.baseURL}/status`);
            const data = await response.json();
            
            if (data.success) {
                this.apiStatuses = new Map(data.data.map(status => [status.service, status]));
                this.updateStatusOverview();
                this.updateStatusGrid();
                this.log('Estados de APIs actualizados');
            }
        } catch (error) {
            this.log(`Error obteniendo estados: ${error.message}`, 'error');
        }
    }

    async getInitializationStatus() {
        try {
            const response = await fetch(`${this.baseURL}/initialize/status`);
            const data = await response.json();
            
            if (data.success) {
                const isInitialized = data.data.isInitialized;
                if (isInitialized) {
                    document.getElementById('systemStatus').textContent = 'Operacional';
                    document.getElementById('systemStatus').className = 'text-2xl font-bold text-green-600';
                } else {
                    document.getElementById('systemStatus').textContent = 'Inicializando';
                    document.getElementById('systemStatus').className = 'text-2xl font-bold text-yellow-600';
                }
            }
        } catch (error) {
            this.log(`Error obteniendo estado de inicialización: ${error.message}`, 'error');
        }
    }

    updateStatusOverview() {
        const statuses = Array.from(this.apiStatuses.values());
        const connected = statuses.filter(s => s.status === 'connected').length;
        const error = statuses.filter(s => s.status === 'error').length;
        const avgLatency = statuses
            .filter(s => s.latency)
            .reduce((sum, s) => sum + s.latency, 0) / Math.max(connected, 1);

        document.getElementById('connectedCount').textContent = connected;
        document.getElementById('errorCount').textContent = error;
        document.getElementById('avgLatency').textContent = `${Math.round(avgLatency)}ms`;
    }

    updateStatusGrid() {
        const grid = document.getElementById('apiStatusGrid');
        grid.innerHTML = '';

        const services = [
            { name: 'coingecko', icon: 'fab fa-bitcoin', color: 'orange' },
            { name: 'dexscreener', icon: 'fas fa-chart-line', color: 'green' },
            { name: 'ethereum', icon: 'fab fa-ethereum', color: 'blue' },
            { name: 'polygon', icon: 'fas fa-polygon', color: 'purple' },
            { name: 'etherscan', icon: 'fas fa-search', color: 'blue' },
            { name: 'uniswap', icon: 'fas fa-exchange-alt', color: 'pink' },
            { name: 'aave', icon: 'fas fa-piggy-bank', color: 'green' }
        ];

        services.forEach(service => {
            const status = this.apiStatuses.get(service.name);
            const card = this.createStatusCard(service, status);
            grid.appendChild(card);
        });
    }

    createStatusCard(service, status) {
        const card = document.createElement('div');
        card.className = 'bg-white rounded-lg p-4 shadow-md border-l-4';
        
        let statusColor, statusText, statusIcon;
        
        if (!status || status.status === 'disconnected') {
            statusColor = 'border-gray-400';
            statusText = 'Desconectado';
            statusIcon = 'fas fa-times-circle text-gray-400';
        } else if (status.status === 'connected') {
            statusColor = 'border-green-500';
            statusText = 'Conectado';
            statusIcon = 'fas fa-check-circle text-green-500';
        } else {
            statusColor = 'border-red-500';
            statusText = 'Error';
            statusIcon = 'fas fa-exclamation-triangle text-red-500';
        }

        card.className += ` ${statusColor}`;

        const latency = status?.latency ? `${status.latency}ms` : 'N/A';
        const lastChecked = status?.lastChecked ? new Date(status.lastChecked).toLocaleTimeString() : 'Nunca';

        card.innerHTML = `
            <div class="flex items-center justify-between mb-3">
                <div class="flex items-center space-x-2">
                    <i class="${service.icon} text-${service.color}-500 text-xl"></i>
                    <h3 class="font-semibold text-gray-800 capitalize">${service.name}</h3>
                </div>
                <i class="${statusIcon} text-xl"></i>
            </div>
            <div class="space-y-2 text-sm text-gray-600">
                <div class="flex justify-between">
                    <span>Estado:</span>
                    <span class="font-medium">${statusText}</span>
                </div>
                <div class="flex justify-between">
                    <span>Latencia:</span>
                    <span class="font-medium">${latency}</span>
                </div>
                <div class="flex justify-between">
                    <span>Última verificación:</span>
                    <span class="font-medium">${lastChecked}</span>
                </div>
            </div>
            ${status?.error ? `
                <div class="mt-3 p-2 bg-red-50 border border-red-200 rounded text-red-700 text-xs">
                    ${status.error}
                </div>
            ` : ''}
        `;

        return card;
    }

    async testSingleAPI(service) {
        try {
            const response = await fetch(`${this.baseURL}/test/${service}`);
            const data = await response.json();
            
            if (data.success) {
                this.showNotification(`API ${service} probada exitosamente`);
                this.log(`API ${service} probada: ${data.data.status}`);
                await this.getAPIStatuses();
            } else {
                throw new Error(data.message || 'Error probando API');
            }
        } catch (error) {
            this.showNotification(`Error probando ${service}: ${error.message}`, 'error');
            this.log(`Error probando API ${service}: ${error.message}`, 'error');
        }
    }

    async testAllAPIs() {
        this.showLoading(true);
        
        try {
            const response = await fetch(`${this.baseURL}/test/all`);
            const data = await response.json();
            
            if (data.success) {
                this.showNotification('Todas las APIs probadas exitosamente');
                this.log(`Todas las APIs probadas. Resumen: ${data.summary.connected} conectadas, ${data.summary.error} con error`);
                await this.getAPIStatuses();
            } else {
                throw new Error(data.message || 'Error probando APIs');
            }
        } catch (error) {
            this.showNotification(`Error: ${error.message}`, 'error');
            this.log(`Error probando todas las APIs: ${error.message}`, 'error');
        } finally {
            this.showLoading(false);
        }
    }

    async testCoinGeckoData() {
        try {
            const coins = document.getElementById('coingecko-coins').value;
            const response = await fetch(`${this.baseURL}/coingecko/prices?coins=${encodeURIComponent(coins)}`);
            const data = await response.json();
            
            if (data.success) {
                const resultDiv = document.getElementById('coingecko-result');
                resultDiv.innerHTML = `<pre class="text-xs">${JSON.stringify(data.data, null, 2)}</pre>`;
                this.log('Datos de CoinGecko obtenidos exitosamente');
            } else {
                throw new Error(data.message || 'Error obteniendo datos');
            }
        } catch (error) {
            document.getElementById('coingecko-result').innerHTML = `<div class="text-red-600">Error: ${error.message}</div>`;
            this.log(`Error obteniendo datos de CoinGecko: ${error.message}`, 'error');
        }
    }

    async testEthereumGas() {
        try {
            const response = await fetch(`${this.baseURL}/ethereum/gas`);
            const data = await response.json();
            
            if (data.success) {
                const resultDiv = document.getElementById('gas-result');
                resultDiv.innerHTML = `<pre class="text-xs">${JSON.stringify(data.data, null, 2)}</pre>`;
                this.log('Precio de gas de Ethereum obtenido exitosamente');
            } else {
                throw new Error(data.message || 'Error obteniendo precio de gas');
            }
        } catch (error) {
            document.getElementById('gas-result').innerHTML = `<div class="text-red-600">Error: ${error.message}</div>`;
            this.log(`Error obteniendo precio de gas de Ethereum: ${error.message}`, 'error');
        }
    }

    async testPolygonGas() {
        try {
            const response = await fetch(`${this.baseURL}/polygon/gas`);
            const data = await response.json();
            
            if (data.success) {
                const resultDiv = document.getElementById('gas-result');
                resultDiv.innerHTML = `<pre class="text-xs">${JSON.stringify(data.data, null, 2)}</pre>`;
                this.log('Precio de gas de Polygon obtenido exitosamente');
            } else {
                throw new Error(data.message || 'Error obteniendo precio de gas');
            }
        } catch (error) {
            document.getElementById('gas-result').innerHTML = `<div class="text-red-600">Error: ${error.message}</div>`;
            this.log(`Error obteniendo precio de gas de Polygon: ${error.message}`, 'error');
        }
    }

    async testDexScreenerData() {
        try {
            const pair = document.getElementById('dexscreener-pair').value;
            const response = await fetch(`${this.baseURL}/dexscreener/pair/${encodeURIComponent(pair)}`);
            const data = await response.json();
            
            if (data.success) {
                const resultDiv = document.getElementById('dexscreener-result');
                resultDiv.innerHTML = `<pre class="text-xs">${JSON.stringify(data.data, null, 2)}</pre>`;
                this.log('Datos de DexScreener obtenidos exitosamente');
            } else {
                throw new Error(data.message || 'Error obteniendo datos');
            }
        } catch (error) {
            document.getElementById('dexscreener-result').innerHTML = `<div class="text-red-600">Error: ${error.message}</div>`;
            this.log(`Error obteniendo datos de DexScreener: ${error.message}`, 'error');
        }
    }

    async testEtherscanData() {
        try {
            const txHash = document.getElementById('etherscan-tx').value;
            const response = await fetch(`${this.baseURL}/etherscan/tx/${encodeURIComponent(txHash)}`);
            const data = await response.json();
            
            if (data.success) {
                const resultDiv = document.getElementById('etherscan-result');
                resultDiv.innerHTML = `<pre class="text-xs">${JSON.stringify(data.data, null, 2)}</pre>`;
                this.log('Datos de Etherscan obtenidos exitosamente');
            } else {
                throw new Error(data.message || 'Error obteniendo datos');
            }
        } catch (error) {
            document.getElementById('etherscan-result').innerHTML = `<div class="text-red-600">Error: ${error.message}</div>`;
            this.log(`Error obteniendo datos de Etherscan: ${error.message}`, 'error');
        }
    }

    toggleAutoRefresh() {
        if (this.isAutoRefreshActive) {
            this.stopAutoRefresh();
        } else {
            this.startAutoRefresh();
        }
    }

    startAutoRefresh() {
        this.isAutoRefreshActive = true;
        this.autoRefreshInterval = setInterval(() => {
            this.refreshAllData();
        }, 30000); // 30 segundos
        
        const button = document.getElementById('autoRefresh');
        button.innerHTML = '<i class="fas fa-pause mr-2"></i>Pausar';
        button.className = 'bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-lg transition-all';
        
        this.log('Auto-refresh activado (cada 30 segundos)');
    }

    stopAutoRefresh() {
        this.isAutoRefreshActive = false;
        if (this.autoRefreshInterval) {
            clearInterval(this.autoRefreshInterval);
            this.autoRefreshInterval = null;
        }
        
        const button = document.getElementById('autoRefresh');
        button.innerHTML = '<i class="fas fa-play mr-2"></i>Auto-Refresh';
        button.className = 'bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-all';
        
        this.log('Auto-refresh desactivado');
    }

    showLoading(show) {
        const overlay = document.getElementById('loadingOverlay');
        if (show) {
            overlay.classList.remove('hidden');
            overlay.classList.add('flex');
        } else {
            overlay.classList.add('hidden');
            overlay.classList.remove('flex');
        }
    }

    showNotification(message, type = 'success') {
        const toast = document.getElementById('notificationToast');
        const messageSpan = document.getElementById('notificationMessage');
        
        messageSpan.textContent = message;
        
        if (type === 'error') {
            toast.className = 'fixed top-4 right-4 bg-red-600 text-white px-6 py-3 rounded-lg shadow-lg transform translate-x-full transition-transform duration-300 z-50';
        } else {
            toast.className = 'fixed top-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg transform translate-x-full transition-transform duration-300 z-50';
        }
        
        // Mostrar toast
        setTimeout(() => {
            toast.classList.remove('translate-x-full');
        }, 100);
        
        // Ocultar toast después de 3 segundos
        setTimeout(() => {
            toast.classList.add('translate-x-full');
        }, 3000);
    }

    log(message, level = 'info') {
        const logsDiv = document.getElementById('systemLogs');
        const timestamp = new Date().toLocaleTimeString();
        
        let colorClass = 'text-green-400';
        if (level === 'error') colorClass = 'text-red-400';
        else if (level === 'warning') colorClass = 'text-yellow-400';
        
        const logEntry = document.createElement('div');
        logEntry.className = `mb-1 ${colorClass}`;
        logEntry.innerHTML = `[${timestamp}] ${message}`;
        
        logsDiv.appendChild(logEntry);
        logsDiv.scrollTop = logsDiv.scrollHeight;
        
        // Limitar logs a 100 entradas
        while (logsDiv.children.length > 100) {
            logsDiv.removeChild(logsDiv.firstChild);
        }
    }

    clearLogs() {
        const logsDiv = document.getElementById('systemLogs');
        logsDiv.innerHTML = '<div class="text-gray-400">Logs limpiados...</div>';
        this.log('Logs del sistema limpiados');
    }

    exportLogs() {
        const logsDiv = document.getElementById('systemLogs');
        const logs = Array.from(logsDiv.children).map(child => child.textContent).join('\n');
        
        const blob = new Blob([logs], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `api-logs-${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.log('Logs exportados exitosamente');
    }
}

// Inicializar el sistema cuando se carga la página
document.addEventListener('DOMContentLoaded', () => {
    window.apiManagementSystem = new APIManagementSystem();
});
