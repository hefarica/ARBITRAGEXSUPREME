/**
 * ArbitrageX Pro 2025 - Frontend Application
 * =========================================
 * JavaScript principal para el dashboard de arbitraje
 */

class ArbitrageXApp {
    constructor() {
        this.config = this.loadConfig();
        this.isAutoTradeEnabled = false;
        this.opportunities = [];
        this.priceData = new Map();
        this.lastUpdate = null;
        
        this.init();
    }

    async init() {
        console.log('🚀 Iniciando ArbitrageX Pro 2025...');
        
        // Inicializar event listeners
        this.setupEventListeners();
        
        // Cargar configuración guardada
        this.loadSavedConfig();
        
        // Cargar opciones de filtros desde el backend
        await this.loadFilterOptionsFromBackend();
        
        // Verificar estado de APIs
        await this.checkAPIStatus();
        
        // Iniciar monitoreo si está configurado
        if (this.isConfigured()) {
            this.startMonitoring();
        }
        
        // Mostrar notificación de bienvenida
        this.showNotification('Bienvenido', 'ArbitrageX Pro 2025 iniciado correctamente', 'success');
        
        // Configurar sincronización con Contract Watcher si está disponible
        this.setupContractWatcherSync();
        
        // Configurar sistema de defensa MEV
        this.setupMEVDefenseSystem();
    }

    setupContractWatcherSync() {
        // Escuchar cambios del Contract Watcher
        if (window.contractWatcher) {
            // Crear un evento personalizado para sincronizar filtros
            window.addEventListener('contractWatcher:contractChanged', async (event) => {
                console.log('🔄 Contract Watcher detectó cambios, sincronizando filtros...');
                await this.loadFilterOptionsFromBackend();
            });
            
            // También escuchar cambios en el estado del Contract Watcher
            if (window.contractWatcher.onContractChange) {
                window.contractWatcher.onContractChange = async (newData, source) => {
                    console.log('🔄 Contract Watcher onContractChange, sincronizando filtros...');
                    await this.loadFilterOptionsFromBackend();
                };
            }
        }
    }

    setupEventListeners() {
        // Botones principales
        document.getElementById('settings-btn')?.addEventListener('click', () => this.showConfigModal());
        document.getElementById('refresh-opportunities')?.addEventListener('click', () => this.refreshOpportunities());
        document.getElementById('auto-trade-toggle')?.addEventListener('click', () => this.toggleAutoTrade());
        
        // Filtros
        document.getElementById('min-profit-filter')?.addEventListener('input', () => this.applyFilters());
        
        // Dropdowns multiselect
        this.initMultiSelectDropdowns();
        
        // Modal de configuración
        document.getElementById('close-config')?.addEventListener('click', () => this.hideConfigModal());
        document.getElementById('config-form')?.addEventListener('submit', (e) => this.saveConfig(e));
        document.getElementById('test-config')?.addEventListener('click', () => this.testConfiguration());
        document.getElementById('configure-apis')?.addEventListener('click', () => this.showConfigModal());
        
        // Notificaciones
        document.getElementById('close-notification')?.addEventListener('click', () => this.hideNotification());
        
        // Cerrar modal al hacer clic fuera
        document.getElementById('config-modal')?.addEventListener('click', (e) => {
            if (e.target.id === 'config-modal') {
                this.hideConfigModal();
            }
        });
    }

    loadConfig() {
        const defaultConfig = {
            apis: {
                coingecko: '',
                ethereum_rpc: '',
                etherscan: '',
                uniswap_subgraph: ''
            },
            trading: {
                min_profit: 0.5,
                max_slippage: 0.5,
                auto_trade: false
            }
        };
        
        const savedConfig = localStorage.getItem('arbitragex_config');
        return savedConfig ? { ...defaultConfig, ...JSON.parse(savedConfig) } : defaultConfig;
    }

    saveConfigToStorage() {
        localStorage.setItem('arbitragex_config', JSON.stringify(this.config));
    }

    loadSavedConfig() {
        // Cargar valores en el formulario
        document.getElementById('coingecko-api').value = this.config.apis.coingecko || '';
        document.getElementById('ethereum-rpc').value = this.config.apis.ethereum_rpc || '';
        document.getElementById('etherscan-api').value = this.config.apis.etherscan || '';
        document.getElementById('uniswap-subgraph').value = this.config.apis.uniswap_subgraph || '';
        document.getElementById('min-profit').value = this.config.trading.min_profit || 0.5;
        document.getElementById('max-slippage').value = this.config.trading.max_slippage || 0.5;
    }

    async loadFilterOptionsFromBackend() {
        console.log('🔄 Cargando opciones de filtros desde el backend...');
        
        try {
            // Intentar cargar desde el backend
            const filterOptions = await this.fetchFilterOptionsFromBackend();
            if (filterOptions) {
                this.populateFiltersWithBackendData(filterOptions);
                console.log('✅ Filtros poblados desde el backend');
            } else {
                // Fallback a datos locales si el backend no responde
                console.log('⚠️ Backend no disponible, usando datos locales');
                this.populateFiltersWithLocalData();
            }
        } catch (error) {
            console.error('❌ Error cargando filtros desde backend:', error);
            console.log('🔄 Usando datos locales como fallback');
            this.populateFiltersWithLocalData();
        }
    }

    async fetchFilterOptionsFromBackend() {
        try {
            // Intentar obtener desde el Contract Watcher si está disponible
            if (window.contractWatcher && window.contractWatcher.getState) {
                const state = window.contractWatcher.getState();
                if (state.contractData) {
                    return this.extractFilterOptionsFromContract(state.contractData);
                }
            }

            // Intentar obtener desde endpoints del backend
            const endpoints = [
                '/api/filters/options',
                '/api/strategies',
                '/api/blockchains',
                '/api/categories',
                '/api/complexities'
            ];

            for (const endpoint of endpoints) {
                try {
                    const response = await fetch(endpoint);
                    if (response.ok) {
                        const data = await response.json();
                        console.log(`✅ Datos obtenidos de ${endpoint}:`, data);
                        return data;
                    }
                } catch (e) {
                    console.log(`⚠️ Endpoint ${endpoint} no disponible`);
                }
            }

            return null;
        } catch (error) {
            console.error('❌ Error en fetchFilterOptionsFromBackend:', error);
            return null;
        }
    }

    extractFilterOptionsFromContract(contractData) {
        try {
            // Extraer opciones de filtros desde los datos del contrato OpenAPI
            const options = {
                blockchains: [],
                strategies: [],
                categories: [],
                complexities: []
            };

            if (contractData.paths) {
                // Extraer blockchains desde endpoints como /api/blockchains/{chain}/status
                const blockchainPaths = Object.keys(contractData.paths).filter(path => 
                    path.includes('/blockchains/') || path.includes('/chains/')
                );
                
                blockchainPaths.forEach(path => {
                    const chain = path.split('/').pop();
                    if (chain && !options.blockchains.includes(chain)) {
                        options.blockchains.push(chain);
                    }
                });

                // Extraer estrategias desde endpoints como /api/strategies/{strategy}
                const strategyPaths = Object.keys(contractData.paths).filter(path => 
                    path.includes('/strategies/') || path.includes('/arbitrage/')
                );
                
                strategyPaths.forEach(path => {
                    const strategy = path.split('/').pop();
                    if (strategy && !options.strategies.includes(strategy)) {
                        options.strategies.push(strategy);
                    }
                });
            }

            // Si no hay datos suficientes del contrato, usar datos por defecto
            if (options.blockchains.length === 0) {
                options.blockchains = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism', 'avalanche', 'fantom', 'cronos'];
            }
            
            if (options.strategies.length === 0) {
                options.strategies = [
                    'cross-chain-multi-hop-flash-loan',
                    'cross-chain-cross-dex',
                    'flash-loan-triangular-cross-dex',
                    'multi-hop-cross-dex',
                    'jit-liquidity-arbitrage',
                    'flash-loan-cross-dex',
                    'triangular-inter-dex',
                    'atomic-swap-cross-dex',
                    'triangular-intra-dex',
                    'basic-cross-dex',
                    'basic-flash-loan'
                ];
            }

            // Categorías y complejidades basadas en las estrategias
            options.categories = ['flash-loan', 'cross-chain', 'mev-protection', 'atomic-swap'];
            options.complexities = ['simple', 'intermediate', 'advanced', 'expert'];

            return options;
        } catch (error) {
            console.error('❌ Error extrayendo opciones del contrato:', error);
            return null;
        }
    }

    populateFiltersWithBackendData(filterOptions) {
        if (!filterOptions) return;

        // Poblar filtro de blockchains
        if (filterOptions.blockchains && filterOptions.blockchains.length > 0) {
            this.populateBlockchainFilter(filterOptions.blockchains);
        }

        // Poblar filtro de estrategias
        if (filterOptions.strategies && filterOptions.strategies.length > 0) {
            this.populateStrategyFilter(filterOptions.strategies);
        }

        // Poblar filtro de categorías
        if (filterOptions.categories && filterOptions.categories.length > 0) {
            this.populateCategoryFilter(filterOptions.categories);
        }

        // Poblar filtro de complejidades
        if (filterOptions.complexities && filterOptions.complexities.length > 0) {
            this.populateComplexityFilter(filterOptions.complexities);
        }
    }

    populateFiltersWithLocalData() {
        console.log('🔄 Poblando filtros con datos locales...');
        
        // Datos locales como fallback
        const localData = {
            blockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism', 'avalanche', 'fantom', 'cronos'],
            strategies: [
                'cross-chain-multi-hop-flash-loan',
                'cross-chain-cross-dex',
                'flash-loan-triangular-cross-dex',
                'multi-hop-cross-dex',
                'jit-liquidity-arbitrage',
                'flash-loan-cross-dex',
                'triangular-inter-dex',
                'atomic-swap-cross-dex',
                'triangular-intra-dex',
                'basic-cross-dex',
                'basic-flash-loan'
            ],
            categories: ['flash-loan', 'cross-chain', 'mev-protection', 'atomic-swap'],
            complexities: ['simple', 'intermediate', 'advanced', 'expert']
        };

        this.populateFiltersWithBackendData(localData);
    }

    populateBlockchainFilter(blockchains) {
        const container = document.getElementById('blockchain-dropdown');
        if (!container) return;

        const blockchainData = {
            'ethereum': { name: 'Ethereum (ETH)', icon: '🔷' },
            'polygon': { name: 'Polygon (MATIC)', icon: '🟣' },
            'bsc': { name: 'BSC (BNB)', icon: '🟡' },
            'arbitrum': { name: 'Arbitrum (ARB)', icon: '🔵' },
            'optimism': { name: 'Optimism (OP)', icon: '🔴' },
            'avalanche': { name: 'Avalanche (AVAX)', icon: '⚪' },
            'fantom': { name: 'Fantom (FTM)', icon: '👻' },
            'cronos': { name: 'Cronos (CRO)', icon: '💎' }
        };

        // Mantener la opción "Todas" y el separador
        const headerHtml = container.querySelector('.p-2').innerHTML;
        
        // Limpiar opciones específicas (mantener header)
        const blockchainOptions = container.querySelectorAll('.blockchain-checkbox:not([value="all"]):not([value="cross-chain"]):not([value="intra-chain"])');
        blockchainOptions.forEach(opt => opt.parentElement.remove());

        // Agregar nuevas opciones
        blockchains.forEach(blockchain => {
            if (blockchainData[blockchain]) {
                const label = document.createElement('label');
                label.className = 'flex items-center p-2 hover:bg-gray-600 rounded cursor-pointer';
                label.innerHTML = `
                    <input type="checkbox" class="blockchain-checkbox mr-2" value="${blockchain}">
                    <span class="text-sm">${blockchainData[blockchain].icon} ${blockchainData[blockchain].name}</span>
                `;
                
                // Insertar antes del separador de tipos de operación
                const operationSeparator = container.querySelector('.text-xs.text-gray-400:contains("TIPOS DE OPERACIÓN")');
                if (operationSeparator) {
                    operationSeparator.parentElement.insertBefore(label, operationSeparator.parentElement);
                } else {
                    container.appendChild(label);
                }
            }
        });

        // Re-inicializar event listeners
        this.setupMultiSelectDropdown('blockchain', 'blockchain-checkbox');
    }

    populateStrategyFilter(strategies) {
        const container = document.getElementById('strategy-dropdown');
        if (!container) return;

        const strategyData = {
            'cross-chain-multi-hop-flash-loan': { name: 'Cross-Chain Multi-Hop Flash-Loan', icon: '🚀' },
            'cross-chain-cross-dex': { name: 'Cross-Chain Cross-DEX Arbitrage', icon: '🌐' },
            'flash-loan-triangular-cross-dex': { name: 'Flash-Loan Triangular Cross-DEX', icon: '⚡' },
            'multi-hop-cross-dex': { name: 'Multi-Hop Cross-DEX Arbitrage', icon: '🔄' },
            'jit-liquidity-arbitrage': { name: 'JIT Liquidity Arbitrage', icon: '🛡️' },
            'flash-loan-cross-dex': { name: 'Flash-Loan Cross-DEX Arbitrage', icon: '💸' },
            'triangular-inter-dex': { name: 'Triangular Inter-DEX', icon: '🔺' },
            'atomic-swap-cross-dex': { name: 'Atomic Swap Cross-DEX', icon: '⚛️' },
            'triangular-intra-dex': { name: 'Triangular Intra-DEX', icon: '📐' },
            'basic-cross-dex': { name: 'Basic Cross-DEX Arbitrage', icon: '🔄' },
            'basic-flash-loan': { name: 'Basic Flash-Loan Arbitrage', icon: '💰' }
        };

        // Mantener la opción "Todas" y el separador
        const headerHtml = container.querySelector('.p-2').innerHTML;
        
        // Limpiar opciones específicas (mantener header)
        const strategyOptions = container.querySelectorAll('.strategy-checkbox:not([value="all"])');
        strategyOptions.forEach(opt => opt.parentElement.remove());

        // Agregar nuevas opciones
        strategies.forEach(strategy => {
            if (strategyData[strategy]) {
                const label = document.createElement('label');
                label.className = 'flex items-center p-2 hover:bg-gray-600 rounded cursor-pointer';
                label.innerHTML = `
                    <input type="checkbox" class="strategy-checkbox mr-2" value="${strategy}">
                    <span class="text-sm">${strategyData[strategy].icon} ${strategyData[strategy].name}</span>
                `;
                container.appendChild(label);
            }
        });

        // Re-inicializar event listeners
        this.setupMultiSelectDropdown('strategy', 'strategy-checkbox');
    }

    populateCategoryFilter(categories) {
        const container = document.getElementById('category-dropdown');
        if (!container) return;

        const categoryData = {
            'flash-loan': { name: 'Flash-Loan (4 estrategias)', icon: '💸' },
            'cross-chain': { name: 'Cross-Chain (5 estrategias)', icon: '🌐' },
            'mev-protection': { name: 'MEV-Protection (1 estrategia)', icon: '🛡️' },
            'atomic-swap': { name: 'Atomic-Swap (1 estrategia)', icon: '⚛️' }
        };

        // Mantener la opción "Todas" y el separador
        const headerHtml = container.querySelector('.p-2').innerHTML;
        
        // Limpiar opciones específicas (mantener header)
        const categoryOptions = container.querySelectorAll('.category-checkbox:not([value="all"])');
        categoryOptions.forEach(opt => opt.parentElement.remove());

        // Agregar nuevas opciones
        categories.forEach(category => {
            if (categoryData[category]) {
                const label = document.createElement('label');
                label.className = 'flex items-center p-2 hover:bg-gray-600 rounded cursor-pointer';
                label.innerHTML = `
                    <input type="checkbox" class="category-checkbox mr-2" value="${category}">
                    <span class="text-sm">${categoryData[category].icon} ${categoryData[category].name}</span>
                `;
                container.appendChild(label);
            }
        });

        // Re-inicializar event listeners
        this.setupMultiSelectDropdown('category', 'category-checkbox');
    }

    populateComplexityFilter(complexities) {
        const container = document.getElementById('complexity-dropdown');
        if (!container) return;

        const complexityData = {
            'simple': { name: 'Simple (3 estrategias)', icon: '🟢' },
            'intermediate': { name: 'Intermediate (3 estrategias)', icon: '🟡' },
            'advanced': { name: 'Advanced (2 estrategias)', icon: '🟠' },
            'expert': { name: 'Expert (3 estrategias)', icon: '🔴' }
        };

        // Mantener la opción "Todas" y el separador
        const headerHtml = container.querySelector('.p-2').innerHTML;
        
        // Limpiar opciones específicas (mantener header)
        const complexityOptions = container.querySelectorAll('.complexity-checkbox:not([value="all"])');
        complexityOptions.forEach(opt => opt.parentElement.remove());

        // Agregar nuevas opciones
        complexities.forEach(complexity => {
            if (complexityData[complexity]) {
                const label = document.createElement('label');
                label.className = 'flex items-center p-2 hover:bg-gray-600 rounded cursor-pointer';
                label.innerHTML = `
                    <input type="checkbox" class="complexity-checkbox mr-2" value="${complexity}">
                    <span class="text-sm">${complexityData[complexity].icon} ${complexityData[complexity].name}</span>
                `;
                container.appendChild(label);
            }
        });

        // Re-inicializar event listeners
        this.setupMultiSelectDropdown('complexity', 'complexity-checkbox');
    }

    async saveConfig(event) {
        event.preventDefault();
        
        // Recopilar datos del formulario
        this.config.apis.coingecko = document.getElementById('coingecko-api').value;
        this.config.apis.ethereum_rpc = document.getElementById('ethereum-rpc').value;
        this.config.apis.etherscan = document.getElementById('etherscan-api').value;
        this.config.apis.uniswap_subgraph = document.getElementById('uniswap-subgraph').value;
        this.config.trading.min_profit = parseFloat(document.getElementById('min-profit').value) || 0.5;
        this.config.trading.max_slippage = parseFloat(document.getElementById('max-slippage').value) || 0.5;
        
        // Guardar en localStorage
        this.saveConfigToStorage();
        
        // Verificar APIs
        await this.checkAPIStatus();
        
        // Ocultar modal
        this.hideConfigModal();
        
        // Mostrar confirmación
        this.showNotification('Configuración guardada', 'Las APIs han sido configuradas correctamente', 'success');
        
        // Iniciar monitoreo si está configurado
        if (this.isConfigured()) {
            this.startMonitoring();
        }
    }

    async testConfiguration() {
        const testButton = document.getElementById('test-config');
        const originalText = testButton.innerHTML;
        
        testButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Probando...';
        testButton.disabled = true;
        
        try {
            // Test CoinGecko API
            const coingeckoKey = document.getElementById('coingecko-api').value;
            if (coingeckoKey) {
                const response = await this.testCoinGeckoAPI(coingeckoKey);
                if (response) {
                    this.showNotification('CoinGecko', 'Conexión exitosa', 'success');
                } else {
                    this.showNotification('CoinGecko', 'Error en la conexión', 'error');
                }
            }
            
            // Test Ethereum RPC
            const ethRPC = document.getElementById('ethereum-rpc').value;
            if (ethRPC) {
                const response = await this.testEthereumRPC(ethRPC);
                if (response) {
                    this.showNotification('Ethereum RPC', 'Conexión exitosa', 'success');
                } else {
                    this.showNotification('Ethereum RPC', 'Error en la conexión', 'error');
                }
            }
            
        } catch (error) {
            console.error('Error testing configuration:', error);
            this.showNotification('Error', 'Error al probar la configuración', 'error');
        } finally {
            testButton.innerHTML = originalText;
            testButton.disabled = false;
        }
    }

    async testCoinGeckoAPI(apiKey) {
        try {
            const response = await fetch(`https://pro-api.coingecko.com/api/v3/ping`, {
                headers: {
                    'x-cg-pro-api-key': apiKey
                }
            });
            return response.ok;
        } catch (error) {
            console.error('CoinGecko test failed:', error);
            return false;
        }
    }

    async testEthereumRPC(rpcUrl) {
        try {
            const response = await fetch(rpcUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'eth_blockNumber',
                    params: [],
                    id: 1
                })
            });
            const data = await response.json();
            return data.result !== undefined;
        } catch (error) {
            console.error('Ethereum RPC test failed:', error);
            return false;
        }
    }

    isConfigured() {
        return this.config.apis.coingecko && 
               this.config.apis.ethereum_rpc && 
               this.config.apis.etherscan;
    }

    async checkAPIStatus() {
        const statusElement = document.getElementById('api-status');
        const configStatusElement = document.getElementById('config-status');
        
        statusElement.textContent = 'Verificando...';
        statusElement.className = 'text-2xl font-bold text-yellow-400';
        
        let activeAPIs = 0;
        const totalAPIs = 4;
        
        // Estado de cada API
        const apiStatuses = {
            coingecko: false,
            ethereum: false,
            etherscan: false,
            uniswap: false
        };
        
        // Verificar CoinGecko
        if (this.config.apis.coingecko) {
            apiStatuses.coingecko = await this.testCoinGeckoAPI(this.config.apis.coingecko);
            if (apiStatuses.coingecko) activeAPIs++;
        }
        
        // Verificar Ethereum RPC
        if (this.config.apis.ethereum_rpc) {
            apiStatuses.ethereum = await this.testEthereumRPC(this.config.apis.ethereum_rpc);
            if (apiStatuses.ethereum) activeAPIs++;
        }
        
        // Simular verificación de otras APIs
        if (this.config.apis.etherscan) {
            apiStatuses.etherscan = true;
            activeAPIs++;
        }
        
        if (this.config.apis.uniswap_subgraph) {
            apiStatuses.uniswap = true;
            activeAPIs++;
        }
        
        // Actualizar estado general
        statusElement.textContent = `${activeAPIs}/${totalAPIs}`;
        if (activeAPIs === totalAPIs) {
            statusElement.className = 'text-2xl font-bold text-green-400';
        } else if (activeAPIs > 0) {
            statusElement.className = 'text-2xl font-bold text-yellow-400';
        } else {
            statusElement.className = 'text-2xl font-bold text-red-400';
        }
        
        // Actualizar estado individual en sidebar
        this.updateConfigStatus(apiStatuses);
    }

    updateConfigStatus(statuses) {
        const configStatusElement = document.getElementById('config-status');
        
        const statusHTML = `
            <div class="flex items-center justify-between">
                <span>CoinGecko API</span>
                <span class="px-2 py-1 ${statuses.coingecko ? 'bg-green-500 bg-opacity-20 text-green-400' : 'bg-red-500 bg-opacity-20 text-red-400'} rounded text-xs">
                    ${statuses.coingecko ? 'Conectado' : 'No configurado'}
                </span>
            </div>
            <div class="flex items-center justify-between">
                <span>Ethereum RPC</span>
                <span class="px-2 py-1 ${statuses.ethereum ? 'bg-green-500 bg-opacity-20 text-green-400' : 'bg-red-500 bg-opacity-20 text-red-400'} rounded text-xs">
                    ${statuses.ethereum ? 'Conectado' : 'No configurado'}
                </span>
            </div>
            <div class="flex items-center justify-between">
                <span>Uniswap V3</span>
                <span class="px-2 py-1 ${statuses.uniswap ? 'bg-green-500 bg-opacity-20 text-green-400' : 'bg-red-500 bg-opacity-20 text-red-400'} rounded text-xs">
                    ${statuses.uniswap ? 'Conectado' : 'No configurado'}
                </span>
            </div>
        `;
        
        configStatusElement.innerHTML = statusHTML;
    }

    startMonitoring() {
        console.log('🔄 Iniciando monitoreo de oportunidades...');
        
        // Actualizar precios cada 10 segundos
        setInterval(() => {
            this.updatePrices();
        }, 10000);
        
        // Buscar oportunidades cada 30 segundos
        setInterval(() => {
            this.refreshOpportunities();
        }, 30000);
        
        // Sincronizar estado multi-chain cada 5 segundos
        this.initMultiChainStatusSync();
        
        // Primer update inmediato
        this.updatePrices();
        this.refreshOpportunities();
    }

    async updatePrices() {
        if (!this.config.apis.coingecko) return;
        
        try {
            // TODO: Implementar llamada real a CoinGecko API
            // const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true');
            // const prices = await response.json();
            // this.updatePriceDisplay(prices);
            
            // Placeholder temporal hasta implementar API real
            this.updatePriceDisplay({
                bitcoin: { usd: 0, usd_24h_change: 0 },
                ethereum: { usd: 0, usd_24h_change: 0 }
            });
            
        } catch (error) {
            console.error('Error updating prices:', error);
        }
    }

    updatePriceDisplay(prices) {
        const priceMonitor = document.getElementById('price-monitor');
        
        const btcPrice = prices.bitcoin.usd.toFixed(2);
        const btcChange = prices.bitcoin.usd_24h_change.toFixed(2);
        const ethPrice = prices.ethereum.usd.toFixed(2);
        const ethChange = prices.ethereum.usd_24h_change.toFixed(2);
        
        priceMonitor.innerHTML = `
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-xs font-bold">
                        BTC
                    </div>
                    <span>Bitcoin</span>
                </div>
                <div class="text-right">
                    <div class="font-bold">$${btcPrice}</div>
                    <div class="text-sm ${btcChange >= 0 ? 'text-green-400' : 'text-red-400'}">
                        ${btcChange >= 0 ? '+' : ''}${btcChange}%
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold">
                        ETH
                    </div>
                    <span>Ethereum</span>
                </div>
                <div class="text-right">
                    <div class="font-bold">$${ethPrice}</div>
                    <div class="text-sm ${ethChange >= 0 ? 'text-green-400' : 'text-red-400'}">
                        ${ethChange >= 0 ? '+' : ''}${ethChange}%
                    </div>
                </div>
            </div>
        `;
    }

    async refreshOpportunities() {
        const refreshButton = document.getElementById('refresh-opportunities');
        const originalHTML = refreshButton.innerHTML;
        
        refreshButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Actualizando...';
        refreshButton.disabled = true;
        
        try {
            this.showNotification(
                'Búsqueda Activa',
                'Escaneando oportunidades de arbitraje en blockchains conectadas...',
                'info'
            );
            
            // TODO: Implementar búsqueda real de oportunidades de arbitraje
            // await this.scanRealArbitrageOpportunities();
            // this.applyFilters();
            
            // Placeholder temporal hasta implementar escaneo real
            this.opportunities = [];
            this.applyFilters();
            
            this.showNotification(
                'Actualización Completa',
                `${this.opportunities.length} oportunidades encontradas`,
                'success'
            );
            
        } catch (error) {
            console.error('Error refreshing opportunities:', error);
            this.showNotification(
                'Error',
                'Error al buscar oportunidades: ' + error.message,
                'error'
            );
        } finally {
            refreshButton.innerHTML = originalHTML;
            refreshButton.disabled = false;
        }
    }

    // TODO: Implementar generación real de oportunidades de arbitraje
    // Esta función será reemplazada por scanRealArbitrageOpportunities()
    generateMockOpportunities() {
        console.warn('⚠️ generateMockOpportunities() está deprecado. Use scanRealArbitrageOpportunities() en su lugar.');
        this.opportunities = [];
        
        // TODO: Conectar con backend para obtener oportunidades reales
        // TODO: Implementar escaneo real de DEXs y exchanges
        // TODO: Calcular costos de transacción reales
        // TODO: Verificar liquidez disponible
        // TODO: Detectar oportunidades rentables basadas en precios reales
        
        console.log('🔍 TODO: Implementar escáner real de arbitraje');
    }

    getRandomBlockchain() {
        const blockchains = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism', 'avalanche', 'fantom', 'cronos'];
        return blockchains[Math.floor(Math.random() * blockchains.length)];
    }

    getRandomToken() {
        const tokens = ['ETH', 'USDC', 'USDT', 'DAI', 'WBTC', 'MATIC', 'BNB', 'AVAX'];
        return tokens[Math.floor(Math.random() * tokens.length)];
    }





    getRandomExchange(blockchain) {
        const exchanges = {
            ethereum: ['Uniswap V3', 'Uniswap V2', 'SushiSwap', '1inch', 'Curve'],
            polygon: ['QuickSwap', 'SushiSwap', 'Uniswap V3', 'Curve', 'Balancer'],
            bsc: ['PancakeSwap', 'Biswap', 'BakerySwap', 'MDEX', 'Venus'],
            arbitrum: ['Uniswap V3', 'SushiSwap', 'Balancer', 'Curve', 'GMX'],
            optimism: ['Uniswap V3', 'Synthetix', 'Curve', 'Balancer', 'Velodrome'],
            avalanche: ['Trader Joe', 'Pangolin', 'SushiSwap', 'Curve', 'Platypus'],
            fantom: ['SpookySwap', 'SushiSwap', 'Curve', 'Beethoven X', 'SpiritSwap'],
            cronos: ['VVS Finance', 'Tectonic', 'Ferro', 'MMF', 'Beefy']
        };
        
        const exchangeList = exchanges[blockchain] || ['DEX', 'Exchange'];
        return exchangeList[Math.floor(Math.random() * exchangeList.length)];
    }

    // Función eliminada - todo el código mock ha sido removido
    // TODO: Implementar sistema real de detección de arbitraje
    scanRealArbitrageOpportunities() {
        // Esta función debe implementar:
        // 1. Conexión a APIs de DEXs reales
        // 2. Comparación de precios entre exchanges
        // 3. Cálculo de costos de transacción reales
        // 4. Verificación de liquidez disponible
        // 5. Detección de oportunidades rentables
        console.log('🔍 TODO: Implementar escáner real de arbitraje');
    }
            { 
                name: 'Ethereum', 
                chainId: 1, 
                gasRange: [20, 200], 
                dexs: ['Uniswap V3', 'SushiSwap', 'Curve', 'Balancer'],
                nativeCurrency: 'ETH',
                explorer: 'https://etherscan.io'
            },
            { 
                name: 'Polygon', 
                chainId: 137, 
                gasRange: [1, 200], 
                dexs: ['QuickSwap', 'SushiSwap', 'Curve', 'Balancer'],
                nativeCurrency: 'MATIC',
                explorer: 'https://polygonscan.com'
            },
            { 
                name: 'BSC', 
                chainId: 56, 
                gasRange: [1, 50], 
                dexs: ['PancakeSwap', 'BiSwap', 'SushiSwap', 'Venus'],
                nativeCurrency: 'BNB',
                explorer: 'https://bscscan.com'
            },
            { 
                name: 'Arbitrum', 
                chainId: 42161, 
                gasRange: [0.1, 10], 
                dexs: ['Uniswap V3', 'SushiSwap', 'Curve', 'Balancer'],
                nativeCurrency: 'ETH',
                explorer: 'https://arbiscan.io'
            },
            { 
                name: 'Optimism', 
                chainId: 10, 
                gasRange: [0.1, 15], 
                dexs: ['Uniswap V3', 'SushiSwap', 'Curve', 'Velodrome'],
                nativeCurrency: 'ETH',
                explorer: 'https://optimistic.etherscan.io'
            },
            { 
                name: 'Avalanche', 
                chainId: 43114, 
                gasRange: [1, 100], 
                dexs: ['Trader Joe', 'Pangolin', 'SushiSwap', 'Curve'],
                nativeCurrency: 'AVAX',
                explorer: 'https://snowtrace.io'
            },
            { 
                name: 'Fantom', 
                chainId: 250, 
                gasRange: [1, 50], 
                dexs: ['SpookySwap', 'SpiritSwap', 'Curve', 'SushiSwap'],
                nativeCurrency: 'FTM',
                explorer: 'https://ftmscan.com'
            },
            { 
                name: 'Cronos', 
                chainId: 25, 
                gasRange: [1, 30], 
                dexs: ['VVS Finance', 'SushiSwap', 'Curve', 'Croswap'],
                nativeCurrency: 'CRO',
                explorer: 'https://cronoscan.com'
            }
        ];

        // 11 ESTRATEGIAS REALES DEL PROYECTO (from src/config/strategies.ts)
        const strategies = [
            { 
                id: 'cross-chain-multi-hop-flash-loan',
                label: 'Cross-Chain Multi-Hop Flash-Loan',
                complexity: 'expert',
                riskLevel: 'extreme',
                roi2025: 10,
                profitRange: [2.0, 2.5], // avgProfit from config
                gasMultiplier: 2.5,
                requiresFlashLoan: true,
                crossChainCompatible: true,
                supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc'],
                category: 'flash-loan',
                minCapital: 50000,
                successRate: 65,
                avgExecutionTime: 45
            },
            {
                id: 'cross-chain-cross-dex',
                label: 'Cross-Chain Cross-DEX Arbitrage',
                complexity: 'expert',
                riskLevel: 'high',
                roi2025: 9,
                profitRange: [1.2, 1.8], // avgProfit from config
                gasMultiplier: 2.0,
                requiresFlashLoan: false,
                crossChainCompatible: true,
                supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'bsc'],
                category: 'cross-chain',
                minCapital: 25000,
                successRate: 75,
                avgExecutionTime: 60
            },
            {
                id: 'flash-loan-triangular-cross-dex',
                label: 'Flash-Loan Triangular Cross-DEX',
                complexity: 'advanced',
                riskLevel: 'high',
                roi2025: 8,
                profitRange: [1.0, 1.5], // avgProfit from config
                gasMultiplier: 1.8,
                requiresFlashLoan: true,
                crossChainCompatible: false,
                supportedBlockchains: ['ethereum', 'polygon', 'arbitrum'],
                category: 'flash-loan',
                minCapital: 15000,
                successRate: 80,
                avgExecutionTime: 30
            },
            {
                id: 'multi-hop-cross-dex',
                label: 'Multi-Hop Cross-DEX Arbitrage',
                complexity: 'advanced',
                riskLevel: 'medium',
                roi2025: 7,
                profitRange: [0.8, 1.2], // avgProfit from config
                gasMultiplier: 1.5,
                requiresFlashLoan: false,
                crossChainCompatible: true,
                supportedBlockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism'],
                category: 'cross-chain',
                minCapital: 10000,
                successRate: 85,
                avgExecutionTime: 25
            },
            {
                id: 'jit-liquidity-arbitrage',
                label: 'JIT Liquidity Arbitrage',
                complexity: 'expert',
                riskLevel: 'high',
                roi2025: 6,
                profitRange: [1.5, 2.0], // avgProfit from config
                gasMultiplier: 2.2,
                requiresFlashLoan: false,
                crossChainCompatible: false,
                supportedBlockchains: ['ethereum'],
                category: 'mev-protection',
                minCapital: 20000,
                successRate: 70,
                avgExecutionTime: 15
            },
            {
                id: 'flash-loan-cross-dex',
                label: 'Flash-Loan Cross-DEX Arbitrage',
                complexity: 'intermediate',
                riskLevel: 'medium',
                roi2025: 5,
                profitRange: [0.5, 0.8], // avgProfit from config
                gasMultiplier: 1.3,
                requiresFlashLoan: true,
                crossChainCompatible: false,
                supportedBlockchains: ['ethereum', 'polygon', 'bsc'],
                category: 'flash-loan',
                minCapital: 5000,
                successRate: 90,
                avgExecutionTime: 20
            },
            {
                id: 'triangular-inter-dex',
                label: 'Triangular Inter-DEX',
                complexity: 'intermediate',
                riskLevel: 'medium',
                roi2025: 4,
                profitRange: [0.4, 0.6], // avgProfit from config
                gasMultiplier: 1.2,
                requiresFlashLoan: false,
                crossChainCompatible: false,
                supportedBlockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum'],
                category: 'cross-chain',
                minCapital: 3000,
                successRate: 92,
                avgExecutionTime: 18
            },
            {
                id: 'atomic-swap-cross-dex',
                label: 'Atomic Swap Cross-DEX',
                complexity: 'intermediate',
                riskLevel: 'low',
                roi2025: 3,
                profitRange: [0.2, 0.4], // avgProfit from config
                gasMultiplier: 1.0,
                requiresFlashLoan: false,
                crossChainCompatible: true,
                supportedBlockchains: ['ethereum', 'polygon', 'arbitrum'],
                category: 'atomic-swap',
                minCapital: 2000,
                successRate: 95,
                avgExecutionTime: 15
            },
            {
                id: 'triangular-intra-dex',
                label: 'Triangular Intra-DEX',
                complexity: 'simple',
                riskLevel: 'low',
                roi2025: 2,
                profitRange: [0.2, 0.3], // avgProfit from config
                gasMultiplier: 0.8,
                requiresFlashLoan: false,
                crossChainCompatible: false,
                supportedBlockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism'],
                category: 'cross-chain',
                minCapital: 1000,
                successRate: 96,
                avgExecutionTime: 12
            },
            {
                id: 'basic-cross-dex',
                label: 'Basic Cross-DEX Arbitrage',
                complexity: 'simple',
                riskLevel: 'low',
                roi2025: 1,
                profitRange: [0.1, 0.2], // avgProfit from config
                gasMultiplier: 0.7,
                requiresFlashLoan: false,
                crossChainCompatible: false,
                supportedBlockchains: ['polygon', 'bsc', 'arbitrum', 'optimism'],
                category: 'cross-chain',
                minCapital: 500,
                successRate: 98,
                avgExecutionTime: 10
            },
            {
                id: 'basic-flash-loan',
                label: 'Basic Flash-Loan Arbitrage',
                complexity: 'simple',
                riskLevel: 'low',
                roi2025: 0,
                profitRange: [0.05, 0.1], // avgProfit from config
                gasMultiplier: 0.6,
                requiresFlashLoan: true,
                crossChainCompatible: false,
                supportedBlockchains: ['polygon', 'bsc', 'arbitrum'],
                category: 'flash-loan',
                minCapital: 0,
                successRate: 99,
                avgExecutionTime: 8
            }
        ];

        const tokenPairs = [
            ['USDC', 'ETH'], ['WETH', 'USDT'], ['DAI', 'USDC'], ['USDC', 'WBTC'],
            ['ETH', 'USDT'], ['WMATIC', 'USDC'], ['BNB', 'BUSD'], ['AVAX', 'USDC'],
            ['FTM', 'USDC'], ['ETH', 'BASE'], ['ARB', 'ETH'], ['OP', 'ETH']
        ];

        const opportunities = [];
        const numOpportunities = Math.floor(Math.random() * 8) + 8; // 8-15 oportunidades

        for (let i = 0; i < numOpportunities; i++) {
            // Seleccionar estrategia aleatoria
            const strategy = strategies[Math.floor(Math.random() * strategies.length)];
            
            // Filtrar blockchains soportadas por la estrategia
            const supportedChains = blockchains.filter(chain => 
                strategy.supportedBlockchains.includes(chain.name.toLowerCase())
            );
            
            if (supportedChains.length === 0) continue; // Skip si no hay blockchains soportadas
            
            // Determinar si será cross-chain o intra-chain basado en la estrategia
            const isCrossChain = strategy.crossChainCompatible && 
                                 supportedChains.length > 1 && 
                                 Math.random() > 0.6;
            
            let blockchain0, blockchain1, dex0, dex1;
            
            if (isCrossChain) {
                // Cross-chain: diferentes blockchains de las soportadas
                const chain0 = supportedChains[Math.floor(Math.random() * supportedChains.length)];
                let chain1;
                do {
                    chain1 = supportedChains[Math.floor(Math.random() * supportedChains.length)];
                } while (chain1.chainId === chain0.chainId && supportedChains.length > 1);
                
                blockchain0 = chain0.name;
                blockchain1 = chain1.name;
                dex0 = chain0.dexs[Math.floor(Math.random() * chain0.dexs.length)];
                dex1 = chain1.dexs[Math.floor(Math.random() * chain1.dexs.length)];
            } else {
                // Intra-chain: misma blockchain de las soportadas
                const chain = supportedChains[Math.floor(Math.random() * supportedChains.length)];
                blockchain0 = blockchain1 = chain.name;
                
                // Asegurar DEXs diferentes en la misma blockchain
                dex0 = chain.dexs[Math.floor(Math.random() * chain.dexs.length)];
                do {
                    dex1 = chain.dexs[Math.floor(Math.random() * chain.dexs.length)];
                } while (dex1 === dex0 && chain.dexs.length > 1);
            }

            // Seleccionar par de tokens
            const tokenPair = tokenPairs[Math.floor(Math.random() * tokenPairs.length)];
            
            // Calcular métricas basadas en la estrategia
            const baseProfit = strategy.profitRange[0] + 
                Math.random() * (strategy.profitRange[1] - strategy.profitRange[0]);
            
            const blockchain0Data = blockchains.find(b => b.name === blockchain0);
            const blockchain1Data = blockchains.find(b => b.name === blockchain1);
            
            const baseGas = Math.random() * 30 + 10;
            const gasEstimate = Math.round(baseGas * strategy.gasMultiplier);
            
            const confidence = Math.floor(
                85 + Math.random() * 10 - 
                (strategy.complexity === 'expert' ? 15 : 
                 strategy.complexity === 'advanced' ? 10 : 5)
            );

            opportunities.push({
                id: `opp_${Date.now()}_${i}`,
                pair: `${tokenPair[0]}/${tokenPair[1]}`,
                dex0: dex0,
                dex1: dex1,
                blockchain0: blockchain0,
                blockchain1: blockchain1,
                chainId0: blockchain0Data.chainId,
                chainId1: blockchain1Data.chainId,
                strategy: strategy,
                profit: parseFloat(baseProfit.toFixed(3)),
                confidence: confidence,
                liquidity: Math.floor(Math.random() * 200000 + 20000),
                gasEstimate: gasEstimate,
                timestamp: Date.now(),
                isCrossChain: isCrossChain,
                requiresFlashLoan: strategy.requiresFlashLoan
            });
        }



    updateOpportunitiesDisplay() {
        const opportunitiesList = document.getElementById('opportunities-list');
        const filteredOpportunities = this.getFilteredOpportunities();
        
        if (filteredOpportunities.length === 0) {
            opportunitiesList.innerHTML = `
                <div class="text-center text-gray-400 py-8">
                    <i class="fas fa-info-circle text-4xl mb-4"></i>
                    <p>No se encontraron oportunidades que cumplan los criterios</p>
                    <p class="text-sm mt-2">Total disponibles: ${this.opportunities.length} | Filtradas: 0</p>
                </div>
            `;
            return;
        }
        
        const opportunitiesHTML = filteredOpportunities.map(opp => `
            <div class="bg-gray-700 rounded-lg p-4 hover:bg-gray-600 transition-colors slide-in">
                <div class="flex items-center justify-between mb-3">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                            <i class="fas fa-exchange-alt text-white"></i>
                        </div>
                        <div>
                            <h4 class="font-semibold">${opp.pair}</h4>
                            <div class="flex items-center space-x-2 text-sm text-gray-400 mb-1">
                                <span>${opp.dex0}</span>
                                <span class="blockchain-badge blockchain-${opp.blockchain0.toLowerCase()}">${opp.blockchain0}</span>
                                <i class="fas fa-arrow-right"></i>
                                <span>${opp.dex1}</span>
                                <span class="blockchain-badge blockchain-${opp.blockchain1.toLowerCase()}">${opp.blockchain1}</span>
                            </div>
                            <div class="text-xs text-gray-500">
                                <span class="strategy-badge strategy-${opp.strategy.complexity}">${opp.strategy.label}</span>
                                ${opp.strategy.requiresFlashLoan ? '<span class="ml-2 px-1 py-0.5 bg-yellow-500 bg-opacity-20 text-yellow-400 rounded text-xs">⚡ Flash Loan</span>' : ''}
                            </div>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="text-lg font-bold text-green-400">+${opp.profit}%</div>
                        <div class="text-sm text-gray-400">${opp.confidence}% confianza</div>
                    </div>
                </div>
                <div class="grid grid-cols-4 gap-3 text-sm">
                    <div>
                        <span class="text-gray-400">Liquidez:</span>
                        <div class="font-medium">$${opp.liquidity.toLocaleString()}</div>
                    </div>
                    <div>
                        <span class="text-gray-400">Gas Est.:</span>
                        <div class="font-medium">${opp.gasEstimate} gwei</div>
                    </div>
                    <div>
                        <span class="text-gray-400">Tipo:</span>
                        <div class="font-medium">
                            <span class="${opp.blockchain0 === opp.blockchain1 ? 'intra-chain-indicator' : 'cross-chain-indicator'}">
                                ${opp.blockchain0 === opp.blockchain1 ? '🔗 Intra-chain' : '🌉 Cross-chain'}
                            </span>
                        </div>
                    </div>
                    <div>
                        <button class="w-full px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded text-white transition-colors" 
                                onclick="app.executeOpportunity('${opp.id}')">
                            Ejecutar
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
        
        opportunitiesList.innerHTML = opportunitiesHTML;
    }

    updateStats() {
        // Actualizar estadísticas
        document.getElementById('active-opportunities').textContent = this.opportunities.length;
        
        // Simular ganancias del día
        const dailyProfit = (Math.random() * 500 + 100).toFixed(2);
        document.getElementById('daily-profit').textContent = `$${dailyProfit}`;
        
        // Simular win rate
        const winRate = Math.floor(Math.random() * 30 + 70);
        document.getElementById('win-rate').textContent = `${winRate}%`;
    }

    async executeOpportunity(opportunityId) {
        const opportunity = this.opportunities.find(opp => opp.id === opportunityId);
        if (!opportunity) return;
        
        const issCrossChain = opportunity.blockchain0 !== opportunity.blockchain1;
        const blockchainInfo = issCrossChain ? 
            `${opportunity.blockchain0} → ${opportunity.blockchain1}` : 
            opportunity.blockchain0;
            
        this.showNotification(
            'Ejecutando arbitraje', 
            `${opportunity.pair} en ${blockchainInfo} (${issCrossChain ? 'Cross-chain' : 'Intra-chain'})`, 
            'info'
        );
        
        // Simular ejecución
        setTimeout(() => {
            const success = Math.random() > 0.2; // 80% success rate
            if (success) {
                this.showNotification(
                    'Arbitraje exitoso', 
                    `Profit: +${opportunity.profit}% en ${opportunity.pair} (${blockchainInfo})`, 
                    'success'
                );
                this.addToRecentActivity(
                    `Arbitraje ejecutado: ${opportunity.pair}`, 
                    `${blockchainInfo} - Profit: +${opportunity.profit}%`
                );
            } else {
                this.showNotification(
                    'Arbitraje fallido', 
                    `Error al ejecutar ${opportunity.pair} en ${blockchainInfo}`, 
                    'error'
                );
                this.addToRecentActivity(
                    `Arbitraje fallido: ${opportunity.pair}`, 
                    `${blockchainInfo} - Error en ejecución`
                );
            }
        }, 3000);
    }

    toggleAutoTrade() {
        this.isAutoTradeEnabled = !this.isAutoTradeEnabled;
        const button = document.getElementById('auto-trade-toggle');
        
        if (this.isAutoTradeEnabled) {
            button.innerHTML = '<i class="fas fa-robot mr-2"></i>Auto Trade: ON';
            button.className = 'px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-sm transition-colors';
            this.showNotification('Auto Trade activado', 'El sistema ejecutará oportunidades automáticamente', 'success');
        } else {
            button.innerHTML = '<i class="fas fa-robot mr-2"></i>Auto Trade: OFF';
            button.className = 'px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded-lg text-sm transition-colors';
            this.showNotification('Auto Trade desactivado', 'Ejecución manual activada', 'info');
        }
    }

    addToRecentActivity(title, description) {
        const activityElement = document.getElementById('recent-activity');
        const timestamp = new Date().toLocaleTimeString();
        
        const activityHTML = `
            <div class="border-b border-gray-700 pb-2 mb-2">
                <div class="font-medium">${title}</div>
                <div class="text-gray-400">${description}</div>
                <div class="text-xs text-gray-500 mt-1">${timestamp}</div>
            </div>
        `;
        
        activityElement.insertAdjacentHTML('afterbegin', activityHTML);
        
        // Limitar a 5 actividades
        const activities = activityElement.children;
        if (activities.length > 5) {
            activityElement.removeChild(activities[activities.length - 1]);
        }
        
        // Remover el mensaje de "sin actividad"
        const noActivity = activityElement.querySelector('.text-center');
        if (noActivity) {
            noActivity.remove();
        }
    }

    showConfigModal() {
        document.getElementById('config-modal').classList.remove('hidden');
    }

    hideConfigModal() {
        document.getElementById('config-modal').classList.add('hidden');
    }

    showNotification(title, message, type = 'info') {
        const notification = document.getElementById('notification');
        const icon = document.getElementById('notification-icon');
        const titleElement = document.getElementById('notification-title');
        const messageElement = document.getElementById('notification-message');
        
        // Configurar íconos y colores según el tipo
        const configs = {
            success: {
                icon: 'fas fa-check-circle',
                color: 'bg-green-500 text-white'
            },
            error: {
                icon: 'fas fa-exclamation-circle', 
                color: 'bg-red-500 text-white'
            },
            warning: {
                icon: 'fas fa-exclamation-triangle',
                color: 'bg-yellow-500 text-black'
            },
            info: {
                icon: 'fas fa-info-circle',
                color: 'bg-blue-500 text-white'
            }
        };
        
        const config = configs[type] || configs.info;
        
        icon.className = `w-6 h-6 flex items-center justify-center rounded-full ${config.color}`;
        icon.innerHTML = `<i class="${config.icon}"></i>`;
        titleElement.textContent = title;
        messageElement.textContent = message;
        
        notification.classList.remove('hidden');
        
        // Auto-hide después de 5 segundos
        setTimeout(() => {
            this.hideNotification();
        }, 5000);
    }

    hideNotification() {
        document.getElementById('notification').classList.add('hidden');
    }

    getBlockchainColor(blockchain) {
        const colors = {
            'Ethereum': 'blue-500',
            'Polygon': 'purple-500',
            'BSC': 'yellow-500',
            'Arbitrum': 'indigo-500',
            'Optimism': 'red-500',
            'Avalanche': 'red-600',
            'Fantom': 'blue-400',
            'Cronos': 'blue-900'
        };
        return colors[blockchain] || 'gray-500';
    }

    getBlockchainIcon(blockchain) {
        const icons = {
            'Ethereum': 'fab fa-ethereum',
            'Polygon': 'fas fa-hexagon',
            'BSC': 'fas fa-coins',
            'Arbitrum': 'fas fa-layer-group',
            'Optimism': 'fas fa-bolt',
            'Avalanche': 'fas fa-mountain'
        };
        return icons[blockchain] || 'fas fa-link';
    }

    getFilteredOpportunities() {
        const minProfitFilter = parseFloat(document.getElementById('min-profit-filter')?.value || 0);
        
        // Obtener valores seleccionados de filtros multiselect
        const selectedBlockchains = this.getSelectedMultiValues('blockchain-checkbox');
        const selectedStrategies = this.getSelectedMultiValues('strategy-checkbox');
        const selectedCategories = this.getSelectedMultiValues('category-checkbox');
        const selectedComplexities = this.getSelectedMultiValues('complexity-checkbox');
        
        return this.opportunities.filter(opp => {
            // Filtro de profit
            if (opp.profit < minProfitFilter) return false;
            
            // Filtro de blockchains seleccionadas
            if (!selectedBlockchains.includes('all') && selectedBlockchains.length > 0) {
                let blockchainMatch = false;
                
                for (const blockchain of selectedBlockchains) {
                    switch (blockchain) {
                        case 'cross-chain':
                            if (opp.blockchain0 !== opp.blockchain1) blockchainMatch = true;
                            break;
                        case 'intra-chain':
                            if (opp.blockchain0 === opp.blockchain1) blockchainMatch = true;
                            break;
                        case 'ethereum':
                            if (opp.blockchain0 === 'Ethereum' || opp.blockchain1 === 'Ethereum') blockchainMatch = true;
                            break;
                        case 'polygon':
                            if (opp.blockchain0 === 'Polygon' || opp.blockchain1 === 'Polygon') blockchainMatch = true;
                            break;
                        case 'bsc':
                            if (opp.blockchain0 === 'BSC' || opp.blockchain1 === 'BSC') blockchainMatch = true;
                            break;
                        case 'arbitrum':
                            if (opp.blockchain0 === 'Arbitrum' || opp.blockchain1 === 'Arbitrum') blockchainMatch = true;
                            break;
                        case 'optimism':
                            if (opp.blockchain0 === 'Optimism' || opp.blockchain1 === 'Optimism') blockchainMatch = true;
                            break;
                        case 'avalanche':
                            if (opp.blockchain0 === 'Avalanche' || opp.blockchain1 === 'Avalanche') blockchainMatch = true;
                            break;
                        case 'fantom':
                            if (opp.blockchain0 === 'Fantom' || opp.blockchain1 === 'Fantom') blockchainMatch = true;
                            break;
                        case 'cronos':
                            if (opp.blockchain0 === 'Cronos' || opp.blockchain1 === 'Cronos') blockchainMatch = true;
                            break;
                    }
                    if (blockchainMatch) break;
                }
                
                if (!blockchainMatch) return false;
            }
            
            // Filtro por estrategias seleccionadas
            if (!selectedStrategies.includes('all') && selectedStrategies.length > 0) {
                if (!selectedStrategies.includes(opp.strategy.id)) return false;
            }
            
            // Filtro por categorías seleccionadas
            if (!selectedCategories.includes('all') && selectedCategories.length > 0) {
                if (!selectedCategories.includes(opp.strategy.category)) return false;
            }
            
            // Filtro por complejidades seleccionadas
            if (!selectedComplexities.includes('all') && selectedComplexities.length > 0) {
                if (!selectedComplexities.includes(opp.strategy.complexity)) return false;
            }
            
            return true;
        });
    }

    applyFilters() {
        this.updateOpportunitiesDisplay();
        
        const filtered = this.getFilteredOpportunities();
        const total = this.opportunities.length;
        
        if (filtered.length !== total) {
            this.showNotification(
                'Filtros aplicados',
                `Mostrando ${filtered.length} de ${total} oportunidades`,
                'info'
            );
        }
    }

    getFilteredOpportunities() {
        let filtered = [...this.opportunities];
        
        // Filtro de profit mínimo
        const minProfit = parseFloat(document.getElementById('min-profit-filter')?.value) || 0;
        filtered = filtered.filter(opp => opp.profit >= minProfit);
        
        // Filtro de blockchain
        const selectedBlockchains = this.getSelectedMultiValues('blockchain-checkbox');
        if (selectedBlockchains.length > 0 && !selectedBlockchains.includes('all')) {
            filtered = filtered.filter(opp => {
                // Incluir si alguna blockchain coincide
                return selectedBlockchains.some(blockchain => {
                    if (blockchain === 'cross-chain') {
                        return opp.type === 'cross-chain';
                    } else if (blockchain === 'intra-chain') {
                        return opp.type === 'intra-chain';
                    } else {
                        return opp.blockchain1 === blockchain || opp.blockchain2 === blockchain;
                    }
                });
            });
        }
        
        // Filtro de estrategia
        const selectedStrategies = this.getSelectedMultiValues('strategy-checkbox');
        if (selectedStrategies.length > 0 && !selectedStrategies.includes('all')) {
            filtered = filtered.filter(opp => selectedStrategies.includes(opp.strategy));
        }
        
        // Filtro de categoría
        const selectedCategories = this.getSelectedMultiValues('category-checkbox');
        if (selectedCategories.length > 0 && !selectedCategories.includes('all')) {
            filtered = filtered.filter(opp => selectedCategories.includes(opp.category));
        }
        
        // Filtro de complejidad
        const selectedComplexities = this.getSelectedMultiValues('complexity-checkbox');
        if (selectedComplexities.length > 0 && !selectedComplexities.includes('all')) {
            filtered = filtered.filter(opp => selectedComplexities.includes(opp.complexity));
        }
        
        return filtered;
    }

    updateOpportunitiesDisplay() {
        const container = document.getElementById('opportunities-list');
        if (!container) return;
        
        const filtered = this.getFilteredOpportunities();
        
        if (filtered.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12">
                    <i class="fas fa-search text-6xl text-gray-600 mb-4"></i>
                    <h3 class="text-xl font-bold text-gray-400 mb-2">No se encontraron oportunidades</h3>
                    <p class="text-gray-500">Ajusta los filtros o actualiza la búsqueda</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = filtered.map(opportunity => this.createOpportunityCard(opportunity)).join('');
        this.updateStats();
    }

    createOpportunityCard(opportunity) {
        const complexityColors = {
            simple: 'bg-green-500',
            intermediate: 'bg-yellow-500', 
            advanced: 'bg-orange-500',
            expert: 'bg-red-500'
        };
        
        const categoryIcons = {
            'flash-loan': 'fa-bolt',
            'cross-chain': 'fa-link',
            'mev-protection': 'fa-shield-alt',
            'atomic-swap': 'fa-atom'
        };
        
        return `
            <div class="opportunity-card bg-gray-800 rounded-lg p-4 border border-gray-700 hover:border-blue-500 transition-all cursor-pointer">
                <div class="flex justify-between items-start mb-3">
                    <div class="flex items-center space-x-2">
                        <span class="blockchain-badge blockchain-${opportunity.blockchain1}">${opportunity.blockchain1.toUpperCase()}</span>
                        ${opportunity.blockchain2 !== opportunity.blockchain1 ? 
                            `<i class="fas fa-arrow-right text-gray-400"></i>
                             <span class="blockchain-badge blockchain-${opportunity.blockchain2}">${opportunity.blockchain2.toUpperCase()}</span>` 
                            : ''}
                    </div>
                    <div class="text-right">
                        <div class="text-2xl font-bold text-green-400">+${opportunity.profit}%</div>
                        <div class="text-xs text-gray-400">Ganancia</div>
                    </div>
                </div>
                
                <div class="flex items-center justify-between mb-2">
                    <h3 class="font-semibold text-white truncate">${opportunity.strategyLabel}</h3>
                    <div class="flex items-center space-x-2">
                        <span class="complexity-badge ${complexityColors[opportunity.complexity]} text-white text-xs px-2 py-1 rounded">
                            ${opportunity.complexity}
                        </span>
                        <i class="fas ${categoryIcons[opportunity.category]} text-blue-400"></i>
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-2 text-sm text-gray-300 mb-3">
                    <div><span class="text-gray-500">Token:</span> ${opportunity.token}</div>
                    <div><span class="text-gray-500">Gas:</span> $${opportunity.gasEstimate}</div>
                    <div><span class="text-gray-500">Volumen:</span> $${opportunity.volume.toLocaleString()}</div>
                    <div><span class="text-gray-500">Ventana:</span> ${opportunity.timeWindow}s</div>
                </div>
                
                <div class="flex justify-between items-center">
                    <div class="text-xs text-gray-400">
                        ${opportunity.exchange1} → ${opportunity.exchange2}
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-xs px-2 py-1 bg-blue-600 rounded">Confianza: ${opportunity.confidence}%</span>
                        ${opportunity.requiresFlashLoan ? '<i class="fas fa-bolt text-yellow-400" title="Requiere Flash Loan"></i>' : ''}
                    </div>
                </div>
            </div>
        `;
    }

    updateStats() {
        const filtered = this.getFilteredOpportunities();
        
        // Actualizar contador de oportunidades
        const opportunitiesCount = document.getElementById('active-opportunities');
        if (opportunitiesCount) {
            opportunitiesCount.textContent = filtered.length;
        }
        
        // Calcular ganancias estimadas del día
        const totalProfitToday = filtered.reduce((sum, opp) => {
            return sum + (opp.profit * opp.volume / 100); // Profit % * Volume
        }, 0);
        
        const dailyProfit = document.getElementById('daily-profit');
        if (dailyProfit) {
            dailyProfit.textContent = `$${totalProfitToday.toFixed(2)}`;
        }
        
        // Calcular win rate promedio
        const avgConfidence = filtered.length > 0 
            ? filtered.reduce((sum, opp) => sum + opp.confidence, 0) / filtered.length 
            : 0;
            
        const winRate = document.getElementById('win-rate');
        if (winRate) {
            winRate.textContent = `${avgConfidence.toFixed(0)}%`;
        }
    }

    // Alias para compatibilidad
    renderOpportunities() {
        this.updateOpportunitiesDisplay();
    }

    initMultiSelectDropdowns() {
        // Configurar dropdown de blockchains
        this.setupMultiSelectDropdown('blockchain', 'blockchain-checkbox');
        
        // Configurar dropdown de estrategias
        this.setupMultiSelectDropdown('strategy', 'strategy-checkbox');
        
        // Configurar dropdown de categorías  
        this.setupMultiSelectDropdown('category', 'category-checkbox');
        
        // Configurar dropdown de complejidad
        this.setupMultiSelectDropdown('complexity', 'complexity-checkbox');
    }

    setupMultiSelectDropdown(filterType, checkboxClass) {
        const dropdownBtn = document.getElementById(`${filterType}-dropdown-btn`);
        const dropdown = document.getElementById(`${filterType}-dropdown`);
        const selectedText = document.getElementById(`${filterType}-selected-text`);
        const checkboxes = document.querySelectorAll(`.${checkboxClass}`);

        if (!dropdownBtn || !dropdown || !selectedText) return;

        // Abrir/cerrar dropdown
        dropdownBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            // Cerrar otros dropdowns
            document.querySelectorAll('[id$="-dropdown"]').forEach(otherDropdown => {
                if (otherDropdown !== dropdown) {
                    otherDropdown.classList.add('hidden');
                }
            });
            dropdown.classList.toggle('hidden');
        });

        // Cerrar dropdown al hacer clic fuera
        document.addEventListener('click', (e) => {
            if (!dropdown.contains(e.target) && !dropdownBtn.contains(e.target)) {
                dropdown.classList.add('hidden');
            }
        });

        // Manejar selección de checkboxes
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.handleMultiSelectChange(filterType, checkboxClass);
                this.applyFilters();
            });
        });
    }

    handleMultiSelectChange(filterType, checkboxClass) {
        const checkboxes = document.querySelectorAll(`.${checkboxClass}`);
        const selectedText = document.getElementById(`${filterType}-selected-text`);
        const allCheckbox = document.querySelector(`.${checkboxClass}[value="all"]`);
        
        const selectedValues = Array.from(checkboxes)
            .filter(cb => cb.checked && cb.value !== 'all')
            .map(cb => cb.value);

        // Si se selecciona "Todas", desmarcar específicas
        if (allCheckbox.checked) {
            checkboxes.forEach(cb => {
                if (cb.value !== 'all') cb.checked = false;
            });
            selectedText.textContent = allCheckbox.nextElementSibling.textContent.replace('✅ ', '');
        } 
        // Si se selecciona alguna específica, desmarcar "Todas"
        else if (selectedValues.length > 0) {
            allCheckbox.checked = false;
            
            if (selectedValues.length === 1) {
                const selectedCheckbox = document.querySelector(`.${checkboxClass}[value="${selectedValues[0]}"]`);
                selectedText.textContent = selectedCheckbox.nextElementSibling.textContent;
            } else {
                selectedText.textContent = `${selectedValues.length} seleccionadas`;
            }
        }
        // Si no hay nada seleccionado, marcar "Todas"
        else {
            allCheckbox.checked = true;
            selectedText.textContent = allCheckbox.nextElementSibling.textContent.replace('✅ ', '');
        }
    }

    getSelectedMultiValues(checkboxClass) {
        const checkboxes = document.querySelectorAll(`.${checkboxClass}`);
        const allCheckbox = document.querySelector(`.${checkboxClass}[value="all"]`);
        
        if (allCheckbox && allCheckbox.checked) {
            return ['all'];
        }
        
        return Array.from(checkboxes)
            .filter(cb => cb.checked && cb.value !== 'all')
            .map(cb => cb.value);
    }

    // ========================
    // Multi-Chain Status Sync
    // ========================
    
    initMultiChainStatusSync() {
        // Estado inicial
        this.connectedChains = 0;
        
        // FORZAR LECTURA INMEDIATA
        this.forceReadConnections();
        
        // Intervalo cada segundo (más agresivo)
        setInterval(() => {
            this.forceReadConnections();
        }, 1000);
        
        // Escuchar cambios
        window.addEventListener('storage', (e) => {
            if (e.key === 'arbitragex_blockchain_connections') {
                console.log('🔄 STORAGE CHANGED - Leyendo inmediatamente');
                this.forceReadConnections();
            }
        });
        
        // Custom events
        window.addEventListener('blockchainConnectionsChanged', (e) => {
            console.log('⚡ CUSTOM EVENT - Leyendo inmediatamente');
            this.forceReadConnections();
        });
        
        // NUCLEAR OPTION: Detectar cuando la ventana vuelve a tener foco
        window.addEventListener('focus', () => {
            console.log('👁️ WINDOW FOCUS - Forzando lectura');
            this.forceReadConnections();
        });
        
        // También cuando se hace visible la pestaña
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                console.log('👁️ TAB VISIBLE - Forzando lectura');
                this.forceReadConnections();
            }
        });
    }

    forceReadConnections() {
        console.log('🔍 FORCE READ - Verificando localStorage...');
        
        const saved = localStorage.getItem('arbitragex_blockchain_connections');
        
        if (saved) {
            try {
                const data = JSON.parse(saved);
                if (data.blockchainConnections) {
                    const connected = Object.values(data.blockchainConnections).filter(conn => conn.connected === true).length;
                    console.log('🔢 CONEXIONES ENCONTRADAS:', connected);
                    
                    this.connectedChains = connected;
                    this.updateChainCounter();
                    return;
                }
            } catch (e) {
                console.error('❌ Error parseando:', e);
            }
        }
        
        // Si llegamos aquí, no hay datos válidos
        console.log('📭 SIN DATOS VÁLIDOS');
        this.connectedChains = 0;
        this.updateChainCounter();
    }

    // Función legacy para compatibilidad
    checkMultiChainStatus() {
        this.forceReadConnections();
    }

    updateChainCounter() {
        const counterElement = document.getElementById('connected-chains-count');
        if (counterElement) {
            counterElement.textContent = `${this.connectedChains}/8`;
            
            // Cambiar color según número de conexiones
            const indicator = counterElement.parentElement.querySelector('.fas');
            if (this.connectedChains === 8) {
                indicator.className = 'fas fa-network-wired text-green-400';
                counterElement.className = 'text-xs font-bold text-green-300';
            } else if (this.connectedChains > 0) {
                indicator.className = 'fas fa-network-wired text-yellow-400';
                counterElement.className = 'text-xs font-bold text-yellow-300';
            } else {
                indicator.className = 'fas fa-network-wired text-red-400';
                counterElement.className = 'text-xs font-bold text-red-300';
            }
        }
    }

    async loadFilterOptionsFromBackend() {
        console.log('🔄 Cargando opciones de filtros desde el backend...');
        
        try {
            // Intentar cargar desde el backend
            const filterOptions = await this.fetchFilterOptionsFromBackend();
            if (filterOptions) {
                this.populateFiltersWithBackendData(filterOptions);
                console.log('✅ Filtros poblados desde el backend');
            } else {
                // Fallback a datos locales si el backend no responde
                console.log('⚠️ Backend no disponible, usando datos locales');
                this.populateFiltersWithLocalData();
            }
        } catch (error) {
            console.error('❌ Error cargando filtros desde backend:', error);
            console.log('🔄 Usando datos locales como fallback');
            this.populateFiltersWithLocalData();
        }
    }

    async fetchFilterOptionsFromBackend() {
        try {
            // Intentar obtener desde el Contract Watcher si está disponible
            if (window.contractWatcher && window.contractWatcher.getState) {
                const state = window.contractWatcher.getState();
                if (state.contractData) {
                    return this.extractFilterOptionsFromContract(state.contractData);
                }
            }

            // Intentar obtener desde endpoints del backend
            const endpoints = [
                '/api/filters/options',
                '/api/strategies',
                '/api/blockchains',
                '/api/categories',
                '/api/complexities'
            ];

            for (const endpoint of endpoints) {
                try {
                    const response = await fetch(endpoint);
                    if (response.ok) {
                        const data = await response.json();
                        console.log(`✅ Datos obtenidos de ${endpoint}:`, data);
                        return data;
                    }
                } catch (e) {
                    console.log(`⚠️ Endpoint ${endpoint} no disponible`);
                }
            }

            return null;
        } catch (error) {
            console.error('❌ Error en fetchFilterOptionsFromBackend:', error);
            return null;
        }
    }

    extractFilterOptionsFromContract(contractData) {
        try {
            // Extraer opciones de filtros desde los datos del contrato OpenAPI
            const options = {
                blockchains: [],
                strategies: [],
                categories: [],
                complexities: []
            };

            if (contractData.paths) {
                // Extraer blockchains desde endpoints como /api/blockchains/{chain}/status
                const blockchainPaths = Object.keys(contractData.paths).filter(path => 
                    path.includes('/blockchains/') || path.includes('/chains/')
                );
                
                blockchainPaths.forEach(path => {
                    const chain = path.split('/').pop();
                    if (chain && !options.blockchains.includes(chain)) {
                        options.blockchains.push(chain);
                    }
                });

                // Extraer estrategias desde endpoints como /api/strategies/{strategy}
                const strategyPaths = Object.keys(contractData.paths).filter(path => 
                    path.includes('/strategies/') || path.includes('/arbitrage/')
                );
                
                strategyPaths.forEach(path => {
                    const strategy = path.split('/').pop();
                    if (strategy && !options.strategies.includes(strategy)) {
                        options.strategies.push(strategy);
                    }
                });
            }

            // Si no hay datos suficientes del contrato, usar datos por defecto
            if (options.blockchains.length === 0) {
                options.blockchains = ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism', 'avalanche', 'fantom', 'cronos'];
            }
            
            if (options.strategies.length === 0) {
                options.strategies = [
                    'cross-chain-multi-hop-flash-loan',
                    'cross-chain-cross-dex',
                    'flash-loan-triangular-cross-dex',
                    'multi-hop-cross-dex',
                    'jit-liquidity-arbitrage',
                    'flash-loan-cross-dex',
                    'triangular-inter-dex',
                    'atomic-swap-cross-dex',
                    'triangular-intra-dex',
                    'basic-cross-dex',
                    'basic-flash-loan'
                ];
            }

            // Categorías y complejidades basadas en las estrategias
            options.categories = ['flash-loan', 'cross-chain', 'mev-protection', 'atomic-swap'];
            options.complexities = ['simple', 'intermediate', 'advanced', 'expert'];

            return options;
        } catch (error) {
            console.error('❌ Error extrayendo opciones del contrato:', error);
            return null;
        }
    }

    populateFiltersWithBackendData(filterOptions) {
        if (!filterOptions) return;

        // Poblar filtro de blockchains
        if (filterOptions.blockchains && filterOptions.blockchains.length > 0) {
            this.populateBlockchainFilter(filterOptions.blockchains);
        }

        // Poblar filtro de estrategias
        if (filterOptions.strategies && filterOptions.strategies.length > 0) {
            this.populateStrategyFilter(filterOptions.strategies);
        }

        // Poblar filtro de categorías
        if (filterOptions.categories && filterOptions.categories.length > 0) {
            this.populateCategoryFilter(filterOptions.categories);
        }

        // Poblar filtro de complejidades
        if (filterOptions.complexities && filterOptions.complexities.length > 0) {
            this.populateComplexityFilter(filterOptions.complexities);
        }
    }

    populateFiltersWithLocalData() {
        console.log('🔄 Poblando filtros con datos locales...');
        
        // Datos locales como fallback
        const localData = {
            blockchains: ['ethereum', 'polygon', 'bsc', 'arbitrum', 'optimism', 'avalanche', 'fantom', 'cronos'],
            strategies: [
                'cross-chain-multi-hop-flash-loan',
                'cross-chain-cross-dex',
                'flash-loan-triangular-cross-dex',
                'multi-hop-cross-dex',
                'jit-liquidity-arbitrage',
                'flash-loan-cross-dex',
                'triangular-inter-dex',
                'atomic-swap-cross-dex',
                'triangular-intra-dex',
                'basic-cross-dex',
                'basic-flash-loan'
            ],
            categories: ['flash-loan', 'cross-chain', 'mev-protection', 'atomic-swap'],
            complexities: ['simple', 'intermediate', 'advanced', 'expert']
        };

        this.populateFiltersWithBackendData(localData);
    }

    populateBlockchainFilter(blockchains) {
        const container = document.getElementById('blockchain-dropdown');
        if (!container) return;

        const blockchainData = {
            'ethereum': { name: 'Ethereum (ETH)', icon: '🔷' },
            'polygon': { name: 'Polygon (MATIC)', icon: '🟣' },
            'bsc': { name: 'BSC (BNB)', icon: '🟡' },
            'arbitrum': { name: 'Arbitrum (ARB)', icon: '🔵' },
            'optimism': { name: 'Optimism (OP)', icon: '🔴' },
            'avalanche': { name: 'Avalanche (AVAX)', icon: '⚪' },
            'fantom': { name: 'Fantom (FTM)', icon: '👻' },
            'cronos': { name: 'Cronos (CRO)', icon: '💎' }
        };

        // Mantener la opción "Todas" y el separador
        const headerHtml = container.querySelector('.p-2').innerHTML;
        
        // Limpiar opciones específicas (mantener header)
        const blockchainOptions = container.querySelectorAll('.blockchain-checkbox:not([value="all"]):not([value="cross-chain"]):not([value="intra-chain"])');
        blockchainOptions.forEach(opt => opt.parentElement.remove());

        // Agregar nuevas opciones
        blockchains.forEach(blockchain => {
            if (blockchainData[blockchain]) {
                const label = document.createElement('label');
                label.className = 'flex items-center p-2 hover:bg-gray-600 rounded cursor-pointer';
                label.innerHTML = `
                    <input type="checkbox" class="blockchain-checkbox mr-2" value="${blockchain}">
                    <span class="text-sm">${blockchainData[blockchain].icon} ${blockchainData[blockchain].name}</span>
                `;
                
                // Insertar antes del separador de tipos de operación
                const operationSeparator = container.querySelector('.text-xs.text-gray-400:contains("TIPOS DE OPERACIÓN")');
                if (operationSeparator) {
                    operationSeparator.parentElement.insertBefore(label, operationSeparator.parentElement);
                } else {
                    container.appendChild(label);
                }
            }
        });

        // Re-inicializar event listeners
        this.setupMultiSelectDropdown('blockchain', 'blockchain-checkbox');
    }

    populateStrategyFilter(strategies) {
        const container = document.getElementById('strategy-dropdown');
        if (!container) return;

        const strategyData = {
            'cross-chain-multi-hop-flash-loan': { name: 'Cross-Chain Multi-Hop Flash-Loan', icon: '🚀' },
            'cross-chain-cross-dex': { name: 'Cross-Chain Cross-DEX Arbitrage', icon: '🌐' },
            'flash-loan-triangular-cross-dex': { name: 'Flash-Loan Triangular Cross-DEX', icon: '⚡' },
            'multi-hop-cross-dex': { name: 'Multi-Hop Cross-DEX Arbitrage', icon: '🔄' },
            'jit-liquidity-arbitrage': { name: 'JIT Liquidity Arbitrage', icon: '🛡️' },
            'flash-loan-cross-dex': { name: 'Flash-Loan Cross-DEX Arbitrage', icon: '💸' },
            'triangular-inter-dex': { name: 'Triangular Inter-DEX', icon: '🔺' },
            'atomic-swap-cross-dex': { name: 'Atomic Swap Cross-DEX', icon: '⚛️' },
            'triangular-intra-dex': { name: 'Triangular Intra-DEX', icon: '📐' },
            'basic-cross-dex': { name: 'Basic Cross-DEX Arbitrage', icon: '🔄' },
            'basic-flash-loan': { name: 'Basic Flash-Loan Arbitrage', icon: '💰' }
        };

        // Mantener la opción "Todas" y el separador
        const headerHtml = container.querySelector('.p-2').innerHTML;
        
        // Limpiar opciones específicas (mantener header)
        const strategyOptions = container.querySelectorAll('.strategy-checkbox:not([value="all"])');
        strategyOptions.forEach(opt => opt.parentElement.remove());

        // Agregar nuevas opciones
        strategies.forEach(strategy => {
            if (strategyData[strategy]) {
                const label = document.createElement('label');
                label.className = 'flex items-center p-2 hover:bg-gray-600 rounded cursor-pointer';
                label.innerHTML = `
                    <input type="checkbox" class="strategy-checkbox mr-2" value="${strategy}">
                    <span class="text-sm">${strategyData[strategy].icon} ${strategyData[strategy].name}</span>
                `;
                container.appendChild(label);
            }
        });

        // Re-inicializar event listeners
        this.setupMultiSelectDropdown('strategy', 'strategy-checkbox');
    }

    populateCategoryFilter(categories) {
        const container = document.getElementById('category-dropdown');
        if (!container) return;

        const categoryData = {
            'flash-loan': { name: 'Flash-Loan (4 estrategias)', icon: '💸' },
            'cross-chain': { name: 'Cross-Chain (5 estrategias)', icon: '🌐' },
            'mev-protection': { name: 'MEV-Protection (1 estrategia)', icon: '🛡️' },
            'atomic-swap': { name: 'Atomic-Swap (1 estrategia)', icon: '⚛️' }
        };

        // Mantener la opción "Todas" y el separador
        const headerHtml = container.querySelector('.p-2').innerHTML;
        
        // Limpiar opciones específicas (mantener header)
        const categoryOptions = container.querySelectorAll('.category-checkbox:not([value="all"])');
        categoryOptions.forEach(opt => opt.parentElement.remove());

        // Agregar nuevas opciones
        categories.forEach(category => {
            if (categoryData[category]) {
                const label = document.createElement('label');
                label.className = 'flex items-center p-2 hover:bg-gray-600 rounded cursor-pointer';
                label.innerHTML = `
                    <input type="checkbox" class="category-checkbox mr-2" value="${category}">
                    <span class="text-sm">${categoryData[category].icon} ${categoryData[category].name}</span>
                `;
                container.appendChild(label);
            }
        });

        // Re-inicializar event listeners
        this.setupMultiSelectDropdown('category', 'category-checkbox');
    }

    populateComplexityFilter(complexities) {
        const container = document.getElementById('complexity-dropdown');
        if (!container) return;

        const complexityData = {
            'simple': { name: 'Simple (3 estrategias)', icon: '🟢' },
            'intermediate': { name: 'Intermediate (3 estrategias)', icon: '🟡' },
            'advanced': { name: 'Advanced (2 estrategias)', icon: '🟠' },
            'expert': { name: 'Expert (3 estrategias)', icon: '🔴' }
        };

        // Mantener la opción "Todas" y el separador
        const headerHtml = container.querySelector('.p-2').innerHTML;
        
        // Limpiar opciones específicas (mantener header)
        const complexityOptions = container.querySelectorAll('.complexity-checkbox:not([value="all"])');
        complexityOptions.forEach(opt => opt.parentElement.remove());

        // Agregar nuevas opciones
        complexities.forEach(complexity => {
            if (complexityData[complexity]) {
                const label = document.createElement('label');
                label.className = 'flex items-center p-2 hover:bg-gray-600 rounded cursor-pointer';
                label.innerHTML = `
                    <input type="checkbox" class="complexity-checkbox mr-2" value="${complexity}">
                    <span class="text-sm">${complexityData[complexity].icon} ${complexityData[complexity].name}</span>
                `;
                container.appendChild(label);
            }
        });

        // Re-inicializar event listeners
        this.setupMultiSelectDropdown('complexity', 'complexity-checkbox');
    }

    // ========================================
    // 🛡️ SISTEMA DE DEFENSA MEV
    // ========================================
    
    setupMEVDefenseSystem() {
        console.log('🛡️ Configurando sistema de defensa MEV...');
        
        // Event listeners para botones de defensa MEV
        document.getElementById('mev-defense-scan')?.addEventListener('click', () => this.scanMEVThreats());
        document.getElementById('mev-defense-test')?.addEventListener('click', () => this.testMEVDefenseSystem());
        
        // Inicializar estado del sistema de defensa
        this.updateMEVDefenseStatus();
        
        // Configurar monitoreo automático
        this.startMEVDefenseMonitoring();
    }
    
    async scanMEVThreats() {
        try {
            console.log('🔍 Escaneando amenazas MEV...');
            
            // Mostrar estado de escaneo
            this.updateMEVDefenseStatus('ESCANEANDO', 'orange');
            
            // Simular escaneo (en producción esto llamaría al backend)
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // TODO: Implementar escaneo real de amenazas MEV
            // const realThreats = await this.scanRealMEVThreats();
            // this.updateMEVDefenseThreats(realThreats.length);
            // this.showNotification('Escaneo Completado', `${realThreats.length} amenazas detectadas`, 'info');
            
            // Placeholder temporal hasta implementar escaneo real
            this.updateMEVDefenseThreats(0);
            this.showNotification('Escaneo Completado', 'Sistema de escaneo real pendiente de implementación', 'info');
            
            // Actualizar estado
            this.updateMEVDefenseStatus('ACTIVO', 'green');
            
        } catch (error) {
            console.error('❌ Error escaneando amenazas MEV:', error);
            this.updateMEVDefenseStatus('ERROR', 'red');
            this.showNotification('Error', 'Fallo al escanear amenazas MEV', 'error');
        }
    }
    
    generateMockMEVThreats() {
        console.warn('⚠️ generateMockMEVThreats() está deprecado. Use scanRealMEVThreats() en su lugar.');
        
        // TODO: Implementar escaneo real de amenazas MEV
        // TODO: Conectar con Flashbots, MEV-Share, Eden
        // TODO: Monitorear mempool en tiempo real
        // TODO: Detectar patrones de frontrunning y sandwich attacks
        // TODO: Analizar transacciones sospechosas
        
        console.log('🔍 TODO: Implementar escáner real de amenazas MEV');
        return [];
    }
    
    async testMEVDefenseSystem() {
        try {
            console.log('🧪 Probando sistema de defensa MEV...');
            
            // Mostrar estado de prueba
            this.updateMEVDefenseStatus('PROBANDO', 'blue');
            
            // Simular prueba del sistema
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Simular activación de modo de emergencia
            this.activateMEVEmergencyMode();
            
            // Mostrar notificación
            this.showNotification('Prueba Completada', 'Sistema de defensa MEV funcionando correctamente', 'success');
            
            // Restaurar estado normal después de 3 segundos
            setTimeout(() => {
                this.deactivateMEVEmergencyMode();
            }, 3000);
            
        } catch (error) {
            console.error('❌ Error probando sistema de defensa MEV:', error);
            this.showNotification('Error', 'Fallo al probar sistema de defensa MEV', 'error');
        }
    }
    
    activateMEVEmergencyMode() {
        console.log('🚨 Activando modo de emergencia MEV...');
        
        // Actualizar indicadores
        document.getElementById('mev-defense-emergency-mode').textContent = 'ACTIVO';
        document.getElementById('mev-defense-emergency-mode').className = 'px-2 py-1 bg-red-500 text-white text-xs rounded-full';
        
        // Cambiar color del header
        document.querySelector('.defense-gradient')?.classList.add('animate-pulse');
        
        // Mostrar notificación
        this.showNotification('🚨 MODO EMERGENCIA', 'Sistema de defensa MEV en modo de emergencia', 'warning');
    }
    
    deactivateMEVEmergencyMode() {
        console.log('✅ Desactivando modo de emergencia MEV...');
        
        // Restaurar indicadores
        document.getElementById('mev-defense-emergency-mode').textContent = 'INACTIVO';
        document.getElementById('mev-defense-emergency-mode').className = 'px-2 py-1 bg-gray-500 text-white text-xs rounded-full';
        
        // Restaurar header
        document.querySelector('.defense-gradient')?.classList.remove('animate-pulse');
        
        // Mostrar notificación
        this.showNotification('✅ Modo Normal', 'Sistema de defensa MEV restaurado', 'success');
    }
    
    updateMEVDefenseStatus(status = 'ACTIVO', color = 'green') {
        const statusElement = document.getElementById('mev-defense-system-status');
        if (statusElement) {
            statusElement.textContent = status;
            statusElement.className = `px-2 py-1 bg-${color}-500 text-white text-xs rounded-full`;
        }
        
        // Actualizar también la tarjeta de métricas
        const metricStatus = document.getElementById('mev-defense-status');
        if (metricStatus) {
            metricStatus.textContent = status;
        }
    }
    
    updateMEVDefenseThreats(count) {
        const threatsElement = document.getElementById('mev-defense-active-threats');
        if (threatsElement) {
            threatsElement.textContent = count;
            
            // Cambiar color según la cantidad de amenazas
            if (count === 0) {
                threatsElement.className = 'px-2 py-1 bg-green-500 text-white text-xs rounded-full';
            } else if (count <= 2) {
                threatsElement.className = 'px-2 py-1 bg-orange-500 text-white text-xs rounded-full';
            } else {
                threatsElement.className = 'px-2 py-1 bg-red-500 text-white text-xs rounded-full';
            }
        }
        
        // Actualizar también la tarjeta de métricas
        const metricThreats = document.getElementById('mev-defense-threats');
        if (metricThreats) {
            metricThreats.textContent = `${count} amenazas`;
        }
    }
    
    startMEVDefenseMonitoring() {
        // Monitorear estado del sistema cada 30 segundos
        setInterval(() => {
            this.updateMEVDefenseStatus();
        }, 30000);
        
        console.log('🛡️ Monitoreo de defensa MEV iniciado');
    }
}

// Inicializar aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ArbitrageXApp();
});

// Función global para ejecutar oportunidades (llamada desde HTML)
window.executeOpportunity = (id) => {
    if (window.app) {
        window.app.executeOpportunity(id);
    }
};
