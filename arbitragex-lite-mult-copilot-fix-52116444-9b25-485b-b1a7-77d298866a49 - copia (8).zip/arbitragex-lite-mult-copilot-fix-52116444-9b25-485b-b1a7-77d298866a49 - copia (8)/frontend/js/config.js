/**
 * ArbitrageX Pro 2025 - Configuration Manager
 * ==========================================
 * Gestión de configuración de APIs y parámetros
 */

class ConfigManager {
    constructor() {
        console.log('🚀 ConfigManager: Constructor iniciado');
        this.config = this.loadConfig();
        this.strategies = this.getStrategiesDefinition();
        this.blockchainConnections = {};
        this.init();
    }

    getStrategiesDefinition() {
        return [
            // ESTRATEGIAS DE ARBITRAJE (15)
            {
                id: 'cross-chain-multi-hop-flash-loan',
                label: 'Cross-Chain Multi-Hop Flash-Loan',
                roiScore: 10,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 50000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'flash-loan',
                description: 'Arbitraje complejo que combina flash loans con rutas multi-hop entre diferentes blockchains para maximizar oportunidades',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'cross-chain-cross-dex',
                label: 'Cross-Chain Cross-DEX Arbitrage',
                roiScore: 9,
                complexity: 'expert',
                risk: 'high',
                minCapital: 25000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'cross-chain',
                description: 'Arbitraje entre diferentes DEXs en múltiples blockchains aprovechando diferencias de precio',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'triangular-arbitrage',
                label: 'Arbitraje Triangular',
                roiScore: 8,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 10000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje triangular entre 3 pares de trading en la misma blockchain',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'cross-dex-arbitrage',
                label: 'Cross-DEX Arbitrage',
                roiScore: 7,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 5000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje entre diferentes exchanges descentralizados en la misma blockchain',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'flash-loan-arbitrage',
                label: 'Flash Loan Arbitrage',
                roiScore: 9,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 20000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'flash-loan',
                description: 'Arbitraje utilizando préstamos flash para maximizar capital sin colateral',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'impermanent-loss-arbitrage',
                label: 'Impermanent Loss Arbitrage',
                roiScore: 6,
                complexity: 'advanced',
                risk: 'medium',
                minCapital: 3000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje aprovechando pérdidas impermanentes en pools AMM',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'liquidation-arbitrage',
                label: 'Liquidation Arbitrage',
                roiScore: 8,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 15000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje aprovechando liquidaciones en protocolos de lending',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'oracle-arbitrage',
                label: 'Oracle Arbitrage',
                roiScore: 7,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 2000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje aprovechando discrepancias en oracles de precios',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'gas-arbitrage',
                label: 'Gas Arbitrage',
                roiScore: 5,
                complexity: 'basic',
                risk: 'low',
                minCapital: 1000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje optimizando costos de gas entre blockchains',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'slippage-arbitrage',
                label: 'Slippage Arbitrage',
                roiScore: 6,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 3000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje aprovechando slippage en pools de liquidez',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'time-arbitrage',
                label: 'Time Arbitrage',
                roiScore: 7,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 8000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje aprovechando diferencias temporales en precios',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'volatility-arbitrage',
                label: 'Volatility Arbitrage',
                roiScore: 8,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 25000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje aprovechando cambios en la volatilidad del mercado',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'liquidity-arbitrage',
                label: 'Liquidity Arbitrage',
                roiScore: 6,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 4000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje aprovechando diferencias en la liquidez de pools',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'yield-arbitrage',
                label: 'Yield Arbitrage',
                roiScore: 7,
                complexity: 'advanced',
                risk: 'medium',
                minCapital: 6000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje entre diferentes protocolos de yield farming',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'futures-arbitrage',
                label: 'Futures Arbitrage',
                roiScore: 9,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 30000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'arbitrage',
                description: 'Arbitraje entre futuros y spot en diferentes blockchains',
                hunterMode: true,
                autoExecution: true
            },

            // ESTRATEGIAS DE YIELD (10)
            {
                id: 'liquidity-provision',
                label: 'Liquidity Provision',
                roiScore: 6,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 5000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Provisión de liquidez en pools AMM con recompensas',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'yield-farming',
                label: 'Yield Farming',
                roiScore: 7,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 2000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Farming de yield en protocolos DeFi',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'staking',
                label: 'Staking',
                roiScore: 5,
                complexity: 'basic',
                risk: 'low',
                minCapital: 1000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Staking de tokens nativos para obtener recompensas',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'lending',
                label: 'Lending',
                roiScore: 6,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 3000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Préstamos de criptomonedas con intereses',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'borrowing',
                label: 'Borrowing',
                roiScore: 7,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 5000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Estrategias de borrowing para maximizar capital',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'vault-strategies',
                label: 'Vault Strategies',
                roiScore: 8,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 10000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Estrategias automatizadas en vaults DeFi',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'rebase-tokens',
                label: 'Rebase Tokens',
                roiScore: 6,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 2000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Trading de tokens con mecanismos de rebase',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'dividend-tokens',
                label: 'Dividend Tokens',
                roiScore: 5,
                complexity: 'basic',
                risk: 'low',
                minCapital: 1000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Tokens que distribuyen dividendos automáticamente',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'auto-compound',
                label: 'Auto-Compound',
                roiScore: 7,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 3000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Reinversión automática de recompensas',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'cross-chain-yield',
                label: 'Cross-Chain Yield',
                roiScore: 8,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 8000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'yield',
                description: 'Estrategias de yield entre diferentes blockchains',
                hunterMode: true,
                autoExecution: true
            },

            // ESTRATEGIAS DE DERIVADOS (8)
            {
                id: 'options-trading',
                label: 'Options Trading',
                roiScore: 8,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 15000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'derivatives',
                description: 'Trading de opciones en protocolos DeFi',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'futures-trading',
                label: 'Futures Trading',
                roiScore: 9,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 20000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'derivatives',
                description: 'Trading de futuros con apalancamiento',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'perpetuals',
                label: 'Perpetuals',
                roiScore: 8,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 12000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'derivatives',
                description: 'Trading de contratos perpetuos',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'synthetic-assets',
                label: 'Synthetic Assets',
                roiScore: 7,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 8000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'derivatives',
                description: 'Trading de activos sintéticos',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'structured-products',
                label: 'Structured Products',
                roiScore: 9,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 25000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'derivatives',
                description: 'Productos estructurados complejos',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'volatility-trading',
                label: 'Volatility Trading',
                roiScore: 8,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 18000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'derivatives',
                description: 'Trading basado en la volatilidad del mercado',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'correlation-trading',
                label: 'Correlation Trading',
                roiScore: 7,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 10000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'derivatives',
                description: 'Trading basado en correlaciones entre activos',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'basis-trading',
                label: 'Basis Trading',
                roiScore: 6,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 6000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'derivatives',
                description: 'Trading del basis entre futuros y spot',
                hunterMode: true,
                autoExecution: true
            },

            // ESTRATEGIAS DE PROTECCIÓN (5)
            {
                id: 'mev-protection',
                label: 'MEV Protection',
                roiScore: 4,
                complexity: 'basic',
                risk: 'low',
                minCapital: 500,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'protection',
                description: 'Protección contra miner extractable value',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'front-running-protection',
                label: 'Front-Running Protection',
                roiScore: 5,
                complexity: 'intermediate',
                risk: 'low',
                minCapital: 1000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'protection',
                description: 'Protección contra front-running en transacciones',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'sandwich-protection',
                label: 'Sandwich Protection',
                roiScore: 5,
                complexity: 'intermediate',
                risk: 'low',
                minCapital: 1000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'protection',
                description: 'Protección contra ataques sandwich',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'slippage-protection',
                label: 'Slippage Protection',
                roiScore: 4,
                complexity: 'basic',
                risk: 'low',
                minCapital: 500,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'protection',
                description: 'Protección contra slippage excesivo',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'reentrancy-protection',
                label: 'Reentrancy Protection',
                roiScore: 6,
                complexity: 'advanced',
                risk: 'medium',
                minCapital: 2000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'protection',
                description: 'Protección contra ataques de reentrancy',
                hunterMode: true,
                autoExecution: true
            },

            // ESTRATEGIAS DE GOVERNANCE (3)
            {
                id: 'governance-token-arbitrage',
                label: 'Governance Token Arbitrage',
                roiScore: 7,
                complexity: 'advanced',
                risk: 'high',
                minCapital: 8000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'governance',
                description: 'Arbitraje de tokens de governance',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'voting-power-arbitrage',
                label: 'Voting Power Arbitrage',
                roiScore: 6,
                complexity: 'intermediate',
                risk: 'medium',
                minCapital: 5000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'governance',
                description: 'Arbitraje del poder de voto en DAOs',
                hunterMode: true,
                autoExecution: true
            },
            {
                id: 'proposal-arbitrage',
                label: 'Proposal Arbitrage',
                roiScore: 8,
                complexity: 'expert',
                risk: 'extreme',
                minCapital: 15000,
                blockchains: ['ethereum', 'polygon', 'arbitrum', 'optimism', 'bsc', 'avalanche', 'fantom', 'cronos', 'solana', 'gnosis', 'moonbeam'],
                category: 'governance',
                description: 'Arbitraje basado en propuestas de governance',
                hunterMode: true,
                autoExecution: true
            }
        ];
    }

    async init() {
        try {
            console.log('🚀 ConfigManager: Iniciando...');
            
            // Configurar sistema de pestañas PRIMERO
            this.setupTabs();
            console.log('✅ Tabs configurados');
            
            // Configurar event listeners
            this.setupEventListeners();
            console.log('✅ Event listeners configurados');
            
            // Cargar valores guardados
            this.loadSavedValues();
            console.log('✅ Valores guardados cargados');
            
            // Inicializar MetaMask
            await this.initMetaMask();
            console.log('✅ MetaMask inicializado');
            
            // Inicializar conexiones de blockchain
            this.initBlockchainConnections();
            console.log('✅ Conexiones blockchain inicializadas');
            
            // Inicializar APIs
            this.initAPIs();
            console.log('✅ APIs inicializadas');
            
            // Actualizar estado de APIs
            this.updateAPIStatus();
            console.log('✅ Estado de APIs actualizado');
            
            console.log('🎉 ConfigManager inicializado correctamente');
        } catch (error) {
            console.error('❌ Error inicializando ConfigManager:', error);
        }
    }

    setupTabs() {
        console.log('🔍 Configurando sistema de pestañas...');
        
        const tabs = document.querySelectorAll('.tab-button');
        const tabContents = document.querySelectorAll('.tab-content');
        
        console.log('🔍 Encontrados:', tabs.length, 'tabs y', tabContents.length, 'contenidos');
        
        if (tabs.length === 0 || tabContents.length === 0) {
            console.error('❌ No se encontraron elementos de pestañas');
            console.log('🔍 Buscando elementos con clases específicas...');
            console.log('🔍 .tab-button encontrados:', document.querySelectorAll('.tab-button').length);
            console.log('🔍 .tab-content encontrados:', document.querySelectorAll('.tab-content').length);
            return;
        }
        
        tabs.forEach((tab, index) => {
            console.log(`🔍 Configurando tab ${index + 1}:`, tab.textContent, 'data-tab:', tab.getAttribute('data-tab'));
            
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('🔍 Tab clickeado:', tab.textContent);
                
                const targetTab = tab.getAttribute('data-tab');
                console.log('🔍 Target tab:', targetTab);
                
                if (!targetTab) {
                    console.error('❌ No se encontró data-tab en:', tab);
                    return;
                }
                
                // Remover clase activa de todos los tabs
                tabs.forEach(t => t.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Activar tab seleccionado
                tab.classList.add('active');
                const targetContent = document.getElementById(targetTab + '-tab');
                
                if (targetContent) {
                    targetContent.classList.add('active');
                    console.log('✅ Tab activado:', targetTab);
                } else {
                    console.error('❌ No se encontró el contenido para el tab:', targetTab);
                }
            });
        });
        
        console.log('✅ Sistema de pestañas configurado');
    }

    setupEventListeners() {
        console.log('🔍 Configurando event listeners...');
        
        // Test individual APIs
        const testButtons = document.querySelectorAll('.test-btn');
        testButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const apiType = btn.dataset.api;
                this.testSingleAPI(apiType, btn);
            });
        });

        // Test all APIs
        const testAllButton = document.getElementById('test-all-apis');
        if (testAllButton) {
            testAllButton.addEventListener('click', () => {
                this.testAllAPIs();
            });
        }

        // Save configuration
        const saveButton = document.getElementById('save-all-config');
        if (saveButton) {
            saveButton.addEventListener('click', () => {
                this.saveAllConfiguration();
            });
        }

        // Export configuration
        const exportButton = document.getElementById('export-config');
        if (exportButton) {
            exportButton.addEventListener('click', () => {
                this.exportConfiguration();
            });
        }

        // MetaMask connect button
        const connectButton = document.getElementById('connect-metamask');
        if (connectButton) {
            connectButton.addEventListener('click', () => {
                this.connectMetaMask();
            });
        }

        console.log('✅ Event listeners configurados');
    }

    loadSavedValues() {
        console.log('🔍 Cargando valores guardados...');
        
        try {
            // Cargar valores de RPCs
            if (this.blockchainConnections) {
                Object.keys(this.blockchainConnections).forEach(blockchain => {
                    const rpcInput = document.getElementById(`${blockchain === 'eth' ? 'ethereum' : blockchain}-rpc`);
                    if (rpcInput && this.blockchainConnections[blockchain].rpc) {
                        rpcInput.value = this.blockchainConnections[blockchain].rpc;
                    }
                });
            }
            
            // Cargar valores de APIs
            if (this.config.apis) {
                Object.keys(this.config.apis).forEach(api => {
                    const input = document.getElementById(`${api}-api-key`);
                    if (input) {
                        input.value = this.config.apis[api].key || '';
                    }
                });
            }
            
            console.log('✅ Valores guardados cargados');
        } catch (error) {
            console.error('❌ Error cargando valores guardados:', error);
        }
    }

    loadConfig() {
        try {
            const saved = localStorage.getItem('arbitragex-config');
            if (saved) {
                return JSON.parse(saved);
            }
        } catch (error) {
            console.error('Error cargando configuración:', error);
        }
        
        return {
            apis: {},
            rpcs: {},
            notifications: {},
            strategies: {},
            security: {}
        };
    }

    saveConfig() {
        try {
            localStorage.setItem('arbitragex-config', JSON.stringify(this.config));
        } catch (error) {
            console.error('Error guardando configuración:', error);
        }
    }

    initBlockchainConnections() {
        this.blockchainConnections = {
            ethereum: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            polygon: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            arbitrum: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            optimism: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            bsc: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            fantom: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            cronos: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            avalanche: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            solana: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            gnosis: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            moonbeam: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null },
            base: { connected: false, rpc: '', balance: '--', gas: '--', lastConnected: null }
        };
    }

    initAPIs() {
        if (!this.config.apis) {
            this.config.apis = {};
        }
    }

    async initMetaMask() {
        console.log('🔍 Inicializando MetaMask...');
        
        // Esperar un poco para que MetaMask se cargue completamente
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        if (typeof window.ethereum !== 'undefined' && window.ethereum.isMetaMask) {
            console.log('✅ MetaMask detectado correctamente');
            
            try {
                // Verificar si ya está conectado
                const accounts = await window.ethereum.request({ method: 'eth_accounts' });
                if (accounts.length > 0) {
                    console.log('✅ MetaMask ya conectado:', accounts[0]);
                    this.updateMetaMaskStatus(accounts[0]);
                } else {
                    console.log('ℹ️ MetaMask no conectado - listo para conectar');
                    this.resetMetaMaskStatus();
                }
                
                // Configurar listeners
                this.setupMetaMaskListeners();
                
                // Actualizar estado de la red
                await this.updateNetworkStatus();
                
            } catch (error) {
                console.error('❌ Error inicializando MetaMask:', error);
                this.resetMetaMaskStatus();
                this.showNotification('Error', 'Error al inicializar MetaMask: ' + error.message, 'error');
            }
        } else {
            console.log('❌ MetaMask no detectado - verificar instalación');
            this.showNotification('Error', 'MetaMask no está instalado. Por favor instala MetaMask para usar las funciones de wallet.', 'error');
            this.resetMetaMaskStatus();
        }
    }

    setupMetaMaskListeners() {
        if (window.ethereum && window.ethereum.isMetaMask) {
            console.log('🔧 Configurando listeners de MetaMask...');
            
            window.ethereum.on('accountsChanged', (accounts) => {
                console.log('🔄 Cuentas de MetaMask cambiaron:', accounts);
                if (accounts.length > 0) {
                    this.updateMetaMaskStatus(accounts[0]);
                    this.showNotification('Info', 'Cuenta de MetaMask cambiada', 'info');
                } else {
                    this.resetMetaMaskStatus();
                    this.showNotification('Info', 'MetaMask desconectado', 'info');
                }
            });
            
            window.ethereum.on('chainChanged', (chainId) => {
                console.log('🔄 Red de MetaMask cambió:', chainId);
                this.updateNetworkStatus();
                this.showNotification('Info', 'Red de MetaMask cambiada', 'info');
            });
            
            window.ethereum.on('connect', (connectInfo) => {
                console.log('🔗 MetaMask conectado:', connectInfo);
                this.showNotification('Éxito', 'MetaMask conectado', 'success');
            });
            
            window.ethereum.on('disconnect', (error) => {
                console.log('🔌 MetaMask desconectado:', error);
                this.resetMetaMaskStatus();
                this.showNotification('Info', 'MetaMask desconectado', 'info');
            });
            
            console.log('✅ Listeners de MetaMask configurados');
        }
    }

    async connectMetaMask() {
        console.log('🔍 Conectando MetaMask...');
        
        if (typeof window.ethereum === 'undefined' || !window.ethereum.isMetaMask) {
            this.showNotification('Error', 'MetaMask no está instalado. Por favor instala MetaMask para continuar.', 'error');
            return;
        }
        
        try {
            console.log('🔍 Solicitando cuentas de MetaMask...');
            const accounts = await window.ethereum.request({
                method: 'eth_requestAccounts'
            });
            
            if (accounts.length > 0) {
                console.log('✅ MetaMask conectado exitosamente:', accounts[0]);
                this.updateMetaMaskStatus(accounts[0]);
                this.showNotification('Éxito', 'MetaMask conectado correctamente', 'success');
                
                // Actualizar estado de la red después de conectar
                await this.updateNetworkStatus();
            } else {
                console.log('ℹ️ No se obtuvieron cuentas de MetaMask');
                this.showNotification('Info', 'No se pudieron obtener cuentas de MetaMask', 'info');
            }
        } catch (error) {
            console.error('❌ Error conectando MetaMask:', error);
            
            if (error.code === 4001) {
                this.showNotification('Info', 'Conexión a MetaMask cancelada por el usuario', 'info');
            } else if (error.code === -32002) {
                this.showNotification('Info', 'MetaMask ya está procesando una solicitud. Por favor revisa tu extensión.', 'info');
            } else {
                this.showNotification('Error', 'Error al conectar MetaMask: ' + error.message, 'error');
            }
        }
    }

    async disconnectMetaMask() {
        console.log('🔌 Desconectando MetaMask...');
        
        try {
            // Limpiar el estado de MetaMask
            this.resetMetaMaskStatus();
            
            // Limpiar el estado de la red
            const networkElement = document.getElementById('metamask-network');
            if (networkElement) networkElement.textContent = 'Desconectada';
            
            // Mostrar notificación de éxito
            this.showNotification('Éxito', 'MetaMask desconectado correctamente', 'success');
            
            console.log('✅ MetaMask desconectado exitosamente');
            
            // Opcional: Limpiar cualquier dato almacenado localmente
            localStorage.removeItem('metamask-account');
            localStorage.removeItem('metamask-network');
            
        } catch (error) {
            console.error('❌ Error desconectando MetaMask:', error);
            this.showNotification('Error', 'Error al desconectar MetaMask: ' + error.message, 'error');
        }
    }

    updateMetaMaskStatus(account) {
        const statusElement = document.getElementById('metamask-status');
        const accountElement = document.getElementById('metamask-account');
        const connectButton = document.getElementById('connect-metamask');
        const indicatorElement = document.getElementById('metamask-indicator');
        
        if (statusElement) statusElement.textContent = 'Conectado';
        if (accountElement) accountElement.textContent = account.substring(0, 6) + '...' + account.substring(38);
        if (connectButton) connectButton.textContent = 'Desconectar';
        if (indicatorElement) {
            indicatorElement.className = 'w-3 h-3 bg-green-500 rounded-full';
            indicatorElement.classList.remove('animate-pulse');
        }
        
        // Actualizar también el estado detallado
        const statusDetailElement = document.getElementById('metamask-status-detail');
        if (statusDetailElement) statusDetailElement.textContent = 'Conectado a MetaMask';
        
        // Actualizar la red
        this.updateNetworkStatus();
    }

    resetMetaMaskStatus() {
        const statusElement = document.getElementById('metamask-status');
        const accountElement = document.getElementById('metamask-account');
        const connectButton = document.getElementById('connect-metamask');
        const indicatorElement = document.getElementById('metamask-indicator');
        const statusDetailElement = document.getElementById('metamask-status-detail');
        
        if (statusElement) statusElement.textContent = 'No conectado';
        if (accountElement) accountElement.textContent = '--';
        if (connectButton) connectButton.textContent = 'Conectar MetaMask';
        if (indicatorElement) {
            indicatorElement.className = 'w-3 h-3 bg-red-500 rounded-full';
            indicatorElement.classList.remove('animate-pulse');
        }
        if (statusDetailElement) statusDetailElement.textContent = 'MetaMask no conectado';
    }

    async updateNetworkStatus() {
        console.log('🔄 Actualizando estado de red...');
        
        if (window.ethereum && window.ethereum.isMetaMask) {
            try {
                const chainId = await window.ethereum.request({ method: 'eth_chainId' });
                console.log('🔄 Chain ID actual:', chainId);
                
                // Actualizar UI según la red
                this.updateNetworkUI(chainId);
                
                // Actualizar el indicador de red en la UI
                const networkElement = document.getElementById('metamask-network');
                if (networkElement) {
                    const networkName = this.getNetworkNameFromChainId(chainId);
                    networkElement.textContent = networkName;
                    networkElement.className = 'text-green-600 font-medium';
                }
                
                // Verificar si la red actual está en nuestras blockchains configuradas
                const currentBlockchain = this.getBlockchainFromChainId(chainId);
                if (currentBlockchain) {
                    console.log(`✅ Red actual: ${currentBlockchain}`);
                    // Marcar esta blockchain como conectada
                    if (this.blockchainConnections[currentBlockchain]) {
                        this.blockchainConnections[currentBlockchain].connected = true;
                        this.blockchainConnections[currentBlockchain].lastConnected = new Date();
                        this.updateBlockchainConnectionUI(currentBlockchain, true);
                    }
                }
                
            } catch (error) {
                console.error('❌ Error obteniendo chain ID:', error);
                // Si hay error, mostrar como desconectado
                const networkElement = document.getElementById('metamask-network');
                if (networkElement) {
                    networkElement.textContent = 'Error';
                    networkElement.className = 'text-red-600 font-medium';
                }
            }
        } else {
            console.log('❌ MetaMask no disponible para actualizar estado de red');
            const networkElement = document.getElementById('metamask-network');
            if (networkElement) {
                networkElement.textContent = 'Desconectada';
                networkElement.className = 'text-red-600 font-medium';
            }
        }
    }

    // Función para verificar MetaMask en tiempo real
    checkMetaMaskStatus() {
        console.log('🔍 Verificando estado de MetaMask...');
        
        if (typeof window.ethereum !== 'undefined' && window.ethereum.isMetaMask) {
            console.log('✅ MetaMask detectado en tiempo real');
            return true;
        } else {
            console.log('❌ MetaMask no detectado en tiempo real');
            return false;
        }
    }

    // Función para forzar la reconexión de MetaMask
    async forceMetaMaskReconnect() {
        console.log('🔄 Forzando reconexión de MetaMask...');
        
        if (this.checkMetaMaskStatus()) {
            try {
                await this.connectMetaMask();
            } catch (error) {
                console.error('❌ Error en reconexión forzada:', error);
            }
        } else {
            this.showNotification('Error', 'MetaMask no está disponible para reconexión', 'error');
        }
    }

    updateNetworkUI(chainId) {
        console.log('🔄 Actualizando UI para red:', chainId);
        
        // Actualizar el indicador de red principal
        const networkElement = document.getElementById('metamask-network');
        if (networkElement) {
            const networkName = this.getNetworkNameFromChainId(chainId);
            networkElement.textContent = networkName;
            networkElement.className = 'text-green-600 font-medium';
        }
        
        // Actualizar el estado de la blockchain correspondiente
        const blockchainName = this.getBlockchainFromChainId(chainId);
        if (blockchainName && this.blockchainConnections[blockchainName]) {
            this.blockchainConnections[blockchainName].connected = true;
            this.blockchainConnections[blockchainName].lastConnected = new Date();
            this.updateBlockchainConnectionUI(blockchainName, true);
            
            // Obtener información actualizada de la blockchain
            this.updateBlockchainInfo(blockchainName);
        }
    }

    async testSingleAPI(apiType, button) {
        console.log('🔍 Probando API:', apiType);
        
        if (button) {
            button.textContent = 'Probando...';
            button.disabled = true;
        }
        
        try {
            // Simular prueba de API
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            if (button) {
                button.textContent = '✅ Funciona';
                button.style.backgroundColor = '#10b981';
            }
            
            this.showNotification('Éxito', `API ${apiType} funciona correctamente`, 'success');
        } catch (error) {
            if (button) {
                button.textContent = '❌ Error';
                button.style.backgroundColor = '#ef4444';
            }
            
            this.showNotification('Error', `Error probando API ${apiType}`, 'error');
        }
        
        // Resetear botón después de 3 segundos
        setTimeout(() => {
            if (button) {
                button.textContent = 'Probar';
                button.disabled = false;
                button.style.backgroundColor = '';
            }
        }, 3000);
    }

    async testAllAPIs() {
        console.log('🔍 Probando todas las APIs...');
        
        const testButton = document.getElementById('test-all-apis');
        if (testButton) {
            testButton.textContent = 'Probando...';
            testButton.disabled = true;
        }
        
        try {
            // Simular pruebas de todas las APIs
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            if (testButton) {
                testButton.textContent = '✅ Todas Funcionan';
                testButton.style.backgroundColor = '#10b981';
            }
            
            this.showNotification('Éxito', 'Todas las APIs funcionan correctamente', 'success');
        } catch (error) {
            if (testButton) {
                testButton.textContent = '❌ Error';
                testButton.style.backgroundColor = '#ef4444';
            }
            
            this.showNotification('Error', 'Error probando APIs', 'error');
        }
        
        // Resetear botón después de 5 segundos
        setTimeout(() => {
            if (testButton) {
                testButton.textContent = 'Probar Todas las APIs';
                testButton.disabled = false;
                testButton.style.backgroundColor = '';
            }
        }, 5000);
    }

    updateAPIStatus() {
        console.log('🔍 Actualizando estado de APIs...');
        
        const statuses = {
            coingecko: 'No configurado',
            ethereum: 'No configurado',
            uniswap: 'No configurado'
        };
        
        this.updateAPIStatusDisplay(statuses);
    }

    updateAPIStatusDisplay(statuses) {
        Object.keys(statuses).forEach(api => {
            const statusElement = document.getElementById(`${api}-status`);
            if (statusElement) {
                statusElement.textContent = statuses[api];
            }
        });
    }

    saveAllConfiguration() {
        console.log('🔍 Guardando toda la configuración...');
        
        try {
            this.collectAndSaveValues();
            this.saveConfig();
            this.showNotification('Éxito', 'Configuración guardada correctamente', 'success');
        } catch (error) {
            console.error('❌ Error guardando configuración:', error);
            this.showNotification('Error', 'Error guardando configuración', 'error');
        }
    }

    collectAndSaveValues() {
        console.log('🔍 Recolectando valores de formularios...');
        
        // Recolectar valores de RPCs
        const rpcInputs = document.querySelectorAll('input[id*="-rpc"]');
        rpcInputs.forEach(input => {
            const blockchain = input.id.replace('-rpc', '');
            if (!this.config.rpcs) this.config.rpcs = {};
            this.config.rpcs[blockchain] = input.value;
        });
        
        // Recolectar valores de APIs
        const apiInputs = document.querySelectorAll('input[id*="-api-key"]');
        apiInputs.forEach(input => {
            const api = input.id.replace('-api-key', '');
            if (!this.config.apis) this.config.apis = {};
            this.config.apis[api] = { key: input.value };
        });
        
        console.log('✅ Valores recolectados:', this.config);
    }

    exportConfiguration() {
        console.log('🔍 Exportando configuración...');
        
        try {
            const dataStr = JSON.stringify(this.config, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            
            const link = document.createElement('a');
            link.href = URL.createObjectURL(dataBlob);
            link.download = 'arbitragex-config.json';
            link.click();
            
            this.showNotification('Éxito', 'Configuración exportada correctamente', 'success');
        } catch (error) {
            console.error('❌ Error exportando configuración:', error);
            this.showNotification('Error', 'Error exportando configuración', 'error');
        }
    }

    showNotification(title, message, type = 'info') {
        console.log(`🔔 ${title}: ${message}`);
        
        // Crear notificación simple
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            max-width: 300px;
            word-wrap: break-word;
        `;
        
        switch (type) {
            case 'success':
                notification.style.backgroundColor = '#10b981';
                break;
            case 'error':
                notification.style.backgroundColor = '#ef4444';
                break;
            case 'warning':
                notification.style.backgroundColor = '#f59e0b';
                break;
            default:
                notification.style.backgroundColor = '#3b82f6';
        }
        
        notification.innerHTML = `<strong>${title}</strong><br>${message}`;
        document.body.appendChild(notification);
        
        // Remover después de 5 segundos
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 5000);
    }

    // Función para conectar una blockchain específica
    async connectBlockchain(blockchainName) {
        console.log(`🔗 Conectando a ${blockchainName}...`);
        
        if (!window.ethereum || !window.ethereum.isMetaMask) {
            this.showNotification('Error', 'MetaMask debe estar conectado para conectar blockchains', 'error');
            return false;
        }

        try {
            // Obtener la configuración RPC de la blockchain
            const rpcUrl = this.getBlockchainRPC(blockchainName);
            if (!rpcUrl) {
                this.showNotification('Error', `RPC no configurado para ${blockchainName}`, 'error');
                return false;
            }

            // Solicitar cambio de red en MetaMask
            const chainId = this.getBlockchainChainId(blockchainName);
            const chainName = this.getBlockchainDisplayName(blockchainName);
            
            console.log(`🔄 Solicitando cambio a red ${chainName} (${chainId})...`);
            
            try {
                // Intentar cambiar a la red
                await window.ethereum.request({
                    method: 'wallet_switchEthereumChain',
                    params: [{ chainId: chainId }],
                });
                
                console.log(`✅ Cambio exitoso a ${chainName}`);
                
                // Actualizar estado de conexión
                this.blockchainConnections[blockchainName].connected = true;
                this.blockchainConnections[blockchainName].lastConnected = new Date();
                
                // Actualizar UI
                this.updateBlockchainConnectionUI(blockchainName, true);
                
                this.showNotification('Éxito', `Conectado a ${chainName}`, 'success');
                
                // Obtener balance y gas
                await this.updateBlockchainInfo(blockchainName);
                
                return true;
                
            } catch (switchError) {
                // Si la red no está en MetaMask, solicitar agregarla
                if (switchError.code === 4902) {
                    console.log(`🆕 Red ${chainName} no está en MetaMask, solicitando agregar...`);
                    
                    try {
                        await window.ethereum.request({
                            method: 'wallet_addEthereumChain',
                            params: [{
                                chainId: chainId,
                                chainName: chainName,
                                nativeCurrency: this.getBlockchainNativeCurrency(blockchainName),
                                rpcUrls: [rpcUrl],
                                blockExplorerUrls: [this.getBlockchainExplorer(blockchainName)]
                            }],
                        });
                        
                        console.log(`✅ Red ${chainName} agregada exitosamente`);
                        
                        // Actualizar estado de conexión
                        this.blockchainConnections[blockchainName].connected = true;
                        this.blockchainConnections[blockchainName].lastConnected = new Date();
                        
                        // Actualizar UI
                        this.updateBlockchainConnectionUI(blockchainName, true);
                        
                        this.showNotification('Éxito', `Red ${chainName} agregada y conectada`, 'success');
                        
                        // Obtener balance y gas
                        await this.updateBlockchainInfo(blockchainName);
                        
                        return true;
                        
                    } catch (addError) {
                        console.error(`❌ Error agregando red ${chainName}:`, addError);
                        this.showNotification('Error', `Error agregando red ${chainName}: ${addError.message}`, 'error');
                        return false;
                    }
                } else {
                    console.error(`❌ Error cambiando a red ${chainName}:`, switchError);
                    this.showNotification('Error', `Error cambiando a red ${chainName}: ${switchError.message}`, 'error');
                    return false;
                }
            }
            
        } catch (error) {
            console.error(`❌ Error conectando a ${blockchainName}:`, error);
            this.showNotification('Error', `Error conectando a ${blockchainName}: ${error.message}`, 'error');
            return false;
        }
    }

    // Función para conectar todas las blockchains
    async connectAllChains() {
        console.log('🔗 Conectando todas las blockchains...');
        
        if (!window.ethereum || !window.ethereum.isMetaMask) {
            this.showNotification('Error', 'MetaMask debe estar conectado para conectar blockchains', 'error');
            return;
        }

        const blockchains = Object.keys(this.blockchainConnections);
        let connectedCount = 0;
        let totalCount = blockchains.length;

        this.showNotification('Info', `Iniciando conexión a ${totalCount} blockchains...`, 'info');

        for (const blockchain of blockchains) {
            try {
                console.log(`🔄 Conectando ${blockchain}...`);
                
                const success = await this.connectBlockchain(blockchain);
                if (success) {
                    connectedCount++;
                }
                
                // Pequeña pausa entre conexiones para evitar sobrecarga
                await new Promise(resolve => setTimeout(resolve, 1000));
                
            } catch (error) {
                console.error(`❌ Error en ${blockchain}:`, error);
            }
        }

        console.log(`✅ Proceso completado: ${connectedCount}/${totalCount} blockchains conectadas`);
        
        if (connectedCount > 0) {
            this.showNotification('Éxito', `${connectedCount} de ${totalCount} blockchains conectadas`, 'success');
        } else {
            this.showNotification('Error', 'No se pudo conectar ninguna blockchain', 'error');
        }
    }

    // Función para desconectar todas las blockchains
    async disconnectAllBlockchains() {
        console.log('🔌 Desconectando todas las blockchains...');
        
        const blockchains = Object.keys(this.blockchainConnections);
        
        for (const blockchain of blockchains) {
            this.blockchainConnections[blockchain].connected = false;
            this.blockchainConnections[blockchain].lastConnected = null;
            this.updateBlockchainConnectionUI(blockchain, false);
        }
        
        this.showNotification('Info', 'Todas las blockchains han sido desconectadas', 'info');
    }

    // Función para obtener información de una blockchain
    async updateBlockchainInfo(blockchainName) {
        if (!this.blockchainConnections[blockchainName].connected) {
            return;
        }

        try {
            const rpcUrl = this.getBlockchainRPC(blockchainName);
            if (!rpcUrl) return;

            // Obtener balance de la cuenta actual
            const accounts = await window.ethereum.request({ method: 'eth_accounts' });
            if (accounts.length > 0) {
                const balance = await window.ethereum.request({
                    method: 'eth_getBalance',
                    params: [accounts[0], 'latest']
                });
                
                const balanceEth = parseInt(balance, 16) / Math.pow(10, 18);
                this.blockchainConnections[blockchainName].balance = balanceEth.toFixed(4);
            }

            // Obtener gas price
            const gasPrice = await window.ethereum.request({
                method: 'eth_gasPrice'
            });
            
            const gasPriceGwei = parseInt(gasPrice, 16) / Math.pow(10, 9);
            this.blockchainConnections[blockchainName].gas = gasPriceGwei.toFixed(2);

            // Actualizar UI
            this.updateBlockchainInfoUI(blockchainName);
            
        } catch (error) {
            console.error(`❌ Error obteniendo info de ${blockchainName}:`, error);
        }
    }

    // Función para actualizar UI de conexión de blockchain
    updateBlockchainConnectionUI(blockchainName, isConnected) {
        const statusElement = document.getElementById(`${blockchainName}-status`);
        const connectButton = document.getElementById(`${blockchainName}-connect`);
        
        if (statusElement) {
            statusElement.textContent = isConnected ? 'Conectado' : 'Desconectado';
            statusElement.className = isConnected ? 'text-green-600 font-medium' : 'text-red-600 font-medium';
        }
        
        if (connectButton) {
            connectButton.textContent = isConnected ? 'Desconectar' : 'Conectar';
            connectButton.className = isConnected ? 
                'px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-sm rounded transition-colors' :
                'px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-sm rounded transition-colors';
        }
    }

    // Función para actualizar UI de información de blockchain
    updateBlockchainInfoUI(blockchainName) {
        const balanceElement = document.getElementById(`${blockchainName}-balance`);
        const gasElement = document.getElementById(`${blockchainName}-gas`);
        
        if (balanceElement) {
            balanceElement.textContent = this.blockchainConnections[blockchainName].balance;
        }
        
        if (gasElement) {
            gasElement.textContent = this.blockchainConnections[blockchainName].gas;
        }
    }

    // Funciones auxiliares para obtener información de blockchains
    getBlockchainRPC(blockchainName) {
        const rpcConfigs = {
            ethereum: 'https://mainnet.infura.io/v3/YOUR-PROJECT-ID',
            polygon: 'https://polygon-rpc.com',
            arbitrum: 'https://arb1.arbitrum.io/rpc',
            optimism: 'https://mainnet.optimism.io',
            bsc: 'https://bsc-dataseed.binance.org',
            fantom: 'https://rpc.ftm.tools',
            cronos: 'https://evm.cronos.org',
            avalanche: 'https://api.avax.network/ext/bc/C/rpc',
            solana: 'https://api.mainnet-beta.solana.com',
            gnosis: 'https://rpc.gnosischain.com',
            moonbeam: 'https://rpc.api.moonbeam.network',
            base: 'https://mainnet.base.org'
        };
        return rpcConfigs[blockchainName] || null;
    }

    getBlockchainChainId(blockchainName) {
        const chainIds = {
            ethereum: '0x1',
            polygon: '0x89',
            arbitrum: '0xa4b1',
            optimism: '0xa',
            bsc: '0x38',
            fantom: '0xfa',
            cronos: '0x19',
            avalanche: '0xa86a',
            solana: '0x65', // Solana usa un formato diferente
            gnosis: '0x64',
            moonbeam: '0x504',
            base: '0x2105'
        };
        return chainIds[blockchainName] || '0x1';
    }

    getBlockchainDisplayName(blockchainName) {
        const names = {
            ethereum: 'Ethereum Mainnet',
            polygon: 'Polygon Mainnet',
            arbitrum: 'Arbitrum One Mainnet',
            optimism: 'Optimism Mainnet',
            bsc: 'Binance Smart Chain Mainnet',
            fantom: 'Fantom Opera Mainnet',
            cronos: 'Cronos Mainnet',
            avalanche: 'Avalanche C-Chain Mainnet',
            solana: 'Solana Mainnet',
            gnosis: 'Gnosis Chain Mainnet',
            moonbeam: 'Moonbeam Mainnet',
            base: 'Base Mainnet'
        };
        return names[blockchainName] || blockchainName;
    }

    getBlockchainNativeCurrency(blockchainName) {
        const currencies = {
            ethereum: { name: 'Ether', symbol: 'ETH', decimals: 18 },
            polygon: { name: 'MATIC', symbol: 'MATIC', decimals: 18 },
            arbitrum: { name: 'Ether', symbol: 'ETH', decimals: 18 },
            optimism: { name: 'Ether', symbol: 'ETH', decimals: 18 },
            bsc: { name: 'BNB', symbol: 'BNB', decimals: 18 },
            fantom: { name: 'Fantom', symbol: 'FTM', decimals: 18 },
            cronos: { name: 'Cronos', symbol: 'CRO', decimals: 18 },
            avalanche: { name: 'Avalanche', symbol: 'AVAX', decimals: 18 },
            solana: { name: 'Solana', symbol: 'SOL', decimals: 9 },
            gnosis: { name: 'xDai', symbol: 'XDAI', decimals: 18 },
            moonbeam: { name: 'Moonbeam', symbol: 'GLMR', decimals: 18 },
            base: { name: 'Ether', symbol: 'ETH', decimals: 18 }
        };
        return currencies[blockchainName] || { name: 'Ether', symbol: 'ETH', decimals: 18 };
    }

    getBlockchainExplorer(blockchainName) {
        const explorers = {
            ethereum: 'https://etherscan.io',
            polygon: 'https://polygonscan.com',
            arbitrum: 'https://arbiscan.io',
            optimism: 'https://optimistic.etherscan.io',
            bsc: 'https://bscscan.com',
            fantom: 'https://ftmscan.com',
            cronos: 'https://cronoscan.com',
            avalanche: 'https://snowtrace.io',
            solana: 'https://explorer.solana.com',
            gnosis: 'https://gnosisscan.io',
            moonbeam: 'https://moonbeam.moonscan.io',
            base: 'https://basescan.org'
        };
        return explorers[blockchainName] || 'https://etherscan.io';
    }

    // Función para obtener nombre de red desde chain ID
    getNetworkNameFromChainId(chainId) {
        const networkNames = {
            '0x1': 'Ethereum Mainnet',
            '0x89': 'Polygon Mainnet',
            '0xa4b1': 'Arbitrum One Mainnet',
            '0xa': 'Optimism Mainnet',
            '0x38': 'Binance Smart Chain Mainnet',
            '0xfa': 'Fantom Opera Mainnet',
            '0x19': 'Cronos Mainnet',
            '0xa86a': 'Avalanche C-Chain Mainnet',
            '0x64': 'Gnosis Chain Mainnet',
            '0x504': 'Moonbeam Mainnet',
            '0x2105': 'Base Mainnet'
        };
        return networkNames[chainId] || `Red ${chainId}`;
    }

    // Función para obtener blockchain desde chain ID
    getBlockchainFromChainId(chainId) {
        const blockchainMap = {
            '0x1': 'ethereum',
            '0x89': 'polygon',
            '0xa4b1': 'arbitrum',
            '0xa': 'optimism',
            '0x38': 'bsc',
            '0xfa': 'fantom',
            '0x19': 'cronos',
            '0xa86a': 'avalanche',
            '0x64': 'gnosis',
            '0x504': 'moonbeam',
            '0x2105': 'base'
        };
        return blockchainMap[chainId] || null;
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 DOM cargado, inicializando ConfigManager...');
    
    try {
        window.configManager = new ConfigManager();
        console.log('✅ ConfigManager inicializado en window.configManager');
    } catch (error) {
        console.error('❌ Error creando ConfigManager:', error);
    }
});

// También ejecutar inmediatamente por si acaso
if (document.readyState === 'loading') {
    console.log('🔄 DOM aún cargando, esperando...');
} else {
    console.log('🚀 DOM ya listo, ejecutando inmediatamente...');
    
    try {
        window.configManager = new ConfigManager();
        console.log('✅ ConfigManager inicializado inmediatamente');
    } catch (error) {
        console.error('❌ Error creando ConfigManager inmediatamente:', error);
    }
}


