/**
 * 📈 Trade History - Sistema de Historial de Trades para ArbitrageX Pro 2025
 * 
 * Este módulo maneja el historial completo de trades incluyendo:
 * - Lista detallada de todos los trades
 * - Filtros avanzados por estrategia, blockchain, fecha, resultado
 * - Análisis de rendimiento por período
 * - Exportación a CSV/JSON
 * - Estadísticas detalladas
 */

class TradeHistoryManager {
    constructor() {
        this.trades = [];
        this.filteredTrades = [];
        this.filters = {
            strategy: 'all',
            blockchain: 'all',
            dateRange: 'all',
            result: 'all',
            minProfit: 0,
            maxProfit: 1000
        };
        
        this.sortBy = 'date';
        this.sortOrder = 'desc';
        this.currentPage = 1;
        this.itemsPerPage = 25;
        
        this.init();
    }

    init() {
        this.loadMockTrades();
        this.setupEventListeners();
        this.renderTrades();
        this.updateStatistics();
    }

    loadMockTrades() {
        // Generar datos mock para desarrollo
        const strategies = ['Flash-Loan', 'Cross-Chain', 'MEV-Protection', 'Atomic-Swap'];
        const blockchains = ['Ethereum', 'Polygon', 'BSC', 'Arbitrum', 'Optimism', 'Avalanche'];
        const results = ['success', 'failed', 'pending'];
        
        // TODO: Conectar con backend para obtener historial real de trades
        // TODO: Integrar con blockchain para verificar transacciones
        // TODO: Implementar paginación real de datos
        // TODO: Conectar con base de datos de trades ejecutados
        
        // Placeholder temporal - array vacío hasta implementar datos reales
        this.trades = [];
        this.filteredTrades = [];
        
        console.log('🔍 TODO: Implementar carga real de historial de trades');
    }

    getRandomToken() {
        const tokens = ['ETH', 'USDC', 'USDT', 'DAI', 'WBTC', 'UNI', 'LINK', 'AAVE', 'COMP', 'CRV'];
        return tokens[Math.floor(Math.random() * tokens.length)];
    }

    setupEventListeners() {
        // Filtros
        document.getElementById('strategy-filter')?.addEventListener('change', (e) => {
            this.filters.strategy = e.target.value;
            this.applyFilters();
        });
        
        document.getElementById('blockchain-filter')?.addEventListener('change', (e) => {
            this.filters.blockchain = e.target.value;
            this.applyFilters();
        });
        
        document.getElementById('date-range-filter')?.addEventListener('change', (e) => {
            this.filters.dateRange = e.target.value;
            this.applyFilters();
        });
        
        document.getElementById('result-filter')?.addEventListener('change', (e) => {
            this.filters.result = e.target.value;
            this.applyFilters();
        });
        
        document.getElementById('min-profit-filter')?.addEventListener('input', (e) => {
            this.filters.minProfit = parseFloat(e.target.value) || 0;
            this.applyFilters();
        });
        
        document.getElementById('max-profit-filter')?.addEventListener('input', (e) => {
            this.filters.maxProfit = parseFloat(e.target.value) || 1000;
            this.applyFilters();
        });
        
        // Ordenamiento
        document.getElementById('sort-by')?.addEventListener('change', (e) => {
            this.sortBy = e.target.value;
            this.sortTrades();
            this.renderTrades();
        });
        
        // Paginación
        document.getElementById('prev-page')?.addEventListener('click', () => {
            if (this.currentPage > 1) {
                this.currentPage--;
                this.renderTrades();
            }
        });
        
        document.getElementById('next-page')?.addEventListener('click', () => {
            const maxPages = Math.ceil(this.filteredTrades.length / this.itemsPerPage);
            if (this.currentPage < maxPages) {
                this.currentPage++;
                this.renderTrades();
            }
        });
        
        // Exportación
        document.getElementById('export-csv')?.addEventListener('click', () => {
            this.exportToCSV();
        });
        
        document.getElementById('export-json')?.addEventListener('click', () => {
            this.exportToJSON();
        });
        
        // Búsqueda
        document.getElementById('search-trades')?.addEventListener('input', (e) => {
            this.searchTrades(e.target.value);
        });
    }

    applyFilters() {
        this.filteredTrades = this.trades.filter(trade => {
            // Filtro por estrategia
            if (this.filters.strategy !== 'all' && trade.strategy !== this.filters.strategy) {
                return false;
            }
            
            // Filtro por blockchain
            if (this.filters.blockchain !== 'all' && trade.blockchain !== this.filters.blockchain) {
                return false;
            }
            
            // Filtro por resultado
            if (this.filters.result !== 'all' && trade.result !== this.filters.result) {
                return false;
            }
            
            // Filtro por rango de fechas
            if (this.filters.dateRange !== 'all') {
                const now = new Date();
                const tradeDate = new Date(trade.timestamp);
                const daysDiff = (now - tradeDate) / (1000 * 60 * 60 * 24);
                
                switch (this.filters.dateRange) {
                    case 'today':
                        if (daysDiff > 1) return false;
                        break;
                    case 'week':
                        if (daysDiff > 7) return false;
                        break;
                    case 'month':
                        if (daysDiff > 30) return false;
                        break;
                    case 'quarter':
                        if (daysDiff > 90) return false;
                        break;
                }
            }
            
            // Filtro por rango de ganancias
            if (trade.profit < this.filters.minProfit || trade.profit > this.filters.maxProfit) {
                return false;
            }
            
            return true;
        });
        
        this.currentPage = 1;
        this.sortTrades();
        this.renderTrades();
        this.updateStatistics();
    }

    sortTrades() {
        this.filteredTrades.sort((a, b) => {
            let aValue, bValue;
            
            switch (this.sortBy) {
                case 'date':
                    aValue = a.timestamp;
                    bValue = b.timestamp;
                    break;
                case 'profit':
                    aValue = a.profit;
                    bValue = b.profit;
                    break;
                case 'profitPercentage':
                    aValue = a.profitPercentage;
                    bValue = b.profitPercentage;
                    break;
                case 'amountIn':
                    aValue = a.amountIn;
                    bValue = b.amountIn;
                    break;
                case 'executionTime':
                    aValue = a.executionTime;
                    bValue = b.executionTime;
                    break;
                default:
                    aValue = a.timestamp;
                    bValue = b.timestamp;
            }
            
            if (this.sortOrder === 'asc') {
                return aValue > bValue ? 1 : -1;
            } else {
                return aValue < bValue ? 1 : -1;
            }
        });
    }

    searchTrades(query) {
        if (!query.trim()) {
            this.filteredTrades = [...this.trades];
        } else {
            const searchTerm = query.toLowerCase();
            this.filteredTrades = this.trades.filter(trade => 
                trade.id.toLowerCase().includes(searchTerm) ||
                trade.strategy.toLowerCase().includes(searchTerm) ||
                trade.blockchain.toLowerCase().includes(searchTerm) ||
                trade.tokenIn.toLowerCase().includes(searchTerm) ||
                trade.tokenOut.toLowerCase().includes(searchTerm) ||
                trade.txHash.toLowerCase().includes(searchTerm)
            );
        }
        
        this.currentPage = 1;
        this.sortTrades();
        this.renderTrades();
        this.updateStatistics();
    }

    renderTrades() {
        const container = document.getElementById('trades-container');
        if (!container) return;
        
        const startIndex = (this.currentPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const pageTrades = this.filteredTrades.slice(startIndex, endIndex);
        
        container.innerHTML = pageTrades.map(trade => this.renderTradeRow(trade)).join('');
        
        this.updatePagination();
        this.updateTradeCount();
    }

    renderTradeRow(trade) {
        const statusClass = trade.result === 'success' ? 'text-green-400' : 
                           trade.result === 'failed' ? 'text-red-400' : 'text-yellow-400';
        
        const statusIcon = trade.result === 'success' ? 'fas fa-check-circle' : 
                          trade.result === 'failed' ? 'fas fa-times-circle' : 'fas fa-clock';
        
        const profitClass = trade.profit >= 0 ? 'text-green-400' : 'text-red-400';
        const profitIcon = trade.profit >= 0 ? 'fas fa-arrow-up' : 'fas fa-arrow-down';
        
        return `
            <tr class="border-b border-gray-700 hover:bg-gray-800 transition-colors">
                <td class="px-4 py-3 text-sm">
                    <div class="flex items-center space-x-2">
                        <span class="font-mono text-blue-400">${trade.id}</span>
                        <button onclick="copyToClipboard('${trade.id}')" class="text-gray-400 hover:text-white">
                            <i class="fas fa-copy text-xs"></i>
                        </button>
                    </div>
                </td>
                <td class="px-4 py-3 text-sm">
                    <div class="flex items-center space-x-2">
                        <span class="text-gray-300">${trade.timestamp.toLocaleDateString('es-ES')}</span>
                        <span class="text-gray-500">${trade.timestamp.toLocaleTimeString('es-ES')}</span>
                    </div>
                </td>
                <td class="px-4 py-3 text-sm">
                    <span class="px-2 py-1 rounded-full text-xs font-medium bg-blue-900 text-blue-300">
                        ${trade.strategy}
                    </span>
                </td>
                <td class="px-4 py-3 text-sm">
                    <span class="px-2 py-1 rounded-full text-xs font-medium bg-purple-900 text-purple-300">
                        ${trade.blockchain}
                    </span>
                </td>
                <td class="px-4 py-3 text-sm">
                    <div class="flex items-center space-x-2">
                        <span class="text-gray-300">${trade.amountIn}</span>
                        <span class="text-gray-500">${trade.tokenIn}</span>
                    </div>
                </td>
                <td class="px-4 py-3 text-sm">
                    <div class="flex items-center space-x-2">
                        <span class="text-gray-300">${trade.amountOut}</span>
                        <span class="text-gray-500">${trade.tokenOut}</span>
                    </div>
                </td>
                <td class="px-4 py-3 text-sm">
                    <div class="flex items-center space-x-1 ${profitClass}">
                        <i class="${profitIcon} text-xs"></i>
                        <span class="font-medium">${trade.profit.toFixed(2)}</span>
                        <span class="text-gray-500">(${trade.profitPercentage.toFixed(2)}%)</span>
                    </div>
                </td>
                <td class="px-4 py-3 text-sm">
                    <div class="flex items-center space-x-2">
                        <span class="text-gray-300">${trade.gasUsed.toLocaleString()}</span>
                        <span class="text-gray-500">wei</span>
                    </div>
                </td>
                <td class="px-4 py-3 text-sm">
                    <div class="flex items-center space-x-2 ${statusClass}">
                        <i class="${statusIcon}"></i>
                        <span class="capitalize">${trade.result}</span>
                    </div>
                </td>
                <td class="px-4 py-3 text-sm">
                    <div class="flex items-center space-x-2">
                        <button onclick="viewTradeDetails('${trade.id}')" class="text-blue-400 hover:text-blue-300">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button onclick="copyToClipboard('${trade.txHash}')" class="text-gray-400 hover:text-white">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    updatePagination() {
        const totalPages = Math.ceil(this.filteredTrades.length / this.itemsPerPage);
        const paginationContainer = document.getElementById('pagination');
        
        if (!paginationContainer) return;
        
        let paginationHTML = '';
        
        // Botón anterior
        paginationHTML += `
            <button id="prev-page" class="px-3 py-2 rounded-lg ${this.currentPage === 1 ? 'bg-gray-700 text-gray-400 cursor-not-allowed' : 'bg-gray-600 text-white hover:bg-gray-500'}">
                <i class="fas fa-chevron-left mr-1"></i>
                Anterior
            </button>
        `;
        
        // Números de página
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= this.currentPage - 2 && i <= this.currentPage + 2)) {
                paginationHTML += `
                    <button class="page-number px-3 py-2 rounded-lg ${i === this.currentPage ? 'bg-blue-600 text-white' : 'bg-gray-600 text-gray-300 hover:bg-gray-500'}" data-page="${i}">
                        ${i}
                    </button>
                `;
            } else if (i === this.currentPage - 3 || i === this.currentPage + 3) {
                paginationHTML += '<span class="px-2 py-2 text-gray-400">...</span>';
            }
        }
        
        // Botón siguiente
        paginationHTML += `
            <button id="next-page" class="px-3 py-2 rounded-lg ${this.currentPage === totalPages ? 'bg-gray-700 text-gray-400 cursor-not-allowed' : 'bg-gray-600 text-white hover:bg-gray-500'}">
                Siguiente
                <i class="fas fa-chevron-right ml-1"></i>
            </button>
        `;
        
        paginationContainer.innerHTML = paginationHTML;
        
        // Event listeners para números de página
        document.querySelectorAll('.page-number').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.currentPage = parseInt(e.target.dataset.page);
                this.renderTrades();
            });
        });
    }

    updateTradeCount() {
        const countContainer = document.getElementById('trade-count');
        if (countContainer) {
            countContainer.textContent = `${this.filteredTrades.length} trades encontrados`;
        }
    }

    updateStatistics() {
        const stats = this.calculateStatistics();
        this.renderStatistics(stats);
    }

    calculateStatistics() {
        const successfulTrades = this.filteredTrades.filter(t => t.result === 'success');
        const failedTrades = this.filteredTrades.filter(t => t.result === 'failed');
        
        const totalProfit = successfulTrades.reduce((sum, t) => sum + t.profit, 0);
        const totalLoss = failedTrades.reduce((sum, t) => sum + Math.abs(t.profit), 0);
        const netProfit = totalProfit - totalLoss;
        
        const avgProfit = successfulTrades.length > 0 ? totalProfit / successfulTrades.length : 0;
        const avgLoss = failedTrades.length > 0 ? totalLoss / failedTrades.length : 0;
        
        const winRate = this.filteredTrades.length > 0 ? 
            (successfulTrades.length / this.filteredTrades.length) * 100 : 0;
        
        const totalVolume = this.filteredTrades.reduce((sum, t) => sum + t.amountIn, 0);
        const avgExecutionTime = this.filteredTrades.reduce((sum, t) => sum + t.executionTime, 0) / this.filteredTrades.length;
        
        return {
            totalTrades: this.filteredTrades.length,
            successfulTrades: successfulTrades.length,
            failedTrades: failedTrades.length,
            totalProfit,
            totalLoss,
            netProfit,
            avgProfit,
            avgLoss,
            winRate,
            totalVolume,
            avgExecutionTime
        };
    }

    renderStatistics(stats) {
        const container = document.getElementById('statistics-container');
        if (!container) return;
        
        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-gray-800 rounded-lg p-4 border border-gray-700">
                    <h4 class="text-gray-400 text-sm mb-2">Total de Trades</h4>
                    <p class="text-2xl font-bold text-white">${stats.totalTrades.toLocaleString()}</p>
                    <div class="flex items-center space-x-2 mt-2">
                        <span class="text-green-400 text-sm">${stats.successfulTrades}</span>
                        <span class="text-gray-500">/</span>
                        <span class="text-red-400 text-sm">${stats.failedTrades}</span>
                    </div>
                </div>
                
                <div class="bg-gray-800 rounded-lg p-4 border border-gray-700">
                    <h4 class="text-gray-400 text-sm mb-2">Win Rate</h4>
                    <p class="text-2xl font-bold text-green-400">${stats.winRate.toFixed(1)}%</p>
                    <p class="text-gray-500 text-sm mt-1">${stats.successfulTrades} exitosos</p>
                </div>
                
                <div class="bg-gray-800 rounded-lg p-4 border border-gray-700">
                    <h4 class="text-gray-400 text-sm mb-2">Beneficio Neto</h4>
                    <p class="text-2xl font-bold ${stats.netProfit >= 0 ? 'text-green-400' : 'text-red-400'}">
                        ${stats.netProfit >= 0 ? '+' : ''}${stats.netProfit.toFixed(2)} USD
                    </p>
                    <p class="text-gray-500 text-sm mt-1">Promedio: ${stats.avgProfit.toFixed(2)}</p>
                </div>
                
                <div class="bg-gray-800 rounded-lg p-4 border border-gray-700">
                    <h4 class="text-gray-400 text-sm mb-2">Volumen Total</h4>
                    <p class="text-2xl font-bold text-blue-400">${stats.totalVolume.toFixed(2)} USD</p>
                    <p class="text-gray-500 text-sm mt-1">Tiempo avg: ${stats.avgExecutionTime.toFixed(0)}ms</p>
                </div>
            </div>
        `;
    }

    exportToCSV() {
        const headers = ['ID', 'Fecha', 'Estrategia', 'Blockchain', 'Token In', 'Token Out', 'Cantidad In', 'Cantidad Out', 'Beneficio', 'Beneficio %', 'Gas', 'Resultado', 'Hash TX'];
        
        const csvContent = [
            headers.join(','),
            ...this.filteredTrades.map(trade => [
                trade.id,
                trade.timestamp.toISOString(),
                trade.strategy,
                trade.blockchain,
                trade.tokenIn,
                trade.tokenOut,
                trade.amountIn,
                trade.amountOut,
                trade.profit,
                trade.profitPercentage,
                trade.gasUsed,
                trade.result,
                trade.txHash
            ].join(','))
        ].join('\n');
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `trades-${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
    }

    exportToJSON() {
        const data = {
            exportDate: new Date().toISOString(),
            totalTrades: this.filteredTrades.length,
            filters: this.filters,
            trades: this.filteredTrades
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `trades-${new Date().toISOString().split('T')[0]}.json`;
        link.click();
    }

    // Métodos públicos para integración
    getTradeById(id) {
        return this.trades.find(trade => trade.id === id);
    }

    getTradesByStrategy(strategy) {
        return this.trades.filter(trade => trade.strategy === strategy);
    }

    getTradesByBlockchain(blockchain) {
        return this.trades.filter(trade => trade.blockchain === blockchain);
    }

    getTradesByDateRange(startDate, endDate) {
        return this.trades.filter(trade => 
            trade.timestamp >= startDate && trade.timestamp <= endDate
        );
    }

    refreshData() {
        this.loadMockTrades();
        this.applyFilters();
    }
}

// Funciones globales para uso desde HTML
window.copyToClipboard = (text) => {
    navigator.clipboard.writeText(text).then(() => {
        // Mostrar notificación
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-600 text-white px-4 py-2 rounded-lg z-50';
        notification.textContent = 'Copiado al portapapeles';
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 2000);
    });
};

window.viewTradeDetails = (tradeId) => {
    if (window.tradeHistoryManager) {
        const trade = window.tradeHistoryManager.getTradeById(tradeId);
        if (trade) {
            // Aquí puedes implementar un modal con detalles del trade
            alert(`Detalles del trade ${tradeId}\nEstrategia: ${trade.strategy}\nBlockchain: ${trade.blockchain}\nBeneficio: ${trade.profit} USD`);
        }
    }
};

// Exportar la clase para uso global
window.TradeHistoryManager = TradeHistoryManager;

// Auto-inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.tradeHistoryManager = new TradeHistoryManager();
});

