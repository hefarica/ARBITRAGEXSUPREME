/**
 * 🔍 Contract Watcher Configuration para ArbitrageX Pro 2025
 * Sistema de vigilancia automática de contratos backend
 */

// Configuración global del Contract Watcher
window.ARBITRAGEX_CONTRACT_CONFIG = {
    // Fuentes de contrato para ArbitrageX
    contractSources: [
        '/api/openapi.json',                    // Contrato principal
        '/openapi.json',                        // Alternativo
        '/.well-known/schema-index.json',       // Índice de schemas
        '/api/opportunities/schema',            // Schema de oportunidades
        '/api/assets/schema',                   // Schema de assets
        '/api/dexes/schema',                    // Schema de DEXs
        '/api/strategies/schema',               // Schema de estrategias
        '/api/blockchains/schema'               // Schema de blockchains
    ],
    
    // Configuración de vigilancia
    watchInterval: 30000,                       // 30 segundos
    enableSSE: true,                           // Server-Sent Events
    enablePolling: true,                       // Polling como fallback
    debugMode: true,                           // Logs detallados
    
    // Configuración de UI
    showConfirmationModal: true,               // Modal de confirmación
    autoApplyChanges: false,                   // No aplicar automáticamente
    preserveUserSettings: true,                // Preservar configuraciones del usuario
    
    // Integración con sistema existente
    integrateWithExisting: true,               // Integrar con app.js existente
    updateOpportunitiesList: true,             // Actualizar lista de oportunidades
    updateBlockchainStatus: true,              // Actualizar estado de blockchains
    updateStrategyFilters: true,               // Actualizar filtros de estrategias
    
    // Endpoints específicos de ArbitrageX
    arbitragexEndpoints: {
        opportunities: '/api/opportunities',
        strategies: '/api/strategies',
        blockchains: '/api/blockchains',
        prices: '/api/prices',
        execution: '/api/execution',
        metrics: '/api/metrics'
    }
};

// Configuración de templates para ArbitrageX
window.ARBITRAGEX_TEMPLATES = {
    // Template para oportunidades de arbitraje
    opportunityCard: (opportunity) => `
        <div class="bg-gray-800 rounded-xl border border-gray-700 p-4 hover:border-blue-500 transition-colors">
            <div class="flex items-center justify-between mb-3">
                <div class="flex items-center space-x-2">
                    <span class="text-sm font-medium text-gray-300">${opportunity.strategy || 'Estrategia'}</span>
                    <span class="px-2 py-1 bg-blue-500 bg-opacity-20 text-blue-400 rounded text-xs">${opportunity.blockchain || 'Blockchain'}</span>
                </div>
                <div class="text-right">
                    <div class="text-lg font-bold text-green-400">${opportunity.profit || '0'}%</div>
                    <div class="text-xs text-gray-400">Profit</div>
                </div>
            </div>
            <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-400">Exchange A:</span>
                    <span class="text-white">${opportunity.exchangeA || 'N/A'}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-400">Exchange B:</span>
                    <span class="text-white">${opportunity.exchangeB || 'N/A'}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-400">Token:</span>
                    <span class="text-white">${opportunity.token || 'N/A'}</span>
                </div>
            </div>
            <button class="w-full mt-3 px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-sm transition-colors">
                🚀 Ejecutar Arbitraje
            </button>
        </div>
    `,
    
    // Template para métricas del sistema
    metricCard: (metric) => `
        <div class="bg-gray-800 rounded-xl border border-gray-700 p-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-400 text-sm">${metric.label}</p>
                    <p class="text-2xl font-bold text-${metric.color || 'white'}">${metric.value}</p>
                </div>
                <div class="w-12 h-12 bg-${metric.color || 'blue'}-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                    <i class="fas fa-${metric.icon || 'chart-line'} text-${metric.color || 'blue'}-400"></i>
                </div>
            </div>
        </div>
    `,
    
    // Template para estado de blockchain
    blockchainStatus: (blockchain) => `
        <div class="flex items-center justify-between p-2 hover:bg-gray-700 rounded">
            <div class="flex items-center space-x-2">
                <div class="w-3 h-3 bg-${blockchain.connected ? 'green' : 'red'}-400 rounded-full"></div>
                <span class="text-sm">${blockchain.name}</span>
            </div>
            <span class="text-xs text-gray-400">${blockchain.connected ? 'Conectada' : 'Desconectada'}</span>
        </div>
    `
};

// Configuración de integración con app.js existente
window.ARBITRAGEX_INTEGRATION = {
    // Métodos para actualizar el sistema existente
    updateOpportunities: function(newOpportunities) {
        if (window.app && window.app.updateOpportunitiesDisplay) {
            window.app.updateOpportunitiesDisplay(newOpportunities);
        } else {
            console.log('⚠️ app.updateOpportunitiesDisplay no disponible');
        }
    },
    
    updateBlockchainCount: function(connectedCount) {
        const element = document.getElementById('connected-chains-count');
        if (element) {
            element.textContent = `${connectedCount}/8`;
        }
    },
    
    updateDailyProfit: function(profit) {
        const element = document.getElementById('daily-profit');
        if (element) {
            element.textContent = `$${profit}`;
        }
    },
    
    updateActiveOpportunities: function(count) {
        const element = document.getElementById('active-opportunities');
        if (element) {
            element.textContent = count;
        }
    },
    
    // Método para sincronizar con el sistema de configuración
    syncWithConfig: function() {
        if (window.configManager && window.configManager.getConnections) {
            const connections = window.configManager.getConnections();
            this.updateBlockchainCount(connections.connectedCount || 0);
        }
    }
};

// Configuración de notificaciones
window.ARBITRAGEX_NOTIFICATIONS = {
    showToast: function(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg text-white z-50 ${
            type === 'success' ? 'bg-green-500' :
            type === 'error' ? 'bg-red-500' :
            type === 'warning' ? 'bg-yellow-500' :
            'bg-blue-500'
        }`;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 3000);
    },
    
    showModal: function(title, content, onConfirm, onCancel) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-gray-800 rounded-xl p-6 max-w-md mx-4">
                <h3 class="text-lg font-bold mb-4">${title}</h3>
                <div class="mb-4">${content}</div>
                <div class="flex gap-3">
                    <button class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600" id="confirm-btn">
                        ✅ Confirmar
                    </button>
                    <button class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600" id="cancel-btn">
                        ❌ Cancelar
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Event listeners
        modal.querySelector('#confirm-btn').onclick = () => {
            modal.remove();
            if (onConfirm) onConfirm();
        };
        
        modal.querySelector('#cancel-btn').onclick = () => {
            modal.remove();
            if (onCancel) onCancel();
        };
    }
};

// Inicialización automática cuando se carga la página
document.addEventListener('DOMContentLoaded', function() {
    console.log('🔧 Configuración del Contract Watcher cargada');
    console.log('📋 Configuración:', window.ARBITRAGEX_CONTRACT_CONFIG);
    
    // Sincronizar con el sistema existente después de un delay
    setTimeout(() => {
        if (window.ARBITRAGEX_INTEGRATION.syncWithConfig) {
            window.ARBITRAGEX_INTEGRATION.syncWithConfig();
        }
    }, 1000);
});

// Exportar configuración para uso global
window.ArbitrageXContractConfig = {
    config: window.ARBITRAGEX_CONTRACT_CONFIG,
    templates: window.ARBITRAGEX_TEMPLATES,
    integration: window.ARBITRAGEX_INTEGRATION,
    notifications: window.ARBITRAGEX_NOTIFICATIONS
};
