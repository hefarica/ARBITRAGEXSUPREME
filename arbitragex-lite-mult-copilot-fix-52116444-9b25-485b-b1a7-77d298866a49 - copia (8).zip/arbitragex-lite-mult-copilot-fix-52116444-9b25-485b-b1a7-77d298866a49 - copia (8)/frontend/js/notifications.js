/**
 * 🔔 Notifications.js - Sistema de Alertas Push para ArbitrageX Pro 2025
 * 
 * Este módulo maneja todas las notificaciones del navegador incluyendo:
 * - Alertas de trades exitosos/fallidos
 * - Notificaciones de precios y oportunidades
 * - Alertas del sistema y blockchain
 * - Configuración de notificaciones
 * - Historial de notificaciones
 */

class ArbitrageXNotifications {
    constructor() {
        this.isSupported = 'Notification' in window;
        this.permission = 'default';
        this.notifications = [];
        this.settings = {
            tradeAlerts: true,
            priceAlerts: true,
            systemAlerts: true,
            soundEnabled: true,
            desktopNotifications: true,
            tradeThreshold: 0.5, // % mínimo para notificar
            priceChangeThreshold: 2.0, // % mínimo para notificar
            maxNotifications: 50
        };
        
        this.sounds = {
            success: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT'),
            error: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT'),
            alert: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT')
        };
        
        this.init();
    }
    
    init() {
        this.loadSettings();
        this.checkPermission();
        this.setupEventListeners();
        this.startNotificationService();
        
        if (this.isSupported) {
            console.log('🔔 Sistema de notificaciones inicializado');
        } else {
            console.warn('⚠️ Notificaciones no soportadas en este navegador');
        }
    }
    
    async checkPermission() {
        if (!this.isSupported) return;
        
        if (Notification.permission === 'granted') {
            this.permission = 'granted';
        } else if (Notification.permission === 'denied') {
            this.permission = 'denied';
        } else {
            this.permission = 'default';
        }
    }
    
    async requestPermission() {
        if (!this.isSupported) return false;
        
        try {
            const permission = await Notification.requestPermission();
            this.permission = permission;
            
            if (permission === 'granted') {
                this.showNotification('Notificaciones Activadas', 'Ahora recibirás alertas de trades y oportunidades', 'success');
                return true;
            } else {
                this.showNotification('Permiso Denegado', 'Las notificaciones están deshabilitadas', 'error');
                return false;
            }
        } catch (error) {
            console.error('Error al solicitar permiso de notificaciones:', error);
            return false;
        }
    }
    
    showNotification(title, body, type = 'info', options = {}) {
        if (!this.isSupported || this.permission !== 'granted') return;
        
        const defaultOptions = {
            icon: this.getNotificationIcon(type),
            badge: '/images/logos/arbitragex-badge.png',
            tag: 'arbitragex-notification',
            requireInteraction: type === 'error',
            actions: this.getNotificationActions(type),
            data: {
                type: type,
                timestamp: Date.now(),
                source: 'ArbitrageX Pro 2025'
            }
        };
        
        const notification = new Notification(title, { ...defaultOptions, ...options });
        
        // Agregar a historial
        this.addToHistory({
            id: Date.now(),
            title,
            body,
            type,
            timestamp: new Date(),
            read: false
        });
        
        // Reproducir sonido si está habilitado
        if (this.settings.soundEnabled) {
            this.playSound(type);
        }
        
        // Auto-cerrar notificaciones de info después de 5 segundos
        if (type === 'info') {
            setTimeout(() => {
                notification.close();
            }, 5000);
        }
        
        // Event listeners para la notificación
        notification.onclick = () => {
            this.handleNotificationClick(notification);
        };
        
        notification.onclose = () => {
            this.markAsRead(notification.data.timestamp);
        };
        
        return notification;
    }
    
    getNotificationIcon(type) {
        const icons = {
            success: '/images/logos/success-icon.png',
            error: '/images/logos/error-icon.png',
            warning: '/images/logos/warning-icon.png',
            info: '/images/logos/info-icon.png',
            trade: '/images/logos/trade-icon.png',
            price: '/images/logos/price-icon.png',
            system: '/images/logos/system-icon.png'
        };
        
        return icons[type] || icons.info;
    }
    
    getNotificationActions(type) {
        const actions = {
            trade: [
                { action: 'view', title: 'Ver Trade' },
                { action: 'dismiss', title: 'Descartar' }
            ],
            price: [
                { action: 'analyze', title: 'Analizar' },
                { action: 'dismiss', title: 'Descartar' }
            ],
            error: [
                { action: 'retry', title: 'Reintentar' },
                { action: 'dismiss', title: 'Descartar' }
            ]
        };
        
        return actions[type] || [];
    }
    
    playSound(type) {
        const sound = this.sounds[type] || this.sounds.alert;
        if (sound) {
            sound.currentTime = 0;
            sound.play().catch(error => {
                console.warn('No se pudo reproducir sonido:', error);
            });
        }
    }
    
    // Notificaciones específicas de trades
    notifyTradeSuccess(tradeData) {
        if (!this.settings.tradeAlerts) return;
        
        const title = '✅ Trade Exitoso';
        const body = `Trade #${tradeData.id} completado con ganancia de ${tradeData.profit}%`;
        
        this.showNotification(title, body, 'success', {
            tag: `trade-${tradeData.id}`,
            data: { ...tradeData, type: 'trade' }
        });
    }
    
    notifyTradeFailed(tradeData) {
        if (!this.settings.tradeAlerts) return;
        
        const title = '❌ Trade Fallido';
        const body = `Trade #${tradeData.id} falló: ${tradeData.error || 'Error desconocido'}`;
        
        this.showNotification(title, body, 'error', {
            tag: `trade-${tradeData.id}`,
            data: { ...tradeData, type: 'trade' }
        });
    }
    
    notifyPriceAlert(token, oldPrice, newPrice, changePercent) {
        if (!this.settings.priceAlerts || Math.abs(changePercent) < this.settings.priceChangeThreshold) return;
        
        const direction = changePercent > 0 ? '📈' : '📉';
        const title = `${direction} Alerta de Precio`;
        const body = `${token} cambió ${Math.abs(changePercent).toFixed(2)}% (${oldPrice} → ${newPrice})`;
        
        this.showNotification(title, body, 'price', {
            tag: `price-${token}`,
            data: { token, oldPrice, newPrice, changePercent, type: 'price' }
        });
    }
    
    notifyOpportunity(opportunity) {
        if (!this.settings.tradeAlerts) return;
        
        const title = '🎯 Nueva Oportunidad';
        const body = `${opportunity.strategy} en ${opportunity.blockchain} - ROI: ${opportunity.roi}%`;
        
        this.showNotification(title, body, 'trade', {
            tag: `opportunity-${opportunity.id}`,
            data: { ...opportunity, type: 'opportunity' }
        });
    }
    
    notifySystemAlert(message, type = 'warning') {
        if (!this.settings.systemAlerts) return;
        
        const title = '⚙️ Alerta del Sistema';
        const body = message;
        
        this.showNotification(title, body, type, {
            tag: `system-${Date.now()}`,
            data: { message, type: 'system' }
        });
    }
    
    notifyBlockchainStatus(blockchain, status, details) {
        if (!this.settings.systemAlerts) return;
        
        const icons = {
            connected: '🟢',
            disconnected: '🔴',
            slow: '🟡',
            error: '⚠️'
        };
        
        const title = `${icons[status] || '❓'} ${blockchain}`;
        const body = details || `Estado: ${status}`;
        
        this.showNotification(title, body, status === 'error' ? 'error' : 'info', {
            tag: `blockchain-${blockchain}`,
            data: { blockchain, status, details, type: 'blockchain' }
        });
    }
    
    // Manejo de historial de notificaciones
    addToHistory(notification) {
        this.notifications.unshift(notification);
        
        // Mantener solo las últimas notificaciones
        if (this.notifications.length > this.settings.maxNotifications) {
            this.notifications = this.notifications.slice(0, this.settings.maxNotifications);
        }
        
        this.saveHistory();
        this.updateNotificationBadge();
    }
    
    markAsRead(timestamp) {
        const notification = this.notifications.find(n => n.timestamp.getTime() === timestamp);
        if (notification) {
            notification.read = true;
            this.saveHistory();
            this.updateNotificationBadge();
        }
    }
    
    markAllAsRead() {
        this.notifications.forEach(n => n.read = true);
        this.saveHistory();
        this.updateNotificationBadge();
    }
    
    clearHistory() {
        this.notifications = [];
        this.saveHistory();
        this.updateNotificationBadge();
    }
    
    getUnreadCount() {
        return this.notifications.filter(n => !n.read).length;
    }
    
    updateNotificationBadge() {
        const count = this.getUnreadCount();
        const badge = document.getElementById('notificationBadge');
        
        if (badge) {
            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : count;
                badge.classList.remove('hidden');
            } else {
                badge.classList.add('hidden');
            }
        }
    }
    
    // Configuración
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
        this.saveSettings();
        
        // Notificar cambios
        this.showNotification('Configuración Actualizada', 'Las preferencias de notificaciones han sido guardadas', 'info');
    }
    
    toggleSound() {
        this.settings.soundEnabled = !this.settings.soundEnabled;
        this.saveSettings();
        
        const message = this.settings.soundEnabled ? 'Sonidos habilitados' : 'Sonidos deshabilitados';
        this.showNotification('Sonidos', message, 'info');
    }
    
    toggleDesktopNotifications() {
        if (this.permission === 'denied') {
            this.showNotification('Permiso Denegado', 'Habilita las notificaciones en la configuración del navegador', 'error');
            return;
        }
        
        this.settings.desktopNotifications = !this.settings.desktopNotifications;
        this.saveSettings();
        
        const message = this.settings.desktopNotifications ? 'Notificaciones habilitadas' : 'Notificaciones deshabilitadas';
        this.showNotification('Notificaciones', message, 'info');
    }
    
    // Persistencia
    saveSettings() {
        try {
            localStorage.setItem('arbitragex-notifications-settings', JSON.stringify(this.settings));
        } catch (error) {
            console.error('Error al guardar configuración de notificaciones:', error);
        }
    }
    
    loadSettings() {
        try {
            const saved = localStorage.getItem('arbitragex-notifications-settings');
            if (saved) {
                this.settings = { ...this.settings, ...JSON.parse(saved) };
            }
        } catch (error) {
            console.error('Error al cargar configuración de notificaciones:', error);
        }
    }
    
    saveHistory() {
        try {
            const history = this.notifications.map(n => ({
                ...n,
                timestamp: n.timestamp.toISOString()
            }));
            localStorage.setItem('arbitragex-notifications-history', JSON.stringify(history));
        } catch (error) {
            console.error('Error al guardar historial de notificaciones:', error);
        }
    }
    
    loadHistory() {
        try {
            const saved = localStorage.getItem('arbitragex-notifications-history');
            if (saved) {
                const history = JSON.parse(saved);
                this.notifications = history.map(n => ({
                    ...n,
                    timestamp: new Date(n.timestamp)
                }));
            }
        } catch (error) {
            console.error('Error al cargar historial de notificaciones:', error);
        }
    }
    
    // Event handlers
    handleNotificationClick(notification) {
        const data = notification.data;
        
        switch (data.type) {
            case 'trade':
                this.handleTradeNotification(data);
                break;
            case 'opportunity':
                this.handleOpportunityNotification(data);
                break;
            case 'price':
                this.handlePriceNotification(data);
                break;
            case 'system':
                this.handleSystemNotification(data);
                break;
            case 'blockchain':
                this.handleBlockchainNotification(data);
                break;
        }
        
        notification.close();
    }
    
    handleTradeNotification(tradeData) {
        // Navegar a la página de historial de trades
        if (window.location.pathname.includes('trade-history.html')) {
            // Si ya estamos en la página de historial, buscar el trade
            if (window.TradeHistoryManager) {
                const tradeManager = window.TradeHistoryManager.getInstance();
                if (tradeManager) {
                    tradeManager.highlightTrade(tradeData.id);
                }
            }
        } else {
            // Navegar a la página de historial
            window.location.href = 'trade-history.html';
        }
    }
    
    handleOpportunityNotification(opportunityData) {
        // Navegar al dashboard principal
        if (!window.location.pathname.includes('index.html')) {
            window.location.href = 'index.html';
        }
        
        // Resaltar la oportunidad en el dashboard
        this.highlightOpportunity(opportunityData);
    }
    
    handlePriceNotification(priceData) {
        // Mostrar análisis de precios
        this.showPriceAnalysis(priceData);
    }
    
    handleSystemNotification(systemData) {
        // Mostrar detalles del sistema
        this.showSystemDetails(systemData);
    }
    
    handleBlockchainNotification(blockchainData) {
        // Navegar a la página de configuración de blockchain
        if (!window.location.pathname.includes('config.html')) {
            window.location.href = 'config.html';
        }
        
        // Resaltar el estado de la blockchain
        this.highlightBlockchainStatus(blockchainData);
    }
    
    // Métodos de utilidad
    highlightOpportunity(opportunity) {
        // Implementar lógica para resaltar oportunidades en el dashboard
        const event = new CustomEvent('highlightOpportunity', { detail: opportunity });
        window.dispatchEvent(event);
    }
    
    showPriceAnalysis(priceData) {
        // Implementar modal de análisis de precios
        const event = new CustomEvent('showPriceAnalysis', { detail: priceData });
        window.dispatchEvent(event);
    }
    
    showSystemDetails(systemData) {
        // Implementar modal de detalles del sistema
        const event = new CustomEvent('showSystemDetails', { detail: systemData });
        window.dispatchEvent(event);
    }
    
    highlightBlockchainStatus(blockchainData) {
        // Implementar resaltado de estado de blockchain
        const event = new CustomEvent('highlightBlockchainStatus', { detail: blockchainData });
        window.dispatchEvent(event);
    }
    
    // Servicio de notificaciones en tiempo real
    startNotificationService() {
        // Simular notificaciones de prueba cada 30 segundos
        setInterval(() => {
            if (this.settings.tradeAlerts && Math.random() > 0.7) {
                this.simulateTradeNotification();
            }
            
            if (this.settings.priceAlerts && Math.random() > 0.8) {
                this.simulatePriceNotification();
            }
        }, 30000);
    }
    
    simulateTradeNotification() {
        const trades = [
            { id: Math.floor(Math.random() * 1000), profit: (Math.random() * 10 - 2).toFixed(2) },
            { id: Math.floor(Math.random() * 1000), error: 'Gas price too high' }
        ];
        
        const trade = trades[Math.floor(Math.random() * trades.length)];
        
        if (trade.profit) {
            this.notifyTradeSuccess(trade);
        } else {
            this.notifyTradeFailed(trade);
        }
    }
    
    simulatePriceNotification() {
        const tokens = ['ETH', 'BTC', 'USDC', 'DAI', 'UNI'];
        const token = tokens[Math.floor(Math.random() * tokens.length)];
        const oldPrice = (Math.random() * 1000 + 100).toFixed(2);
        const changePercent = (Math.random() * 20 - 10).toFixed(2);
        const newPrice = (oldPrice * (1 + changePercent / 100)).toFixed(2);
        
        this.notifyPriceAlert(token, oldPrice, newPrice, parseFloat(changePercent));
    }
    
    // Setup de event listeners
    setupEventListeners() {
        // Escuchar eventos de trades
        window.addEventListener('tradeCompleted', (event) => {
            const { trade, success } = event.detail;
            if (success) {
                this.notifyTradeSuccess(trade);
            } else {
                this.notifyTradeFailed(trade);
            }
        });
        
        // Escuchar eventos de oportunidades
        window.addEventListener('opportunityFound', (event) => {
            this.notifyOpportunity(event.detail);
        });
        
        // Escuchar eventos de precios
        window.addEventListener('priceChanged', (event) => {
            const { token, oldPrice, newPrice } = event.detail;
            const changePercent = ((newPrice - oldPrice) / oldPrice) * 100;
            this.notifyPriceAlert(token, oldPrice, newPrice, changePercent);
        });
        
        // Escuchar eventos del sistema
        window.addEventListener('systemAlert', (event) => {
            const { message, type } = event.detail;
            this.notifySystemAlert(message, type);
        });
        
        // Escuchar eventos de blockchain
        window.addEventListener('blockchainStatusChanged', (event) => {
            const { blockchain, status, details } = event.detail;
            this.notifyBlockchainStatus(blockchain, status, details);
        });
    }
    
    // Métodos públicos para uso externo
    getSettings() {
        return { ...this.settings };
    }
    
    getHistory() {
        return [...this.notifications];
    }
    
    testNotification(type = 'info') {
        const testMessages = {
            success: { title: '✅ Notificación de Prueba', body: 'Esta es una notificación de éxito de prueba' },
            error: { title: '❌ Notificación de Prueba', body: 'Esta es una notificación de error de prueba' },
            warning: { title: '⚠️ Notificación de Prueba', body: 'Esta es una notificación de advertencia de prueba' },
            info: { title: 'ℹ️ Notificación de Prueba', body: 'Esta es una notificación de información de prueba' }
        };
        
        const message = testMessages[type] || testMessages.info;
        this.showNotification(message.title, message.body, type);
    }
}

// Inicialización global
window.ArbitrageXNotifications = ArbitrageXNotifications;

// Crear instancia global cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    if (!window.notifications) {
        window.notifications = new ArbitrageXNotifications();
    }
});

// Exportar para uso en módulos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ArbitrageXNotifications;
}

