/**
 * 🛡️ MEV DEFENSE SYSTEM - Sistema de Defensa Activa y Contrataque
 * ==============================================================
 * Frontend JavaScript para el sistema de defensa MEV
 */

class MEVDefenseSystem {
    constructor() {
        this.defenseStatus = 'ACTIVE';
        this.activeThreats = new Map();
        this.defenseHistory = [];
        this.coalitionMembers = new Set();
        this.emergencyMode = 'NONE';
        this.defenseConfig = this.loadDefenseConfig();
        
        this.init();
    }

    async init() {
        console.log('🛡️ Iniciando Sistema de Defensa MEV...');
        
        // Inicializar event listeners
        this.setupEventListeners();
        
        // Cargar configuración guardada
        this.loadSavedDefenseConfig();
        
        // Verificar estado del backend
        await this.checkBackendStatus();
        
        // Iniciar monitoreo automático
        this.startDefenseMonitoring();
        
        // Mostrar notificación de inicio
        this.showDefenseNotification('Sistema de Defensa MEV iniciado', 'success');
    }

    setupEventListeners() {
        // Botones principales del sistema de defensa
        document.getElementById('defense-scan-btn')?.addEventListener('click', () => this.scanForThreats());
        document.getElementById('defense-auto-toggle')?.addEventListener('click', () => this.toggleAutoDefense());
        document.getElementById('coalition-join-btn')?.addEventListener('click', () => this.joinCoalition());
        document.getElementById('emergency-nuclear-btn')?.addEventListener('click', () => this.activateNuclearDefense());
        
        // Configuración del sistema
        document.getElementById('defense-config-form')?.addEventListener('submit', (e) => this.saveDefenseConfig(e));
        document.getElementById('defense-test-btn')?.addEventListener('click', () => this.testDefenseSystem());
        
        // Gestión de amenazas
        document.getElementById('threat-response-btn')?.addEventListener('click', () => this.executeDefenseResponse());
        document.getElementById('threat-escalate-btn')?.addEventListener('click', () => this.escalateThreat());
        
        // Modos de emergencia
        document.getElementById('emergency-persistent-btn')?.addEventListener('click', () => this.activatePersistentThreatMode());
        document.getElementById('emergency-coalition-btn')?.addEventListener('click', () => this.activateCoalitionWarMode());
        document.getElementById('emergency-deactivate-btn')?.addEventListener('click', () => this.deactivateEmergencyMode());
    }

    loadDefenseConfig() {
        return {
            autoResponse: true,
            escalationEnabled: true,
            coalitionMode: true,
            nuclearApprovalRequired: false,
            maxConcurrentThreats: 100,
            threatMemoryDuration: 86400,
            responseCooldown: 300,
            escalationThresholds: {
                minorToModerate: 3,
                moderateToMajor: 7,
                majorToNuclear: 15
            }
        };
    }

    loadSavedDefenseConfig() {
        try {
            const saved = localStorage.getItem('mev_defense_config');
            if (saved) {
                this.defenseConfig = { ...this.defenseConfig, ...JSON.parse(saved) };
                console.log('✅ Configuración de defensa cargada');
            }
        } catch (error) {
            console.error('❌ Error cargando configuración de defensa:', error);
        }
    }

    async checkBackendStatus() {
        try {
            const response = await fetch('/api/mev-defense/status');
            if (response.ok) {
                const status = await response.json();
                this.updateDefenseStatus(status);
                console.log('✅ Backend de defensa conectado');
            } else {
                console.warn('⚠️ Backend de defensa no disponible');
            }
        } catch (error) {
            console.error('❌ Error conectando con backend de defensa:', error);
        }
    }

    startDefenseMonitoring() {
        // Monitoreo automático cada 30 segundos
        setInterval(() => {
            if (this.defenseConfig.autoResponse) {
                this.autoScanForThreats();
            }
        }, 30000);

        // Actualización de estado cada 10 segundos
        setInterval(() => {
            this.updateDefenseDisplay();
        }, 10000);
    }

    async scanForThreats() {
        try {
            console.log('🔍 Escaneando en busca de amenazas...');
            this.showDefenseNotification('Escaneando amenazas...', 'info');
            
            const response = await fetch('/api/mev-defense/scan', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            
            if (response.ok) {
                const threats = await response.json();
                this.processDetectedThreats(threats);
                console.log(`✅ ${threats.length} amenazas detectadas`);
            } else {
                throw new Error('Error en escaneo');
            }
        } catch (error) {
            console.error('❌ Error escaneando amenazas:', error);
            this.showDefenseNotification('Error en escaneo de amenazas', 'error');
        }
    }

    async autoScanForThreats() {
        if (this.defenseStatus === 'ACTIVE' && this.activeThreats.size < this.defenseConfig.maxConcurrentThreats) {
            await this.scanForThreats();
        }
    }

    processDetectedThreats(threats) {
        threats.forEach(threat => {
            if (!this.activeThreats.has(threat.id)) {
                this.activeThreats.set(threat.id, threat);
                this.classifyThreatLevel(threat);
                this.addThreatToDisplay(threat);
                
                if (this.defenseConfig.autoResponse) {
                    this.executeAutomaticResponse(threat);
                }
            }
        });
        
        this.updateThreatCounter();
    }

    classifyThreatLevel(threat) {
        // Clasificar amenaza según patrones detectados
        let level = 'MINOR';
        
        if (threat.type === 'SANDWICH_ATTACKER' || threat.type === 'VALIDATOR_CORRUPTION') {
            level = 'CRITICAL';
        } else if (threat.type === 'FRONTRUNNER' || threat.type === 'MEMPOOL_SNIFFER') {
            level = 'HIGH';
        } else if (threat.type === 'COPYCAT') {
            level = 'MEDIUM';
        }
        
        threat.level = level;
        threat.classifiedAt = new Date().toISOString();
    }

    addThreatToDisplay(threat) {
        const container = document.getElementById('active-threats-list');
        if (!container) return;
        
        const threatCard = document.createElement('div');
        threatCard.className = 'bg-red-50 border border-red-200 rounded-lg p-4 mb-3';
        threatCard.id = `threat-${threat.id}`;
        
        const levelColor = {
            'MINOR': 'text-yellow-600',
            'MEDIUM': 'text-orange-600',
            'HIGH': 'text-red-600',
            'CRITICAL': 'text-red-800'
        };
        
        threatCard.innerHTML = `
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                    <div>
                        <h4 class="font-semibold text-gray-900">${threat.type.replace('_', ' ')}</h4>
                        <p class="text-sm text-gray-600">${threat.address}</p>
                        <p class="text-xs ${levelColor[threat.level]} font-medium">Nivel: ${threat.level}</p>
                    </div>
                </div>
                <div class="flex space-x-2">
                    <button onclick="window.mevDefense.executeDefenseResponse('${threat.id}')" 
                            class="px-3 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-700">
                        🛡️ Defender
                    </button>
                    <button onclick="window.mevDefense.escalateThreat('${threat.id}')" 
                            class="px-3 py-1 bg-orange-600 text-white text-xs rounded hover:bg-orange-700">
                        ⚡ Escalar
                    </button>
                </div>
            </div>
        `;
        
        container.appendChild(threatCard);
    }

    async executeAutomaticResponse(threat) {
        try {
            const response = await fetch('/api/mev-defense/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ threatId: threat.id })
            });
            
            if (response.ok) {
                const result = await response.json();
                this.recordDefenseResponse(threat.id, result);
                this.showDefenseNotification(`Respuesta automática ejecutada para ${threat.type}`, 'success');
            }
        } catch (error) {
            console.error('❌ Error en respuesta automática:', error);
        }
    }

    async executeDefenseResponse(threatId) {
        try {
            const threat = this.activeThreats.get(threatId);
            if (!threat) return;
            
            this.showDefenseNotification(`Ejecutando defensa contra ${threat.type}...`, 'info');
            
            const response = await fetch('/api/mev-defense/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ threatId, manual: true })
            });
            
            if (response.ok) {
                const result = await response.json();
                this.recordDefenseResponse(threatId, result);
                this.showDefenseNotification(`Defensa ejecutada exitosamente`, 'success');
                
                // Remover amenaza si fue neutralizada
                if (result.success && result.threatNeutralized) {
                    this.removeThreat(threatId);
                }
            }
        } catch (error) {
            console.error('❌ Error ejecutando defensa:', error);
            this.showDefenseNotification('Error ejecutando defensa', 'error');
        }
    }

    async escalateThreat(threatId) {
        try {
            const threat = this.activeThreats.get(threatId);
            if (!threat) return;
            
            this.showDefenseNotification(`Escalando amenaza ${threat.type}...`, 'warning');
            
            const response = await fetch('/api/mev-defense/escalate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ threatId })
            });
            
            if (response.ok) {
                const result = await response.json();
                this.showDefenseNotification(`Amenaza escalada a nivel ${result.newLevel}`, 'success');
                threat.level = result.newLevel;
                this.updateThreatDisplay(threatId);
            }
        } catch (error) {
            console.error('❌ Error escalando amenaza:', error);
            this.showDefenseNotification('Error escalando amenaza', 'error');
        }
    }

    async joinCoalition() {
        try {
            const coalitionId = prompt('Ingresa el ID de la coalición:');
            if (!coalitionId) return;
            
            this.showDefenseNotification('Uniéndose a coalición...', 'info');
            
            const response = await fetch('/api/mev-defense/coalition/join', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ coalitionId })
            });
            
            if (response.ok) {
                const result = await response.json();
                this.coalitionMembers.add(coalitionId);
                this.showDefenseNotification(`Unido a coalición ${coalitionId}`, 'success');
                this.updateCoalitionDisplay();
            }
        } catch (error) {
            console.error('❌ Error uniéndose a coalición:', error);
            this.showDefenseNotification('Error uniéndose a coalición', 'error');
        }
    }

    async activateNuclearDefense() {
        if (!this.defenseConfig.nuclearApprovalRequired || confirm('¿Estás seguro de activar el modo NUCLEAR? Esto puede causar daños colaterales.')) {
            try {
                this.showDefenseNotification('Activando modo NUCLEAR...', 'warning');
                
                const response = await fetch('/api/mev-defense/emergency/activate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: 'NUCLEAR_DEFENSE' })
                });
                
                if (response.ok) {
                    this.emergencyMode = 'NUCLEAR_DEFENSE';
                    this.showDefenseNotification('Modo NUCLEAR activado', 'error');
                    this.updateEmergencyModeDisplay();
                }
            } catch (error) {
                console.error('❌ Error activando modo nuclear:', error);
                this.showDefenseNotification('Error activando modo nuclear', 'error');
            }
        }
    }

    async activatePersistentThreatMode() {
        try {
            this.showDefenseNotification('Activando modo de amenaza persistente...', 'warning');
            
            const response = await fetch('/api/mev-defense/emergency/activate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mode: 'PERSISTENT_THREAT' })
            });
            
            if (response.ok) {
                this.emergencyMode = 'PERSISTENT_THREAT';
                this.showDefenseNotification('Modo de amenaza persistente activado', 'warning');
                this.updateEmergencyModeDisplay();
            }
        } catch (error) {
            console.error('❌ Error activando modo persistente:', error);
            this.showDefenseNotification('Error activando modo persistente', 'error');
        }
    }

    async activateCoalitionWarMode() {
        try {
            this.showDefenseNotification('Activando modo de guerra de coalición...', 'warning');
            
            const response = await fetch('/api/mev-defense/emergency/activate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mode: 'COALITION_WAR' })
            });
            
            if (response.ok) {
                this.emergencyMode = 'COALITION_WAR';
                this.showDefenseNotification('Modo de guerra de coalición activado', 'warning');
                this.updateEmergencyModeDisplay();
            }
        } catch (error) {
            console.error('❌ Error activando modo de coalición:', error);
            this.showDefenseNotification('Error activando modo de coalición', 'error');
        }
    }

    async deactivateEmergencyMode() {
        try {
            this.showDefenseNotification('Desactivando modo de emergencia...', 'info');
            
            const response = await fetch('/api/mev-defense/emergency/deactivate', {
                method: 'POST'
            });
            
            if (response.ok) {
                this.emergencyMode = 'NONE';
                this.showDefenseNotification('Modo de emergencia desactivado', 'success');
                this.updateEmergencyModeDisplay();
            }
        } catch (error) {
            console.error('❌ Error desactivando modo de emergencia:', error);
            this.showDefenseNotification('Error desactivando modo de emergencia', 'error');
        }
    }

    toggleAutoDefense() {
        this.defenseConfig.autoResponse = !this.defenseConfig.autoResponse;
        this.saveDefenseConfig();
        
        const button = document.getElementById('defense-auto-toggle');
        if (button) {
            button.textContent = `Auto Defensa: ${this.defenseConfig.autoResponse ? 'ON' : 'OFF'}`;
            button.className = this.defenseConfig.autoResponse ? 
                'bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors' :
                'bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors';
        }
        
        this.showDefenseNotification(
            `Auto defensa ${this.defenseConfig.autoResponse ? 'activada' : 'desactivada'}`,
            this.defenseConfig.autoResponse ? 'success' : 'warning'
        );
    }

    async saveDefenseConfig(event) {
        if (event) event.preventDefault();
        
        try {
            const formData = new FormData(event.target);
            const config = {
                autoResponse: formData.get('autoResponse') === 'on',
                escalationEnabled: formData.get('escalationEnabled') === 'on',
                coalitionMode: formData.get('coalitionMode') === 'on',
                nuclearApprovalRequired: formData.get('nuclearApprovalRequired') === 'on',
                maxConcurrentThreats: parseInt(formData.get('maxConcurrentThreats')),
                threatMemoryDuration: parseInt(formData.get('threatMemoryDuration')),
                responseCooldown: parseInt(formData.get('responseCooldown'))
            };
            
            this.defenseConfig = { ...this.defenseConfig, ...config };
            this.saveDefenseConfig();
            
            // Actualizar en el backend
            const response = await fetch('/api/mev-defense/config', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            });
            
            if (response.ok) {
                this.showDefenseNotification('Configuración guardada', 'success');
            }
        } catch (error) {
            console.error('❌ Error guardando configuración:', error);
            this.showDefenseNotification('Error guardando configuración', 'error');
        }
    }

    saveDefenseConfig() {
        try {
            localStorage.setItem('mev_defense_config', JSON.stringify(this.defenseConfig));
        } catch (error) {
            console.error('❌ Error guardando configuración local:', error);
        }
    }

    async testDefenseSystem() {
        try {
            this.showDefenseNotification('Probando sistema de defensa...', 'info');
            
            const response = await fetch('/api/mev-defense/test', {
                method: 'POST'
            });
            
            if (response.ok) {
                const result = await response.json();
                this.showDefenseNotification(`Prueba exitosa: ${result.message}`, 'success');
            } else {
                throw new Error('Error en prueba');
            }
        } catch (error) {
            console.error('❌ Error en prueba del sistema:', error);
            this.showDefenseNotification('Error en prueba del sistema', 'error');
        }
    }

    recordDefenseResponse(threatId, response) {
        const defenseRecord = {
            threatId,
            timestamp: new Date().toISOString(),
            response,
            success: response.success
        };
        
        this.defenseHistory.push(defenseRecord);
        this.updateDefenseHistoryDisplay();
    }

    removeThreat(threatId) {
        this.activeThreats.delete(threatId);
        const threatElement = document.getElementById(`threat-${threatId}`);
        if (threatElement) {
            threatElement.remove();
        }
        this.updateThreatCounter();
    }

    updateThreatDisplay(threatId) {
        const threat = this.activeThreats.get(threatId);
        if (!threat) return;
        
        const threatElement = document.getElementById(`threat-${threatId}`);
        if (threatElement) {
            const levelElement = threatElement.querySelector('.text-xs');
            if (levelElement) {
                levelElement.textContent = `Nivel: ${threat.level}`;
                levelElement.className = `text-xs ${this.getLevelColor(threat.level)} font-medium`;
            }
        }
    }

    getLevelColor(level) {
        const colors = {
            'MINOR': 'text-yellow-600',
            'MEDIUM': 'text-orange-600',
            'HIGH': 'text-red-600',
            'CRITICAL': 'text-red-800'
        };
        return colors[level] || 'text-gray-600';
    }

    updateThreatCounter() {
        const counter = document.getElementById('active-threats-count');
        if (counter) {
            counter.textContent = this.activeThreats.size;
        }
    }

    updateCoalitionDisplay() {
        const display = document.getElementById('coalition-members-count');
        if (display) {
            display.textContent = this.coalitionMembers.size;
        }
    }

    updateEmergencyModeDisplay() {
        const display = document.getElementById('emergency-mode-status');
        if (display) {
            display.textContent = this.emergencyMode === 'NONE' ? 'Inactivo' : this.emergencyMode;
            display.className = this.emergencyMode === 'NONE' ? 
                'px-2 py-1 bg-green-500 text-white text-xs rounded-full' :
                'px-2 py-1 bg-red-500 text-white text-xs rounded-full';
        }
    }

    updateDefenseStatus(status) {
        this.defenseStatus = status.status;
        this.activeThreats = new Map(status.activeThreats || []);
        this.coalitionMembers = new Set(status.coalitionMembers || []);
        this.emergencyMode = status.emergencyMode || 'NONE';
        
        this.updateDefenseDisplay();
    }

    updateDefenseDisplay() {
        this.updateThreatCounter();
        this.updateCoalitionDisplay();
        this.updateEmergencyModeDisplay();
    }

    updateDefenseHistoryDisplay() {
        const container = document.getElementById('defense-history-list');
        if (!container) return;
        
        // Mantener solo los últimos 20 registros
        const recentHistory = this.defenseHistory.slice(-20);
        
        container.innerHTML = recentHistory.map(record => `
            <div class="flex items-center justify-between p-2 border-b border-gray-200">
                <div>
                    <span class="text-sm font-medium">${record.threatId}</span>
                    <span class="text-xs text-gray-500 ml-2">${new Date(record.timestamp).toLocaleTimeString()}</span>
                </div>
                <span class="px-2 py-1 text-xs rounded-full ${record.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                    ${record.success ? '✅' : '❌'}
                </span>
            </div>
        `).join('');
    }

    showDefenseNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 max-w-sm ${
            type === 'success' ? 'bg-green-500 text-white' :
            type === 'error' ? 'bg-red-500 text-white' :
            type === 'warning' ? 'bg-yellow-500 text-black' :
            'bg-blue-500 text-white'
        }`;
        
        notification.innerHTML = `
            <div class="flex items-center space-x-2">
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" class="ml-2 text-white hover:text-gray-200">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    getDefenseStats() {
        return {
            activeThreats: this.activeThreats.size,
            totalThreats: this.defenseHistory.length,
            coalitionMembers: this.coalitionMembers.size,
            emergencyMode: this.emergencyMode,
            defenseStatus: this.defenseStatus,
            autoResponse: this.defenseConfig.autoResponse
        };
    }
}

// Inicializar sistema de defensa cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    if (!window.mevDefense) {
        window.mevDefense = new MEVDefenseSystem();
        console.log('🛡️ Sistema de Defensa MEV inicializado');
    }
});

// Función global para ejecutar defensa (llamada desde HTML)
window.executeDefense = (threatId) => {
    if (window.mevDefense) {
        window.mevDefense.executeDefenseResponse(threatId);
    }
};

// Función global para escalar amenaza
window.escalateThreat = (threatId) => {
    if (window.mevDefense) {
        window.mevDefense.escalateThreat(threatId);
    }
};
